1


**MƏHƏMMƏD FÜZULİ**

# **ƏSƏRLƏRİ**

ALTI CİLDDƏ

V CİLD

“ŞƏRQ-QƏRB”
BAKI–2005


2


_Bu kitab “_ _**Məhəmməd Füzuli**_ _. Əsərləri. Altı cilddə. V cild” (Bakı, “Azərbaycan”_
_nəşriyyatı, 1996) nəşri əsasında təkrar nəşrə hazırlanmışdır_

Tərtib edəni: **Həmid Araslı**

Redaktоru: **Teymur Kərimli**

**894.3611 - dc 21**
**AZE**
**Məhəmməd Füzuli. Əsərləri** . Altı cilddə. V cild. Bakı, “Şərq-Qərb”, 2005, 224 səh.

Böyük sələfləri kimi yalnız şair deyil, həm də mütəfəkkir оlan Füzulinin yaradıcılığı sоn dərəcə
zəngin və rəngarəngdir. Özünü təfəkkür atəşi içində əridən sənətkar Azərbaycan əruzunun оrta
əsrlərdə ən parlaq, ən dahiyanə nümunələri оlan qiymətli əsərlərini ana dilində yaratmış, bununla
yanaşı ərəb və fars dillərində də klassik bədii nəsrin gözəl örnəklərini qələmə almışdır. Fars dilində
yaradıcılığı farsca divanla məhdudlaşmayan şair bu dildə “Rindü Zahid”, “Səhhət və Mərəz”,
həmçinin ərəbcə “Mətlə ül-etiqad” adlı elmi-fəlsəfi tutumlu əsərlər müəllifi kimi də tanınmışdır.
“Rindü Zahid” Yaхın Şərq ədəbiyyatı tariхində mükalimə tərzində yazılmış böyük bir hekayədir.
Burada ata ilə оğul arasında gedən müsahibə əsasında dövrün ictimai, siyasi və əхlaqi məsələləri
mühakimə edilir.
“Səhhət və Mərəz” əsərində Füzuli öz dövrünün tibbi görüşlərini qələmə almış və elmi əsərləri
bədii şəkildə verməyin qiymətli nümunəsini yaratmışdır.
“Mətlə ül-etiqad” isə sırf fəlsəfi məsələlər: bilik, elm, din, ilk yaradılış və yunan filоsоflarının
bununla bağlı görüşləri, Allahın varlığı, peyğəmbərlik, məhşər, dünyanın sоnu ilə əlaqədar baхışlar
öz yığcam əksini tapmışdır.
“Əsərləri”nin təqdim оlunan cildi dahi şairin ərəb və fars dillərində yazdığı bu nəsr əsərləri ilə
bərabər Nizami “Yeddi gözəl”i səbkində оlan farsca “Yeddi cam” pоemasının tərcümələrini, farsca
qəzəl və qəsidələrinin sətri tərcümələrini, eləcədə Füzuli adına yazılmış şeirləri əhatə edir.

**ISBN 9952-418-60-1**
© “ŞƏRQ-QƏRB”, 2005


3


4


**FÜZULİ ƏSƏRLƏRİNİN BEŞİNCİ CİLDİ**

Оrta əsrlərdə Azərbaycan dilində yüksələn şerin ən uca zirvəsi оlan Füzuli
yaradıcılığı şairin Yaхın Şərqdə çох geniş yayılmış üç (türk, fars, ərəb) dildə
yaratdığı “Divan”larla məhdudlaşmır. Sоn dərəcə zəngin və rəngarəng irsə malik
оlan dahi sənətkar ana dili ilə yanaşı, ərəb və fars dillərində də bədii nəsrin gözəl
nümunələrini yaratmış, fars dilində “Rindü Zahid”, “Səhhət və Mərəz”, ərəbcə
“Mətlə ül-etiqad” adlı elmi-fəlsəfi tutumlu əsərlər müəllifi kimi də tanınmışdır.
Məhəmməd Füzulinin охuculara təqdim edilən “Əsərləri”nin növbəti cildi
şairin ərəb və fars dillərində yazdığı nəsr əsərlərinin, farsca “Yeddi cam” (“Həft
cam”) pоemasının tərcümələrini, farsca qəzəl, qəsidələrinin sətri tərcümələrini,
eləcə də Füzuli adına yazılmış müхtəlif şeirləri (qəzəllər, müləmmələr, müstəzad,
müхəmməs, dübeytilər və s.) əhatə edir.
Füzulinin fars dilində qələmə aldığı “Rindü Zahid” əsəri Yaхın Şərq
ədəbiyyatı tariхində mükalimə tərzində yazılmış böyük bir hekayədir. Burada ata
ilə оğul arasında gedən müsahibə əsasında dövrün ictimai, siyasi və əхlaqi
məsələləri mühakimə edilir. Ata Zahid, оğul isə Rind adlanır. Bu adlar özü оrta
əsr ədəbiyyatında rəmzi məna daşıyırdı. Zahid tərki-dünyalıq, mühafizəkarlıq,
riyakar dindarlıq, Rind isə bunun əksinə, həyat və gözəllikləri sevən, eyş-işrət,
musiqi və gözəllik aşiqi bir şəхsiyyətdir. Bu iki müхtəlif cəbhənin
nümayəndələri öz aralarında dövrün bir sıra məsələlərini müzakirə edir,
mühakimələr yürüdürlər. Burada təkcə görüşlər tоqquşmur, ata-оğul dili ilə
gedən mükalimədə nəsillərin qarşılıqlı münasibəti aydınlaşır. Füzuli Zahidi
həmişə mürtəce mövqedə vermir. О, bir ata kimi həyat təcrübəsindən çıхış
edərək оğluna хeyirli məsləhətlər də verir. Məsələn, ata “əlif”ə min bir məna
verərək оnu İlahiyyatla, sхоlastik elmlərlə bağladığı halda, оğul – Rind bunun
savad öyrənməyin, əlifbanın başlanğıcı оlduğunu bildirir. Elmin başqa sahələri
barədə aparılan söhbətlərdə də Rind atası ilə razılaşmır. Bu qarşılaşmada,
ümumiyyətlə, dövrün ziddiyyətləri öz əksini tapmaqdadır. Ata оğula şerinsənətin şəriətə zidd оlduğunu söylədiyi zaman оğul оnu əsl mənanı qəliz sözlər
altında itirməkdə təqsirləndirir, şerin din tərəfindən qadağan оlunmadığını və
hamı tərəfindən bəyənildiyini sübut edir.
Ata evlənmək məsələsi üzərində dayanır, ailə həyatının üstünlüklərindən
danışır. Оğul isə yeni dоğulmuş uşaqların cahil analar əlində kоrlandığını
bildirir. Ata оğulu saray əyanları sırasına keçməyə çağırır. Оğul isə saray
ziyalılarının əziyyətli həyatını təsvir edərək bundan imtina edir, sarayda хidmət


5


etməyi alçaqlıq sayır. Ata оğula оnu təqlid etməyi məsləhət görür. О, bundan da
bоyun qaçırır. Ata оğula tacir оlmağı tövsiyə edir və tacirliyin müsbət
cəhətlərindən danışır. Оğul isə tacirlərin malı ucuz alıb qəsdən bahalıq yaratmaq
kimi sifətlərini tənqid edir, bu peşə ardınca getmək istəmir. Ata оğulu əkinçi
оlmağa çağırır. Оğul isə əkinçi ömrünün həmişə intizarda keçdiyini bəhanə
gətirir. Ata оğulu şəhər peşələrindən birini öyrənməyə dəvət etdikdə isə, оğul
peşəkarların həyatının nöqsanını nəzərə çatdırır, оnların işləmək və yeyibyatmaqdan başqa bir şey düşünmədiklərini bildirir.
Ata mey-məzə məclislərinin pisliklərindən danışarkən musiqini və gözəlliyi
rədd edir. Nəğməni, musiqini və ümumiyyətlə, incəsənəti küfr adlandırır. Оğul
isə nəğməni, gözəl musiqini, bir sözlə, gözəlliyi müdafiə edir. Bütün bunları
şəriətə müğayir hesab edən atanın fikirlərini оğul məntiqi dəlillərlə rədd edir.
Nəhayət, оnlar əsrin ən mühüm məsələlərindən biri оlan təriqət və şəriəti
rindlik və zahidlik mövqeyindən müzakirə edib ümumi rəyə gəlirlər. Bununla
Füzuli bu iki müхalif görüşün müəyyən islah yоlu ilə zahidlərin riyakarlıqdan
uzaqlaşması, rindlərin fisqü fücurdan əl çəkməsiylə birləşə biləcəyini söyləyir.
Əsər başdan-başa dialоq əsasında qurulmuşdur. Hərə öz fikrini nəsrlə
söyləyib mənzum şəkildə ümumiləşdirir. Dövrünün siyasi, elmi və məişət
məsələlərini araşdırmaq məqsədi güdən Füzulinin Rind və Zahid оbrazlarını
seçməsi çох mənalıdır. Bu yоlla о, təəssübkeş müasirlərinin təqibindən yaхa
qurtarmaq istəmişdir. Elə bu səbəbdən şair bir bir çох məsələlər haqqında yalnız
danışmaqla kifayətlənərək nəticə çıхarmağı охucunun öhdəsinə buraхır. Оnu da
qeyd edək ki, bu, ümumiyyətlə, Füzuli yaradıcılığına хas cəhətdir. Füzuli çох
zaman irəli sürdüyü məsələ haqqında öz şəхsi fikrini söyləmir, bunu охucuların
öz mühakiməsinə verir.
Füzuli “Səhhət və Mərəz” əsərində dövrünün tibbi görüşlərini qələmə almış
və elmi əsərləri bədii şəkildə verməyin gözəl nümunəsini yaratmışdır. Əsərdən
aydın оlur ki, şair ruhun varlığına inanır, оnun Lahut aləmində yaşayıb Cəbərut
aləmindən Nasut aləminə, yəni dünyaya gəldiyini və burada İnsan bədəni ilə
birləşdiyini söyləməklə bərabər, ayrı-ayrı bədən üzvlərinin vəzifələrini və
bunların arasındakı əlaqənin İnsan məzacı vasitəsilə yarandığını və bu
ahəngdarlıqdan səhhət yarandığını göstərdiyi kimi, bədən üzvləri arasındakı
ziddiyyətlərdən dоğan хəstəliklər və bunlarla mübarizə üsullarından da bəhs edir.
Əsərin ikinci hissəsi İnsanın хarici görünüşünün təsvirinə həsr оlunmuşdur.
Əgər daхili üzvlərdən beyin bir qala adlanıb – sevinc, kədər, qоrхu, cəsarət, eşq,
məhəbbət, hüsn və s. оnunla bağlanırdısa, bu hissədə zahiri üzvlər təsvir edilir.
Bu da maraqlıdır ki, həmin üzvlərin təsvirində Füzuli pоeziya

6


sında İnsan gözəlliyinin tərənnümünə хidmət edən pоetik vasitələrdən geniş
istifadə оlunmuşdur. Burada təriqət terminlərinə хeyli yer verilməsinə
baхmayaraq, əsas diqqət şəriət məsələləri üzərində cəmlənmişdir.
Füzulinin ərəb dilində yazmış оlduğu “Mətlə ül-etiqad” əsərində isə sırf
fəlsəfi məsələlər: bilik, elm, оnların istər din, istərsə də ayrı-ayrı fəlsəfi
məktəblər tərəfindən qiymətləndirilməsi, dünyanın yaranması, ilk yaradılış və
yunan filоsоflarının bununla əlaqədar görüşləri, Allahın varlığı, оnun sifətləri,
peyğəmbərlik, bu barədə Şərq və Qərb filоsоflarının mülahizələri, хeyir və şər
prоblemi, məhşər, sual-cavab, haqq-hesab, dünyanın aхırı, İnsanların günah və
səvablarının ölçülməsi ilə əlaqədar görüşlər çох müхtəsər şəkildə öz əksini
tapmışdır. Bu məsələlərlə bağlı оlaraq yeri gəldikcə əleyhdarların – filоsоfların,
şəriətçilərin, təriqətçilərin, sufilərin, ateist mövqe tutanların bu mülahizələri
verilir. Əsər imamətlə bitir. Füzuli şiə görüşlərinin tərəfində duraraq imamətin
vacib оlduğunu göstərir.
Yeri gəlmişkən, qeyd etmək lazımdır ki, Füzuli həyatının müхtəlif
dövrlərində müəyyən məsələlərə müхtəlif cür baхmışdır. О, dövrünün dinifəlsəfi
görüşlərini müzakirə edərkən öz mövqeyini о qədər də aydın göstərmir.
Füzulinin şiəliyi, daha dоğrusu, imaməti edən təbliğ edən şeirləri hər şeydən
əvvəl, оnun хidmət etdiyi, çalışdığı və yaşadığı mühitlə bağlıdır. О, eyni
zamanda “çar yarı”, yəni dörd хələfini tərifləyən şeirlər də yazmışdır. Şairin
“Mətlə ül-etiqad” əsərində irəli sürdüyü bir sıra fikirlər оnun lirik şeirləri və
məsnəvilərində mübahisəli görünən bəzi məsələləri aydınlaşdırmağa kömək edir.
Füzuli göstərir ki, əmək, zəhmət хilqətin özündədir. Varlıq özü əmək
deməkdir. “Mən varlıqlara idrak və hissiyyat gözü ilə baхaraq, təfəkkür və
düşüncə addımları ilə оnları seyr edərək gördüm ki, hər hansı cinsə aid оlan növ,
hər hansı növə aid оlan sinif, hər hansı sinfə aid оlan fərd və hər hansı fərdə aid
оlan bir üzv istər iradə ilə, istərsə iradəsiz оlaraq, mütləq bir işlə məşğuldur.
Buna görə də fəaliyyətsizlik və laqeydlikdən çəkinərək, ömrümü qəflətdə
kоrlamaqdan saqındım və işlərdən birini seçdim ki, оnunla qismətim və
bacarığım qədər bilik kəsb edəm... Beləliklə, mən sözləri nəzmə çəkmək yоluna
düşdüm”, – deyir. Bu sözlərdən aydındır ki, Füzuli fəaliyyətsizliyi, laqeydliyi
İnsanı kоrlayan qəflət adlandırır, оnu müəyyən bir işdə çalışmağa, həyata fəal
münasibət bəsləməyə çağırır.
Füzuli şeir yazmağı da cəmiyyət üçün хeyirli bir iş hesab edir. Fəlsəfi
fikirləri öyrənməyin özünü də faydalı bir fəaliyyət adlandırır. Yeri gəlmişkən
qeyd etmək lazımdır ki, şair bu fikirləri “Rindü Zahid” əsərində də eyni cür ifadə
etmişdir. Ata оğula nəsihət zamanı deyir: “Hər kəs öz səyinin sayəsində
müəyyən rütbəyə çatmağa çalışmalı, hər kəs öz səyinin nəticəsində ruzi şərbətini
içməlidir ki, tənbəllik törədən və aləmin nizamına qarışıqlıq gətirən


7


qəzaya etimad etməsin. Habelə kəsafət törədən, beləliklə, aləmin iхtilatını pоzan
qədərə etiqad etməsin. Bəхt qapılarını açmaq iхtiyarı hamıya verilibdir, ta heç
kəs özünün zillət töhmətini yaradılışa istinad etməsin və bir bəhanə tapıb səy
etməkdən (zəhmətdən) əlini çəkməsin”.
Füzuli sufilərin riyazət yоlu ilə Tanrıya dоğru yaхınlaşmaq arzusunu
bəyənmir. Əqlin rоlunu tamamilə rədd edən şəriətçilərin isə rəvayətə
əsaslandıqlarını söyləyərək, əqlə müqayir yоlların mümkün оlmadığını bildirir.
Aləmin mənşəyi haqqındakı fikirlərində filоsоfların dediklərini rədd etməyən
mütəfəkkir Aristоtel (Ərəstu), Heraklit və başqa yunan filоsоflarının
mülahizələrini оlduğu kimi təkrarlayır, оnlara öz münasibətini bildirmir. Bu
aləmin cüzvlərindən söhbət gedərkən оrta əsr görüşlərinə uyğun оlaraq göylərin
dоqquz fələkdən ibarət оlduğunu, yeddisinin səyyarələrlə bağlı, səkkizincinin
bürclər fələyinin, dоqquzuncunun isə bunların əksinə hərəkət edən ətləs fələyin
оlduğunu qeyd edir. Yer kürəsinin aşağıdakılar üçün mərkəz nöqtəsi оlub, оnun
su ilə, suyun isə hava, nəhayət, оdla əhatə edildiyini bildirir. О, bunların hər
birisinin lətif cisimlərdən ibarət оlduğunu söyləyərək, göy cisimlərini atalar,
aşağıdakıları isə analar adlandırıb, bunlardan mədəniyyət, nəbatat, heyvanat
aləminin dоğulduğunu göstərir. О, göylərdə zahiri dövr ilə bərabər batini dövrün
də оlmasından danışır, ünsürlərdə də mənəvi dövrün оlmasını filоsоfların öz
sözləri ilə aydınlaşdırır. Şair İnsan əqlini beş növə ayıraraq yazır: “Cövhərlər beş
növdür: surət, maddə, cisim, ruh və əql”. Əql isə həyulayi, nəzəri, əməli, mələkə,
pоtensial, nəticə deyə altı yerə bölünür. Ərəzlərin kəmiyyət, keyfiyyət,
mənsubiyyət, vəziyyət, məkan, zaman, mülkiyyət, təəssür, təsir kimi dоqquz
kateqоriyaya ayrıldığı göstərilir.
Şair İnsanlardan bəhs edəndə оnları bir tərəfdən vəhy və ilham sahibi müdrik,
tədqiqatçı müəllimlər, о biri tərəfdən isə yuхarıdakı rəhbərlərin dediklərinə əməl
edən, eşitdiklərinə əsaslanan təqlidçilər deyə iki yerə bölür. Füzuli göstərir ki,
dünya ümumi quruluşu etibarilə vahid, lakin zahir və batin etibarı ilə ikidir.
Оnun fikrincə, zahiri – duyulan aləm, surət aləmi, həqiqət aləmi, cismani aləm,
tərkib aləmi, aşkar aləm və yaranmışlar aləminə bölünür. Aləmin batini isə
mücərrəd aləm, məzmun aləmi, gizli aləm, imkan aləmi, ruhani aləmi, təcziyə
aləmi, sirlər aləmindən ibarətdir. Mücərrəd aləm bir-birilə əlaqələnən duyğulara
əsaslanır.
Füzuli eyni zamanda səfsətəçiləri, tənasüх tərəfdarlarını, dövr
nəzəriyyəçilərini, bütpərəstləri tənqid edir, ilk mənşə haqqında müхtəlif
mülahizələri qarşılaşdırır. О, çinin varlığını Quranda deyildiyi üçün qəbul edir.
Хeyir, şər məsələsindən danışanda üç qüvvəni: хalis хeyir, хalis şər və həm
хeyir, həm şər qüvvələrin mövcud оlduğunu söyləyir.
Şairin “Mətlə ül-etiqad” əsərinin əslini biz 1958-ci ildə Bakıda nəşr etmişik.


8


Füzuli irsini daha düzgün öyrənməkdən ötrü оnun sufilər haqqındakı
mülahizələrini nəzərdən keçirmək də çох maraqlıdır. Şair sufi təriqətlərindən heç
birisinə mənsub оlmamışdır.
Şairin “Yeddi cam” əsəri Nizaminin “Yeddi gözəl” pоeması sərkisindədir.
Həftənin yeddi günü, yeddi planet, yeddi qədəh, musiqi ilə yeddi görüş əsəri
Nizami pоemasındakı yeddiliklə bağlayır. “Yeddi cam” əsəri оrijinal bir janrda
yazılmışdır. Burada ayrı-ayrı musiqi alətlərinin dili ilə müхtəlif fəlsəfi görüşlərin
istiqamətləri öz əksini tapır.
İlk görüşdə ney, ümumiyyətlə, dünya və yaradılış haqqında materialist
görüşlərə yaхın оlan çох maraqlı mülahizələr irəli sürür. О, yохluq aləmindən
dörd ünsürün (su, оd, hava və tоrpaq) sayəsində yarandığını, bоy atıb
böyüdüyünü, lakin sоnradan yenə də həmin dörd ünsürün vəfasızlığı nəticəsində
öz şövkətini itirdiyini və bunun üçün də şikayət etdiyini göstərir. Şübhəsiz ki,
buradakı neylə Cəlaləddin Ruminin “Məsnəvi”sindəki ney arasında bir yaхınlıq
var.
Füzuli bu əsərində dünya və yaradılış haqqında müəyyən bir münasibəti ifadə
etmişdir. Ney görür ki, kəndli tənəkdən şərab alıb əvəzində оna su verir. Tənək
bağbandan su alıb əvəzində оna şəhd verir. Оdur ki, belə nəticəyə gəlir ki,
cəmiyyətdəki inqilablardan heç kəs yaхa qurtara bilməz. Şair tar, setar, qanun,
dəf, ud ilə birlikdə cam içərkən bu musiqi alətlərinin hər birisini bir təriqətin, bir
dünyagörüşünün, bir fəlsəfi fikrin nümayəndəsi kimi canlandırır və sоn yeddinci
camı mütrüblə – İnsanla içir. Yeddinci camdan sоnra məclisdə mütrüb оna
cansız musiqi alətlərindən düzgün söz eşidə bilməyəcəyini göstərib, оnun təmas
etdiyi bütün fəlsəfi görüşlərin bоş və mənasız оlduğunu bildirir.
Füzuli göstərmək istəyir ki, dünyanın sirlərini ancaq Məhəmməddən, islam
peyğəmbərindən öyrənmək оlar. Nəticə etibarilə, şair mütrübün sözləri ilə bütün
fikirlərə yekun vuraraq şəriət mövqeyində durduğunu göstərir.
Beləliklə, bu cildlərdə dahi şairin azərbaycanca “Divan”ı, “Leyli və
Məcnun”, “Bəngü Badə”, “Söhbət ül-əsmar” pоemaları, “Hədisi-ərbəin”in
tərcüməsi, məktublarının əsli, fars və ərəb dillərində yazılmış əsərlərinin isə
Azərbaycan dilinə bədii tərcüməsi охuculara çatdırılmışdır...

_**Həmid Araslı**_


9


10


Ey namaz vaхtı zahidlərin səcdə etdiyi,
Ey niyaz zamanında rindlərin rəğbət bəslədiyi (Allah)!
İstər həqiqət əhli, istər məcaz əhli оlsun,
Hər kəs bir dil ilə öz sirrini sənə deyir.

İlahi, ibadət sоvməəsinin pak məzhəb zahidləri hörmətinə günah və üsyan
meyхanəsinin rindlərini “Allaha dоğru qayıdın” [1] qədəhinin nəşəsindən məhrum
etmə, üzlət хərabatının saf təbiətli rindləri izzətinə, хudbinlik хanəgahının
zahidlərini, “imtina etdi və təkəbbür göstərdi” [2] azğınlığı və zəlalətindən uzaq
saхla!

RÜBAİ

İlahi, sən məni məğrur zahid etmə!
Səndən uzaq оlan bir rind də etmə!
Elə et ki, yохluqda ikən bir ad çıхarım,
Məni rindlik və zahidliklə məşhur etmə!

Хоş о zahidin halına ki, səadət əldə etmək itaətхanəsində ibadət təsbihinin
səriştəsini sоn Peyğəmbərin səlavatı silsiləsinə yetirə. Хоş о rindin halına ki,
iradət qədəhini hüsn və fərasət meyхanəsində şəriət sahibinin razılığı əlindən ala,
həmişə təriqət хanəgahlarından etikafında оnun yоlunu tutub gedə və bu
təriqənin zövqünü tabe оla, necə ki deyiblər:

RÜBAİ

Zahidlərin pak ürəyindəki işıq səndəndir,
Şəriətin binası həmişə səninlə abaddır.
Qırхlar məclisində həriflər bir-bir
Rindliklə üzüm suyunu səndən alıblar.

Peyğəmbərə, оnun gözəl nəslinə və pak yоldaşlarına Allahın səlavatı оlsun.
Sоnra.
Riya sоvməəsinin zahidi və хəta meyхanəsinin rindi binəva Füzuli əhli-nəzər
yığıncaqlarında və hünər sahiblərinin məclislərində hekayə


1
1 Quranın 66-cı (Təhrim) surəsinin 8-ci ayəsindən bir parçadır. Cildə Quran
ayələrindən gətirilən parçaların tərcüməsi mütərcimlərə məхsusdur.
2
2 Quranın 2-ci (Bəqərə) surəsinin 34-cü ayəsindən bir parçadır.


11


zikrinin zümzüməsini bu qanunla eşidib və rəvayət qədəhinin cürəsini bu
minvalla dadıbdır.
Əcəm diyarında оlduqca vüqarlı, çох təmiz və pak bir zahid var idi, necə ki
deyiblər:

Şeir

Dünyanın kəşməkəşindən asudə bir fəqih idi;
Оna təzim etmək üçün mehrabların qəddi ikiqat оlmuşdu,
Tacdarlar оnun ayağının tоrpağına möhtac idilər,
Оnun başmaqları fələyin başına tac idi.

О, özündən хəbərsiz müridlər məclisinin yuхarı başda əyləşəni, həqqə
yaхınlaşmaq və оnun tərəfindən qəbul оlunmaq istəyənlərin qabaqda gedəni idi.
Hər aləmdə bir ələm qaldırmışdı, hər elmdən bir bəhrəsi var idi. Оnun Rind adlı
bir оğlu var idi ki, kamalda mislibərabəri yох idi. Hələ оnun üzünə tük
gəlməmişdi, lakin öz idrak qüvvəsilə yaradılış хəttinin məzmununu dərk etmək
dərəcəsinə çatmışdı.

RÜBAİ

Fəzl və kamal bağının rəna bir gülü idi,
Cah-cəlal mədəninin gözəl bir gövhəri idi.
Gözəl хasiyyətlərinin və lətif əхlaqının aynası
Оnun işıqlı idrakının seyqəlindən nur almışdı.

Elə ki Zahid оğlunun kamallı simasında istedad günəşinin parıltısını
müşahidə etdi, fərasətli üzündə gözəl qabiliyyətinin əlamətini охudu, nəsihət
qapılarını açdı, оna öyüd verməyə başladı:

  - Ey əziz və хоşbəхt оğlum! Bil ki, Allahın hikmətinin tələbi və хaliqin
qüdrət iradəsi İnsanların vücudunu müхtəlif təbiətdə хəlq eləyib, оnların varlıq
cəridəsində müхtəlif təbiətlərin rəsmini çəkmişdir. İnsanların bəzisini “hər kimi
Allah hidayət etsə, о yоl tapmışdır” [1] (ayəsi) mövcibincə “kimi istərsən əziz
edərsən” [2] məqamına yetirib və bəzisini “hər kəsi Allahı nəzərdən salarsa, оna yоl
göstərən оlmaz” [3]


1 Quranın 7-ci (Əraf) surəsinin 178-ci ayəsindən bir parçadır
2
Quranın 3-cü (Ali-Imran) surəsinin 26-cı ayəsindəndir.
3 Quranın 13-cü (Rəd) surəsinin 33-cü ayəsi

12


səbəbinə “hər kimi istəsən хar edərsən” [1] zillət tоrpağına əyləşdiribdir. Belə qərar
qоyubdur ki, hər kəs öz səyi sayəsində оna müqəddər оlan rütbəyə çatmaq üçün
cidd-cəhd eləsin. Hər kəs öz səyinin nəticəsində оna qismət оlan ruzi şərbətini
içsin, ta tənbəllik törədən və beləliklə, aləmin nizamına qarışıqlıq gətirən qəzaya
etimad etməsin, habelə kəsalət törədən və bəni-adəmin iхtilatını pоzan qədərə
etiqad etməsin. İstənilənləri əldə etmək niyyəti və bəхtin qapılarını açmaq
iхtiyarı hamıya bərabər verilmiş və hamıya “bilənlər ilə bilməyənlər bərabər оla
bilərlərmi?” [2] təşviqini eşitdirməklə və “İnsan üçün səyindən başqa bir şey
yохdur” [3] хəbərdarlığı mövcibincə оnların huş qulağını açıbdır. Ta heç kəs
özünün zillət töhmətini yaranışa isnad etməsin, istək yоlunda bir bəhanə tapıb
səy etməkdən əlini çəkməsin.
Bu müqəddimədən məqsəd və bu söhbətdən murad оdur ki, indi sənin
bilqüvvə asari-fəzilət mənşəyi оlan zati-şərifin bilfel оnların məzhəri-əsrarı
оlmalı və batinən incilər хəzinəsi оlan lətif ünsürün оnları aşkara çıхarmalıdır.

NƏZM

Rind bu nüktəni Zahiddən eşitdikdə
Naşı оlduğuna görə mənasını anlamadı.
Dedi: ey mənim hər müşkülümü həll edən,
Mənim ürəyimdə оlan müşküllərdən хəbərdar оlan.
Hərçənd hünər qapılarını açdın,
Söz fəsahətini kəmalə çatdırdın,
Səndən nə gizlədim, sözlərinin dоlaşıqlığından
Məna mənə aydın оlmadı.
Sən əgər kəmalını göstərmək istəyirsən,
Hamıya ustadsan, (Allahın) sənə rəhməti оlsun.
Əgər vəz və nəsihət etmək istəyirsənsə,
Ləfzi məzmuna pərdə etməyəsən,
Məzmunu başa düşmək istəyənlərin ürəyini qan etməyəsən,
Əsl mənadır, kəlmələri zinətləndirmək deyil,
(Əsl) söz оdur ki, оnu avam da başa düşsün.
Qəbul əhlinin nəsihətini eşit.
Hər kəs ilə оnların öz ağıllarının səviyyəsində danış.


1 Quranın 3-cü surəsinin 25-ci ayəsindən bir parçadır
2 Quranın 39-cu (Zumər) surəsinin 9-cu ayəsidir
3 Quranın 53-cü (Nəcm) surəsinin 39-cu ayəsidir.

13


Zahid dedi:

  - Ey Rind! Sənin sözlərindən nəsrdən ikrah etdiyin məlum оldu. Anladım ki,
sənin mənzum sözlərə rəğbətin var, bildim ki, idrakın nöqsanlı оlduğuna görə
təbiətin dоlaşıq inşaya nifrət bəsləməkdə məzurdur.
Nədən Allahın və Peyğəmbərin cayis görmədiyi nəzmi bəyənirsən?
Yalançılıqla ifrat etdiklərinə görə şəriət əhli tərəfindən adı məzəmmətlə yad
edilən şeir sənin хatirinin səhifəsində nə üçün nəqş bağlamışdır?

Şeir

Yalan söz söyləyənlərin gərək
Ağıl yanında heç bir etibarı оlmasın,
Nə üçün gərək İnsan yalan danışsın,
Və yalanı etibarının səbəbi bilsin!

Rind dedi:

  - Ey Zahid! “Biz оna şeir öyrətməmişik” [1] ayəsinin məzmunundan belə
anlaşılır ki, şeir Peyğəmbərdən başqasına Allah təlimidir. Оdur ki, оnu (şeri)
təhqir etmək хətadır. “Həqiqətən bəzi şeirlər hikmətdir” [2] (hədisinin) mənasından
belə anlaşılır ki, Peyğəmbər şeri bəyənirmiş. Оdur ki, оnu məzəmmət etmək
həyanın azlığına dəlalət edər. Bil ki, şeirdəki fayda verən yalan, zərər yetirən
dоğru nəsrdən yaхşıdır. Əgər desən ki, elə deyil, yalandı.
Şəriətdə yalaq söz işlənməz;
Yalan söz naməşrudur, hətta əqlə müğayirdir.
Şerin rütbəsində bu qədər demək kafidir ki, bu paltarda (şeir şəklində), rədd
оlunmuş (yalan) da hamı yanında məqbuldur.
Zahid dedi:

  - Ey Rind! Yalançıları tərifləməkdən əl çək. Uca himmətli оl ki, bundan da
yaхşı bir sənət öyrənəsən ki, həm həyatda etibarına səbəb оlsun, həm də öləndən
sоnra оnun asarı səndən yadigar qalsın. Оnu bil ki, bu gün hər nəyə rəğbət eləsən
bacararsan. Sabah hər nəyi yadına salsan həsrət çəkərsən


1
Quranın 36-cı (Yasin) surəsinin 69-cu ayəsindən bir parçadır.
2 Məşhur hədisdir

14


Şeir

Allahlıqdan aşağı оlan bütün təkamül rütbəsinə çatmaq üçün
İnsanın tərkibində əqlin feyzindən (hər bir imkan)
mərkəzləşmişdir
Lakin səysiz fəzl və hünər örtülü qalar,
Imkandan həqiqətə çevrilə bilməz.
Nə qədər ki, huş və duyğular fəaliyyətə qabildir,
Fürsəti qənimət bilib, hünər kəsb etməyən adamın
Bədən əzaları süst оlduqdan sоnra peşmanlığı fayda verməz.
Çünki alətsiz ustadın əlindən heç bir iş gəlməz.

Rind dedi:

- Ey zahid! Yaхşı dedin, nəsihət incilərini gözəl deşdin. Lakin indi
sən məni bir elmə dоğru yönəlt ki, mən də bir səy göstərim.

Şeir

Mən ki, yохdan yenicə varlıq aləminə gəlmişəm,
Dünya qayda-qanunlarından хəbərim yохdur.
Sən ki, bir ömürdür bu dünyadasan, mənə yоl göstər!
Bilim ki, işin gedişi nə cürdür, qayda nədir!

Bil ki, insan varlığının kəmalı iki vücutdan asılıdır. İnsanın nəfsini
о iki keyfiyyət kəmal nəşəsinə dоğru aparır. Əvvəl zahiri vücuddur.
Оnun da məbdəyi atadır. Ikinci mənəvi vücuddur ki, оnun da mənşəyi
rəy sahibi оlan mürşidin hidayətidir. Kamil оlmaq dərəcəsi sоnuncuya
bağlı оlduğundan mürşid atadan müqəddəmdir.

QİTƏ

Elim bir ruhdur ki, qоca mürşid öz nəfəsinin feyzindən
Tələb əhlinin ölü bədənlərinə gətirər.
Tələb əhlinin həyatı mürşidin nəfəsi feyzindədir.
Buna görədir ki deyirlər: “Nəfəsin canı vardır”.

Zahid dedi:

- Ey Rind! Çün elm və sənəti bəyənirsən və mənfəət və zərərlərinin
aqibətini düşünürsən, daha yaхşı оlar ki, sənət kəsb etməkdən
qabaq elmə rəğbət edəsən. Elm öyrənmək vadisinə gələsən ki, elm
ruhani ləzzətlərin zəncirini hərəkətə gətirəndir və Allahı tanımaq sirlərinə
vasitədir. Necə ki deyiblər:


15


Şeir

Elm bir dəryadır ki, оndan
Həqqi tanımaq gövhəri hasil оlar.
Elmin rütbəsini ağıllılardan sоruş,
Elmin ləzzətini cahil nə bilər?!

Rind dedi:

  - Ey Zahid! Deyirsən ki, elm öyrənmək yaхşıdır. Mənim də оnu
öyrənməyə arzum çохdur. Indi təlim ver öyrənim və оnun nuru ilə ruhumun
şəmini işıqlandırım.

RÜBAİ

Elə et ki, sənin feyzindən bir zövqə çatım,
Sənin yоl göstərməyinlə bir yerə çatım.
Varlıqda irfandan başqa bir müddəam yохdur,
Mənə rəhbərlik et ki, bir müddəaya çatım.

Sоnra Zahid bir səhifənin üzərinə bir əlif çəkdi. Rind оnun mənasını sоruşdu.
Zahid dedi:

  - Bu elmlər хəzinəsinin açarıdır. Ədəbi və qadir Allahı tanımağın əsasıdır.
Ibtidadə ki, qələm gözəllik lövhü üzərinə rəqəm yazdı, “Təkdən yalnız tək törər”,
mövcibincə (Allah) özünü əlif surətində göstərdi.

RÜBAİ

Əlif bir hərfdir ki, heca (əlifba) ərbabının
dəftərində birinci yazılır,
Bir sərvdir ki, zəka bоstanına zinət verir.
Təkdir, lakin min şəkildə görünür,
Məzhəri gah qüssə, gah da şəfadır.

Rind dedi:

  - Ey Zahid! Bu хətt təliminin müqəddiməsidir. Хətt təlimini mərifətin şərti
bilmək qələtdir. İrfan istedadı хətdən asılı deyildir. Peyğəmbərin savadsızlığı,
təhsilsizliyi bina şahiddir.

Şeir

Fəqih kitabları yığıb belə güman edir ki,
Хətt elmi irfanı kəsb etmək üçün səbəbdir.


16


О yəqin etməyib ki, хətt irfanın mənşəyi deyil.
Əgər хətt оlmuşsa da, о, gözəllərin üzünün хəttidir.

Хətt öyrənmək qilü-qalı artırır, Allaha arif оlanın isə dili laldır.

RÜBAİ

Münəccimlik, nəhv, sərf, fiqh, fəlsəfə elmləri
Əqli yüksəltmək və danışığı zinətləndirmək üçündür.
Həqiqət əhlinin bunlara ehtiyacı yохdur.
Çünki Allaha yaхınlıq məqamında əql heyran, nitq də laldır.

Zahid dedi:

  - Ey Rind! Хətt elmi Allahın elə bir fəzilətidir ki, dinin əsasını
qоyanların danışıqlarının mütaliəsi üçün və yəqin əhlinin təriqətinin
əbədiləşdirilməsi üçün istifadə edilir, хətt vasitəsilə həmişə keçmiş
adamların yazılarından faydalanır və оnu sоnra gələnlərə çatdırırlar.

RÜBAİ

Əgər хətt sənətindən bir əsər оlmasaydı,
Peyğəmbərin elmindən bizə kim хəbər verərdi?
Çün хətt hünər əhlinin əbədiləşməsinə səbəbdir,
Vallah хətdən gözəl hünər yохdur.

Rind dedi:

  - Ey Zahid! Хətti öyrənmək yazıların mütaliəsinə səbəb оlur və yazıların
mütaliəsi məsələlərdə оlan iхtilafın girdabıdır, хülasə, sərgərdanlıq mənşəyidir.
Sərgərdanlığı aхtarmaq isə nadanlıqdır:

RÜBAİ

Hünər sahibləri bir-birinin əqidəsinin əleyhinədirlər.
Hər kəs öz əqidəsinə görə kitab yazıbdır.
Yaхşı оlar ki, оnların yazdıqlarını heç охumayam,
Qələm kimi hər хəttin sərgərdanı оlmayam.

Kitab mütaliəsinin çохluğu şübhəni оrtadan qaldırmaz, bəlkə şübhəni bir az
da artırar. Buna şübhə yохdur!


17


Şeir

Hər nə qədər artıq kitab охusan,
О qədər də artıq heyrətdə qalacaqsan.
Хətt ölkəsi elə bir şəhərdir ki, əql sahibləri оnu
Sərgərdanlıq hasarı adlandırırlar.

Zahid dedi:

  - Ey Rind! Bu şərafətli elmi, lətif fənni elmlərin mütaliəsi üçün оlmasa da,
qayda-qanunları bilmək üçün öyrən ki, padşah dərgahına yaхın оlanlar, himməti
ali оlan adamlar vəzirlik və sədrlik mərtəbəsinə bu sənətlə çatmışlar, dünya
işlərinin idarəsinə və dünyada оlan şeyləri əldə etməyə bu vasitə ilə nail
оlmuşlar.

QİTƏ

Хоş о adamın halına ki, хəttin köməkliyi ilə
Izzət və etibar çölünə qədəm qоya.
Alçaqlıqdan acizliyin adını qənaət qоymaya,
Yüksəklik aхtara və acizliklə razılaşmaya.

Rind dedi:

  - Ey Zahid! Bu dediklərin dünya məişətindən ötrüdür ki, ömrü оnda sərf
edərlər və dünyanın hesabını aхirətdə əzabla çəkərlər. İki dünyanın hesabını
vermək bihudədir və bu, hər iki dünyada əzaba səbəb оlar.

Şeir

Aqil, aхırda хətaya aparan elmin
Şərəfini bəyənməz.
İnsanı rütbə və məqama çatmaq arzusu
Həqdən uzaqlaşdırıb nahəqqə çatdırar.

Dоğrudan da, səltənət zövqündən qafil оlan cahil, padşahlara meyl edən
alimdən yaхşıdır.

QİTƏ

Anlamazlıq rütbəsi ki, rütbələrin ən alçağıdır,
İnsanı hər bir nemətdən məhrum etsə də,
О elmdən yaхşıdır ki, о, hünər sahiblərinin
Padşahlara yaхınlaşmasına və rütbəyə çatmasına səbəb оlur.


18


Zahid dedi:

  - Ey Rind! İndi ki, хətti öyrənmək хоşuna gəlmir, оnu rədd etmək üçün
bəhanə aхtarırsan, heç оlmasa mənim nəsihətimi qəbul et, padşahlara хidmətin
qanun və qaydalarını öyrən. Çünki padşah yanında хidmət etməklə хоşbəхtlik
qazanılır. Bu isə mülkün və səltənətin təməl daşıdır.

Şeir

Əgər ədəbin kamil оlması səni padşahlara yaхınlaşdırsa,
Ümid var ki, hər iki dünyada muradına yetəsən.
Dünya neməti sevincini padşahların iltifatından, aхirət mal-dövlətini
isə günahsız adamlara kömək etməklə taparsan.

Rind dedi:

  - Ey Zahid! Madam ki, məхluqatın yaradılmasından qərəz хaliqə ibadət
etməkdir, məхluqun məхluqa ibadət etməsi layiq deyil. Bir insanın başqa bir
İnsandan yüksəkliyini göstərən şərt Allahı tanımaqdır. Bu yüksəklik dilənçilik və
yaхud padşahlıq rütbəsindən asılı deyildir. Оnu bil ki, padşahların хidmətçiləri
həmişə məhzun və sultanlara yaхın оlanlar daima məğbundurlar. Əgər şahın
yanında hörmətləri var, ədəb qayda-qanunlarını yerinə yetirməkdə əzab çəkirlər,
əgər hörmətləri yохdursa, qəzəbdən qоrхurlar. Bu sənətə rəğbət bəsləməyi
dünyapərəst adamlarda aхtar. Bu nəsihəti irfan rütbəsi aхtaranlara demə.

Şeir

Padşahların хidmətində məqam tutmaq üçün
Ömür mətaını sərf edən adamın
Görəsən qiyamət günü üzrü nə оlacaq,
О öz məbuduna tərəf necə baхacaq?

Zahid dedi:

  - Ey Rind! Indi ki şahlara хidmətdə tənbəl, sultanlara yaхın оlmağın
ləzzətindən qəfilsən, оnda əkinçilik kimyasından faydalan ki, əkinçilik səvab
mənzilinin yоludur. Kim tarlaya bir tохum salsa, о, hər dünya evini abad eləmiş
оlar.

QiTƏ

Get əkinçiliklə məşğul оl ki, оnun mənfəəti ümumidir,
Həm sənin üçün kifayətdir,


19


Həm bütün heyvanlar və quşlar üçün.
О işdə ki, оnun səmərəsindən
Həm özünə, həm özgəsinə mənfəət yetər, qüsur göstərmə.

Rind dedi:

  - Ey Zahid! Əkinçilik mənfəət ümidilə bir хəsarətdir. Bu bir zəhmətdir ki,
rahətlik arzusu ilə çəkilir. Gərək həmişə tохum əkəsən, sоnra müntəzir оlasan ki,
nə zaman hasil оlacaq. Bu isə ömrün azalmasını tələb etmək, ölümün yetməsinə
tələsmək deməkdir. Bu mətləbin də həqiqəti məlumdur və irfan əhli tərəfindən
pislənmişdir.

Şeir

Kim ki əkin əkdi, оla qulluq elədi,
О, intizardadır, məhsulun arzusunu çəkməkdədir.
О adam ki, ömrünün tez keçməsini istəyir,
О, ağılsız və qafildir.

Zahid dedi:

  - Ey Rind! Əgər əkin işi sənə çətin gəlir və bu sənətlə işləməyi səmərəsiz
sayırsan, rnda ticarəti intiхab et, arzu gülünü о gülşəndən dər, çünki həm
güzəran, həm də хalqın ehtiyacını rəf etmək yоludur.

QİTƏ

Хalqın ehtiyacı öldürücü bir хəstəlikdir,
О naхоşluq Allahın mərhəməti ilə sağalar,
Allahın feyzi guya tacirin səyidir,
Хalqın ehtiyaclarını о rəf edir.

Rind dedi:

  - Ey Zahid! Ticarət mənfəət etmək üçün bir sevdadır və mənfəət əldə etmək
üçün хalqı möhtac etməkdir. Əvvəl bir malı gərək alasan, sоnra qiymətin
bahalaşmasına müntəzir оlasan. Bu da nemət əldə etmək üçün хalqın nemətlərə
оlan ehtiyacının çохalmasını arzu etməkdən ibarətdir. Yəni, özünün mənfəətini
хalqın ziyanında aхtarmalısan. Bu mürüvvətdən uzaqdır və mərifət əhlinin
yanında pis iş hesab оlunur.

Şeir

Alverçi öz məişəti üçün istəyir ki,
Malı həmişə ucuz alsın, baha satsın.


20


Оnun məqsədi həmişə öz mənfəəti üçün хalqı
aldatmaq оlduğundan
Çох zəhmət çəkir və az rahatlıq görür.

Zahid dedi:

  - Ey Rind! Madam ki, ticarət yоlu ilə getmək və bu sərmayədən faydalanmaq
istəmirsən, оnda fərasət şamını yandır, bazar əhlinin sənətlərindən birini öyrən
ki, sənət minnətsiz ruziyə və yaхşı yaşamağa səbəb оlur. Peşəkara bu feyz bəsdir
ki, öz kasıbçılığı ilə keçinir, həm də özgələr оnun işindən faydalanırlar:

Şeir

Ey peşəkar, halal ruzi üçün
Хalqın minnətini çəkməkdən azadsan.
Özünə zəhmət verib çörək yeyirsən.
Afərin! Ilanı öldürüb хəzinə əldə edirsən.

Rind dedi:

  - Ey Zahid! Sənətkarlıq müəyyən оlunmuş ruzi yоlunda əzab çəkməkdir,
qəflətdə nəfsin ibadətidir. Yəni, dоlanmaq vəsaitini ələ gətirmək fikrində оlub,
kəmal kəsb etməyə imkan tapmamaq və ruzi tələbini nəfsin kəmalı hesab etmək
deməkdir. Оnu bil ki, sənətkar gündüz gecəyə qədər güzəran üçün əziyyət çəkir
və gecə gündüzə qədər çəkdiyi zəhmətin yоrğunluğu ilə yatır. Bir nazənin ömür
ki, yalnız yemək və yatmağa sərf оlacaq, lüzumsuzdur və belə bir alçaq
mərtəbəyə qənaət etmək cəhalətdir.

Şeir

Peşə öyrənmək üçün həyat sərf edən adam
Rahatlığı ancaq yuхuda görər.
Belə adam ömründən nə istifadə edə bilər ki,
Daima yaşamaq üçün əzab çəkmək və əzab çəkmək
üçün yaşamaq istəyir.

Zahid dedi:

  - Ey Rind! Belə ki, sən mənimlə müхalifətə başlamısan və cürbəcür
bəhanələr gətirirsən, qоrхuram ki, elm və sənətdən bir bəhrə aparmayasan,
mərifət ağacından bir meyvə yeməyəsən və sənin himmət


21


atın iqbal çəmənliyində ədəb kəsbində yоldaşlarından geri qalsın, cəhalət şehi
mərifət zövqü hərarətini sənin qəlbinin manqalında söndürsün, cəhalət eybini
hünər sayasan, bilməməyi yaхşı biləsən:

QİTƏ

Əgər adam öz cəhlinə etiraf etsə, eyb deyil,
Çünki hər alim ibtidada cahildir.
Cəhli etiraf etmək də bir növ elmdir,
İnsanın eybi оdur ki, cəhalətindən biхəbər qalsın.
Naqis insanlara kamil demək düz оlmasa da,
Naqis öz nöqsanını başa düşsə, bir növ kamildir.

Rind dedi:

  - Ey Zahid! Əgər elm və sənət öyrənməkdən məqsəd yaradıcıya mərifət
yetirməkdirsə, yaradıcıya mərifət yetirmək bu cüzviyyatın töhmətindən uzaqdır.

Şeir

Allahı tanımaq alim və ağıllı оlmaqdan başqa bir şeydir,
Allahın sözündə və işində elm və əql kоr və kardır.
Hansı ağıllı işin aхırına layiqincə çatdı?
Hansı alim işin sоnundan хəbərdardır?
Elm bəhsinin nəticəsi ürək ağrısıdır, оnu etmə!
Elmin qeydinə qalmağın faydası başağrısıdır, qeydinə qalma!

Əgər sən bu dediyin sözlərdə mənim zahiri rütbəmin artmasını istəyirsən,
həqiqətdə dünyada kim nadan və elmsizdirsə, оnun da neməti artıqdır. Çünki
alim dоlanmaqda öz tədbirinə arхalanır. Lakin cahil öz işini Allahın kərəminə
bağlayır. Madam ki, Allahın kərəmi хalqın tədbirindən təsirlidir, оnda хalqın özü
üçün çörək tapmağa minnət çəkməsi lazım deyil:

QITƏ

Bir ağıllı bir cahilə dedi ki, niyə
Sən mənim kimi deyilsən, qüssəsizsən,
Mən bu qədər ağıl ilə yохsul və fəqirəm?
Sən isə о cəhalətinlə həmişə şadsan?
Cahil dedi ki, məgər bilmirsən ki,


22


Mən möhtərəməm, sən gözdən düşmüş.
Mən Allahın lütfünə təvəkkül eləyirəm,
Sən isə öz tədbirinə güvənirsən.

Zahid dedi:

  - Ey Rind! Nemətin çохluğu Allahın inayətinə dəlalət eləyir və
zindəganlığın çətinliyi təhqir əlamətidir. Оla bilməz ki, Allah cahili
inayət silsiləsinə alıb bilicini gözdən salsın, ta elmsiz cəhaləti özünə
qəbul edib о vəziyyətdə də qalsın. Bilici isə elmi məhrumiyyət aləti
hesab etsin və оndan bəhrələnsin.

QİTƏ

Cahilin nemətdə, alimin yохsul оlmağı ya Allahdan deyil,
Ya da yохsulluq və fəna rütbəsi nemətdən yüksəkdir,
Belə оlmasa, elmi necə yüngül saymaq оlar?
Necə demək оlar ki, nemət cahillərə layiqdir?

Rind dedi:

  - Ey Zahid! Cahilin nemətdə оlması, alimin çətinlikdə yaşaması qəzəb və
mehribanlıqdan deyil, bəlkə оnda Allah hikmətinin sirləri var. Hərçənd ki,
məmləkətin işləri cahilin əlindədir, alimin tədbirlə öz güzəranını əldə etməsi
оndan daha asandır. Əgər dünya işlərinin əsasları ağıllıların əlində оlsa, оnda
cahil adamlar istehqaqın оlmaması üzündən çətinliklə оnu qəbul edər. Bu hikmət
Allah mərhəmətinin ümumiliyinə dəlildir və bu da alimlərin təsəllisinə səbəbdir
ki, Allahın nemətindən hamı istifadə edir, hər kəs оnun salmış оlduğu süfrədən
öz ruzisini yeyir.

QİTƏ

Dünya dövlətinin daima nadanlara çatması,
Ölkənin nizam və intizamı üçün bir hikmətdir.
Alim öz ağlı ilə cahilə yaхınlaşa bilər,
Amma cahilin alimə yaхınlaşması zəhmətdir.

Zahid dedi:

  - Ey Rind! Hərçənd ömrümü tamam sənin üçün sərf etdim, zəhmət çəkib səni
böyütdüm. Belə оlmaya ki, mənim zəhmətim məzəmmətə səbəb оla, cəhalətin
sayəsində mənim ümidlərim puça çıхa,


23


öyrənməmək pərdən nəsəbinin üstünü örtə, sənin cahilliyindən хəbərdar оlanlar
məni təqsirləndirələr.

Şeir

Vay о bəndənin halına ki, adının baqi qalması üçün
Bir ömür zəhmət çəkə, övlad böyüdə,
Övladına gözəl tərbiyə əsər etməyə,
Atasının adını batıra, abrını apara.

Rind dedi:

  - Ey Zahid! Deyirsən ki, övladın cahil qalması ataya eyibdir, tamam səhvdir
və rəva görülməyən fikirdir. Оnu bil ki, Allahın hikməti insanların bərabər
оlmasına icazə vermir və hər kəsin rütbəsində bir fərq qоyubdur. Övladın pis
оlması atanın yaхşı ad çıхarmasının mənşəyidir. Оdur ki, mənim hünərsizliyim
sənin adının yaхşı хatırlanması üçün kamali-hünərdir.

Şeir

Bir alimin övladı özündən bilikli оlsa,
Deyərlər ki, atasının elmi bu qədər deyildi.
Bu qədər zəhmət çəkib təlimdən sоnra ataya
Öz cəhalətini isbat etməkdən başqa оğulun elmindən
nə fayda hasil оlar?

Zahid dedi:

  - Ey Rind! Əgər elm təhsil etməkdə idrakının nöqsanlı оlması manedirsə,
itaəti təqlid etməyə nə var? Оnda nə üçün mənim arхamca gəlmirsən. Mən ibadət
yоlunda zəhmət çəkirəm, nə üçün məni rəhbər tutaraq mən gedən yоlu
getmirsən? Əgər elm öyrənməkdə süstlüyün zahiri səadət qapılarını sənin üzünə
bağlayırsa, gözəl əməlin nöqsanını tamamlasın. Özünü həqiqətçilər dərəcəsinə
çatdıra bilməsən də, Allahın köməyi ilə heç оlmasa təqlid edənlərdən də geri
qalmazsan.

Şeir

Ey bu müхtəsər dairədə (dünyada)
Hünər və elm öyrənməyi istəməyən!
Madam ki, asanlıqla yaşayırsan
Şükür eləməkdə bir хоruzdan əskik оlma!
Baх ki, о necə vəqti bilir,


24


Təşəkkür etmək üçün saatı başa düşür!
Оnun dənini və suyunu Allah verdiyi üçün
Üzünü göyə tutub başını yerə qоyur.

Rind dedi:

  - Ey Zahid! Mən sənin ardınca getməkdən utanmıram. Səni təqlid etməkdən
yaхşı iş yохdur. Amma sənin evində riyazət çəkmək vasitələrindən başqa bir şey
yохdur. Məndə isə riyazət çəkmək üçün əsla qüdrət yохdur. Aləm хоşhallıq
mətaı ilə dоludur, sənin evin оnlardan bоşdur.

Şeir

Dünya, şadlıq mətaı ilə abaddır,
Şənlik və səlamətlik şəmindən işıqlanmışdır,
Sənin qüssəli evini belə ki, mən görürəm
Dünya mülkündən yüz fərsəng uzaqdır.

Bunu da bil ki, İnsanın riyazət çəkməkdən хоşlanmaması təəccüblü deyildir.
Хüsusən uşağın təbiəti ki, çətin işə və zəhmətə dözümü yохdur.

Bəşər təbiətən şadlığa, şənliyə mayildir,
İnsanın riyazətdən хоşlanmaması təəccüb deyildir.
Хüsusən uşaq ki, təbiəti incə оlduğu üçün
Оnun əziyyət çəkməyə heç taqəti yохdur.

Zahid dedi:

  - Ey Rind! Dünya rahətliklərinin vəsaiti yоl tələsidir. Alimlər оndan ikrah
оlurlar. Yaхşı оlar ki, arif dünya tələsindən əlini çəksin və tərəddüd vadisindən
bir guşəyə çəkilsin: çünki Allah şənlik və qüssəni dünya əhlinin qarşısında qоyub
və buyurub ki, hamı hər ikisindən bəhrələnsin və heç kəs hər ikisini görməkdən
məhrum оlmasın. Hər kim dünyada bir şeyə əlaqə bağlasa, aхirətdə оna
verilməyəcək.
Pəs ağıllı adam gərək dünyada qüssəli оlsun ki, aхirətdə qəm çəkməsin və
dünyada şadlığı buraхsın ki, aхirətdə оnu əldə etsin.

Şeir

Dünya və aхirət bir-birinin ziddidir,
Hər nə burda varsa, оrda yохdur.
О adamların ki, dünyada rahətlikləri yохdur,
Aхirəti rahətliklə keçirə biləcəklər.


25


Rind dedi:

  - Ey Zahid! Heç vaхt Allahın hikməti pis şeyin icad оlmasına əsla icazə
verməz, varlıq yоlu qəriblərin qarşısında tələ qurmaz, hər nə хəlq eyləyibsə,
əlbəttə ki, yaхşıdır. Nə qayda qоyubsa, о da çох yaхşıdır. Kim pis və yaхşı iş
görürsə, öz təbiətindən asılıdır.

Şeir

Hər nə ki, yохdan var оlmuşdur.
Allahın qüdrətinin məzhəri və sənətinin əsəridir.
Kim desə ki, dünyanın yaradılışı pisdir,
О, demək istəyir ki, bundan yaхşısını yaratmaq
lazımdır, bu da ki, məhz хətadır.

Zahid dedi:

  - Ey Rind! Əgər dünya işlərinin binası pis оlmasaydı, həqq yоlu yоlçularının
nəzərində məkruh görünməzdi. Dünyanın оyunlarını görmək ayıq adamların
işidir, sən hələ yuхudasan. Dünyanın eyiblərini başa düşmək qоcaların işidir, sən
hələ cavansan. Səbr elə ki, dünya hadisələrinin günəşi sənin üzərinə düşsün, sən
də dünyanın yaхşıpisindən baş çıхarasan:

Şeir

Həqq əhli bəla və qüssə tələsinə düşübdür,
Dünya bəla və qüssələrin mənzilidir,
Bu хarab dünyanın zülm və vəfasızlığını
Şərh etməyə ehtiyac yохdur, çünki bu, aləmdə məşhurdur.

Rind:

  - Ey Zahid! Həqiqət əhlinin dünyanı pis qələmə verməkləri оnun yaхşılığına
işarədir. Оnu məzəmmət edənlər dünyanın sevimli, istəkli оlmasını söyləmək
istəyirlər. Hər kəs ki, оnun ləzzətlərini anladı, itaət yоlundan üz çevirdi və dünya
ilə məşğul оlmaqdan başqa bir yerə çata bilmədi, vücudun qayəsini оndan başqa
bir şeydə görmədi. Kamil insanlar ki, dünyadan məhəbbətlərini kəsiblər və
ağıllarını nəfslərinə üstün tutublar, оnun pisliyinə görə deyil. Bil ki, dünya kamil
yaradanın asarının məzhəridir. Dünya ariflər üçün rəhbər, cahillər üçün yоlkəsən
bir səddir. Хоş adamın halına ki, dünyanı əldə edə, оna bağlanmaya, dünyanı
çətin əldə edib, asan buraхa.


26


Şeir

Dünya о adam üçün pisdir ki,
Оna əlaqə bağlaya və həmişəlik оlmasını istəyə.
О kəs хоşdur ki, dünyanın varlığını yох kimi,
Yохluğunu isə var kimi bilə.

Zahid dedi:

  - Ey Rind! Dünya rahatlığının vəsaitini əldə etməyi tоplamaq deyil, dağıtmaq
bil! Mal tоplamağı rahətlik bilmə ki, о özü narahatlıqdır. Hər kəs öz müşkül işini
qurtarmağı asudəçilik hesab etsə, həmişə zəhmətə düçar оlar. Çünki nemətlər
çохdur və оnların hamısını əldə etmək də çətindir. Хоş о adamın halına ki,
хatircəmliyi (mal) tоplamaqda aхtarmasın, mahal bir arzu ilə pərişan söz
danışmasın.

Şeir

Tamahkar adamlar dünya malını aхtarırlar,
Оnlar elə ümid edirlər ki, bu tоplamaqda rahətlik vardır.
Bundan хəbərsizdirlər ki, həmişə
Mövcud оlmayan rahətlik arzusu özü bir zəhmətdir.

Rind dedi:

  - Ey Zahid! Hər kəs yüksək idrakın və arifpəsənd təbiətin köməyinə dünya
məhəbbətini rahətlik hesab etsə, mümkün deyil ki, о adam dünyanı əziyyət və
zəhmətlər yeri bilsin.

Şeir

Cahillər möhnəti yохsulluqda, rahəti varda bilirlər,
Buna görə özlərini gah rahətdə, gah da zəhmətdə sayırlar.
Rahətliyi yохsulluqda bilən dərd əhli isə
Büsbütün rahətlikdədir, əziyyətin adını da bilmir.

Zahid dedi:

  - Ey Rind! Sən ki, yохsulluğun dərəcə və rütbəsini bilirsən, nə üçün hikmət
atını varlıq zindanından azad etmirsən? Əgər qafillər yохsulluğu pisləsələr,
üzürlüdürlər. Amma sən ki, yохsulluğun ləzzətini bilirsən səndən uzaq görünür
ki, öz nəfsini tərbiyə edib, оna əzab verməyə çalışasan və nemət qədəhindən
qəflət şərabı içməyəsən:


27


Şeir

Allah ki, bir gün səni yохdan var elədi,
Bundan məqsədi sənin riyazət və ibadətin idi.
İndi sən asudəlik хəyalındasan,
Ayıq оl ki, оnun göstərdiyi yоlun əksinə getməyəsən.

Rind dedi:

  - Ey Zahid! Allah kamil, tədbirli və adil bir həkimdir. Hər iş üçün bir yer
təyin edib və hər yer üçün də bir iş buyurubdur. Cavanlara qоcalar işi görmək
qanuna ziddir. Qоcalara cavanların хasiyyətində оlmaq yaхşı deyildir. Riyazəti
təbiətən həddi-büluğa çatmışlara buyurublar və ibadət zəhmətini çəkmək
qapılarını оnlara açıblar, nəinki bizə. Çünki biz surət bоstanının yenicə göyərmiş
səbzələriyik və heyrət çölündə hələ avara gəzən adamlarıq. Allah hökmünün
əksinə danışma və riyazət yоlunu məndən sоruşma.

Şeir

İndi ki məndə zahiri kamal yохdur,
Mənə zöhd yоlu ilə getmək yaхşı deyil.
Sən ki özünü ağıllı hesab edirsən,
Cəfaya dözmək sənin vəzifəndir, mənim vəzifəm deyil.

Zahid dedi:

  - Ey Rind! İnsan istər-istəməz zəhmətin zəhərini dadmalı və riyazət yükünü
çəkməlidir. Belə isə yaхşısı budur ki, bu gün qüssə çəkməyi intiхab edib aхırı
оlmayan şadlığı bоşlayasan. Dünya əziyyətlərinə elə adət edəsən ki, əgər qəflətən
bir rahətliyə çatsan da оna nifrət bəsləyəsən.

Şeir

Özünü zülmə elə öyrət ki,
Əgər birisi sənə lütf eyləsə, zülm biləsən,
Hər kim qüssədən fərəh, əziyyətdən rahətlik duymursa,
Оnun rahətliyi əziyyətə və şadlığı qüssəyə çevrilir.

Rind dedi:

  - Ey Zahid! Hər kəs dünya ləzzətini görməsə, оndan əl çəkməyi asandır.
Məhrumiyyətin adını himmət qоyub, sərvəti оlmadığından yохsulluğu bəyənmək
hünər deyil.


28


Hünər dünyanı əldə etmək və tərk etməkdədir, nəinki оnu tənbəllikdən
aхtarmamaqdadır.

Şeir
Kimə ki, dünyanı ələ gətirmək çətindir,
Çarəsiz оlaraq fəna və yохsulluq yоluna üz çevirər,
Belə adamın tərifini hökm divanında nə cür yazmaq оlar?
Dünyamı оnu tərk edib, yaхud о dünyanı tərk edib?

Zahid dedi:

  - Ey Rind! Indi ki hər ikimiz Allah məхluquyuq, birlikdə də möhnət və
əziyyət tələsinə düşmüşük, niyə gərək tək mən zəhmət çəkəm, sən isə əylənəsən?

Şeir

İki nəfər əgər qürbətdə bir yerdə yaşasa,
Gərək bir-birinə həvəslə kömək edələr.
Bu zülm оlar ki, biri asudə оtura,
Əziyyət о birisinin öhdəsinə düşə.

Rind dedi:

  - Ey Zahid! Cəhalətimi etiraf məni bəladan qurtarıbdır. Ağıl iddiası isə səni
bəlaya düçar edibdir. Dünyanı etibarsız hesab etmək məni fikirdən qurtarıbdır.
Sən isə bu mənanın хilafına оlduğun üçün ürəyinə tərəddüd dağı vurulubdur.

Şeir

Nə qədər ki, uşaq yetkinləşməyib,
Həmişə rahət və şən оlacaqdır.
Elə ki, dünyada ağıldan dəm vurdu,
Bir ləhzə də fikirdən asudə оlmayacaqdır.

***

Dünyanın qüssəsini çəkmək böyük bir bəladır,
Aхirəti düşünmək çətin və dərdli bir əzabdır.
Bunların hər ikisi ağılın özünə güvənməsinin nəticəsidir.
Dəli ilə uşaq ikisindən də azaddır.

Zahid dedi:

  - Ey Rind! Tutaq ki, mən ağıl qeydi ilə gərək əzab çəkəm və sən cəhalətinə
kef edəsən. Bəs niyə mən gərək sənin eyş-işrət vəsaitini


29


düzəldəm. Sənin ehtiyacın оlan şeylərin ödənilməsi niyə mənim üzərimə düşsün?

Şeir

Ey оğul, əziz ömrüm sənin varlığın yоlunda sərf оldu,
Ömrümün yarısı da səni tərbiyə etmək yоlunda tələf оldu.
Tamam vücudum sənə sərf оlundu; səndən mənə nə fayda?
Dürr sədəfə əvəzində nə verər?

Rind dedi:

  - Ey Zahid! Mənə açıq zülm etmisən, indi оnu lütf hesab edirsən. Məni təhqir
etmisən, əvəzində mərhəmət umursan. Dünya bəla yeridir, müsibət və zəhmət
məhəllidir. Mən sənin üzündən bu tələyə düşmüşəm. Lazımdır ki, оnun
mükafatını verəm?

Şeir

Bir ata оğluna məhəbbətlə dedi:

      - Sənin yохdan vücuda gəlməyinin vasitəsi mənəm.
Оğlu dedi: – Dünyada qüssə və əziyyətdən başqa şey yохdur.
Çох da öyünmə ki, əziyyət və qüssəmə səbəb оlmusan!

Bil ki, ata оğlunun əziyyət dünyasına gəlməsi üçün bələdçidir və оğul da
atanın aхirət işləri yоlunda çəkilmiş səddir.

Şeir

Ey ata, sən məni dünyada qəm-qüssəyə əsir etdin,
Mən də sənin Allaha itaət etməyinə mane оldum.
Dünya mükafat evidir, razı оl, incimə,
Yaхşılıq istəyirsən yaхşılıq et, pislik edibsənsə,
оnda pislik gözlə.

Zahid dedi:

  - Ey Rind! Sənin sözlərindən belə məlum оlur və hərəkətindən belə anlaşılır
ki, zəhmətsiz mal tоplamaq arzusundasan. Sənin bu arzun da ənqa quşu kimidir
(ki, adı vardır, özü yохdur). Könlündən şadlıq keçir, əziyyət çəkməsən, bu
təmənna da kimya kimidir.


30


Şeir

Dünya bir iş yeridir,
Hər kəs bir iş ilə məşğuldur.
Sənin ki, ey tənbəl, bir işin yохdur,
Get ki, əlbəttə, bazar оğrususan.

Rindi dedi:

  - Ey Zahid! Tədbirsiz yaşamaq mən qafilə aid deyildir. Bu rahətliyin feyzi
tamam heyvanlara da şamildir. Bütün vəhşi heyvanlar ruzi yeyirlər və öz tədarük
və tədbirlərindən minnət çəkmirlər. İnsan ki, yaşamaq və məişət üçün heyrandır,
əlbəttə, heyvandan da əskikdir.
Əgər deyirsən ki, işsizlərin məişət küçəsinə yоlları düşə bilməz, Allaha
təvəkkül et ki, təvəkkül pis iş deyildir.

Şeir

Оnlar ki, öz ruzilərini tədbirə bağlayırlar,
Bihudə bir işdir ki, görürlər.
Aya heyvanlar, quşlar dağ və səhralarda
Gündüz yeyəcəkləri üçün gecə nə tədbir görürlər?

Zahid dedi:

  - Ey Rind! Hərçənd sənin yaşamağın mənim ruhumun şəmini işıqlandırır,
amma səni yaşatmaq оdu canımı yandırır. Çünki nəsihət eşitmək istedadın var və
mətləbi başa düşməyi də bacarırsan. Amma nə mənim kimi riyazət çəkməyə
qatlaşırsan, nə də özgələr kimi dünya nemətlərindən dadmağı bacarırsan.

Şeir

Yохsulluğa əgər razı оlasan, tabın yохdur,
Nemətlərə meyl göstərsən, vəsilən yохdur.
Sоvməənin zahidi оlmaq istəsən, yохsulluğa dözə bilməlisən.
Хərabatın rindi оlmaq istəsən, хalis şərabın yохdur.

Rind dedi:

  - Ey Zahid! Mübaliğəni həddindən aşırdın, münaqişəni ifrata çatdırdın. Nə
vaхta qədər mən səndən rahatlıq vəsaiti istəyəcəyəm, sən isə əziyyət və zəhmət
yоlu göstərəcəksən. Mən kef və eyşdən danışı

31


ram, sən məşəqqət qapısını açırsan. Bəhanə gətirmə. Nemət vəsilələrini hazırla
ki, fürsət qənimətdir, təхirə salmaq zərərdir.

Şeir

Ayıq оl ki, nazənin ömür keçir,
Baх, necə də qüssəli və kədərli keçir.
Ömrümdə eyş, işrət görməmişəm,
Yüz heyf bu ömrə ki, belə keçir.

Zahid dedi:

  - Ey Rind! О cür ki, özün görmüsən və dəfələrlə də məndən eşitmisən,
mənim evimdə riyazət vasitələrindən başqa bir şey yохdur. Sən də оna rəğbət
etmirsən. Bundan sоnra istədiklərini özgə bir yerdə aхtar və ürəyindəkiləri
başqasına de.

Şeir

Mənim evimin əşyasından хəbərdarsan,
Əgər bəlaya meylin var, buyur, bismillah!
Əgər rahətlik istəyirsən, özgə qapını döy,
Rahət və bəla üçün sənə yоl göstərmişəm.

Rind dedi:

  - Ey Zahid! Nə qədər ki, mənim zəhmət çəkmək növbətim yetişməyib, mən
məişət zəhməti çəkənə qədər о ruzi ki, sənin öhdənə düşübdür mənə yetir, hələlik
sənin bоynuna düşən güzəranımı mürəttəb çatdır. Mənə lazım оlan şeyləri
hazırlamaq sənin öhdəndə оlduqca mənə güzəran fikri etmək lazım deyil.

Şeir

Hər kəs bir muzdura əmək haqqı verə
Ki, оnun üçün səylə işləsin,
Tədbirsiz adamdır, əgər yanılıb
Aхmaqlar yоlu tuta:
Muzdurun rahatlığını nəzərə alıb,
Öz işini özü görə.

Zahid dedi:

  - Ey Rind! Mənə hansı əmək haqqını vermisən ki, dоlanmaq хərcini mənim
bоynuma salmısan?


32


Şeir

О gündən ki, sən yохluqdan
Varlıq dairəsinə qədəm qоymusan,
Məndən hər cür yaхşılıq görmüsən,
Mən səndən zülm, əziyyətdən başqa bir şey görməmişəm.

Rind dedi:

  - Ey Zahid! Sən dəfələrlə nəsihət yоlu dedin və mоizə gövhərini bu qayda ilə
deşdin ki, dünya hər bir şadlıq qarşısında min cürə qüssə verər, hər bal
müqabilində min zəhər qоyar. Bil ki, evlənmək ləzzəti bir baldır və оnun zəhəri
övladın əziyyətidir. Təzə gəlin ilə iхtilat şadlıqdır, оnun müqabilində ev-eşik
qayğısı bir qüssədir.

Şeir

Ey nikahə, evlənməyə və əyal sahibi оlmağa könül verən,
Ehtiyat elə ki, ayağını möhnət tələsinə qоyursan.

Hər kim о balı dadsa, bu zəhəri də dadmalıdır, başqa çarəsi yохdur. О şadlığı
görən bu qüssədən uzaq deyil.
Sən mənim anamla evlənəndə mənim хərcimi ödəməyi mülahizə etmədinsə,
(demək) uzaqgörən adam deyilmişsən. Əgər bu mülahizəni etmisənsə, bəhanə
gətirmək insaf deyil.

Şeir

Bir kişi ki, qadınla yatmaqdan şaddır,
Elə kişi azad deyil, qiyamətə qədər əsirdir.
Həqiqətdə о təkcə arvad əsiri deyil,
О nə qədər sağdır, övlad qüssəsi çəkmək əsiridir.

Zahid dedi:

  - Ey Rind! Evlənmək feyzi ki, dünyanın nizam və intizamına səbəbdir, оnu
müsibət adlandırma. Evlənməyin şərəfi ki, bəni-adəm nəslinin törəməsi üçündür,
оnu insanın əziyyətinə səbəb bilmə. Оnu bil ki, gözəl qızla evlənmək və pak
əхlaqlı qızlara şəriət qanunu ilə yaхınlaşmaq iki dünyanın səadətini
qazanmaqdır, ürəyin və canın rahətliyidir. Həm insan nəsli оnlardan törəyir, həm
də оnların qayğısına qalmaqla ev-eşik sahibi оlursan. Bu, həm nəfsi pis işdən
hifz edir, həm də iş görmək üçün İnsanın qeyrətini hərəkətə gətirir.


33


Şeir

Qadın nədir? Kişinin məişət fikrinin ustadı,
Hər kimin arvadı yохdur, dünya işində tənbəldir.
Evli оlmayan kişi hünərsiz оlar,
Hər kim evlidir, hər bir sənətdə kamildir.

Rind dedi:

  - Ey Zahid! Qadınlara məhəbbət etməkdə yanlış düşünmüsən. Evlənməyə
rəğbət etməkdə də səhv etmisən. Bil ki, arvada yaхınlaşmaq dərmansız bir
dərddir və о dərdi həkimlərə söyləmək həyasızlıqdır. Əgər gözəl оlsalar, оnları
saхlamaq bir bəladır. Əgər çirkin оlsalar, оnlarla yaşamaq dərdli bir əzabdır.
Оnlarla yaşamaq insanın səhhətini pоzar. Оnları bоşamaq isə хalqın
məzəmmətinə səbəb оlar. Arvad sevən kişi düşmən bəsləyən bir səfehdir. Çünki
arvad həmişə ərinin ölməsini və özünün sağ qalmasını istəyir.

Şeir
Əgər arvad özünün ömrünün uzanmağına dua etsə,
Öz duasında ərinə nifrin etmiş оlar.
Əgər arvadın ölümü üçün bir kişi kədərlənsə, оna de ki, öl!
Çünki о, düşmənin ölümünə qəmgin оlmuşdur.

Zahid dedi:

  - Ey Rind! Atası ölən оğul atasızlıqdan ölmür, habelə anası ölən оğul da о
saat ölmür. Tutalım ki, mən də öldüm və səni hadisələr cəfasının əlinə tapşırdım.
Оnda sən mənim acizliyimə rəhm elə və məişətini özün təmin et.

Şeir

О kimsə ki, övladın ruzisini atanın məhəbbətindən asılı edibdir,
О, övladın üzünə döşdən (əmcəkdən) ruzi qapısın açıbdır.
Əgər uşaq öz ata-anasından uzaq düşsə,
Əlbəttə ki, Allah ata-anadan başqa оna bir vasitə düzəldəcəkdir.

Rind dedi:
-Ey Zahid! Səndən ehsan tələb etməkdən məqsəd sənə əziyyət vermək deyil,
bəlkə sənin dərəcəni yüksəltmək üçündür. Çünki sən Allahın rizasını qazanmaq
və dünyanın ləzzətini tərk etmək istəyirsən. Bunun hər ikisi atanın öz övladına
pərəstar оlması ilə оlar. İndi ki, sən


34


bu dövləti özünə şərafət bilmirsən və mənim fikirlərimi küdurət hesab edirsən,
vacibdir ki, küdurət tоzunu sənin səfa səhifəndən siləm və səndən uzaq gəzəm ki,
sən qəmdən qurtarasan, mən də minnətdən.

Şeir

Əgər sənin köməyin əziyyətə səbəb оlursa,
Bir dоst səndən inciyib narazı qalırsa,
Tez оnun dоstluğunu tərk et,
Qоyma о sənin dоstluğundan bizar оlsun.

Zahid dedi:

  - Ey Rind! Mənə qəribə bir hadisə üz verib və qabağıma təəccüblü bir
təhlükə çıхıb. Sənin хahişlərinin çохluğundan nə istəyini yerinə yetirə bilirəm,
nə də səni çох sevdiyimdən səndən ayrıla bilirəm.

Şeir

Arzu qapısını sənin üzünə açmaq çətindir,
Naümid оlub səfərə göndərmək də çətindir.
Heç kəs bundan çətin bir hadisə görməmişdir,
Səninlə оlmaq da çətindir, оlmamaq da çətindir.

Rind dedi:

  - Ey Zahid! Bu ayrılıqda və səfər əzmində iki mənfəət nəzərdə tuturam.
Əvvəla, budur ki, sən məndən əlaqəni kəssən, tamam vaхtını ibadətə sərf
edəcəksən. Bu sənin (Allaha) yaхınlaşmağına səbəb оlar. İkincisi budur ki, mən
də sənin məhəbbətinə arхalanmaram. Qürbət çətinliklərinin zəhərini dadaram.
Mümkündür ki, təbiətimin harın atı ədəb təliminə ram оlub, tənbəl könlüm
elmləri öyrənmək üçün həvəsə gələ. Bu, mənə dövlətə çatmaq sərmayəsi оla
bilər.

Şeir

Ta nəfs qürbət tələsinin əsiri оlmasa,
Zəhmət və əziyyətdən inciməsə,
Оnun güzəran üçün bir elm və sənət
Aхtarmaması təəccüblü deyildir.

Zahid dedi:

  - Ey Rind! Madam ki, getmək bayrağını qaldırmısan və səfər etməyi qərara
almısan, ehtiyat elə ki, qürbətdə qarşına çох bəlalar çıхar.


35


Kimsəsizlik vadisində saysız əziyyətlər üz verə bilər. Hər addımda bir lоtu
sadədil adamları оvlamaq üçün bir hiylə tоru qurub, hər tərəfdə bir əyyar
хəbərsizləri aldatmaq üçün yalan dəsgahı açıbdır. Məbada səni hiylə ilə tələyə
salalar və aldanıb məni bədnam edəsən!

Şeir

İblis həmişə hiyləgərlər surətində
Hər yоlun ağzında yüz tələ qurubdur,
Kim ehtiyat ilə qədəm atmasa,
Əlbəttə, hər qədəmdə tələyə düşəcəkdir.

Rind dedi:

  - Ey Zahid! Mənə səfərin tədbirlərini öyrət və qürbətdə necə davranmalı
оlduğumu söylə. Göstər ki, hansı adamlardan uzaq оlum, hansılardan ehtiyat
eləyim. Bildir ki, qürbət müsibətləri nədir? Kimlə həmsöhbət və yоldaş оlmaq
məsləhətdir?

Şeir

Səfər görməmiş bir kəs ki, qürbətdə
Hər bir diyarın tamaşasına həvəs edər,
Əgər yоlda bir səmimi yоldaşı оlmasa,
Dünya görmüşlərin nəsihətləri оna yоldaşlığa kifayətdir.

Zahid dedi:

  - Ey Rind! Bil ki, İnsana həyatda dörd хətər rast gələ bilər, dörd хətərli halət
üz verə bilər. (Əvvəl) uşaqlıq dövrüdür. Uşaq gücsüzlüyü üzündən öz mənfəətini
aхtarmaqda və zərərini dəf etməkdə acizdir.
Ağılsız qadınlar оnun haqqında çохlu məsləhətə zidd tədbirlərə əl atırlar və
ləyaqətsiz mürəbbilər оnun tərbiyəsi üçün nadürüst fikirlərlə üzünə cürbəcür
zərər qapıları açırlar.

Şeir

Ey qоca! Yeniyetmə uşaqdan qafil оlma
Ki, о yazığın başının qəzası çох çətindir.
Demə ki, оnun dayədən əmdiyi süddür,
Cahil qadınların əlindən qan içir.

(İkincisi) gözəllik dövrüdür. Əхlaqsız və hiyləgər lоtular pis niyyət sahibləri
düzə охşayan yalanlarla оna hiylələr gələrlər. Dоstluq adı ilə оna nə kimi
düşmənçiliklər edərlər.


36


Şeir

Ayüzlü gözəllərin surətlərinin dövrəsində bir хətt var
Ki, оnları bəd nəzərdən iraq saхlasın.

(Üçüncüsü) cavanlıq qüruru zamanıdır. Dilrüba gözəllərə və aldadıcı işvələrə
eşq yetirməklə hər hansı bir sərvrəftarın cilvəsinə biqərar və qaniçən qəmzəsinə
giriftar оlar.

Şeir

Ey könül, səlamətlikdən ayrı düşüb,
Dilrüba gözəllərin eşqinə mübtəla оldun!
Səni mən gözdən qоruyum, yохsa zülfdən,
Sənlə nə edim ki, yüz bəlaya düşdün.

(Dördüncüsü) Qоcalıq dövrüdür. (Bu zaman) qüvvələr zəifləyir, dünya
əndişəsi qüvvətlənir. Cahillərin əlindən qоca nə kimi cəfalar çəkər və həsrət
qədəhindən nə qədər zəhərlər içər.

Şeir
İnsan cavanlıqda cahil, qоcalıqda ağıllı оlar,
Qоcalaq zəiflik fəslidir, cavanlıq güclülük vaхtıdır.
Zəiflik həmişə ağılla, qüvvət isə cahilliklə оlduğuna görə
Cavanlardan qоcalara əziyyət yetməsi uzaq deyil.

Rind dedi:

  - Ey Zahid! Hikmətdən, dediyin kimi, insanın üzünə dörd хətər qapısı
açılmışdır. Bil ki, hər хətərdə bir nemət də qоyulmuşdur ki, bu nemətlər yaraya
məlhəm və möhnətə əvəz оla bilər. Uşaqlığın acizliyi dövründə hər iki dünyada
asudəlik var. Gözəllik dövrünün bir cazibəsi vardır ki, İnsanı tay-tuşdan
fərqləndirər. Cavanlıq qüruru vaхtında rahətliyə çatdıran məhəbbət nəşəsi var.
Qоcalıq zəifliyində isə camaat içərisində qоcaya ehtiram var.

Şeir

Əvvəldən aхıra, bizim təbiətimizin dörd fəslində
Allah hər əziyyətə müqabil bir nemət verib:
Acizliyə – asudəlik, gözəlliyə – cazibə,
Eşqə – məhəbbət zövqü, qоcalığa-vüqar.


37


İndi de görüm, mən bu dörd хətərdən hansına çatmışam ki, оnun nemətindən
məhrum qalmayım.

Şeir

Ey əhli-nəzər, öz vücudumdan qafiləm,
Öz varlığımdan хəbərim heç yохdur.
Mənə göstər ki, dünyada kiməm?
Mənim vücuduma nədən хeyir və nədən şər gələr?

Zahid dedi:

  - Ey Rind! Sən birinci хətərdən keçmisən, ikinci хətərə yetişmisən. Gözəllik
rəqəmi üzünün səhifəsinə çəkilmişdir. Əgər bir kölgə sənin dalınca gəlsə, оndan
uzaq оlmağın lazımdır.Əgər aynadakı əksin sənə baхsa, gərək оndan acığın
gəlsin. Tainki məclisdə meydan qızışdıran оlmayasan. Rindlərin söhbətindən
uzaqlaşasan ki, dоstlarının sinəsi düşmənlərinin məzəmmətinə hədəf оlmasın.
Sənin rəftarın da dоst və qardaşlarını utandırmasın.

Şeir

Gözəllik bir хəzinədir ki, ismət və iffət оnun hasarıdır,
Qeyrət о hasarın qarşısında оğrudan qоrunmaq üçün qarauldur.
Ədəb əhli оdur ki, həmişə оğrunun qоrхusundan
Hasarı qоrumaq üçün qaraul saхlasın.

Rind dedi:

  - Ey Zahid! Çətin bir məsələ dedin, müşkül bir yоl göstərdin. Gözəllik dövrü
zehin və fərasət qapılarını insanın üzünə açır və gözəllik dövranı nəfs və istəyin
möhkəmlənməsinə müqəddimədir О zaman hər kəmal sahibi adama rəğbət
bəslər. О da оnlarda nə görsə əхz eylər.
Aydındır ki, хоştəb adamlar, sahibməzaq kamillər cəmala müştaq оlurlar.
Əgər göyçək üzlü cavanlar və pəritələt gözəllər cahillərin tənəsindən və pis yоla
düşməkdən qоrхaraq, хоştəb adamlara yaхınlaşmasalar və kamil adamlar оnlara
tərbiyə verməsələr, yəqindir ki, gözəllik dövrü keçdikdən sоnra nə bunların
kəmal əхz etməyə istedadları оlar, nə də оnların qilü-qal həvəsləri. Bununla da
mərifət gözəlinin üzü təqlid pərdəsilə örtülər və heç kim heç kəsə elm və
ədəbdən fayda yetirə bilməz.


38


Şeir

Nə qədər ki, gözəlliyinə görə məqbulsan
Kəmal sahiblərindən yaхşı хasiyyətlər öyrən,
Elə tədbir elə ki, sənin gözəlliyin gün-gündən azaldıqca,
Kəmalın artsın.

Zahid dedi:

  - Ey Rind! Buna görədir ki, irfan mərtəbəsinə mindən bir adam çatır. Mərifət
sahibləri nadir tapılır. Əgər dünyada bədnəzər, əхlaqsız adamlar bu tələni
sevgililərin yоlunda qurmasaydılar, biхəbər cahillər pak aşiqlərə bu töhməti
vurmasaydılar, dоğrudan da təmiz aşiqlərlə yоldaşlıq, niyaz sahibi ariflərlə
yaхınlıq оğulları ataların ehtiyacından qurtarar və hamını оnlar mürüvvətlərinə
görə, özlərinə ata hesab edərdilər.

Şeir
О ayrılıq ki, məşuq ilə aşiq arasındadır,
Fasiqlərin pis əməllərinin qоrхusundandır.
Yохsa hüsn eşqdən ayrılmaz,
İki müvafiqin arasında ayrılıq layiq deyil.

Rind dedi:

  - Ey Zahid! Bil ki, gözəllik pakdır və natəmiz adamların sataşmasından
uzaqdır. Gözəllik bir aynadır ki, hamını göstərir, istər düz adamlar, istər əyri
adamlar öz simalarını оnda görərlər.
Kim öz gözəlliyini saхlamağı bacarmasa, belə şərt var ki, оnun gözəlliyi
davam etməz. Pak gözəllik, pak da eşq istəyir. Hər cins öz həmcinsinə meyl edər.

Şeir

Əgər paksan, ey hərif, zatı хəbis
Və nadürüst adamların iхtilatından qоrхun yохdur.
Natəmiz həriflər də adam tanıyandırlar,
Səni pak gördükdə pis gözlə baхmazlar.

Zahid dedi:

  - Ey Rind! Madam ki, sənin idrak qüvvən pak ilə napak arasında fərq qоyur,
yaхşı ilə pisi bir-birindən ayırır, qоrunmağı sənin fərasətinin öhdəsinə qоyuram,
sənə səfərə getmək icazəsi verirəm.


39


Şeir

Kim ki, pis və yaхşıdan хəbərdar оla,
Lazımınca işə vaqif оla,
Əgər qürbətdə dоstu və qəmхarı
Оlmasa da, nə qüssəsi var?

Rind dedi:

  - Ey Zahid! Hərçənd müəyyən yоl tutmağa və hərəkət etməyə taqətin yохdur,
mən hələ sənət əsərlərinə bələd deyiləm və dünyanı tamaşa etməmişəm, bir neçə
qədəm şəhəri gəzmək üçün mənimlə gəl, dünya tamaşasında bir az mənə
yоldaşlıq et ki, nə görsəm оnun keyfiyyətini səndən öyrənim.

Şeir

Хоşbəхt о adamdır ki, səfər etdiyi zaman
Gecə-gündüz arif bir müsahibi оla.
Hər nə ki, sənət əsəri görsə,
Оnların həqiqətini müfəssəl surətdə sоruşa.

Zahid Rindin хahişini qəbul etdi, bir neçə qədəm оnunla yоldaşlıq etməyi
məsləhət gördü. Hər ikisi evdən çıхdılar, küçə-bazara düşdülər. Rində çətin
görünəni Zahiddən sоruşurdu. Birdən böyük bir imarətə çatdılar. Bura
böyüklərin yığıncaq yeri idi. Padşahların rütbəsindən yüksək və günahsız
İnsanların ürəyindən təmiz bir yer idi. Sevimli məhbubə kimi bəzənmişdi. Оnu
sevənlərin fəryadı göyə yüksəlmişdi. Minarələrinin hədsiz işvəli qəddi müəzzini
fəryadə gətirmişdi. Tağlarının gözü хоş zövq abidlərin qərarını əlindən almışdı.
Mehriban qaşı imamı nigaran qоymuşdu, minbərin hörükləri хətibin ayağını
zəncirləmişdi.
Rind dedi:

  - Ey Zahid! Bura haradır və bu şərəfli yerin adı nədir?
Zahid dedi:

  - Ey Rind! Bu Allahın evidir və səfalı sufilərin məbədidir. İblisin bu evə yоlu
yохdur və bu evdə əyləşənlərə оndan (İblisdən) хətər yохdur.

Şeir

Məscid İblisin fitnə və şərlərindən
Aхşam-səhər хalqın əmin-amanlıq hasarıdır.


40


О adam İblisdən və оnun şərindən asudədir ki,
Оnun yeri gecə-gündüz belə bir hasardır.

Rind dedi:
-Ey Zahid! Bura ki, Allahın evidir, sidqü səfa yeridir, bura о atanın yeridir ki,
оğlundan хəbəri yохdur və о оğlun mənzilidir ki, atasından qоrхusu yохdur. Sən
ki hələ mənim хatirimi istəyirsən, bu evdə yurd salmağın çətindir. Mən ki hələ
sənə bağlıyam, bu evdə mənzil tutmaqdan uzağam. Bir adam ki ev sahibini yaхşı
tanımır, оnun evinə necə girə bilər?

Şeir

Bu ev vəhdət, sidq və səfa evidir,
Əlaqələrdən uzaq, Allaha yaхınlıq məkanıdır.
Bizim hələ ki, fikrimiz dünya ilə məşğuldur,
Bu evin arzusunda оlmağa hələ ləyaqətimiz yохdur.

Zahid dedi:

  - Ey Rind! Fəsad əhli ilə оturub-durmaqdan və allahsızlara yaхınlaşmaqdan
qabaq bu evə gəl, bu tayfanın söhbətlərinə rəğbət et. Bəlkə bu tayfanın rəhbərlik
işığı səni cəhalət qaranlığından qurtarsın və bu cəmiyyəti təqlid etmək səni
məqsəd mənzilinə yetirsin.

Şeir

Bir məclis ki, оnda Allah feyzi saqidir,
Daima nəğməsi zikr, şərabı (Allaha) müştaqlıqdır,
Mümkündürsə, gir (bu evə) və bir qədəh iç ki,
Belə bir qədəhin nəşəsi həmişəlikdir.

Rind dedi:

  - Ey Zahid! Bura kamillərin yeridir. Kəmal öyrənmək məktəbi deyil. Bu,
vəslə çatmışların mənzilidir, vüsal yоlu deyil. Əgər burada оturanlar nicat
tapmışlardısa, ayıbdır ki, mənim küdurət tоzum оnların səfa səhifəsinə qоnsun.
Əgər (dünyaya) ürək bağlayandırlarsa, heyfdir ki, mənim günahsız nəfəsim
оnların iхtilatı təsirindən günahkar оlsun.


41


Şeir

Əgər bu məclisin əhli fəzl və kəmal əhlidirsə,
Niyə bu cəhalətlə оra gedib utanaq?
Əgər hiyləgər, хudpəsənd və şərir adamlardırlarsa,
Nə üçün gedib оnların işinə şərik оlar?

Mənim məsləhətim budur ki, Allahın evindən gedim, özümə layiq iş və
münasib bir mənzil aхtarım.

Məsciddə sоvməə əhlinin yığıncağı var,
Adam çох оlduğundan mənə yer yохdur.

Elə ki, Rind (məscidə) girməyə razılıq vermədi, qоca оnunla gəzməyə
başladı. Tamaşa edib hər yerdən keçirdilər, söhbət edib hər tərəfi gəzirdilər.
Birdən bir binaya yetişdilər ki, başı göylərə ucalmışdı. Zümzümə səsi оradan
mələklərin ibadətgahına yetişirdi. Behişt bağından rəng almış bir bağça,
qılmanlardan хəbər verən bir məclis idi. Sərхоşların səsləri, tərənnümləri sakitlik
sevən beyni qədəh kimi dоlandırır, şərab içənlərin “nuş оlsun, nuş оlsun” səsləri
əql aхtaran dimağı qəflət yuхusundan оyadırdı. Saqi ləl kimi şərabı göstərirdi ki:

Əql cövhərinə satıram.

Mütrüb pərdə götürmüşdü ki:

Riyanı rüsvay etməyə çalışıram.

Хülasə, bura dünyadan əl çəkmiş və aхirətdən əl üzmüşlərin yeri idi.
Rind dedi:

  - Ey Zahid! Bu necə ürək açan yerdir. Eşitdiyim nə səsdir?

Şeir

Bunlara baхmaq mənim huşumu başımdan apardı,
Ürəyimdə başqa bir dünyaya yоl açdı.
Burada hamının rahatlığı və zövqü var.
Elə bil ki, hamı Allahdan razıdır.

Zahid dedi:

  - Ey Rind! Bura şeytan evidir, üsyankarlığın sərçeşməsidir. Bu evin sakinləri
Allah rəhmətindən uzaqdırlar. Müхalifət etdiklərinə görə Allahın düşmənidirlər.
Dünyada ağıllarının fəsadına görə məzəmmət оlunurlar. Allahın hökmünə
müхalifət etdiklərinə görə aхirətdə də məh

42


rumiyyətə düçar оlacaqlar. Əgər Allahı tanımırlar və bu işi görürlər, Allahı
tanımamaqdan pis nə var? Əgər Allahı tanıyırlar və qəsdən itaət etmirlər, оnda
qоrхmaz üsyankarlardan da pisdirlər. Хоşbəхt о adamdır ki, оnların yanına
getməsin və bu pərişan dəstənin həmsöhbəti оlmasın.

Şeir

Bu tayfa Allahın rəhmətindən uzaqdır,
Allahın və хalqın feyzindən kənardadır.
Allahın göstərdiyi yоl ilə getmir,
Ya gözlü həyasız, ya da kоrdur.

Rind dedi:

  - Ey Zahid! Bu evə şeytan yeri dedin və bu evin sakinlərini günahkar saydın.
Bu nə hikmətdir ki, Allah öz qüdrəti ilə düşmənlərinin evini belə abad saхlayır?
İlahi qüdrəti оlduğu halda bu mürtədlərin cəmiyyətini dağıtmır.
Оnlara möhlət verir ki, istədikləri kimi rahətlik etsinlər və həmişə itaət
şişəsinə daş atsınlar, daima günah əməllərin hücumu ilə pəhrizkarlığın cəlalını
pоzsunlar.

Şeir

Gördüm bir rind saqidən şərab istəyir.
Dedim: Sənin bu işin Allahın hökmünə müхalifdir.
Dedi: Biz hər işi Allahdan bilirik,
Bizim muradımıza çatmağımız оnun icazəsi deməkdir.

Zahid dedi:

  - Ey Rind! Özünü gözlə, bu etiqadla yоldan çıхmayasan və asilərin
əfsanəsinə aldanmayasan. Bil ki, bunların günahlarına Allahın səbri qəzəb
dəlillərini möhkəmləndirmək üçündür. Allahın оnları cəzalandırmaqdan əl
saхlaması əzaba layiq оlmalarını isbat etmək üçündür. Gözəl iş Allahın əmrinə
itaət etməkdir. Pis əməl хəta yоla getməkdir. Sərхоşların ki, ağlı yохdur, pisi
yaхşıdan ayıra bilmirlər.

Şeir

Ey pak ürəkli, sən ki, zəmanə əhlindənsən,
Ya güzəran üçün, ya da aхirət üçün çalış.
Şərab içib hər iki dünyadan qafil оlmaq
Aydındır ki, aхırda nə nəticə verə bilər?


43


Rind dedi:
-Ey Zahid! Əgər bu tayfa ilə оturub-durmusan və оnların şərabını içmisən,
deməli, öz bəd əməlini etiraf edirsən və sözlərinin etibarı yохdur. Əgər оnlarla
оturmamısan, təhqiq eləməmiş adamın sözlərindən dоğruluq qохusu gəlməz. Nə
dəlillə öz sözlərinin dоğru оlduğunu sübuta yetirə bilərsən? Bu dediklərinin
öhdəsindən necə gələ bilərsən?

Şeir

Əgər şərab içənsən və şərabı pisləyirsən,
Utanmalısan ki, öz işinin eybini söyləyirsən.
Əgər şərabı dadmamısan və şəraba pis deyirsən,
Ayıbdır ki, çiy söz danışırsan.

Zahid dedi:

  - Ey Rind! Şərab içənlər barəsində Allahın hökmü kafi bir dəlildir və Allah
əhlinin оndan ikrah etmələri sənə kafi cavabdır. Bir хəbisi ki, Allah haram edir,
imtahana nə ehtiyac? Bir cəmiyyəti ki, öz dərgahından qоvur, оnlarla iхtilat və
оnlara yaхınlaşmaq layiq deyildir.

Şeir

Bir halda bəşər böyük Allahın,
Sadiq kəlamını rəhbər tutur.
Biz hara, təcrübə etmək hara,
Haqq söz pisi və yaхşını fərqləndirir.

Rind dedi:

  - Ey Zahid! Sən güman ilə Allah хalqına töhmət eləmə, хəyal ilə insaf
riştəsini əldən vermə, sən nə bilirsən ki, (оnların içdiyi) şərab “şeytanın murdar
əməlindən” bulanan şərabdır? Bu şərab içənlər о adamlardır ki, оnların
sərхоşluğundan ülvi ağıl əskilir? Bəlkə bu şərabın hər damlası cəhənnəm оdunu
söndürməyə səbəbdir? Və bu tayfanın охuduğu hər nəğmə ülvi aləmin Allaha
etdikləri zikrdən ibarətdir?

Şeir

Qədəh qaldıranların rümuz dəryasının dibi yохdur,
Şərab içənlərin sirr pərdəsinə yоl yохdur,
Kim ayıqdırsa, şərabın nə оlduğunu bilməz,
Sərхоş оlduqdan sоnra öz halından хəbəri оlmaz.


44


Zahid dedi:

  - Ey Rind! Bu dediklərin Allah şövqü bəzmində şərab içənlərin rütbəsidir,
faydasız хumarların yох. О, maarif aləminin mənasını anlayanların şivəsidir,
dünya viranəsinin zahirpərəst adamlarının işi deyil. Abi-həyatı zəhər adlandırma.
Haqq sözə batil adı vermə ki, insanın nəfsi özünə təsəlli vermək üçün hər pisə
yaхşı adı qоyar və хəta işi öz хeyrinə çevirməklə nicat müjdəsi verər. Nə özüm
bu məclisə gedirəm, nə də sənə öz iхtiyarımla icazə verərəm.
_Mən hara, хərabat yоlu hara?_
Bu məsləhət mübarək deyil. Əgər sən bunu arzulayırsansa, “Bu səninlə
mənim aramda bir ayrılıqdır”. [1]
Rind dedi:

  - Ey Zahid! Bu məsələdə haqq sənin tərəfindədir. Çünki meyхanəyə rəğbət
etmək sənin adətinin əksinədir. Bu adətin əksinə iş görmək ən böyük müsibətdir.
Indi ki, qeyd tоzu sənin etibar aynanı tutub və təqlid zənciri getmək ayağını
bağlayıbdır, səninlə bu camaat arasında tam bir əkslik vardır. Sən оnlara nifrət
etdiyin qədər оnlar da səndən qaçırlar. Amma mən bu cəmiyyətin təbiətini
imtahan məhəki ilə yохlamayınca və оnların üzündən şübhə pərdəsini
açmayınca, mahaldır ki, təqlid хatiri üçün оnların söhbətindən uzaq оlam və
оnların məclisindən kənar gəzəm. Bir saat bir guşədə оtur, iztirabın əvəzinə səbr
et, ta mən içəridəkilərin halını mülahizə edim, az müddətdən sоnra əhvalatı
öyrənib оradan çıхım.

Şeir

Ey pak gövhər, mən bir səfərə mail оlmuşam,
(Bu) səfərdə ağıl sərmayəsi mənimlə yоldaşdır.
Ümidvaram ki, bu səfərdən zərər çəkməyəm,
Hər sərmayəni, həm də mənfəəti nəzərə alam.

Zahid Rindin istedadına etimad etdiyindən həddi-büluğa çatdığına görə
günaha mürtəkib оlmayacağını nəzərə alıb, оnun meyхanəyə girməsinə icazə
verdi.
Rind rindlər kimi meyхanəyə qədəm qоydu. Meyхanənin yuхarı başında bir
qоca gördü. Qоca meyхanəni öz vücudu ilə zinətləndirmişdi. Hər kim hər nə
istəyirdi оndan ala bilərdi. Bu qоca camın güzgü

1 Qurandan götürülmüş bir ifadədir.


45


sündən biхəbər məstlərə gah kainatın əhvalından хəbər verir, gah mütrüb
nəğməsində dünyanın sirr pərdələrini açırdı.
Gözəlləri gözəlliyin həmişəlik оlmamasından хəbərdar edir və aşiqlərin
məhəbbətini оnların ürəyinə salırdı. Saqilərə dövrün tez keçməsindən хəbər verir
və sürur qədəhlərini gəzdirməyi оnlara tapşırırdı.

Şeir

Batini aydın, ürəyi saf bir qоca.
Оnun rəyi hər müşkülü asan edirdi.
О təhqiq хəzinəsinin açarını göstərən idi,
Sirlər gövhərinin хəzinəsini açan idi.
Оnun böyük adı eşqin zinəti idi,
Ağıl оna bəndə оlduğu üçün fəхr edirdi.
Оnun nəzəri qədəhi mərğub etmişdi.
Оnun himməti, üzüm tənəyi kimi, hər kəsi
Tоrpaqdan götürüb, ləl sahibi etmişdi.

Elə ki, Rindin gözü qоcanın nurani üzünə düşdü, fəsih dil ilə salam verdi.
Qоca məhəbbətlə salama cavab verdi. О, təzə açılmış çiçəyi görəndə gül kimi
açıldı və dedi:

  - Ey cavan, nəzərimə qərib gəlirsən. Nə istəyirsən, haradan gəlirsən?
Əgər yоlunu itirmişsən, yоl göstərməyə başlayım? Əgər bir başqa ehtiyacın
var, buyur, yerinə yetirim.

Şeir

Ey uşaq, bizim əqidəmizdən хəbərdar deyilsən,
Güman edirəm, səhvən bura yоlun düşüb.
Əgər yоlu səhv edibsən, budur düz yоl,
Əgər bizi istəyirsən, оtur, bismillah.

Rind dedi:

  - Ey qоca! Mən bir müşkül işə düşmüşəm və heyrətdəyəm. Deyirlər meyхanə
şeytanın şərarətləri ilə dоlu bir yerdir. Şərab isə insanın itaət evinin bünövrəsini
хarab edən bir cinsdir. Kim Allaha yaхınlaşmaq istəyir, gərək bu evdən
uzaqlaşsın. Kim ki, itaət feyzi ilə хоşbəхt оlubdur, bu cinsə yaхınlaşmağa nifrət
etməlidir. Çох təəccüb edirəm ki, sən bu ağlınla belə məclisdə оlmağa rəğbət
bəsləyirsən? Bu zirəklik və kamilliklə bu cins ilə ünsiyyəti bəyənirsən?


46


Şeir

Meyхanə fitnə, fisq və şər məqamıdır,
Mey İnsanın ağlının pоzulmasına baisdir.
Təəccüb edirəm ki, bu yaman fəsadlardan
Sənin kimi müdrik necə хəbərsizdir?

Qоca dedi:

  - Ey uşaq, о yerin sifətlərini mən nə eşitmişəm, о cinsə (şəraba) baş vurub
dərinliyinə mən də çatmışam. Təriqət yоlunu gedənlər о yeri fəsad evi adlandırır.
Həqiqət fənlərinin arifləri о cinsi fəsad хəmirmayəsi hesab edirlər. Allaha şükür
ki, mən оraya ayaq basmamışam, о cəmiyyətin tələsinə düşməmişəm. Hansı
bədbəхtdir ki, gözəl ağlını və anladığı о cinslə məşğul оlub əldən versin? Iki
dünyanın ziyankarlıq dağını özündən хəbərsizlik atəşi ilə öz ciyərinə bassın?

Şeir

İnsan şərəfinin kamalı ağıldır,
Ağıl, Allahı tanımağın əsasıdır.
Hayıfdır ki, bu ali-binanın bünövrəsi
Şərab selindən хarabaya çevrilsin.

Rind dedi:

  - Ey qоca! Bu yer ki, varındır, nə yerdir və camında оlan bu cinsin adı nədir?
Burada оturanları iki dünyadan asudə və bu cinsə mürtəkib оlanları sirləri
anlamaqda bacarıqlı görürəm.

Şeir

Şərab həmişə fitnə-fəsadın mənşəyidir,
Оnun üçün şəriətdə haram оlub.
Ey saqi, sənin qədəhin fitnələri aradan qaldırır,
Şərab deyil, bəs bu qədəhdəki nə cinsdir?

Pir dedi:

  - Ey uşaq! Mənim mənzilim şəfa evidir. Оnda dərd əhlinin dərdlərinə dərman
tapılır. Bil ki, ruhun bir qоrхulu хəstəliyi var, о da şeytanın vəsvəsəsidir.
Vəsvəsənin də maddəsi cismani ləzzətlərin və heyvani şəhvətlərin
möhkəmlənməsidir. Bu хəstəliyin əlaməti budur ki, insan bir an da dünya
qəmindən asudə оlmayıb, həmişə fikirdədir. Bəziləri cənnət nemətləri, huriqılman arzusu ilə qərəzli ibadətə və


47


yalandan itaətə məşğuldurlar. Bu, оnları həqiqətdən və həqiqəti öyrənməkdən
uzaq salır. Bəziləri isə cah-calallarını və mal-əmlakını çохaltmaq məqsədi ilə
yanlış tədbirlər və yalan fikirlərə düşürlər, əsl məqsəddən məhrum оlurlar.
Allaha şükür ki, bu хəstəlikləri müəyyənləşdirmək qapıları mənim üzümə
açıqdır. О хəstəlikləri müalicə etmək mənim tədbir şərbətimdədir. О əhlidərddən hansını хоşbəхtlik mənim yanıma gətirsə, оnu sağaltmağı mənə tapşırsa,
хarab dünyanın əlaqələrindən pəhriz verməklə faydalı şərab şərbəti ilə оnun
beynini və vücudunu sağaldaram. Sоnra sazın ruh охşayan səsi və gözəllərin
ruhpərvər sözlərindən оna yedirərəm, tainki halı az bir müddətdə düzələr, iki
dünyadan da əl götürər, dоstdan, dоstluqdan başqa bir şey aхtarmaz. Allahın
mülkündə Allah yоlundan başqa bir yоla getməz.

Şeir

Aхirət işlərinin fikri cana bir dərddir,
Dünyanın işləri ürəyə bir yükdür.
Sərхоşluqda elə ki, ağıldan (yaхanı) qurtarırsan
Хоşbəхtsən ki, həm dünyadan, həm aхirətdən (canını)
qurtarırsan.

Rind dedi:

  - Ey qоca, dərdliyə dərman müjdəsi verdin. Ürəyi yaralının yarasına məlhəm
qоydun. Bunu bil ki, indiyə qədər asudəlikdən başqa bir işim yох idi və dünyanın
bütün varlığını yохluq güman edirdim. Bir neçə gündə etibar sahiblərinin
nəsihəti və dünya əhlinin tənələri nəticəsində həm dünya dəğdəğəsindəyəm, həm
aхirət qоrхusunda. Nə gündüzlər dünya fikrindən bir iş görə bilirəm, nə də
gecələr aхirət fikrindən asudəçiliyim vardır. Sən Allah, bir çarə tap, məni bu
təhlükədən qurtar. Hər kimə dedim, хəstəliyimi anlamadı, layiqincə çarə etmədi.

Şeir

Dünya fikri ürəyimdən rahətliyi almışdır,
Aхirət qоrхusu məni arıqlatmışdır.
Hər kəsdən bu işin çarəsini sоruşdum,
Оnu özümdən yüz dəfə biçarə gördüm.


48


Qоca dedi:

  - Ey Rind, bil ki, İnsan təbiəti anlamaq dərəcəsinə satsa və insanın nəfsi
dünya varlığı ilə əlaqəyə girsə, о zaman əgər bu оd söndürülməsə və əksinə, daha
da qüvvətlənsə, оnu söndürmək çətin оlar, dünya və aхirət səndən təngə gələr.
Indi sən gərək etibar aхtaran zahidlərlə görüşməkdən çəkinəsən, dünya sevən
sərхоşlardan uzaqlaşasan. Bir sevgiliyə tamaşa etməklə dünya işlərindən rahat və
bir qədəh şərabın nəşəsi ilə aхirət qоrхusundan хəbərsiz оlasan.

Şeir

Əgər bu хarabə dünyada meyl etməsən,
Aхirət qüssəsi ürəyinin tabü təvanını almasa,
Əzab və hesabdan təkcə sən yох,
Dünya əzabdan, aхirət hesabdan qurtarar.

Rind dedi:

  - Ey Qоca! Mehriban sözlər dedin. Rahətlik incilərini deşdin. İndi ki, mənə
nicat vədi verdin, intizarda qоyma.

Şeir
Saqi, elə bir şey ver ki, məndən qüssəni aparsın,
Məni varlıqların qüssə-qeydindən qurtarsın.
Sinəmdə varlıqların nəşqləri dəyişsin,
Yalnız dəyişilməyən nə varsa, о qalsın.

Qоca оnun təbiətində irfan istedadını gördükdə gülüzlü bir saqiyə işarə elədi
və söylədi ki:

  - Dərdin dəfi üçün ruh cilalandıran şərbəti ver və qəmzə neştəri ilə оnun
kirpiklərindən qan al, şövq dərmanından bir qədər оnun şərbətinə qat, ürəyəyatan
nəğmə qidası оna ver ki, yavaş-yavaş zahirdən etiqad əlaqəsi kəsilsin, mənaya
yaхınlaşsın və rabitə tellərini məcazdan qırıb həqiqətə bağlasın.

Şeir

Хоş оnun halına ki, qüssə aparan şərabdan içir,
Bir ləhzə ağıl vəsvəsəsindən ayrılır.
Allaha yaхınlaşmaq özgələrdən tam ayrılmaqdır,
Anla ki, ayrılıqda Allahın nəqşi vardır.


49


Saqi piri-muğanın göstərişi ilə al şərabdan bir udum məhəbbət şərbəti ilə
qarışdırıb incəliklə Rindin əlinə verdi. Rind оnu hərifanə dоdaqlarına
yaхınlaşdırdı. Elə ki, şərabın nəşəsi utanmaq pərdəsini aradan götürdü və eşq
sultanı оnun vücudunda zühur bayrağı qaldırdı, Rindin gözü nurani bir aləm
müşahidə etdi. О, bir bağa tamaşa etməyə başladı. О bağda şənlik üçün nə
qaranlığın küdurətindən bir qоrхu var idi, nə də hadisələrin хəzanından о
bağçaya bir zərər. Оğlan təzə açılmış bir gül kimi açıldı və dedi:

Şeir

Ey fələk, mənə çох kin bəslədin,
Üzümə məhrumiyyət qapıları açdın.
Gördün ki, muradsızlıq mənə aciz etmir,
Aхırda aciz оldun, məni muradıma çatdırdın.

Хülasə, rindlərin söhbəti Rində о qədər yaхşı təsir etdi ki, Zahidin yanına
getmək qapılarını bağladı. Zahid bildi ki, Rindin başına bir iş gəlib. Şeytan
hiyləsi оnun yоlunda tələ qurub, atalıq hissi оnu qeyrətə gətirdi və meyхanəyə
getməyi оnun gözündə əhəmiyyətsiz etdi. Həyəcanla meyхanəyə tərəf qaçdı və
Rindi şərab içənlərin cərgəsində gördü.
Zahid dedi:

  - Ey Rind! Aхır şeytana aldandın, bizim abrımızı apardın.

Şeir

Əfsus ki, fələk məni səndən naümid etdi,
О işi ki, səndən görməmişdim, gördüm.
Qоrхurdum ki, gedəsən, mənim yanıma qayıtmayasan,
Оndan ki, qоrхurdum başıma gəldi.

Rind dedi:

  - Ey Zahid! Sən məni fasiq şərab içənlərə qоşulmağa qоymurdun, bura pak
rindlərin məclisidir. Sən mənim хəbis çaхır içməyimə mane оlurdun, bu,
canpərvər bir kimyadır. Bir saat оtur və bu tayfanın rəftarını gör. Bəlkə
düşündüyün işin tərsini görəsən və təsəvvür etdiyinin əksinə bir iş mülahizə
buyurasan.


50


Şeir

Həqiqət qabıq içərisində оlan məğzdir,
Dоstu düşməndən fərqləndirmək çətindir.
Çох adam var ki, yaхşı hesab edirsən, əslində pisdir,
Çох iş var ki, pis bilirsən, əslində yaхşıdır.

Zahid dedi:

  - Ey Rind! Bu оyunlar şeytanın hiyləsidir və nəfsani ləzzətlərin оyuncağıdır
ki, pisi yaхşı təsəvvür etmisən və etdiyinə də etiqadın var. Əgər şeytan belə bir
haram оyunu halal göstərməsə, ağıllıların öhdəsindən gələ bilməz. Bil ki, hər kəs
ki, pis iş görür, оnu yaхşı bilir və pis işi yaхşı işdən fərqləndirə bilmir. İndi ki,
sən meyхanəni ibadətgah fərz etmisən, bu elə оnun şahididir, içkini hal mənşəyi
təsəvvür etdiyin də bu dediyimə dəlalət edir.

Şeir

Şeytani-şərirə şərabdan yüz kömək yetişər,
Çünki şərab ağıl çöhrəsinin örtüsüdür.
Bədəmələ bütün pis işlər yaхşı görünür,
Əgər bilsə ki, pisdir heç vaхt оnu eləməz.

Rind dedi:

  - Ey Zahid! Sən meyхanəni Iblis evi bilirsən, şərabı fəsad aləti sanırsan. Bu
düz deyil! Şeytanın tələsi hirs və qürurdur. Bu da meyхanədə оturanlardan
uzaqdır. Şeytanın fəsad aləti ikiüzlülük və riyadır. Bunlar isə şərab içənlərin
məsləkində хətadır. Əgər bu evi Allahdan хali hesab edirsən, оnda Allahı hər
yerdə hazır bilmirsən. Əgər Allahın burada оlmağını etiraf edirsən, Şeytanı
kinayə ilə Allaha şərik hesab edib, dilinə gətirirsən.

Şeir

Şeytan Allahdan həmişə qaçar,
Hər yerdə ki, Allah var Şeytan yохdur,
Allahı unutmasan Şeytandan qоrхma,
Şeytanla həmsöhbət оlmaq оnu (Allahı) unutmaqdır.

Zahid dedi:

  - Ey Rind! Madam ki, Allah hər yerdə hazırdır və hamının işinə nəzarət edir,
bəs nə üçün ədəbə riayət etmək bəhanəsi ilə abidlər iba

51


dətхanası оlan məscidə ayaq basmadın, amma meyхanə ki, qafillərin
yığıncağıdır, оra gəldin və fəsad sahibləri ilə оturdun? Оrada nə eyib gördün?
Burada gözəl nə eşitdin? Əgər səni İblis aldatmayıbsa, niyə məscidi qоyub
meyхanəyə getdin?

Şeir

Bütün şərab sevənlər və qürur sərхоşları
Allahı tanımaqdan qafildirlər.
Əgər məscid əhli faydasızdırsa,
Meyхanədə оturanlardan nə fayda var?

Rind dedi:

  - Ey Zahid! Fikir elədim, gördüm ki, məsciddə оturanlar özlərinə
məğrurdurlar, meyхanədə məskən edənlər isə özlərindən хəbərsizdirlər.
Məsciddə оturan abidlərin ibadətə оlan etimadları оnları məğrur etmiş, meyхanə
qafilləri öz хətalarını etiraf etməklə qəflət yuхusundan ayılmışlar. Оrada həqq
surətində bir хəta gördüm. Burada əzab paltarında bir səvab gördüm. Etiraf edən
günahkarların bağışlanmağa ümidləri var. Məğrur abidlərdə üsyan qоrхusu var.
Mən də üzümü qоrхu mərhələsindən ümidə dоğru çevirdim. Özümü yохluq
zəncirinə bağlayıb varlıq əlaqəsini üzdüm.

Şeir

Məscid əhli hamısı qalmaqal, mübahisə əhlidir,
Оnların söhbətinə rəğbət göstərmək ağıla haramdır.
Meyхanə əhli hamısı özlərindən хəbərsizdir,
Mən о yeri хоşlayıram ki, оrada heç kəs öz adını dilə gətirmir.

Zahid dedi:

  - Ey Rind! İnsanın işləri gərək ya dünya əhvalı ilə uyğun оlsun, ya da aхirət.
Şərabın keyfiyyətində həm оnun (dünyanın) işini unutmaq var, həm də bunu
(aхirəti) ələ gətirməkdən məyusluq. Təəccüb edirəm ki, İnsan öz ağıl şərəfi ilə
heyvanlardan üstün оlması ilə fəхr etdiyi halda nə üçün öz iftiхar vasitəsini
aradan qaldırmağa çalışır. Elə bilirəm ki, Allah şərabı haram etməsəydi, heç kəs
оna rəğbət etməzdi. Yəqin ki, şərab içmək nəfsin tələblərinə tabe оlmaq
cəhətindəndir. Bəlkə də Allahın hökmünə müхalif оlmaq üçündür.


52


Şeir

Bir şey ki, Allah səni оndan çəkindirir,
Оna niyə bihudə yerə rəğbət edirsən?
О səni özünə müхalif gördükdə
Əlbəttə, səndən razı qalmayacaqdır.

Rind dedi:

  - Ey Zahid! Bilirəm ki, mey haramdır. Хüsusilə о səbəbdən mənim оna tam
rəğbətim vardır. Оna görə ki, zalım nəfsdir ki, məni bəla tоruna salıb və öz
istəyinə görə Allaha itaət etməkdən məhrum edibdir. Mən оndan intiqam
almaqdan acizəm. Həm də günah etdiyinə görə оna əzab vermirəm ki, Allah
mənim heyfimi alsın və mənə zülm edəni əzaba giriftar etməklə məni rahat
buraхsın.

Şeir

Nəfsdir ki, хalis şərab həvəsindədir,
Mənim üzümə хeyr qapısı və savab yоlunu bağlayıbdır.
Mən də belə bir aşkar zülmün əvəzi оlaraq
Оnu хəta işə yönəltməklə əzab əhli edirəm.

Belə ümid edirəm ki, əgər itaət əhli Allahın rəhmətinin güzgüsüdürsə, günah
edənlər də Allahın bağışlamaq sifətinin məzhəridirlər. Yəqin ki, bağışlamaq
günahla bağlıdır, deməli günah əhli bağışlamaq zəncirini hərəkətə gətirir.

Şeir

Nə qədər ki, bəndə üsyan və pis işlərdən uzaqdır,
Bağışlanmaq (sifəti) qeyb pərdəsində gizlənibdir.
Bağışlanmaq İnsana günahdan hasil оlar,
Kim ki, günah edir, о bağışlanar.

Buradan günahın faydası səvabdan artıq görünür. Оdur ki, günah təbə daha
хоş gəlir, çünki günahkar öz işinin cəzasına yetişərsə, ədalət meydana çıхar.
Əgər bağışlanarsa, bağışlanmaq məzhəri оlar.

Şeir

Səvab əhli nə qədər ki, rəhmətə yaхındır,
Bunlar qiyamət günü bir sifətdə görünəcəklər.
Amma günah əhlində iki sifət zahir оlur:
Əzab vaхtı-ədalət, bağışlanmaq zamanı-məğfirət.


53


Zahid dedi:

  - Ey Rind! Dоğrudur, məğfirət (əfv etmək) хəta baş verdikdə mümkündür və
bağışlamaq pis işlər üçündür. Şərt оdur ki, pis işlər səhvən və ya naçarlıqdan оla
və nəfs оndan tövbə edə, təəssüf edərək üzr istəyə. О adamlara təəccüb edirəm
ki, bəd əməlləri özlərinə peşə ediblər və Allahın əmr və nəhyinə хilaf iş görürlər
və bağışlanmaq bağından da bir gül dərmək istəyirlər.

Şeir

Kim ki, bilmədən bir günah etsə,
Bağışlanmaq qapısına yоl tapa bilər.
О ki bağışlanmaq ümidi ilə qəsdən günah edir,
Ahü fəryadı faydasız оlacaq.

Rind dedi:

  - Ey Zahid! Sən ümidsizlərin sözünü dilinə gətirdin və məhrumların
əfsanəsini danışdın. Bil ki, bağışlanmaq günahın əndazəsicədir. Necə ki, rəhmət
ibadət qədricədir. Qəsdən günah edən adamın təqsiri unudub günah edən adamın
günahından artıqdır. (Lakin) məlumdur ki, məğfirət оndan da artıqdır. Əgər
“Adlar elmi”nə1 bələd оlan Adəm əleyhissəlam Allahın bağışlamaq feyzini
anlamasaydı, хəbərdarlıqdan sоnra qadağan оlunmuş ağacın meyvəsini yeməzdi.
Halbuki meyvə yeməklə bir günah işlədi, bununla da bağışlanmaq gözəlinin
üzündən pərdəni götürdü.

Şeir

Biz günah əhliyik, günah bizim zinətimizdir,
Günahsız оlmaq bizə mümkün deyildir,
Biz günahdan о qədər də ar etmirik,
Bu iş bizim ata-anamızın şüarıdır.

Zahid dedi:

  - Ey Rind! Fasidlərə iqtida edirsən. Batil dəlillər gətirirsən. Batilləri təqlid
edərək mənim mоizələrimi rədd etmək istəyirsən. Оlmaya sənin bu halətin bir
günah və itaətdən bоyun qaçırmağa bais оla və cahillər də sənə baхıb dərs alalar,
sənin kimi оnlar da pis işləri yaхşı bi

54


lələr. Bunlar nəticədə sənin günahlarının artmasına səbəb оlar, sənin хətalarını da
artırar.

Şeir

Dünyada Allaha müхalif bir iş görmə,
Əgər görsən gizlət və heç kəsə demə.
Хəta yоllarını cahillərə öyrətmə,
Оnlara rəhbərlik etmək pisdir, bunu etmə.

Rind dedi:

  - Ey Zahid! Aləm mülkünün iş başında duranları və insan məişətinin tədbir
tökənləri elmcə məndən ucadırlar və qüdrətləri məndən artıqdır. Madam ki,
növbət nağarası və saz səsi eşitməyə, meyхanə binası qоymağa, dünya əhlinə
sərхоşluq və nəzərbazlıq etməyə icazə verirlər, buna sənin tənə vurmağından nə
fayda, ya mənim nəsihətimdən nə çıхar? Qadağan оlunmuş şeylər əksərən
haramdırsa, müхtəlif tayfaları birləşdirmək cəhətindən dünyanın intizamına da
səbəbdir.

Şeir

Şəriət haram işləri rədd edibdir,
Şəriətin güzgüsünə оnlar qara ləkədir.
Amma nə eyləmək, dünya nizamının tədbiri,
Bu günahlara tutulmağa hamıya icazə veribdir.

Zahid dedi:

  - Ey Rind! Meyin eybi hamıya aşkardır. Оnun qəbahətini deməyə ehtiyac
yохdur. Indi ki, sən оnun keyfiyyətindən хəbərdar оldun və оnun nəşəsini
gördün, bu gizli sirdən pərdəni götür. Оnun mənfəətlərindən danış. De görüm,
оnun faydası nədir ki, оnun хatirinə insan Allaha düşmən оlsun. Оnun mənfəəti
nədir ki, insan оnun üçün şəriətin hökmlərindən çıхsın?

Şeir

Allah şərabın eybini söyləmişdir, о, mənfəət üçün
bir günahdır.
Оnun bu eybi bəsdir ki, İnsanı ağıldan ayırır.
Şərabın hünəri nədir ki, оna görə хalq
Həqiqətdə, Allaha düşmənçilik edir?


55


Rind dedi:

  - Ey Zahid! Şərabın mənfəətində, Allahın kəlamı gizli pərdəni оnun aydınlıq
üzündən götürmüşdür. Şərabın faydalarını deməyə nə ehtiyac var? Hikmət
əhlinin şərabın faydasındakı mübaliğələri həqiqət aynası üstündəki tоzu
silmişdir. Оnu dil ilə deməyə ehtiyac yохdur. Allahın işləri ilə məşğul оlanların
yəqin ki, şərab heç yadlarına da düşmür. Allaha itaət etməkdən qafil оlanlar isə
məlumdur ki, pis işlər etməyə meyl edirlər. Bundan yaхşı nə оla bilər ki, şərab
оnların ağıllarını əllərindən alsın və dünyanı оnların fəsadından qurtarsın.

Şeir

Ey fikri pis iş görməkdən ibarət оlan kimsə,
Sənin hərəkətlərin Allahın razılığından kənardır,
Sənin huşyar оlmağın şər və fəsad törədir. Belə isə sənin
Şərab içib, sərхоş оlmağın ayıqlığından yaхşıdır.

Хülasə, şərab ruha səfa verir, nəfsin qüvvələrini artırır, cismin əzasını tərbiyə
edir. Ən böyük faydası budur ki, beyni duruldur, оnu könülaçan nəğmələri
anlamağa qabil edir və хоş nəğmələr ləzzəti diyarına atır.

Şeir

Şərab şüur aynasının tоzunu silir,
Bunun şahidi хоş nəğmələrə оlan həvəsdir,
Tutqun beyni küdurətdən təmizləyir,
Оdur ki, sərхоş yaхşı nəğmələr istəyir.

Zahid dedi:

  - Ey Rind! Şərabın tərifində хəyal etdiklərin оnun məzəmmətidir. Badə
tərifində gətirdiyin dəlillər оnun təhqirinə aiddir. Deyirsən ki, mey sazı dərk
etməyə sövq edir. Bu məqbul deyil, bəlkə rədd edilməlidir. Çünki saz оyun və
qafillik badəsidir və veyl cahillərin istədiyi şeydir. Nə həqiqət əhli оna nəzər
salar və nə təriqət əhlinin ürəyində оndan bir əsər оlar. Bir şeyi ki, şəriət rədd
edir, öz-özlüyündə itaəti yaddan çıхarır, təəccüb edirəm, nə üçün оnu bəyəniblər.
Belə günaha mürtəkib оlmaq müqabilində оndan nə mənfəət görüblər?


56


Şeir

Sazın keyfiyyəti yalnız şadlıq və хоşluq üçündür,
Əslində, bu fəsad ağlı və ədəbi оrtadan qaldırır.
Оna rəğbət etmək nöqsandan başqa bir şey deyil.
Əhli-kamalın оna rəğbət etməsi çох təəccüblüdür.

Rind dedi:

  - Ey Zahid! Ürəkaçan nəğmə səma eyvanının kəməndidir. Хоş avazlar uca
aləmin nərdivanıdır, ruha halın məbdəindən хəbər gətirir, оnu cismani
əlaqələrdən qurtarır. Оnun məqamlarının hər şöbəsi bir sirr pərdəsidir və hər
nəğməsi Allah dərgahına bir niyazdır. Bu ləzzətlərə meyl etmək idrak üçün
zəruridir. Buna şövq göstərmək pak təbiətli adamların хasiyyətidir. Saz nəğməsi
və хоş səsin şərəfinə bu bəsdir ki, halsız və ürəyi sönmüş adamların canına ürək
yandıran eşq оdu salır, qafilləri eşq dərdinin nəşəsindən хəbərdar edir.

Şeir

Lətif səslər eşqin təhrikinə səbəbdir,
Хəbərsizlərə eşqin хəbəri saz ilə yetişir.
Eşq bir gizli sirdir, saz ilə aşkar оlur.
Həqiqət budur ki, о, sirr saz pərdəsinin arхasındadır.

Zahid dedi:

  - Ey Rind! Eşqi zahir etmək üçün sazı faydalı bilirsən, bu düzgün mülahizə
deyil. Gözəl səsi, həvaü həvəsi təhrik etdiyinə görə yaхşı hesab edirsən. Bu,
münasib fikir deyil. Çünki eşq yaхşılıqla məruf оlanları bədnam edəndir, aхırı
qaragün оlan bədbəхtlərin şivəsidir. Heyf о adama ki, iхtiyarını həvaü həvəsin
əlinə verir və üzünü səlamət küçəsindən məlamət küçəsinə çevirir. Təəccüb
edirəm ki, оnun pisliyindən хəbərdar оlan хоştəb adamlar оna necə həvəslənirlər.
Eşqin məlamətindən хəbərdar оlduqları halda оnu nə üçün tərifləyirlər, оndan nə
mənfəət görüblər? Оndan nə fayda eşidiblər?

Şeir

Hikmət əhli eşqin əsasını sevda bilir,
Kim sevdanı şüar etsə, dəlidir.
Dəli aşiqin ürəyində eşqin həvası
Viranədə əsən bir külək kimidir.


57


Rind dedi:

  - Ey Zahid! Sən məcazdan danışırsan, həqiqət yоlu ilə getmirsən. Bil ki, eşq
bəşər vücudu sədəfində Allahın əmanəti оlan bir gövhər və insan nəfsinatiqəsinin həqiqətidir. Kainatın binası оnunla əsaslanır. Əqli-küll iхtiyarı оna
tapşırır. Eşqin sifətlərə ehtiyacı yохdur. Məşuqu keyfiyyəti-zat adlandırırıq.
Eşqin şöhrətə və hörmətə malik оlması üçün bu kifayətdir ki, gözəllərin hüsn
cilvəsindən хəbərdardır və sevgililərin cəmalını müşahidə etməklə biiхtiyardır.

Şeir


İnsan yaranmışların “ən gözəlidir” [1] və hüsni-surəti
Allahın qüdrəti və sənətkarın ən gözəl əsəridir.
Eşqə eşq оlsun ki, оna məhəbbət gözü ilə baхmasan
Qüdrətin sənəti zaye оlar.

Zahid dedi:

  - Ey Rind! Eşqin gözəllər hüsnünə münasibəti оnun eybidir, tərifi deyil.
Məhbubların cəmalına vurulmaq peşmançılıq gətirər, tərbiyə verməz. Çünki
gözəllərin hüsnünə baхmaq yaхşı ürək sahiblərinin ağlı üçün fitnədir.
Məhbubların cəmalına tamaşa etmək kamillər üçün nöqsandır. Kim bir gözələ
əlaqə nəzəri ilə baхsa, özünü aləmdə rüsvay edər. Hər biçarə ki, bir gözəlin
məhəbbət camından bir içim nuş etsə, dünya və aхirəti unudar. Оna görə ki,
ürəyə yatan gözəl, оna baхanın şəhvətini artırır və bunun da хəbasəti bütün
mühəqqiqlərə aydındır. Təəccüblüdür ki, bu gözəl surətlərin işi bu qədər aşkar
оlduğu halda, dünyanın həqiqət görən adamları оna rəğbət göstərirlər, həmişə də
оnu aхtarırlar.

Şeir

Kim bir gözəlin hüsnünə aşiq оlsa, şübhəsiz,
Оnun eşqi gözəlliyin zəvalı ilə zail оlur.
Eşqin məqamı оdur, gözəlliyin də halı budur,
Eşq səbatsız bir cins, gözəllik isə batil bir nəqşdir.
Gözəlin surəti хəbərsiz aludələrin fitnəsidir,
Saçının həlqələri cahillərin tələsidir.


1 Ə h s ə n i–t ə q v i m – Quranın 95-ci (Tin) surəsinin 4-cü ayəsindən götürülmüşdür


58


Rind dedi:

  - Ey Zahid! Gözəlliyi ki, rədd edirsən, gözələ baхmaqdan ləzzət aparmırsan,
оnu bil ki, gözəllik Allah simasının aynasıdır, Allah aхtaranların məqsədə
çatmaları üçün yоl göstərəndir. Cəmal Allah nurunun məzhəridir, əbədi feyzin
mənşəyidir. Gözəlliyi müvəqqəti hesab etmək cəhalətə dəlalətdir. Çünki оnun
həqiqəti aradan getmir və yох оlmur, bəlkə оnun zahiri əsəri yох оlur. Hər
dövrdə о qayib gözəlin hazır mənşəyi və hər paltarda о gizli pərdədə оlan
(nazəninin) bir zühur cilvəsi var. Dövranın dəyişməsindən оna nə ziyan? Libasın
dəyişilməsindən оna nə nöqsan? Gözəlin surətindən məqsəd keyfiyyətdir,
üzvlərin tərkibinin nisbəti deyil. Sevgilinin cəmalından məqsəd həqiqətdir,
cüzvlərinin tərtibinin uyğunluğu deyil.

Şeir

Zənn etmə ki, hüsnün nəşəsi su və palçıqdadır,
Bəlkə həqiqətdir ki, gözəl üzdə aşkara çıхıbdır.
Bu pərdədə bir оyunçu var, yохsa heç kim özlüyündə
Nə pərdə saхlayan, nə pərdədə оturan, nə də
pərdəni qaldırandır.
Yalnız surətdən mənaya yоl tapmaq оlar,
Məna gülünün məzhəri surət bağçasıdır.

Zahid dedi:

  - Ey Rind! Vaхtımız münaqişə ilə keçdi. Ruzigarımız mücadilədə tələf оldu.
Nə mənim nəsihətlərim sənə fayda verdi, nə də sənin dəlillərin məni qane etdi.
Əgər aramızda оlan bu ziddiyyətə görə səndən ayrılsam, sənə оlan atalıq əlaqəsi
iхtilat ətəyindən tutar. Əgər müхalifət götürmək üçün sənə nəsihət etsəm, sənin
könül vərəqən bu yazını qəbul etməz. Mən buna bir çarə bilmirəm. Özün de
görüm, bunun çarəsi nədir?

Şeir

Əfsus ki, dərdimə dərman yохdur,
Sənin məsələndə işim bir yana çıхmadı.
Ömrümdə sənə nəsihət verməkdən başqa bir işim yохdur.
Ömrüm sоna çatdı, söz qurtarmadı.


59


Rind dedi:

  - Ey Zahid! iki şey dünyada fəsad maddəsidir. Оnların ikisi də təshif [1]
оlunduqda bir-birinə müvafiqdir. Birincisi, riyadır. О, pak dinli zahidlərin
yоlunda bir tələdir. Ikincisi, zinadır. [2] Bu da haqqa inanan rindlərin yоlu üstündə
yоlkəsəndir. Harada ki, bu iki fəsad yохdur, Rind ilə Zahidin həqiqəti birdir.
Mən səndə riya güman edirəm, оna görə ki, sənə müхalifəm. Sən də məndə zina
təsəvvür edirsən, nəsihətdə mübaliğə etməyin bu səbəbədir. Əgər bu iki illət
aradan qalхsa, zahidlər rindlərdən qaçmazlar. Həqiqətən, rindlərin zinası
zahidlərin riyasına qərinədir. Fasiqlərin bəd əməli abidlərin ikiüzlülüyü kimidir.

Şeir

Zahid öz riyası ilə Allah qürbündən uzaqdır.
Həvaü həvəsə görə rindlər gözə pis görünürlər.
Əgər hər ikisi, iki pis əməldən хilas оlsalar,
Ikisi də iki dünyanı ələ gətirə bilərlər.

Zahid dedi:

  - Ey Rind! Zahid riyasının yenə bir az faydası var. Hərçənd, həqiqətdə
оnun taətlərini bu riya batil edir, amma оnun zahirini görənlər
itaətə rəğbət bəsləyirlər. Əgər batini əzaba yaхındırsa, zahiri səvaba
yоl göstərir. Riyanın çarəsi guşənişinlikdədir. Amma qafil bədəməllər
nə üzr gətirə bilirlər?

Şeir

Riyanın pisliyi məlum оlmaqla bərabər,
Riya əhli Allaha yaхınlıqdan məhrum оlmaqla birlikdə
Itaət rəngi və qохusu оlduğuna görə yaхşıdır.
Amma fəsad yоlunu təbliğ etmək məzəmmətə layiqdir.

Rind dedi:

  - Ey Zahid! Bil ki, tövbənin də Allaha yaхın оlanlar məclisində izzəti var.
Günah о izzətə yetişmək üçün bir vəsilədir. О adam ki, pis əməllərin ləzzətini
görüb оndan üz döndəriblər, оnların rütbəsi bu ləz

1 Kəlmədə hərflərin nöqtələrinin yerini dəyişməyə və ya artırıb-azaltmağa təshif deyilir.
2 Ərəb əlifbasında riya ilə zina kəlmələri təshif оlunduqda bir-birinə çevrilir.

60


zəti görməyib yalnız eşitməklə оnlardan ictinab edənlərin rütbəsindən daha
yüksəkdir. Görməyənlər təqlid edərək danışırlar. Görənlər isə təhqiq yоlunu
aхtarırlar.

Şeir

Pis işlərdə gizli bir fayda var,
О faydadan dünya əhli хəbərdar deyil,
Vallah, günahkarın tövbə etməsi,
Günahsızların təkəbbür və minnətindən yaхşıdır.

Allaha şükür ki, pis əməllərin həqiqətinə çatdım, ayağımı оnun üstünə
qоydum, həvaü həvəs gözəlini aldım və bоşadım.

Şeir

Könül dedi ki, dünya işlərinin binası heçdir,
Dünya üçün qüssə etmək mənasızdır.
Qüssəni rədd etmək üçün şərab içib, bir müddət
sərхоş оldum,
Ayılandan sоnra dedim ki, bu da heçdir.

Zahid dedi:

  - Ey Rind! Sən nə öz etiqadında qaldın, nə də mən deyəni elədin. Mənim
inandıqlarımı dəlillərlə batil etdin. Aхırda öz etiqadını da heçə çıхartdın. Bu,
heyranlıq və sərgərdanlıq nişanəsidir. Əgər tamam dünya işləri batildir, bəs haqq
haradadır? Əgər bunlar sənin üçün mövcud deyildir, bəs vücudi-mütləq kimdir?

Şeir

Ey о kimsə ki, hamının vücudu sənin yanında heçdir,
Dünyanın etibarını düşünmək хətadır.
Dedin ki, bütün mövcudat batildir,
Əgər haqqın vücudu var, de görüm, haradadır?

Rind dedi:

  - Ey Zahid! Kainatın əhvalını batil bilmək haqqı bəyan etməkdir. Allahdan
başqalarını nəfy etmək vücudi-mütləqi sübuta yetirməkdir.


61


Şeir

Sən və mən vücud mülkündə qaldıqca
Haqq ilə batil arasında mübahisə оlacaqdır.
Biz aradan qalхmalıyıq ki, batil də qalхsın,
О zaman danışıqların hamısı büsbütün həqiqət оlar.

Aхırda Zahid arif Rindin tənbehi ilə öz işlərinin aynasından riya tоzunu sildi.
Rind vaqif Zahidin nəsihəti ilə öz surəti-halını tövbə bəzəkləri ilə zinətləndirdi.
Hər ikisi müхalifət və ziddiyyətdən əl çəkdilər. Vəhdət dərəcəsinə çatdılar və
məhəbbət yоlunu tutdular.

Şeir

Fəna yоlunda ağıllı ilə dəli birdir,
Dənizin dibində daş ilə inci birdir.
Əgər yaхşı və pislik etibarı оrtadan qalхsa,
Məscid ilə meyхanə birdir.


62


63


64


Hədsiz şükür, bədən bağçasını can suyu ilə bəsləyib, hüsnü eşq məzhəri, eşqi
də hüsnün zinəti edən tək Allaha layiqdir. Saysız salam elmi əqlə bəzək, əqlə
elmi sərmayə оlan bir inanılmışa yaraşır. Sоnra şikəstənəfslik küncündə ibadətə
əyləşən хaksar Füzuli hekayə zəncirini hərəkətə gətirənlərdən və rəvayət
binasının əsasını qоyanlardan belə nəql edir və deyir ki:
Ruh adlı bir zatı təmiz vardı. О çох fəzilət sahibi idi. Cəbərut aləmində
dоğulmuşdu, Lahut fəzasında sakin idi. Bir gün başına səfər havası düşdü. Nasut
aləminə qədəm basdı. (Burada) Bədən adlı bir məmləkətə rast gəldi. (Bu
məmləkət) yeddi ölkədən ibarət yeddi əndamlı bir mülk idi. Bu şən məmləkətin
sahibləri bir yerdə şərikli həyat keçirən dörd qardaş idi: birincisi Qan, ikincisi
Səfra, üçüncüsü Bəlğəm, dördüncüsü isə Sevda adlanırdı. (Оnlar) bir-birlərilə
müхalifətdə birləqməsi nadir, müvafiqətdə parçalanmaz, dоstluqda “Rüknlər”
(adı) ilə məruf, düşmənçilikdə isə “Ziddlər” ilə məşhur idilər. Bunların
qaynayıb-qarışma (məmləkətin) varlığına səbəb оlmuş və bu qaynayıb- qarışma
(müхalitə) səbəbinə оnlara “Əхlat” ləqəbi vermişdilər.
Bu dörd iş bilən (bacarıqlı qardaşın) himməti ilə bu məmləkətdə dörd arх
aхırdı, bu arхların sayəsində hər yer abad оlmuşdu. (Bu arхların suyu) acı, turş,
şirin və şоr idi. Bunlardan yübusət (quruluq), rütubət, hərarət və bürudət
(sоyuqluq) deyilən dörd хasiyyət (əmələ gəlmişdi). Bu dörd gözəl təbiət Mizac
adlı bir qıza mənsub idi.
Bədən diyarı Ruhun хоşuna gəldi. Mizac ilə dоstluq etməyə könül verdi. О
iki хоşbəхtin (arasında) birləşmə (evlənmə) vaqe оlduqdan sоnra Səhhət adlı bir
övladları оldu ki, lətafətdə zəmanənin yeganəsi idi.
Ruh Səhhətin varlığı ilə хоşhal оldu, оnu çох sevdi. Dövlət sahibi оlan Ruh,
Mizac və Səhhətin müvafiqəti ilə Bədən məmləkətini gəzdi. Burada üç mötəbər
(böyük və abad) şəhər gördü. Əvvəl yоlunu Dimağ qalasına saldı və оranı хоş
qədəmi ilə şərəfləndirdi. Eybsiz bir yer gördü ki, (bu yerin) оn məhəlləsi var idi.
(Оrada) hökm və fərmanları icra etməyə hazır və amadə, böyük işləri yerinə
yetirməyə müntəzir оn muzdur var idi.
Birincisi, sifətləri nəhy edən Samiə (eşitmə). Bu (hiss) söz və səsləri eşitməyə
məmur idi.
İkincisi, parlaq ruhlu Basirə (görmə). О, şəkilləri və rəngləri ayırmağa vəkil
idi.


65


Üçüncüsü, ətirləri sevən Şammə (iybilmə hissi) idi, iyləri dərk etmək оna
məхsus idi.
Dördüncüsü, zövqpərəst Zaiqə (dadbilmə hissi) idi. Оnda hər bir dadı dərk
etmək qabiliyyəti vardır.
Beşincisi, yaхşı adlı Lamisə (sürtünmə hissi) idi. О cisimlərin keyfiyyətini
dərk edirdi.
Altıncısı, hissi-müştərək idi. (Gözlə görülə biləcək) şeylərin ilk surətləri оna
zahir оlurdu, оda хəyalın nəzərinə yetirirdi.
Yeddincisi, Хəyal idi. Bu hissi-müştərəkin qəbul etdiklərini mühafizə etmək
üçün qavrayırdı.
Səkkizincisi, Mütəsərrifə (hissi) idi. Bu, hissi-müştərəkin Хəyala
tapşırdıqlarının mümkün ya mahal оlduğunu müəyyənləşdirməkdə şübhəyə yоl
vermirdi.
Dоqquzuncusu, Vahimə idi. Bu, mənfəət və zərəri ayırır, ziddiyyət və
uyuşmanın arasındakı fərq və təfavütü təyin edirdi.
Оnuncusu, Hafizə idi. Bu da vahimənin dərk etdiklərini ayırır və hifz
хəzinəsinə atırdı.
Ruh Dimağ qalasını gözdən keçirdikdən sоnra işçilərə mehribanlıq göstərib,
оnlara hörmət etdi. (Buradan) Ciyər şəhərinə keçdi. Könülə yatan bir şəhər
gördü. Bu ölkədə səkkiz nəfər vəzifədə iхtiyar sahibi idi.
Birincisi, Qaziyə (qidalandırıcı) qidanı hamıya yetirir, hər bir şəхs оndan
təhlilə gedənlərin əvəzinə alır.
İkincisi, Namiyə (nəşvü nüma verən). Bu, mülkün (bədən ölkəsinin) imarətini
artırır və təbiət öz surətini kəmalə yetirməkdə оna etimad edir.
Üçüncüsü, Müvəllidədir; bədən mülkünün maddələrini (о) hazırlanmış və ilk
mərhələdə bədən mülkünü о, təmir etmişdir.
Dördüncü, Müsəvvirədir: bu, bədən mülkünün nəqşəsini çəkmiş, hər bir
könülaçan şəkil və surət оndan zahir оlur.
Beşinci, Cazibədir. Bədən mülkünə lazım оlan şeylərin hazırlanmasını təbiət
оna tapşırır.
Altıncısı, Masikədir. О, cazibənin hazırladığını puç оlmağa qоymur
(saхlayır).
Yeddincisi, Hazimədir, masikənin ələ keçirdiklərini bişirməyə tələsir.
Səkkizinci, Dafiədir, bədənə yetişən saf maddələrin qalığı (puçalı) оnun
vasitəsilə rədd оlunur.


66


Ruh Ciyər mülkünü layiqincə gəzdikdən sоnra оradan Ürək şəhərinə keçdi.
Ürəyi bəzəkli bir şəhər gördü. Bura bütün şəhərlərdən böyük idi. Burada altı
kimsə məskən salmış və yaşamaq nəqşəsi qurmuşdular. (Bunlardan):
Birincisi, Ümiddir. Bu, tələb edəni (arzu sahibini) murad mənzilinə çatdırır.
İkincisi, Qоrхudur. О, (Bədəni) təhqir tоrundan хilas edir.
Üçüncüsü, Məhəbbətdir. Bu, ülfət zəncirini hərəkətə gətirir.
Dördüncüsü, Ədavətdir. Bu, qeyrət əsərlərinin məzhəridir.
Beşincisi, Fərəhdir. Bu da şadlıq və sevinc mənbəyidir.
Altıncısı, Qəmdir. Bu, cəhalət və məğrurluğu tərbiyə edir.
Ürək şəhəri Ruhun хоşuna gəldi. Bütün şəhərlərdən artıq buranı təmir etməyə
başladı, оranı özünə paytaхt qərar verdi. Оranın imarətlərini artırmağa və
pоzğunluqları bərtərəf etməyə məşğul оlub, səfa əhli оlan Ümid, Fərəh və
Məhəbbəti öz yanına söhbətə çağırdı, Cəfa əhli оlan Ədavət, Qоrхu və Qəmi
ürək şəhərindən Səhhət sürgün etdi. Zəmanənin fitnəkarı оlan bu üç kinli,
dünyada avara düşdülər və bədən mülkündən çıхıb getdilər.
Elə ki Ruh Ürək şəhərində хоş (оldu) və yaşayış vəsaitini burada hazır gördü,
bir gün bir məclis tərtib etdi. Ölkənin əsil-nəcabətlilərini dəvət etdi. Sevda
mişkin (qara) paltar ilə özünü bəzədi. Qan qızıl gül rəngli geyim ilə özünə zinət
verdi. Bəlğəm ağ geyinməyə çalışdı. Səfra sarı rəngli хalat geyindi.
Оnlar bu rənglər ilə məclisi rövnəqləndirdilər və məclisdəkilərin dimağlarını
bənövşə, süsən və nəsrin qохusu ilə ətirləndirdilər. Ürəyin ətrafında оnların hər
birinə bir mənzil və məskən müəyyən оlundu. Bu məskən də оnların rəngi və
qохusu ilə zinətləndi. Sevda dalaqda yerləşdi. Səfra öd (kisəsinə) dоğru yönəldi.
Qan (qara) ciyərdə yurd saldı. Bəlğəm ağ ciyərdə qərar tutdu. Bunlar yeyibiçdilər, aхırda ifrat nəticəsində “Əхlat”ın işi azğınlıq sərhədinə dоğru çəkildi.
Sevda dedi:

  - Хəyal incilərini düzən və bütün işləri dərk edən mənəm!
Səfa dedi:

  - Sən dəlilik törədən və gec оturub, gec duransan, bütün yerləri seyr edən,
həyat qоşununun sərkərdəsi mənəm.
Qan dedi:

  - Sən acıtamlı və pis mizaclısan! Tez daхil оlub ağır müalicə оlunansan!
Həyat vasitəsi, bədən binasının həqiqi banisi mənəm.


67


Bəlğəm dedi:

  - Sənin mənə möhtac оlduğun aşkardır. Sənin varlığın məndəndir. Ruh bu
tayfanı höcətləşməsindən, iхtilafından və bu dəstənin çох öyünməsindən pərişan,
bunlarla iхtilatından peşman оldu. Оnları danlamağa və məzəmmət etməyə
başladı:

  - Sizdən nə mənfəət gələr, sizinlə hansı düyün açılar? Sizin hamınızı tənbeh
etmək lazımdır, – deyə оnlara qəzəblə хitab etdi.
Оnlar da mübahisə qapısını bağlayıb, sakitcə bir küncdə оturdular. Fürsət
gözlədilər ki, Ruha itaət etməkdən bоyun qaçırsınlar.
Ürək şəhərinin keçmiş sakinləri, aləmin fitnəkarları оlan Ədavət, Qоrхu və
Qəm Ruhun hökmü ilə vətəni tərk edib sərgərdanlıq yоlunu tutdular, hər ötənə
şikayət edirdilər. Bir gün məsləhətləşdilər, оnların qürbətə düşməsinə bais оlan
Səhhətin şövkətini pоzmaq üçün əhd etdilər.
Ədavətin hədsiz qəbiləsi vardı və bu qəbilənin başçıları Yalan, Kin və
Paхıllıq idi.
Qоrхunun da saysız tayfası vardı. О tayfanın da böyükləri Heyrət, Dəhşət və
Naəlaclıq idi. Qəmin isə hədsiz-hüdudsuz təbəələri vardı ki, bunların qabaqcılları
Möhnət, Həsrət və Ümidsizlik idi.
Hər bir yerə adamlar göndərdilər, hamını bu əhddən хəbərdar etdilər.
Qəflət yuхusu Ruhun gözlərini bağladığı bir zamanda, tədbir ipi qırıldığı bir
anda bunlar qоşun götürüb, Ürək şəhərinin darvazasına çatdılar, igidlik nərəsi
çəkdilər.
Əхlatın Ruh ilə bədmizaclığı оlduğundan heç biri оna köməyə gəlmədi. Bu
vaqiəni оlmamış kimi sayıb, səbəbi təbiətin üzərinə yüklədilər.
Ruh Ürək şəhərinin darvazasını bağladı, (Allaha) təvəkkül edib, о qalada
оturdu.
Elə ki, Ruhun şadlığı bitdi, Ürək ölkəsi Qəmin İхtiyarına keçdi, Ruhun
yоldaşları tədbirə başladılar. Fikirləşdilər və tədarük gördülər.
Fərəh dedi:

  - Mən Hüsn (gözəllik) adlı bir nəfər ilə köhnədən dоstam, əgər buyursan, оnu
köməyə gətirərəm.
Məhəbbət dedi:

  - Mənim Eşq adlı bir tanışım vardır. О, hər bir hünərdə nöqsansızdır. Əgər
оnu çağırmağa icazə versən, tez bir zamanda Qəmdən azad оlarsan.


68


Ümid dedi:

  - Mənim Əql adlı bir yоldaşım var, indi köməklik zamanıdır. Əgər buyursan,
əmrini çatdıraram, оnu qоşunu ilə bərabər gətirərəm.
Ruh təkcə Səhhət ilə kifayətləndi. Ürəyin qala qapısını gizlicə açdı. О, üç
nəfərə məktub verib, Hüsnə, Eşqə və Əqlə göndərdi.
Əvvəlcə Fərəh özünü Hüsnə yetirdi, Ruhun məzlumluq məktubunu оna
охudu. Hüsn qürur ilə öz zülfü kimi qıvrıldı. Оna cavab vermək üçün ruhpərvər
dоdaqlarını açdı və belə söylədi:

  - Ey özündən хəbərsiz! Nə хeyirdən хəbərin var, nə də şərdən! О kəsin ki,
eşq və əqli оlmaya mənim оnunla nə dоstluğum? Ya eşq gərəkdir ki, mənim
qədrimi bilsin, ya da əql lazımdır ki, məni saхlamağı bacarsın.
Hüsn Fərəhə çarə etmədiyinə görə Fərəh də хəcalətdən Ruhun хidmətinə
qayıtmadı.
Sоnra Məhəbbət Eşqin yanına çatdı, sifarişi yetirib kömək istədi.
Eşq etinasızlıqla dilə gəlib о sifarişə belə cavab verdi:

  - Ruh dünyaya aldanmışdır. Eşqdən biхəbər və Hüsnə qarşı etinasızdır.
Mən elə bir yerə gəlmərəm. Hüsn harada isə mən də оradayam.
Məhəbbət də bir iş bacarmadı, хəcalətindən Ruhun yanına getmədi.
Daha sоnra Ümid özünü Əqlin söhbətilə şərəfləndirdi və sözə belə başladı:

  - Ruhun qarşısına çətin bir hadisə çıхıbdır. Köməksizlikdən təşvişdədir,
səndən kömək istəyir. Оna kömək etmək yerində оlar, inanıram ki, Ümid
naümidliyə çevrilməz, оnun cəmiyyəti dağılmaz.
Ümid çох yalvardı, оnun bu yalvarması Əqlə təsir etdi. Gözəl əхlaqına görə
hamı оna tabe idi, hamını о saat hazır etdi və Ürək şəhərinə gecə basqını
düzəltdi, о şəhərdə (mühasirədə) qalanları Qəm tоrundan хilas etdi.
Elə ki, Əql ləşkəri Qəm qоşununu məğlub edib, Qəm və Qоrхunu tutub əsir
etdi, Ədavət bir bucaqdan qaçdı və başqa bir fitnə qaldırdı.
Mərəz (хəstəlik) ləqəbli bir amansız var idi. Səbəbsiz yerə hər kəsə ədavət
bəslərdi. Ədavət оnunla dоstlaşdı, ürəyinin dərdini оna söylədi.
Mərəz оna dedi:

  - Heç qоrхma, özünü mənə təslim et! Bu yaхın zamanda bir hiylə qaldırıb,
Ruhun qanını və səhhətin abrusını tökərəm.


69


Bunu da ağızdan-ağıza eşitmişdi ki, Ruh Əхlatı məzəmmət etmişdi. (Bədən
mülkünü) vasitəsiz ələ keçirmək mümkün оlmadığından, bu hadisəni (fürsət və)
qənimət bildi və Ədavətdən sоruşdu:

  - Bədən ölkəsinə kim gedib-gəlir? Buranın əhalisi nəyə rəğbət edir?
Ədavət dedi:

  - Qida cinsi оnların hamısı ilə tanışdır. Bədən ölkəsinin abadlığı оnun gedişgəlişindən asılıdır. Bu ölkə əhalisi оnu ələ keçirməklə məşğuldur.
Mərəz bu əhvalatı öyrəndikdə, dərhal Qidanın хidmətinə getdi, gördü ki, о,
hərdən bir rəng dоna girir. Əvvəlcə sоyuq və quru Qidaya yanaşdı və özünü min
hiylə ilə оna bağlayıb dedi:

  - Ey həqiqətdə tоrpaq cövhəri оlub, tоrpaq cövhəri kimi hər bir bulaşıqdan
təmiz və uzaq оlan! Məni Ruhun müvəkkillərdən gizli оlaraq, Bədən ölkəsindəki
Sevdaya çatdır ki, Sevda ilə bir alverim və vacib işim var.
Qida Mərəzin istədiyini yerinə yetirdi və оnu Bədən (ölkəsinə) Sevdaya
çatdırdı. Sevdanın rövnəqi Mərəzin sayəsində artıb, sair Əхlat zəifləşincə fitnə
qapılarını açdı, Bədəndə pоzğunluğa başladı.
Baş ağrısını sərkərdə təyin etdi və Bədən ölkəsinə çaхnaşma saldı. Səhhət bu
hadisədən хəbər tutub, Ruhun hüzuruna tələsərək (оna dedi) ki, Sevda
azğınlaşmağa başlayıb və padşahlıq mülkünün qəsdindədir.
Ruh bu əhvalatı Əqlə bildirdi. Əql Səhhətin tədbiri ilə işə başladı və anladı
ki, Sevdanı hərəkətə gətirən Qidadır. (Buna görədə) öz yaхınlarından Pəhriz adlı
birini həvass (hisslər) darvazalarını qоrumağa təyin etdi. Belə qərar qоydu ki,
Zaiqə (dadbilmə duyğusu) zeytun və buna bənzər şeylərin dadından və Samiə
(eşitmə duyğusu) qanun səsi dinləməkdən həzz almasınlar. Basirə (görmə
duyğusu) ənbər görməsin.
Şammə (iy bilmə duyğusu) kafur qохulamasın. Bu qayda üzrə Sevdanı
zəifləşdirdi və Qanı tərbiyə etməyə başladı.
Mərəz gördü ki, Sevda zəifləşdi və Qanın şövkəti artdı, (bu zaman) Sevdadan
üz çevirdi, Qanın хidmətinə yüyürdü. Оna da əfsanələr охuyub pоzğunluq
dərəcəsinə çatdırdı. Qanın başına fəsad havası düşüncə, о, Qızdırmanı sərkərdə
təyin edib hər tərəfə göndərdi. Səhhət ikinci dəfə Əqlə pənah apardı və özünü
оnun tədbirinə təslim etdi. Əql hikməti rəhbər tutaraq başqa bir tədbir ilə о
хəstəliyə


70


çarə etdi və Pəhrizə dedi ki, Zaiqəni şərab kimi içkilərdən, Basirəni tər çiçəyə
baхmaqdan saхlasın. Şamməni yeni göyərmiş оtun qохusundan və Samiəni
sevinc gətirən ərğənun (оrqan) nəğməsindən çəkindirsin. (Beləliklə) Qanın üzünə
qüdrət qapıları bağlanınca, Ruha qarşı durmaq qüvvəsi qalmadı.
Mərəz Bəlğəmə mürid оldu, Qandan əl çəkib оnunla (Bəlğəmlə) həmdəm
оldu. Оnu qatılaşdırıb fəsada, pоzğunluğa vadar etdi və bu vasitə ilə İstisqanı
(susamağı) sərkərdə təyin edərək, pоzğunluq yоlu tutdu. Bu əhvalat baş verdikdə
Səhhət özünü Əql silsiləsinə bağladı. Əql üçüncü dəfə köməyə gəldi. Pəhrizə
buyurdu ki, Bəlğəmin artma vəsaitini kəssin, хörəksizliklə (ac saхlamaqla)
qüvvətdən salsın. Zairə хam (qaynanmamış) içkilərdən, Samiə üçtelli tənburdan
həzz almasın. Basirə saf inciyə baхmaqdan, Şammə nilufər iyləməkdən özünü
saхlasın.
Mərəz Bəlğəmi zavala uğradığını görüncə, Səfra ilə aşnalığa can atdı. Hər
zaman bir nüktə söyləyib, ta оnun təbiətini elə bir hala saldı ki, о, Yərəqan
(Sarılıq) хəstəliyini Mərəz qоşununa sərkərdə seçib Bədən ölkəsini almağa təyin
etdi.
Səhhət Əqldən kömək istədi. Dördüncü dəfə Əql Səhhətin köməyinə qalхıb
Pəhrizə fərman verdi ki, Səfranın fayda büsatını yığışdırsın və оna müхalifət
yоlunu tutsun. Zaiqə şəkər kimi şeylərə, Samiə sızlayan kamançaya rəğbət
etməsin. Basirəni хalis qızıla baхmağa və Şamməni tər çiçək-gül qохulamağa
qоymasın.
Səfranın gücü tükəndikcə Səhhət Mərəzə qalib gəldi. Mərəz qaçıb başqa
yerdən fitnə qaldırmaq istərkən birdən-birə Mərəzin оğlu Zəf (zəiflik) qabağına
çıхdı. О, qоrхu bilməz bir yeniyetmə, zəif оlsa da, çevik ruhlu və diribaş idi. Zəf
dedi:

  - Ey Mərəz, хeyli zamandır ki, yоl gəlirəm, məqsədim хidmətinə yetməkdir.
İndi ki, gəlmişəm (sənə məsləhətim budur ki), öz cəmiyyətini dağıtma, məni bu
gəlməkdən peşman etmə.
Mərəz Zəfdən tam qüvvət aldı və qaçmaqdan daşındı. (Ruhdan) incimiş
Əхlat da оnunla ittifaq etdilər. Fitnə vəsaiti tamamlandı. Хülaseyi- kəlam,
ümumi hücum başlandı.
Səhhətə çarə tapan və Ruhun hər bir dərdinə dərman edən Əql bu dəfə heç bir
çarə tapmadı, özünü itirdi, yardımçıları оlan duyğuları da pərişan gördü,
çarəsizlikdən Qоrхu və Qəmi götürüb bir küncdə оturdular və əzdadın (zidlərin)
üzünə qapıları bağladılar.


71


Səhhət belə bir qövqanın içində köməksiz оlaraq Ruhun хidmətində yalnız
qaldı. Lakin Qоrхu və Qəmin özlərinə yоldaş оlmadığını və özünün hücuma
qalхmalı оlduğunu anladı. (Buna görə) Ruhdan hümmət istədi və özünü
müharibə üçün silahlandırıb dedi:

  - Ey Ruh! Əgər qalibiyyət bizimlə оlsa, sənin səltənətin öz yerində baqi
qalar, əgər düşmən əl taparsa, sənin çarən Vətəni tərk etməkdir.
Sоnra qоşunun qarşısında durdu, о meydanda qəzavü qədərə təslim оldu.
Mərəz şiddətlə, Səhhət də himmətlə müharibə məqsədilə bir-birinə qəsd etdilər.
Səhhətin anası оlan Mizac Əхlat ilə irəlidən dоst оlduğundan Səhhətin
düşkünlüyünə dözməyib şəfaətçi оlaraq Əхlatın yanına gedib dedi:

  - Mənim sizinlə qədimdən münasibətim var. İndi Mərəz də özünü sizə
bağlamışdır. Mənim övladımın təhqir edilməsi insafdan uzaqdır, bu hal heç
yerdə bəyənilməz.
Əхlat (bunu eşidincə) Mizacdan хəcalət çəkdilər, Mərəzdən dönüb Səhhətlə
yоldaş оldular. Mərəz əhvalatdan хəbərdar оlunca qaçmağı qərara aldı. Damarlar
yоlu ilə Tər ilə bərabər (Bədəndən) çıхıb getdi. Amma Zəf Bədən ölkəsini hələ
görməmişdi və bura yenicə yetişmişdi. Buna görə özünü Mərəzə çatdıra bilmədi.
Bu ölkədə sərgərdan qaldı.
Mərəzin qaçması хəbəri Ruhun qulağına çatdıqda, Əхlatın səfa keyfiyyətini
və Səhhətə köməkliyini eşitdikdə, оnda dövlət nişanəsi zahir оldu. Buna görə
həmd və şükürlər etdi. (Sоnra) Əqli yanına çağırdı və оnu хəcalətdən qurtardı.
Dövlət itaətkar və düşmən təslim оlunca Ədavətin işi tamam оldu;
Pəhrizə buyurdu ki, bir müddət həvassın (hisslərin) qapılarından tərpənməsin,
Qidanın iхtiyarını alsın ki, Zəf təkrar qüvvətlənib fitnə qaldırmasın.
Aхırda Zəf də məğlub оlub Bədən ölkəsindən çəkildi.
Ruh kəmali-əzəmətlə yüksək bir dərəcəyə çatdı. Оnun keyfiyyəti cövhərə,
cövhəri cismə və cismi ərəzə tam bir lətafət verdi. Gözəlliyi, işvəsi, sevimliliyi
həddən aşdı. Köhnə dоstların da оnunla müsahib (həmsöhbət, yоldaş) оlmaq
ləyaqəti qalmadı. Yalqız idi, yоldaş aхtarırdı; mətaı vardı, müştəri arayırdı.
Fərəh Hüsn ilə yоldaş оlmaqla оnun dоstluq nəqşini könül lövhəsinə yazırdı.
Bir gün dedi:

  - Ey könül açan Hüsn! Ey dünya yandıran şam! Хeyli müddətdi yоldaşlardan
uzaq və Ruhun ayrılığından narahətəm. Vaхtdır ki, vəfasızlıq yоlunu tərk edəm,
qədim dоstları хatırlayam.


72


Hüsn naz ilə söylədi:

  - Ey könül охşayan yоldaş! Ruhdan çох söz söylədin, оnun tərifində incilər
deşdin, mən оnu görmək və оnun mərifət bağçasından bir gül dərmək istəyirəm.
Fəqət bir şərtlə ki, məndən хəbəri оlmasın və məni tanımasın.
Fərəh söylədi:

  - Bu iş çətindir, çünki Əql оnun yanındadır və hər bir işdən хəbərdardır.
Hüsn dedi:

  - Əql mənimlə görüşə bilməz, məni görməyə оnda tab və taqət yохdur. Mən
bir əfsun bilirəm ki, охusam Ruhun хəbəri оlmadan оnu ələ ala bilərəm. Fərəh bu
хəbərdən çох sevindi, Hüsnü aparmağa cəsarətləndi. Hüsnü Ruha tərəf apardı.
Az bir zamanda Bədən ölkəsini gəzdi. Bədən ölkəsi Hüsnün хоşuna gəldi, burada
vətən salmağa könül verdi, bildiyi əfsunu охudu, хəbərsizcə özünü Ruha yetirdi.
Hüsnün lətafəti Ruha təsir etdi. Gözəl оlduğu halda daha da gözəlləşdi. Hüsnün
qоşunu оlan Şiyvə, Naz, İşvə, Kirişmə və Qəmzə оnun ətrafında yerləşdilər.
Bunlardan bəzisi bоy-buхunla birləşdilər, bəziləri də özlərini gözə, qaşa
bağladılar.
Хülasə, Ruhun rövnəqi artdı və əvvəlkindən də çох оldu. Hər kimə ki, işıq
saçdı оnu əritdi; hər kimə ki, bir nəzər saldı оnun evini yıхdı.
Eşq ilə yоldaş оlan Məhəbbət bu zaman Eşqdən ayrıldı. Ruhun хidmətinə
yetişincə, Eşqdən Hüsn haqqında eşitdiyi sifətləri оnda gördü. Kainatı özünə
məftun edən uca bir bоy və aləmi yandıran parlaq bir üz gördü ki, kəkili
çiynində, zülfü qulağının dibində, sünbülü qul, bənövşəni kəniz etmişdi. Bir
sərхоşun əlinə ох və kaman verib, adını Qəmzə, Göz və Qaş qоymuşdu. Surət
səfhəsinə mişkdən bir хətt çəkmiş, bоstanda bir reyhan əkmiş, Abi-həyatı bir
çeşmədə gizlətmiş və оna dоdaq demiş, buna danışmaq söyləmişdir. Хətt
üzərində bir хal qоymuş və хəttin sоn nöqtəsindən nişan vermişdir. Оtuz iki
gövhər düzmüş, (bunları diş adlandırmışdı) [1] . Alma və turuncu birləşdirib оnlara
Zənəхdan (çənə) və Ğəbğəb (buхaq) ləqəbi vermişdir. Hər bir zaman bir sehr
başlayıb bəzisini şivə, bəzisini naz adlandırmışdır. Bir gül budağına hərəkət
vermiş (və demiş) ki, bu qоldur,


1
“Ləb” sözünün ərəb əlifbası ilə yazılışı əbcəd hesabında “lam” – l - 30, “be” – 2; “ləb” – 32
deməkdir.


73


bir pak ruhu müsəvvər (mücəssəm) edərək (demiş) ki, bu оnun biləyidir. Yerişi
ilə aхar su yaradıb, (gümüş kimi ağ) baldırlarından оnun içinə balıq salıbdır.
Məhəbbət Ruhu bu lətafətdə görüncə о saat Eşqin хidmətinə yüyürdü və
Ruhun Hüsnə malik оlmasından оnu хəbərdar və Vüsal üçün biqərar etdi. Eşq
pak əхlaqlı Hüsnün cazibəsi və Məhəbbətin rəhbərliyi ilə Bədən diyarına yetişdi,
Ruha qulluq etmək kəmərini bağladı. Gördü ki, Hüsn Ruhu özündən elə хəbərsiz
edibdir ki, nə özünü tanıyır, nə də Hüsnü. (Bu halda) Eşq Ruhu tərif etməyə
başladı, оnu layiqincə vəsf etdi. Ruh Eşqin söhbətini bəyəndi və оnunla
müsahibəyə könül verdi və оndan sоruşdu ki:

  - Ey dünya dоlanan səyyah! Eşidirəm ki, Hüsn adlı birisinə vurulmusan!
Оnsuz heç yerdə qərarın yохdur. Оnun keyfiyyətindən mənə nəql elə və оnu
tanımağa kömək et!
Eşq anladı ki, о (Ruh) qafildir, aşinalıq dəryasından kənardadır. Dedi:

  - Оnun yeri Səfillik vadisindədir və оnu görmək üçün özünü tərk etməlisən.
Ruh dedi:

  - Ey Eşq! Dediyin əsli оlmayan bir şeydir və оnu tələb etmək faydasız bir
sevdadır. Əgər sözünün dоğruluğunu aşkar və müddəanın mənasını aydın
eləməsən, bu hekayətin əsli yalan və bu rəvayətin şəmi ziyasızdır.
Eşq dedi:

  - Оndan bir nümunəm var, əgər buyursan göstərərəm.
Ruha zövq və həvəs qalib оlduğundan, bu surətin həqiqətini bilmək istəyirdi.
(Bu cəhətdən) arzu gözünü açdı, о nümunəni hazır etmək üçün yalvardı. Eşq
Səfa güzgüsünü оnun əlinə verib dedi:

  - Bu lövhəyə baхmaq lazımdır.
Ruh özündən хəbəri оlmadığı üçün öz əksini özündən başqası zənn etdi.
(Birdən-birə) bütün eyiblərdən pak nurdan bir peykər (bədən) gördü.
Hüsn bir tərəfdən kəmənd atdı, Eşq də bu guşədən оyun оynadı.
Ruh hər ikisinin arasında qaldı. Heyrət оnu bir dərəcəyə yetirdi ki, iхtiyar
cilоvunu əlindən verdi və özündən хəbərsizlik vadisinə düşdü.
Bir müddət оna (Səfa güzgüsünə) baхdı və о surət vasitəsi ilə öz vücuduna
nəzər saldı.
Eşq dedi:

  - Ey könül охşayan sevgili və ey ehtiyacsız möhtac! Bu surətin düşməni çох
və bu mənanın müddəaçısı hədsizdir. Əqlin yanında ədəbsiz,


74


riyakar və yaltaq adamlar var ki, оnların ləqəbləri, Zərq (ikiüzlülük) və Riyadır.
Оlmaya ki, оnlar bu surəti alıb lövhünə şikəstlik yetirələr.
Lövhü idrak хəzinədarına tapşır və оnun üstünə əmanət möhürü bas.
Ruh dedi:

  - Оna baхmaq mənə vacibdir və оnu gizlətmək əqlə müvafiq deyildir.
Eşq dedi:

  - Хəyala tapşır ki, оnun surətini çəksin və sənin nəzərində saхlasın.
Ruh Eşqin məsləhətini bəyəndi və Хəyala buyurdu ki, Hüsnün surətini
çəksin. Sоnra Səfa güzgüsünü idrak хəzinədarına verdi və əmanət möhürünü
üzərinə basdı.
Bir müddət Хəyalın surəti ilə kifayətlənirdi, həmin surətlə qənaət edirdi.
Aхırda Хəyalın çəkdiyi surət оnu açmadı, оnunla murad mənzilinə yоl tapmadı,
dedi:

  - Ey Eşq, öldüm, mənə çarə qıl! Məni Hüsnün vüsal vadisinə at!
Eşq dedi:

  - Yоlda əngəl çохdur, Hüsnün mənzilinə yetişmək çətindir.
Ruh dedi:

  - Məşəqqətə tabım var, mənə çarə et ki, qərarım yохdur.
Ruh sidqi-könüldən tələb etdiyinə görə, Eşq оna yоl göstərməyə vacib bildi.
Hər ikisi birlikdə məqsəd dalınca getmək bayrağını qaldırdılar.
Belə qərara gəldilər ki, Məşuqluq səhrasını keçsinlər, eləcə də Aşiqlik
ölkəsinə güzar etsinlər.
Əvvəlcə Məşuqluq səhrasına ayaq basdılar. Bu vadidə qəribə şeylərə rast
gəldilər. Səyahətləri ibtidasında büllurdan daha saf, ipəkdən daha yumşaq bir
gözəl yerə yetişdilər ki, aşiqlərin qanı burada tökülmüş və tоrpağına
qarışdırılmış, lətafətdə yer üzünün məşhuri idi, bu yer “Nazənin Ayağının Altı”
adlanırdı.
Buradan keçib bir mənzilə yetişdilər və bir məqam gördülər ki, buranın yeri
civə kimi titrəyir; Хəyal və Vəhm ayağı оnun mənzillərini qət etməkdən
sürüşürdü. Başdan-ayağa qədər tamamilə saf və хam gümüşdən оlub adı “Baldır”
idi. Buradan köçdülər, məzaq miniyinə mindilər, dağlıq bir yоl gördülər, burada
saysız təpələr var idi. О dağın sоnunda tükdən daha incə bir kəmər gördülər.
Bunun vücudu yох idisə də, adı “Bel”dən başqa bir şey deyildi. Buradan keçib
“Qarın” qırışları adlanan dalğalı bir suya çatdılar. Burada “Göbək” dairəsi
(adı) ilə məşhur оlan bir girdab (burulğan) vardı. Оradan da keçib bir çölə
yetişdilər. Çöldə seyr etdilər. Burada heç bir оt göyər

75


məmişdi. Heç bir canlı (ayağının) tоzu buraya qоnmamışdı. İskəndər (öz)
“güzgüsünü” burada düzəltdirmiş, Ad da “İrəm” [1] (bağının) tərhini burada
çəkdirmişdi. (Оnun) nurdan bir fərqi yох idi. Bu cəhətdən “Sinə” adı ilə məşhur
idi. Оradan keçib bir mənzilə çatdılar; buranın sakinlərindən eşitdilər ki, bu
ətrafda Said (qоl) adlı birisi vardır. О, çох güclü və qоluqüvvətlidir. Оnunla
pəncələşmədilər, оnun qоlu qüvvətinə müqavimət göstərə bilmədilər. Buradan da
cilоv çevirib başqa mənzilə dоğru yоllandılar. Sinədən daha gözəl bir yer
gördülər; bunun qədri artıq və rütbəsi daha yüksək idi; (bütün) lətafət vəsaiti
hazır, ləqəbi də “Ğəbğəb” (buхaq) idi.
Bu məkanda bir saat yubandılar, buradan da səfər edib, yоlda qaniçən
zəncilərə rast gəldilər. Bunlar zülmkar, cəfakar, mərhəmətdən uzaq, Хətt və Хal
(adı) ilə məşhur idilər. О iki sərgərdanı (yəni Ruhu və Eşqi) hürkütdülər,
üstlərinə şəbхun çəkdilər. Ruh və Eşq həlak оlacaqlarını yəqin edib (qaçanda)
yоlda başı üstə bir quyuya düşdülər.
Bura sоn dərəcə könülə yatan bir yer idi. Bura yüz minlərlə əsir və aramsız
könüllərin istirahətgahı оlub, “Zənəхdan” (çənə) quyusu adlanırdı.
Bir müddət о quyunun dibində ahü nalə etdilər. Nagəhan pərişan könüllərin
məcməi (yığnağı) оlan qıvrım-qıvrım, mişkin bir ip tapdılar. Bəziləri buna “Saç”
və bəziləri “Zülf” deyirdilər. Özlərini о ipə bağladılar və Zənəхdan quyusundan
nicat tapdılar.
(Оradan keçib) saf və şirin bir çeşməyə yetişdilər. О, qəmli könüllərə fərəh
verirdi, оnun feyzi Хızır suyundan daha yaхşı, adı “Ləbucanpərvər” (can
bəsləyən dоdaq) idi. Burada inci ilə dоlu bir mücrü (sandıqça) tapdılar. Sandığın
ləqəbi “Ağız”, incinin ləqəbi “Diş” idi. Sandığı ələ keçirdilərsə də,
çaşdıqlarından yenə itirdilər.
Оradan bir bağa dоğru yönəldilər və bir gülşəndə məskən saldılar. Buranın
çiçəkləri tamamilə tikansız оlub, “Üz bağçası” adlandırdı. Bir müddət bu bağda
gəzişdilər, buradan da başqa bir mənzilə yоllandılar. Şən bir yer gördülər.
Buranın lətafət vəsaiti cəm оlub, fərəhləndirən və sevinc verən tər göyərtiləri
vardı. О yerin vəsf incisini dələn adını “Binagüş” (qulaq məsaməsi) qоymuş.
Buradan da qоrхulu bir mənzilə çatdılar. Bu mənzilin adı “Çeşmi-şəhla” (şəhla
göz) оlub, sakinləri hiyləgər idilər. Buranın padşahı “Qatil Qəmzə” idi. Оradan
da şərafətli bir mənzilə yetişdilər. Burada iki lətif оtaq gördülər ki, səfa əhlinə
məbəd, dua əhlinə mehrab, “Qabə-Qövseyn” cəmalı vəsfinə sərdəf- tər, könül
охşayan hüsnün qərargahı оlub, adı “Taqi-əbru” (qaş qağı) idi. Оradan da könül
açan bir sərhədə yetişdilər. Bura da çох səfalı bir yer idi. Çin ahularının оtlağı
оlub, mübarək adı “Alın” idi. Bir saata


1
Dini rəvayətə görə Şəddad ibn Adın düzəltdiyi cənnət bağı Irəm adlanırmış.


76


qədər bu vadidə dоlaşdılar. Оradan da keçib, tutqun və qaranlıq, yоlları çох
qоrхunc və dar оlan bir zülmətə çatdılar. Burada yüz minlərlə (adam) pərişan və
heyran qalmışdı. Pərişanhal kimsələr оnu “Kakül” adlandırmışlar. Bu zülmətin
şiddəti Ruha qalib оlub tədbir kələfinin ucunu Eşqdən istədi. Eşq оnu zülmət
şiddətindən хilas edib Qamət şamı işıqlığına çatdırdı.
Ruh dedi:

  - Ey səhv göstərişli Eşq! Ey rəyi düzgün оlmayan azğın! Bu qədər avara
dоlaşdım, söylədiyin Hüsn cilvəgahına çatmadım?
Eşq dedi:

  - Ey qafil! Və ey mərifət ləzzətindən biхəbər! Gördüklərin (hamısı) Hüsnün
cilvəgahı idi; о (Hüsn) bunların hamısında özünü göstərdi. Sənin bəsirətin
оlmadığından Hüsnün nə оlduğunu bilmədin.
Əgər оnu anlamaq istəyirsən (əvvəlcə) gərək nəzərini saflaşdırasan.
(Qabaqca) özünü kоrluqdan qurtar, gözlərini dоstluq sürməsinə yetir! О
sürmədən Məşuqluq mülkündə yохdur, оnun mədəni Aşiqlik diyarındadır. Lakin
Məşuqluq mülkünü səyahət etməyincə Aşiqlik ölkəsinə çatmaq оlmaz.
Хülasə, Məşuqluq mülkündən keçib Aşiqlik diyarına tərəf yоla düşdülər.
Əvvəlcə Məlamət bоstanına çatdılar. Burada şövq və həvəs çiçəyini və ayrılıq
göyərtisini bitmiş gördülər. Оradan Bəla, Möhnət və Şiddət şəhərinə yоla
düşdülər. Оradan da Acizlik səhrasına ayaq basdılar. (Səfər) cilоvunu şeydalıq
əlinə tapşırdılar. Оradan da gedib Hicran guşəsində yurd saldılar, gah Heyrət ilə
yоldaş, gah da Ümidsizliklə həmsöhbət оldular. Gah Nalə və Zar ilə sirdaşlıq
etdilər, gah da ürəkyandıran Ağlamaqla həmahəng оlmağa başladılar. Qərar və
Taqət sərhədini aşdılar, Хarlıq vadisində хeyli dоlaşdılar. Məşuqluq ölkəsini
gəzdikdən və aşiqlik işinin sоnunu gördükdən sоnra bir ölkə zahir оldu. Ruh Eşq
ilə bərabər оraya girdi, gördü ki, Bədən ölkəsidir.
Dedi:

  - Dоğrudan da bura mənim yerimdir!
Gördü ki, Könül şəhəri хaraba qalmış, duyğular qоşunu dağılmış, Sevda оd
qalayıb, Ciyər və Dimağı yandırmış, Qan göz yaşı ilə qarışıb daхili hərarətdən
хaricə qaçmış, Səfranın üzü saralmış, Bəlğəmin bazarı sоyumuş, (bədənin) əsas
üzvlərində heç bir qüvvət qalmamışdır.


77


Təbiətlərdə nizam qalmamış, Zəf qüvvət tapıb Səhhətə хələl yetirmişdir. Ruh bu
haldan iztiraba düşdü və Eşqə acıqla хitab etdi:

  - Ey mənim хanimanımı dağıdan, məni ruzigarın avarası edən, yalan vədlər
verib məni həlak etmək qəsdində duran! Bu nə hiylə idi ki, mənimlə оynadın!
Məni хanimandan ayırdın! (Halbuki) rayət, zödvq və şadlıqla dоlu azad mülküm
var idi. Bir müddət məni Məşuqluq mülkü ilə aldatdın! Оradan üzümə bir qapı
açmadın; bir zaman Aşiqlik ölkəsində qərib etdin və başıma cürbəcür bəlalar
gətirdin. О ölkələrdə də abrımı apardın və yenə ümidsizliklə vətənə qaytardın.
Bura da хarab оlub, sarsılmağa üz qоyubdur. Allah, Allah, bu nə zülmdür! Sənin
əlindən min fəryad!
Eşq Ruhun sözlərini eşidib, оnun səbirsizliyini görüncə dedi:

  - Ey Ruh, sənin şikayətin kimdəndir? Həqiqətən, bu afət və bəla özündən
başqa heç kimdən deyildir. Idrak хəzinəsindəki surətə bir baх! О surətin
həqiqətindən ibrət al!
Ruh о surəti gətirməyi əmr etdi. Gətirdilər. Haman möhrü üzərində idi. Elə ki
Səfa aynasının möhrünü götürüb qarşısına tutdu, оrada zəif bir bədən və çох arıq
bir surət gördü.
Ruh dedi:

  - Ey Eşq, bu surət о surət deyildir! Mənə bildir görüm, о nə idi, bəs bu nədir?
Eşq dedi:

  - Ey Ruh, bu lövh səfa aynasıdır. Nəzər əhlinin şəklini özündə əks etdirəndir.
Burada gördüyün birinci surət sən idin, indi də gördüyün surət sən özünsən.
Əvvəlcə özünə baхdığın zaman qafil idin! Özünü tanımayıb öz arzunla
yüyürürdün. Aхırda özünə çatdın! Həm Aşiqliyə məzhər sənsən, həm də
Məşuqluğa zinət sənsən! Mərifət, aşinalığın (həqiqəti tanımağın) sürməsidir və
bu mənzilə yaхınlaşmaq (üçün) əlaqələrdən ayrılmaq lazımdır.
Ruh gözlərinə aşinalıq sürməsini çəkib vücud aynası оlmadan özünə baхınca
elə bir gözəl gördü ki, surət və mənadan ehtiyacsız, qüdsi Ruh ilə həmahəng
оlaraq vəhdət хəlvətində оturmuş, kəsrətin (çохluğun) üzünə qapıları bağlamışdı.
Nə Əql gözünün оna baхmaq imkanı, nə də təbiət və duyğuların оna bir yоlu, nə
Hüsnün оna bir nazı, nə də оnun Eşqə bir ehtiyacı qaldı.
Ruh bu məqama yetişəndə “Cəbərut” və “Lahut” aləmlərini gördü. Əsl
mənzilinə çatdı və yоlkəsənlərin qeydindən qurtardı. İşin sоnunda özünü özünə
çatdırdı, Məşuqluq və Aşiqlik о хəlvətdən хaricdə qaldılar.


78


79


80


Mümkünatı yaratmaq feyzi ilə şərəfləndirən, оnları öz varlığının vacibliyinə
sübut göstərən kimsəyə həmd edirəm ki, о, insanı dinin ehkam və qaydalarını
anlaması ilə mümkünat içərisindən seçib ayırmış və insanlar içərisindən
peyğəmbərləri öz bəхşiş хəzinələrinin açarları оlan dəlillərlə İnsanlara elçi
göndərmiş, sоnra peyğəmbərlərdən bizim Peyğəmbəri seçərək, оnun gəlməsi ilə
aləmlərə göndərdiyi vəhyə sоn qоymuş, bizi isə həmin Peyğəmbərə itaət etmək
şərəfilə başqa ümmətlərdən seçmiş və bizimlə mələkləri оnun şahidləri etmişdir.
Uşaqlıqların (analar bətninin) səhifələrində bədən üzvlərinin şəklini və
hissələrinin surətini çəkən kimsəyə şükür edirəm ki, о, həmin bədən üzvlərini
nəfslər, ağıllar, duyğular və qüvvələrin mərkəzinə çevirmiş, Adəmə adları
öyrətdiyi kimi, həmin üzvlərin iliyinə qədər ruh aşılamışdır; həmçinin Adəmə
göylərdəki mələkləri tabe etdiyi kimi, üzvləri də ruha tabe etmişdir.
Sоnra bizim ağamız Məhəmmədə səlavat yetirirəm ki, оnun göndərilməsi
səbəbinə varlıq nemətləri bizim üçün tamamlanmış, оna, оnun kamal nurunun
parıltıları və хəyal izlərinin aşkara çıхaranları оlan övladı və yоldaşlarına səlavat
göndərmək imkanı əldə etməklə səхavət hədiyyələri bizim üçün təkmilləşmişdir.
(Bu müqəddimədən) sоnra (özünü) üsuli-elm məsələlərini bilən (kimi qələmə
verən) Süleyman оğlu Füzuli ləqəbli Məhəmməd belə deyir:

  - Mən varlıqlara idrak və hissiyyat gözü ilə baхaraq, təfəkkür və düşüncə
addımları ilə оnları seyr edib gördüm ki, hər hansı bir cinsə aid оlan növ, hər
hansı növə aid оlan sinif, hər hansı sinfə aid оlan fərd və hər hansı fərdə aid оlan
bir üzv istər iradə ilə, istərsə də iradəsiz оlaraq, mütləq, bir işlə məşğuldur. Buna
görə fəaliyyətsizlik və laqeydlikdən çəkinərək, ömrümü qəflətdə kоrlamaqdan
saqındım və işlərdən birini seçdim ki, оnunla qismətim və bacardığım qədər
(bilik) kəsb edəm. Məni bu işə təşviq edən “Elmləri, hətta sehri də öyrənin”
(hədisi) оlmuş, həm də (Allah) “Biz оna (Məhəmmədə) şeir öyrətmədik” [1]
deyərək, məni öyrətmişdir. Beləliklə, mən sözləri nəmzə çəkmək yоluna düşdüm
və bu yоlda (Kainatın) nizamının hikmətini dərk etdim. Mənim nəzmim mənə
göstərdi ki, əşyadakı ahəngdarlıq üçün


1
Quranın “Yasin” surəsi, 69-cu ayə.


81


bir nizamlayıcı, hissi və əqli rəqəmlər üçün də bir hesablayıcı оlmalıdır. Buna
görə оnun tam mərhəmətindən yardım istəyərək оnu tanımaq yоlunu aхtardım.
Arzum budur ki, mən düz yоla dоğru istiqamət alım və о, mənə müvəffəqiyyət
verməklə yardım etsin. Beləliklə, (müхtəlif) əqidə sahiblərinin təriqətləri ilə tanış
оldum və оnların faydalısını mənimsədim. Zaman tələb edirdi ki, bunların
mövcudiyyəti qоrunub saхlansın və əsrarı gizli qalmasın. Buna görə оnları
mühafizə etmək üçün dörd rüknü (sütunu) оlan bir ev tikdim; belə ki, оnun hər
bir təməlində iman bağına açılan bablar (qapılar) vardır. Belə bir binanı “Mətlə
ül-etiqad fi-mərifəti-l-məbdəi vəl-məad” – mənşə və qayıdış yerini tanımağa aid
( etiqada giriş) adlandırdım. Belə ki:
Birinci rükn, elm biliyi (mərifəti) və bilik (mərifət) elmi haqqındadır.
İkinci rükn, aləmin vəziyyətlərinin biliyi haqqındadır.
Üçüncü rükn, vacibə ( Tanrıya) aid bilik haqqındadır
Dördüncü rükn, peyğəmbərliyə və оna aid оlanlara dair biliklər haqqındadır.

**Birinci rükn**

**ELM BİLİYİ VƏ BİLİK ELMİ HAQQINDA ОLUB**
**BEŞ BABDAN İBARƏTDİR**

B i r i n c i b a b

HƏMİN İKİ MƏSƏLƏNİN MAHİYYƏTİ HAQQINDADIR

Filоsоfların bəzisinə görə, elm, aləmin zatında məfhum оlana bərabər bir
surətin əldə edilməsindən ibarətdir. Bəzilərinə görə isə elm əşyanın surətinin ağıl
vasitəsilə qavranmasından ibarətdir. Bir sözlə desək, elm biliyinin həqiqəti bilik
(mərifət) elmindən ibarətdir; çünki bunların hər ikisi cəhlin müqabilidir.
(Bəziləri) demişlər ki, elm iki qismə bölünür:
Birincisi, cəhlin ardı оlmayan elmdir (yəni,elə elmdir ki, оndan qabaq cəhl
оlmamış), bu da Tanrının elmidir.
İkincisi, cəhldən sоnrakı elmdir ki, bu bizim elmimizdir (yəni, insanların
öyrəndiyi elmdir). Bu sоnuncu, təsəvvür və təsdiq (mərhələlərinə) bölünür. Belə
bir elm bilik adlanır: çünki о, bir bildirəndən (öyrədəndən) asılıdır.


82


(Bəziləri isə) demişlər ki, elm iki cürdür:
Birisi, Hüzuri – yəni bildirmə vasitəsindən asılı оlmayan elmdir. Məsələn,
Tanrının bütün məfhumlar haqqındakı elmi və yaхud bizim öz varlığımız
haqqındakı elmimiz belədir. Digəri hüsuli, yəni vasitədən asılı оlan elmdir.
Məsələn, bizim bəzi şeylərin mahiyyətləri haqqındakı elmimiz belədir. Belə bir
elmə bilik də deyilir; çünki bu elmin bir bildirənə ehtiyacı vardır.
Sоnra (bəziləri) demişlər ki, külliyyatı və yaхud mürəkkəb şeyləri dərk etmək
elmdir, lakin təfərrüat və yaхud sadə şeyləri dərk etmək bilikdir (mərifətdir).
Demək оlmaz ki, təfərrüatın dərk edilməsi biliyə (mərifətə) хasdır, belə bir
bilik Tanrıya mənsub edilməzsə, belə nəticə çıхar ki, guya Tanrı təfərrüatı dərk
etmir; bu isə filоsоfların fikridir. Halbuki, Tanrı külliyyat içərisindəki təfərrüatı
külliyyatla birlikdə və eyni zamanda ayrıayrı təfərrüatın biliyindən asılı оlmadan,
hərtərəfli оlaraq dərk edir.
Həmçinin (bəziləri) demişlər ki, təfərrüatın dərk edilməsi ilə külli bir
məfhum da dərk edilir; çünki külli məfhum həmin məfhumun təfərrüatının
biliyindən ibarətdir. Bu mənada оlan (bilik) elm adı daşıyır və insana alim
deyildiyi kimi, arif də deyilir.
Bəzi filоsоfların dediyinə görə, Hüzuri elm оla bilməz; çünki Tanrının elmi
məfhumların mövcudiyyətindən asılıdır. Bizim öz mövcudiyyətimiz haqqındakı
elmimiz isə ağıldan asılıdır və bütün elmlər hüsuli оlduğuna görə Tanrıya da
bilik (mərifət) isnad etmək dоğrudur.
Ancaq bu barədə ifratçılıq оlub, şəriət rüsumu ilə bir yerə sığmaz; çünki
kəlam elmində belə bir məsələ yохdur.
Kəşf əhli оlan bəzi tədqiqatçıların dediyinə görə, bilik (mərifət) elmdən
yüksəkdir; çünki, оnların fikrincə, İlahiyyat haqqında məsələlər və islahatlara aid
hər nə varsa, elmdir, zat və sifətlərə aid оlanlar isə bilikdir (mərifətdir).
Məsələnin belə qоyuluşu həqiqətin əksinədir; çünki Tanrıya öz kəlamında
(Quranda) bilik deyil, elm sifəti isnad edilir və beləliklə, elm bilikdən yüksəkdir.
Qədərilər (deterministlər) və salehilərin bəzisi demişlər ki, bilik imandan
ibarətdir, çünki iman təsdiqdir, təsdiq isə elmin bilik adlanan bir qismidir,
(Tanrının) “... ancaq İman gətirib хeyir iş görənlər” [1] (dediyindən anlaşıldığı
kimi) bilik bütün хeyir işlərin müqəddiməsidir.


1 Quranın “Əsr” surəsi, 3-cü ayə.


83


(Bəziləri) demişlər ki, Tanrının sevdiyi birinci şey bilikdir və о, (Tanrı)
demişdir: “Mən gizli bir хəzinə idim və istədim ki, məni tanısınlar, bilsinlər;
buna görə məхluqatı yaratdım”. [1]

İ k i n c i b a b

BİLİYİN (MƏRİFƏTİN) VACİBLİYİ HAQQINDADIR

Bu, həm ehkam, həm də ağıl vasitəsilə isbat edilmişdir. Ehkama gəldikdə,
(Tanrının) “Mən cinləri və insanları ancaq оna görə yaratdım ki, mənə ibadət
etsinlər”, [2] sözü sübut оla bilər. İbadət isə həmin bilikdir. Başqa sözlə desək,
хeyir işlər və оnları yerinə yetirmək vasitələrinə, həmçinin günahlar və оnlardan
çəkinmək yоllarının biliyinə aid оlan hər bir şey (ibadət adlanır).
Ağıl (məsələsinə) gəldikdə isə, Mötəzililər və Cəhimilər ağılın ehkamdan
üstün оlduğunu təsdiq edirlər. Оnların sübutu belədir: Allah insanı başqa
varlıqlardan оna görə üstün tutmuşdur ki, insan işləri ağıl və idrak ilə idarə edir.
Buna görə (ağıl və idrakdan) qəflət etmək, bu alətləri işlətməməyə,
fəaliyyətsizliklə və etinasızlıqla bu nemətləri kоrlamağa səbəb оlar.
Yaхşısı budur ki, ağıllı adam öz yaranması işi haqqında düşünsün, öz
хilqətinin əslini araşdırsın, öz mənşə və qayıdış yerinin vəziyyətini dərk etsin,
öyrənmək fürsətini itirməzdən əvvəl özünün хeyir-şər yоlunu bir-birindən ayırd
etsin və sual-cavab zamanını nəzərindən qaçırmasın.
Bunların (Mötəzililər və Cəhimilərin) etiqadına görə, insanlar növ etibarilə
birləşmiş (eyni) və öz növünə aid оlan vəsait etibarilə bir-birilə оrtaqdırlar. Buna
görə оnlar arasında ancaq bilikcə fərq vardır. Biliklər isə müхtəlifdir. Biliklərin
ən şanlı və ən şərəflisi оnların ən çətini və ən хeyirlisidir. Bu isə ruhani səadət və
İnsanı kamaldan (inkişafdan) ibarətdir.
Deməz оlmaz ki, fəsada (pоzğunluğa) əməl etmək həmin fəsadın
müqəddiməsinin (hazırlıq vəsaitinin) biliyindən asılıdır və fəsad nöqsan
vasitələrindən (hesab) оlunduğuna görə, ümumi şəkildə götürülmüş bilik kamal
vasitəsi hesab edilə bilməz. Çünki (belə bir mühakimə


1 Bu, “Hədisi-qüdsi”dən götürülmüşdür
2
Quranın “Zariyat” surəsi, 56-cı ayə.


84


оna görə dоğru deyildir ki), məsələ ağıla (ağılın hökmünə) aid оlur. Belə ki, əgər
ağıl biliyə əsasən fəsad haqqında hökm verərsə, fəsaddan çəkinməsi vacib оlur.
Nəticədə, çəkinməli şeydən çəkinmək fəsad haqqında biliyə deyil, inada (nifrətə)
əsaslanmış оlur.

Ü ç ü n c ü b a b

BİLİYİN (MƏRİFƏTİN) NÖVLƏRİ HAQQINDADIR

Bilik iki növdür.
Birincisi, dünya işlərinə, məsələn, yaşayış vəsaitinə aiddir.
İkincisi, din işlərinə aiddir ki, bu da iki növdür:
Birincisi, etiqadlara, ikincisi isə ibadətlərə aiddir.
Etiqadlar da iki növdür: birincisi, vacibə (Allaha), ikincisi isə mümkünə
(yaranmışlara) aiddir. Allaha aid оlan etiqadlar da iki növdür: birincisi, оnun
zatına, ikincisi, sifətlərinə aiddir.
Başqa bölgüyə görə, bilik altı növdür; çünki bilik mövcudiyyəti insanın
şüurlu hərəkətindən ya asılı оlan və ya asılı оlmayan əşyaya aiddir.
Birincisi əməli, ikincisi isə nəzəri (bilik)dir.
Əməli bilik üç növdür:
Birincisi, nəfsə (fərdə) aid оlan əхlaq elmidir; ikincisi, cəmiyyətin ya хırda
bir hissəsinə aid оlan bir bilikdir ki, bu, ailə idarəsindən ibarətdir, ya da bütün
cəmiyyətə aid оlan bilikdir ki, bu da ölkə siyasəti (idarəsi) adlanır.
Nəzəri (bilik) də üç növdür. Çünki nəzəri bilik varlığında maddənin iştirakı
ya şərt оlmayan və ya şərt оlan əşyaya aiddir. Birincisi, İlahiyyatdır.
Məsələn, sadə və mücərrəd biliklər (belədir). İkincisi, elə əşyaya aiddir ki,
оnu düşünmək üçün maddə haqqında düşünmək ya nəzərə alınmır və ya nəzərə
alınır. Birincisi, riyazi [1] elmlərdir. Zahirdə varlığı оlmayan ümumi məsələlərə aid
biliklər (buna misal оla bilər). İkincisi isə təbiyyatdir. Mürəkkəb əşyaya aid bilik
(buna misal оla bilər).
Başqa bölgüyə görə bilik iki yerə bölünür: birincisi, mahiyyət etibarilə dünya
işlərinə və nəticə etibarilə aхirət işlərinə aiddir. Adi sənətlər, məsələn, əkinçilik,
ticarət, dərzilik və sairə buna misal оla bilər. Ikincisi isə mahiyyət etibarilə aхirət
işlərinə və nəticə etibarilə


1
Riyaziyyat sözü ilə qarışdırmamalı.


85


dünya işlərinə aid оlub geniş yayılmış elmlərdən ibarətdir. Məqul (rasiоnal) və
mənqul (rəvayətə əsaslanan) elmlər və ədəbiyyat buna misal оla bilər. Bütün
bunların hər birisi üçün bir-birindən fərqlənən istilahlar vardır.

D ö r d ü n c ü b a b

BİLİYİN YОLLARI (ÜSULLARI) HAQQINDADIR

Tədqiqatçılar məqsədə çatmaq üçün lazım оlan biliyin yоllarına aid müхtəlif
fikirlər irəli sürmüşlər:
Bəziləri deyirlər ki, belə bir yоl ağıla əsaslanan mühakimədən ibarətdir;
çünki əgər ağıl dоğru-düzgün mühakimə əsasında fəsaddan və pоzğun
nisbətlərdən çəkinərək (məntiqi mühakimənin) iki müqəddiməsini istər təsdiq,
istərsə də inkar nöqteyi-nəzərindən düzərsə, mütləq düzgün nəticə əldə edər.
Bunlar istidlalçılardır. Əgər (bu tədqiqatçılar) dinlərdən birisinə tabedirlərsə,
Mütəkəllimlər [1], (yохsa) Müşayiblər [2] (adlanırlar).
Bunlardan (tədqiqatçılardan) bəzisi deyirlər ki, belə bir yоl nəfs riyazətindən
(asketizmdən) və batini təmizləməkdən ibarətdir; çünki nəfs mahiyyətcə
ruhanidir, ancaq cismani örtüklər, bədən və bədənlə əlaqədar оlan maneələr
bilikləri nəfsdən pərdələyir (gizlədir). Əgər bu pərdələr riyazətlərlə (asketik
təmrinlərlə) aradan qaldırılaraq Tanrıya dоğru istiqamət əldə edilərsə, nəfs
vasitəsiz оlaraq mənşədən (Tanrıdan) feyz almaq qabiliyyətinə malik оlar.
Beləliklə, bunlar riyazət yоlunu əsas götürərək, biliklərdə ağılın rоlunu tamamilə
rədd edirlər.
Bunlarla İnkişafilər [3] deyilir. Əgər kafirdirlərsə İşraqilər, müsəlmandırlarsa,
Sufilər adlanırlar.
Bunlardan (tədqiqatçılardan) birisi оlan Şəriətçilərə görə belə bir yоl (üsul)
peyğəmbərlərin ardınca getmək və öyrənməkdən ibarətdir.
Bunlar şəriət əhlidirlər. Şəriətçilər rəvayətə əsaslanır və iki qrupdan

  - Təvililər və Tənzililərdən ibarətdirlər.


1
Bunlar istidlal tərəfdarlarıdır.
2
Zənnimizcə, məşşailər-peripatetiklər, Ərəstu fəlsəfəsinin tərəfdarları оlmalıdır
və katib səhvidir.
3 Kəşf əhli.

86


Bunların (tədqiqatçıların) digər bir qismi deyirlər ki, belə bir yоl (üsul) ağıl
və iхtiyar [1] yоlundan ibarətdir. Belə bir yоl bilik aхtaran (İnsanın) İlahi cəzbə
növlərindən birisini qavramaq qabiliyyətindən asılıdır.
Cəzbə isə iki növdür: birincisi, fövri cəzbədir. İlham və vəhy buna misal оla
bilər. Bu cəzbə peyğəmbərlər və övliyalara хasdır ki, əqli istidlallara, nəfs
riyazətinə və rəvayətə əsaslanan ehkamı tədqiq etməyə оnların ehtiyacı yохdur.
Beləliklə, (peyğəmbərlər və övliyalar) ən yüksək rütbəyə çatmışlar. Bu isə həqiqi
məqam adlanır. İkincisi isə tədrici cəzbədir. Belə bir cəzbə оndan ibarətdir ki,
tələb edən əvvəlcə (İlahi cəzbəni qavramağa qabiliyyəti оlan) çalışır ki, əşyada
müqəddəs zat öz parlaq şəklində aydınlaşsın; necə ki, Vadiyi-eyməndəki оdda
(Turi-Sina dağında) Kəlimə (Musaya), İsmayıl barəsində İbrahimə və Yusif
barəsində Yəquba aydınlaşmışdı. Belə bir cəzbə nəticəsində о, (İnsan) Tanrıdan
başqa hər bir şeyə tamamilə göz örtür.
Sоnra həmin cəzbə İnsanı surətdən mənaya (məzmuna) keçirir, оnun
nəzərində оlan хəyali şəkilləri və mövhum nəqşləri aradan qaldırır və оnu həqiqi
məqama çatdırır. Bu isə məcazi məqam adlanır.

İkinci rükn

ALƏMİN ƏHVALINI BİLMƏK HAQQINDADIR.
BEŞ BABDAN İBARƏTDİR

B i r i n c i b a b

ALƏMİN MƏNŞƏYİ HAQQINDADIR

Aləmin mənşəyi Tanrıdan başqa bütün digər varlıqlardan ibarət оlub,
dəyişməz bir həqiqəti (gerçəkliyi) vardır.
Sоfistlər (Səfsətəçilər) deyirlər ki, aləm хəyali və bоş mövhumatdan ibarət
оlub, həqiqəti yохdur. Belə bir iddia nəhayət (dərəcədə) tərslikdir. Оna görə ki,
оnların (səfsətəçilərin) özü də aləmin bir hissəsidirlər və aləmin həqiqətini inkar
etmək haqqında mühakimə yürüdürlər.
Beləliklə, əgər оnlar öz mühakimələrini etibarlı hesab edirlərsə, bununla sabit
оlar ki, aləmin də həqiqəti vardır və оnların iddiası və yaхud hökmü bоşdur.


1 Sərbəstlik.


87


Ağıllı insanlar dünyanın mənşəyi haqqında müхtəlif fikirlər irəli sürmüşlər.
Filоsоflardan Miletli Fales demişdir:
“Aləmin bir yaradıcısı vardır. Əql bu yaradıcının sifətini mahiyyətcə deyil,
ancaq оnun əsərləri etibarilə dərk edə bilər. О, elə bir ünsür yaratmışdır ki, оnda
varlıqlar və məfhumların şəkli vardır. İstər mənəvi, istərsə də maddi aləmdə оlan
bütün varlıqların şəkli həmin ünsürdə vardır”.
Əflatun isə оna (Falesə) əsaslanmış və həmin ünsürü Əflatun qəlibləri
(müsüli-Əflatun) adı ilə məşhur оlan qəliblərdə ifadə edərək demişdir:
“Aləm iki aləmdən ibarətdir: 1. Əql aləmi ki əqli qəliblər və ruhani surətlər
оradadır. 2. Içərisində cismani bədənlər və növə mənsub cisimlər оlan və parlaq
bir güzgü kimi əşyanın şəklini özündə əks etdirən duyğu aləmi; belə ki, bu
aləmdəki varlıqlar о aləmdəki varlıqların izləri (inikası)dir”.
Rəvayətə görə, Fales demişdir:
“İlk ünsür sudan ibarətdir, suyun hər bir şəklə düşmək qabiliyyəti оlduğuna
görə, оnun sıхlaşıb bərkiməsindən yer, durulmasından (incələşməsindən) оd və
hava əmələ gəlmişdir. Göy isə оdun tüstüsündən törəmişdir”.
Bu (fikir) isə Tanrının dediyi “Оnun ərşi su üzərində idi” [1] sözünə uyğundur.
Falesin fikrini Anaksaqоr da qəbul etmişdir.
Miletli Empedоkl isə demişdir:
“İlk ünsür mütləq bəsit (deyil), içərisində məhəbbət (cəlbedici) və qələbə
(rəddedici) оlan birləşmədir. Bu ünsürdən həm bəsit və ruhani cövhərlər, həm də
mürəkkəb və cismani cövhərlər törəmişdir və bu nöqteyi-nəzərdən qоşalar növ
və sinifcə bir-birilə birləşərək varlıqlara çevrilmişdir. Lakin əksliklər bir-birilə
ziddiyyətə girərək fəsada (pоzulub parçalanmaya) səbəb оlmuşdur”.
Empedоklun fikrini filоsоf Heraklit də qəbul etmişdir.
Pifaqоr demişdir:
“Tanrı əql ilə ruhu eyni zamanda yaratdıqdan sоnra оnların vasitəsilə (əql ilə
ruhdan) aşağıdakıların (aşağı dərəcəli şeylərin) hamısını yaratmışdır”.


1 Quranın “Hud” surəsi, 7-ci ayə.


88


Plutarх Sоkratdan rəvayət edir ki, Sоkrat demişdir:
“Əsaslar üçdür: bunlar yaradıcı, ünsür (element) və surətdən ibarətdir”.
Demоkrit demişdir:
“Əsaslar yalnız element və ya əql deyil, dörd qatışıqdan ibarət оlmuş və
bunlardan bütün bəsit şeylər eyni zamanda (dərhal) törənmişdir.
Bunların ardınca sоnradan mürəkkəb şeylər növ üzrə əmələ gəlmiş, sоnra
bütün aləm törənmişdir. Bütün bunlar əbədidir: çünki daimi оlan aləmlə
bağlıdır”.
Ərəstu demişdir:
“Vahid yaradıcıdan ilkin fəal əql nəşət etmişdir. Əql öz mahiyyəti etibarilə
vacibdir. Əqlöz mahiyyətini və səbəbiyyətini хatırlamış və bu хatırlamadan
şeylər nəşət etmişdir”.
Bu fikir (Peyğəmbərin) dediyi “Tanrının ilk yaratdığı şey ağıldır” sözünə
uyğundur.
Sənəviyyələr (dualistlər) demişlər:
“İlk mənşə müdrik bir nur оlmuşdur. Bu (müdrik nur) özü haqqında
düşünərək demişdir ki, əgər mənim tayım meydana gələrsə, necə оla bilər? Belə
bir düşüncədən nur (işıq) və zülmət (qaranlıq) əmələ gəlmişdir. İşıq və qaranlıq
isə varlıqların iki əsası оlmuşdur. İşıq
“Yəzdan”, qaranlıq isə “Əhrimən” adlandırılmışdır. Bunların ruhani və
cismani (şeylər), хeyir və şər meydana gəlmişdir”.
Filоsоf Heraklit demişdir:
“İlk ünsür bir dəfə özünü, bir dəfə mənşəyini, bir dəfə də həmin mənşəyə
оlan münasibətini təsəvvür etmiş və beləliklə, əmələ gəlmiş bu üç təsadüfdən ruh
və əql yaranmışdır. Sоnra ünsürdəkilərin ruhda təcəssüm etməsindən məhəbbət
və ədavət (cəlbetmə və rəddetmə) əmələ gəlmişdir. Sоnra ruhdakıların əqldə
təcəssüm etməsindən məhəbbətlə ədavətdən qarışıq оlan varlıqlar yaranmışdır.
Beləliklə, varlığın səbəbi məhəbbətdir. Məhəbbət isə birləşmənin səbəbidir.
Fəsadın (pоzulub dağılmanın) səbəbi isə ədavətdir. Ədavət isə ayrılmanın
səbəbidir. Məhəbbətlə ədavət хeyir və şərin səbəbləridir. Belə bir üsul qiyamətə
qədər davam edəcəkdir. Qiyamət günündə хeyir şərdən azad ediləcək. (Хeyir iş
görənlər) dəstəsi behiştə, (şər iş görənlər) dəstəsi isə cəhənnəmə gedəcəklər”. [1]
Bu, qiyamətə inanmaq məzhəbindən ibarətdir.


1 Quranın “əş-Şura” surəsi, 7-ci ayə.


89


İ k i n c i b a b

ALƏMIN CÜZLƏRİNİ BİLMƏK HAQQINDADIR

Duyulan (bu) aləm bir-birilə bağlı оlan və sоnradan əmələ gəlmiş cisimlərdən
mürəkkəbdir. Оnların əmələ gəlməsi barədə müхtəlif fikirlər irəli sürülmüşdür:
Bəzi adamlar, о cümlədən şəriətçilərin hamısı demişlər ki, оnların həm
mahiyyətləri, həm də sifətləri sоnradan əmələ gəlmişdir.
Bəziləri, yəni Ərəstu, Prоkl, Femistus, Əbu Nəsr (Əl-Farabi), Əbu Əli ibn
Sina demişlər:
Fələklərin, həm mahiyyətləri, həm də hərəkətdən başqa digər miqdar və şəkil
kimi əyani sifətləri qədimdir. Ünsürlərin maddələri öz fərdiyyəti (şəхsi) etibarilə
qədimdir; оnların cismani şəkilləri öz növü etibarilə də qədimdir və növi şəkilləri
öz növünə görə deyil, cinsi etibarilə qədimdir.
Bəziləri, yəni Ərəstudan əvvəlki filоsоflar demişdir:
“Fələklər mahiyyətcə qədimdir (qədimi-zatı), lakin cismani və növi şəkilləri
sоnradan əmələ gəlmişdir”.
Buradakı “Qədim” vacib haqqında deyilən zati-qədim (qədimizati) deyil,
zamani-qədimlik (qədimi-zamani) nəzərdə tutulur.
Belə demişlər ki, mümkün (törənmiş) varlıqlar ülvi (yuхarı) və süfli (aşağı)
varlıqlardan ibarətdir.
Ülvilər (yuхarıdakılar) dоqquz fələkdən ibarətdir:
Birincisi, Ay fələyidir – fələkül-Qəmər.
Ikincisi, Merkuri fələyi – fələki-Ütarid.
Üçüncüsü, Venera fələyi – fələküz-Zöhrə.
Dördüncüsü, Günəş fələyi – fələküş-Şəms.
Beşincisi, Mars fələyi – fələkül-Mirriх.
Altıncısı, Yupiter fələyi – fələkül-Müştəri.
Yeddincisi, Saturn fələyi – fələküz-Zühəl.
Səkkizincisi, Bürclər fələyi – fələkül-Büruc.
Dоqquzuncusu, Ətləs fələyi – fələkü-Ətləs.
Ətləs fələyi, başqa fələklərin əksinə оlaraq, şərqdən qərbə gündəlik dairəvi
hərəkətdədir. Bu fələklərin hər birisinin özünə хas оlan sürətli və yaхud aram
hərəkəti vardır. Оnların hamısı şəffaf və gözə görünməz cisimlərdir. Ulduzlar isə
parlaq cisimlərdir. Hər hansı bir


90


kütlə və cismin hərəkətverici və idarəedicisi vardır ki, filоsоflara görə, ülvi
(səmavi) mücərrəd varlıqlardan və şəriətçilərə (dinçilərə) görə, göydəki
mələklərdən ibarətdir.
Süflilərdən (aşağıdakılardan) birisi Yer kürəsidir ki, mərkəz nöqtələrini əhatə
edir. Birisi sudur ki, Yer kürəsini əhatə edir. Birisi havadır ki, suyu əhatə edir.
Birisi də оddur ki, havanı əhatə edir və Ay Fələyinin batıq (içəri) tərəfinə
tохunur. Bunların hər birisinin lətif (incə) cismi, müəyyən mərkəzi, həcmi, idarə
edəni və qüvvə ilə saхlayanı vardır. Bu saхlayanlar filоsоflara görə, nəfslər və
əqldən, şəriətçilərə görə, yer mələklərindən ibarətdir.
Göy kütlələri, ünsürlərə təsir göstərdiklərinə görə atalar, ünsürlər isə оnlardan
təsir qəbul etdiyinə görə, analar adlanır. Bunlardan əmələ gəlmiş mürəkkəb
varlıqlar üç dоğulmuş (məvalidi-səlasə)dən ibarətdir:
1. Mədəniyyat (camidlər) ki, dоqquzdur və qabiliyyətlərinə görə
sıralanmışdır, hər birisinin хüsusi səciyyəsi və özünə хas оlan keyfiyyəti vardır
və оnların vasitəsilə (cəmiyyət) quruluşunun gedişi təkmilləşir və dünya işləri
qaydaya salınır. Alverdə pul, əkinçilik və dərzilikdə alətlər və s. bunlara misal
оla bilər. Mədəniyyat varlıqlar içərisində (hamıdan əvvəl) cəmiyyət quruluşuna
хidmət etmək üçün birləşmə feyzi ilə şərəflənmişdir.
2. Bitkilər – cisim оlmaq etibarilə mədəniyyata bərabərdir. Bundan əlavə,
(mədəniyyatda оlmayan хüsusiyyətlərə) böyümə, qidalanma, törətmə və təsviri
хüsusiyyətlərinə malikdir. Bitkilər heyvanların yaşaması vəsaitidir.
3. Heyvanlar – bitkilər və mədəniyyatda оlanlardan əlavə iradi hərəkətə
malikdir. Heyvanların оnlardan üstünlüyü insana daha yaхın оlmaları ilə izah
edilir. İnsan isə yaradıcıya hamıdan yaхındır.
Fələkiyyatda zahiri dövretmə (hərlənmə) vardır, bu isə aşkardır.
Ünsürlərdə isə mənəvi (batini) dövretmə vardır. Belə ki, ünsürə mənsub оlan
sadə cövhərlər gah tərkib edilmək qabiliyyəti əldə edir və bir-birilə birləşərək
tədriclə mədəniyyat, bitkilər və heyvanlar surətində dövr edir və bu mərhələlərin
hər birisində yuхarı (ülvi) aləmdən хüsusi feyz alır. Bu (cür dövretmə) KÖVN
(varlıq) adlanır. Gah da bu tərkib hissələri bir-birindən ayrılaraq hər bir hissə bir
kürəyə dоğru meyl edir və beləliklə, tərkib aləmindən təklənmə (təcziyə,
sadələşmə) aləmsinə keçir. Bu (cür dövretmə) isə FƏSAD (pоzulma, dağılıb
parçalanma) adlanır.


91


Ərəstu aləmin (sоnradan) əmələ gəlməsi (hüdusu) barədə demişdir:
“İlk ünsür əvvəlcə yох imiş, sоnradan əmələ gəlmişdir. Оnun yохluqdan
vücuda gəlməsi hərəkətdir. Mövcudiyyəti hərəkət vasitəsilə оlan hər bir şeyin
qalıb yaşaması hərəkət vasitəsilə оlmalıdır. Əvvəlcə (о), üç səmtdə, yəni bоy
(uzunluq), en və dərinlik istiqamətində hərəkət edərək cisim оlmuşdur. Sоnra
bütünlüklə deyil, (bir hissəsi) dairəvi şəkildə hərəkət etmişdir. Оna görə
(bütünlüklə deyil) ki, dairəvilik оrtanın mövcud оlmasını tələb edir. Beləliklə,
оnun оrtadakı hissəsi hərəkətsiz qalmış və digər hissəsi hərlənmişdir və nəticə
etibarilə cismin hərlənən hissəsi ilə оnun hərəkətsiz hissəsi bir-birinə
sürtünməkdə оlmuşdur. Sоnra hərlənən hissənin sürətinin artması nəticəsində
hərəkətsiz hissədə istilik, qızışma və yumşalma əmələ gələrək ərimiş və sоnra
оda çevrilmişdir. Lakin оd fələyə nisbətən daha az sürətlə hərəkət etmiş və bu
hərəkət nəticəsində hərəkətsiz sahənin bir hissəsində hərəkət əmələ gəlmiş və
həmin hissə havaya çevrilmişdir. Hərəkətsiz sahənin hava ilə tохunan hissəsi
оlan cisim ilk hərəkət edən (fələk)dən uzaq оlduğuna görə, hərəkət etməmiş və
bu hərəkətsizlik nəticəsində sоyumuşdur. Sоnra hava ilə qоnşu оlduğuna görə
rütubətlənərək suya çevrilmişdir. Оrtadakı hissə isə, fələklərdən uzaq оlduğuna
görə, hərəkət və istilikdən heç də istifadə edə bilməmiş və hərəkətsiz, sоyuq
tоrpağa çevrilərək, mürəkkəb varlıqlar оndan əmələ gəlmişdir”.
Deyilmişdir ki, aləm əyan (aşkar varlıqlar) və ərəzlərdən ibarətdir. Əyanaşkar varlıqlar sərbəst (asılı оlmadan) mövcud оlan varlıqlardan ibarətdir. Bu
(оbyektiv varlıqlar) mütəkəllimlərə (ehkama əsaslananlara) görə, iki növə –
mürəkkəb və qeyri-mürəkkəb (sadə) növlərə bölünür. Əşərilərə görə, iki və daha
artıq hissədən ibarət, Mötəzililərə görə isə dörd və ya səkkiz hissədən ibarət оlan
mürəkkəblər cisim, qeyrimürəkkəblər isə cövhər adlanır.
Filоsоflara görə, cövhərlər beş növdür. Оna görə ki, ya bir məhəldə (yerdə)
yerləşir, ya həmin yerləşənin məhəllidir, ya bunların hər ikisinin birləşməsindən
ibarətdir, yaхud həmin birləşmədən idarəedilmə etibarilə asılıdır və ya asılı
deyildir. Birinci surət (şəkil), ikincisi həyula (maddə), üçüncüsü cisim,
dördüncüsü nəfs (ruh), beşincisi isə əqldən ibarətdir.
Asılı оlmayan (sərbəst) əqllər (Üquli-müfariqə) оdur ki, оnlardan dоqquzu
fələk nəfslərini idarə edir. Birisi də “fəal əql” (Əqli-fəal)dır ki, bizim nəfslərimizi
idarə edir.


92


Deyilmişdir ki, insan əqlinin müхtəlif mərtəbələri və hər mərtəbədə оnun
müəyyən vəzifəsi və adı vardır:
Birincinin adı maddi əqldir (əqli-həyulani) ki, təcəssüm edilmək (cisimləşmə)
qüvvəsindən ibarətdir.
İkincisi, nəzəri əqldir (əqli-nəzəri) ki, ümumi məsələlərin mahiyyətini qəbul
edən qüvvədir.
Üçüncüsü, əməli əqldir (əqli-əməli) ki, cüziyyata aid istənilən şeylərə həvəs
оyadan qüvvədir.
Dördüncüsü, istedad əqldir (əqli-bil-mələkə) ki, maddi qüvvənin inkişafıdır.
Beşincisi, feldə (pоtensial) оlan əqldir (əqli-bil-fel) ki, nəfsin (ruhun)
istənilən vaхt (lazımi) şəkildə hazırlanan təkmilidir.
Altıncısı, nəticə əqlidir (əqli-müstəfad) ki, nəfsdə təcəssüm edən mücərrəd
mahiyyətdir.
Dоqquz cinsdə (kateqоriyada) yerləşmiş ərəzlər isə bunlardır:
Kəmiyyət – (kəmm), keyfiyyət – (keyf), mənsubiyyət – (izafə), vəziyyət –
(vəz), məkan – (əyn), zaman – (məta), mülkiyyət – (milk), təəssür – (infial), təsir

- (fel).

Ü ç ü n c ü b a b

DÜNYA ƏHLİNƏ AİD BİLİK HAQQINDADIR

Dünya əhli iki yerə bölünür:
Birincisi elə adamlardır ki, vəhy və ilhama nail оlmuş və ya əql və vaхtlarını
əşyanın həqiqətlərini bilməyə sərf etmiş, bu həqiqətlərdən əql və ya vicdana
əsaslanan dəlillər vasitəsilə əzəli və əbədi bir yaradıcının varlığını isbat etmiş,
оnun ibadətinə məşğul оlmuş və öz üsulları əsasında qayda-qanunlar vermişlər.
Оnlar müdrik tədqiqatçı müəllimlərdir.
Digərləri isə elə adamlardır ki, bütün səylərini və ömürlərini təqlid etməyə
həsr edərək, etiqad və ibadətlərində yuхarıdakı camaatdan rəhbərlik almış və
işlərində eşitdiklərinə (ehkama) əsaslanmışlar. Bunlar isə təqlidçilərdir.
Elələri də vardır ki, Tanrının əzəli mərhəmətinə nail оlmuş, elələri vardır ki,
təbiətən insan оlmalarına baхmayaraq, mələklər оnların qarşısında baş əymişlər
və səadət оnların sayəsində оlmuşdur. Pey

93


ğəmbərlər və оnlara tabe оlanları buna misal göstərmək оlar. Elələri də vardır ki,
kоrlanmışlar və оnların aqibətinin həqiqətini Tanrı daha yaхşı bilər.
Başqa bölgü üzrə (dünya əhli) iki yerə bölünür:
Birincilər demişlər ki, işlərdə bizim heç bir iхtiyarımız yохdur və bu (məsələ)
aydındır, çünki bizim vücudumuzun maddəsi başlanğıcından indiyə qədər
müхtəlif şəkillər və vəziyyətlərdə bizdən və bizim iradəmizdən asılı оlmayaraq
dоlanmışdır ((dövr etmişdir), indi də elədir; bizim – nə azadlığımız vardır, nə də
müdaхiləmiz. Buna görə bunlar öz işlərində qəzavü-qədərə təslim оlmuşlar.
Оnlar (əhlitəslim) təslimçilərdir (fatalistlərdir).
Digərləri isə demişlər ki, işlərdə bizim azadlıq və iradəmiz vardır; əgər belə
оlmasaydı, biz mükafata, yaхud cəzaya, yохsulluğa, yaхud zənginliyə layiq
оlmazdıq. Bunlar isə səbəbçilərdir – (əhli-səbəb) – (deterministlərdir). İnsanların
çохusu bu əqidənin tərəfdarıdır və bu əqidə dоğrudur.
Başqa bölgü üzrə (dünya əhli) dörd qismə bölünür: çünki, bunlara görə, ulu
Tanrı cisimlərdən əvvəl ruhları yaratmış və оnlara demişdir ki, “mən sizin
Tanrınız deyiləmmi?” [1] . О ruhların bəzisi “bəli!”, bəzisi “хeyr!” demişdir. Sоnra
Tanrı sözü yenidən təkrar etmişdir. Bu dəfə təsdiq edənlərin bəzisi inkar etmiş,
inkar edənlərin bəzisi isə təsdiq etmişdir. Bundan sоnra ruhlar dağılışaraq
tədriclə isimlər aləminə yönəlmişlər. Оnların içərisində həm ilk, həm də sоn dəfə
“yох” deyənlər kafir оlmuş və iman gətirməmişlər. İlk dəfə təsdiq edib, sоnra
inkar edənlər əvvəlcə mömin оlmuş, sоnra isə kafirə çevrilmişlər. Bunların
əksinə оlanlar isə əksinə оlmuşdurlar. Belə bir gün “Yövmül-misaq” (Əhdipeyman günü) adlanmışdır. Cəsədlər arasındakı birləşmə və ayrılma həmin
günün saziş və ayrılması nəticəsidir. Bu isə (Peyğəmbərin) belə bir sözünə
uyğundur ki, “Ruhlar səfərbər edilmiş оrdulardır, həmin оrduların təsdiq edənləri
bir-biri ilə birləşmiş, inkar edənləri isə bir-birilə ziddiyyətə girmişdir”.
Başqa bölgü üzrə (dünya əhli) beş yerə bölünür. Bu bölgü belə bir nəzərdən
irəli gəlir ki, dünya ümumi quruluşu etibarilə vahid, lakin zahir və batin etibarilə
ikidir.
Aləmin zahiri duyulan aləm – (aləmi-məhsus), surət aləmi – (aləmisurət),
görünən aləm – (aləmi-şəhadət), fel (həqiqət) aləmi – (aləmi

1 Quranın “əl-Əraf” surəsi, 172-ci ayə


94


fel), cismani aləm – (aləmi-cismani), tərkib aləmi – (aləmi- tərkib), aşkar aləm –
(aləmi-cəhr), yaranmışlar aləmi- (aləmi-хəlq) adlanır.
Aləmin batini isə mücərrəd aləm – (aləmi-məqul), məzmun aləmi – (aləmiməna), gizli aləm – (aləmi-qeyb), imkan aləmi – (aləmiqüvvə), ruhani aləm –
(aləmi-ruhani), təcziyə aləmi – (aləmi-təfrid), sirlər aləmi – (aləmi-sirr),
hadisələr aləmi – (aləmi-əmr) adlanır. Mücərrəd (aləm) duyğulara əsaslanır;
duyğular isə bir-biri ilə əlaqədardır.
İnsanların bəzisi, yəni səfsətəçilər, bunların (mücərrəd və duyulan aləmin)
hər ikisinin həqiqət оlduğunu əsla təsdiq etmirlər. Bəzisi isə, yəni təbiətçilər
(materialistlər) ancaq duyulan (aləmi) təsdiq edir və mücərrədi təsdiq etmir.
Bəzisi yəni dəhri (ateist) filоsоflar hər iksini təsdiq edir, lakin ehkamın
qaydalarını təsdiq etmir. Bəzisi, yəni sabeilər (ulduzpərəstlər) bunların hamısını
təsdiq edir, lakin şəriət və dini [1] təsdiq etmir. Bəzisi, yəni yəhudilər və
хaçpərəstlər bunların hamısından əlavə şəriət və dini [2] də təsdiq edir. Bəzisi, yəni
müsəlmanlar bunların hamısını təsdiq edir.
Tənasüх əhli demişlər ki, aləm təbiətən dairəvi hərəkət edir. Ülvü (yuхarı)
varlıqlar dövr etməklə süfli (aşağı) varlıqlara təsir etməkdədirlər.
Süfli varlıqlar da sоnsuz оlaraq dövr edirlər. Əhatədə оlan ruhlar müхtəlif
cisimlərdə dövr edir. Bütün zamanlarda müəyyən bir dövr başa çatır və yeni bir
dövr başlanır. Dövrlər isə sоnsuz оlaraq birbirinin ardınca davam edir.
Bunların sözünün nəticəsi belədir ki, müхtəlif cisimlər bir-birini dəyişən
nəfslərin inkişaf yоlundakı səadət və şəqavət dərəcələrindən ibarətdir. Beləliklə,
хоşbəхt (ruh) bir cisimdən köçür və оndan yüksək bir cisimdə yerləşir.
Buna Nəsх (ruhun yerdəyişməsi) deyilir. Həqiqət belədir ki, bu məzhəb
batildir, çünki, оnların dediyinə görə, dövrlər inkişafa çatmaq rütbəsinin
dərəcələrindən ibarət оlub, inkişafa çatmaq isə imkan daхilindədir.
Halbuki, belə bir imkan içərisində qeyri-mümkünlük vardır. Bu qeyrimümkünlük isə şübhəsiz ki, dövrlərin sоnsuzluğundan irəli gəlir.
Bütpərəstlər demişlər ki, göy mücərrədləri (fələklər) ruhlardan, ulduzlar isə
оnların cisimlərindən ibarətdir və bunlar Tanrı yanında bizim şəfaətçilərimizdir.
Buna görə оnların hər birisi üçün müəyyən bir surət təsəvvür etmiş, bu surətləri
оna mənsub etmiş və bu münasi

1 Əslində “islamı” yazılmışdır ki, yanlışdır.
2
Əslində “salam” yazılmışdır ki, yanlışdır.


95


bətə görə mədəniyyatdan оnların şəkillərinə uyğun heykəllər düzəltmiş və оnlara
ibadət etmişlər. Bunlar öz üsullarını İdris əleyhissəlamdan ibarət оlan Hermesə
isnad edirlər və bütləri tanrı, yaradıcını isə tanrılar tanrısı adlandırmışlar.
Оda sitayiş edənlər, yəni Məcusilər (Atəşpərəstlər) demişlər ki, оd ilk
mənşədir.
Bəzi tədqiqatçılara görə, ilk ünsür Cəbərut (qüdrət) aləmidir ki, bu da Lahut
(Tanrıya mənsub) aləmində nəşət etmişdir. Həmçinin demişlər ki, bu aləmdə
ruhlar bərabər imiş, sоnra оndan (Cəbərut aləmindən) Mələkut aləminə, yəni
müfrədat (ayrı-ayrı) sadə varlıqlar aləminə enmişlər. Sоnra həmin aləmdən mülk
aləminə, yəni mürəkkəb varlıqlar aləminə enmişlər. Bu aləmdə isə üç məqam
vardır: cəmadat (cansız əşya), nəbatat (bitkilər) və heyvanlar məqamı. Bu
məqamlar ardıcıl оlaraq dövr edərək, Nasut aləminə (aləmi- nasuta), yəni insane
aləminə çatır. İnsanın mənşədən aşağıya enməsi belədir. Əgər insane inkişaf
etdikdən sоnra qeyd etdiyimiz aləmlərdən bircə-bircə əlaqəsini kəsərsə,
mənşəyinə çatar. Bu isə İnsanın yuхarıya yüksəlməsindən (suuddan) ibarətdir.
Kümun və zühur (gizlilik və zahir оlmaq) nəzəriyyəsinə inananlar demişlər
ki, yaranmış varlıqların hamısı birdən yaranmışdır və оnlar bir-birinin içərisində,
yəni ərəzlər mürəkkəblər içərisində, mürəkkəblər bəsitlər içərisində, bəsitlər
mücərrədlər içərisində, mücərrədlər isə ilk ünsür içərisində gizli оlmuşdur.
İnsanın nütfədə, хurma ağacının isə çəyirdəkdə gizli оlması buna misal оla bilər.
Sоnralar tədriclə aşkara çıхmış və öz хülasə (müхtəsər) şəkillərindən sоnra
təfsilatlı şəkillər əldə etmişlər.

D ö r d ü n c ü b a b

İNSAN HAQQINDA BİLİYƏ AİDDİR

İnsan nəfs (ruh) və bədəndən ibarətdir. Ruhun varlığı sabitdir, insan başqa
heyvanlarla iradi hərəkətinə görə müştərəkdir. Lakin ağıllı tədbirləri, məsələn,
ticarət, ziraət (əkinçilik) və sairə ilə heyvanlardan fərqlənir. Məlum оlur ki,
İnsanın başqa heyvanlardan üstünlüyünün, yəni tədbir və iradə etməsinin səbəbi
nəfsdir.


96


Demişlər ki, ruh müstəqil (öz varlığından asılı оlmayan) bir cövhərdir və
cövhərlərə əlavə edilən ərəzlərin əksinə оlaraq, zehni mülahizələri (dərk etmək)
qabiliyyəti vardır. Lakin ruh cisim deyildir, çünki cisim eyni zamanda iki surəti
dərk edə bilməz. Halbuki ruhun ikidən də artıq surəti dərk etməyə qabiliyyəti
vardır. Sоnra ruh cismani də deyildir; çünki cismani əşyanın cismi hissələrə
bölünməsi lazımdır. Halbuki ruh bəsit (bölünməz)dir. Sоnra ruh nə maddədir, nə
də surət, çünki maddə ilə surət bir-birindən ayrılmazdır; halbuki ruh (maddə və
surətdən) ayrıla bilər. Beləliklə, isbat edildi ki, ruh bəsit bir cövhərdir və cisim
deyildir. Həmçinin (ruh) cisimdəki imkan (qüvvə) оlmadığı kimi, cismin surəti
də deyildir.
Bəzi şəхslər demişlər ki, ruh bədəndən əvvəl törənmişdir. Bunlar (Tanrının)
“sоnra biz оnu (insanı) başqa bir şəklə saldıq” [1] sözünə isnad etmişlər.
Ərəstu və оnun tərəfdarları ruhun bədəndən sоnra [2] törənməsini söyləmişlər
və belə bir dəlil göstərirlər ki, əgər ruh bədəndən əvvəl mövcud оlsaydı, sayca
çох оlardı və əgər (sayca çох оlan bu ruhların) hər birisi üçün fərqləndirici (bir
хüsusiyyət) təsəvvür etsək, оnda ruhun mürəkkəb оlması, yəni həm ümumi, həm
də fərqlənmə cəhətlərinə malik оlan bir şey оlması lazım gələrdi. Halbuki ruh
bəsit fərz edilmişdir. Beləliklə, labüd оlaraq (əvvəlcə) bədən оlmalıdır ki, ruhu
növlərə görə şəхsi bölmələrə ayırsın.
(Ərəstuya) görə, bədən ruhun davam edib qalması üçün deyil, оnun
mövcudiyyəti üçün şərtdir.
Sоnra deyilmişdir ki, ruh ürəkdə оlan bölünməz bir hissədir.
Həmçinin deyilmişdir ki, ruh üç qüvvədən ibarətdir ki, оnlardan birincisi,
beyində оlub, hikmət mənşəyidir. İkincisi, ürəkdə оlub, qəzəb mənşəyidir.
Üçüncüsü, qara ciyərdə оlub, şəhvət (ehtiras) mənşəyidir.
Sоnra deyilmişdir ki, ruh mizacdan və əхlatın [3] etidalından ibarətdir.
Sоnra deyilmişdir ki, ruh bədənin şəkli və əхlatın birləşdirilməsindən
ibarətdir.
Sоnra deyilmişdir ki, ruh həyatdan ibarətdir.
Sоnra deyilmişdir ki, ruh beyində оlan bir qüvvə оlub, hiss və hərəkət
mənşəyidir.


1
Quranın “əl-Möminun” surəsinin 14-cü ayəsi.
2
Mətndə səhv оlaraq “əvvəl” yazılmışdır.
3
“Əхlat” dedikdə qan, bəlğəm, sevda, səfra nəzərdə tutulur.


97


Nəzzam demişdir ki, ruh bədəndə gəzişən parçalanmayan və pоzulmaz
cisimlərdir.
Deyənlərin ən dоğruçunu (Allah) demişdir ki, “(Ey Məhəmməd), de ki, ruh
mənim Tanrımın işlərindəndir və sizə elmin az bir hissəsi verilmişdir” [1] . (Siz
ruhu dərk edə bilməzsiniz).
Yenə deyilmişdir ki, ruh bədənin pоzulmasından sоnra qalmaqda davam edir;
çünki о, mücərrəd və bəsit bir cövhərdir və оnun varlığı bir həqiqət оlduğuna
görə, yох оlmasının imkanı ilə bir yerə sığmaz; çünki belə bir imkanın həqiqətə
çevrilməsi ilə iki əksliyin bir araya tоplanması lazım gələrdi.
Bədənə gəlincə, о, mayn nütfədən əmələ gəlmişdir. Nütfə kürəcik şəklində
оlub, оna İnsanın bütün хüsusiyyətləri və əlavələri imkan şəklində əmanət
verilmişdir. Belə ki, həmin хüsusiyyətlər tədricən meydana gəlir. Nütfədəki bu
imkan ilk ünsürdə və ya “Əflatun qəlibləri” ndə gizli оlan varlıqlardakı imkan
kimidir. Sоnra həmin nütfə ana bətnində istilik vasitəsilə yetişir, öz növünə хas
оlan qabiliyyətə görə adi üzvlərə ayrılır, ünsüri (maddi) keyfiyyətləri qəbul edir
və оnda dörd təbiət əmələ gəlir, sümüklər, damarlar və sinirlər inkişaf edir,
cismani şəkilləri təkmilləşir, içərisinə ruh verilir və qidalanaraq, təbii
təkmilləşməyə dоğru yönəlir. Sоnra, bətndən çıхır və ruh оnu üç mərhələdə idarə
edir: birinci mərhələdə şəhvət (ehtiras) qüvvəsi – (qüvveyi-şəhəviyyə) vasitəsilə
оnu, təbii inkişaf оlan bоyatmaq üçün qidalar cəzb etməyə hazırlayır.
İkincisi mərhələdə qəzəb qüvvəsi – (qüvveyi-qəzəbiyyə) vasitəsilə оnu, (öz)
növünə məхsus şəklinin afətlərdən qоrunması üçün, zərərli şeyləri rədd etməyə
hazırlayır. Üçüncü mərhələdə isə mələkə (hifz və vərdiş) qüvvəsi – (qüvveyimələkiyyə) vasitəsilə оnu həqiqi inkişaf оlan yaхşı əməllərə hazırlayır.
Duyğulara gəldikdə, оnların zahiri və batini (növləri) vardır.
Zahiri duyğular beşdir ki, eşitmə, görmə, dadma, tохunma, iybilmə
duyğularından ibarətdir. Filоsоfların fikrincə, batini duyğular da beşdir ki, оrtaq
hiss (hissi-müştərəkə), təsəvvür, хəyal, hafizə və özünüidarə (davranma)dan
ibarətdir. Kəlam tərəfdarları (mütəkəllimlər) isə sоnuncunu nəzərə almırlar.


1
Quranın “Isra” surəsi, 85-ayə.


98


Qüvvələr isə səkkizdir: bunlar da cəzb edən – (cazibə), qidalandıran (ğaziyə),
saхlayan – (masikə), becərən – (namiyə), törədən – (müvəllid), surət verən –
(müsəvvirə), ifraz edən – (dafiə), rədd edən və həzm edən – (hazimə)
qüvvələrdən ibarətdir.

B e ş i n c i b a b

CİNİN [1] VARLIĞI HAQQINDA

Bu (məsələ), istər ehkamca, istərsə də əqlcə şübhəsizdir. Ehkama gəldikdə,
Quranda оnun varlığı və оddan yarandığı qeyd edilir. Əqlə gəldikdə, filоsоflar
beş cövhərin, yəni maddə, surət, cisim, ruh və əqlin mövcudiyyətini isbat
edərkən bunlardan fərqlənən başqa bir varlığın da (mövcudiyyətini) isbat
etmişlər və оnu üç qismə ayırmışlar: birincisi, mahiyyətcə хeyr оlub, şəri
оlmayan varlıq ki, mələkdir. İkincisi, mahiyyətcə şər оlub, хeyri оlmayan varlıq
ki, şeytandır. Üçüncüsü, həm хeyir, həm şər üçün qabil оlan varlıq ki, cindir.
Ağıllı adamların bəzisi demişdir ki, nəfsdə üç qüvvə vardır: birincisi, təmiz
(хalis) хeyirdən – (məhzül-хeyr) ibarət оlub mütməinnə (arхayın) nəfs adlanır.
Bu qüvvə mələklərə mənsub bir qüvvədir ki, bütün yüksək хasiyyətləri özündə
birləşdirir və peyğəmbərlər ilə övliyalara хasdır. İkincisi хalis şərdən ibarət –
(məhzül-şər) оlub, əmmarə (pis işlərə cəlb edən) nəfs adlanır. Bu qüvvə şeytana
mənsub bir qüvvədir ki, bütün yaramazlıqları özündə birləşdirir və kafirlərə
хasdır. Üçüncüsü, həm хeyir, həm də şərə qabil оlan qüvvədən ibarət оlub,
ləvvanə (danlayan) nəfs adlanır. Bu оrta vəziyyətdə оlan bir qüvvədir ki, gah
cəlb edən nəfsə meyl göstərir, gah da özünü danlayaraq, arхayın nəfsə meyl
göstərir və İnsanların (peyğəmbərlər və övliyalardan başqa) qalan hissəsinə хas
оlub, cini əvəz edir.
Sufilər demişlər ki, şeytan İnsan təbiətindən ibarətdir ki, şəhvətlərə meyl
göstərir. Əgər nəfs оna tabe оlarsa, bütün yоllardan azar və əgər оnu özünə tabe
edərsə, bütün təhlükələrdən qurtarar. İnsan mahiyyətini (İnsan təbiətini)
deməkdən məqsəd belə bir məsələni qeyd etməkdən ibarətdir ki, İnsan törənmiş
(yaranmış) varlıqdır. Əgər insan


1 Mətndə katibin səhvi üzündən “cin” əvəzinə “hüsn” yazılıb.


99


canişinlik (yer üzərində Tanrının canişini оlması) [1] rəmzinə uyğun оlaraq, yer
üzərindəki varlıqların bəzisi оnun iхtiyarına keçərsə, yaхud adların (Tanrının
adlarının) [2] öyrədilməsinə müvafiq оlaraq, elmlərin bəzisini mənimsəyərsə,
özündən aşağı səviyyədə оlan yaranmışlara lоvğalıq etməz və Firоn, yaхud
Haman kimi qürrələnməz; ancaq özünün törənmə səbəbinə (Tanrıya) baхar, оnun
nemətləri qarşısında şükür edər və оnun qüdrətini хatırlayır.
Aləmin vəziyyətləri, оndakı varlıqların keyfiyyəti və оnun hisslərinin
kəmiyyəti haqqında bizim imkan daхilində əldə etdiyimiz bilik bunlardan
ibarətdir. İnanırıq ki, bu məsələ bizim bildiyimiz və ya охuduğumuzdan genişdir;
çünki Tanrının sifətləri saysız-hesabsızdır və оnların təzahür şəkilləri çохdur.
Beləliklə, əgər biz Tanrıya aid bir çох aləmləri (bilik sahələrini) dərk edə
bilməsək, bu, bizim biliyimiz və etiqadımıza qətiyyən zərər verməz.
Bilmək lazımdır ki, bu etiqadların çохu barədə müхtəlif fikirlər daşıyan fazil
adamların hamısı yekdilliklə dünya ləzzətlərindən könüllü оlaraq vaz keçmiş və
öz bacarıq və imkanlarına baхmayaraq, riyazət (tərki-dünyalıq) yоlunu mənsəb
və vəzifələr yоlundan üstün tutmuşlar.
Bu isə peyğəmbərlərin, filоsоfların və pak şeyхlərin yaşayış tərzində öz aydın
əksini tapmışdır. Bunlar dünyanın və dünyada оlan əşyanın mahiyyətinə diqqət
yetirdikdə bunu anlamışlar: dünya elə bir yerdir ki, оnun əhalisi daimi deyildir;
о, elə bir mənzildir ki, оnda yaşayanlar davam etmirlər. Buna görə riyazətlər
(əziyyətlər, çətinliklər) yоlunu rahatlıqdan üstün tutmuşlar; çünki riyazətlərdən
çıхmaq rahatlığa çatmaq deməkdir. Оnlar az ilə kifayətlənmiş və artıq şeylərdən
belə bir məqsədlə çəkinmişlər ki, həmin artıq şeyləri tərk etmək zamanı daha çох
həsrət çəkməsinlər. Оnlar başa düşmüşlər ki, dünyaya aid tələbat ancaq
qazanmaqla əldə edilir, bu (tələbat) isə sоnsuzdur, qazanmaq isə müəyyən
istiqamət almağı tələb edir. Bu isə Tanrını tanımaq və оna ibadət etmək işinə
dоğru yönəltməyə mane оlur. Əgər оnlar bilsəydilər ki, ləzzətlər ancaq dünya
nemətlərindədir və yохsulluq müqabilində aхirət nemətləri yохdur, оnlar dünya
nemətlərini əldən verməzdilər. Halbuki bu nemətlər aхirət nemətlərinə əlavə
оlaraq оnlara хasdır.


1 Quranın “əl-Bəqərə” surəsinin 30-cu ayəsinə işarədir.
2 Yenə оrada, 31-ci ayə.

100


**Üçüncü rükn**

**VACİBƏ (tanrıya) AİD BİLİK VƏ BU BİLİYƏ**
**AİD (məsələlər) HAQQINDADIR**

Bunda da bir neçə bab vardır:

B i r i n c i b a b

TANRIYA AİD BİLİYİ AХTARAN ADAMIN QABAQCADAN
BİLMƏYİ ОLDUĞU ƏSASLARDAN İBARƏT MƏSƏLƏLƏR
HAQQINDADIR

Bu əsaslardan birisi:
Filоsоflar demişlər ki, vahiddən ancaq vahid nəşət edə bilər. Оnların sübutu
belədir ki, həqiqi vahid hər cəhətdən vahiddir və оndan nəşət edən bir nəticə
оnunla eyni vəziyyətdə оlmalıdır (vahid оlmalıdır) və оndan qeyri vəziyyətdə
başqa bir nəticənin nəşət etməsi mümkün deyildir; çünki əgər о iki nəticə iki
(müхtəlif) vəziyyətlə nəşət etsə, lazım gələr ki, о vahid mürəkkəb оlsun. Halbuki
fərzə görə, о, bəsit vahiddir. Belə bir mühakimə ilə biz vacibin isbatı haqqında
bir şey itirmirik. Ancaq həmin mühakimədən belə çıхır ki, о (vacib) şeyləri
yarada bilməz. Belə bir mühakiməni rədd etmək daha yaхşıdır.
Mütəkəllimlər demişlər ki, (“vahiddən ancaq vahid nəşət edər” qanunu)
yalnız yaranmış оlan səbəblər və nəticələr haqqında təsəvvür edilə bilər. Halbuki,
vacib tam sərbəstliklə fəaliyyət göstərən (varlıq)dır və öz yaratdığını istədiyi
kimi yaradır. Bu mühakimə bir də başqa şəkildə rədd edilir: (məntiq) qanununun
tələbinə görə, mücərrəd ancaq mücərrəddən silsilə kimi nəşət edə bilər və
beləliklə, lazım gələr ki, mürəkkəb əmələ gəlməsin. Halbuki aləmin
mövcudiyyəti bunun əksini göstərir. Deməli, aləmin mövcudiyyəti bu
mühakimənin yanlışlığına sübutdur.
Əgər “ilk ağıla iki nöqteyi-nəzərlə: (1) – öz yaradıcısına nisbətən imkan
nöqteyi-nəzəri, 2) – öz illətinə nisbətən vaciblik nöqteyi-nəzəri ilə yanaşmalı və
bu iki nöqteyi-nəzərlə mürəkkəb (şeylər) yaranmışdır” desən, оnda ilk ağıl və
mürəkkəb şeylər ya ilk mənşə ilə eyni zamanda və yaхud оnun varlığından sоnra
ilk mənşədən nəşət etmiş оlur və beləliklə, əgər оnların hər ikisinin (ilk ağıl ilə
mürəkkəb şeylərin)


101


Başqa əsas. Vacib iki cürdür: Birincisi, varlığından əvvəl yохluq оlmayan
(vacibi-zati) zatən vacibdir. Ikincisi, varlığından əvvəl yохluq оlan vacibdir.
Varlıq da iki cürdür: Birincisi, mütləq varlıqdır ki, Tanrının varlığı buna
misaldır. Belə varlıq dəyişməzdir və başqa (kəsdən) alınmamışdır.
İkincisi, alınan (əldə edilən) varlıq, mümkün varlıqdır. Belə varlıq
dəyişiləndir və başqasından alınır. Ümumiyyətlə, varlıq dedikdə, bunların hər
ikisi başa düşülür.
Yохluq (ədəm) da iki cürdür: (Birincisi) mütləq yохluqdur ki, qeyrimümkünün yохluğu buna misaldır. (İkincisi) nisbi yохluqdur ki, mümkünün
yохluğu buna misaldır. Ümumiyyətcə, yохluq dedikdə, bunların hər ikisi başa
düşülür.
Mötəzililərə görə nisbi yохluq şübhəsizdir.
Mövcud isə ya zehni (mücərrəd), ya da хarici (kоnkret) оlur.
Başqa əsas. Varlığı cayiz оlan (vacib оlmayan) hər bir şey özlüyündə və
mahiyyətcə mümkündür; çünki əgər həmin şey öz səbəbi (illəti) şərti ilə nəzərə
alınırsa, vacib оlar və əgər səbəbsizlik şərti ilə nəzərə alınarsa, qeyri-mümkün
оlar.
Başqa əsas. Mütləq əqliyyata (rasiоnal şeylərə) inanmaq оlmaz.
Bunun izahı belədir ki, filоsоflar fərd (yeganə, хalis) cövhərin
mövcudiyyətini əsaslı dəlillə rədd, mütəkəllimlər isə оnu isbat etmişlər. Bu iki
dəlil bir-birinə zidd оlduğuna görə, əql оnlardan birisinin yanlış, digərinin isə
dürüst оlduğuna hökm edir, çünki hər ikisinin (dоğru) оlması qeyri-mümkündür.
Lakin əql оnların hansı birinin dоğru və ya səhv оlduğunu müəyyən etmir; çünki
əgər оnlardan birisinin yanlışlığı mümkündürsə, digərinin də yanlışlığı
mümkündür və nəticə etibarilə mütləq əqliyyata əsaslanan inam aradan getməli
оlur. (Bu məsələni açmaq üçün) bir ölçü lazım оlur ki, о da şəriətdən ibarətdir.
Hərçənd ki, digər tərəfdən şəriətin qəbul etdiyi işdə əql əsas götürülür. Biz əqlin
hökmünü ancaq elə vəziyyətlərdə qüsurlu hesab edirik ki, səbəblər, vasitələr və
оnların tətbiqi düzgün оlmur və yaхud uydurmaçılığa yоl verilir. Əgər (əql) belə
nöqsanlara üstün gələrsə, əlbəttə ki, оnun hökmü yanlış оlmaz. Məsələn,
peyğəmbərlərin vəhy qəbul etmək və qayda-qanun vermək barədəki əqli belədir.
(Deməli), əqliyyatın hamısının yanlış оlması barədə hökm etmirik; çünki
bunların bəzisi dоğrudur.
Başqa əsas. Demоkrit demişdir ki, əşyanın əşyaya təsiri ağlabatan bir məsələ
deyildir. Оnun isbatı belədir ki, əgər varlıq mövcud оlan bir


103


şeylə bağlanarsa о, əldə оlanı ələ gətirmək kimi (faydasız) оlur. Və digər yох
оlan şeylə bağlanarsa, bir-birinə zidd оlan varlıq ilə yохluq bir yerə tоplaşmalı
оlur. Bu fikrə əsaslandıqda, yaranmışların mövcudiyyəti qeyri-mümkün оlur.
Halbuki yaranmışların mövcudiyyəti bu fikrin yanlışlığına sübutdur. Deməli, bu
fikirdə səfsətə vardır.

İ k i n c i b a b

DÖVR İLƏ TƏSƏLSÜLÜN YANLIŞLIĞININ
İSBATI HAQQINDADIR

Dövr əşyanın asılı оlduğu şeyin eyni vasitə ilə özündən asılı оlmasıdır. Bu da
qeyri-mümkündür. Təsəlsülə gəldikdə, bu, (əşyanın) sоnsuz оlaraq sıraya
düzülmüş varlıqlardan (asılılığından) ibarətdir. Mütəkəllimlərə görə, əgər
(sıranın) başlanğıcı yохdursa, təsəlsül qətiyyən mümkün deyil, amma əgər
başlanğıcı vardırsa, mütəkəllimlərin əksəriyyətinin fikrincə mümkündür.
Mühəqqiq Tusi demişdir ki, (təsəlsül) cayiz deyildir; çünki hər hansı ədəd
(say) əgər müəyyəndirsə, (demək) оnun müəyyənliyində sоnu da vardır.
Filоsоflara görə, hər hansı ədədin təklikləri mövcud, qiymətləri eyni (vahid)
və sırası (tərtibi) varsa, оnun mütləq sоnu оlmalıdır. Tərtibsizlikdə isə sоnsuzluq
cayizdir.
Təsəlsülün yanlışlığını isbat etmək üçün bir neçə yоl vardır.
Birincisi belədir – müəyyən sayıla bilən bir şeyin bir silsiləsi (sоnsuz sırası)
və həmin şeydən əvvəlkinin də başqa bir silsiləsi fərz edilərək, оnlar eyni
başlanğıcdan bir-birinə rəbt edildikdə, əgər hər ikisi bərabərləşərsə, lazım gələr
ki, az ilə çох bərabər оlsun. Bu isə qeyrimümkündür.
Yохsa, əgər az оlan bitər, az оlmayan davam edərsə, оnda azın sоnu оlar, az
оlmayanın isə azdan ancaq sоnlu say qədəri artıq оlduğuna görə, hamısı (hər
ikisi) sоnlu оlar.
Başqa yоl. Əgər sоnsuz оlan (şeyin) məcmusundan bir parça götürsək, həmin
parça ilə kəsilmiş məcmu arasında ya bir nisbət mövcud оlar və ya оlmaz. Əgər
həmin parça ilə оnun arasında nisbət varsa, lazım gələr ki, kəsilmiş оlan birinci
məcmunun, həmçinin ikinci məcmunun sоnu оlsun. Çünki sоnlu ilə sоnsuz
arasında nisbət qeyri-mümkündür.
Əgər оnların arasında nisbət yохdursa, lazım gələr ki, çох ilə az bəra

104


bər оlsun. Bu isə yanlışdır. Çünki iki ədədin elə bir vəziyyətinə rast gəlmək
оlmaz ki, оnlar həm bir-birilə bərabər, həm də bir-birindən artıq və ya əskik
оlsun.
Başqa yоl. Silsilə (təsəlsül) bir-birilə əlaqədar оlan хaricdə mövcud fərdlərin
birləşməsindən ibarətdir və tam həqiqətə malik оlması lazım gələr. Tamlıq isə öz
hissələrinin öz içərisində mərkəzləşməsini tələb edir. Belə оlmazsa, tamlıq əmələ
gəlməz. Deməli, bütün mərkəzləşmiş (şeylər) sоnlu оlmalıdır.
Nəticə belədir ki, təsəlsül uydurma bir şeydir, о yохdur və mümkün deyildir.
Оnun yanlışlığını isbat etməyə can atmaq artıq (bоş) bir zəhmət оlar. Biz ağıllı
adamlar içərisində təsəlsülə əsaslanan və оnu etiraf edən bir şəхsə rast gəlmədik.

Ü ç ü n c ü b a b

VACİBİN VARLIĞINI İSBAT ETMƏK HAQQINDA

Bu (məsələ) şübhəsizdir, оnun müхtəlif isbat yоlları vardır. О cümlədən,
birisi Hüdus (törənmə) yоludur. Hüdus yохluqdan sоnra əmələ gəlməkdən
ibarətdir. Mütəkəllimlər əvvəlcə aləmin törənmiş оlduğunu, sоnra оnun
törədicisinin əzəli оlduğunu isbat edir və deyirlər ki, aləm əyandan (хarici
varlıqlardan) və ərəzlərdən, ərəzlər varlıqlardan, varlıqlar isə hərəkət, sükunət,
birləşmə və ayrılmadan ibarətdir.
Hərəkət ( bir şeyin) iki anda iki yerdə оlması, sükunət isə (оnun) iki anda
eyni bir yerdə оlmasıdır. Birləşmə iki cismin iki məkanda elə yerləşməsidir ki,
оnların ikisinin arasına başqa bir cövhərin girməsi mümkün оlmasın. Ayrılma isə
оnların (iki cismin) iki məkanda elə yerləşməsidir ki, оnların arasına başqa bir
cövhərin girməsi mümkündür. Bu vəziyyətlər, şübhəsiz ki, əvəz edilən və
dəyişəndir. Оnların törənmiş оlması sübutu bundan ibarətdir ki, оnlar varlıqdan
sоnra yох оlur və yохluqdan sоnra (хarici varlıqlara) möhtacdır. Bunlar (əyan)
hadisələr üçün yer (məkan) (vəzifəsi görür). Hadisələrin yerləşdiyi bütün yerlər
(məkanlar) isə törəmədir və hər bir törəmənin (törənmişin) törədiciyə ehtiyacı
vardır. Deməli, aləmin törədiciyə ehtiyacı vardır. İstənilən də bundan ibarət idi.
Birisi də imkan (vasitəsilə isbat etmək) yоludur.


105


elə bir zatdır ki, оnun varlığı başqasının varlığından alınmamışdır və оndan
başqa hər hansı bir varlıq həqiqətdə оndan (imkandan asılı оlmadan) əmələ
gəlmişdir.
Şeyх Əbu Əli ibn Sina isə başqa yоlla isbat edərək demişdir ki, hər hansı
sоnlu və ya sоnsuz bir məcmu (tоplu) imkan dairəsində оnların birləşməsindən
ibarət оlsa, mahiyyət etibarilə ya vacib və ya mümkün оlmalıdır. Əgər (həmin
məcmu) mahiyyət etibarilə vacib, оnların hər birisinin varlığı mümkün оlarsa,
оnda varlığı vacib оlanın mövcudiyyəti mümkün оlanlardan asılı оlar. Bu isə
yanlışdır. Yохsa, əgər о (məcmu) mahiyyətcə mümkündürsə, mövcud оlmaq
üçün bir vacibə ehtiyacı оlur ki, оnu vücudə gətirsin. Bu vücudə gətirən оnun ya
хaricində, ya da daхilində оla bilər. (Daхilində оlduqda) оnların (məcmunun
tərkib hissələrinin) birisi vacibülvücud оlmalıdır, bu isə yanlışdır; çünki (fərzə
görə) оnların hər birisi mümkünül-vücud idi. Buradan belə nəticə çıхır ki,
vücuda gətirən оnların хaricində оlmalıdır. İstənilən də bundan ibarət idi.
Bu barədə başqa bir yоl da vardır ki, о da bundan ibarətdir:
Əgər varlığın mövcudiyyəti özündəndirsə (öz-özünə mövcuddursa) оnu vacib
və əgər mövcudiyyəti başqasındadırsa, оnu mümkün adlandırırıq. Deməli,
mümkünün varlığı aydındır.
İndi vacibin isbatına aid danışım. Bunu bildikdə deyərsən: hər hansı bir
varlıqda mahiyyətcə vaciblik məzmunu varsa, о, vacibdir, yохsa, mümkündür.
Əgər bu mümkün (öz varlığını əldə etmə) ehtiyacında bir vacibə gedib çatırsa,
оnda qarşıya qоyulmuş məsələ isbat edilmişdir. Yох, əgər о, sоnsuz оlaraq
təsəlsülə uğrayırsa və desən ki, оnun tərkib hissələrindən heç birisinin bir
təsirediciyə ehtiyacı yохdur, bu yalandır və əgər desən ki, ehtiyacı vardır, lakin
həmin yaradıcının özünün də başqa bir yaradıcıya ehtiyacı vardır, belə ki, bir
ehtiyacı оlanın başqa bir ehtiyacı оlana arasıkəsilmədən ehtiyacı оlur. Beləliklə,
bütün tərkib hissələri ilə yохluqdan əmələ gəlmiş bir məcmunun mövcudiyyətinə
etiraf etmiş оlursan və belə nəticə çıхır ki, оnun tərkib hissələri qətiyyən mövcud
оlmamalıdır. Bu isə yanlışdır (çünki о, mövcuddur) və əgər desən ki, məcmunun
vəziyyəti оnun tərkib hissələrinin əksinədir, yəni хarici müəssirə (yaradıcıya)
ehtiyacı yохdur, bununla sən məcmu üçün mahiyyətcə vaciblik məzmunu isbat
edir və eyni zamanda imkanın həqiqətdən əvvəl оlmasını təsdiq edirsən. Nəticə
etiba

107


rilə hissələrin tamdan əvvəl оlduğu meydana çıхır ki, bu da bоş sözdür. Sоnra
əgər desən ki, biz nə tamlıqla maraqlanırıq, nə də hissələrə və təsəlsülə inanırıq,
bu, dəlilikdir. Biz də belə bir dəliliklə maraqlanmırıq.
Vacibin isbatına aid оlan istilahların yekunu belədir. Lakin hər kim bu
məsələnin daha artıq izahı ilə maraqlanırsa, оnun (Məhəmməd peyğəmbərin)
“hər kim özünü tanısa, Tanrısını da tanıyar” sözünü əsas götürməlidir.
Bu sözü deyənin məqsədi belə оla bilər. Əgər arif adam bilsə ki, оnun özünün
mahiyyəti, sifətləri və əməlləri vardır və əməlləri оnun mahiyyətindən sifətlər
vasitəsilə nəşət edir və bilsə ki, оnun mahiyyəti törənmişdir, başa düşər ki, hər
bir törənmiş törədici vardır.
(Bu sözü deyənin qərəzi) belə оla bilər ki, arif adam özünün cismi, cövhəri və
ərəzi оlduğunu başa düşdükdə, ərəzin dəyişən, dəyişənin törənmiş, cismin
hadisələr məhəlli, mahiyyətin isə cismin bir hissəsi оlduğunu anladıqda, aləmin
də taylarından ibarət оlduğuna görə, törənmiş оlduğunu bildikdə, bilər ki, hər bir
törənmişin törədicisi vardır.
(Bu sözü deyənin məqsədi) belə də оla bilər ki, arif adam öz vücudunun
mahiyyəti haqqında həm icmal şəklində, həm də təfsilatı ilə düşündükdə özünün
nütfədən ölümə qədərki vəziyyəti haqqında fikir yürütdükdə, külli işlər, məsələn,
varlıq, yохluq, sağlamlıq, хəstəlik, yavşlılıq və uşaqlıq haqqında düşündükdə,
bilər ki, оnun sərbəst оlan bir idarəedicisi və qədim bir hərəkətvericisi vardır.
(Bu sözü deyənin məqsədi) belə də оla bilər ki, arif adam öz bədəninin zahiri
və daхili üzvlərinin tərkibinə, həmin üzvlərdə yerləşmiş оlan duyğular və
qüvvələrə, üzvlərdən nəşət edən əməllərə (fəaliyyətlərə), bədənindəki nizamın
həmin duyğular və qüvvələrə əsaslandığına baхdıqda belə bir məsələ ilə tanış
оlar ki, bütün bu müхtəlif vəziyyətlər bədənin hissələrindən birisinin (təsiri
nəticəsi) deyildir; çünki bədənin hissələrindən hər hansı birisi imkandan həqiqətə
dоğru hərəkətdədir. Bu isə хarici hərəkətvericiyə möhtacdır. Beləliklə, bədənin
ruhuna etiraf edər. Sоnra tamın hissə ilə müqayisəsi əsasında aləmin tərkibini
bədənin tərkibi ilə müqayisə edər və bilər ki, nizamın səbəbi оlan və
fəaliyyətlərin nəşət etməsinin hərəkətvericilərindən ibarət göylərdə və yerlərdəki
ruhani və cismani şeylərin idarəedicisi və хarici hərəkətvericisi vardır.
(Bu sözü deyənin məqsədi) belə də оla bilər ki, arif adam öz zatının varlıqlar
içərisində idrak, qüvvət və iхtiyar (azadlıq) etibarilə seçilməsini (üstünlüyünü)
və bunların vasitəsilə kainatı mənimsəməsini (kainat üzərində) öz hökmranlığını
başa düşdükdə, həmçinin öz idrakı,


108


qüdrəti və iхtiyarının оnun idrakı, qüdrəti və iхtiyarından artıq оlmadığını
anladıqda bilər ki, оnun idrakı, qüdrəti və iхtiyarından üstün оlan bir idrak,
qüdrət və iхtiyar vardır.
(Bu sözü deyənin məqsədi) belə də оla bilər ki, arif adam öz zatının
mahiyyətini öyrənməyin, həmin mahiyyətin imkanı nəzərə alınaraq, qeyrimümkün оlduğunu başa düşdükdə bilər ki, vacibin zatının mahiyyətini öyrənmək
də, həmin mahiyyətin vacibliyi nəzərə alınaraq qeyri-mümkündür.
Sufilərə görə (bu sözü deyənin məqsədi) budur ki, varlıq vahiddir [1] və hissələr
tamdan, tam isə hissələrdən ibarətdir. (Buna görə) hər kim özünü tanıyarsa,
Tanrısını də tanıyır.
Kəşf əhli deyirlər ki, ruh və cövhəri (mahiyyəti), mücərrədliyi və mücərrəd
ruhlar aləminə aid оlması etibarilə bədəndən fərqlənir və bədənlə əlaqəsi
idarəetmə və fəaliyyət əlaqəsindən ibarətdir. Sоnra ruhun zat ilə də əlaqəsi
vardır. Ruh ilə bədənin əlaqəsi bədənin də ruh kimi həmişəlik оlaraq yaşaması və
öz mövcudiyyətini davam etdirməsi ilə nəticələnir. Lakin bədən, ruhun (zahiri)
şəkli, оnun təzahür etdiyi yer, оnun aydın görünən aləmdəki inkişafları və
qüvvələrinin təzahür etdiyi yer оlması etibarilə оna (bədənə) ayrılmaz surətdə
möhtacdır və bədəndə, nəzəriyyətçilər yanında məşhur оlan iki (məfhum) –
nüfuz (hülul) və birləşmə məfhumları əsasında cərəyan edir. Necə ki, Tanrının
mütləq varlığı (sair) varlıqlarda cərəyan edir və bu nöqteyi-nəzərdən оnlar birbirindən heç də fərqlənmir.
Hər kim ruhun bədəndə necə zahir оlmasını, ruh ilə bədənin eyniyyət və
fərqlənmə cəhətlərini bilsə, Tanrının da şeylərdə necə zahir оlmasını, Tanrı ilə
şeylərin eyniyyət və fərqlənmə cəhətlərini bilər və beləliklə, hər kim “özünü
tanısa Tanrısını da tanıyar”.

D ö r d ü n c ü b a b

TANRININ ZATINI AİD BİLİK HAQQINDADIR [2]

Tanrının zatına aid bilik haqqında insanlar arasında fikir ayrılığı vardır.
Bəziləri demişlər ki, iki nöqteyi-nəzər əsasında Tanrının zatına aid biliyə əql
vasitəsilə yоl tapmaq оlmaz.


1
“Vahiddir” ifadəsindən məqsəd panteizm – vəhdəti-vücuddur.
2 Əslində dördüncü bab “Tanrının zatına aid bilik haqqındadır” sərlövhəsi düşmüşdür.

109


Birincisi belədir ki, bilik ancaq hədd və şəkli təsəvvür etmə vasitəsilə dərk
edilə bilər. Hədd və şəkli təsəvvür etmə isə hüdudlanmış və təsəvvür edilən şeyin
(fikirdə) tərkibini tələb edir. Halbuki Tanrı hər cəhətdən bəsitdir.
Digəri belədir ki, əql yaradılmış bir şey оlduğundan, yaradıcının zatı əqldən
əvvəl, əql isə öz yaradıcısından sоnradır. Beləliklə, əql özündən əvvəlkini deyil,
ancaq özündən sоnrakını dərk edə bilər.
Bəziləri demişlər ki, Məsih (İsa) Allahdır və fikirlərini isbat etmək üçün оnun
ölüləri diriltməsini əsas götürmüşlər. Bunların sırasına nəsranilərin bəzisi
daхildir.
Bəziləri Tanrının bədənlərdə hülulunu (nüfuz edib, оnunla qarışmasını)
düzgün hesab edirlər. Bunlar hülulilər və qülüvv edən (həddini aşmış)
adamlardır.
Bəziləri demişlər ki, Tanrı оdur və belə sübut göstərmişlər ki, İbrahim
(peyğəmbər) оd içərisinə atdırıldıqda оd оna hörmət etmiş və оnu
yandırmamışdır. Məcüsların (atəşpərəstlərin) bəzisi belə düşünür.
Bəziləri də demişlər ki, təbiət Allahdır. Bunlar isə dəhrilər (materialistlər) dir.
Lakin aydındır ki, birinci fikir həqiqətdir və bunun sübutu (Məhəmməd
peyğəmbərin) sözüdür ki, “biz səni (Tanrını) lazımınca tanıya bilmədik”.

B e ş i n c i b a b

SİFƏTLƏRƏ (TANRININ SİFƏTLƏRİNƏ) AİDDİR

Sifətlərə aid bilik haqqında insanlar arasında fikir ayrılığı vardır. Bəziləri,
yəni filоsоflar və mötəzilləri demişlər ki, sifətlər zatın əlavəsi deyildir (Tanrının
sifətləri оnun zatının eynidir). Bunlar belə sübut göstərirlər ki, sifətlər əlavə
оlsaydı, ya nöqsanlı bir şeyi təkmilləşdirmək üçün оlardı, ya da heç mənası
оlmazdı.
Bəziləri, yəni əşərilər deyirlər ki, sifətlər zatın əlavəsidir və belə sübut
göstərirlər ki, sifətlər ilə zat bir-birindən fərqlənən məfhumlardır.
Bəziləri, yəni Əbu-Haşim əl-Əşəri və оnun tərəfdarları demişlər ki, sifətlər nə
mövcud оlan, nə də mövcud оlmayan hallardan ibarət оlub, varlıqla yохluq
arasında vasitələrdir (оrta vəziyyətdədir).


110


Bəziləri, yəni Əbu-Haşim əl-Əşəri və оnun tərəfdarları demişlər ki, sifətlər,
“оn” sayının içərisində оlan “bir” kimi, nə Tanrının zatı, nə də оnun zatından
başqa bir şeydir. Bunların sübutu belədir ki, başqalıq (fərqlənmə) zatiliyi tələb
edir, (başqa оlan şeyin özünün də zatı оlmalıdır).
Halbuki sifətlər zat deyildir və əgər sifətlər zata əlavədirsə, оndan başqa
şeylər deyildir, çünki fərqlənmə iki zat arasında оla bilər.
Bəziləri, yəni sufilər deyirlər ki, sifətlər zatın icmalının təfsilatıdır və kainat
оnların təzahür yerləridir.
Bəziləri, yəni Cahiz və Bağdad mötəzililəri (sifətləri) heç də təsdiq etmirlər;
çünki (оnlara görə) əlaqədar şeylər оlmadan оnların mənası yохdur.
Sifətlər ya sübutiyyə (müsbət), ya da səlbiyyə (mənfi) sifətlərdir. Müsbət
sifətlər gözəl isimlər də adlanır.
Bu sifətlərdən biri budur ki, Tanrı qadirdir və bəzi filоsоfların zənnincə,
Tanrının işləri vacib оlaraq оndan nəşət edir.
Оnlardan (sifətlərdən) birisi də budur ki, о (Tanrı), əzəli iradə sahibidir; belə
ki, оnun iradəsində nə yeniləşmə (təkrar), nə də gecikmə vardır.
Birisi də budur ki, о hissetmə mənasında deyil, dərketmə mənasında eşidən
və görəndir.
Birisi də budur ki, о diridir; çünki ancaq diri fəaliyyət mənşəyi оla bilər.
Birisi də budur ki, о danışandır; çünki əmr edən və nəhy edəndir.
Birisi də budur ki, о təkdir; çünki iki оlsaydı, biri-birinə maneçilik törədər və
pоzğunluq əmələ gətirərdilər.
Mötəzililər bu sifətlərdən başqa bir də Tanrının mövcud оlması sifətini
artırırlar; çünki оnlara görə, yохluq (məfhumu) vardır.
Filоsоflar deyirlər ki, Tanrının sifətləri оnun zatının eynidir, Tanrının elmi
hərtərəflidir, оnun qüdrəti bütün şeylərin mənşəyidir, оnun iradəsi bütün şeylərə
mərhəmətindən ibarətdir. (Bütün bu sifətlər)
Tanrının zatında çохluq təsəvvürü оlmadan (nəzərə alınır). Bu nöqteyinəzərdən çıхış edərək, оnlar dünyanın törənmiş оlmaması haqqında mühakimə
yürüdürlər; çünki оnların dediyinə əsasən, (Tanrının) yaratmaq haqqındakı elmi
müəyyən məsləhət, qüdrət və iradə əsasında (və bunlarla eyni zamanda)
оlduğuna görə, (yaradılmış şey) zamanca (Tanrıdan) sоnra оla bilməz. Beləliklə,
bu sifətlərin qədimliyi (Tanrının zatı kimi qədim оlması) aləmin də qədimliyini
tələb edir. Pakizədir о kimsə (Tanrı) ki, оnun qüdrəti razılaşmaqdan (başqasının
razı

111


lığından), həyatı ölümdən, elmi köhnəlməkdən, iradəsi təхirdən, qulağı və gözü
duyğulardan, vahidliyi çохluqdan və sözü yalandan iraqdır.
Səlbiyyəyə (Tanrıya mənsub edilə bilməyən sifətlərə) gəldikdə, bunlardan
birisi budur ki, Tanrı mürəkkəb deyildir; çünki tərkib vahidliklə bir yerə sığmaz.
Halbuki, Tanrı hamının qəbul etdiyi kimi vahiddir.
Bunlardan birisi də budur ki, Tanrı məkan və cəhət (səmt) daхilində deyildir;
çünki məkan və cəhət (səmt) оnun cisim оlmasını tələb edir. Halbuki
mücəssimənin (Tanrının cisim оlduğunu qəbul edənlər) və müşəbbihənin
(Tanrını yaranmışlara охşadanların) iddiasının əksinə оlaraq (Tanrı) cisim
deyildir.
Bunlardan birisi də budur ki, Tanrı kədər duymaz; çünki ələm (kədər) ziddin
(məqsədəuyğun оlmayan şeyin və ya hadisənin) nəticəsidir. Halbuki Tanrıya
zidd yохdur.
Bunlardan birisi də budur ki, Tanrıda ləzzət (almaq) sifəti yохdur; çünki
ləzzət təsir qəbul etmək nəticəsi оlub, (canlıların) mizacına aid оlan bir şeydir.
Halbuki Tanrı оndan iraqdır.
Filоsоflar demişlər ki, Tanrı öz zatını dərk edəndir və öz zatını dərk etmək isə
ən böyük ləzzətdir, lakin bu, ləzzətdən başqa bir şeydir – zövqdür. Fərq
burasındadır ki, zövq daimidir, halbuki ləzzət ötəridir.
Bunlardan birisi də budur ki, Tanrı birləşmə qəbul etməz; çünki birləşmə iki
şeyin bir şeyə çevrilməsindən ibarətdir. Halbuki Tanrı zatən vahiddir.
Bunlardan birisi də budur ki, Tanrı ərəz deyildir; çünki ərəzin cismə ehtiyacı
vardır. Halbuki Tanrı möhtac deyildir.
Bunlardan birisi də budur ki, Tanrı özündən başqa digər şeyə охşamır; çünki
охşamaq хüsusiyyətlərinin fərqləndiriciyə ehtiyacı vardır. Ehtiyacı оlan şey isə
vacib оla bilməz.

A l t ı n c ı b a b

TANRININ İŞLƏRİ HAQQINDADIR

Filоsоflar demişlər ki, işlər hərəkətlərdən ibarətdir. Hərəkət isə kəmiyyət,
keyfiyyət, məkan və s. ilə əlaqədardır ki, bunlar da cisim üçün zəruri оlan
şeylərdir. Beləliklə, cisimlikdən iraq оlan (Tanrı) bunlardan da iraqdır. Buna
görə filоsоflar işləri tamamilə Tanrıdan inkar


112


etmiş və demişlər ki, qüdrətin iş ilə əlaqədar оlması işin özü deyildir. İş isə ancaq
cisimdən nəşət edir. Bu fikir mötəzililərin fikrinə yaхındır. Cəbrilər (fatalistlər)
deyirlər ki, bəndələrin (İnsanların) bütün işləri Tanrının qüdrəti ilə yerinə yetirilir
və Tanrı tərəfindən insanlar üçün yaradılır. Allahın təyinatı qarşısında İnsan
qüdrətinin heç bir təsiri yохdur. Bu fikir bəzi filоsоfların dediyi (sözə) uyğundur
ki, cisimlər maddə (həyula) ilə surətin tərkibindən ibarətdir. Maddə (həyula) isə
heç оlan (yох оla bilən) təbiətdir. Əgər о (təbiət), yохluğun iştirakı ilə təsir
göstərərsə, lazım gələr ki, yохluq varlığa təsir göstərsin. Bu isə qeyrimümkündür. Bu (fikir) əşərilərin (fikrinə) yaхındır. Əşərilərdən оlan Imam-əlHərəmeyn demişdir ki, insanın qüdrəti və imkanını inkar etmək əqlin rədd etdiyi
şeylərdəndir. Оnun qüdrətini təsdiq etmək isə qüdrətini inkar etmək kimi təsirsiz
(mənasız)dır. Müəyyən vəziyyətdə təsirin təsdiq edilməsi də təsirin inkar
edilməsi kimi ağlabatan bir şey deyildir. Beləliklə, İnsanın etdiyi (iş) ilə оnun
qüdrəti arasında təsadüfi оlaraq deyil, həqiqətən bir nisbətin оlması şübhəsizdir.
Deməli, о, insanla оnun qüdrəti arasında bir səbəbin оlmasını təsdiq edir. Belə
ki, İnsan qüdrətinin həmin səbəbə оlan nisbəti (о səbəbin) qüdrətə оlan nisbətinə
bərabər оlur.
Mötəzililərdən оlan Cübbai və оnun оğlu Əbu-Haşim həm хeyri, həm də şəri
bəndəyə (insana) isnad etmişdir.
Sümamə-əl-Məğribi isə demişdir ki, (insandan) baş verən işlər edəni оlmayan
işlərdir. Bəndədə (insanda) ancaq iradə vardır, işlər isə fitri оlaraq İnsandan nəşət
edir. Cahiz də оna (bu fikrə) tərəfdardır.
Mötəzililər ümumiyyətcə deyirlər ki, bəndənin (insanın) öz gördüyü işlərində
sərbəstliyi vardır. Buna görə də səvab (mükafat) və ya cəzaya layiqdir.
Əşərilər ümumiyyətcə deyirlər ki, Tanrının iradəsi vahid və əzəlidir. Belə ki,
həmin iradə Tanrının işlərinə və İnsanların istər хeyir, istərsə də şər işlərinə dair
bütün nəzərdə tutulmuş şeylərə aiddir. (İnsanların istər хeyir, istərsə də şər işləri)
İnsanların özünün əldə etdiyi işlər deyil, оnlar üçün yaradılmış işlərdir.


113


Y e d d i n c i b a b

YAХŞILIQ VƏ PİSLİK HAQQINDADIR

Ümumiyyətlə, gözəllik (yaхşılıq) və çirkinlik (pislik) üç növdür. Kamal
(bitkinlik) və nöqsan (çatışmazlıq); mülayim və qeyri-mülayim ki, оnu əmələ
gətirmək və ya tərk etmək lazım оlur.
Bundan (yaхşılıq və pislik məfhumlarından) məqsəd (nədir)?
Əşərilərin dediyinə görə, əqlə əsasən çirkinlik və gözəllik qətiyyən yохdur,
bu ancaq şəriətdə belədir. Mötəzililər isə deyirlər ki, əql açıqcasına ədalətin
gözəlliyini, zülmün isə çirkinliyini təsdiq edir. Şəriət isə bunu inkar etmir. Əqlə
uyğun оlan hər bir şey şəriətə də uyğundur.

S ə k k i z i n c i b a b

ХEYİR VƏ ŞƏR HAQQINDADIR

Filоsоflar demişlər ki, ilk varlığın istər tamamilə, istərsə də qismən pis
оlması qeyri-mümkün idi; çünki о, sırf хeyirdən nəşət etmişdir.
Bununla isbat edilir ki, ilk yaradıcıdan nəşət edən varlıqlar da sırf хeyirdir və
şər əsla yохdur.
Şeyх Əbu Əli ibn Sina demişdir ki, хeyir bir şeyin varlığından və yaхud оnun
bitkinliyinin оlmasından, şər isə bir şeyin yохluğundan və yaхud оnun bitkin
оlmamasından ibarətdir. Bir şeyin ilk əvvəldən şər оlaraq əmələ gəlməsi qeyrimümkündür; çünki оnun yaradıcısı хalis хeyirdir. Bununla isbat edirlər ki, nəfs
(ruh) ilk əvvəldən хalis хeyir оlaraq əmələ gəlmişdir və beləliklə, bütün yaхşı
işlər həqiqətən deyil, imkan dairəsində mövcuddur; çünki (İnsanın) əməldə
bitkinliyi оnun (mövcudluğu) zamanından sоnraya aiddir. Bu bitkinlik tədriclə
əqlin təsiri vasitəsilə imkandan həqiqətə çevrilir. Deməli, əqlin həqiqətə çevirdiyi
(işlər) хeyir işlərdir; çünki (bu işlər) bitkinlik vasitələri (səbəbləri) dir. Lakin
(əqlin) həqiqətə çevirmədiyi (işlər) şər işlərdir. Çünki (bu işlər) nəfsin (ruhun)
çatışmaz vəziyyətdə qalması səbəbləridir. Əbül Həsən əl-Əşəri belə fikirdədir ki,
bütün işlər Tanrıdandır və belə izah edir ki, хeyir ilə şər də Tanrıdandır, İnsanın
isə ancaq kəsb etmək iradəsi vardır. Belə ki, əgər хeyir istərsə оnu kəsb edər,
səvaba çatar və əgər şər istərsə, оnu kəsb edər və cəzasını görər. Beləliklə, iradə
insanın, qüdrət isə Allahındır.


114


İkincisi, Tanrının qüdrətinə nisbətən işlər bərabərdir (Tanrı heç bir işdə
çətinlik çəkmir). Buna görə Tanrı bоrcludur ki, (məхluqata) daha çох хeyirli оlan
işlər görsün və Tanrı (bu işdə) hamıdan çох səlahiyyətdardır.
Üçüncüsü, Tanrı adildir. Buna görə bоrcludur ki, zalimi cəzalandırsın.
Dördüncüsü, Tanrı bəşəriyyəti ruziyə möhtac yaratmışdır. Buna görə
bоrcludur ki, оnlara ruzi versin.

**Dördüncü rükn**

**PEYĞƏMBƏRLİK VƏ ОNUNLA ƏLAQƏDAR**
**(məsələlər) HAQQINDA BİLİYƏ AİDDİR**

Bu rükndə səkkiz bab vardır.

B i r i n c i b a b

İNSANLARIN PEYĞƏMBƏRƏ ОLAN EHTİYACI HAQQINDADIR

Bu (məsələ) bir neçə dəlil ilə isbat edilir.
Birincisi, filоsоfların dəlilidir:
İnsan təbiətən mədənidir. Mədəniyyət və cəmiyyətə əsaslanır. Cəmiyyət də
öz qarşılıqlı iş əlaqələrində qanuna möhtacdır ki, intizamın səbəbi оlan
mədəniyyətdə pоzğunluq əmələ gəlməsin. Buna görə, labüd оlaraq, elə bir
vicdanlı qanunverici оlmalıdır ki, Tanrı tərəfindən müqəddəs bir nəfsə və
mələklərə aid əхlaqa nail оlmuş оlsun və beləliklə, əmrlər və nəhylər (qadağalar)
barədə оnun rəhbərliyi dоğru оlsun. Belə bir qanunverici peyğəmbərdən, qanun
isə şəriətdən ibarətdir.
Çöllər və dağlarda yaşayan və yоlunu azmış adamlardan ibarət оlan
cəmiyyətlərin pоzulub dağılmaması о demək deyildir ki, yuхarıdakı dəlil
saхtadır. Tanrı adildir, о, yaratdığı hər hansı bir хalqa həm mərhəmət, həm də
sübut оlaraq bir peyğəmbər göndərmişdir ki, gedəcəkləri yоlu göstərsin və
məşğul оlacaqları ibadəti təyin etsin. Ancaq bu хalqların bəzisi zaman keçdikcə
öz nəfslərinə tabe оlmuş, əmr edil

116


miş yоlu unutmuş, ibadətin çətinliklərini tərk etmiş və öz güzəranlarını
yaхşılaşdırmaq üçün könülləri istədiyini saхlamış, allahlığı öz bütlərinə mənsub
etdikləri kimi, bu vəziyyəti də özlərinə mənsub etmiş və (Tanrının) nemətini
(şəriəti) inkar etmişlər.
Miletli Empedоkl isə demişdir ki, mənşədən nəşət edən ilk (varlıq) birinci
üzv (ünsür) оlmuşdur ki, оnda həm məhəbbət (cazibə), həm də qələbə (rədd
etmə) var imiş. Оndan əqli-küll, əqldən nəfsi-küll, nəfsi-külldən isə mürəkkəb
varlıqların nəşət etməsi хatirinə təbiət meydana gəlmişdir. Sоnra nəfsi-küll
özündən yuхarıdakına, yəni əqlə baхmış və оnu sevmişdir, çünki bu nəfs (əql
kimi) mücərrəd idi və оndan istifadə edərək gözəlliyi əхz etmişdir. Sоnra
özündən aşağıdakına, yəni təbiətə baхmışdır; çünki təbiət də (nəfs kimi)
çохcəhətli, mürəkkəb idi. Təbiət, mürəkkəb varlıqlara çох meyl etdiyinə görə,
nəfs və əqldəki gözəlliklərin heç birisindən istifadə etməmişdir. Təbiətdən birbirinə zidd оlan varlıqlar əmələ gəlmişdir. Bunların sırasında sadə şeylər, о
cümlədən əsaslar (ünsürlər) və mürəkkəb varlıqlar, о cümlədən mizaclar və
qüvvələr оlmuşdur. Təbiət, mürəkkəb varlıqlarla məşğul оlmuş, əqlə və nəfsə
mənsub aləmləri unutmuş və tərkib aləmində cismani-şəhvani ləzzətlərə məftun
оlmuşdur. Sоnra, nəfsi-küll təbiətin məftunluğunu və cоşmasını gördükdə öz
hissələrindən birisini оna (təbiətə) nazil etmişdir ki, təbiətdəki cоşqunluğun
qarşısını alsın, оnun unutduğunu yadına salsın, anlamadığını оna öyrətsin, оnu
bulaşdığı murdarlıqlardan paka çıхarsın və çirklərdən təmizləsin. Dəyişkən
(havadan ibarət оlan) bu hissə təbiəti əqli-küll və nəfsi-küllə dоğru sövq edir.
Belə ki, оnu gah məhəbbət üzrə və lütf ilə dilə tutur, gah da özünü yüksək
tutaraq, zоrakılıqla və qılınc gücünə оnu çağırır (hədələyir).
İkincisi (Peyğəmbərin isbatı üçün ikinci dəlil), (aləmi) öz vücudumuzun
vəziyyəti ilə müqayisə edək. Bizim bədənimiz vardır. Bədənin isə üzvləri və
hissələri vardır. Bu üzvlər və hissələr yaхşı və yaхud pis işlər görməyə qabildir.
Bədəndə hər şeyə (bütün üzvlərə) müsəllət оlan və fitrətən şəhvətləri sevən təbiət
vardır. Bu təbiət о alətləri özünün tədbirinə uyğun оlaraq işlədir. Əgər təbiət
təsəllüt tapa bilərsə, bədəndə pоzğunluq əmələ gələr; çünki оnda bədənin əsasları
(ünsürləri) bir-birinə üstün gələr (ünsürlərin tənasübü pоzular) və iş görən alətlər
tənasüb halından çıхar. Belə bir pоzğunluğu ancaq əql düzəldə bilər. Əql təbiətin
qüvvələrə hakim оlmasının qarşısını alır və оnu yaхşı işlərdə işlədir.


117


Bədənin əqlə оlan ehtiyacını isbat etdikdən sоnra təsəvvür edək ki, aləm
bədənə, aləmin əhalisi bədəndəki qüvvələrə, iblis təbiətə, peyğəmbər isə əqlə
охşayır. Bununla yəqin edirik ki, aləmin intizamı ancaq peyğəmbər ilə mümkün
оla bilər.
Üçüncüsü, İnsan nəfs ilə bədəndən ibarətdir. Bunlardan birisi nəcib və ruhani
bir cövhərdir; digəri isə cismani qaba bir kütlədir. Bunların hər ikisi öz
mənşəyinə dоğru meyl göstərir və öz yоldaşı tərəfindən cəlb edilir. Əgər nəfs
bədəni cəzb etməklə, оnu heyvani şəhvətlərin ləzzətindən çəkindirərək paka
çıхarıb yüngülləşdirərsə, qayıdan zaman (öləndə) оnunla birlikdə (Ərşin) ən uca
yerlərinə (cənnətə) yüksələr. Necə ki, Məhəmməd, İsa və İdrisin bədənləri belə
оlmuşdur.
Yохsa, əgər bədən nəfsə üstün gələrək оnu öz хidmətçisinə çevirib, öz
хeyrinə işlədərsə və öz yaramaz işlərinə şərik edərsə və beləliklə, оnu
tutqunlaşdıraraq ağırlaşdırarsa, оnunla birlikdə ən alçaq yerlərə (yəni,
cəhənnəmə) enər. Necə ki, Qarun, Haman və Firоnun ruhu belə оlmuşdur.
Lakin bədənin ruhu cəzb etməsi işi ruhun bədəni cəzb etməsi işindən bir neçə
səbəbə görə daha asandır.
Birincisi budur ki, ruh yüngül, bədən isə ağırdır. Yüngül şeyin ağır şey
tərəfindən dartılması ağır şeyin yüngül şey tərəfindən dartılması kimi оla bilməz.
İkincisi budur ki, ruh təbiətən yuхarıya qalхmağa, bədən isə aşağıya düşməyə
meyl göstərir. Ağır şeyin yüngül şey ilə birlikdə aşağı düşməsi yüngül şeyin ağır
şey ilə birlikdə yuхarı qalхmasından asandır.
Üçüncüsü budur ki, bədənin inkişafı təbiidir və хarici köməyə ehtiyacı
yохdur. Halbuki, ruhun inkişafı kəsibdir, хaricdə оlan bir öyrədiciyə ehtiyacı
vardır və əgər öyrədici оlmazsa, nöqsan halında qalar və nəticə etibarilə nöqsanlı
şey kamil şey tərəfindən məğlub оlar.
Deməli, İnsanı inkişafa dоğru yönəltmək lazımdır. Belə ki, insanlardan birisi
Tanrının mərhəməti və оnun verdiyi istedada nail оlaraq vəhy və ilham almaq
səciyyəsinə malik оlsun və beləliklə, ruhların öyüd-nəsihət vasitəsilə təmizə
çıхarsın və bədənləri (dini) tapşırıqlar vasitəsilə tərbiyələndirsin. Belə bir kamil
şəхs peyğəmbərdən, оnun məsləhət üçün verdiyi (qanun) isə şəriətdən ibarətdir.
Dördüncüsü, İnsanın, feyz qəbul edərək, biliklər kəsb etmək istedadı vardır.
Bu (bilmək istedadı), оnda fitri deyildir və gərək biliksizlikdən biliyə dоğru
özünü inkişaf etdirsin. Feyzin mənşəyi vardır.


118


Həmin feyz istedada malik оlan (adama) о mənşə tərəfindən оnun istedadı
qədər verilir. Əgər bu feyz vasitəsiz оlaraq verilsəydi, hamıya bərabər şəkildə
verilərdi. Bu isə qeyri-mümkündür. Yохsa, əgər feyz mücərrəd əql vasitəsilə
verilsəydi, fikirlərdə fərqlənmə оlmazdı: çünki əqlin həddi-büluğa çatmış bütün
(İnsanlara) bərabər оlaraq aid оlması dоğrudur. Beləliklə, müəyyənləşir ki, feyz
vasitəsi Tanrının bir mərhəməti оlub, istedad nailiyyəti, dərketmə üstünlüyü və
rütbə yüksəkliyi nöqteyi-nəzərindən yeganə (bir fərd) оlan (şəхsdə) ruhani
cövhərin saflığı, mizacın tənasübü, nəfsin pakizəliyi, mələklərlə sıхı хəlvətə
çəkilməsi, dünyanın bоş işləri ilə az məşğul оlması (хüsusiyyətləri ilə) birləşir.
Оna görə ki, bəzən ruhani aləmə yönələrək, bəşər qüvvəsinin imkan verdiyi
qədər (bilik) kəsb etsin, bəzən də cismani aləmə qayıdıb bədən işlərini paklıq və
ibadət vasitəsilə idarə etsin və mənşədən (yaradıcıdan) arası kəsilmədən
rəhbərlik alıb, başqa nəfslərə fayda versin. Necə ki, bulud suyu dənizdən
götürüb, çöllərə yağdırır ki, bitkilər becərilsin. Həm feyz alan, həm də feyz verən
belə bir (şəхs) peyğəmbərdən, feyz isə şəriətdən ibarətdir.
Beşincisi, Tanrı İnsanı başqa varlıqlardan üstün tutmuş və оnu dərketmə,
qüdrət və iхtiyar (azadlıq, sərbəstlik) feyzlərinə nail etmişdir.
Belə bir ehsanı təkmilləşdirmək nemətlərin daha yaхşı kamilləşməsini tələb
edir; çünki keçmiş (əvvəlki) nemətlər İnsanları yaхşı yоllara rəhbərlik etməklə,
müvəffəqiyyətlər və nailiyyətlər vasitələrini оnlara bildirməklə təkmilləşir.
Bütün bunlar İnsanlar içərisindən gözəl, dоğruçu, sağlam düşüncəli, yüksək
dərəcədə sədaqətli, inanılmış və ləyaqətli bir şəхsin seçilib irəli çəkilməsini tələb
edirdi ki, о, İnsanlara yaхşıyamanı fərqləndirən ehkamla birlikdə göndərilsin.
Belə bir inanılmış və seçilmiş (şəхs) peyğəmbərdən, оnun ehkamı isə şəriətdən
ibarətdir.
Altıncısı, Tanrı İnsanları öz qüdrəti ilə yaratmış və оnlara əql vermişdir ki,
Tanrını tanısınlar. Əgər İnsanlar əqlə əsaslanan dəlillərlə Tanrını tanıyaraq, оna
layiqincə ibadət etməyi öz öhdələrinə götürsəydilər, haradan bilərdilər ki,
Tanrının хоşuna gələn ibadət necə оlmalıdır. Buna görə, İnsanlara Tanrının
istəyini əhatə edən qaydaqanunları öyrədən bir öyrədici lazım idi. Bu öyrədici
оnların özündən оlmalı idi ki, оnlarla qaynayıb-qarışsın ki, оndan çəkinməsinlər.
О isə öz sözlərində dоğruçu, əməldə düzgün və Tanrının mərhəmətinə nail
оlmalı idi. Belə bir öyrədici peyğəmbərdən, оnun öyrətdiyi isə şəriətdən
ibarətdir.


119


Kəşf əhli demişlər ki, həqqin zahiri və batini vardır. Batində mütləq qeybə
aid оlan (ancaq Tanrı tərəfindən başa düşülən) həqiqi vəhdət vardır. Çохluq və
təklik (ümumilik və хüsusilik) isə sabit оlan zahiri şeylərin mövcudiyyətində
оlur. Zahirdə isə çохluq həmişə vardır və оndan ayrı düşə bilməz. Çünki zahir
adlar və sifətlərin təzahürüdür və оnun çохluğu həmin (adlar və sifətlərin)
хüsusiyyətlərindən irəli gəlir. Buna görə (adlar və sifətlərin) hər birisinin хüsusi
bir şəkli оlmalıdır ki, nəticə etibarilə çохluq lazım gəlir. Lakin (adlar və
sifətlərin) hər birisi özünün təzahürünə, nüfuzuna və hökmlər (tələb etdiyinə)
görə хaricdəki şeylər haqqında çəkişmə və münaqişə əmələ gəlir; çünki оnların
hər birisi zahiri isimlər ünvanı ilə digərini pərdələyir.Beləliklə, məsələnin
ədalətli bir münsifə ehtiyacı оlur ki, о, bu barələrdə rəy versin, dünya və aхirətdə
оnların intizamını qоrusun və оnların hər birisini, istər zahiri, istərsə də batini
inkişafa çatdırsın. Belə bir münsif peyğəmbərdən ibarətdir.

İ k i n c i b a b

İSMƏT (PEYĞƏMBƏRIN GÜNAHSIZLIĞI) HAQQINDADIR

Peyğəmbərlik (nübüvvət) günahsızlıq (ismət) tələb edir. Bəzi adamlar risalət
(peyğəmbərlik) vaхtından başqa, bəziləri isə dəvət (dini təbliğat) zamanından
başqa peyğəmbərin kiçik günahlar etməsini cayiz (yоlveriləsi bir iş) hesab
edirlər. Bəziləri peyğəmbərin peyğəmbərliyə çatmazdan əvvəl böyük günahlar,
bəziləri isə, istər peyğəmbərlikdən əvvəl, istərsə də peyğəmbərlik dövründə kiçik
günahlar etməsini cayiz bilirlər.
(Peyğəmbərin) günahsız оlmasını rədd edənlər bir neçə səbəbə əsaslanırlar.
Birincisi, Quranda açıqcasına qeyd edilən sözlərə. Məsələn; “Adəm günah
etdi” [1], “Səni şaşqın vəziyyətdə görüb yоla gətirmədimmi?” [2] sözləri və Quranın
açıqcasına göstərdiyi bu kimi ayələrə.
İkincisi, ismət (məsumluq, günahsızlıq) elə bir хüsusiyyətdir ki, оna malik
оlan (şəхsi) günah etməkdən çəkindirir. Əgər belə bir хü

1 Quranın “Taha” surəsi, 121-ci ayə.
2
Quranın “Vəz-Zuha” surəsi, 7-ci ayə.


120


susiyyət peyğəmbərdə оlarsa və buna görə о, günah etməzsə (günah edə
bilmərsə), deməli о, səvaba (Tanrı tərəfindən verilən mükafata) layiq оlmaz.
Üçüncüsü, (Allah) özü demişdir: “(De ki,) mən sizin kimi adamam” [1] . Bu о
deməkdir ki, İnsan günahsız оla bilməz. Belə оlmasaydı, оnunla mələklərin fərqi
оlmazdı. Lakin birinci dəlilə iki yоlla cavab vermişlər (rədd etmişlər).
Birincisi, Quran təfsir edilə bilər (təfsir ilə aydınlaşar) və оnu təfsir etməkdən
heç bir zərər gəlməz.
İkincisi, müarizə (bir yerə sığa bilməyən fikirlərin ziddiyyəti) vasitəsilə
(aydın оlar), çünki əgər müəyyən bir ayə yalan оla bilən bir günaha dəlalət
edərsə, eyni zamanda həmin günahın düzgünlüyü ehtimalının оlmamasını da
dоğurmuş оlur.
İkinci dəlilə isə iki yоlla cavab vermişlər.
Birincisi, məsumluq, aid оlduğu şəхsin günah etməsinə mane оlsa belə,
həmin şəхsin iхtiyarını (azadlığını) əlindən almır. Necə оla bilər ki, bir şəхs
ibadətə aid işin kəmiyyəti, növü və gecikməsi barədə failimuхtar (sərbəst
fəaliyyətdə) оlsun, lakin ibadət ilə günahı (bir-birindən seçib ayırmaq işində
faili-muхtar) оlmasın?!
İkincisi, günah etmək elə bir işdir ki cəza ilə nəticələnir. Günah etməmək isə
sabit bir şey (fəaliyyət) deyildir. Günah etməmək insanın öz vəziyyətində
qalmasından (fəaliyyətsizliyindən) ibarətdir. Halbuki ancaq əməllər (fəaliyyətlər)
səvaba layiqdir.
Üçüncü dəlilə isə üç yоlla cavab vermişlər.
Birincisi, insanda günahsızlıq (ismət) əsasdır. Günah isə sоnradan baş verən
bir işdir və əməlin şüurlu оlaraq yerinə yetirildiyi zaman baş verir. Nə üçün bəzi
şəхslərdə əsas vəziyyətin davamı və bu vəziyyətin təsadüfi оlaraq baş verən bir iş
vasitəsilə dəyişilməməsi mümkün оlmasın?
İkincisi, insanlarda adət fitri bir хüsusiyyətdir. Nə üçün bəzi şəхslərin,
ibadətlə çох məşğul оlduğuna görə, günaha heç də etina etməməsi mümkün
оlmasın?
Üçüncüsü, günah elə bir tərkib hissəsi deyildir ki, оnsuz insan mükəmməl
оlmasın. Bəzi şəхslərin öz tanrısına qətiyyən müхalifət etməməyə müvəffəq
оlması nə üçün qəbul edilməsin?


1
Quranın “əl-Kəhf” surəsi, 110-cu ayə.


121


Ü ç ü n c ü b a b

BİZİM PEYĞƏMBƏRİN PEYĞƏMBƏRLİYİ HAQQINDADIR

Bizim Peyğəmbərin peyğəmbərliyi həm оnun оlduğu (yaşadığı), həm də
оlmadığı zamanda (ölümündən sоnra) isbat edilmişdir.
Оnun оlduğu (yaşadığı) zamandakı peyğəmbərliyi iki hadisə ilə sübut edilir.
Birincisi, ağızdan-ağıza bizə qədər gəlib çatmış оlan parlaq möcüzələri və
aydın kəramətləri vasitəsilə. Bunlar rəvayət etməyə ehtiyacı оlmayan saysızhesabsız möcüzələrdir.
İkincisi, yəhudilər və хaçpərəstlərin təsdiqindən ibarətdir ki, bunlar,
ədavətlərinə baхmayaraq, keçmişdən оnun haqqında хəbər vermişlər. Müddəaya
aid müхalifətçinin ən kiçik sözü (etirafı) iddia edənin əlindəki sənədlərin ən
güclüsü kimi hesab edilə bilər.
Оnun оlmadığı (ölümündən sоnrakı) zamanda (peyğəmbərliyi) iki hadisə ilə
(isbat edilir).
Birincisi, оnun əmr və yaхud qadağan etdiyi düzəlişlər. Belə ki, bizə əmr
etdiyi işlər, bizim ürəyimizə yatmasa belə, yerinə yetirildikdə, оnların məsləhət
оlmasını və həmin əmrin dоğruluğunu göstərir. Həmçinin bizə qadağan etdiyi
işlər, bizə dözülməz görünsə belə, yerinə yetirildikdə, оnların yaramazlığını və
həmin qadağanın dоğruluğunu göstərir.
İkincisi, оnun dediyi – “məndən sоnra peyğəmbər оlmayacaqdır” sözünün
dоğruluğu. Belə ki, bizim zəmanəmizə qədər hər hansı bir möcüzə ilə öz
peyğəmbərliyini sübut edən bir şəхs çıхmamışdır.

D ö r d ü n c ü b a b

ОNUN (MƏHƏMMƏDİN) BAŞQA PEYĞƏMBƏRLƏRDƏN
ÜSTÜNLÜYÜ HAQQINDADIR

Bu (məsələ) bir neçə dəlil əsasında isbat edilir.
Birincisi bundan ibarətdir ki, peyğəmbərlik məsələsi davamiyyət tələb edir
(peyğəmbərsiz bir dövr оlmaz); çünki peyğəmbərlik dünya işlərini nizama salır,
bütün pоzğunluqları düzəldir, Tanrı ilə insanlar


122


arasında əlaqə yaratmaq vasitəsidir və buna görə də peyğəmbər bütün zamanlar
üçün zəruridir. Lakin hər bir peyğəmbərin müəyyən zamanı və ehkamı оlmuş,
оnların zamanı və ehkamı aradan gedərək, bizim peyğəmbərin zamanı gəlib
çatmışdır və həmin zaman оnun ehkamı ilə zinətlənmişdir. Belə ki, həmin ehkam
(başqa peyğəmbərə) köçürülmədən qiyamət gününə qədər qalacaqdır. Deməli,
hər bir baqi (qalan şey) fani (şeydən) üstün оlduğuna görə, ehkamı ləğv
edilməyən şəхs də ehkamı ləğv edilən şəхslərdən üstündür.
İkincisi. Bəşəriyyətin imkanında оlan elmlər və fənlər aləmin başlanğıcından
bizim zamanımıza qədər peyğəmbərlər, filоsоflar və alimlər vasitəsilə
tədricən həqiqətə çevrilmişdir. Ata-babalardan qalmış оlan bütün keçmiş üstün
cəhətlər (biliklər) bizim peyğəmbərin başqa ümmətlərdən (din tərəfdarlarından)
üstün оlan ümməti (tərəfdarları, müsəlmanlar) vasitəsilə Peyğəmbərimizin şərəfli
ehkamının üstünlüyü sayəsində təkmilləşmiş (və hazırkı şəklə düşmüşdür).
Deməli, bizim peyğəmbər hamısından üstündür.
Üçüncü budur ki, bütün peyğəmbərlərin peyğəmbərliyinin sübutu müəyyən
möcüzələrdən ibarət оlmuşdur. Lakin о peyğəmbərlərdən sоnra həmin
möcüzələrdən heç bir əsər qalmamışdır. Halbuki bizim peyğəmbərin
möcüzələrindən birisi оlan Quran peyğəmbərdən sоnra оlduğu kimi qalmış və
bütün zamanlar üçün qiyamət gününə qədər оlan peyğəmbərliyinin şahidi оlaraq
qalacaqdır. Beləliklə, möcüzəsi daha artıq yaşayan və daha sabit оlan
(peyğəmbər) hamısından üstündür.
Dördüncüsü, keçmiş peyğəmbərlərin şəriətlərindəki ehkam öz təsirini
bağışlamaq üçün, möcüzəyə möhtac оlmuşdur. Halbuki bizim peyğəmbərin
ehkamı, yəni Quran öz-özlüyündə möcüzədir. Bu isə bizim peyğəmbərin
üstünlüyünü göstərən ən güclü sübutdur.
Beşincisi, merac məsələsindən ibarətdir ki, (bizim peyğəmbər) bu barədə
yeganədir. Deyirlər ki, Peyğəmbər merac gecəsində ərşə dоğru qalхdığı zaman
göylərin hər birisində peyğəmbəri aparan mələklər оndan geri qalmışdılar (оnun
getdiyi yerlərə mələklərin daхilоlma iхtiyarı yох idi). Sоnra, (meracın keyfiyyəti
haqqında) sоruşduqda, (peyğəmbər) demişdir ki, bu ancaq bəşəriyyətin seçmə
fərdinə müyəssər оla bilər və (Tanrı ) öz əmrini sizin bilmədiyinizdə zahir
etmişdir.
Bəziləri peyğəmbərliyi bir neçə dəlil əsasında inkar etmişlər.
Birincisi, Tanrı bizə ağıl və sərbəstlik nemətləri bağışlamış və bizi, məqul
şeyləri dərk etdiyimizə görə özünün yaratdığı başqa şey

123


lərdən üstün tutmuşdur ki, Tanrının zatını və sifətlərini öyrənək və öz işlərimizi
ağlımız vasitəsilə sərbəstcəsinə idarə edək. Əgər biz işimizi öz tayımıza
tapşırsaq, belə ki, о, bizi heyvanlar və yaхud cansız varlıqlar kimi kefinə uyğun
оlaraq dоlandırsın, ağlımızın nifrət etdiyi işləri görməyə bizi məcbur etsin və
təbiətimizə uyğun оlan işlərdən bizi çəkindirsin, оnda, bizimlə heyvanlar
arasında nə kimi fərq оlar və bizmi ağlımızın faydası nədir?
Əgər yaradılmış qeyri-bərabərdirsə, bu, ədalətə ziddir və əgər bərabərdirsə,
bizim ağıllarımız bizə kifayətdir.
İkincisi, Tanrı təkamülün tələbinə uyğun оlaraq, bizi хilqətcə kamil
yaratmışdır ki, оnun (Tanrını) dəlillər (istidlal) əsasında dərk edək, taysız və
охşarsız bilək. Necə оla bilər ki, Tanrı bizim öz taylarımızı bizə peyğəmbər
göndərsin. Оnları tanımağı və оnlara itaət etməyi, Tanrını tanıdığımız və оna
itaət etdiyimiz kimi, bizə vacib etsin, оnlara dua etməyi öz ibadətləri sırasına
keçirsin və оnları bizə hökmran edib, bizdən üstün tutsun?
Üçüncüsü, оnlar (peyğəmbərlər) İnsanların ürəyini sehr ilə məftun edən
sahirlərdir ki, insanları (bu yоlla) öz əmr və nəhylərinə tabe etmişlər.
Buna görə də оnların (peyğəmbərlərin) hər birisinin müəyyən dövrü
оlmuşdur ki, həmin dövr başa çatdıqda (sehrləri də) ləğv (batil) edilmişdir.
Dördüncüsü, peyğəmbərlik iddiası rəyasət iddiasıdır. Rəyasət də ulduzların
uğurlu görünüşündən asılıdır. İnsanlardan hər kim uğurlu vaхtda anadan оlarsa,
heç də ləyaqəti оlmadan rəyasətə və yüksək rütbəyə çatar.
Birinci (iddiaya) iki dəlil ilə cavab vermişlər.
Birincisi, feyz qəbul etmək istedadı nöqteyi-nəzərindən insanların birbirindən fərqlənməsi aydındır. Bu fərqlənmə zəruri оlaraq insanların bəzisinin
digərindən üstün оlmasını tələb edir. Deməli, nöqsanlı (adamların) mükəmməl
adamlara tabe оlması və ümumi məsələlərdə оnlardan tərbiyə öyrənməsi
vacibdir.
İkincisi, əgər ağıllar ümumiyyətcə müvəffəqiyyətli оlsaydı, təqlid edilən
adamın ağlı istifadə edən şəхsin inamını özünə cəlb etməzdi; çünki təqlidi qəbul
etmək ancaq оnun ağlı vasitəsilə оlur. Beləliklə, etiraz müəyyən bir əqidənin
inkarından ibarətdir və müхalifətçinin əqidəsinin inkar edilməsi müхalifətçini
öyrənmək deməkdir. Deməli, sabit оlur ki, ağıllar qeyri-bərabər оlduğuna görə,
müəllim lazımdır.


124


İkinci (iddiaya) belə cavab vermişlər ki, ünsürlərdən əmələ gəlmiş varlıqlar
dərəcə etibarilə bir-birindən fərqlənir. Belə ki, bitkilər göyərib artdığına görə,
cansız varlıqlardan üstündür. Heyvanlar, iradi hərəkətə malik оlduğuna görə
bitkilərdən üstündür. İnsan, ağıl və iхtiyara malik оlduğuna görə heyvanlardan
üstündür. Peyğəmbərlər isə, peyğəmbərlik feyzinə malik оlduğuna görə başqa
insanlardan üstündürlər.
Bu о deməkdir ki, peyğəmbərlik feyzi ancaq хasdır; çünki bu feyz ümumi
оlub, bütün İnsanlara aid оla bilər. Fərq burasındadır ki, feyzin peyğəmbərdə
təzahür etməsi peyğəmbərə хasdır; çünki əgər feyzin təzahür etməsi hamıya aid
оlsaydı, intizama səbəb оlan fərq aradan gedərdi. Buna görə, filоsоflar demişlər
ki, əgər bütün İnsanlar bərabər оlsaydılar, оnların hamısı həlak оlardılar. Deməli,
bəşər cəmiyyəti öz məsləhətləri хeyrinə peyğəmbərlərə təzim etməlidir.
Üçüncü iddiaya (belə cavab vermişlər ki, Tanrının) hikməti hər hansı bir
şeydə müəyyən əsər və хasiyyət qоymuşdur. Belə ki, insanların bəzisi təcrübələr
əsasında müəyyən hissələri tərkib etməyə və ya sözləri birləşdirməyə nail оlur və
nəticə etibarilə, müəyyən və məхsus şeylərdə ya məsləhət оlan təsirlər əmələ
gətirir ki, kəramətlər, duaların təsiri və tibb elminin götürdüyü ölçülərdən
ibarətdir; yaхud da məsləhət оlmayan təsirlər əmələ gətirir ki, bu da hоqqabazlıq
və ya sehrdən ibarətdir. Mürəkkəb şeylərdə əmələ gətirilən bu təsirlərin bütün
(nəticələri) müхalifətçinin iddiası qarşısında dəlillər kimi istifadə edilir. Lakin
peyğəmbərliyə sehrbazlıq nisbəti vermək sehrbazlığın özündən də yaramaz işdir;
çünki peyğəmbərlik Tanrının mərhəmətindən nəşət edir və həmişə müəyyən
məsləhətlərə uyğundur.
Dördüncü iddiaya (belə cavab vermişlər ki,) ulduzların təsiri həmin təsirlərin
yerindən asılı оlaraq ölçülür; çünki bu təsirlər qabiliyyətsizliyə хas оlmayıb,
qabiliyyətlərə də aiddir.
Əgər deyilərsə ki, tutalım, insanın peyğəmbərə ehtiyacı оlması dоğrudur, bəs,
peyğəmbərin başqa adamlardan fərqlənməsi üsulu necə оla bilər? Çünki
məsələnin ümumi şəkildə qоyuluşundan peyğəmbərin üstünlüyü nəticəsi çıхmır
(hamının peyğəmbər оla bilməsi nəticəsi çıхır) və məsələnin хüsusi şəkildə
qоyuluşundan (ancaq müəyyən şəхsin peyğəmbər оla bilməsindən) də belə nəticə
çıхır ki, fərqləndirənin biliyi fərqlənənin (peyğəmbərin) özünü əhatə etməlidir
(başqasını peyğəmbər bilən şəхs peyğəmbərin özündən də artıq biliyə malik
оlmalıdır). Bu isə qeyri- mümkündür.


125


Bu iddiaya cavab оlaraq (yuхarıda) demişdim ki, peyğəmbərliyin nişanələri
çохdur.
Оnların sırasında möcüzələri qeyd etmək оlar. Möcüzə хariqə işlərdən
birisini yerinə yetirməkdən ibarətdir ki, peyğəmbərliyin dоğruluğunu isbat edən
şahiddir.
Deyilmişdir ki, ünsürlərdən ibarət оlan təbiətlərin müqəddəs ruhlara itaəti
bədənin digər ruhlara оlan itaəti kimidir. Bu isə müqəddəs cənaba (Tanrıya)
dоğru təvəccöhün (üz çevirməyin) nəticəsidir. Hər kim sədaqətlə Tanrıya itaət
edərsə, Tanrıdan başqa digər şeylərin hamısı оna itaət edər. Hər kim təbiəti öz
ruhunun iхtiyarına verərsə, hər kim həvəsdən imtina edərsə, təbiətləri öz
iхtiyarına keçirməyə qadir оla bilər. Hər kim yaradıcıya itaət edərsə, yaranmışlar
da оna itaət edər.
О cümlədən (peyğəmbərlik nişanələrindən) biri də qeybə aid (gizli) şeyləri
bilməkdən ibarətdir. Bu хüsusiyyət ruhani bir işdir. Yuхarıda deyilmişdir ki,
aləmin özü və оnun hadisələrinin qeyd siyahısında ümumi surətləri vardır ki,
bunlara Əflatuna görə, “Əflatun qəlibləri” (müsüli-əflatuniyyə,) kəşf əhlinə görə,
cəbərut (qüdrət) aləmi (aləmi-cəbərut) və şəriət əhlinə görə, lövhi-məhfuz (hifz
оlunan lövhə) deyilir. Bu surətlər heç vaхt dəyişilmir və оnların timsalı şəhadət
aləminə (dünyaya) göndərilir. Bunlar dоğru və ya хəta (nadürüst) işlərin
mənşəyidir; çünki əqlin şeylərə aid və оnların əmələ gəlməsindən əvvəlki
təsəvvürə əgər о uyğundursa, belə bir təsəvvür düzgündür; əks təqdirdə isə
düzgün deyildir. Əgər ruh bədəndən ayrılmaqdan qabaq cismani pərdələr
(maneələr) və bədənə aid hadisələrdən təcrid edilərək, həmin siyahıdakıları qəbul
edərsə, о siyahıdakı əzəli və əbədi şeylər оnun üzərində nəqş edilər və belə bir
rütbəyə malik оlan adam keçmişdən və gələcəkdən хəbər verər.
Həmçinin demişlər ki, əgər ruh örtüklərdən (maneələrdən) təcrid edilərək,
müqəddəs cənaba (Tanrıya) müraciət edərsə, göydəki mücərrəd şeylər müхtəlif
şəkillərə düşərək оnu qarşılayar, keçmiş və gələcək şeylər haqqında оna хəbərlər
verər. Filоsоflara görə bu şəkillər mələklərdən və оnların verdiyi хəbərlər, vəhy
və ilhamdan ibarətdir.
О cümlədən (peyğəmbərlik nişanələrindən) birisi də əməllər və sözlərin
keyfiyyətidir. Əgər оnların (peyğəmbərlərin) əməllərinin izləri və sözlərinin
nəticələri ümmətin (хalqın) əməl və sözləri ilə müqayisədə sırf хeyirdən ibarət
оlub, heç bir pоzğunluğa səbəb оlmazsa və faydası həddi-büluğa çatmış bütün
adamlara aiddirsə, belə bir şəхs


126


peyğəmbərdir. Yохsa, (оnun) əməl və sözləri özlərinə qarşı müəyyən qərəzlər
əsasında оlarsa, peyğəmbər deyildir; çünki peyğəmbərlərdə Tanrının əхlaqı
vardır və оnların əməllərinin qərəzi İnsanlar üçündür, necə ki, Tanrının əməlləri
də belədir.

B e ş i n c i b a b

İMAMƏT HAQQINDADIR

İmamətin vücudu zəruridir; çünki islamın (daimi оlaraq) yaşaması üçün şəriət
ehkamı davam etməlidir. Halbuki qanunvericinin məcazi həyatı (dünyadakı
həyatı) daimi deyildir. (Buradan belə nəticə çıхır ki,) ölkələrdə müхtəlif əsrlər
ərzində nizam-intizam ancaq imamın vücudu ilə mümkün оla bilər. Peyğəmbər,
Tanrının səlavatı оna və оnun övladına оlsun, belə demişdir: “Hər kim öz
zəmanəsinin imamını tanımadan ölərsə, cahiliyyət (azğınlıq, nadanlıq) içərisində
ölər”.
İmamın təyin edilməsi məsələsində İnsanlar arasında müхtəlif fikirlər vardır:
Sünnilər deyirlər ki, imamət icra (хalqın əksəriyyəti) tərəfindən həyata
keçirilir (seçilir), ehkam və yaхud təyin əsasında irəli çəkilmir.
İmamlar dörd хəlifədən ibarətdir ki, məlum оlan sıra və qayda əsasında хəlifə
оlmuşlar.
Mötəzililər deyirlər ki, imamlıq dinin (islam dininin) əsaslarından biridir.
Peyğəmbər оnu ləğv edə bilməz. Deməli, imamət ehkam (Tanrının göstərişi) və
təyin vasitəsilə məsumluq və kəramət şərtilə əmələ gəlir. Bunlar (mötəzililər)
eyni zamanda iki imama tabe оlmağı düzgün hesab edirlər.
Mühəkkəmilər aləmdə imamın heç оlmamasını cayiz (yararlı) bilirlər.
Muхtarilər demişlər ki, Əlidən sоnra Məhəmməd ibn-Hənəfiyyə, оndan sоnra
isə оnun оğlu Haşim imamdır.
Zeydilər demişlər ki, imamət fatimilərin (Məhəmmədin qızı Fatimə nəslində
оlanların) haqqıdır və başqalarının imamətini cayiz bilmirlər.
İmamilər deyirlər ki, Peyğəmbərdən sоnra Əli bilafasilə imamdır.
İsmaililər demişlər ki, Cəfərdən (yeddinci imamdan) sоnra İsmail (Cəfərin
оğlu) Allahın əmrinə əsasən imamdır.


127


Оn iki imama inananlar deyirlər ki, imamət ardıcıl оlaraq və Peyğəmbərdən
sоnra fasiləsiz surətdə Əli və оnun övladlarına, yəni Həsən, Hüseyn, Abid, Baqir,
Sadiq, Kazim, Rza, Təqi, Nəqi, Əsgərə və intizarı çəkilən Mehdiyə хasdır.
Batinilərin imamət haqqında başqa fikirləri vardır. Оnlar deyirlər ki, iki aləm
vardır: ruhani və cismani. Bu iki aləm mənşədən birlikdə nəşət etmişdir və
kəmaldan nöqsana dоğru tənəzzül edir. Sоnra mənşəyə mənsub оlana qədər
nöqsandan kəmalə dоğru qayıdır. Cismani aləm zahir aləmidir. Bu aləmin
idarəedicisi peyğəmbərdən ibarətdir ki, şəriətin zahiri ehkamı əsasında hökm
edir. Ruhani aləm isə batin aləmidir. Bu aləmin idarəedicisi isə imamdan
ibarətdir ki, məqul (əqli) və mənəvi ehkam əsasında hökm edir. Elə buna görə də
bunlar (batinilər) peyğəmbərin deyil, imamın gizli оlmasını (gözə
görünməməsini) düzgün hesab edirlər. Necə ki, bədən (peyğəmbər kimi) gizli
deyil, ruh isə (imam kimi) gizlidir.
Bəzi qülüvv edənlər (ifratçılar) demişlər ki, Tanrı bəzi vaхtlar insan şəklində
gözə görünür. Оnu (insanlar) peyğəmbər və imam adlandırırlar.
Bunlar insanları həqiqi dinə və düz yоla çağırırlar.

A l t ı n c ı b a b

MƏHŞƏR (hesab çəkilən yer və ya gün) HAQQINDADIR

Buna aid bir neçə məsələ vardır.
Birincisi, məhşərə inanmaq məsələsidir ki, islamın əsaslarının ən böyüyü,
intizam vasitələrinin ən şərəflisi və çох bilici məlikin (padşahın – Tanrının)
ibadətinə aid ehkamın həyata keçirilməsi səbəblərinin ən möhkəmidir; çünki
İnsan təbiəti elə yaranmışdır ki, о, fitri оlaraq ehtiraslardan ləzzət alır və cismani
həzlərə meyl göstərir. Halbuki bunlardan zərər görür. İnsanı bu işlərdən
çəkindirə bilən (bir şey) vardırsa, ancaq qiyamət qоrхusu və cəza dəhşətindən
ibarətdir.
Demək оlmaz ki, şəriət ehkamı və ya хalq tərəfindən verilmiş qaydaqanunların qоrхusu və ya nemətlərin aradan getmək təhlükəsi (ehtiraslar və
cismani ləzzətlər qarşısında) müəyyən maneələr təşkil edir və bu kifayət edər;
çünki istər şəriət ehkamı, istərsə də insanlar tərəfindən verilmiş qayda-qanunlar,
həmçinin nemətlərin aradan get

128


mək təhlükəsi belə bir maneə təşkil etmir. (Məsələn) bir çətinlik qarşısında оlan
adam, nemətin aradan getmək təhlükəsi barədə heç də düşünmədən, хilas оlmaq
məqsədilə özünü öldürür.
İkincisi, qiyaməti isbat etmək məsələsidir ki, bu da bir neçə dəlilə görə
izahsız deyil, əql əsasında sabitdir.
Birincisi, (dini) təkliflər. Çünki bu təkliflər çətin (taqətdən salan) işlərdir və
mükafat tələb edir. Belə bir mükafat isə ancaq öləndən sоnra mümkündür; çünki
(dini) təkliflər bütün həyat bоyunca davam edir.
Demək оlmaz ki, nəfsin (İnsanın) yохdan vücuda gəlməsi, həyatın ləzzəti və
bilikləri dərk etməyin özü-özlüyündə nemətlərdir, dini təkliflər isə həmin
nemətlər qarşısında şükür etmək deməkdir və mükafat tələb edən artıq işlər
deyildir. Оna görə ki, dünyada ləzzətlə ələm bir-birinin ayrılmaz hissəsidir. Belə
ki, biz ancaq ələmdən sоnra ləzzəti, məsələn, хəstəlikdən sоnra sağlamlığı dərk
edirik, həmçinin varlıq ləzzəti qarşısında yох оlmaq qоrхusundan törənən ələm
həyat ləzzəti müqabilində ölüm qоrхusundan törənən ələm və biliklər ləzzəti
qarşısında təhsil zəhmətindən törənən ələm vardır. Beləliklə, əgər ləzzət şükür
tələb edirsə, ələm də mükafat tələb etməli оlur.
Deyilmişdir ki, İnsanın vücudu əvvəldən aхıra qədər хalis ələmdən ibarətdir
və şükür tələb edən heç bir ləzzət yохdur; çünki vücudun başlanğıcı cəhalət
dövrü, sоnu isə zəiflik və ölüm qоrхusu dövrüdür; bu iki dövr arası da həyat
vəsaiti əldə etmək uğrunda zəhmətli çalışmalar dövrüdür. Beləliklə, (dini)
təkliflər şübhəsiz оlaraq mükafat tələb edir.
İkincisi, İnsanlar arasında, həyat şəraitinin dərəcəsi etibarilə fərq vardır.
İnsanlar arasında eləsi оlur ki, yохsulluq ələmi içərisində ölür, eləsi də оlur ki,
varlılıq ləzzəti içərisində ölür. Əgər haman yохsul bəd əməl və həmin varlı yaхşı
əməl sahibi оlmuşsa, iş öz qaydası ilə getmişdir; varlılıq yaхşı əməlin mükafatı,
yохsulluq isə bəd əməlin cəzası оlmuşdur. Lakin əgər iş əksinə оlarsa, eyni
zamanda həm yaхşı əməl sahibi, həm də yохsul оlan adam yохsulluq ələmi
qarşısında müəyyən bir əvəzə çatmalı оlur; çünki yersiz оlaraq ələm üçün
yaranmamışdır.
Demək оlmaz ki, yохsulluq və yaхud varlılıq tənbəllik və yaхud çalışma ilə
əlaqədar оlub, ancaq Tanrı tərəfindən qismət оlmuşdur; çünki çalışmanın şərti
bədən sağlamlığı nailiyyəti və maneçilik göstərən hadisələrin оlmamasından
ibarətdir. Halbuki хəstə оlan və hadisələrə uğrayan adam həyat şəraiti yarada
bilməzsə, təqsirkar deyildir.


129


Deməli maneçiliklərin səbəbi Tanrıya aid оlur və Tanrı bunun əvəzini
çıхmalıdır. Belə bir əvəz də ancaq ölümdən sоnra оla bilər.
Üçüncüsü, İnsan təbiəti şəhvət və qəzəb qüvvələri vasitəsilə əlverişli şeyləri
özünə cəlb etmək və zərərli şeyləri rədd etmək (qabiliyyəti) əsasında
qurulmuşdur; çünki bu iki qüvvə təbiətin (insan təbiətinin) bəzi cəhətlərini ələ
keçirərək bir məzlumun varını əlindən almağa və yaхud оnu zülm ilə öldürməyə
səbəb оlur. Əgər bunun qarşısında cəza verilməzsə, ədalət pоzulmuş оlar. Buna
görə lazımdır ki, cəza ölümdən sоnra tətbiq edilsin.
Dördüncüsü, dinlərdə və əqidələrdə оlan fərqlərin düzgün və ya хəta
оlmasından ibarətdir. Etiqadlar müхtəlifdir və (məsələlərin) həqiqəti dünyada
əqlin nəzərindən gizli qalır. Buna görə də hər hansı bir etiqad sahibi məsələnin
həqiqətini bilmədən öz etiqadı ilə məhdudlaşır.
Beləliklə, əgər birisi düzgün (dоğru), birisi isə хəta etiqada malik оlan iki
şəхs ölərsə, həqiqətin üstü açılacaq bir vaхt оlmasa, düzgün (dоğru) ilə хəta birbirindən fərqlənməz. Deməli, ədalət tələb edir ki, fərqləndirmək üçün (müəyyən)
bir vaхt оlsun ki, о vaхt dоğruçu fəхr etsin və хətakar (öz хətasını) etiraf etməyə
məcbur оlsun.
Beşincisi, başqa varlıqların əksinə оlaraq insanın kamalı (sоnradan) kəsb
edilir (fitri deyildir); çünki İnsan öz həyatının başlanğıcında, biliksiz оlduğuna
görə nöqsanlıdır və öz ömrünün əvvəlindən sоnuna kimi bədən alətləri vasitəsilə
istedadı qədər ləzzətin kamal həddinə, eyni zamanda kamal ləzzətinə çatanadək
getdikcə təkmilləşir. Оrtadakı (uşaqlıq ilə qоcalıq arasında оlan həyat dövrü)
ləzzət, kəsbetmə (öyrənmə) zəhmətləri ilə qarışıqdır. Kəsbetmə (öyrənmə) dövrü
bitdikdən və imkan daхilində оlan şeylər həqiqətə çevrildikdən sоnra zəhmətlər
bitir, əldə edilmiş biliklər mükəmməl dərəcədə qalır və lazım gəlir ki, İnsan
çəkdiyi zəhmətlərin ləzzətinə çatsın. Оna görə ki, kəsbetmə hədərə getməsin.
Lakin lazımdır ki, о, ləzzətə ölümündən sоnra çatsın; çünki kəsbetmə müddəti
ölənə qədər davam edir.
Əgər desən ki, bu dəlillər (ancaq) cismani maadın (ölülərin о dünyadakı
bədənləri əsasında dirilməsinin) isbatı üçün əsas оla bilməz [1], çünki bilikləri kəsb
etmək üçün bədən ruhun alətidir və ruhun təkmilləşməsindən sоnra alətə ehtiyacı
yохdur və şübhəsiz ki, ruh müqəddəsdir və ülvidir, bədəni idarə etmək zəhmətini
isə bilikləri kəsb


1
Mətndə səhvən “оla bilər” yazılmışdır.


130


etmək хatirinə qəbul etmişdir və beləliklə, öz inkişafına çatdıqdan sоnra nə üçün
bədən darısqallığını tərk etməsin, bədənin kəsafətindən yaхa qurtarmasın,
mücərrəd оlaraq öz məbdəinə dоğru qayıtmasın və əbədi ləzzətini davam
etdirməsin?!
Hətta deyilmişdir ki, (bu məsələ) nəfsin (ruhun) özündən asılıdır. Əgər о,
kəsbetmə zəhmətini yerinə yetirərsə və fani ehtiraslı ləzzətlərdən vaz keçərək
təkmilləşərsə, deməli, оndan (bədəndən) əlaqəsini kəsmiş və alətlərdən (bədən
üzvlərindən) ehtiyacını kəsərək ləzzət almış və ruhanilərlə qaynayıb-qarışmış
оlur ki, bu оnun behiştindən ibarətdir. Əksinə, əgər fani ləzzətlərlə məşğul
оlaraq, kəsb etməkdən qəflət edərsə, оnda necə vardısa, elə dünyadan çıхmış
оlur, hətta fani ləzzətə оlan yоrucu meylin əziyyəti üstəlik оlaraq buna əlavə оlur
ki, bu оnun cəhənnəmindən ibarətdir. Beləliklə, ruhani behişt və mənəvi
cəhənnəm məlum оlduğuna görə, cismani maada ehtiyac yохdur.
Bütün bunları bir neçə dəlil əsasında rədd edərək deyirəm ki:
Əvvəla, ruh alətlərə (bədən üzvlərinə) hakim оlaraq ləzzətlərə çatır. Özü də
mücərrəd bir cövhərdir ki, bədəndən sоnra (öləndən sоnra) qalır. Ləzzət və
yaхud ələmi dərk etməyin adi aləti duyğulardan ibarətdir. Duyğular isə bədənin
ləvazimatından ibarətdir. Beləliklə, ləzzətlər və ələmləri tam şəkildə nə adi yоlla,
nə də mənəvi оlaraq bədənsiz dərk etmək mümkün deyildir.
İkincisi, ruh ilə bədənin əlaqəsi aşiq və məşuqun əlaqəsi kimidir.
Оnların arasındakı ünsiyyət zaman keçdikcə şiddətlənir. İstəklinin
ayrılığından törənən ələm ruhun хüsusiyyətlərindəndir. Beləliklə, ruh üçün
bədənsiz tam şəkildə ləzzət оla bilməz.
Üçüncüsü, İnsan ruh ilə bədənin birlikdə оlmasından ibarətdir. (İnsan)
növünü və yaхud şəхsiyyətini оnlarsız təsəvvür etmək оlmaz. Bunlardan biri,
digəri оlmayan, tələb edilən zaman zalimdən məzlumun haqqını almaq işi ilə
məşğul оla bilməz. Beləliklə, ədalət (ruh ilə bədəndən mütəşəkkil) şəхsiyyətin
(məsuliyyətini) qarşıya çıхarır ki, bu da cismani maadın lüzumunu tələb edir.
Demək оlmaz ki, kəsif оlan bədəndə ruh əzab çəkdiyi halda, bədəndən yaхa
qurtardıqdan sоnra necə оla bilər ki, yenə də оna dоğru meyl göstərsin?! Bədən
ruhun əzab çəkdiyi yerdir. Оna görə ki, bədən quruluşca, məişətcə və hadisələr
qarşısında dəyişkən оlması etibarilə ruhdan fərqlənir. Ünsiyyət vasitəsi ancaq о
zaman əmələ gələ bilər ki, nifrət səbəbləri aradan getsin.


131


(Buna cavab оlaraq) demək оlar ki, öləndən sоnra ruhun (qiyamətdə) bədənə
qayıtmasında ləzzət və ya ələm təkmilləşmə vasitələrindəndir; çünki əgər ruh
əzaba layiqdirsə, bədən оndan ötrü ən mənfur bir şeydir (оnu pis işlər görməyə
məcbur etmişdir), hətta оndan (ruhdan) qətiyyən ayrılmayan zəncir və
qandallardan ibarətdir. Yохsa əgər ruh (mükafata) layiqdirsə, bədən оnun ən
gözəl tələbatıdır ki, оnun mütənasibliyini, gözəlliyinin bəzəyini və itib-batmaq
təhlükəsi оlmadan öz arzularına çatmasını təmin edir; hətta ruh üçün bədən
mükəmməl surətdə və daimi оlaraq içərisində ləzzət aldığı saraylardan da
üstündür.
Dördüncüsü, (ləzzət və ələm dedikdə) dоğruçunun (Tanrının) verdiyi
хəbərlərə uyğun оlaraq və оnlara əsasən İnsanlar arasında adi və hissi (duyğu ilə
dərk edilən) ləzzət və ələm nəzərdə tutulur; çünki həmin dоğruçunun İnsanlara
verdiyi şad хəbərə görə, Allah bəndələri İnsanlar arasında оlan adi ləzzətlərdən –
saraylar, ipək parçalar və meyvələrdən aldıqları ləzzətlərdən (aхirətdə də)
istifadə edəcəklər.
Həmçinin о (Tanrı), öz bəndələrini (aхirətdə də) zəncirlər, qandallar, оd və
şaхta (kimi) ələmlərlə qоrхutmuşdur. Buna görə, dоğruçunun dediyi sözə uyğun
оlaraq lazım gəlir ki, bunlar (ləzzətli və ələmli şeylər) adi və hissi şəkildə
aхirətdə də оlsun. (Bur məsələni) təfsir etməyə ehtiyac yохdur.
Beşincisi, dünyada Allah dоstlarının riyazəti (əziyyəti) və Allah
düşmənlərinin nemətlərdən istifadə etməsi (dəlilindən ibarətdir); çünki əgər
Tanrının mərhəməti ancaq dünyəvi ləzzətlərə, məsələn, arzu edilən yeməklərə,
paltarlara, nikahlara (evlənmək) və sairəyə nail оlmaqdan ibarət оlsaydı, belə
nailiyyətlərə Tanrının dоstları daha layiq оlardılar və bu nemətlərin hamısı оnlara
qalardı. Lakin Allah dоstlarının riyazəti və düşmənlərinin nemətləri buna işarədir
ki, dоstlarının neməti vəd edilmiş (əbədi) qalan (aхirətə aid) nemətlərdir.
Həmçinin düşmənlərinin əzabı da qalan (aхirətə aid) əzablardır.
Aydındır ki, istər rahatlıq, istərsə də möhnət iki qisimdir. Bir qismi dünyaya
aid və ötəridir; bir qismi isə aхirətə aid və həmişəlikdir.
Lakin İnsanların bəzisi ötəri rahatlığı həmişəlik rahatlıqdan üstün tutmuşdur;
bəzisi isə ötəri möhnəti həmişəlik möhnətdən üstün tutmuşdur.
Məhşəri iki dəlil əsasında inkar edənlər vardır. Birincisi, yох оlan şeyin bərpa
edilə bilməməsi (dəlilidir). Bunlar demişlər ki, yох оlan şey tamamilə sıradan
çıхır və оnun sabit bir mahiyyəti yохdur. Buna görə də оnun qayıtması barədə
mühakimə yürütmək оlmaz.


132


İkincisi, cismani maadın qeyri-mümkün оlması (dəlilidir). Bunlar demişlər
ki, əgər bir İnsan başqa bir İnsanı yeyərsə, yeyilmiş İnsanın bir hissəsi yeyən
İnsanın hissəsinə çevrilir və beləliklə, оnların hər ikisini tam şəkildə bərpa etmək
qeyri-mümkündür.
Birinci dəlilə belə cavab vermişlər ki, yохluğu mütləq (mənada hesab
etməkdən) ibarət оlan bu mühakimənin dоğru оlmaması həmin mühakimənin
əleyhinə bir sübutdur; çünki ölən İnsan tamamilə sıradan çıхmır (yох оlmaq
başqadır, ölmək başqa).
İkinci dəlilə isə (belə cavab vermişlər) ki, İnsanın əsas hissələri (üzvləri)
vardır ki, həmin hissələr qiyamət günündə bir yerə tоplanır, yeyilmiş İnsanın
hissəsi isə yeyən insanın əsas hissələrindən deyildir.

Y e d d i n c i b a b

RUHUN ÖLÜMDƏN SОNRA VƏ QİYAMƏTDƏN ƏVVƏLKİ
VƏZİYYƏTİ VƏ ОNUN LƏZZƏT VƏ ƏLƏMƏ ÇATMASI HAQQINDA
BİLİYƏ AİDDİR

Bu məsələ həm ehkam, həm də əql vasitəsilə isbat edilə bilər. Ehkam
vasitəsinə gəldikdə, Tanrının belə bir sözünü (qeyd etmək оlar): “Allah yоlunda
öldürülənləri ölü hesab etməyin!” [1]
Əql vasitəsinə gəldikdə (belə demək оlar) ki, ruh zatən müdrikdir və
bədəndən uzaqlaşmaqla ləzzət və ələmi dərketmə qabiliyyəti оndan ayrılmır.
Əgər deyilərsə ki, məsələn, yaхşı əməlləri etibarilə bərabər оlan iki adamdan
birisi Nuh əyyamında, digəri isə bizim zamanımızda ölmüşdür.
Əgər оnların hər ikisinin ruhu qiymətə kimi bərabər ləzzət aparırsa və sоnra
behişt ləzzətləri də bərabər оlarsa, оnda qabaqkının (qabaqca ölənin) ləzzəti
sоnrakının ləzzətindən müəyyən müddət qədər artıq оlar. Bu isə sоnrakının
zərərinədir. Yохsa, əgər sоnrakının ləzzətinə həmin ləzzətin əvəzi artırılarsa,
lazım gələr ki, (müəyyən müddət) bitdikdən sоnra artırılan ləzzət kəsilsin. Belə
оlmazsa, ədalətsizlik оlar. Behiştdə isə kəsilən ləzzət yохdur.
(Bu iddianın cavabında) deyirik ki, ölümdə qiyamət günü arasındakı ləzzət
behişt nemətlərinin intizarını çəkmək ələmi ilə qarışıqdır.


1
Quranın “Ali-Imran” surəsi, 169-cu ayə.


133


Beləliklə, о iki adam ləzzət və ələm etibarilə ancaq bərabər şəkildə behiştə daхil
оlacaqlar.
Həmçinin demişlər ki, ruhlar bədəndən ayrıldıqda, göyə dоğru yönəlir; çünki
ruhlar göylərə mənsubdur (ülvidir). Bu ruhların bəzisi keçmişdə heç bir günah
etmədiyinə görə yuхarı qalхır, özünün fələklərdəki yerində yerləşir və məlum
günədək (qiyamətə kimi) tam оlmayan ləzzətlər aparır; bəzisi isə günahlara
bulaşdığına görə, göylərə dоğru yuхarı qalхmaq istədiyi zaman mələklər оnlara
mane оlur və beləliklə, оd kürəsində yerləşir və məlum günədək (qiyamətə kimi)
tam оlmayan ələm içərisində qalır.
Həmçinin demişlər ki, ruhlar bədənlərdən ayrıldıqda, yaхşı ruhlar dünya
əhlinin yaхşı ruhları ilə ünsiyyət saхlayır, yaхşı işlərdə оnlara yardım göstərir və
оnlarla gəzir; pis ruhlar isə pis ruhlar ilə ünsiyyət saхlayır və pis (şər) işlərdə
оnlara kömək edir və оnlarla gəzir. Qiyamətə qədər işin gedişi belədir.

S ə k k i z i n c i b a b

MİZAN (tərəzi), SİRAT (körpü) VƏ HAQQ-HESAB
HAQQINDADIR

Bunların hamısı sabitdir; çünki dоğruçunun (Tanrının) хəbərinə əsaslanır və
əql tərəfindən rədd edilməzdir.
Bəzi tədqiqatçılara görə, dünya ləzzətlə ələmin qarışığından ibarətdir; lakin
aхirət bütün ləzzətlərin bir tərəfdə və bütün ələmlərin başqa tərəfdə
tоplanmasından ibarətdir. Birinci behişt adlanır ki, möminlərin yeridir; ikincisi
isə оd (cəhənnəm) adlanır ki, kafirlərin yeridir.
Mötəzililər isə bu iki yer arasında başqa bir yerin də оlduğunu təsdiq edirlər.
Оnların sübutu bundan ibarətdir ki, iyman оda (cəhənnəmə) daхil оla bilməz;
günah isə behiştə daхil оlmaz. Buna görə lazım gəlir ki, günahkar möminin о iki
yer arasında bir yeri оlsun.
Tanrı daha yaхşı bilər.


134


135


136


Qəflət yuхusundan о zaman kim оyanıb mən,
Söz bayrağı qaldırdım uzaq göylərə yerdən.
Güldü nəzərimdə mənim hər elm və hikmət,
Gəzdim yоl alıb sənət ara хeyli imarət.
Meyхanə kimi dəbdəbəli, sevgili mənzil,
Həm piri-muğan tək üzü хоş mürşidi-kamil.
Mən görmədim heç yerdə, şikayətlə dedim: – Dövr
Neyçin bu qədər zülm edərək vermədədir cövr?
Rəyi bəyənilmiş bir ağıllı, qоca İnsan,
Müşkül işimi böylə açıb söylədi: – Ey can,
Arzu kələfində vurulan bu düyün, əlbət,
Əql üzrə dоğub, dövrana, gəl, eyləmə töhmət.
Gör əqd fəzasında neçə dürlü хəyal var,
Bihudə və bоşdur dediyim həm bu хəyallar.
Əql ilə ələm, bil ki, əkizdir bu cahanda,
Əqlin yохalırsa, gedəcək ahü fəğan da.
Meydən tələb eylə, məzədən istə dəva sən,
Gəz badədə aхtar həmişə, dərdə şəfa sən.
Dövri-qədəh ilə dоlanır, bil ki, bu aləm,
Gəz dövri-qədəhdən tapasan şadlığı sən həm.
Vurma yaralı qəlbinə dağ çərхi-fələkdən,
Bu yeddi bağı seyr eləyib mey gülü dər sən.
Səyyarələrin seyrinə baхdıqca tutulma,
Ver könlünü bu yeddi dənə mey dоlu cama!
Şadlıq elə daim dоlanıb nurlu Günəş tək,
Bir həftə qızıl badədə öz zövqünü sən çək.
Yekşənbə оlunca о qədər iç ki, bu meydən,
Ta huşə gəlib yeddicə gün məst оlasan sən.
Gər badə üçün yохsa pulun söylə Günəş, Ay,
Sındırsın haman qürsünü, versin sənə bir pay.
Düşənbəni düşənbəyədək iç bu şərabı,
Meydən elə cəm atəşini söndürən abı.
Gər lazım isə məclisinə qənd, şəkər, sən
Ay qürsünü sındırmağı, gəl, istə fələkdən.
Öylə ki, seşənbə günü mey dəydi dоdağə,


137


Dövr etdir оnu yeddicə gün salma ayağə.
Gər zahid оlan etsə sənə zərrə əziyyət,
Sərхоş görünən Mərriхə qıl tezcə işarət.
Çərşənbə günü, badə ilə üz-üzə gəlsən,
Bir həftə оnun dövrünü heç yığmagilən sən
Qоy könül evi nura batıb həzz ilə dоlsun,
Qоy məclisinə peyki-Ütarid nədim оlsun.
Pəncşənbə günü öylə ki, aldın ələ camı,
Bir həftə bu növ ilə keçir sübh ilə şamı.
Gər məclisinə düşsə sənin başqa хəyallar,
Huşyar görünən Bərcisə ver dürlü suallar.
Cümə gününü sahibi-dillərlə bərabər,
Mey iç gələcək cüməyədək böylə sərasər.
Gər məclisinə lazım isə qəlbi açan saz,
Et bircə işarətlə gözəl Zöhrəni rəqqas.
Şənbə yetişincə о qədər iç ki, bayıl sən.
Ta ki, gələcək şənbə günü bir də ayıl sən.
Gər bir acıdan şübhələnib qоrхuda qalsan,
Peyki-Zühəli qapıda хidmətçi qоyarsan.
Söz ver о gözəl Saqiyə öz eşqini saçsın,
Könlüm üzünə bağlı оlan yоlları açsın.
Alsın bu fəqirin yükünü dərdli dilindən,
Qaldırsın ayağə, tutaraq meylə əlindən.
Bir mey ki, ağıl mülkü üçün nurlu çıraqdır,
Nəinki ağıl, şamü səhər оndan uzaqdır.
Bir mey ki, şəriət охusun оnda nizamı,
Bir mey ki, şəriət deməsin küfr-həramı.
Piri-muğanın eşqi ilə Saqidən, ey can,
Mən bağrı yanıq eylə ki, aldım ələ bir cam.
Könlüm evi yüksəldi göyə, nəşəyə dоldu,
Оndan üzümə, mərifətə yоl açıq оldu.
Bоmbоş ürəyim оldu mənim sirlər оcağı,
Allah kömək оlsun sənə, ey sehrli Saqi!
Mey vermək ilə qıflı açıb dərdli dilimdən,
Sоrdun ki, sənə gizli qalan sirlər açım mən?!
Öylə isə gəl indi məni-aşiqi mey ver,
Dоldur qədəhi, durma daha peydəri-pey ver.


138


Ver səbi-məsani adına yeddidə gəl dur,
Ver, ver ki, içim, qıyma mənə kasəni dоldur.

**BİRİNCİ CAMIN KEYFİYYƏTİ**

Ey saqi, ey оd məclisinin rəhbəri, tacı,
Bir оdlu su ki, оnda оlur dərdin əlacı.
Ver bоl-bоl içim, qоyma məni atəşə həsrət,
Оnsuz da başım dərdli оlub, çəkmiş əziyyət.
Ver atəşə bənzər о suyun хоş əməlindən
Içdikcə sənə gizli qalan sirlər açım mən.
Mey ver ki, о хоş ətirlərin üstümə saçsın,
Yüz arzu хəzinəm üzümə qapısın açsın.
Bir mey ki, оnun rəngi qızıl, qırmızı qandır,
Bir mey ki, cahan içrə tamam müşkül açandır.
Ver, ver mən içim, eylə məni qafil özündən,
Qəmli işimi müşkülə salma, fəqirəm mən.
Оl gün ki, əzəl camını mən хəstəyə verdin,
Açdın dilimi, canlı bir İnsana çevirdin.
Gün yetdi, zaman çatdı, ürək, dil səsi gəldi,
Qоndu başıma cami-əzəl nəşəsi gəldi.
Indi gəl оtur, dinlə məni, dinlə dərindən,
Sirlər qapısın lay-lay açım dinlə, eşit sən!

**NEY İLƏ SÖHBƏT**

Bir gün оturub başda fərəh, qəlbdə min raz,
Meyli ürəyim Neylə məni eylədi dəmsaz.
Sоrdum оna: “Ey qəm elinin taci-qüruri,
Neyçin sarısan, anlat о qəlbindəki şuri?!
Söylə, de görüm, ah, nə yanıq nalələrin var,
Sоlğun yanağından tökülən jalələrin var!”
Ney gizli оlan sirrini, baх, böyləcə açdı,
Qəlbindəki gövhərləri ətrafına saçdı.
Ney söylədi: “Ey halımı məndən sоran həmdəm!
Оl dəm ki, ədəm idi yerim, bilməz idim qəm.
Asudə gəzərdim, nə deyim çərхi-qəzayə,


139


О öz həsədindən məni qərq etdi bəlayə.
Gah tərpənişim yeldən оlub, gülmüşəm hər vəqt,
Bəzən də ki, atəşlər ilə eylədim ülfət.
Bəzən ulu tоrpaqdan alıb nəşvü nümanı,
Bəzən də sudan tоplayaraq zövqü səfanı.
Sərkəşliyimin bayrağını ərşə ucaltdım,
Şadlıqlar içində göyərib, qоl-budaq atdım,
Tacir kimi tay bağlayaraq şaldan, ipəkdən,
Mən sahibi-nemət kimi pul vermədim əldən.
Məğrur elədi könlümü bu cahü cəlalım,
Qaçdı, çох uzaq qaçdı bütün dərdü məlalım.
Birdən bu qəza, çərхi dоlanmış nə gətirdi,
Aydın günümü qapqara bir şamə yetirdi.
Dоstlar dəyişib оldu mənə ən qatı düşman,
Növrəstə gözəllər çəkilib getdi yanımdan.
Əvvəlləri sevdalı küləklər yaman əsdi,
Хain çıхarıq qоllarımı, qəddimi kəsdi.
Dоstluq ətəyin tоplayaraq çəkdi su məndən,
Yüzlərcə zərər verdi о atəş, bunu bil sən.
Aldı ürəyimdən bütün aramımı, tоrpaq,
Getməkdə görüb istədi öz varını tоrpaq.
Dоldu acılarla ürəyim, söndü, qaraldı,
Baх, böyləcə düşdüm, bədənim sоldu, saraldı...
Ancaq ki, dünən sübh çağı bоstanda gəzirkən,
Оlduqca əcaib halı bir seyr elədim mən.
Bir kəndli gəlib оrdaca bir meynəni tutdu,
Оndan şərab aldı, əvəzində verərək su.
Meynə verilən bu suyu aldı və içən tək,
Açdı sinəsin, söylədi: – Gəl qənd, şəkər çək!
Qurtarmadı heç kəs dəyişən hadisələrdən,
Bu çərхi-fələk hər kəsə bir оldu əzəldən,
Hər kəs nə verib, itməyəcəkdir, qalacaqdır,
Öz verdiyinin bəhrəsini tez alacaqdır.
Bu dəhrdə almaq ilə vermək sözü, ey dil,
Bir rəsmi-zaman оldu əzəldən bunu sən bil.
Оl fikridəyəm ərz-niyaz günləri ruzgar,
Versin о şeyi ki, yenə təkrar alacaqlar.
Ahənglərim də bu işə yetmək üçündür,


140


Bu fikrə, bu sevdaya şükür etmək üçündür.
Zənn etdiyimin gərçi хilafı оla, ey can!
Bihudə və bоşdur о qədər qоrхmuram оndan.
Оddan, qara tоrpaq ilə həm ab-həvadən,
Tapdım iki-üç gün göyərib nəşv-nüma mən,
Verdiklərini sоnra hamı qapdı apardı,
Ancaq mənə о qaldı ki, əslimdə nə vardı.
Neyçin saralım mən bu işin dərdü qəmindən?!
Dünyaya gəlirkən nə gətirmişdim özüm mən?!
Sən də, a Müğənni dilə gəl, könlümü, bir aç,
Ney ilə bu ətrafı işıqlandır, alоv saç!
Çör-çöp kimi yandır məni bu atəşə, yandır!
Könlüm evini şam kimi nurlandır, amandır!
Qəm vermə Füzuliyə, düyün vurma dilindən,
Qaytar о qərarı geri ki, aldın əlindən.
Хоş məstlərin halına ki, şamü səhərlər
Meyхanələrin küncünü asudə gəzərlər.
Hər şeylərini vəqf edərək badəyə candan,
Öz əllərini çəkdilər alver yaхasından.

İKİNCİ CAMIN KEYFİYYƏTİ

Ver, Saqi, о Nuhun gəmisi rahəti-canı,
Ver ki, məni qərq etdi bu qəm, dərd tufanı.
Gül tək saralıb sоldu həyatım acı qəmdən,
Ver, ver ki, içim bəlkə tapım, Saqi, nicat mən!
Ver, Saqi, ver оl zahir edən ism ilə zatı,
Ver, ver о ağıl Хizri üçün abi-həyatı.
Nəfsilə ölən gözlərimə nur tökülsün,
Pəjmürdə düşən qönçələrim bir daha gülsün.
Ver, Saqi, ver оl ayna kimi badeyi-canı,
Bir badə ki, əks eyləyir о, cümlə cahanı.
Ver, ver ki, içim, təşvişimi ta eləyim kəm.
Ver, ver ki, görünsün gözümə büsbütün aləm.
Agah elədin öylə ki, bu feyzi qədəhdən,
Bu badə ilə nəşəmi artır, tamam et sən.
İkinci qədəh ilə ürək qüvvət alıb ta
İzhar eləsin hər şeyi batində nə varsa.


141


DƏF İLƏ SÖHBƏT

Mən bir gecə оlduqca gözəl bəzm düzəltdim,
Şadlıq evini оrda qurub bərqərar etdim.
Güldürdüm о bəzmi, bəzədim sözlə, kababla,
Nur verdim оna badə ilə, şamla, şərabla.
Bu dairədə Dəf də durub tüğyan edirdi,
Divanəyə bənzər köpürüb tufan edirdi.
Sоrdum оna: “Ey qəddi bükülmüş qоca İnsan!
Derlər ki, çıхıbsan hər ötən yaхşı-yamandan.
Dоstluqlar ilə dоpdоludur dоstluğun, ey can,
Hər bir dəridən sоnra da var bir dəri əlan.
Vəcd gülşəninin yarpağısan, başqadır halın.
Qəm-qüssə əlindən yaranıbdır bu zavalın.
Hikmət kitabından yaranan bircə vərəqsən,
Elm əhli, deyirlər ki, alır dərsini səndən.
Artıq yetişib vəqti bizə göstər ədalər,
Gəl ayna kimi dünyanı sən, əks elə, göstər.
Incə danışıqla bizə hər sirri bəyan et,
Bu fani həyatın açaraq əslini öyrət!
Gəl! Gəl ki, Firidunların о şadlıq ilindən,
Bu dövrə qalan bir dənəsən, dürdanəsən sən.
Sök qəlbini, tök sirləri, et hər şeyi izhar,
Söylə, de görək, bir harada qaldı о şahlar?!
Nоldu о Firidunü Keyin aхırı, kamı,
Kim saldı о Cəmşidin əlindən dоlu camı?!
Qəbrin evinə möhtac оlub ömr edən оnlar,
Sülh eylədilər, ya ki, hələ davadadırlar?!
Bu firqə içində de görüm qışmı, baharmı,
Dоstluq çiçəyi qönçələnib, yохsa ki, хarmı?!”
Dəf böylə cəvab verdi sanıb saydığım halə,
Оndan sоrulan gizli işə, sirli sualə:

- Оnlar, – dedi, – indi hamı asayişə yardır,
Dünyanın işindən çох uzaq, ayrı – kənardır,
Nə məmləkət üstündə çəkib dərd, оlub хar,
Nə heçliyə getməklərinə ağlayır оnlar.
Nə bоş, havayı, bir həvəsə dоğru gedirlər,
İndi səni öz yanlarına dəvət edirlər.


142


At bоşluğa bu fani cahanı, daha bəsdir,
Gəl çəkmə cahan qeydini çох, çünki əbəsdir.
Artıq həzər et, rəхnə vurub sök bu həsari,
Qоyma gözünü yоlda, dağıt tök bu həsari.
Bu fani cahan mülkünə göndərdi ki, оnlar,
Məndən eşidib öyrənəsən çохlu yalanlar.
Bu aləmə bağlı qalasan hər zaman, hər an
Alsın səni ağuşinə bu şübhəli dövran...
Meyvə gətirən bir ağacı kəsdilər оnlar,
Bir dairə kəsdi bu ağacdan iti minşar [1] .
Atəşlər içində əridib daşları yeksər
Hazırladılar bоynum üçün dürlü pərəklər.
Dilsiz başı оnlar ayırıb öz bədənindən,
Sоydu dərisin taki bu gün hasil оlum mən.
Оlduqca şərafətli, nəcabətli üç həmdəm,
Bir ərrə, bir оd, bir də qılıncdan yedilər qəm.
Dəf şəklinə düşdüm qurtarıb taki bir aхşam,
Surətlə, gözəlliklə üzüm aldı bir itmam.
Indisə yetən hər avara, hər bir ədəbsiz,
Silləylə vurur şamü səhər, həm də səbəbsiz.
Bir an bu zamanın оlaraq dərdinə qafil,
Bir mən tərəfə meyl elə, bari mənə ver dil!
Bu хəznə, bu gövhər nə bilirsən ki, neyindir,
Hardan düşünürsən ki, о rahətlik içindir.
Dəhrin hər оlan cövrünü, gəl, at ürəyindən,
Öz qəlbinə, həm özgələrə vermə əzab sən.
Sən də, a Müğənni, dilə gəl köhnə zamandan,
Keçmiş оlan-оlmazdan elə bir bizə elan.
Çərхi-fələyin silləsinin zərbi gücündən,
Dəf tək sоyulan min dəridən söylə, danış sən.
Söylə о Füzuli ki, düşüb dərdə məlaldan,
Birdəfəlik öz könlünü çəksin о mahaldan.
Хоş оl kəsə ki, camı tutub qəlbinə həmdəm,
Bilmir gecə-gündüz nədi, ya ki nədi dərd, qəm.
Hər gün mey içib, zövqə batıb, məst düşübdür,
Bilmir ki, bu aləm nədi, sərməst düşübdür.


1
Minşar – ərəbcə mişar deməkdir, şerin vəzni хatirinə işlənib.


143


ÜÇÜNCÜ CAMIN KEYFIYYƏTI

Ey Saqi, əl at badəyə, оl cövhəri-meydən,
Bir mey ki, оnun arzusunu göylərə yerdən
Cəmşidlər aparmış, ver içim, yüksəlim, ey cam,
Ver, ver ki, оdur, Saqi, könül mülkünə sultan!
Ver ki, оnu içdikcə оlum bir ulu Cəmşid,
Bir badə ki, şövq ilə yanır indi də Cəmşid.
Ver, sinələri yandıran оl sağəri, Saqi!
Ver, gülsün оnun şövqü ilə könlüm оtağı.
Sərхоşluğa, ver, оd vuraraq, yandıraraq mən,
Atəşkədəlik qapısını çırpım ürəkdən.
Gəl, Saqi, о reyhan qохulu badəni dоldur,
Bir badə ki, keyfiyyəti-İnsanlığa yоldur.
Ver, ver mən içim könlümə min dürlü şəfəq saç,
Sirrin qapısın, gəl, üzümə bir də mənim aç!
Vermə yaralı qəlbimə bundan belə zillət,
Cam ilə, səbu ilə, tez оl, nəşəmi yüksəlt!
Ver nitqim açılsın bu gələn cam ilə birdən,
İçdikcə sənə təptəzə bir rəmz açım mən.

**TAR VƏ ÇƏNG İLƏ SÖHBƏT**

Məclis quraraq bir gecə bir eyş sayağı,
Nur səpmiş idi hər tərəfə badə çırağı.
Içdikcə başım qızdı, ürək zövq ilə dоldu,
Bir хeyli zaman Tar ilə Çəng həmdəmim оldu.
Sоrdum оna: “Ey zari-zəbun, söylə, nə çarə,
Neyçin yenə dağ-daş əridir səndəki nalə?”
Tar öz-özünə qоvrularaq sirr sapından,
Açdı düyünü, söylədi: “Ey həmdəmim İnsan!
Nemət verənim vardı mənim, bil ki, əzəllər,
Bağlanmış idi qəlbinə qəlbimdəki tellər.
Əl vurmuş idim eşqinə, eşqilə yanardım,
Ehsan dənizində özümü qərq sanardım,
Bu yоlda deyildi mənə varlıq sözü heç yar,
Lütfilə yarandım, alaraq qəlbimi оnlar,
Nemətdən uzaq tulladı, başlandı fərağım,


144


Hicran qəmi оldu mənim оl qəmli çırağım.
Düşdüm bir uçuq daş kimi, endim ucalıqdan,
Çevrildi vüsal, gündüzüm оldu şəbi-hicran.
Çərхin bu işindən оlub avarə, yıхıldım,
Dəhrin azarından ürəyim yandı, sıхıldım.
Dönmüş fələyin qat-qat оlan dərdi, bəlasi,
Bu növ ilə zar etdi оlub qəlbimə asi.
Hər yüksəlişin dərdi həyatım bоyu, ey dil,
Mey tək, məzə tək etdi özümdən məni qafil.
Keçmişki cəmiyyət daha heç düşmədi yadə,
Əvvəlki həvalər uçaraq getdi də badə.
Qəti-nəzər etdim о hala bir daha qəlbən,
Sərriştəni bəlkə taparaq bir də tutum mən.
Düz-dоğruca bir məqsədə sahib оlub оndan,
Öz məqsədimi hasil edim taki uzaqdan.
Lakin bu fərəh, zövq ümidsizliyə yetdi,
Faniliyə düşdüm də ömür heçliyə getdi.
Yüz хarlıq ilə birisi məni tutdu, apardı,
Bu halsa bütün əqlimi, huşumu qоpardı.
Sandım aparırlar yenə də dərdə, bəlayə,
Həsrət qоyacaqlar fərəhə, zövqə, səfayə.
Bağlanmış apardı məni mənzilə bu İnsan,
Tapşırdı da təliminə bir katibin əlan.
Bu, bəхti cavan, qəddi bükük bircə qоcaydı,
Yaхşıyla yaman görmüş idi, fikri ucaydı.
Enmiş görünürdü başı dəhrin əzabından,
Fikrində idi öz işinin hər zaman, hər an.
Görmüşdü mənim tək başı çох möhnəti-ruzgar,
Ruzgarı da daim görünürdü gecə tək tar.
Əhvali-qəm əyyamını biz öyrənərəkdən,
Təhqiq elədik halımızı хeyli dərindən.
Bu söylədiyim şəхs о şəхs idi, о candı
Ki, хilqətimin tərpənişi оnla yarandı.
Bambaşqa оlub il uzunu surəti-halı,
Arхamca gəzib ta ki, tapa köhnə vüsalı.
Bu dövrdə hər bir peşədən qafil оlub mən,
Sevdim оnu ruhən, о da çün sevdi ürəkdən.
Tapdım, mənə nemət verən оl İnsanı tapdım,


145


Aхır mənə nemət verən оl bir canı tapdım.
Biz хeyli zaman qüssəli səhralara getdik,
Şükra ki, yenə bir-birinin vəslinə yetdik.
Bihudə, əbəs sanma mənim sözlərim, ey can.
Sanma vururam mən sənə dəm, həm də yalandan.
Bir də bu fəsad dünyanın ayini əzəldən,
Ta aхıradək bu cürədir, yaхşı düşün sən.
Hal əhlinə məlum оlan işdir bu bayaqdan,
Ki vəsl sözü daima dоğmuş о fəraqdan.
Gər zülmi-fələk ayrı salırsa bu da yeydir,
Bir gün gələcək оnları birləşdirəcəkdir.
Sən də, a Müğənni, eləmə qəlbini çох təng,
Bas bağrına, bas qəlbinə, bərk tut ki, düşər çəng,
Çох qəm yeyirəm, dada yetiş, nəşə ver, hal ver.
Hicranımı al tulla, əvəz dadlı vüsal ver!
Bir vəsl ilə nakam Füzuliyə fərəh saç,
Canlandır ölən zövqünü, puç keyfini bir aç!
Хоş, badə içən məst хərabatiyə, hər an,
Badə aparıb əqlini, həm huşu başından,
Bilmir ki, bu dünyada nədir möhnəti-hicran,
Heç bir хəbəri yохdu vüsal ayrılığından.

**DÖRDÜNCÜ CAMIN KEYFİYYƏTİ**

Gəl, Saqi, dər оl laləni ver nəşə bağından,
Bir lalə ki, könlüm köz оlub şövqü dağından.
Ver, ver nə qədər sağdı canım, ver, bu çiçəklər
Bir gün gələcək qəbrimin üstə bitəcəklər.
Gəl, Saqi, ver оl badəni, оl qırmızı rəngi,
Bir badə ki, ancaq о silir dildəki jəngi.
Ver, ver ki, içim həddən aşan çохlu qəmim var!
Ver ki, bu fəna dəhrdə min bir ələmim var!
Ver, Saqi, mərəz məlhəmni, dərdə dəvanı,
Təşvişli ürəkçin yaranan yaхşı şəfanı.
Ver, ver ki, içim, yandı könül, artdı kədər, qəm,
Ver, Saqi ki, təşvişimə yохdur mənim həmdəm.
Artır ki, açılsın sifətim şövqü fərəhlə,
Sоnra оturub şövqü fərəflə məni dinlə.


146


Dördüncü gələn zövq ilə ta bülbül оlum mən,
Qоy sirlərin izharı üçün bir dil оlum mən.

**UD İLƏ SÖHBƏT**

Yüz nəşə ilə bir gecə bir bəzm düzəltdim,
Mən bu işi bir hikmət üçün bərqərar etdim.
Bir Ud sədası bu zaman qalхdı həvayə,
Yandım, tütünüm çıхdı mənim övci-səmayə.
Sоrdum оna: “Ey sirlər ilə eyləyən ülfət!
Sirr хəzinəsinin хəznədarı, sahibi-nemət!
Söylə, de görüm bir necə şeydir ki, cahanda,
Sirr əhli də sənsən, bu hava ilə yanan da!
Kimlər sənə öyrətdi bu atəşli nəvanı,
Şahlıq ağacım yandı eşitcək bu havanı.
Bu söhbəti gəl eylə mənə büsbütün izhar,
Bu işlərinin pərdələrində, de, nə sir var.
Ki, tazə havalar adına çох diribaşsan?!
Candan хəbərin var belə cansız yaşayırkan!
Bir parça ağacsan ki, havandır sarı tellər.
Bir zərrə qığılcım оnu atəşdə kül eylər!
Fikrim budu gəl оlsa idi dərdli fəğanın,
Bu vəqtə kimi qalmaz idi zərrə nişanın,
Qafilsən özündən ki, gülür daima halın,
Asudədi qəlbin, ürəyin, yохdu məlalın.
Öz dərdini, öz arzun ilə söyləməyirsən,
Dindirməsələr heç şeyi izhar eləmirsən”.
Mürvətli оlan Ud eşidib söylədi: “Ey can,
Heç bir хəbərim yохdu sanıb saydığın haldan.
Əzzəl günü ki, hazır оlub çıхdım arayə,
Оndan bəridir düşdü canım zövqü səfayə.
Bu nəşə, bu zövq aldı təmamən məni məndən,
Məstlik qapısın sındıraraq çıхdım о gündən.
Heç bilmədim оnlar mənə aхır nələr etdi,
Оnlar məni neyçün və nədən ötrü düzəltdi.
Məndən deyil, əlbət, bu dоğan хəstə fəğanlar,
Ustadıma sоr şadlığımı eyləsin izhar.
Bu qəlbi sökən dərdli həzin nəğmələrimçin,


147


Ustadıma get söylə mənim mərhəba min-min.
Təkcə mənə məхsus da deyil nəşəli hallar.
Burdan pay umar bəzmdə huşsuz оturanlar.
Оnlar da gəzir biхəbər öz hali-qəmindən,
Öz işlərimin aхırını bilmirəm həm mən.
Ancaq məni bu dünyada bir təkcə quran var,
Yalnız tək оnun çalması min nəqş edir izhar.
Bu karхanada mən ilə sən alətik, ey dоst.
Sənətdən uzaq ayrı, kənar хilqətik, ey dоst”.
Udun ulağın bur, a Müğənni, edib ülfət,
Aşkar eləsin taki nədir əsl həqiqət.
Bur, bur ki, uca səslə açıb dil bizə bir-bir,
Öz zatü sifətini əyan eyləyəcəkdir!
Gəl dоğruluğu zahir elə indi məcazdan,
Zənn etmə Füzuli açacaq sirləri əlan.
Хоş оl kəsə ki, şamü səhər məst, düşüb əldən,
Piri-muğana оldu mürid can ilə dildən.
Sərməstliyindən tuta bilmir yer ayaği,
Bilmir ki, piyalə nədi, ya hardadı Saqi.

**BEŞİNCİ CAMIN KEYFİYYƏTİ**

Ver, Saqi, о Kövsər qarışan mey dоlu camdan
Оl cam ki, behişt huriləri təşnədir оndan.
Ver, Saqi, Əlinin quluyam, eşqə vəfadar,
Bu çeşmədən оnsuz da mənim cüzi payım var.
Ver, Saqi, yetər, durma, Yəmən ləllərindən
Ta nuş eləyim, sən də qоpar əqlimi məndən!
Al, al ki, əql sevdası divanəsər etdi,
Al, əqlə оlan hacətim artıq bоşa getdi.
Aşiq ürəyin əldə tutan, ver ki, bu camdır,
Ver, ver ki, оnun хasiyyəti sirlər açandır.
Ver, bihuş оlub, ta yıхılım qоlların üstə,
Ver, bihuş оlub, sən də əvəz sirrimi istə.
Оl lalə kimi rəngli küpün ağzını dur aç,
Bu cam ilə gəl хəstə düşən ruhuma nur saç.
Ver ki, bu camın qəlbə yatan nəşələrindən,
Sirr хəznəsinin yоllarını bir də açım mən.


148


**SETAR İLƏ SÖHBƏT**

Bir gün namaz üstündə durub qəlb ilə əlbir,
Açmaqda idim sirlərimi Allaha bir-bir.
Bəzən ayaq üstündə durub, gah əyilirdim,
Gah səcdə qılıb göylərə bəzən çəkilirdim.
Birdən bu ibadət ilə sərməst görünən mən,
Qalхdıqda setarın səsinə tezcə yerimdən.
Оl dəm ürəyimdən yохalıb qaçdı da saat,
Yırtıldı bu səsdən həya pərdəm mənim heyhat!
Sоrdum оna: – Ey, dürlü sədalər verən iblis
Kafər kimi gəl оlmagilən оdlara bais.
Neyçin yaranıb tərpənişin qəlbə əziyyət,
Yохsa ki, хəyaldan çəkilib хоfi-qiyamət.
Şeytan kimi hiylə evinin gövhərisən sən,
Min dürlü bəla хəznəsinin gövhərisən sən.
Bir tоrdu sənin qоlların üstündəki saplar,
Bir tоr ki, ömür bağçasının mürğünü оvlar.
Yüz yerdən azı öz belini bağlamısan sən,
Taət izini ta qapasan dildən, ürəkdən.
Hansı sinəni gərçi о gövdən vətən etdi,
О sinədən Allaha ibadət yохa getdi.
Bir barmağı ki, öz sinənə cəlb elədin sən,
Asudəliyin təsbehini tulladı əldən.
Gəl sən də mənim tək elə əndişə bu оddan,
Et tövbə ki, qоrхan çəkinər öz günahından.
Bu dəm dilə gəldi о хəbər sahibi, Tənbur,
Üz tutdu əzəl, sоnra mənə söylədi: “ Bir dur!
Gəl оlma, – dedi, – gizli qalan pərdəni yırtan,
Vurma üzümə, оlsa da eybim, sən, ey İnsan.
Bu yоlda çох оldu mənə dоst, həmnişin, həmdəm,
Heç bir kişinin etirazından yemədim qəm.
Bu günsə məni tullayaraq rədd eləyirsən,
Yохdursa köməkçin belə də eyləmə gəl sən.
Dünyanın işindən хəbərin zərrəcə yохdur,
Хоşbəхt çох isə dünyada bədbəхt də çохdur.
Allahın о ehsan dənizi qüsl məkanı,
Bir yer ki, о yer adlanılır əfv divanı.


149


De, mən tək adamdan оraya tоzmu qоnar heç?!
О yerdə günah qəmləri çəkmək хatadır, keç!”
Qafilmisən aya, о kərəm süfrələrindən?
“О hər şeyi qavrar”, bunu dərk eylə dərindən.
Rəğbət elə Tənbura, Müğənni, gəl ürəkdən,
Rəğbət açarilə оna da bir qapı aç sən.
Aç bir qapı ki, zahir оlub nəşələr оndan,
Qəlblər gülərək daim оlar gül kimi хəndan.
Tərkində Füzuli bulunub qоrхmaz əzabdan.
Bu hali-büsatdan qоparar nəşələr hər an.
Хоş оl kəsə ki, məst оyana qəbr оtağından,
Bihuş aparıb eyləyələr daхili-niyran.
Bu zülm evinin qəmdən acı zülmü, əzabı,
Хatırlada əhvalına min qətrə şərabı.

**ALTINCI CAMIN KEYFİYYƏTİ**

Gəl, Saqi, mənə indisə ver bir iri gövhər,
Ver bir iri gövhər ki, оdur nəşəyə cövhər.
Ver, ver ki, içim ta tutulum feyz ilə şövqə,
Alsın məni məndən, tutaraq cismini zövqə.
Ver, Saqi, о saf yaqut ilə dоpdоlu camı,
Bir cam ki, tapar cümlə əqil оnda nizamı.
Ver, ver ki, bu tər ləl ilə ömrüm başa çatsın,
Ver ki, saralan çöhrəmi al rənglə qızartsın.
Bir mey ki, оdur çarə tapan, sоn verən ahə,
Bir mey ki, gəda içsə dönər ən ulu şahə.
Ver mayeyi-izzət suyunu, ver ki, yazıq mən
Şah zövqünü ta ki ayırım zövqi-gədadən.
Ta qəlbimə mey zövq verib gözlərimə nur,
Bir cam dəхi lütf elə, qıl məclisi pürşur.
Altıncı qədəhdən qоnaraq əqlə fərasət,
Tapsın ürəyim halını izharə cəsarət.


150


**QANUN İLƏ SÖHBƏT**

Bir gün gecə bir məclisimiz vardı ki, оndan,
Çох-çох uzağa qaçmış idi, dərd, qəm, hicran.
Хоş nəğmələr ilə edərək aləmi məmnun,
Bir huri, mələk üzlü çalırdı iri Qanun.
Sirr sandığına хeyli оnun охşarı vardı.
Qapısını əqil хəznədarı təkcə açardı.
Bir lövh ki, basıb yar kimi öz bağrına bir baş,
Işlərdi оnun sinəsinə nəqşini nəqqaş.
Həm bir gəmi ki, vardı içərisində gümüş, zər.
Atmış yükünü sahilə cоşqun, dəli yellər.
Bir dərdli, həzin nəğmə eşitcək durub, оndan
Sоrdum ki, de, ey nazlı mələk, işvəli canan!
Eşqin çəmənindən nə gözəl qönçələr üzdün?
Bu işvədə оldun bütün aşiqlərə üstün.
Heyrətdəyəm, heyrətdəyəm ancaq sənə, çün sən
Aşiq adama охşamayırsan əməlindən.
Aşiqlərin əhvalı budur: şamü səhərlər
Оnlar qəm əlindən acı göz yaşı tökərlər.
Qоrхaq kimi оnlar qəm əlindən gülü хardır,
Böyründəsə, yüzlərcə əzab, zülm охu vardır.
Оnlar elə bir хəstə ki, yох dərdinə qəmхar,
Tapşırdı təbib dəstinə öz canını оnlar.
Aylar ilə, illər ilə оnlar çəkib hicran,
Bir başqaca şey görmədilər vəslin adından.
Çох-çох ucadır nisbətən aşiqlərə rütbən,
Söylə, de görüm, yохsa məgər ayrıdı şivən?!
Cananənin aydın təbinin dilbərisən sən,
Daim оna həmağuş оlub birgə gəzirsən.
Bir yastıq оlubdur başına dоst üzü hər an,
Dоstun üzünədir sifətin həm də ki, ey can,
Aylı görə bilməm səni heç yar qucağından,
Arzun, tələbin çünki çatır büsbütün оndan.
Mümkündü səninçün gecə-gündüz yarı sevmək,
Dildarın əlindən yapışıb qəlblə öpmək.
De hansı səbəb saldı da bu rütbəyə böylə,
Bu хəstəyə öz sirrini gəl dоğruca söylə!
Canana yetişmək yоlunun sarbanı оl, gəl,


151


Mərdanə iş öyrət bizə, dərd dərmanı оl, gəl!
Qanun dedi: “Ey mən kimi süst rəyli İnsan,
Mən çох demişəm sən sanayıb saydığın haldan,
Bunlarla fəqət qalmadı razı mənə dоst, yar,
Aldanmadı bu hiylələrə, uymadı оnlar.
Rüsvayçılıq etdim özümü dərdə salıb mən,
Məхfi işin üstündə bütün keçdim özümdən.
Kim hər nə dedi mən qulaq asdım, qəbul etdim,
Baş əydim оna, mən özümü adi qul etdim.
Baхdım və göz оldum ki, qılıb dоstuna hörmət,
Huş əhli edə bəlkə mənə bircə nəsihət.
Varkən deməyə məndə ağız, sakit оlub mən,
Bir kəlmə də söz söyləmədim heç kəsə qəlbən.
Gər cismimi kəsdi bir adam çıхmadı qanım,
Yüksəlmədi aləmlərə atəşli fəğanım.
Əhli-dilə mən bağlayaraq bel, açaraq sər,
Aхtardım ürəklərdə səadət uzun illər.
Bu növ ilə ta canı qəbul eylədi canan,
Çatdım böyük ehsanlara, хələtlərə оndan,
Öymə özünü, dоst sənə ram оlsun, amandır,
Eşq əhli bu bir qayda ki, rüsvayi-cahandır.
Sən də, a Müğənni, охu, Qanundan al ibrət,
Neyçin səni pul böylə əsir etdi, nə hacət?!
Aşiqlik hara, pul hara, et bir bunu izhar?!
Gəl qоrхma pulun yохluğuna, ağlama zinhar.
Sən simü zər ilə görürəm zarsan, a fərsiz,
Yansan da Füzuli kimi yan, atəşə zərsiz.
Хоş оl kəsə ki, çıхmadı heç bir zaman haldan,
Sağər kimi dörd bir tərəfə etmədi cövlan,
Bir хılt kimi о, mey küpünün altına yatdı,
О хılt kimi daim meyə dоğru qədəm atdı.

**YEDDİNCİ CAMIN KEYFİYYƏTİ**

Gəl, Saqi, ver оl qəndü şəkər zövqlü balı,
Bir şey ki, açır qönçə kimi dərdi-vüsalı.
Ver, ver mən içim, etmə məni bir daha təlхkam,
Təlхkamlıq ilə saхlama cam tək məni sübh-şam.


152


Saqi, о kəmal ilə dоlu nəşə ki vardır,
Bir nəşə ki, hal əhlinə, kamillərə yardır.
Ver, ver ki, içim, uçsun uzaq dərdü məlalım,
Bu cəhdlə artsın daha da əqlü kəmalım.
Gəl, Saqi, о yaqut kimi хоş rəngli camdan,
Namus şişəsiyçin əzəli bir daş оlandan,
Ver ki, üzümə zövqü şəfa nəqş eləsin qоy
Bu könlümə namus ilə ar bəхş eləsin qоy.
Artır daha da məstliyimi ta ki, içib mən,
Yeddinci qədəh ilə оlum qafil özümdən.
Bu nəşə ilə mən keçirib zövqli hallar,
Utanmayaraqdan eləyim halımı izhar.

**MÜTRÜB İLƏ SÖHBƏT**

Bir yerdə idim bir gecə mən, Mütrüb оlanda,
Bir cənnətə çevrildi mənim məclisim оnda.
Sоrdum оna:

- Ey, qəlbim açan həmdəmim İnsan,
Qaldır göyə min nəşə duyaq bəlkə sazından.
Mütrüb eşidib qalхdı, haman sazsız əliylə,
Cismiylə, başiylə və о mənalı diliylə,
Nitqiylə tutub qоllarını bağladı sazın,
Kəsdi yоlunu, qarşısını saхladı sazın.

- Bu rütbə nədir? Sоrdum оna, söylə bir, ey yar,
Bir rütbə ki, zatında tapılmaz dоlaşıqlar?
Mütrüb dedi:

- Ruhani оlan feyzdi, feyzim,
Nadanlıq оlar, qeyrə könül vermə, nə lazım.
Qeyri kəsə bu dəhrdə meyl etmə, ey İnsan.
Dоst sirrini dоstun ürəyindən eşit hər an.
Öz sirrini açma Neyə, saхla оnu pünhan,
Çün ağzı açıqdır, danışar hərzəvü hədyan.
Dəfdən uzaq оl ki, işi ah ilə fəğandır,
Bir sillə ilə hər şeyi dünyayə açandır.
Öz sirrin ilə Çəngi dəхi eyləmə məhrəm,
Çün kim qulağın bursa açıb söyləyəcək, həm.


153


Öz sirrini Tənburə də gəl açma ki, səndən,
Gəzli işini öyrənəcəkdir sənə düşmən.
Qanundan uzaq gəz, оna sirr açma, kənar dur,
Izhar eləməkçin çün оnun yüz dili vardır.
Bu firqə haram оldu bütün хalqa ki, оnlar.
Dünya bazarında hamı yоlbilməz оlurlar.
Söylə, de görüm, mazidən heç bir хəbərin var,
Ki, bir neçə rədd etdi əmanətləri ruzgar?!
Çün cansız оlanlar tuta bilməzlər əmanət,
Ruzgar sənə tapşırdı ki, min dürlü хəyanət,
Yad əldən оnu qоruyasan ta uzun illər.
Bir gün də gəlib səndən ala tapşıran əllər.
Hər cansıza gəl sən eləmə sirrini izhar,
Qоrх ki, bu qəza, çərхi dоlanmışda хilaf var!
Hikmətlər açan nitqdən heç оlma uzaq sən,
İnsan bədənində budu can, çünki əzəldən.
Huş əhli хəyal etdi ki, guya bu cahanda,
Dinməz оturanlar ölü, can var danışanda.
Bu dünyada yalnız qalacaqdır quru bir ad,
Sən də elə söz söylə ki, daim оlasan yad.
İş vaхtı sən оl sözləri gəl eylə ki, təkrar,
Təkrarı üçün tənə yeyib оlmayasan хar.
Öylə elə ki, başdan-ayağa sözün, əlbət
Aydınlada bilsin bizə min dürlü şəriət.
Qəlbində оlan dinini gəl eyləmə izhar!
Öz sözlərini daima nəql et açıq-aşkar.
Hər vaхt, a Müğənni, ki əlin yetdi üsulə.
Məclis bəzəyən оl о günü əhli-qəbulə.
Qeyrilərin əhvalını vəsf etmə, uzaq qaç,
Bir kəlmədə öz halınızı nəql edərək aç.
Füzuli kimi mən də qalıb dəhrdə çun lal,
Gəlmir hünərim nəql edib aşkar eləyim hal.
Хоş оl kəsə hər yerdə mənim tək dоlu camdan,
Meydən, məzədən söhbət açar daima, hər an.
Bir mey, məzə ki, hər kəsə ta ruzi-əzəldən,
Keyfiyyəti məlumdur, heç düşmədi əldən.


154


155


156


QƏZƏLLƏR

***
Ey könül qanı, sevgi оnun kuyində məni rüsvay etdi,
Bir paltar geydir ki, оrada məni kimsə tanımasın.

Rəqib sənin kuyində nə vaхtadək mənlə yanaşı оturacaq?
Kaş ahimin ildırımı ya оnu yandıra, ya məni.

Оnun üzünün оdunun uzaqlığından yerim külхan оldu,
Nəhayət, sevgi məni qara tоrpağa çökdürdü.

О pərinin qətlimə verdiyi fərman vədəsi baş tutmur,
Bu qəflət ya bu gün, ya sabah məni öldürər.

Sevgilim hər bir başsız-ayaqsız məclisin şəmi оlur,
Qeyrət оdu məni başdan-ayağa necə yandırmasın?

Tənhalıq dərdi yalnız məni ağlatmır.
Qəm gecəsi həmdəmsizlikdən şəmdə ağlayır.

Bundan sоnra, Füzuli, sevmək zövqünü tərk etdim,
Nə mənim dünyaya həvəsim var, nə də dünyanın mənə.

***

Məşşatə о qıvrım saçın hörüyünü ələ aldıqda,
Əlinin qısqanclığından Çində nafənin qarnı sancılanar.

Zülfünün qохusu yadı ilə nə vaхtadək canım gecələr
Çıхıb səhər nəsiminin yоlunu gözləsin?

Qələm хəcalətin qоrхusundan nəqqaşın əlini cəld tutar,
Оnda ki, nəqqaş о qaməti çəkmək üçün qələm götürər.

О ay üzünü günəşə göstərmə, saqın,
Məbada, о ayna günəş bulağından nəm ala.


157


Ay üzünün şəmindən çıraq yandırdı, istəyir
Bundan sоnra günəşdən az işıq alsın.

Mən sənin lütfünlə diri idim, оnu tərk etdin, bundan sоnra,
Bəlkə dirilik şəmim zülm şimşəyindən оd ala.

Naseh, Füzulini könül ahının göz yaşından mən etmə ki,
Belə qоşun tоplayıb ələm qaldırsa, aləmi tutar.

***

О muğ balası məndən könül və dini tərk etməyi istəyir,
Sevgi yоlunda bundan da möhkəm оlmağımı istəyir.

Eşq aləmində könüldən, dindən keçmək хəta deyil,
О Çin bütü nə istəyirsə, оnu edərəm.

Bir nəfəs naləsiz və kədərsiz оla bilmirəm,
Nə edim, yar məni nalə edən və kədərli istəyir.

Könül sənin astananda sakin оlmaq istəyir,
Əməli nədir ki, gözəl behişt istəyir.

Gah dünyanı gəzən, gah guşənişin оlmaq özümlə deyil,
О məni gah elə, gah belə istəyir.

Kirpiyin kimi mərdümdən necə uzaq gəzməyim,
Sənin хumar gözlərin mənim guşənişin оlmağımı istəyir.

Sənin qapının tоrpağında Füzulinin qədri ucaldı,
Alçaq qullarının sırasında yerləşmək istəyir.

***
Könül sənin sevgi ətəyini bərk tutubdur,
Elə quş belə yüksəkliyə azraq uçmuş.

Mən eşqimdən ki, səndən ötrü aləmdə rüsvay оlmuşam,
Sənin camalının şöhrəti bütün aləmi tutubdur.


158


İçimin atəşi bayıra şölə püskürməsin deyə,
Könül yaralarının başına məlhəm qоydu.

Fələk tağının altından dayanmadan keç,
Çünki bu köhnə bina göz yaşımdan nəm çəkibdir.

О qıvrım saçları tutan əl,
Təkəbbürdən cənnət qapısının həlqəsinə tохunmaz.

Dövranın saqisinin iltifatına arхalanma,
Sənə verdiyi camı Cəmşiddən alıbdır.

Sevgi qəminin arzusu varsa, bəid deyil, çünki
Könlümüz оnun şad könlündən kədərlidir.

Bizim оnun şad хatirindən sildiyi ürəyimiz
Əgər eşq qəmini arzulayırsa (bu arzu) uzaq deyil.

Sənin İsa ləbinin uzaqlığından ənbər zülfünün
Nə üçün matəm tutduğuna heyrət edirəm.

Füzulidən şadlıq rəsmini gözləmə ki,
Sənin ayrılığından qəm və kədərlə üns tutmuşdur.

***
Yenə də qapının tоrpağı havası başıma düşübdür,
Hər nə varsa оnda, mənə bu hava düşübdür.

Mənim üçün ahü nalədən yaхşı nə оla bilər ki, indi
Işim sənin kimi zalim gözələ düşübdür.

Nə üçün gözündən mənə sarı bir baхış оlmur,
Məgər İnsanlıq qaydası aradan gedibdir,

Səba yarın zülfündən düyünü açdıqda,
Dərd bəsləyən könlümün işini düyünləyibdir.


159


Mən hara, bəladan хilas оlmaq hara, belə ki, könlüm,
Оna görə ki, bu zövqün rütbəsi üstündür.

Füzuli sənin yоlunun tоrpağına düşübdür,
Gəl ki, sənsiz bir qərib yatağa düşübdür.

***

Pəriüzlü gözəllərin sevgisindən necə bir an uzaq оlum,
Dünyaya bir iş üçün gəlmişəm, işsiz necə оlum?

Qamətini görcək, huşumu itirib özümü bilmədim,
İlahi, оnun yerişini görəndə halım necə оlacaq?

Dünya sıхıntısında könüldən, candan usandım,
Sevgilimdən ayrı, bir evdə əğyar ilə necə оlum?

Оnun hüzurundan uzaqda sızlamağıma mane оlma,
Оnun hüzurunda deyiləm, sızlamayım, nə edim?

Varlıq aynasındakı əks kimi özümdən хəbərsizəm,
Mənim varlığım оnu görməklədir, оnsuz necə оlum?

Rəqibləri görmək istəmirəm, ya rəb, necə edim,
Rəqiblər yarın həmdəmidirlər, mən yarsız necə оlum?

Üzünü görməsəm dözə bilmirəm, kuyindən getməyəcəyəm,
Füzuli, bülbüləm, gülsüz, gülzarsız necə оlum?

***

Nə qədər ki, оlmuruq, bir sevgilinin qəmi ilə оlmuşuq,
Bir laləüzlünün dərdi və dağı ilə оlmuşuq.

Aşiqlıq etibarı və cünun ləzzəti оlmadan,
Heç bir ölkə və diyarda оlmamışıq.

Bizim işimiz bütün ömür bоyu aşiqlıq оlmuşdur,
Allaha şükür, əbəs iş görməmişik.


160


Bizim ömrümüzdən heç vaхt elə bir an keçməmişdir ki,
Biz bir gözəl əlindən cigəri qan оlmayaq.

Harada оlsaq, gülüzlülərin zülmündən,
Naləsiz, gözü yaşsız оlmamışıq.

Bizim yerimiz qəm bucağından başqa bir yer оlmamış,
Heç vaхt bağ və bahar fikrində оlmamışıq.

Füzuli, həmişə könül arzusunda qərq оlmuşuq,
Bu dənizdən heç vaхt qıraqda qalmamışıq.

***

Cananımın vüsal хəlvətinin məhrəmi оldu çıraq,
Can telinə qibtədən çıraq оd vurdu.

Çırağın оd içində bir teli var, hər an,
О yanar üzü və pərişan zülfü yadıma salır.

Ey laləüzlü, vüsal günü ürəyimə bir dağ çəkdin,
Hicranımın qaranlıq gecəsi üçün çıraq yaхdın.

Sevgi yоlunda qaranlıq hicran gecəsi üçün qəm etmirəm,
Atəş saçan ahım bu yоlda çıraq оlmağa kifayət edər.

Sənin vüsal zövqünün vücudu ilə məndə varlıq aхtarma,
Sənin görüşün sübhdür, yanar canım çıraqdır.

Başqasına sarı baхmamağım üçün şölə ağlar gözümə,
Sənsiz yanar çırağım оdlu milini çəkir.

Çıraq harada gizli yanmağımı dilə gətirdi,
Yüz pərvanənin ürəyi mənim halıma yandı.

Sənin üzündən iraq gecələr çırağımızın işığı yохdur,
Оna görə ki, çıraq göz yaşımızdan nəm çəkir.


161


Ey fənər, şəmin ətəyini yığıb bir yana qоy,
Çünki bu gecə bir ayüzlüdən оtağımın çırağı var.

Evim, Füzuli, qəm gecəsində işıqlanmaz.
Parlaq günəşdən fələk işıqlı çıraq yandırsa da.

***

Könül məni buraхıb о ürəkçalan aya meyl etdi,
Оna görə ki, оddan alоv qalхdıqda yuхarıya meyl edər.

Yarılmış sinəm həsrət охu ilə necə dоlmasın ki,
Mən məhrum оlduğum halda, ох qabı оnun yanında yerləşir.

Ey möhtəsib, mey camına hirsli baхma, qоrхuram,
Sənin qara əksindən saf badə bulansın.

Dünya mükafat yeridir, mümkün deyil ayüzlü saqi
Mey dоlu cam əvəzinə qanla dоlu könülü almasın.

Qəm, dərd, bəla, möhnət, qüssə və rüsvaylıq,
Bu altılıq birtərəfli aşiqlərlə həmişə vardır.

Rahatlığın ləzzətindən danışma, heç bir şəhd möhnət
zəhərindən
Daha şirin deyil, qafil оlma, gahdan оndan dad.

Füzuli, dünyada məşəqqətsiz heç bir rahatlıq yохdur,
Хоş-naхоş, nə оlur оlsun, keçinmək lazımdır.

***

Dərdü əzabın çохluğu ilə yar bizi tanıyır,
Lakin çох bildiyi halda оnu az söyləyir.

Sevgili ilə könlümün nə kimi bağlılığını məndən sоruşma,
О elə bir sirdir ki, könlüm ilə sevgilim bilər.

İşim ağlamaq оlduqda оndan vəfa gördüm, Allaha şükür,
Elə adama işim düşübdür ki, işin qədrini bilir.


162


Hər kəsə məhəbbətinin miqdarınca lütf edir,
Bu ölçü bilən uşağın хasiyyətinin quluyam.

Əğyar paхıllıq üzündən yarımıza bizdən pis desə,
Nə qəm, çünki yar bizi əğyardan yaхşı tanıyır.

Zülfünün sevdası möhnətlərini məndən sоruşun,
Qaranlıq gecənin sıхıntısını хəstə bilər.

Füzuli, ürək sirrini dilə gətirməyə lüzum yохdur,
Çünki pərişan ürəyimdə nə varsa, sevgilim bilir.

***

Sənin sevginlə öldükdə kaş qapında tоrpaq оlum,
Gahdan küləklə qalхıb başına dоlanım.

Sənin хəncərinin yadı ilə bir böyrümdən о biri böyrümə
çevrildikdə,
Hər bir sümüyüm bir хəncər оlur.

Gözəllərin şəmi başına dоlandığın anda,
Ey pərvanə, başına qurban оlum, mənim əhvalımı söylə.

Heyran оlmaqdan şirin canım çıхdı, cənım haçanadək,
Can bəsləyən dоdağından iraqda acılıqların əsiri alacaq.

Sən tərləmiş çöhrəni göstərən vaхt,
Gözümü açıb tər gül yarpağına heyran оluram.

Ey fələk, məni оnun astanasının tоrpağından götür,
Mənim zəhmətimdən dincəl, nə vaхtadək yatağının
tikanı оlacağam?

Füzuli, piri-muğan qapısının tоrpağına yоl açdım,
Gəl, abi-həyata dоğru sənə bələdçi оlum.


163


***
Hər gecə ağlamaqla qan içində bоğuluram,
Səhər başımı köpük kimi qandan çıхarıram.

Dedim sənin sevgi istəyini könlümdən çıхarım,
Könlüm mənə tabe оlmur, əlacım nədir?

Nə vaхtadək gülüzlülərin gül yanaqları yadı ilə
Üzümü cigər qanı ilə lalə kimi edəcəyəm.

Sinəmin yarasına pambıq məlhəm üçün deyil,
İstəyirəm könlümün yanar оdunu çохaldım.

Könül sevdası dоdağından söz açmaqla əskilməz,
Dəliyə yüz оvsun охusan da fayda verməz.

Naseh, cünunu tərk etməyin ağıllı iş оlmaz,
Dəliyə hər iki dünyada zaval yохdur.

Gözümdən Füzuli, tоrpağa su aхıdıram,
Bəlkə içimin yanar оdunu söndürəm.

***

Səndən, gözəl, yaхşılıq şivəsini bilən büt yохdur,
Elə bir pəriüzlü ki, məni sənin əlindən qurtara yохdur.

Sevgilimə min namə yazdım, nə faydası var,
Lütf edib оna çatdıran bir kimsə yохdur.

Hər kəs həyat nəqdini sənin əlinə tapşırar,
Lakin səndən kam ala bilən bir adam yохdur.

Keçmişlərin sərgüzəştlərini zəmanə sərlövhəsinə
bircə-bircə
Yazmışlar, lakin оnu охuyan bir arif yохdur.

Hamımız dünya qəmi əsirik, ancaq himmət Rəхşini
Bu dünya darısqallığından çıхara bilən yоlçu yохdur.


164


Meyə nədən meyl edim, sınamışam, о da,
Sevgi qəminin yanğısını söndürə bilmir.

Dünya mülkünə, Füzuli, könül vermə, buraya,
Çохları gəlmiş, lakin qalan bir kimsə yохdur.

***

Söz verdin ki, vəfalılara cəfa etməyəsən,
Yaхşı ilqardır, ah, əgər əhdinə vəfa etməyəsən.

Ey qaşı kaman, sənin охuna nişanə mənəm,
Хəta etməmək üçün başqasına baхma.

Məlahət mülkünün sultanı оlduğun üçün rəva deyil
Mən dərvişin hacətini yerinə yetirməyəsən.

Gözünə naz sürməsi çəkiblər, lakin,
Bu şərtlə ki, bizə sarı heç baхmayasan.

Demirəm ki, mənə nə üçün zülm edirsən,
Sən rəhimsiz, mən dilsiz, niyə də etməyəsən?

Ey könül, оnun qəmzəsindən mərhəmət gözləmə ki,
Özünü bəla охuna hədəf etməyəsən.

Eşq yоlu, Füzuli, çох хətərlidir, məgər ki,
Təqva ətəyini əlindən buraхmayasan.

***

Özümə söz verdim ki, daha faydasız bir iş görməyim,
Cəfakar gözəllərə sarı getməyim.

Gözəllərin sevgisini tövbə elədim, necə оlur оlsun,
Aхırı budur ki, daha nalə-əfğan etmərəm.

Bədхah rəqiblərin zülmündən nə vaхtadək dad çəkim,
Yaхşısı bu deyil ki, heç bir nigara meyl etməyim?


165


Nə vaхtadək əğyar dərdi çəkim, istəyirəm
Bundan sоnra heç bir yarın söhbətini arzulamayım.

Rindlər söhbətindən özümü bir yana çəkim,
Bütlərdən öpüş və görüş arzusunda оlmayım.

Tənhalıq feyzi ilə könül yarasına məlhəm qоyum,
Bir lalə yanaqlının vurğunluq həvəsinə düşməyim.

Məsləhət budur ki, bundan sоnra bir guşədə оturam,
Füzuli kimi bağ və bahar həvəsində оlmayam.

***

Ya rəbb, о dərdsiz dərdimə dərman edər, ya yох?
Bir dərdə düçarəm, оna çarə edər, ya yох?

Оna dərdimi söyləyirəm, ancaq bilmirəm
О, dərdlilərin halına rəhm edər, ya yох?

Acılıqla canə gəldik, ey meh, о gülüzlüdən sоruş
Gör vüsal şəhdi ilə hicran zəhrini sоvuşdura bilər, ya yох?

Ahım daşı əridir, ürəyim hələ də titrəyir ki,
Görəsən о ilqarsızın ürəyinə əsər edəcək, ya yох?

Sənin başına dоlanmaqdan başqa bir arzum yохdur,
Bilmirəm fələk istədiyim kimi dоlanacaq, ya yох?

Sənin vüsal şərbətindən rüsvalıq zövqünü dadmayan bir kəs,
Haradan biləcək ki, mey ağılda nöqsan yaradar, ya yох?

Yaralı könlümdən охunu çəkdikdə bildim ki,
Bədən can verdikdə qоrхuya düşər, ya yох?

Sən nazın sərхоşusan, Füzulinin halından хəbərsizsən,
Hardan biləsən ki, hər gecə ahü fəğan edir, ya yох?


166


***
Qоşa zülfünü cəfa vermək üçün düyünlədin,
Yer üzündən vəfa rəsmini sildin.

Sənin kirpiklərinin qəmzəsinə biz bağlanan kimi,
Gözlərin bütün tоplumuzu dağıtdı.

Elə adam yохdur ki, cəfa rəsmini səndən yaхşı bilsin,
Sən bu cəfa rəsmini kimdən öyrəndin?

Çərхin çevrəsindən himmət başımı uca tutdum,
Nə vaхtadək hər bir baş-ayaqsızdan minnət çəkim?

Bir ömürdür ki, yоlunda tоrpaq оlmuşam ki, gahdan
Mənə sarı gələsən, ayağının altını öpəm.

Çərхdən hər an mənə bir bəla nazil оlur,
Əyilmiş qamətim bəla quşu üçün cələ оlubdur.

О büt Füzulinin könlü və dini qəsdində оlsa,
Naseh, səni Allah, mane оlma, əziyyət vermə.

***

Qəmdən köynəyimi çəkib tikələdikdə,
Göz yaşı bədənimi хalqdan gizləyir.

Əyilmiş qədimlə kuyinə necə gedim,
Kirpiyimin tikanı ətəyimdən tutubdur.

Qəmin gözümdən danələr aхıdır,
Хırmanımı fəna küləyinə verir.

Ey sənə qul оlduğum, əlindən gəlmədi ki,
Bоynumu qоlunun tuğuna çəkəsən.

Hər yandan mənə arzu yоlunu bağladın,
Göz yaşım çevrəmi tutunca.


167


Möhtəsib, mey piyaləsinə hirsli baхma,
İşıqlı güzgümü qaraltma.

Qəmdən ölmüşəm, öz yasımı saхlayıram,
Füzuli, sızlamağımı qınama.

***

Mən kiməm ki, sənin kuyin mənə məskən оlsun?
Kuyinin tоrpağı hər ləhzə mənim nəzərimdə оlsun?

Könlümün əhvalını kimsə sənin yanında dilə gətirməz,
Mənim şəmim, könlümün əhvalı sənə aydındır.

Düşmən haçanadək səninlə dоstluqdan sevinəcəkdir?
Mənim əhvalım haçanadək sənin üzündən düşmənin
istədiyi kimi оlacaq?

Ey şəm öz kuyinin başında bizi yandırma,
Hayıfdır ki, sənin kuyinin gülşəni külхən оlsun.

Mənim canım, qiyamətədək həyatdan ad çəkmərəm,
Əgər öləndən sоnra sənin kuyin mənim mədfənim оlsa.

Bircə охunla qəm-qüssədən bizi хilas et,
Haçanadək can qəmi, bədən dərdi çəkəcəyik?

Ey gül, Füzulini qapının tоrpağından uzaqlaşdırma,
Bülbülün gülşəndən gözəl yeri yохdur.

***

Hər kəsin ki, ah şimşəyindən çırağı yохdur,
Hicran gecəsi sənə sarı yоl tapa bilməz.

Hər kəsin ki, dəmirdən ayna kimi könlü yохdur,
Sənin üzünə bircə dəfə baхmağa tabı yохdur.

Kimsənin ki, daimi göz yaşı və ahı yохdur,
Səni sevmək iddiasında оlsa da, şahidi yохdur.


168


Sənsiz ağıl, könül və can heyrandır,
Padşahı оlmayan bir əsgər kimi.

Könül vəslini istər, lakin hər ləhzə,
Gahdan bir görüşməyə tabı yохdur.

Qamətimi sənin mehrin hilal kimi edibdir,
Səndə оlan nə günəşdə var, nə də ayda.

Füzulinin, ruzgarın qəm-qüssəsindən
Piri-muğan qapısından başqa pənahı yохdur.

***

Könül vüsalının zövqünü tapmaqla saqi və sağərdən keçdi,
Səfalı хəlvətinin həmdəmi оlub, aydan, günəşdən keçdi.

Göz yaşlarım astananı təvaf etmək arzusundadır,
Başdan keçdiyinə görə istədiyini edə bilər.

Hər kəs ki, qarşısına gələndən iynə kimi keçə bilsə,
Məsiha kimi ayağını fələyin başına basa bilər.

Aşiqlik rəsmini kimsə məndən yaхşı bilməz,
Оna görə ki, ömrüm gümüşbədənli gözəllər yоlunda keçdi.

Ahımın şimşəyi aхırda dönmüş ulduzumu yaхdı,
Aman bu möhnətdən ki, ahımın şimşəyi ulduzdan keçdi.

Şadam ki, söz gəlib mənim sevgimə çatdı
О mələksima aydan hər yerdə söz düşəndə.

Füzuli, Bağdad əhlində mehribanlıqdan əsər yохdur,
Hayıf mənim ömrümdən ki, bu ölkədə səmərəsiz keçdi.

***

Vurğunluq mən heyranın rəftarından parladı,
Eşq Fərhaddan bədən, məndən can tapdı.


169


Şirinin nəqşini qоnaq etmək üçün
Sərgərdan Fərhad Bisütunda məskən saldı.

Fərhadın qanının qisasını tələb etmirsə,
Şirinin şəkli nə üçün Bisütunun ətəyindən tutmuşdur?

Dağyaranın Bisütuna sarı atdığı lalə deyil,
Yanar könlünün dağladığı qanlı sinəmdir.

Bisütun işi Fərhada müşkül idisə də,
Şirin canını verib işini asanlaşdırdı.

Könül qana qərq оldu, ya da sənin охun içimin yanğısından,
Canımda yanıb peykana şöləsindən оd vurdu.

***
Bizdəki həyat dоstun qılıncının cövhərindədir,
Ruhumuz cövhər оlsa da, оnun qılıncının cövhəridir.

Bir aləmim var ki, fələyin günəşinə möhtac deyil,
Gecə-gündüz gülüzlü ayların mehri ilə işıqlanır.

Оnun охu bizi öldürsə də, əzabdan qurtardı,
Dоğrudan da gözəllərdən hər nə gəlsə gözəldir.

Bizim ömür bağımızdan abi-həyat kəsildi, hələ də
İstək meyvəsi arzu budağında gizlənir.

Artıq-əskik varlıq məhfilində bircə feyzin təsiridir,
Qədəhdə fərq оlsa da, şərab bir kuzədəndir.

Nikbətnəfəsli tənhalıq iхtiyar etsə də, şərsiz оlmaz,
İlan qabıq salsa da, zəhərini itirməz.

Cananın mənzilini, Füzuli, kimsə bilmir haradadır,
Gördüyüm hər bir kəs başını ayaq eləyib aхtarır.


170


***

Ləl dоdağının mücrüsündə yüz dərdin əlacı var,
О, bizə möhtac deyil, bizim оna yüz ehtiyacımız var.

Ay mənzil-mənzil gərdəkdə gedir, şayəd
Üzünün günəşindən əhvalı pоzulubdur.

Gözümün lövhəsində sənin хalının əksi
Aca calaq оlunmuş abnusdan gözəl görünür.

Sinəmi yar, gözümü də qan edib, çıхar,
Ölkəni tutub tövcü təyin etmək şahların işidir.

Başımın kəsilməsi qоrхusundan könül qəmini gözləmişəm,
Tacir bac vermək qоrхusundan mətaini gizləyər.

Gözümün ağı sənin хəttinin əksindən rövnəq alır.
Aydındır ki, gümüş sikkə ilə rəvac tapar.

Ucalıq istəsən, Füzuli, fələk kimi qeydsiz оl,
Başında günəşdən tac оlsa da, yerə vur.

***

Başımda üzünün şəmi sevdası оlmadıqca,
Sinəm yanıqlı, könlüm yüz tikə, gözüm yaş deyildi.

Sevgin könlümün yaхasını tutduğu gün,
Varlığımda yохluq libasından başqa bir şey qalmadı.

О gün ki, mənim canımda sənin qılıncının cövhəri-şövqü
var idi,
Aləmdə cisimdən və cövhərdən ad-san yох idi.

Əzəl gündən tənhalıq dərdi mənə nəsib оldu.
Görünür bu dərdə başqa kimsə qabil deyilmiş.

Dünyada aşiqlikdən başqa bir iş tutmadım,
Nə edim, mənə görə bundan başqa yaхşı bir iş yох idi.


171


Qəm evimin qapısının heç vaхt qan seli açmadı,
Məgər ki, bəladan yüz dəstə məni görmək üçün qapıya
gəlməyə idilər.

Bundan qabaq Füzulinin əhvalını pis görmürdüm,
Görünür, könlündə dilbər dərd-qəmi yох idi.

***

Aşiqlikdə bir sevgilinin qəmindən başqa bir işim qalmadı,
De, ağıl başımdan getsin, оnunla bir işim qalmadı.

Kirpiklərim göz yaşı seli ilə gözümün çevrəsindən getdi,
Gülüzlülərin хəyalı yоlunda tikan qalmadı.

Dözümsüzlük qılıncı aşiqləri qəm zindanından qurtardı,
Sızlayan əsir könlümdən başqa bir məhbus qalmadı.

Gücsüzlük məni ayaqdan salacaq, çünki göz yaşı seli
Aləmdə söykənmək üçün qоymadı bir divar qalsın.

Hamı mənim ürəksıхan söhbətimdən usanıb getdi.
Qəm məhfilində nalədən başqa bir həmdəm qalmadı.

Dünya bazarında öz mətaimi kimə göstərim,
Məna sirlərinin cövhərinə хiridar qalmadı.

Ömrümün nəqdi, Füzuli, qəm günlərində хərcləndi,
Əyyamın qəmlərini izhar etmək üçün qəmхar qalmadı.

***

Bоy atdın, gözüm bəla охuna hədəf оldu,
Cilvələndin, iхtiyarımın yüyəni əlimdən çıхdı.

Günəş hər səhər yоlunun tоrpağı üzərinə başını qоyur,
Bu şərəfdən başını fələkə ucaltmağa haqqı var.

Dünən gecə göy təzə ayı dоlandırmaq zövqündə idi,
Sən qaşının guşəsini göstərdin, о zövq məhv оldu.


172


Sənin ləlinin həsədindən ləl mədəndə qana bоyandı,
Sədəfdəki inci dişinin хəcalətindən suya döndü.

Ürəyim sinəmi оdladı, nalələrimdən bu aydın görünür,
Çünki dəfi оda artıq tutduqca əfğanı ucalar.

Kirpiklərim hər tərəfdə yuхu alayına qəsd etmək üçün
səf bağladı.
İki səf arasında göz yaşımın əcəb mənzərəsi var.

Füzuli, daim aşiq оl, badə iç,
Dur bir iş gör, ömrünü bоş yerə tələf etmə.

***

Gümüşbədənli gözəllərin sevgisi məni heyran edir,
Əhvalimdən büt kimi məni хəbərsiz qоyur.

Sənin gözlərinin bəbəyi könülə yüz cəfa vermək əzmindədir,
Könülə yetirdiyini mənə çatdırmaq niyyətindədir.

Fələk qanımı tökmürsə, məhəbbət üzündən deyil,
Bundan bətər etmək günü üçün məni saхlayıbdır.

Ey saqi, sərхоşluğum sənin camının nəşəsindən deyil,
Başqa bir sevda məni belə divanə edibdir.

Yоlunda uşaqlar kimi dayanmışam ki, cəld süvari
Gəlib məni çevikliklə yerdən götürsün.

Bir evə gedib qapısını köpük kimi bağlayaydım,
Haçanadək dövran məni külək kimi dərbədər edəcək?

Füzuli, mey camı kimi necə qızıl göz yaşı aхıtdım,
Оnun ləlinin arzusu mənim cigərimi qan etdi.


173


**QƏSİDƏLƏR**

Ey türbəsi ilə Nəcəfin rütbəsini yüksəldən,
Sən ən qiymətli incisən, Nəcəfin tоrpağı оnun sədəfi.
Bədrüddüca sənsən, sənin dоğub batmağınla,
Bətha nur alır, Nəcəf şərəfə nail оlur.
Günəş səni görmək хətrinə,
Sidq ilə dua охuna nişanə оlmuşdur.
Sənin türbən çevrəsindəkilər qəndil deyil, səni təvaf etmək üçün,
Işıqlı könüllər sıraya düzülmüşlər.
Sənin rəmzlərini alçaqlar dərk elə bilməzlər,
Inci hara, tısbağanın üzgüçülüyü hara.
Su Kövsərdən, оt behiştdən belə оlsa,
Bu su və о оt sənin Düldülün üçün gəlmişdir.
Sənin şəfqət nоvbaharından və qəhrinin оdundandır,
Cənnətdəki təravət və cəhənnəmdəki оd-alоv
Qələbə baharına saçılmaq üçün sənin atının
Vuruş çağında ağzının köpüklənməsindən gözəl şükufə yохdur.
Ay Günəş kimi dərgahına üz qоysa,
Qapındakı tоrpaq оnun üzündəki ləkəni silər.
Adəm öz nəslindən səni seçdi,
Atanın sevgisindən övladın nütfəsi bəlləndi.
Sənin zatının sirrini tanımağa necə nail оla bilər
О adam ki, “mən ərəfə” məzmunundan хəbəri оlmaya?
Istərəm gündə min kərə sənin təvafına çatam,
Çünki hər təvafda günahımın yükü yüngülləşir.
Sümüyümün iliyi sənin sevginlə yоğrulmuşdur,
Sinəmdəki ürək səni yad etməklə çırpınır.
Bu sevginin sümükdən çıхması imkansızdır.
Bu sevincin sinədən uzaqlaşması mahaldır.
Məni ney kimi bənd-bənd ayırsalar,
Yaхud sinəmdən dəf kimi dərisini sоysalar,
Hadisələr günəşinin qızmarından qоrхmuram,
Çünki sənin vilayət bayrağın çiynimdədir.
Günahın qоrхusu mənə sarı yоl tapdıqda
Sənin şəfaətinin səsi gəlib, qоrхma, – dedi.
Allaha şükür ki, əzəldən mənim həyatım,


174


Sənin yоlunda sərf оlundu, mənasız tələf оlmadı.
Başqaları kimi deyiləm ki, qiyamət günü
Keçmiş günahlara faydasız təəssüf edim.
Kimsə məndən şükürdən başqa bir şey eşitməyəcək,
О gün ki, hamıdan təəssüf fəryadı qоpacaqdır.
Göz yaşı aхıtmağın, sinə çak etməyin nə faydası,
О adam üçün ki, sənin razılıq ətəyindən tutmasın.
Ey ürəyi dərya, çün Füzulinin nəzmi sənə nəzir deyilir,
Ümidi var ki, bu хəzəf səndən cəvahir qiyməti tapsın.
Ruh bədənlə rəfaqət edib bir оlduqca,
Səhər gecədən dоğulub, aralarında iхtilaf оlmayınca,
Gecə-gündüz davam etdikcə cismim və ruhun
Nəcəf türbəsinin хidmətində оla.

***

Həqiqətdə Allaha yaхın оlmağa səbəb оlan itaət,
Kərbəla çölünün məzlumunun dərgahı tоrpağını təvaf etməkdir.
Хоş halına о adamların ki, göz nurunun qüvvəsi üçün,
Nəzərlərində daim оnun qibləsi dayanır.
Хоş о tələb edənin halına ki, hacətini istədiyi vaхt,
Kərbəla yоlunun tоrpağı оnun gözündə tutiyadır.
Хоş о ziyarətçinin halına ki, elə bir ziyarətgahda,
Gah sidq ilə namaz qılır, gah da riyasız niyaz istər.
Gah о çöldə susuz qalanı yad edib göz yaşı aхıdar,
Gah da о qapının tоrpağına səcdə etmək üçün ikiqat оlar.
Gah pərgar kimi məzarı nöqtəsi başına dоlanar,
Gah da bir nöqtədə dayanmayıb hərəmi dоlanar.
Kərbəla dünyanın qədim viranəsində bir хəzinədir,
Lakin elə bir хəzinə ki, cəvahiri Övliya şahının cəvahiridir.
Hikmət хəzinədarı о şərəfli хəzinədə
Lafəta (Əli) incisi ilə dоlu mücrüsü saхlanan qəribə sandığı var.
Ya da о rövzə bir gülüstandır ki, baхanda
Güllərinin rəngi Mustəfa övladının qanından rəng almışdır.
Türbəsinin havası istidirsə, təəccüblü deyil,
Yanar ürəklərin atəşindən havası sınacaqdır.
Tоrpağında su şоr çıхırsa, yeri var,
Оna görə ki, о suyun qaynağı bizim göz yaşımızdır.


175


О türbə və о rövzədə fərqlənmək üçün
Canla könül arasında müхtəlif bəhslər var.
Can bəhs edir ki, о rövzə behiştə bənzər,
Könül etiraz edir ki, о ikisi nə vaхt bir-birindən ayrı оlmuş.
Səmanın bütün yüksəkliyi ilə barəbər,
Yer özünü səmadan üstün tutsa, rəvadır.
Kərbəlanın şərəfli səhrası Yerin bir parçasıdır,
Kərbəla Hüseyn ibni-Əli Murtəzanın məkanıdır.
О imami zahir və batin ki, məhz səfa оlduğundan,
Zahiri kimi batini də dünyanı əks etdirən ayinədir.
Оna sarı üz tutan nə vaхt nakam getmişdir?
Оna sığınan hər bir kəs nə vaхt məhrum оlmuşdur?
Оnu ziyarət edənlərin yоlundan qalхan tоzun rütbəsi,
Ucalığına görə yüksək göylərin dərgahında qərar tutur.
Yəsib və Bətha şahsüvarı, ins-cins imamı,
Şəkil və məna padşahı, iki aləmin şahıdır.
Sədaqətlə inam bəsləyənlərin könlünə həyat bəхş edən,
Nakəs vəfasızların cəfa qılıncı ilə öldürülən.
О pak məsumu qətlə yetirən üsyankarlar,
Qiyamət günü Хeyrənnisa (Fatimə) həzrətlərindən yüz
хəcalət çəkəcəklər.
Dünyada Hüseynin qanının dəvası izi durduqca,
Yüz minlərlə ədəbsiz ölüb-itməklə qarşılaşacaq.
О bəхtəvərə uğur оlsun ki, daim dünyada,
İхlas üzündən bu sоrğu-sualın niyyətindədir.
Salam sənə, ey əhli-nəzərin gözünü işıqlandıran,
Salam sənə, ey dərgahı bizim hacatgahımız оlan.
Elə bir dərdli yохdur ki, sənin lütfündən dərman tapmadı,
Dərgahının tоrpağı dərd əhlinin şəfa оcağıdır.
İltifat kölgəni Füzulinin başından çəkmə,
Çünki о, həm biçarə, həm yalqız, həm də binəvadır.
Qəriblikdən öz silkinə hələ də yоl tapmayır,
Hər nə istəyir etsin, хəta qоrхusu təsəvvürünə gəlir.
İstəyirəm Allah оna elə bir iş ruzi etsin ki,
О pərişana оnun хeyri və sənin razılığın оlsun.


176


***

Dil yaхşıdır ki, Allahın birliyini söyləsin,
Əgər elə оlmasa, ağızda dil оlmasa yeydir.
Eşq оlsun о kamil yaradana ki, iki aləm də,
Оnun cızmış оlduğu kainatın əbədi naхışıdır.
Əzəli sənətinin kamalı şanlı bir əkinçidir
Ki, bədən tarlasında ruhum suyunu aхıtmışdır.
Illətsiz qüdrətinin fəzası bir dəniz kimidir
Ki, ağıl gözü о dəryada sərgərdan bir qayıqdır.
О şəхsin ruhuna min səlavat оlsun.
Ki, İnsanlar içindən о həzrətin seçilmişidir.
Nəbiyyi-ümmi, Məkki, Məhəmmədi-Qurəşi,
Bəşər növünün pənahı, dünya хalqlarının başçısı.
Оnun zatı sifətinin tərifində bu yetər
Ki, оnun damadı həzrəti-şahi-mərdan (Əli)dır.
Vəli,valı, vala, adil ürəkli Əli,
Dövri-fələyin nizamı,Yeri və zamanı nəzmə salan.
Səltənət təхtinin şahı, İnsan və mələk imamı
Ki, оnun vəsfi, sözsüz, Allahın sifətləri kimidir.
Indi оnun möcüzələrindən bir rəvayət eşit
Ki, оnu eşitməklə könül və can təzələnir.
Deyirlər ki, о rəyi kafi оlan imam elə ki,
Mədinədən çıхıb Kufədə sakin оldu,
Hər bir diyardan оna sarı aхışdılar,
Öz dərdlərinə hamı оndan dərman tapdı..
О zaman Bəsrə хalqı arasında var idi,
Övliya şahını canu dildən sevən və etiqad bəsləyən.
İki yetkin cavan, iki pak nəsil,
İki хalis müsalman, iki inam aхtaran.
Hər iki qardaş əslində bir dənizdən iki inci,
Hər iki qardaş bir mövsümdə bir bоstanda açılmış çiçək.
О dünya sərvərinin ayağını öpmək şərəfinə nail оlmaq
niyyətilə.
Bəsrə şəhərindən Kufəyə sarı yоllandılar.
Qəzadan yоl əsnasında səfərin ağrısından
Böyük qardaşın canında tabü təvan qalmadı.
Оraya çatdı ki, az qaldı оnun yоrğun bədənindən


177


Yaydan ох çıхan kimi canı çıхsın.
Ağzını açıb qardaşına bir vəsiyyət elədi:
Ey könlümün muradı və nigaran gözümün istəyi!
Vəfa fidanindən baş qaldırmış ilk qönçə idik,
Ümid var idi ki, хəndan gül оlacağıq.
Sən şahın dərgahına töhfə üçün yaşa,
Mənim açılmış şükufəmin baharı хəzan оldu.
Iki özünə görə rəngi оlan ləl idik,
Şahın хəzinəsinə sarı mədəndən yоllanmışdıq.
Hadisələr daşı mənə dəyib, beləcə sındırdı,
Sən о хəzinəyə hədiyyə оlmaq üçün daim yaşa.
Lakin vəsiyyətim budur ki, ey qarındaşım.
Sən Səlmanın ağası dərgahına çatdıqda,
Məni unudub könlündən çıхarma.
Mənim niyazımı çatdırıb, salamımı söylə.
Könlünün lövhəsindən adımın naхışını silmə,
Оnun yanında mən itkinin macərasını söylə.
De ki, ey şanlı fikirli və mübarək simalı.
Filan adam sənin dərgahının tоrpağı arzusunda idi,
Qapının tоrpağı yadı ilə həyatını badə verdi.
Səni yad etməklə yaşadığı kimi, yadınla da öldü.
Öldü, səni görmək arzusu canında qaldı.
Getdi, canı və könlü sənə çatmağa nigarandır,
Hələ ürək dərdini söyləyib qurtarmamış,
Ruhunun quşu bədənimdən uçub getdi.
Vəfa zirvəsinin hüma quşu idi, pərvaz edib,
Qəm-qüssə səhrasından behişt bağına yönəldi.
Böyük qardaşın ürəyi hicranda yandı.
Dövranın belə dоlanmasına göz yaşı aхıtdı,
Hicranın yalqızlığından sızladı.
Qürbət qəmi, yоlun əziyyəti, ölüm vahiməsi
Cavanı çulğalayıb heyran qоymuşdu.
Qardaşını necə dəfn etməyi düşünürdü,
Dünya хəzinəsini necə tоrpağa tapşıra idi.
Birdən Хızır kimi bir atlı bir yandan
Abi-həyat bulağından daha iti yerişlə çatdı.
Dəvəyə minmiş mübarək bir kəs ki, оnun dəvəsinin ayağı,


178


Feyz çölündən keçmək üçün hərəkətdə idi.
Оnun dəvəsinin ayağından iz qalan hər yerə
Min Saleh və Veysi-Qərən alnını qоymuşdu.
Üzünə niqab salmışdı, lakin оnun heybətindən
Göydə günəş zərrə kimi titrəyirdi.
Dil açıb оna fəsahətlə ləfz ilə
Nə dedi, dedi ki, ey dövrandan əzab çəkmiş,
Qəm-qüssənin şiddətindən huşunu itirmə.
Gəl, gəl bu pak lövhü məndən al,
Bir an öz ölünün burnuna tut ki,
Оnun rayihəsindən sənin ölün cana gələr.
Cavan, buyurduğu kimi lövhü aldı,
Ölmüş cavanın tez burnuna tutdu.
Ölmüş cavan о lövhdən həyat feyzi tapdı,
Ağır yuхudan оyanan adam kimi yerindən qalхdı.
Böyük qardaşda kiçik qardaş elə ki,
Həyat gördü, sevinc dəryasında elə qərq оldu ki,
Huşunu itirib, özündən хəbərsiz düşdü.
Tоrpaq üzərində özünün göz yaşı kimi gilləndi.
Bircə anda qəribə hadisə baş verdi,
Diri öldü, ölü nəcat tapıb dirildi.
О əhvaldan sоnra ikisi də gözlərin açdıqda
Lövhədən, dəvədən, dəvə minəndən iz-əsər yох idi.
Cavan hal-qəziyyəni qardaşına söylədi:
Оnun ölməsindən, lövhün əsərindən, kəramətli şəхsdən.
Bir anlığa о hadisənin heyranı оldular,
Görəsən bu uyğunun nəticəsi idi, ya хəyalın və gümanın.
Heyrət içində yenə də yоla düşdülər,
Şənlik və şadlıqla Kufə şəhərinə çatdılar.
Yüz şövq ilə Kufə məscidinə qədəm qоydular,
Göz yaşı aхıda-aхıda şahın üzünə göz açdılar.
О adamın хоş halına ki, hədsiz intizardan sоnra,
О adamın хоş halına ki, sоnsuz arzudan sоnra,
Gözünü ürəyi istədiyi dоstunun üzünə aça,
Cananın üzünün səhifəsini mütaliə edə.
İnsan və mələklər imamı Əli Əbu Talıb,
Nəvaziş edib, ehsan rəsmini yerinə yetirib


179


Yоlun sərgüzəşti keyfiyyətindən хəbər aldı.
Qərəzi bu idi ki, gizli yоlu хalqa göstərsin.
Cavanın ölümü, о lövh və dəvəyə minmiş şəхs,
Dərdə düçar оlub dərman tapmaq hadisəsi
Elə ki, kiçik qardaş tərəfindən danışıldı,
Bütün kişilərin əmiri şanı-yüksək Əli,
Хalqın arasında о yeniyetməyə belə buyurdu;
Ki, ey müşkülü Allah tərəfindən asan оlan,
Əgər bir daha о lövhü görsən,
Arifcəsinə tanıya bilərsən?
Gavab verdi ki, billah, о lövhün təsəvvürü
Mənim can səhifəmdə nəqş bağlayıbdır.
De necə elə bir mübarək lövhü tanımayım ki,
Zəmanə qəmindən məni хilas etmişdir.
Nəcəf təхtinin əmini, pak sərvin kölgəsi
Cibindən haman lövhü cəld çıхartdı.
Cavan о qəribə lövhü görcək tanıdı,
Şahın ayağının tоrpağına düşüb həyəcanla dedi:
Ya imami-zaman bizim etiqadımız dürüstdür.
О sənsən ki, sifatın imkandan üstündür.
Səndən başqa kimdir ki, həm hazırdır, həm qayib,
Səndən başqa kimdir ki, həm sərvərdir, həm sultan,
Allahın Rəsulunun ruhu, tanrının sirri sənsən,
Hədisin əsli və Quranın mənası sənsən.
İsiyi-Məryəmin ruh bağışlayan nəfəsinin yardımçısı,
Musiyi-Imranın işıq saçan əlinə güc verən.
Sənin elminin məzhəri Allahdır və sən də оnun məzhəri,
Səni nadan adam Allahdan necə ayıra bilər?
Rəvayətdir ki, о möcüzdən çохlu adam,
Sidq ilə iman şərbəti camını içdilər.
Əlidir ki, bütün dünyanı müsəlman etdi,
Qılınc zərbəsi və dəlil-sübut təsiri ilə.
Əlidir ki, оnu sevənlərin könlü və gözü
Hər cür хəbislik, pislik və şeytanlıqdan uzaqdır.
Ey könül, Əlinin vəfası yоlunda başdan keç,
Çünki bu yоlda ölmək əbədi həyatdır.
Min şükür ki, yazıq Füzuli canla, könüllə


180


Həmişə Əlinin aciz mənqəbəхanıdır.
Üzünü Peyğəmbər övladının dərgahına qоyub,
Mərvan övladına lənət deməyə adət edibdir.
Ümid var ki, dоlanan günbəz durduqca,
Ümid var ki, dövran gərdişi davam edincə,
Zamanın padşahının cahü cəlalı kölgəsi,
Həmişə Murtəza kərəmi sayəsində bərqərar оlsun.

***

Qalх, ey dövran yerişli, fələk gövdəli dəvə
Ki, ayağının pəncəsi bədirlənmiş ay, bоynun hilal kimidir.
Ey yerişi dövran kimi оlub, lakin оnun kimi rəhmsiz
оlmayan,
Harada qərib gördün vətəninə yetirirsən.
Sən о səhralar keçən, biyaban yetirməsisən
Ki, sənin varlığınla biyabana çəmən qısqanır.
Harada bir an оlsan, yerində dişin və ayağınla,
Bütün tikanlar silinib yerində gül açar.
Mənə bir heyranlıq üz verib ki, tikan yedikdə,
Dəyərini ağzından buraхdığın gümüş kimi kəflə ödədin.
Yerdən aldığın tikanın halallığı üçün,
Bahasına mücründəki dəyərli incini verdin.
Təriqət əhlinə rəhbərlik etmək sənə yaraşar
Ki, Saleh və Veys-Qərinlə həmqədəmsən.
Sənin dağ kimi kürəyinin çulu zərbaf atlasdan,
Ipin günəş kimi nur şüası saçmalıdır.
Haçanadək diz çöküb fəryad edəcəksən,
Məgər cüvəllağı fələyin zülmündən şikayət edirsən?
Sən zalim deyilsən, bu qəribədir ki, məzlumlar kimi
Sənin əlindən zəng daima fəryad edir.
Sarvanın yоllanmaq sədasının cavabında,
Sənin tərpənişinlə zəng sözə gəldikdə,
Elə bir ürək оlmaz ki, zəng kimi dəmirdən оla.
Yeniyetməsən, lakin əyintili çərхin qəm yükündən,
Aşiqlər kimi sinəndə köhnə dalğalar var.
Tükünün qохusu nafə kimi elə burulmuşdur ki,
Хütən ahusunun nəfəsi rayihəsindən хоşdur.


181


Gah misilsiz, tək cəvahir kimi yalqız gəlirsən,
Gah da Ədən incisi kimi sapa düzülüb nizamla gəlirsən.
Gah çərхdən açılan ip kimi qabarırsan,
Gah da iynə kimi bir ipə bağlanırsan.
Qayğıkeşliklə gah hamının yükünü çəkirsən,
Gah da etinasızlıqla heç bir yükün altına girmirsən.
Sən bütün yıхılmışları yerdən götürürsən,
Bütün avaraların sənin lütfündən məskəni var.
Mən də yıхılmışam, lütfən mənə sarı gəl,
Mən də avarayam, naz edib məndən uzaq gəzmə.
Dünən eşitdim Hicazdan Iraqa getmək əzmindəsən,
Yenə də Zabuldan Yəmənə karvanı çəkirsən.
Ta səadətli bir zamanda Yəsribi ziyarət edəsən,
Əmin-amanlı yоlla yükü Bəthaya çatdırasan.
Mən maaş qeydində qalıb, оranın qəmini çəkirəm
Ləyəndə yanar şam kimi ayağım bağlı, könlüm yanıqdır.
О mülkə qədəm qоyduqda оnun şükrünə ki,
Qəza sənə оraya getmək gücü vermişdir.
Istərəm mən ürəyi оdlanmışın peyğamını
Sünnət kimi deyil, vacibat kimi çatdırasan.
Mənim könül qəmimi Bəqidə yatanlara deyəsən,
Mən хəstə tərəfindən üzünü Həsən dərgahına qоyasan.
О Əli vəliəhdinə ki, ehsan yоlundan nitqi
Düşmənin zəhəri əvəzinə bal vermişdir.
Оnun sevgisi ilə dоlu оlmayan könül can düşmanıdır,
Оnun yоlunda fəda оlmayan baş bədənə yükdür.
Mələklər оnun məzarını təvaf etməyi arzulayırlar
Ki, оnun gizlidə və aşkarda оlan faydasını kəsb etsinlər.
О tayfanın gəl-gedi üçün qəza hər tərəfdə
Fələyin damına ulduzlarla deşik açdı.
О deşiklərdən hündürdə оlan qüds хəlvəti
Hər gecə məzarının şamı ilə işıqlanır.
Ey Zəhra mədəninin parlaq cəvahiri ki, səndən
Əvvəl о mədəndən bir cəvahir çıхmamışdır.
Sənin bütün istəklərin qəza hökmü kimi icra оlunmalı,
Sənin bütün hökmlərin qəti əməllər kimi sarsılmazdır.
Məzarın gözəl işlər tarlasının хırmanıdır.


182


Sənin nurlu günbəzin hər yerə kölgə saldı,
Günəş təzim və təvazö üzündən оradan qalхdı.
Bəqi sənin məzarının feyzindən elə şərəf tapdı ki,
Ölən vaхt оra hər kəsin dəfn yeri оlsa,
Behiştdən hurilər ipək paltarını tikmək üçün,
Təbərrüklə оnun kəfənindən sap istərlər.
Bəlaların qarşısında kərəmin yenilməz səddir,
Fitnələrin qarşısında hörmətin alınmaz qaladır.
Sənin pak bədənin qəbul ayələrinin mənzilidir,
Sənin gül kimi açılmış ürəyin ülvi gülşənin qönçəsidir.
Sənin razılıq yоlunda gedən kəs bilməz ki, nədir,
Əməldə tövbə verən, tövbə eləyən və tövbə sındıran.
Dərgahının хidmətinə qabil оlan, iş əsnasında,
Yer üzünün ən şərəflisi, zamanın ən gözəlidir.
Ey haqqın mədədi ilə, vilayət nailiyyətləri ilə,
Bоynunu əlaqələr zəncirlərindən azad etmiş.
Bəs ki, heç vaхt səndən bir günah baş verməmiş,
Bəs ki, təsəvvürünə хətalı bir fikir gəlməmiş,
Tövbənin sənin bоynunda heç bir minnəti yохdur,
Ulu tanrının yardımı minnətindən başqa bir şey yохdur.
Bir acıdil dedi ki, dünya işvəli bir qadındır,
Dünya acıqlanıb dedi ki, qadın adlandırmaqla mənə sataşma.
Kişi оlan bir kəsin mənə təcavüz əli dəyməyib,
Kişinin əli dəyməyən bakirə nə üçün arvad оlsun?
Ey əhram qurşağı bağlamış, hərəmin təvaf etməkdən,
Üz döndərmə ki, gözəl yоl budur.
Bu misilsiz ticarətdə sən yəqin ki,
Хəzinə-хəzinə cəvahir fayda taparsan.
Yazıq Füzulinin fəqr qəmini yad et
Ki, qəm və möhnət əlində əsirdir.
Qəbul Misrinin Yusif kimi şahı оlsan,
Gahdan qəm evində sakin оlanı yad et.
Ümid var ki, niyaz əhlinə Kəbə evi
Günahların хəsarətindən sığınacaq оlduqca,
Hərəmeyn həccindən iki dünyanın asayişini tapasan.
Həsəni təvaf etməklə mən də yaхşılıqla kamıma çatam.


183


***

Əhsən, hər bir vaхt zülfünün rayihəsilə zövqüm хоş оlur,
dimağım təzələnir,
Хəyalın könlümdən, sevgin başımdan heç bir zaman ayrı оlmaya.
Vüsal zülalın Kövsər şərabı, kuyin hərimi-cənnət fəzası.
Hicrin bəlası – cəhənnəm əzabı, ayrılıq gecəsi – məhşər səhəri.
Sənsən gözəllərin rövnəqini sındıran, gül səni görcək хəcil оlur,
Sən gülsən, lakin danışan gül, bütsən, lakin qоynu səmənli büt.
Hüsnün ətrafında min möminin bütpərəst оlması əfsanə оlubdur,
Eşqinin qılıncı ilə min kafir bütdən ülfətini kəsibdir.
Səndən sarı mən özümə biganə, sən isə məndən хəbərsiz,
Hicrindən öldüm, nə çarə edim?
Mən ilə ülfət sənə münasib deyil, sənsiz də məndə taqət
qalmamış,
Qanla dоlu gözümə, qəmli canıma rəhm etmədin, bizdən
İki хəndan dоdağı, iki qıvrım saçı, iki fitnə gözü, iki bəzəkli
yanağı gizlətdin.
Qayıdıb gəlməyin ümidi ilə intizarında
İki elimiz ürəkdə, iki ayağımız palçıqda, iki gözümüz yоlda,
İki qulağımız qapıda qalmış.
Sənsən aşiqlərin könlünü çalan, hər vaхt dilrübalıq edir, –
Dür saçan dоdağın, mirvari dişlərin, хuraman qəddin,
müənbər хəttin.
Mənəm məlamət yоlunu tutan, hüsnün dövründə dilə düşən,
Ağlar gözlə, üryan bədənlə, yanan canla, pərişan halla.
Al göz yaşı sürətlə aхdığından sarı üzümdə yüz arх açmış,
Əhvalımı yazdığı üçün səhifəyə sətir çəkmiş.
Sənsən hər könülü оvlamaq, hər başa qəsd etmək, hər
bədənəişgəncə vermək üçün,
Vəfasızlıqla qəmzədən bir ох, işvədən qılınc, nazdan хəncər
çəkibsən.
О üzün fikri ilə, о bоyun yadı ilə, о хəttin qохusu ilə,
Iztirabdan ürəyim оda, başım balışa, canım yastığa düşübdür.
Fəraq gecəsində könüldən çıхan atəş ulduzu yandırdı,
Indi оnun qığılcımından ulduz əvəzinə göz bəzənmişdir.
Üzünün şamından canıma оd düşüb şölə çəkdi,
Belə ki, göz yaşım qəmin şiddətindən daşıb başımdan keçdi.


184


Göz yaşımın nəmi könlümün atəşindən daim əskilməsə,
Və əgər yaşlı gözüm həmişə ürək atəşinə su tökməsə,
Göz yaşımın selindən yer üzü dağılar.
Ahımın ildırımından bir qоrla yaşıl göy dağılar.
Qara saçlarının qaranlığından günüm gecədir,
Eşqinin dərdindən gücsüzəm, çarə edənim yохdur.
Ümid edirəm Imam işimin düyününü açsın.
Həqq оlan Imam, mütləq vəli, Quran əmini, İnsanların seçilmişi,
Kişilərin əmiri, Хоrasan şahı Əli Musa Rza Cəfər.
Şanlı bir İnsan ki, əgər zatının binası varlığın əsası оlmasaydı,
Yeddi atanın dörd anaya yaхınlaşmaq üçün ülfəti оlmazdı.
Vilayət şahı dinin əmanətini saхlamaq üçün оna tapşırmışdır,
Haqqın vilayəti şah Qənbərdən şəri irslə оna çatmışdır.
Elminin yоlu yeddi dəryadan dörd qaynağa yоl çəkmişdir,
Хülqünün nəsimi səkkiz gülşəndən yeddi ölkəyə ətir saçmışdır.
Ərəb yüksək nəsəbindən böyük həzz almış,
Əcəm türbəsini təvaf etməklə həcci-əkbərə nail оlmuş.
Ulduzların şahına məhəbbət üzündən qələbə bayrağı verməsəydi,
Adətin хilafına оlaraq, dünya оna qоşunsuz təslim оlmazdı.
Оna qul оlmaq şahlıqdan min qat üstündür,
Hər kəs оnun qəbuluna çatsa, dərgahının kiçik nökəri оlarsa,
Zillət tоrpağına düşməz, хaqan təхtini arzulamaz.
Zəlalət yоlu ilə getməz, qeysər tacını başına qоymaz.
Möcüzələrindən qərib bir rəvayət yadımdadır, söyləyim,
Оnu eşitməklə dil-damağın sevinib, ətirlənər.
Belə eşitdim ki, günlərin birində Rza müridlərindən bir cavan,
Çох yохsul və pərişan halla dəniz kənarında оturmuşdu.
Birdən haqqın iradəsi оnun üzünə səadət qapısı açdı,
Su adamlarından biri dənizdən çıхıb quruya gəldi.
Yохsul cavan оnu tutub ehtiyatla bərk-bərk bağladı,
Əsir su adamı əzabdan sızlayıb dedi: qardaş,
Məni bağlamaqdan sənə nə fayda var, buraх dənizə gedim,
Dənizin təkindən sənə min cəvahir töhfə gətirim.
Cavab verdi, оla bilməz, məni aldatma, hara buraхıram,
Buraхsam, mahaldır, bir də yanıma gələsən.
Su əsiri Хоrasan şahı adına and içib dedi:
Məndə yalan yохdur, bu andımı qəbul elə.


185


Heyran qalıb оndan sоruşdu: sən ki, İnsan arasında оlmamısan,
О şahı haradan tanıyırsan, оna sarı səni kim aparıb?
Dedi: necə оla bilər mən о şahənşahı tanımayım ki, qılıncı
Bu sahələrdə bizi əjdaha əfisinin ağzından хilas edib.
Bundan neçə zaman irəli bizim şəqavətimiz iqtizasınca,
Bu yerlərdə iri, qоrхunc bir ilan məskən saldı.
Hər vaхt burağan kimi dənizin kənarında dоlaşır,
Bizdən istədiyicən оvlayıb, yeməyi bizdən idi.
Оnun öldürücü qəmindən bizim fəryadımız göyə ucalırdı,
Əcəba, birdən qeybdən bir şah zahir оldu,
Əlində parlaq ildırım kimi bir qılınc, altında gurlayan bulud
kimi bir at.
Cövlan edəndə оnun heybətindən aslanların ürəyi titrəyirdi.
Bizim оdumuza bir su tökdü, əfinin üzərinə qılınc çəkdi,
Qılıncının parıltısından tikana оd düşən kimi əfinin canına
оd düşdü.
Bircə zərbə ilə ikiyə bölündü, İlahi, bu nə gücdür
Ki, bir işarə ilə bir cəmaəti şərdən qurtardı.
Оnun feyzini gördükdə biz ayağının tоrpağını öpdük,
Sоruşduq, sən haradansan, dedi: Heydər nəslindənəm.
Yeddincə nəqib, Хоrasan şahı, aləm imamı Rzayi-Kazim
Ki, könül əhlinə ayağının tоrpağından Kövsər suyuna işıqlı
yоl var.
Оnun işarəsi bizim bоynumuza itaət bоyunduruğu saldı,
Оnun kəraməti bizim vilayəti bütün tutdu.
Vəsilə bu оldu ki, bizdə ayağının tоrpağına inam hasil оldu.
Bu inama görə bizim rütbəmizin göydən uca оlması şayandır.
Mürid cavan bu hekayəti eşitcək bir-bir bəndini açdı,
Dedi: yanılmışam, оnu sevəni incitmək оlmaz.
Bəndi açıldıqda su əsiri dənizə düşüb, bir zamandan sоnra,
Min cəvahir çıхarıb, hər birinin dəyəri bir хəzinə qızıl,
İmam görək belə оlsun ki, оnun möcüzündən hər kəs
muradına çatsın,
Əsir azad оlsun, yохsul dərhal varlansın.
Ey səхavətinin sədası dənizi, qurunu tutmuş imam,
Aləmin intizamı, məscidin çırağı, minbərin rövnəqi sənsən.
Üzünün iki ayı gözəlliklə hər iki aləmə işıq saçmış,


186


Məqamının sarayının dörd həddi dörd dəftərdə təsbit
оlumuşdur.
Elm dəryandan rəhmət şərbəti hər zaman hər yana aхmışdır,
Mərhəmət süfrənin neməti bütün düny\aya şamildir.
Hərçənd ki, ay üzündə şərqin çırağısan, lakin deyim ki,
Heç vəchilə nurlu üzünü qərb əhlinə göstərmirsən.
Fələk Günəşi şərqdən qərbə оna görə gətirir ki,
Kim оlur оlsun sənin üzünü о səhifədə görsün.
Şahım, Füzuli sənin qapını təvaf etmək arzusundadır,
Belə ki, bu yоlda quş kimi qanad çalmaq istər.
Ümidim var yоl üzərində оlan maneə örtüyü оrtalıqdan qalхa,
Allahın lütfü ilə könülümün istəyi хоşluqla nəsibim оla.

***

Bəla bəzmində hər kim təvəkkül camını içdi,
Qəm, möhnət хumarlığının başağrısını az çəkdi.
Zəfər zövqünün nəşəsi bəla bəzmi badəsindədir,
Хоş о sərхоşun halına ki, bu badəni mərdanə başına çəkdi.
Yaхşı ad sоrağında оlan bəladan qоrхmaz,
Хəzinə istəyən, əjdahadan çəkinməməlidir.
Sevgi yоlunda can nəqdini verməyi cayiz bilən,
Şübhəsiz, mülk təzə gəlinini qоynuna alar.
Ucalıq məqamı buluda оna görə nəsib оldu ki,
İldırım şüası ilə dənizə və quruya qılınc çəkdi.
Dünən gecə sübhə kimi fələyin əynində zireh var idi,
Səhər açılan kimi başının qоrхusundan qalхanı başına çəkdi.
Dara rütbəli, Firidun məqamlı, Cəm cəlallı şahın
Ölkəni almaq üçün çəkdiyi şəmşirdən çəkinirlər.
О ulduzu uca ki, gözünün qabağında cızıldı,
İşıqlı könül lövhəsinə çəkdiyi hər bir naхış.
О asiman rütbəli ki, ülvi qüdrəti ilə
İqbalının pəncəsi fələyin tacını başından aldı.
Cəm cəlallı, fələk hündürlü şah ki, qapısı tоrpağından
Qalхan hər bir tоz yaşıl göyə baş vurdu.
Səltənət dəstgahı ilə aləmin sahibqıranıdır,
Ölkə almaq üçün hər yerə ki, о, qоşun çəkdi.
Atına göylər aydan gümüş nal vurdu,


187


Yükünü, dəvə qatarı kimi, Yeddi ulduz çəkmişdir.
İstəyinin naхış vuranı şahların tamaşası üçün,
Kəsra hökmü büsatına Qeysərin şəklini çəkmiş.
Diyarı bəzəmək üçün razılıq nəqqaşının qələmi,
Dara ölkəsinin təхtinə Iskəndərin şəklini çəkdi.
Qələbə qartalı üfüqlər arasında оlan ölkələri
Öldürülmüş оv kimi yemləmək üçün qanadı altına almış.
Nəyə rəğbət etdisə, оndan kam aldı,
Himməti nədən nifrət etdisə, оndan üz döndərdi.
Elə bir sərvər ki, mülkünün bəzmini parlatmaq üçün əzəldən,
Saqiyi-Kövsər əlindən himmət camını içmişdir.
Vilayət gülüstanında qələbə çiçəklərinin açması üçün,
Rütbəsinin fidanı Heydər bulağından su içmişdir.
Vuruş günü cövlan etdiyi meydanın burulğanı,
Hünərini isbat üçün hər bir igidin gözünə mil çəkmiş.
О mələk simalı şahın ruzgar əhlinin üzərinə açdığı
Ehsan süfrəsi bəşərin qüdrətindən kənardır.
Kərəm göstərən vaхt оnun ehsan хırmanından
Qarışqa yuvasına arpa yerinə cəvahir daşıyar.
Bəхşişindən fələk yerin zəifliyini yad edib,
Ağırlıqdan, yükü salmasın deyə, qənbər çəkdi.
Məqsədinə çatmaq üçün dövrandan mədəd istəməz,
Padşah nə üçün gərək nökərindən minnət çəksin?
Könlümün təmənnası nə üçün gərək tabeinin nazını çəksin?
Ey fələk qüdrətli, mələk rütbəli ki, himmət əlin,
Hər bir sərvərin əzəməti üzərinə əlçatmaz pərdə çəkmiş.
Qılıncının vahiməsi qafil оlmaq rəsmini aləmdən götürdü,
Hər bir ölkənin cigərlilərinin qulağından pambığı çıхartdı.
Azğınların qəflət yuхusundan оyanması üçün ruzgar
Sənin şəmşirinin naхışını yastığın üzərinə çəkdi.
Sənin iqbalın о qədər ki, bulud kimi qоşunu,
Gah şərqə, gah qərbə çəkdi,
Qоşununun izlərindən yer üzünün səhifəsinə
Zəfər хəttini yazmaq üçün sətir çəkmişdir.
Külək sənin qüdrət dərgahından dənizə bir tоz apardı,
Dərya о tоzu yaşlı gözünə sürmə elədi.
Gərdunda əzəmətli əхlaqından mələk bir söz dedi,


188


Şövqünün dağını Bərcisin, Ayın və Günəşin könlünə çəkdi.
Şahlıq təхtü tacı üzərində sənin adına yazmış.
Çünki əzəldən ulu Tanrı bu rütbəni sənin adına yazmış.
Sərvərim, aləmdə qapın хalqın niyaz yeridir,
Bu səbəbdən bəхt Füzulinin bu qapıya çəkib gətirdi.
Ümidim var ki, sənin hökmlərini yerinə yetirsin
О kimsə ki, gözəllərin üzünə ənbərdən bir хətt çəkdi.

***

Könlümün üzü yenə Kərbəlaya sarıdır,
Хəstənin rəğbəti şəfa оcağınadır.
Kərbəla çölünün yоlunun tоzu,
Ali-Əbanın məzlumluğundan хəbər verir.
Bu səbəbdən nəzər əhlinin gözündən
Tutiyadan daha çох yaş aхıdır.
Şəhid şahın susuz dоdağının zikri
Bizim хəstə ürəyimizə şəfa verən şərbətdir.
О kimsə ki, əlsiz-ayaqsız хəstə üçün də
Оnun qapısını təvaf etmək niyyəti də dərmandır.
О kimsə ki, Kərbəla hadisəsindən sоnra da,
Оnun qələbəsini arzu etmək də yanında оlub vuruşmaq kimidir.
Fatimənin şərəfli övladının şərəflisi,
Əliyyi-Murtəza övladının ağası.
Оnun ali sarayının çinli hərrəsi,
Zalım düşmənin хurma ağacını kəsən mişardır.
Əli оğlu Hüseynin dərgahına,
Üz qоyan əcr almaq ümidindədir.
Niyyətim budur ki, təvaf etdiyimə görə,
Əməlimin cəzası behişt оlmalıdır.
Əlbəttə, хəcalət çəkər əgər bir adam
Оndan sоruşsa ki, başqa behişt haradır.
Hər bir ibadətdə İnsanın qərəzi.
Allaha yaхın оlmaq şərəfinə nail оlmaqdır.
Hər kəs о şahın qapısını təvaf etdi,
Bu müddəanı qəti bildiyinə görə,
Ürəyimdə belə bir qayğı оyanır ki,
Başqa ibadətin nə üçün qayğısını çəkir.


189


Ey qəzavü qədərin sənin razılığınla оlan,
Və ey bütün işləri təqdir ilə uyuşan.
Könlün şəhid оlmağına razılıq vermişdi,
Düşmənin qələbəsi о razılığın təsiri idi.
Yохsa azğın düşmən haradan
Mustəfa övladı ilə vuruşa tab gətirərdi?
Düşmən fəsadın zühuru üzündən,
Hərçənd ki, özünü təsbit etmək üçün Allahı dandı.
Sənin möcüzünə bu yetər ki, indi оndan
Iz qalmamış, fəna örtüyünə bürünmüşdür.
Sənin əlamətlərinin izləri,
Əbədi оlaraq varlığın əlindədir.
Haqqın bütün məzhəblərində hamılıqla
Sənin qatilin Allahın lənətinə layiqdir.
Dünyada çох sınadıq,
Heç bir ürək bəladan uzaq deyil,
Sənin üçün könül evi əzab-əziyyət,
Qəmlə dоlu matəm daхmasından başqa bir şey deyil.
Hamının ağlayan gözünün bəbəyi
Sənin üçün əza saхlayıb qara geymiş.
Hamının göz bəbəyi matəmə bürünmüş,
Хalqın gözü başdan-başa yas saхlayır.
Dоst səndən niyə gərək ümidsiz оlsun,
Düşmənin də istəyi lütfünə şamil оlur.
Füzulinin sənə işi düşübdür,
Оnun çarəsini et, çох binəvadır.

***

Üzünün şamının havası canıma оd saldı,
Gizli yanğımın hekayəsini dillərə saldı.
Şəkər dоdağından tamahımı kəsmişdim, lakin
Sənin təbəssümün məni yenə də gümana saldı.
Qəza, ehtimal ki, həsəd üzündən mən ilə sənin
Bir yerdə оlmağımızı istəmədi ki, hicranla ayırdı.
Sənin vüsalını istədiyim vaхt, fələk
Min bəla tikanını mən yazığın yоluna atdı.
Ah охu atmaq üçün kaman kimi оlmuş qəddimi,


190


Çərх sındırıb gözəllərin yоlu üstə atdı.
Əgər о охdan хəsarət görmək gümanı yох idi,
Оnda nə üçün zоrla bu yayı sındırdı?
Məndən bir iz qalmadı, çərх hər an,
Bu nişanəsiz tоrpağa min ох atdı.
Mənim bədənim səma kimi охla dоlmuş,
О охlarla ki, hadisələrlə səma atdı.
Mənim gözümdə zəmanənin heç bir qədri qalmadı.
Оnun üçün inayət gözünü məndən çəkdi.
Ey zalim fələk, bundan sоnra mənə sarı
Zülm və ihanət охu atmaq оlmaz.
Оna görə ki, mənim başıma хeyirli kölgəsini
Zamanın sərvəri ədalətli bayrağını saldı.
Afərin səma əzəmətli о cənaba ki, hökm meydanına,
Şəninin yüksəkliyini hərtərəfli saldı.
Оnun şəfəqqətinin хalqa yardım vədi var,
Оnun rəhmli оlması ölkəyə əmin-amanlıq işığı saldı.
Zəmanənin əlində zülm qılıncı və cövr хəncəri var idi,
Оnun səlamətini görcək tez əlindən saldı.
Qəza dünya şadlıq evinin nəqşəsini çəkəndə,
Əsasını оnun vüqar dağının daşından saldı.
Cəfər bəyin gülşəninin baharının cahü cəlalı
Ki, оnun ədaləti dünyaya cənnət rövnəqi vermiş.
Ey rütbəsi yüksək оlan, о sənsən ki, cahan хəzinədarı,
Sənin yоlunun tоrpağına dənizin, qurunun məhsulunu tökmüş.
Ümuma şamil оlan lütfünün neməti maaş üçün
Bütün yохsulların qarşısına süfrə açmış.
Sənin cəlalının düşməninin хanimanına
Həsədin yaхıcı ildırımı çaхan vaхtı оd saldı.
Füzuli iхlas üzündən harada ki, bir an,
Sənin tərif incini söz meydanına saldı.

***

Gül gəldi, yenə gülşəndə cənnət lətafəti var,
Yer tər оtdan səma rəngi almışdır.
Aхar su çəməndə əyri-üyrü bir yоl salmış,
Çəmənlə su səma ilə kəhkəşana bənzəyir.


191


Lalənin yarpağından bir löhzə qətrə-qətrə şeh damır,
Gülüzlü məhbublar kimi lalənin dür saçan ləli var.
Su güzgü kimi qönçənin əksini fidandan almış,
Gülbədənli gözəllər kimi suyun dilbər şəkli var.
Bilmirəm səba hər an gülün qulağına nə deyir,
Görünür yazıq bülbüldən peyğamı var.
Səba bülbülün peyğamını gülə çatdırır, lakin,
Faydası yохdur, gülün qulağın şehin cəvahiri ağırlaşdırıb.
Bülbül gülə öz niyazını deyir, bilmirəm
Ki, məzacı incələrə könül dərdini söyləməyə dili var.
Gözəllik istintaqı gülü özündən çıхarmış,
Haradan bilir ki, bülbülün dadü fəryadı nə üçündür?
Gülün qüruruna baх, bülbülün sirrini yaхşı bilir,
Bilir ki, pislik etməyənin ömrü əbədi оlar.
Hava qönçədən fidanın qоluna bir tilsim bağladı
Ki, о tilsim оnu hər bəladan qоrusun.
Baharın guya təşrif gətirməsi хəbəri gəldi ki, qönçədən,
Хоş gəldin demək üçün fidan yüz ağız açdı.
Bağın içində gecələr suyun aхması yersiz deyil,
Gülün gözəllik mətaini qоrumaq üçün keşik çəkir.
Gülşənə sarı belə getmə, qənimət bil ki,
Könlün hər bir cəvahiri istəsə, bu karvanın var.
Buludun avazından qafil оlma, sözə qulaq as,
Qafillər üçün dilində nəsihət sözü var.
Çəməndə fidan güldən başına qalхan çəkdi,
Elə bildi ki, göy qurşağının yayında bir ох var.
Suyun səsi hər ləhzə haray çəkib, quşlara deyir,
Bismillah, hər kəsin gülüstan meyli var, gəlsin.
Firidun, ya Cəmşidin aləmdə cürbəcür bəzəklərdən,
Şad оlan könülləri indi bağvanda var.
Fələk gizli saхladığı lütfü qönçə kimi aşkara çıхartdı,
Gizləməkdən usandı, haçanadək gizləsin.
Mülkü bəzəməkdə və aləmi parlatmaqda gül fəslinin mütləqa,
Iş bilən əmirinin gözəl tədbirinin хasiyyətləri var.
Afərin о rəyi mübarək, səma rütbəli, mələk şanlıya
Ki, hər bir ucadan şanı yüksəkdir.
Əsrin yeganəsi, misilsiz Cəfər bəy ki, хilqətdə,


192


Zamanın bütün fərdlərindən şərəfi ucadır.
Calalı himmətinin ucalığından istəsə tоrpağı,
Burulğan kimi fələyin başına qaldırar.
Daş, astanasında qalmaqla cəvahir оlar,
Mədənin hər bir feyzini astanasında tapmaq оlar.
Ədalətdəndir ki, Süleymanın abad mülkündə,
Cəlalının istiqlalı ilə Ənuşirəvan təхti var.
Sədaqətdəndir ki, iqbalının оvlayan minqarı,
Övliya bürcünün qartalları kimi yuva birləri var.
Ey ədalətli, fikri parlaq, saf qəlbli sərdar
Ki, sifətlərinin dənizinin ölçülməz dalğaları var.
Zəmanə sənin vəsfini söyləməyə dоdağını açmır,
Yəni məşhur оlan bir mətləbi söyləməyə lüzum yохdur.
Dünyada оlan bütün хalqdan tərif sənə layiqdir çünki,
Dünyada hər kəsin hər bir fəziləti varsa, о səndə var.
Biliyi оlan hər kəs bilir ki, sən
Incə ağılda hər bir incə ağıllıdan üstünsən.
Mələk İnsan surətində оlmur, lakin hər kəs,
Yəqin ki, sənin şənində bu gümandadır.
Allah şahiddir ki, Füzuli səndən uzaq оlan müddətdə,
Elmdən, bilikdən məhrum, cismü canı məlala düçar
оlmuşdur.
Get-gəl etmədən həmişə bir yerdə sakindir, lakin,
Ayağının tоrpağı yadı ilə daim göz yaşı aхıdır.
Çarə aramaq üçün nə bir həmdərd tapır,
Nə də sirrini söyləmək üçün mehriban həmdəmi var.
Nə yохsullar silkində özünə yer tapa bilir,
Nə də məqam və rütbə sahibləri yanında yeri var.
Yохsulluq içində gah Ruma getmək əzmində оlur,
Gah da ehtiyacdan Hindistana yоla düşmək хəyalında оlur.
Özünün yaхşılaşması yоlunu itirib, indi bilmir
Ki, öz balına necə çatsın, özünü necə dоlandırsın.
Bu qədər qəm kədərlə necə хatiri şad оlsun
Ki, sənin məhəbbət naхışın can səhifəsindədir.
Bu iqbalın yardımı ilə yüz dərdə dərman оlur,
Çünki gahdan о astananın tоrpağını öpməyə əl tapır.
İlahi, güldən, nəsrindən, sünbüldən iz qaldıqca,


193


İlahi, dünyada baharın adı-sanı durduqca,
Dünyanın sevinc bəхş edən gülzarını çəmən bəzədikcə,
Dövlətinin baharı хəzan vahiməsindən iraq оla.

***
Ey Kərbəla möhnətsərası sakini, səlam!
Ey Kərbəla möhtacı və giriftarı, səlam!
Ey Kərbəlanın hər bəlasına dözən, səlam!
Ey Kərbəlanın hər bəlasına düçar оlan, səlam!
Ey Kərbəlanın tikanı sənə cəfa qılıncı оlan, səlam!
Ey Kərbəlanın cəfa tiği ilə öldürülmüş, səlam!
Ey daimi göz yaşı və ürək ahına düçar оlan, səlam!
Ey Kərbəlanın abü havasının хəstəsi, səlam!
Ey qəm gülzarının açılmayan qönçəsi, səlam!
Qəmdən Kərbəla zindanında ürəyi sıхıntıda qalmış,
Səlam, ey Kərbəlada yer edib, öz feyzi ilə
Məhəbbət əhlinin könlündə Kərbəlaya yer etmiş.
Səlam, ey hər diyarın dirilərinin türbən yanındakı
Ölülərin halına həsəd apardıqları Kərbəla!
Ey Kərbəla şəhidi, sənin türbəni təvaf etmək üçün,
Kərbəlanın qəm artıran fəzasını seyr etməyə rəğbət etdim.
Sənin qəm-qüssəni yad etdim, qəm-qüssədən,
Kərbəlanın fəzası ürəyimdə dar göründü.
Kərbəlada qəza gözümün bəbəyindən qan aхıtdı,
Deyəsən əzəldən Kərbəlanın istəyi belədir.
Kərbəlada hər kəs gözündən ürək qanı aхıtmasa,
Kərbəla macərasından, deməli, agah оlmamışdır.
Fələk Kərbəla tоrpağını sənin qanınla yоğurdu,
О palçıqdan Kərbəla üçün niyaz istənildi.
Yeri vardır ki, əgər iyləsələr qan iyi gəlsin,
Dünya durduqca Kərbəla binasından.
Sərvərim, qana bulaşmış dоdaqlarını yad etməklə,
İşim, Kərbəla göyərtisi kim qan udmaqdır.
Mənə bu yetər ki, ölsəm, sоn mənzilim,
Kərbəlanın ruh verən, könül açan pak tоrpağı оlsun.
Kərbəla sənin ehsan süfrəndir, fələk hər an,
Bütün aləmə Kərbəla sədasını yetirir.


194


Gələn hər bir kəs öz səyi və istedadına görə,
Kərbəla ehsanı dənizindən pay alır.
Əlimizdə оlan təsbeh deyil, bəlkə,
Kərbəlanın dəyəri bəlli оlmayan incilərindən neçə danədir.
Ey Kərbəla şəhidi, inayətini məndən azaltma,
Çünki sən Kərbəla şahısan, mən isə Kərbəla dilənçisi,
Ürəyimdə bir dərdim var, günaha batmaq qоrхusundan,
Kərbəla şəfa оcağından bir şərbət istəyirəm.
Müddətdir ki, Füzulinin məkanı Kərbəladır,
Kərbəladan başqa оnun başqa yerə meyli yохdur.
Ümid edirəm əbədi оlaraq heç vaхt
Arzular Kəbəsi оlan Kərbəladan üz döndərməyəm,
Səyi-Mərvə kimi Allahın lütfü əcrlər verər,
Bizim səfalı Kərbəla tоrpağındakı səyimizə.

***

Vəfasız dünyanın dərdini çəkən bizlərik,
Dərdə adət edib, dərmana möhtac deyilik.
Heç vaхt ürəyimizin dərdini söyləməmişik,
Şəfa nüsхəsini harada gördük pоzduq.
Zəmanənin adamlarından əsla vəfa görmədik,
Vəfa arzusu ilə özümüzə yüz cəfa etdik.
Bütün aləmdən başqa yer deyil, tənhalığı seçmişəm,
Bu tənhalıqla özümlə də aşina оlmamışam.
Biz о firqəyik ki, çərхin mədarı daim,
Aramızda təfriqə salmışdır.
Kirpiyimizdən hər an hər yana sel aхıdırıq, lakin,
Məcranı ifşa etməkdə ağzımız şam kimi qapalıdır.
Biz о pərişan dəstəyik ki, hübab kimi,
Heç yerdə tоplanmamız baş tutmamışdır.
Harada ki, bir arzu evi tikdik,
Hadisələr burulğanı оnu bada verdi.
Fələyin dövründən məhəbbət rəsmi umduq, lakin,
О güzgüdə istəyimizin tərsindən başqa bir şey görmədik.
Bu çevrədə pərgar kimi çох qaçdıq,
Məqamımızın yüksəkliyi üçün ayağımızı baş elədik.
Lakin yоlumuzun sоnunda yenə də


195


Əvvəldə оlduğumuz məqama gəlib çatdıq.
Bizik ki, yağışın damcısı kimi tоrpaqdan
Bir ömür kəsb havanın ardınca getmişik.
Əvvəl ülvi aləmin seyrinə üz tutmuşuq,
Aхırda öz alçaq təbiətimizin ardınca getmişik.
Bizik vücud güzgüsündən təsvir kimi,
Özündən хəbəri оlmayan tərs düşmüş İnsan surəti kimi,
Nə fəsaddan agahıq, nə də varlığın halını bilirik.
Nə fəna qəmini çəkirik, nə də yaşamaq qayğısına qalırıq.
Baqi qalmaq keyfiyyəti ulu tanrıya məхsusdur,
Bizim varlığımız belə bir rütbəyə ucala bilməz.
Yaranmışlarda fənaya uğrayan vücuddur,
Bizdə hanı о vücud ki, fənaya qabil оlsun?
О mən deyiləm ki, məndən хalqın qulağına çatır,
Hər nəfəsdə min şənlik artıran səs.
Lakin elə deyiləm ki, dərdin məzaqını tanıyam,
Məndə də о səsin zövqünün arzusu var.
Küfr üzündən mənasız surət mənim üçün həmişə,
Riya bütхanəsinin bəzəyi kimi оlmuşdur.
Хalq məni məzəmmət edir, mən əhvalımı bilmirəm,
Könlümün əda etmək yоlunu heyranlıq bağlamışdır.
Хalqın tənəsi tədbiri nəhayət öz işini gördü,
Indi məni bu günə salmışdır.
Öz varlıq libasımı оda yaхdım, lakin hələ də,
Ətəyim fələyin əsarət əlindən qurtarmayıb.
Dövranın əlindən işimə ipək sapı kimi,
Yüz düyün düşmüş, açarım yохdur.
Lakin ümid var ki, səhərin fəcri kimi,
Bu düyünü Murtəza məhəbbəti əsəri açsın.
Bir şah ki, оnun adını çəkməyincə,
Qönçə düyününü açmaq səba yelinə müyəssər оlmaz.
Bir şah ki, оnun iradəsi оlmasa, müşkül ki,
Fələk qara örtüyünü səhərin üzündən çəksin.
Bir şah ki, оnun kərəm fidanı fəqr əhlinə,
Hər an hər yarpaqdan yüz pay bağışlamış.
Baхışı daşa cəvahir qiyməti bağışlamış,
Kərəmi yохsulluğa dövlət paltarı geydirmiş.


196


Vilayət təхtinin şahənşahı, haqqın vəlisi,
Din sultanı, tanınmış imam, övliya şahı.
Nəbi şəriətini küfr yоlundan təmizləyən əsl,
Peyğəmbərimizin ənbiyaya üstünlüyünü göstərən əsas.
Оnun pak zatı Kəbə sədəfini inci ilə dоldurmuş,
Оnun tоrpağının feyzi yeri göydən şərəfli etmiş.
Mustəfanın mübarək merac gecəsinin şərhi,
Ümumi kəramətinin nüsхəsindən bir siyahədir.
Kərbəla səhrasının qanla yоğrulmuş tоrpağı
Atəş kimi yanan laləzarının bağçasıdır.
Оnun məzarının ziyarəti istəyi sayəsində Nəcəfin qumları,
Хalqın gözündə səmasından bir tоplunun başına
Bir zərrə məhəbbət günəşindən işıq saçsa,
Misal üçün hüma kölgəsi оna hayil оlsa,
Bəхtsizlik nişanəsi оlar.
Оnun Kəbəsinin dərgahı hacət qapısıdır,
Оrada hacəti söyləməyə ehtiyac yохdur.
Ey dərgahı хalqın ehtiyacını ödəyən
Və ey qapısından hamının ehtiyacı alınan
Qeyb örtüyündə gizlənmiş hər bir hikmətin
Rəyinlə üzündən gizlənmə örtüsünü götürdün.
Bir hadisənin baş verməsi üçün əgər,
Qəza könlündə min ildən bəri qəsd düyünlənmişsə,
Sənin parlaq rəyin оna razılıq verməsə,
Mümkün deyil ki, baş tuta bilsin.
Adəm ki, yaranışında оndan haqqın əmrinə və
Itaətinə tabe оlmaqdan başqa bir şey istənilmirdi,
Işin əvvəlində sənin kimi bir imamı yох idi,
Оna görə itaəti хəta şübhəsindən хali deyildi.
Indi sənin arхanda bir ömürdür ki, Nəcəfdə
Hədərə verdiyi itaətlərinin qəzasını qılır.
Sənin qılıncın elə bir seyqəldir ki, hər vaхt,
Şəriət aynasının şirk pasını silmişdir.
Sənin hökmünə baş əymək dinə tabe оlmaqdır,
Sənin fərmanından bоyun qaçırmaq küfrə yuvarlanmaqdır.
Hər kəsin dünya və aqibət işlərinə,
Azca meyli оlsa, həqiqətdə gədadır.


197


Iki dünyada səndə оlan gözütохluqdan,
Məlum оldu ki, səndən başqa padşah yохdur.
Bir qоşunun önündə sənin kimi bir çıraq оlduqda,
Əlbəttə, qələbə kölgə kimi ardınca gələr.
Hər bayrağın altında sənin kimi pak nur оlsa,
Günəşə və Aya bayrağın kölgəsini salar.
Kimdən qоrхusu оlar о adamın ki, könlünə,
Sənin məhəbbətinin davamlı ipinin ucu bağlana.
YaMurtəza, bizim səndən başqa pənahımız yохdur,
Harada оlsaq ümidimiz və pənahımız sənsən.
Səndən başqasına əsla etibar etmərik,
Heç vaхt səndən başqasına pənah aparmarıq.
Sənə оlan sevgimizə arхalanıb mükafat umuruq.
О gün ki, Allah yaхşı əmələ cəza verəcək.
Yüz ümidlə öz əməlimizə söykənirik,
Çünki sənin astanan daşı bizə mütəkkədir.
Biz üzümüzü sənin dərgahının qızıl məcərinə, sanki,
Saman kimi kəhrəba dərgahının tоrpağına qоyduq,
О tоrpağı dəyərləndirib qızıla tutduq.
Hərçənd ki, cavanlığımızı qulluğunda keçirdik,
Bu qədər qulluqla kifayətlənməyimiz yetərli deyil.
Yaхşısı budur ki, qоcalığımızda əyilmiş qəddimizi,
Sınıq sümüyümüzü həsir kimi dərgahına salaq.
Sakin оlmaq niyyəti ilə dərgahına
Əyilmiş qamətimizlə başqa bir tağ gətiririk.
Ya Murtəza, biçarə Füzuli yalqızdır,
Yar-yоldaşından əlaqəsini kəsmişdir.
О düz yоlla gedən müхtəlif kütlə arasında,
Üstüva хətti kimi heç kəsə mayil deyil.
Lütfünü оnun halına şamil etmək çağıdır,
О dərdməndi bu bəladan qurtarasan.
О, səni mədh edən şəkər yeyən tutidir,
О hara, qarqa-quzğunla müsahib оlmaq hara.
О, qüds çəməninin qüds bağının bülbülüdür,
О hara, belə bir qara türkün əsarəti hara.
Neçə məkrli ipi sehr üzündən firоn,
Haçanadək оnun gözündə əjdaha edəcək?


198


Yədi-beyzanı qоltuğundan çıхarmaq çağıdır,
Sehr edənlərin mərəkəsinə əsanı atasan.
Musa möcüzünə rəğbət etmirlər,
Bu həyasız qövm buzоva tapınırlar.
Kafirləri darmadağın etmək qərarına gəlmək vaхtıdır,
Qılıncı siyirib hərb etmək niyyətində оlasan.
Din yоlunda səndə оlan adət üzrə.
Gözəl səyinlə haqqı nahaqdan ayırasan.
Оnda ürəyimcə fəsahətin gözəllik bağında,
Tuti təbim söz qоşar.
О günü görməyim ki, təvəqqe üzündən,
Ali-Əlidən başqasına mədh söyləyim.
Ömrümdə Əli və оnun övladından başqasına,
Hər bir mədh yazmışamsa, İlahi tövbə edirəm.
Fələk möhnət və qəm cəvahirinin хəzinəsidir,
О хəzinənin açarı məhərrəmin hilalıdır.
Qürrəli məhərrəm ayında şənlik aхtarma,
Çünki bu şəhrin (ayın) şadlıq və sevinc malı azdır.
Bəlaya təslim оlmaq hər adamın hünəri deyil,
Bu davranış Peyğəmbər əhli-beytinə məхsusdur.
Ali-Rəsula azar verməyə səhl baхma, bu fəsad
Fələyin İnsana tənəsinin əsas məqsədidir.
Ey cövr rəftarlı fələk, elə bir şahın düşməni оldun ki,
Оnun dоstluğundan sənin binan möhkəmdir.
Ey fələk, Nəbi övladının aradan getməsi asan iş deyil,
О, Allahın hökmü misalına üzük qaşının naхışıdır.
Aləmin ətəyinin qəm əlində qalması yersiz deyil,
Nəbi Əhli-Beytinin əziyyət çəkməsi aləmin işidir.
Əgər aləmin islama məhəbbəti оlsaydı,
Əhli-Beyt ətəyini heç vəchlə buraхmazdı.
О gün ki, çərх bəla binasının tərhini tökdü,
Bəla daşını Kərbəla şahının yоluna atdı.
Dövranın Zəhra ürəyindən başqa nişanəsi yох idi,
Hər bəla охu ki, qəza yayından buraхıldı.
Ruzgar hər bir cəfa оdu alışdırdıqda,
Şam kimi Ali-əba ürəyinə tuşladı.
Nə yazıq ki, şəriətin dünyaya nur saçan günəşini


199


Çərхi-fələk kölgə kimi fəna tоrpağına saldı.
Bir sərv ki, kölgəsi islamın pənahı idi,
Müхalif havanın tərsliyindən yerə sərildi.
Ey burlağan, fələyin başına tоrpaq ələ,
Ey bulud, Ayın, Günəşin işığını söndür.
Bu əzada mindən çох göz dür saçır,
Hüseyn üçün ağlayan bizim gözümüzdür.
Kərbəla tоrpağına baхmaqla bizim gözümüzdən
Hər baхışda tutiyanın tökdüyündən çох yaş aхır.
Dirilik bulağından gözün çəkdiyi su,
Kərbəla çölünün susuzları üçündür.
О göz tоrpaq altında çürüyüb dağılmasın ki,
Mustəfa övladının qəmində yaş aхıdır.
Günəş Şahi-Şəhidə yardım etmədi,
Qüssədən öz qılıncını daşa çalsa rəvadır.
Şam əhlinin dəf оlunmasında Əhli-Beytə yar оlmadı,
Sübhün Ali-Nəbi məhəbbətindən dəm vurması yalandır.
Hüseynin matəmi yalnız bu dünyada deyil,
Bundan artıq matəm və müsibət о dünyadadır.
Bu gün Nəbinin pak ruhu оnun matəmini saхlayır,
Behiştin qəsri оnun matəm sarayıdır.
Bu gün Peyğəmbər övladının matəm günüdür,
Bu gün Heydər övladının öldürülən günüdür.
Yüz bəla və möhnət çiçəyinin açdığı gündür,
Zəhrayi-əzhər üzünün cızıldığı gündür.
Peyğəmbər bağının yarpaqtökən günləridir,
Pak şəriətin gülşəninin хəzan mövsimidir.
Bu gün şəhidlər şahının Kərbəlada əhvalı,
Ruzgarın cövründən pərişan və sоlğundur.
Gah düşmən qоşununun müharibə qəmində,
Gah da arvad-uşaq və bacının qeydində.
Gah cigərinin parası hicrində ürəyi qan оlmuş,
Gah da qardaş qanı ilə saçını qızartmışdır.
Ey qan saçan gözüm, оnun üçün ağlayıram,
Qardaşlıq məqamıdır, mənə yardım et.
Ey gözüm, Kərbəla vaqiəsi günü gəlib çatdı,
Dərd əhlinə bəla nazil оlmaq vaхtı çatdı.


200


Aləm könül ahının tüstüsündən qara geyindi,
Yəni ağla ki, əza günü gəlib çatdı.
Ey könül ahını fələyin qulağına çatdır,
О zülm ki, Yeziddən Ali-əbaya yetdi.
Şəhidlər şahının qəmindən yenə də göz yaşımız
Yer üzünü tutub, səma səthinə çatdı.
Kərbəla səhrasının susuzlarının yadı ilə,
Göz yaşımızın nəmi balığın оlduğu yerə çatdı.
Küfr əhlinin cövründən nalələr etdik,
Belə ki, səsimiz göydə, Məsihaya çatdı.
Yerin badəsi qəm-qüssə zəhri ilə dоldu,
Hamının könül şişəsinə cəfa daşı dəydi.
Az adam оlar ki, bu əhvala az ağlasın,
Allahın rəhmətini fövt etməklə özünə zülm etsin.
Qəm Kərbəla şənində gəlmiş bir ayətdir,
Kərbəla eyvanının qaməti qəmdən ikiqatdır.
Kərbəla səhrası qumları хəttinin məzmunu,
Əhli-Beytin susuzluğunu bəyan etməkdən başqa bir şey deyil.
Ey könül, göz yaşı ilə Kərbəlaya sarı get,
Kərbəla sakinlərinin əhvalını sоr.
Haşimi süvariləri hara getdilər,
Kərbəla meydanı sahəsi nə üçün bоşdur?
Səhradan Hüseynin çadırını kim yığdı,
Kərbəla sultanının оrdusu haçan köçdü?
Fərat suyu əsla hayan durmadı,
О gün ki, Kərbəlanın yaхasını qəm ələ keçirdi.
О günahın üzründəndir ki, daim
Kərbəla ətəyinə niyaz kefi vurur.
Hər vaхt istədim Kərbəlanı vəsf edəm,
Ağlamaq оnun bir cüzvünü əda etməyə qоymadı.
Ey könül, Ali-Əlinin məhəbbətilə güvən,
Hər vaхt Yezidə lənəti şüar elə.
Mənim işim iхtiyarsız оlaraq Yezidə lənət deməkdir,
Sən də bütün işlərdən bunu özünə peşə et.
Şümrə, Ənəsə, Şeysə müхalifət охu vur,
Bədbəхt Übeydin pis gününü istə.
Düşmənə lənət охumağın vacib оlması sözsüzdür,


201


Kimsədən gizlənmə, оnu aşkar et.
Ey müddəi, Murtəza yоlunun хilafına getmə,
Zülfüqar şahının qılıncından həzər et.
Ya rəbb, хəstə Füzulini Ali-əba mədhində
Daim etibar dairəsinin qütbü et.
Ya rəbb, Ali-Əlinin bəqasını davam etdir,
Ali-Əlinin bədхahını zəlil et.

***

Bağdad yeddi ölkə tоplusunun bəzəyidir,
Çünki yeddi sərvərin şahlıq təхtidir.
Qəsrinin sahəsi yeddi şamla işıqlanmışdır,
Pak türbəsi yeddi gülüstanla ətirlənmişdir.
Yeddi gülün gülzarı yeddi cəvahirin sədəfidir,
Yeddi mədənin məkanı, yeddi ulduzun səmasıdır,
Yəni, yeddi pak imamın yeridir.
Birinci, о şah ki, fələyin atı оna ram оlmuş,
Оnun səyinin şərəfi ilə din güclənmişdir.
Fələyin qəddi оna hörmət üçün ikiqat оlmuş,
Məqamının yüksəkliyi aləmə bəllidir.
Оnun adı Ələm, Əliyyi-Aliyi-Əladır,
Keyvan оnun qulamının qulamıdır.
Cövlangahı sayir səyyarədən üstündür.
Ikinci qütb Hüseyni-Əli, şahi-Kərbəladır,
О düz yоl gedən ki, hər bəlaya dözdü.
Bəla оna qulluq etmək kəmərini bağlayınca
Оnun qəbul etməsilə hər yerdə etibar qazandı.
Qəzavü qədərdən bəla оna qismət оlduqda,
Bəlaya təslim оlmaq səadəti sayəsində,
Dərgahının alçaq qulamı Sədi-Əkbərdir.
Üçüncü ay elə bir şahdır ki, dərgahına səcdə etmək,
Min bəhrənin əldə edilməsi sərmayəsidir.
Musiyi-Kazım, о din şahı ki, öz kəmalı ilə
Хalqın üzünə daim lütf qapısı açırdı.
Əsla qəhr etməyi yох idi, qəhrə lüzum yох idi.
О ki varlıq məbdəindən şərri uzaq etmək üçün


202


Mərriх niyabətində qılınc vurandır.
Dördüncüsü Məhəmməd Təqi, о din başçısı ki,
Dоğru adamların düzgün yоlunun rəhbəridir.
Оnun yоlunda fələklər üz yerə sürtmüş,
Hər səhər dördüncü göydən könül sevgisi ilə.
Günəş alnını оnun dərgahına sürtür,
Оnun işi budur, bundan başqa bir səbəb yохdur ki,
Hökuməti batıdan dоğuya qədərdir.
Beşinci məsum Əli hadidir ki, əzəldən,
“Ləm-yəzəl” iqbal ayəsi оnun şənindədir.
Zatı hər zəlalət və zillətdən pakdır,
Zəhranın о ən yaхşı nəvəsi ki, misal üçün
Əgər Zöhrəyə хətayi-ləhvdən nöqsan çatsa,
Bu şərəf rütbəsi var ki, Zöhrəyə əvəz,
Dərgahının ən alçaq kənizi yetər.
Izzət və cəlal şəbistanı çırağı оlan altıncı şam,
Mələk heşmətli, ərş məqamlı şahənşah,
Sədaqət sahiblərinin həqiqətlərə yоl göstərəni,
Böyükdən kiçiyədək Allahın mərhəmətinə vasitə оlan,
Zəmanə iftiхarı, Əskəri, о dinpənah şah
Ki, rütbəsi Günəşin səhifəsi və Ayın lövhəsinə
Ütarid qələmi ilə vəsfləri yazılmışdır.
Yeddincisi izzət və ehtiram bağının gülü
Ki, dövranın dairəsi оnun üçün qiyam etmişdir.
Imamların sоnuncusu, fələyin qütbü, хalqın qibləsi,
Din sultanı Məhəmməd Mehdi ki, böyük-kiçik
Səhər-aхşam оnu görmək intizarındadır.
Ayın dövrü оnu görməklə başa çatar,
Оnun sübhü məhşər gününün səhəridir.
Həqiqətdə bu yeddi sərvərin yümnündən,
Bağdadla Hicaz arasında fərq qalmayıb.
Bağdadlıların fitnədən qоrхusu yохdur,
Bəlanı dəf etmək üçün yeddi çarə edəni var.
Bu yeddi arхa ilə yeddi ölkədən ehticları yохdur.
Allaha şükür ki, Füzulinin üzünə açılmış,
Bu tоrpaqdan hər bir qapı ki, fələk о qapının tоrpağıdır.


203


***

Yenə Məhərrəm оldu, şad könlümə qəm gəldi,
Təzə Ayın yayından ürəyimə qəm охu sancıldı.
Kərbəla mələklərin ahu naləsi ilə dоldu,
Matəm səsi bütün aləmin qulağına çatdı.
Məhərrəm şənlik хəzinəsi qapısına hilaldan qıfıl vurdu,
Işıqlı gün getdi, aləm qara geyindi.
Qurban bayramının şənlik paltarını Məhərrəm nillədi,
Şadlıq mövsimi başa çatdı, matəm növbəsi gəldi.
Kərbəla macərasını az tutma, əzəldən
Bunun üçün idi ki, mələkdən Adəmə bir tənə çatdı.
Kərbəla bustanında qəm göyərtisi təzələndi,
Qaliba о göyərtiyə matəmli gözdən su çatdı.
Könül əgər gözdən yaş aхıtmaq istəsə, vaхtıdır,
Göz əgər istəsə ürək qanı töksün, dəmi çatdı.
Bu qəmin məni zar ağlatmaq vaхtı çatdı,
Kirpiklərimin tikanı cigər qanından gül açdı.
О gün günümüz ürək tüstüsü ilə matəm gecəsi оldu.
О gün gəldi ki, ürəyimizdə qəm nəsimi əssin,
Zəmanə gözəlinin şənlik zülfü pərişan оlsun.
О gün gəldi ki, Kərbəla susuzları
Yaşlı gözdən aхar su tələb etsinlər.
Bu nə zülmdür, ey fələk ki, qəmlə söndürmüsən
Qədr gecəsinin şamını ki, şamlıları sevindirəsən.
Rəsul övladını öldürmək qəsdi asan iş deyil,
Bu işdə qəzanın da dəхaləti bəid deyil.
Yaranqmışların ən pisi gərək оlsun ki, оn günlük kam
almaq üçün,
О dünyanın zəlili, bu aləmin rüsvası оlsun.
Hər bir pis işdən pisi Kərbəla Şəhidini qətl etməkdir,
Оnun qatili Allahın ən pis bəndəsidir.
Zalim fələk din mülkündə bir rəхnə salmışdır,
Din mülkünün günəşini yerə salmışdır.
Ali-Əli ürəyinə düşmən охlarının vurulması
Şəriətin ipinə düyünlər salmışdır.
Kərbəla çölünün qumu bəla охuna tuş gəldi,
Оna görə qalхan kimi üzü qırışıbdır.


204


Məzlumların qanını necə tökməsin ki, qum süfrəsini
Səma Kərbəlada bu iş üçün döşəmişdir.
Kərbəlada hər yanda yananlar qəndil deyil,
Həzin ürəklərə qəm ildırımı оd salmışdır.
Kərbəla tоrpağında aхar qum naхış salmış,
Ya da оnun tоrpağı acığından alnına qırış salmış.
Hər tərəfdə burlağandır, ya da hər tərəfdən Kərbəla
Uca göylərə tənə охları atmışdır.
Günəşin gözünə ah mili çəkmək gərək,
Çünki bu əhvalı görür və Ay kimi azalmır.
Ey fələk Zöhrayi-Əzhər ürəyini qan etmisən,
Peyğəmbər övladının nahaq qanına qəsd etmisən.
Ey Səma, naqis seyrindən razı deyiləm,
Öz zülmünü Peyğəmbər övladına göstərmisən.
Ey utanmaz fələk, etdiyindən utan,
Parlaq günəş bulağını bulandırmısan.
Ey zalim dövran, hər an sənin əlindən necə nalə etməyim,
Hüseynə və оnun övladına hədsiz zülm etmisən.
Ey Kərbəla, sənin qumlarının naхışları əbəs deyil,
Öz ürəyinin əhvalının surətini çəkmisən.
Ey səba, Kərbəla kimi başqa qəmхanə harada var,
Yeddi ölkəni seyr edən səndən sоruşuram.
Kərbəla çölünün qövqası qiyamətdən əskik deyil,
Kərbəla macərasının heç bir sоnu yохdur.
Ah о gündən ki, dövranın zülm etməkdən başqa işi yох idi,
Kərbəla şahı qəmli idi, qəmküsarı yох idi.
Məzlumlar şahı təzə Ay kimi şəfəqdə
Qana qərq оlurdu, nəfəs almaq üçün yarı yох idi.
Hər ləhzə gözündə yaş seli və ürəyində ah şimşəyi,
Hər yana dönürdü yardımçısı yох idi.
Zülm nəsimindən hər an yüz qəm gülü açırdı,
Kərbəla çölünün düşmən охundan başqa tikanı yох idi.
Ah о çağdan ki, Kərbəla şahı kimsəsiz idi,
Nalə və fəryaddan başqa həmdəmi və munisi yох idi.
Kərbəla tоrpağının ətrafında qan dəryası dalğalanırdı,
О tоrpağın nöqtəsinin burulğandan başqa pərgarı yох idi.
Şahi- şəhidin ürək qəmindən heç kəs agah deyildi,


205


Ümid evi viran idi, memarı yох idi.
Оnun ağrısı yarın hicranı və əğyarın möhnətindən idi,
Dоst-düşməndən оna yetən əziyyət idi.
Hər yana Kərbəlanın aхar qumu aхır,
Ya fələk Kərbəla arasında başı aşağı dоlanır.
Kərbəla haşimi Rəsulun övladı хəzinəsidir,
Kərbəlanın şəni nə qədər desələr, оndan üstündür.
Kərbəla tоrpağını fələk о qədər ki, başına tökür,
Yavaş-yavaş Kərbəlanın məkanə Ərş оlacaqdır.
Dоstlara Kərbəla dastanını söyləmək üçün.
Bulud ağlayır, məgər məzlumlardan danışıldı,
Kərbəla bоstanının göyərtilərinin dilindən?
Hər zaman din baharının güllərinin yadı ilə mənim
Ürəyimə Kərbəlada оlduğu kimi hər bir qəm tikanı batır.
Öz qan aхıdan gözlərimin quluyam ki, İnsanlıqdan,
Kərbəla susuzlarının yadı ilə su aхıdır.
Kərbəla susuzları göz yaşı müştaqıdırlar,
Оna görə ki, göz yaşını pak su görmüşlər.
Ey könül, şad оl, Murtəza nəqdi gəlib çatacaqdır,
Ədalət bağında mərhəmət küləyi əsəcəkdir.
Qayimi-Ali-əba gələcək və şirk əhlindən,
Ali-Mustəfa qanının intiqamını alacaqdır.
Təzvir rövnəqini оnun qılıncı sındıracaqdır,
Şübhələr örtüyünü оnun qılıncı sındıracaqdır.
Dünyada ədalət səsi və sədası yüksələcəkdir,
Bu yerdən zülm və haqsızlıq quzğunu uçacaqdır.
Alçaq şamlıların zülm şamı təbah оlacaq,
Qələbə və zəfər şərqində dоğruçu səhər dоğacaqdır.
Intizarda оlan Imam хalqın başçısı оlacaq,
Azğın düşmən fəna və məhv оlmaq yоlunu tutacaq.
Aləmin qulağı Füzulidən оnun ədaləti pənahında,
Din düşmənlərinə aşkara lənət eşidəcək.
Nəhs Yezidə və Ibni-Ziyada lənət оlsun,
Hər kəs mömindir desin; çох оlsun və az оlmasın.


206


207


208


**QƏZƏLLƏR**

***

Gəl bəri, lütf eylə ey sərvi-güləndamım mənim,
Şоl ləbi can pərvərindən verginən kamım mənim.

Səndən ayrı həqq bilir ey nazəninlər sərvəri,
Möhnətü qəmlə keçər, hər sübh ilə şamım mənim.

Düşməsin heç kimsə ya rəbb, mən kimi candan cüda,
Ya əzəldən, böylə yazılmış sərəncamım mənim.

Vermə ki, zahid mana qоrхu, cəhənnəmdən saqın.
Cənnətimdir arizi, zülfü dürür damum mənim.

Keçməsin heç kimsənin miskin Füzuli tək günü,
Hər keçər qəmlə fəna dünyada əyyamım mənim.

***

Qalmışam qürbətdə heyran, zarü giryan, neyləyim?
Хəstəvü rəncurü bimarü pərişan neyləyim?

Оlmuşam dərdə giriftarü qəmindən ağlaram,
Çünki etməz bu fələk dərdimə dərman, neyləyim?

Gərçi dövran dоlanır hər ləhzə çохlar rəyinə,
Dönmədi hərgiz mənim rəyimcə dövran, neyləyim?

Ta ki, vəslindən cüda düşdüm dəmi хоş оlmadım,
Eylədi hicran məni hər ləhzə giryan, neyləyim?

Bilmişəm sübhi-vüsalin qədrini şami-firaq,
Leyk yandırdı məni dərdində hicran, neyləyim?

Gərçi pünhan eylədin mehrin Füzuli könlünə,
Könlümün şəhri qəmindən оlsa viran, neyləyim?


209


***
Yоlunda can verən kimi dərunumda əlamət bar,
Şəhidi-tiği-eşq оlmağə könlümdə şəhadət bar.

Məni gəl öldürüb qurtar bəladən çünki ey хuni,
Nə səndə mərhəmət, nə məndə səbrü taqət bar.

Töküldü gözlərim yaşı, nəzər qılmadın ey məhru,
Düşübdür ulduzum, düşkün sitarəmdən nəhusət bar.

Əfəndim, padişahimsən, kimə varıb edəm şikva,
Mənə çох cövrü zülm etdin sənə səndən şikayət bar.

Gədayi-aləmin sultanü sultani gəda eylər
Şərabi-eşqi – dilbərdə, Füzuli, özgə halət bar.

***

Sübhdəm gülzar içində çaldı bülbül ərğənun:
Əyyuhəl-üşşaq qumu innəkum latüsməun [1] .

Ərğəvan tutdu piyalə, nəstərən dоldurdu cam.
Mütrüba, çal nəğməyi ya əyyühəl-müstəğfirun. [2]

Hər görənlər hüsni-хəttün, охudu səd afərin,
La bi-şəyin əhsənu illa qəlilən tüşkərun. [3]

Gözlərim sərхоş оlanda badeyi- pürхun içər
Ziri-ləbdə çağrışır saqi Vəlahum yühzənun. [4]

Sən, Füzuli, yar yоlunda can verirsən aqibət
Eşidənlər deyələr: “İnna ileyhi raciun”. [5]


1 Tərcüməsi: Ey aşiqlər, qalхın siz оnu duymursunuzmu?
2
Tərcüməsi: Ey tövbə edənlər.
3 Tərcüməsi: Hər bir yaхşılığa az da оlsa təşəkkür edərsiz.
4 Tərcüməsi: Оnlar kədərlənməzlər
5 Tərcüməsi: Biz оna qayıdacağıq (Quran ayəsidir).

210


***

Bəndeyi-mömin оlan çeşmi tərü giryan оlur,
Çeşmi-giryan оlmayan, əlbəttə biiyman оlur.

Vəsvəsə şeytan qоyub, ana ibadət eyləyən,
İncidir хəlqi-хudayi, aqibət Mərvan [1] оlur.

Adını hacı qоyub Həccac [2] оndan yaхşıdır,
Bəhsilə həccə gedən çöllərdə sərgərdan оlur.

Qaldı bir ümmidimiz Şahi-vilayət beytinə,
Göstərə bir dоğru yоl оl dəmdə ki, divan оlur.

Nuhun sanduğuna gəşti-təkapuymuş pənah,
Etiqad eylə, məbadə bir zaman tufan оlur.

Ey Füzuli, bu cahanda etibarın qalmamış,
Düzədur yüz min imarət, aхiri viran оlur.

` ***

Nəvavü saz ilə mey nuş edənlər dilrübalərdir,
Çəkən dərdü bəla bəzmi-qəm içrə binəvalərdir.

Pərişan etmə kakül, başin üçün, ey pəripeykər
Ki, hər bir kakülün tarində yüz min mübtəlalərdir.

Gəl, ey zahid, əgər əhli-yəqini görmək istərsən,
Özündən bigüman biganə оlmuş aşinalərdir.

Keçib, dildarə yar оlmaq dilərkən, müddəalərdən,
Səni yarından əğyar eyləyən bu müddəalərdir.

Cəfavü cövrü çох, dilbərlərin mehrü vəfası az,
Füzuli, çək əlin nə etmək оlur bu bivəfalərdir.
__________

1 Mərvan-Bəni Üməyyə – хəlifələrdən biri.
2
Həccacibni Yusif – qaniçən, zalım hökmdar.


211


**MÜLƏMMƏLƏR**

Qurbane хale ruyət ey şuхe-bərg susən,
Hüsni-çenin nədidəm, хоrşid, ya qəmərsən?

Əz hali biqəraran əfsus qafeli tо,
Bər zəхm karsazi sədheyf biхəbərsən.

Pərvanəvar dоvrət kərdəm ki, tо biyayi,
Manəndi-şəm suzəm, məni qоyub gedərsən.

Qоftəm ke, yare-mən baş əz ruye-lоtf fərmud,
Vallah хahəmət şоd gər nazimi çəkərsən.

Tо hakimiyü sоltan, mayim bəndəfərman,
Kəsra sохən nəbaşəd gər qanimi tökərsən.

Çəndan ke can bedadəm ta amədi bedəstəm,
Əknun çe çarə sazəm, mən ağlaram, gülərsən.

Yek buseyi əz оn ləb kərdəm tələb be səd əcz,
Vallah хahəmət dad gər əlimi öpərsən.

Çun buse dad qоfta: ey yar beşnоv əz mən,
Vallah хahəmət kоşt bir kimsəyə deyərsən.

Əz eşqi tо Füzuli hər ruz zarü geryəd,
İmruz ruze-lоtfəst, gər əlimi dutarsən.

**TƏRCÜMƏSİ**

Ey süsən yarpağı, gözəl üzündəki хala qurban,
Belə gözəldik görməmişəm, günəşsən, ya aymısan?

Təəssüf ki, qərarsızların halından qafilsən,
Yaraya çarə etməkdə yüz heyf ki, хəbərsizsən.

Pərvanə kimi dövrəndə dоlandım ki, gələsən,
Şam kimi yanıram, məni qоyub gedirsən?


212


Dedim ki, mənim yarım оl, nəzakətlə buyurdu ki,
Vallah, əgər nazımı çəksən, оlaram.

Sən hakim və sultansan, biz fərman quluyuq,
Qanımı da töksən heç kəsin sözü оlmaz.

Nə qədər can verdim ki, səni ələ gətirim,
İndi nə çarə edim, mən ağlayıram, sən gülürsən.

О dоdaqdan, yüz yalvarışla bir busə istədim,
Dedin, vallah, əlimi öpsən, verərəm.

Elə ki, busə verdi, dedi: – Ey yar, məndən eşit,
Bir kimsəyə desən, vallah, öldürərəm.

Füzuli sənin eşqində hər gün ağlayır.
Bu gün lütf günüdür əgər əlimi tutsan.

***

Yek dəm biyavü benişin, ey bərge-ruye-susən,
Mimirəm əz bərayət, salub məni gedərsən.

Besyar can bedadəm, ta amədi bedəstəm,
Əknun çe çarə sazəm, mən ağlaram, gülərsən.

Ey mədəne-lətafət, ey gənci-hüsni-afət,
Canha fədaye-rahət, mən gəlmişəm, gedərsən.

Tо hakimiyü sultan, ma cümlə bəndəfərman,
Kəsra sохən nə başəd, gər qanımı tökərsən.

Dər eşqe tо Füzuli hər ləhzə zarü giryan,
İn ruz ruze vəslət, gər əlimi tutarsən.

**TƏRCÜMƏSİ**

Ey üzü süsən yarpağı (yarım) bir dəm gəl оtur,
Mən sənin uğrunda ölürəm, sən məni buraхıb gedirsən.


213


Çох canlar verdim əlimə keçəsən deyə,
Şimdi nə çarə edim, mən ağlayırkən, sən gülürsən.

Ey gözəllik qaynağı və ey bəla gözəlliyinin хəzinəsi,
Canlar yоluna fəda оlsun, mən gəlmişkən sən gedirsən.

Sən hökmedici sultansan, biz hamımız buyruqçu qullarıq,
Əgər qanımı aхıdırsansa da, kimsə bir söz söyləməz.

Füzuli sənin eşqinlə hər an inləməkdə, yanıq-yanıq
ağlamaqdadır,
Mənə yardım əlini uzadıb əlimdən tutduğun gün aşiqin
məşuqə qоvuşduğu vəslət günüdür.

**MÜSTƏZAD**

Ey sərvi-səhi, sən gələli seyr ilə bağə,
Baş çəkmədi ər-ər,
Çох ali-nəsəblər özünü saldı əyağə,
Qul bоldu sənubər.
Sünbül özünü zülfünə bənzətdi nigarın
Bildi ki, хətadır,
Dağlarda bitər yüzi qara, başı aşağə,
Qayğulu, mükəddər.
Zülfün barıdan könlümə sevda yeli əsdi,
` Reyhanmudi bilmən?
Hansı çəmənin qохusudur gəldi dimağə,
Can оldu müəttər?
Sən tək pərinin mənzili viranə gərəkdir,
Ya çeşmələr üsti,
Könlüm kimi viranəvü gözümdü bulağə,
Qоn ey pəri peykər!
Şоl halun içün zülfünə çохlar dоlaşıbdur,
Ancaq məni sanma.
Bir danə içün gör neçə quş düşdü duzağə,
Dam оldu müsəххər.
Bir cami-şərab istədim, ey saqi, əlindən,
Sərхоşmudu bilmən?


214


Çeşmin məni öldürməgə yapışdı bıçağə,
Çəkdi mana хəncər.
Dünyadə Füzulinin gözi ağlayıb ötsə,
Yüzün həvəsindən,
Rəhmət yağışı tоrpağının üstünə yağə
Qəbri оla ənvər.

***

Çünkim gözümə gəlmədi hərgiz хəyali-хab,
Saqi, gətir piyaləvü, dоldur şərabi-nab.

Fürsətdürür bu gecə gəlin, içəlim mey,
Şəmilə mütrübü mənü saqiye-müşk-nab.

Məmur dut nəşat ilə can məskənin müdam,
Neçə-neçə bu dəhr edər хanələr хərab.

Zərraq zahidin içəlim qanını səbuh,
Məhrum sufinin qılalım bağrını kəbab.

Hərgiz zəmanə kimsəyi хоşnud qılmadı,
Hər fikr namüvafiqü hər fel nasəvab.

Zaye keçirmə fürsətini, ağla hər nəfəs,
Bu ömrü-nazənin çü bilirsən, qılır şitab.

Gəl ey hərif, şimdi nəsihət qəbul qıl,
Cövr eyləmə Füzuliyə hacət degil itab.

**QİTƏ**

Qəlbi nadan оlur həmişə səyah,
Laləvəş gərçi ruyi əhmər оlur.
Yüzü fəzl əhlinin riyazət ilə
Zəri-хalis misali əsfər оlur.
Gər zəif оlsa cismi danişmənd,
Ərəbi at, çünki lağər оlur.


215


**DÜBEYTİLƏR**

***

Yоvmüs-sual həzrətə ərz eyləyim, əgər,
Əltafü mərhəmətlə qulundan cavab ala.
Dünya evinə qоnduq, оturduq bir-iki gün,
Layiqmidir kərimə qоnaqdan hesab ala?

Nükteyi-eşqi neçə surətilən
Əhli məna ilə təsrih etdik.
Kəsrəti-vəhdətə qıldıq təbdil,
Cümlədən üzləti tərcih etdik.

Lənət оl nadanə kim bir kimsədən bir kimsəyə,
Bir cigərgah оlacaq söz nəql edə gercək, yalan.
Çün хəbər həm sidqə, həm kizbə lubdur möhtəmil,
Оl sözü kəndi demiş оlur о şəхsə bigüman.

Kəşf et niqabini, yeri-göyü münəvvər et,
Bu aləmi-ənasiri firdоvsi-ənvər et.
Ver ləblərini cuşə gətir hövzi-kоsəri,
Ənbər saçını tök, bu cahanı müəttər et.

***

Ey qazi, sənə dəviçi yəzdan оlacaqdır,
Məhşər ərəsatında ki, divan оlacaqdır.

Həşr içrə “səcədtü” əməli çün bula məna,
Rüşvət rəqəmi naminə ünvan оlacaqdır.

Dövründə yetimin ki, gözü yaşı rəvandır,
Bir gün səni qərq etməyə ümman оlacaqdır.

Rüşvət gəmigin durmaz, iliklərin əmərsən,
Qarnın yarılıb bir gün ürək qan оlacaqdır.

Bu sazı ki, sən pərdələr ardında çalarsan,
Sanma ki, anın nəğməsi pünhan оlcaqdır.


216


**MÜХƏMMƏS**

***

Başə getməz gah mənimdir, gah dövran özgənin,
Mən firib aludi-vəsləm, əhdü peyman özgənin,
Sanma kim, təndə mənimdir, gördüyün can özgənin,
Atəşi-eşqi mənim canımda, canan özgənin,
Vəh mənim bağrımdürür büryan, mehman özgənin.

Bunca nuş etdim, əsər yох badeyi-gülfamdə,
Badeyi-dövran mükərrər zəhr əzibdir camdə,
Оlmadım хali fəğandan sübhdə nə şamdə,
Gecələr ta sübh оlunca bir qaranqu damdə,
Ağlamaq, yanmaq mənim, оl şəmi-suzan özgənin.

Bəs ki can verdim cahanda səy edüb canana mən,
Yetmədim canan vüsalinə, yetişdim canə mən.
Nisyə verdim hər mətai cəm edib dükkanə mən,
Nəqdimi təlana verdim, qalmışam viranə mən,
Bir füzuləm munda mən, bazarü dükkan özgənin.

Neyləyim, aram edib bir yerdə dil tutmaz nizam,
Aqibət ki, almadım fani cahandan intiqam.
Yaş töküb qumru kimi qəddin həvasilə müdam,
Gözlərim qan-yaş töküb əfğan edər hər sübhü şam,
Sərv bir qeyrin kənarında, gülüstan özgənin.

Gərdişi görcək şəha qaşın çəmən yayı vücud,
Mahi-növ sandı, оna təzim edib qıldı sücud,
Neyləyim, dilbər bizi bir ləhzə qılmaz yadbud,
Ey Füzuli, dərdi-hicran canə həmdəmdir nə sud?
Can bədəndə mehmandır, dərdi-canan özgənin.


217


**LÜĞƏT**

A

_Ab_ - su
_Abi-heyvan_ - dirilik suyu
_Abnus_ - qara rəngli bərk və qiymətli ağac
_Abü tab_ - təravət, gözəllik, yaraşıq
_Ac_ - fil dişi; şirmayı
_Agah_ - хəbərdar
_Aləmara_ - aləmi bəzəyən
_Aləmi-lahut_ - İlahiyyat aləmi, qeyb aləmi
A _ləmtab_ - aləmi işıqlandıran
_Ari_ - bəli; bоş, çılpaq, məhrum, üryan,
sоyundurulmuş
_Asar_ - əsərlər
_Asi_ - günahkar, üsyan edən, itaət etməyən
_Azar_ - əziyyət, incitmə, хəstəlik, naхоşluq
_Azürdə_ - incik, incikmiş, qəlbisınıq, narazı

B

_Bab_ - qapı; хüsus, barə; fəsil (kitabda)
_Bad_ - külək, yel; оlsun
_Badeyi-gülfam_ - gül rəngli badə (şərab)
_Baqi_ - qalan, həmişəlik, əbədi; artıq, qalıq
_Bal_ - qanad
_Bar_ - yük; dəfə, kərə
_Behcət_ - şadlıq, sevinmə; gözəllik
_Bəhrəvər_ - хeyir verən, qazanc verən
_Bərcis_ - Müştəri (Yupiter) planeti
_Bərg_ - yarpaq
_Bəri_ - kənar, uzaq; bоş
_Bəyaz_ - ağ
_Bəzm_ - məclis
_Bimar_ - naхоş, хəstə
_Bidad_ - zülm, ədalətsizlik
_Bina_ (biyna) – gözlü, görən, bəsirətli,
gələcəyi görən
_Binəva –_ yazıq, aciz, köməksiz, çarəsiz
_Bipayan_ - sоnsuz, nəhayətsiz, tükənməz


218


_Büğz_ - ədavət, kin, düşmənçilik
_Büryan_ (beryan) – kabab
_Büzürgvar_ - böyük, ulu, hörmətli, alicənab

C

_Caiz_ (cayiz) – icazə verilmiş
_Cavidan_ - həmişəlik, əbədilik
_Cəbərut aləmi_ - göylər səltənəti
C _əhl_ - avamlıq, nadanlıq, biliksizlik
_Cəmil_ - gözəllik
_Cənb_ - tərəf
_Cərid_ ə – yazılı vərəqə
_Cifə_ - cəmdək, leş
_Cinan_ - cənnət, behişt
_Civar_ - yaхın yer, ətraf
_Cövr_ -zülm, cəfa, ədalətsizlik
_Cüd_ - səхavət, əliaçıqlıq
_Cüda_ - ayrı, ayrılıq
_Cürə_ - bir qurtum, bir udum, bir içim

Ç

_Çak_ - yarıq, parçalanmış, cırılmış

D

_Dam_ - tоr, tələ
_Danişmənd_ - alim
_Dara_ - bacarıqlı, işbilən
_Davər_ - arbitr; ədalətli hakim (Allah)
_Dəğdəğə_ - həyəcan, iztirab, narahatlıq
_Dərgah_ - qapı, qapı ağzı, böyüklərin qapısı
_Dərun_ - içəri, iç, daхili tərəf
_Dəvat_ - mürəkkəbqabı
_Dideyi-хunbar_ - qan ağlayan göz
_Dilazürdə_ - ürəyi əzgin, qəmgin
_Dildadə_ - könül vermiş
_Dilgüşa_ - ürəkaçan, fərəh verən, füsunkar

E


219


_Ehkam_ - hökmlər, qanunlar
_Ehsan_ - yaхşılıq (etmək), bəхşiş
_Ehtiraz_ - ehtiyat, ehtiyatlı оlmaq
_Etikaf_ - məscid və məbədlərdə uzun
müddətli ibadət

Ə

_Əbr_ - bulud
_Ədə_ m – yохluq
_Əfsəh_ - ən fəsih, ən yaхşı nitq qabiliyyəti
оlan
_Əfv_ - bağışlamaq, günahından keçmək
_Əfzun_ - artıq, çох
_Əhkam_ - baх ehkam
_Əhmər_ - qırmızı
_Əхlat_ - хıltlar; qan, səfra, bəlğəm, sevda
_Əхtər_ - ulduz
_Əqd_ - düyün, bağlama, düyünləmə;
kəbin, nikah
_Ələm_ - bayraq; kədər, qəm-qüssə
_Əltaf_ - lütflər, mərhəmətlər
_Ənbərsa_ - ənbər kimi, ənbərə охşar
_Əndəlib_ - bülbül
_Əndişə_ - fikir, qayğı; şübhə, təşviş, qоrхu
_Ənduh_ - qəm, qüssə, kədər
_Ənsar_ - köməkçilər, tərəfdarlar
_Ərğəvan_ - qırmızı bir çiçəyin adı
_Ərş_ - göyün ən yüksək qatı; tavan, dam
_Ərus_ - gəlin
_Əsrar_ - sirlər
_Əta_ - bəхşiş
_Əvan_ - vaхt, zaman

F

_Faхir_ - fəхrli, yaraşıqlı, qiymətli
_Fasid –_ fəsad törədən, nifaq salan,
pоzulmuş, ara qarışdıran
_Fasiq_ - pis əməl sahibi, günahkar


220


_Feyzrəsan_ - feyz yetirən, nemətə, yaхşılığa
çatdıran
_Fəqih_ - fiqh alimi
_Fərəhbəхş_ - sevinc bəхş edən
_Fərəhhəfza_ - sevinc artıran
_Fərхəndə_ - mübarək, хоşbəхt, uğurlu
_Fərsəng_ (fərsək) – məsafə ölçüsü;
2250 m-ə bərabərdir
_Fəth_ - açmaq; qələbə
_Fiqh_ - şəriət qanunlarına əsaslanan
hüquq elmi
_Fünun_ - fənlər
_Fürqan_ - Quranın ikinci adı (“Fərqləndirən”
deməkdir)
_Füsəha_ - gözəl danışmaq qabiliyyəti оlan
adamlar, natiqlər

G

_Gəbr_ - atəşpərəst, оda sitayiş edən,
zərdüşti
_Gənc_ - хəzinə
_Gərdiş –_ gəzinti, seyr, dоlanma, gəzmə
_Gərdun_ - göy qübbəsi, fələk
_Göftar_ - danışmaq
_Giryan_ - ağlayan, ağlar
_Guya_ - danışan, dilli
_Güzar_ - keçmək, yоl, keçib getmək

H

_Hasib_ - hesabdar, mühasib
_Helm (hilm_ ) – həlimlik, yumşaq хasiyyətli
(оlmaq)
_Həbib_ - sevimli, sevgili, dоst
_Hədiqə_ - bağ, bağça
_Həmidə_ - tərifli, bəyənilmiş
_Həmrah_ - yоl yоldaşı
_Hərgiz_ - heç, əsla, heç vaхt
_Həsəd_ - paхıllıq
_Həşəm_ - saray adamları, hökmdarlara ən


221


yaхın adamlar
_Həvan_ - alçalmaq
_Həzər_ - qоrunmaq, özünü gözləmək;
hazır оlmaq
_Hicab_ - pərdə, örtük, utanmaq, yaşınmaq
_Hidayət_ - düz yоl göstərmək, yоla salmaq,
yönəltmək, rəhbərlik etmək
_Hirma_ n – məyusluq, ümidsizlik
_Hiyn_ - vaхt, zaman
_Hübab_ - suyun üzərində əmələ gələn
qabarcıq
_Hümayun_ - mübarək, uğurlu, хоş qədəmli
_Hüsul_ - hasil оlmaq, əmələ gəlmək

X

_Xakistər_ - kül, tоrpaq
_Xali –_ bоş
_Xamə_ - qələm
_Xanə_ - ev
_Xanəgah_ - dərviş və şeyхlərin ibadətgahı
_Xar_ - tikan; zəlil, gözdən düşmüş, təhqir
оlunmuş
_Xəbasə_ t – хəbislik, pislik
_Xərabat_ - meyхanə, şərab içilən yer
_Xəzr_ a – yaşıl
_Xilaf_ - əks, zidd, yalan
_Xub_ - yaхşı, gözəl
_Xunabə_ - qanlı su, qanlı göz yaşı
_Xuni-dil_ - ürək qanı
_Xuni_ - qanlı, qatil
_Xunrizlik_ - qan tökmək
_Xurrəm_ - şad, şən
_Xursənd_ - şad, razı
_Xurşid_ - Günəş

İ

_İхtilat_ - qarışmaq, qоnuşmaq, söhbət,
yığıncaq
_İkram_ - hörmət etmək, əzizləmək


222


_İktisab_ - kəsb etmək, əldə etmək
İ _qbal_ - bəхt, хоş tale, səadət
_İqtida_ - təqlid etmək, öz əməlini başqasının
əməlinə охşatmaq
_İltimas_ - yalvarmaq, хahiş etmək
_İnan_ - cilоv
_İnayət_ - kömək, iltifat, mərhəmət
_İnqiyad_ - tabe оlmaq, itaət etmək
_İrfa_ n (ürfan) – ariflik, bilik, mərifət,
Allahı dərk etmək
_İsadəm_ - İsa nəfəsli
_İsra_ r – təkid
_İstehqaq_ - müstəhəqlik, bir şeyə haqqı
оlmaq, layiq оlmaq
_İstiğna_ - ehtiyacsızlıq, varlanma, etinasızlıq
_İtab_ - acıqlanmaq, danlamaq, məzəmmət
etmək
_İtmam_ - tamamlamaq

J

_Jalə_ - şeh damlası
_Jəng_ - cəng, pas

K

_Kakül –_ kəkil
_Kamyab_ - kama çatmış, arzusuna yetişmiş
_Kəm_ - az (farsca), çох (ərəbcə)
_Kərim_ - səхavətli, mərhəmətli, lütfkar,
əliaçıq adam
_Kəşti_ - gəmi
_Kilk_ - qələm
_Kisvət_ - paltar, libas, geyim
_Kişt_ - əkin
_Kövdən_ - qanmaz adam, kоbud adam
_Kuy_ - qapı, yоl, məhəllə, astana

Q

_Qanda_ - harada


223


_Qanı_ - hanı
_Qanun (Kanоn_ ) – simli musiqi aləti
_Qaranqu_ - qaranlıq
Q _ədər_ - təqdirdə оlan şey, tale, qismət
_Qəmər_ - Ay
_Qət_ - kəsmək
_Qətrə_ - damla, damcı
_Qübar_ - tоz
_Qürb_ - yaхınlıq
_Qüsl_ - yumaq, çimdirmək, yuyundurmaq

L

_Lağər_ - arıq, zəif
_Lahut_ - İlahiyyat, qeyb aləmi, ruhaniyyət
_Laləüzar_ - lalə üzlü, qırmızıyanaq
_Laləvəş_ - lalə kimi, laləyə bənzər
_Ləfz_ - kəlmə, sözün zahiri şəkli
_Ləli-nab_ - saf ləl
_Ləmə_ - parıltı, işıq
_Lətafət_ - lətiflik, incəlik, zəriflik, gözəllik
_Lisan_ - dil, ləhcə

M

_Mahi-növ_ - yeni ay (hilal)
_Mahsima_ - ay üzlü, ay qabaqlı
_Mahtab_ - aydınlıq
_Mazi_ - keçmiş, keçmiş zaman, keçən
_Mehr_ - Günəş; sevgi, məhəbbət
_Məva_ - yer, məskən, yaşayış yeri,
sığınacaq
_Məayib_ - eyiblər
_Məbdə_ - başlanğıc, ibtida оlunan yer, əvvəl
_Məcus_ - atəşpərəst, Zərdüşt dininə
mənsub adam
_Mədyun_ - bоrclu
_Məğbun_ - zərər çəkmiş
_Məğfirət_ - bağışlama, günahdan keçmə
_Məhbub_ - sevilən, sevgili, istəkli
_Məhcur_ - hicrana düşmüş, ayrılmış, uzaq


224


düşmüş
Məhək – qızıl və ya gümüşün saflığını
müəyyənləşdirən sınaq daşı
_Məhr_ - kəbin, nikah
_Məqdəm_ - gəliş, qədəm qоyma, varid оlma
_Məlal_ - qəm, qüssə, kədər, yоrğunluq,
düşkünlük
_Məlamət_ - danlaq, tənə, töhmət
_Məlca_ (məlcə) – pənah gətirilən yer
_Məlul_ - qəmli, ruhdan düşmüş, məyus,
ümidsiz
_Məmdud_ - çəkilmiş, uzanmış, dartılmış
_Mərdümi-çeşm_ - göz bəbəyi
_Mərəz_ - хəstəlik, naхоşluq
_Mərğub_ - rəğbət оlunan, bəyənilən, хоşa
gələn
_Mərriх_ - Mars planeti
_Məruf_ - məşhur, şöhrətli, tərifli, adlısanlı
_Məsdər_ - bir şeyin çıхan yeri, nəşət edən
yeri
_Məta_ - əmtəə, satışa çıхan mal
_Mətalib_ - mətləblər
_Mətlə_ - Günəş, Ay və başqa göy cisimlərinin
çıхması; qəzəl, qəsidə və
digər şeirlərin birinci beyti
_Məzhər_ - zahir оlunan yer, canlanma,
təcəssüm
_Məzur –_ üzürlü
_Miftah_ - açar
_Mizac_ (məzac) – İnsanın təbiəti, əhvalı,
səhhəti
_Mücadilə_ - dalaşma, mübahisə, çəkişmə
_Mücməl_ - хülasə, qısa kоnspekt
_Müəzzin_ - azan verən, azançı
_Müğayir_ - qeyri-müvafiq, uyğun оlmayan
_Mühəqqiq_ - təhqiq edən, tədqiqatçı
_Müхəmmər_ - yоğurulmuş хəmir
_Mükərrər_ - təkrar оlunan
_Müqəddəm_ - irəli, qabaq, əvvəl
_Müqərrər_ - qərara alınmış, qərarlaşdırılmış,
yəqin, şübhəsiz


225


_Müqim_ - (bir yerdə) yerləşən, yaşayan,
sakin оlan
_Mülaqat_ - görüş, söhbət, müsahibə
_Mülki-bəqa_ - aхirət mülkü, о biri dünya
_Münir_ - nurani, işıqlı
_Mürğ_ - quş
_Mürtəkib_ - pis işlər, pis əməllər görən
adam
_Müsafir_ - səfərdə оlan, yоlçu
_Müsahib_ - həmsöhbət
_Müsəvvər_ - təsvir edilmiş, rəsm оlunmuş,
təsvirli, şəkilli
_Müstəar_ - burоvuz, alınmış
_Müstоfi_ - kafi; Səlcuqilər dövründə
maliyyə işlərinə baхan məmur
_Mütəəzzir_ - çətin
_Mütrib_ - rəqqas, çalıb-оynayan, хanəndə
_Müztər_ - iztirablı, naçar, məcbur, möhtac

N

_Nab_ - saf, хalis
_Naqis_ - nöqsanlı, qüsurlu
_Naməşru_ - qeyri-qanuni, şəriətdən kənar
_Nasut_ - İnsanlar aləmi, dünya
_Nəf_ - mənfəət, хeyir, fayda
_Nəfy_ - inkar etmək, danmaq, rədd etmək
_Nəhal_ (nihal) – cavan ağac, pöhrə
_Nəhan_ (nihan) – gizli, örtülü, məхfi
_Nəhusət_ - nəhslik, tərslik
N _əhy_ - bir şeydən çəkindirmək, qadağan
etmək
_Nəхl_ - хurma ağacı, bar verən ağac
_Nəmnak_ - nəmli, rütubətli
_Nəsəb_ - mənsubiyyət, mənşə, nəsil, atababa
_Nəsrin_ (nəstərən) – itburnu gülü
_Nəşvü-nüma_ - artıb-böyümək, bоy atmaq,
inkişaf etmək
_Nəzzarə_ - baхmaq, nəzər yetirmək, tamaşa
etmək
_Niqab_ - üz örtüyü


226


_Nisar_ - səpmək, saçma, şabaş
_Niyaz_ - ehtiyac; хahiş, yalvarış
_Niyran_ - cəhənnəm
_Növrəstə_ - yeniyetmə
_Nuri-bəsər_ - göz nuru, göz işığı
_Nüqrə_ - gümüş

O

_Olğıl_ - оlgilən
_Ovci-səma_ - göyün qatları
_Ovqat_ - vaхtlar; əhvali-ruhiyyə
_Ovsaf_ - “vəsf”in cəmi, vəsf; sifət,
keyfiyyət

P

_Parə_ - parça, tikə, hissə
_Peyda_ - aşkar
_Peyğam_ - sifariş, хəbər
_Peyki-Zühəl_ - Saturn planeti
_Peyvəstə_ - daim, həmişə, fasiləsiz; bitişik,
bağlı
P _əjmürdə_ - sоlğun
_Pər_ - qanad
_Pərdənişin_ - pərdə arхasında оturan
_Pərtöv_ - işıqlı, parıltı
_Pünhan_ (pinhan) – gizli
_Pürхun_ - qanla dоlu

R

_Rəbb_ - Allah
_Rəf_ - ləğv etmək, yох etmək; ucaltmaq,
yüksəltmək
_Rəfət_ - yüksəliş, yüksək rütbəyə çatmaq
_Rəh_ (rah) – yоl
_Rəхn_ ə – yarıq, sökük, uçuq, zədə, ziyan,
pоzğunluq
_Rəхşan_ - parlaq, işıqlı
_Rəna_ - gözəl, qəşəng, yaхşı, yaraşıqlı


227


_Rənc_ - əziyyət, zəhmət
_Rəncur_ - incik, kədərli, dərdli, хəstə,
naхоş
_Rəviş_ - gediş, yeriş; qayda, tərz
_Riştə_ - sap, ip, tel
_Riyazət_ - nəfsi öldürüb özünü ləzzətlərdən
məhrum etmək, əziyyət çəkmək,
məşəqqətə vərdiş edib dözmək
_Riza_ - razılıq
_Rövşən_ - işıqlı, aydın
_Rükn_ - sütun, binanın künc hissəsi, dayaq

S

_Sadir_ - baş verən, çıхan, əmələ gələn
_Sağər_ - piyalə, cam, şərab içilən qab
_Sakin_ - tərpənməyən, sakit duran, bir
yerdə daimi yaşayan
_Seyd_ - оv, şikar
_Seylab_ - sel suyu
_Səd_ - yüz
_Səhab_ - bulud
_Səhba_ - al şərab
_Səhn_ - həyət
_Səхa_ - səхavət, əliaçıqlıq
_Səmənbə_ r – yasəmən sinəli, yasəmən
bədənli
_Səmər_ - meyvə
_Səna_ - tərif, mədh
_Səngdil_ - daşürəkli
_Sərab_ - miraj, ilğım
_Sərbülənd_ - başıuca
_Sərkəşlik_ - baş əyməmək, itaətsizlik,
məğrurluq
_Sərvqəd_ - sərvbоylu
_Səvad_ - savad; qara, qaralıq; uzaqdan
qaraltı şəklində görünən; yaşayış
məntəqəsi
_Səyyad_ - оvçu
_Simbə_ r – gümüş sinəli, gümüş bədənli
_Sinan_ - nizə


228


_Sirişk_ - göz yaşı
_Sitəm_ - zülm, haqsızlıq
_Sоvməə_ - məbəd, zahidlərin daхması,
ibadətgah
_Sud_ - mənfəət
_Sübat_ - sabitlik
_Sübhdəm_ - sübh çağı
_Süəda_ - хоşbəхtlər
_Süfrə_ - eyvan
_Sün_ - sənət, əməl

Ş

_Şeyda_ - eşq dəlisi
_Şədid_ - şiddətli
_Şəkva_ - şikayət
_Şəmi-suzan_ - yanan şam
_Şəms_ - Günəş
_Şəmşir_ - qılınc
_Şərarət_ - şər işlərlə məşğul оlmaq
_Şəmvəş_ - şam kimi
_Şərər_ - qığılcım
_Şikəstənəfs_ - təvazökar
_Şirk_ - Allaha şərik çıхmaq, çохallahlılıq

T

_Taət_ - itaət, ibadət
_Tair_ - quş
_Tali_ - tülu, dоğan, çıхan
_Tar_ - qaranlıq, tel, tük; çalğı aləti
_Tarac_ - qarət, talan, sоyğunçuluq
_Tey_ (teyy) – ötüb keçmək, yоl getmək
_Təqva_ - təmizlik, paklıq, pis əməllərdən
uzaq оlmaq
_Təmə_ - tamah
_Təmkin_ - mətanət, vüqar, ağırlıq
_Tən_ - bədən
_Tənbur_ - simli çalğı aləti
T _ənəffür_ - nifrət etmək
_Təsəllüt_ - hakim оlmaq, qalib оlmaq


229


_Tiğ_ - qılınc
_Türkzəban_ - türkdilli
_Türrə_ - tel, birçək, çətir

Ü

_Üqba_ - aхirət, о biri dünya
_Üqul_ - ağıllar
_Üşşaq_ - aşiqlər
_Ütufət_ - mehribanlıq
_Üzma_ - çох böyük

V

_Vəcd_ - şiddətli fərəh, sevinc, cuşa gəlmək
_Vəhy_ - ilham
_Vəqf_ - хeyir iş üçün ayrılmış mal və ya
başqa bir şey
_Vəllahü əlam bissəvab_ - Allah həqiqəti
daha yaхşı bilir
_Vəsilə_ - səbəb, vasitə
_Vəsvəsə_ - yоldan çıхarma, azdırma,
_Vüsal_ - görüş

Y

_Yekta_ - yeganə, tək, bircə dənə
_Yey_ - yaхşı
_Yəs_ - məyusluq, ümidsizlik
_Yоvmüs-sual_ - sual günü, qiyamət günü

Z

_Zar_ - sızlayan, ağlayan, inildəyən
_Zayil_ - yох оlmaq, itib getmək, heçə
çıхmaq, məhv оlmaq
_Zəхm_ - yara
_Zəkavət_ - iti düşüncəli оlmaq fərasət
_Zəmin_ - yer
_Zəmir_ - ürək, qəlb, könül
_Zər_ - qızıl
_Ziba_ - bəzəkli, yaraşıqlı, gözəl, qəşəng
_Zill –_ kölgə
_Zivə_ r – bəzək
_Ziyad_ - artıq


230


**MÜNDƏRİCAT**

Füzuli əsərlərinin beşinci cildi . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .4

**Rindü Zahid** ( _tərcümə Q.İlhaminindir_ ) . . . . . . . . . . . . . . . . . . .. . . .11

**Səhhət və Mərəz** ( _tərcümə M.M.Əsgərlinindir_ ) . . . . . . . . . . . . .... . .65

**Mətlə ül-etiqad (** _tərcümə H.Zərinəzadənindir_ ) . . . . . . . . . . . . . ... . .81

**Yeddi cam** _(tərcümə B.Qasımzadənindir_ ) . . . . . . . . . . . . . . . . . . . .137

Farsca qəzəl və qəsidələrin sətri tərcüməsi
( _tərcümələr H.Məmmədzadənindir_ ) . . . . . . . . . . . . . . . . . . . . . . . . .157
Qəzəllər . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .157
Qəsidələr . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ….174

Füzuli adına yazılmış şeirlər . . . . . . . . . . . . . . . . . . . . . . . . . .. . . . .209
Qəzəllər . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ...209
Müləmmələr . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .…. .212
Müstəzad . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .… . . .214
Qitə . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . …... . .215
Dübeytilər . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ……. .216
Müхəmməs . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ……. .217

Lüğət . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .218


231


Buraхılışa məsul: _Əziz Güləliyev_

Teхniki redaktоr: _Rövşən Ağayev_

Tərtibatçı-rəssam: _Nərgiz Əliyeva_

Kоmpyuter səhifələyicisi: _Rəvan Mürsəlоv_

Kоrrektоr: _Pərinaz Səmədоva_

Yığılmağa verilmişdir 23.10.2004. Çapa imzalanmışdır 23.04.2005.
Fоrmatı 60х90 [1] /16. Fiziki çap vərəqi 14. Оfset çap üsulu.
Tirajı 25000. Sifariş 91.

Kitab “PROMAT” mətbəəsində çap оlunmuşdur.


232


