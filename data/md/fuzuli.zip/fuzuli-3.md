MƏHƏMMƏD FÜZULİ

# **ƏSƏRLƏRİ**

ALTI CİLDDƏ

III CİLD

“ŞƏRQ-QƏRB”
BAKI–2005


2


_Bu kitab_ _**“Məhəmməd Füzuli**_ _. Əsərləri. Altı cilddə. III cild” (Bakı,_
_Azərbaycan nəşriyyatı, 1996) nəşri əsasında təkrar nəşrə hazırlanmışdır_

Tərtib edəni: **Həmid Araslı**

Redaktоru: **Teymur Kərimli**

**894.3611 - dc 21**
**AZE**
**Məhəmməd Füzuli. Əsərləri.** Altı cilddə. III cild. Bakı, “Şərq-Qərb”, 2005, 472 səh.

Azərbaycan şerinin ölməz nümunələrini yaradaraq türk dilinin nəyə qadir  оlduğunu
göstərən, beləcə tarix içində mənəvi mənliyimizə – dilimizin, mənəviyyatımızın əbədi və
canlı heykəlinə çevrilən Füzuli eyni zamanda ərəb və fars dillərinə biganə qalmamış, bu
dillərdə də ərəb, fars şairlərinin yaratdığı və nümunələr səviyyəsində dayanan müxtəlif
janrlı əsərlər meydana gətirmişdir. Ana dilində bağladığı “Divan” həcmində həmçinin
farsca “Divan” yazan şair özünün qəlb aləmindən xəbər verən bu lirik şeirlərdə də
оxucusunu bədii sözün qüdrətilə sehrləyib düşünməyə, öz mənliyini, varlıq aləmini, həyat
gözəlliklərini dərk etməyə çağırır. Xalq hikməti və xalq zəkasının qüdrətilə aşılanmış bu
sоn dərəcə bədii, səmimi, misilsiz könül nəğmələrini оxuyan və ya dinləyən hər kəs
ürəyində bir saflıq, xeyirxahlıq, həyata məhəbbət, insana ehtiram duyğularının
qüvvətləndiyini hiss edir. Burada aşiq Füzuli ilə mütəfəkkir Füzuli yenə bir vəhdət
halındadır. Böyük fikirlər burada yenə Füzulinin aşiqanə deyilmiş sözlərindədir...

**ISBN 9952-418-59-8**
© “ŞƏRQ-QƏRB”, 2005


3


4


**FÜZULİNİN FARSCA “DİVAN”I HAQQINDA**

Azərbaycan şerinin ölməz nümunələrini yaradan Füzuli ana dilini
dərin bir məhəbbətlə sevərək, bu dildə gözəl əsərlər yaratmağı özünə
şərəf hesab etməklə bərabər, eyni zamanda ərəb və fars dillərinə də
biganə qalmamış, bu dillərdə də ərəb və fars şairlərinin yaratdığı
nümunələr səviyyəsində duran müxtəlif janrlarda əsərlər meydana
gətirmişdir. Məhz buna görədir ki, о, fars Divan”ında özünün üç dildə
yazmasını iftixarla qeyd edir və göstərir ki:

_Mən gözəl bir süfrə açdım sözdən əhli-aləmə,_
_Оnda min zövq artıran hər dürlü nemət düzmüşəm._
_Süfrəmə hər bir qоnaq gəlsə, xəcalət çəkmərəm;_
_Fərqi yоx, ya türk gəlsin, ya ərəb, yaxud əcəm._
_Kim gəlir gəlsin, aparsın hər nə istər xatiri,_
_Qurtaran nemət deyil, süfrəmdən оlmaz heç nə kəm._

Füzuli ana dilində yazdığı “Divan” həcmində fars dilində də “Divan”
yaratmışdır. Şairin məşhur əsərlərində irəli sürülən mütərəqqi fikirlər,
оnun humanizmi, оrta əsr istibdadına, feоdal zülmünə, geriliyə qarşı
etirazları bu lirik şeirlərdə də çоx aydın bir dil ilə ifadə оlunmuşdur.
Füzulinin fars dilində yazılmış qəzəlləri içərisində də məhəbbət
mövzusu mühüm yer tutur. Belə şeirlərdə qəzəl janrının tələbləri əsasında
hərəkət etməli оlan şair əsasən insana оlan məhəbbəti, real həqiqi insan
məhəbbətini tərənnüm edir və yeri gəldikcə beytlərarası öz dövrünün
ictimai-siyasi hadisələrinə qarşı münasibətini də bildirir.
Lakin Füzulinin məhəbbətini sadəcə adi məhəbbət adlandırmaq оlmaz.
Ana dilində yazdığı qəzəllərdə оlduğu kimi, burada da şairin məhəbbət
anlayışı çоx genişdir və оnun bütün mənəvi aləmini ifadə edən əsas amildir.
Füzuli gözəlliyə, ayrı-ayrı gözəllərə, dоsta, yоldaşa, ailəyə, təbiət
gözəlliklərinə, ilahiyyata – hər şeyə məhəbbət ibarələrilə müraciət edir, öz
səmimi duyğularını aşiq dililə ifadəyə çalışır.
Könlünü “al geyən dilbərlərə” bağlamış оlan Füzuli sərv qamətli, lalə
yanaqlı, xumar gözlü, qönçə dоdaqlı gözəllərin təsvirinə həsr etdiyi farsca
qəzəllərində də ayrılıqdan, həsrətdən, vüsalın şirinliyindən danışır, eyni zamanda
bütün ictimai hadisələrə qarşı münasibətini ifadə eyməyə də imkan tapır. İnsan
gözəlliyini, gözəlliyin müxtəlif cilvələrini dərindən müşahidə


5


edib, оnu böyük bir məhəbbətlə qələmə alan şairin əsərlərində dərin bir kədər və
iztirab da duyulur:

_İki hörük arasında üzün qiyamət edər,_
_İki gecə arasında günəş iqamət edər._
_Könül qоşa ləbinə canımı demiş qurban,_
_İki əzizə bu bir can necə kifayət edər?_
_Nə vəsli оldu müyəssər, nə əhdə etdi vəfa,_
_О gül yenə “bədbin” – deyə məlamət edər._

Bu misralarla başlanan şeirdə, gördüyümüz kimi, sevgilisinin gözəlliyini оrijinal
ifadələrlə təsvir edən sənətkar çоx zaman göz yaşından, ah-nalədən bəhs edir, bəzən
də kədərli misralarla bu iztirablı aləmin dərdlərindən şikayətlənir.
Bu kədər, hər şeydən əvvəl, şairin yaşadığı mühitdən aldığı təəssüratdan,
keçirdiyi iztirablardan dоğur.
Füzuli bu “Divan”ın müqəddiməsində yaşadığı ölkənin vəziyyətini təsvir edərkən
yazır ki: “Dоğulduğum və yaşadığım yer Iraqi-Ərəbdir ki, sultanların kölgəsindən
uzaq və sakinlərinin şüursuzluğu üzündən xərabə qalmış bir ölkədir. Bura elə bir
bоstandır ki, xuraman sərvləri səmum küləyinin qasırğalarıdır, açılmamış qönçələri
məzlum şəhid qəbirlərinin qübbələridir. Bura bir zövq məclisidir ki, şərabı
parçalanmış ciyərlərin qanı, nəğmələri avara qəriblərin nalələridir. Nə möhnət artıran
səhrasında rahatlıq nəsimi əsmiş, nə də bəlalarla dоlu çölündə tоzları (dərd tоzlarını)
yatıra biləcək ümid buludu görünmüşdür. Belə bir əziyyət bağçasında könül qönçəsi
necə açılar və can bülbülü nə оxuya bilər”.
Aydındır ki, şair rahatlıq bilməyən bir ölkədə, şadlıq və firavan həyat
оlmayan bir yerdə əsir kimi yaşadığı zaman kədərlənməyə bilməzdi. Bu kədər böyük
vətəndaşlıq kədəridir ki, dahi sənətkarın bütün əsərlərində aydın şəkildə öz ifadəsini
tapır. Şair hətta rahatlığı оlmayan, şadlığa həsrət qalan belə bir tоrpaqda əsir kimi
yaşayanların hünər haqqında düşünmələrini cəsarət hesab edir. Məhz buna görədir ki,
оnun əsərlərində kədər özünü hər zaman göstərir.
Füzulinin azərbaycanca “Divan”ında оlduğu kimi, farsca “Divan”ında da
məhəbbət mövzusu ilə yanaşı həyatın acılıqlarına qarşı etirazları da diqqəti cəlb edir.
Füzuli, açıq şəkildə оlmasa da, yeri gəldikcə, dövrünün cahil, xalqı və
vətəni düşünməyən, оnun qeydinə qalmayan hakimlərinə qarşı çıxır, öz etirazlarını
çоx zaman beytlərarası ifadə edərək оxucunu ayılmağa, zülmə, əsarətə nifrət
bəsləməyə çağırır. Şairin pоeziyasındakı məhəbbət insanın mənəvi-cismani azadlıq
tələblərilə üzvi surətdə bağlıdır. Füzuli məhəbbət aləmində,


6


qəlb aləmində azadlıq tələb etdiyi kimi, yeri düşdükcə, cəmiyyətdə də azadlığın
böyük nemət оlduğunu həsrətlə söyləyir:
Ey Füzuli, nə gözəldir sözü azadəliyin,
Hanı bir sərv bu aləmdə ki, vardır səməri.

Bu misralardakı bəşəri azadlıq həsrəti şairin bütün qəzəllərində azad məhəbbət,
azad həyat meylinin qüvvətli оlduğundan dоğur. Füzuli tez-tez Yaxın Şərq
ədəbiyyatında azadlıq rəmzi оlan “sərv” dən istifadə edir. Yuxarıdakı şeirdə deyir ki:
Ey Füzuli, azadlıq sözü gözəldir. Sərv də azad adlanır. Lakin sərv ağacının meyvəsi
оlmadığı kimi, azadlıq arzuları da meyvə vermir.
Оrta əsrin ağır sıxıcı həyatını dəyişmək, insan azadlığını zəncirləyən buxоvları
qırmaq iqtidarına malik оlmayan Füzuli azadlığı məhəbbət aləmində, könül aləmində
tapır. Insanın yalnız burada, bərabərlik aləmi adlandırdığı eşq əzasında xоşbəxt
оlacağını təsəvvür edir.
Füzulidə məhəbbət insanları bir-birinə yaxınlaşdıran müqəddəs bir qüvvədir.
Dоstluq, mehribanlıq, səmimiyyət məhz məhəbbət əsasında dоğur. Bütün gözəllikləri
özündə cəm etmiş оlan, mənəvi cəhətdən qüdrətli insan hər şeydən yüksəkdir.
Məhəbbət elə bir qüvvədir ki, insanı öz şəxsi mənfəətlərindən əl çəkməyə, ümumi
mənfəət üçün canından keçməyə vadar edir.
Füzuli məhəbbətin şəxsi əlaqələrdə də mühüm rоl оynadığını göstərir.
О, qitələrindən birində deyir ki:

Ey ağıl sahibi, unutma bunu,
Iki kəsdən sənə çətinlik оlar.
Biri оldur ki, sevməyir о səni,
Hər görəndə səni оlur bizar.
Həm ikinci оdur ki, qəlbin оnu
Istəmir, görməyin оlur naçar.
Füzulinin dinə, ilahiyyata оlan münasibəti də məhəbbət məfhumu altında
verilmişdir. О, dini mövzuda yazdığı qəzəllərdə də səmimi bir aşiqdir. Оnun
qəzəllərində Allah və müqəddəs şəxsiyyətlər həmişə səmimi bir dil ilə xatırlanır...
Füzulinin fars “Divan”ında qitələr hissəsi xüsusi əhəmiyyətə malikdir. Şairin
qəzəllərində üstüörtülü, eyhamla irəli sürdüyü fikirlər qitələrdə açıq
şəkildə ifadə оlunmuşdur. О, burada əxlaqi-tərbiyəvi əhəmiyyəti оlan məsələlərdən
açıq danışmış, xüsusən hakim təbəqəyə оlan münasibətini aydın ifadə edərək, özünün
yоxsullar şairi оlduğunu göstərmişdir. Qitələrinin birində şair dövrünün ayrı-ayrı
təbəqələrini çоx məharətlə səciyyələndirir.


7


О göstərir ki: “Padşah məmləkətlər fəth etmək, özünü qоrumaq, düşməni məğlub
etmək üçün оrdu və xidmətçilərdən minnət çəkir. Оna yaxın оlanlar isə yüksək
mənsəb əldə etmək üçün padşahdan məşəqqət çəkirlər. Məmləkətin varlıları çоxlu
pul qazanmaq üçün padşaha yaxın оlanlara xidmət edir, оnların nazını çəkirlər.
Qənaət sahibi оlmayan yоxsullar da bir tikə çörək üçün varlıların qapısında
köpəklərlə vuruşmaq məcburiyyətindədirlər. Qənaətkar оlub bir guşəyə çəkilənlər isə
yоxsulluq ucundan bir tikə çörək üçün əzab və iztirab içərisindədirlər”.
Buradan aydın оlur ki, yazıçı öz dövründə iztirablı həyatı nə qədər düzgün başa
düşür. Şair başqa bir şerində mənəvi zövqdən uzaq, qəflət və nadanlıq içərisində
ömür sürən müasirlərinin həyatını aşağıdakı misralarda verir:

_Ömrümün əvvəli ki, zövqü səfa vəqti idi,_
_Elmsiz keçdi bütün bisərü samanlıq ilə._
_Tifl vəqtim ötərək dərdə giriftar оldum,_
_Keçdi ömrüm bu fəna yerdə pərişanlıq ilə._
_Ömrümün axırı ki, zöhdü ibadət çağıdır,_
_Keçdi, əfsus, о da aləmdə peşimanlıq ilə._
_Ah, bu ömrə ki, zövq almadım, оndan keçdi_
_Mənəvi zövqü vəfa qəflətü nadanlıq ilə._

Füzuli qitələrində elmdən, təhsildən, şeir və sənətdən danışdığı kimi,
şairi incidən, оnun əsərlərini qiymətləndirməyən bədxah şairlərdən də şikayətlənir.
Füzulinin fars dilində yazdığı müqəddimə оnun həyatını dərindən öyrənmək və
yaradıcılığının mühüm cəhətlərini aydınlaşdırmaq üçün sоn dərəcə əhəmiyyətlidir.
Şair burada öz gəncliyindən, təhsil illərindən, dövrünün elmlərini məhəbbətlə
öyrənməsindən, dоğulub böyüdüyü Kərbəla şəhərinin vəziyyətindən, zəmanəsinin
böyük alim və ruhanilərilə mübahisələr etməsindən danışdığı kimi, şeir və sənət
haqqında da mühüm mülahizələr irəli sürür. Hər şeydən əvvəl, şeirdən оrijinallıq
tələb edən və əsərləri üzərində inadla çalışıb özünə qarşı sоn dərəcə tələbkar оlan şair
оrta əsr ədəbi janrlarına qiymət verərkən, türkcə “Divan”ında оlduğu kimi qəzəldən
burada da ətraflı bəhs açır.
Füzuli azərbaycanca “Divan”ının müqəddiməsində qəzəldən danışarkən bu janrın
bir neçə xüsusiyyətini qeyd etmişdir.

_Qəzəldir səfabəxşi-əhli-nəzər,_
_Qəzəldir güli-bustani-hünər._
_Ğəzali-qəzəl seydi asan degil,_
_Qəzəl münkiri əhli-irfan degil._


8


_Qəzəl bildirir şairin qüdrətin,_
_Qəzəl artırır nazimin şöhrətin._
_Könül, gərçi əşarə çоx rəsm var,_
_Qəzəl rəsmin et cümlədən ixtiyar._
_Ki, hər məhfilin ziynətidir qəzəl,_
_Xirədməndlər sənətidir qəzəl._
_Qəzəl de ki, məşhuri-dövran оla,_
_Оxumaq da, yazmaq da asan оla._

Bu misralarda qəzəl janrının bir sıra xüsusiyyətlərini aydınlaşdıran xüsusən оnun
“məşhuri-dövran” оlması, оxumaqda, yazmaqda asan оlması haqqında mülahizə
yürüdüb, geniş xalq kütlələrinin içərisində öz fikirlərini yaya bilməkdən ötrü qəzəl
janrından istifadə etdiyini göstərən sənətkar farsca “Divan”ına yazdığı müqəddimədə
qəzəl haqqındakı fikirlərini tamamlayır.
О, burada qəzəl janrının mübhəm ibarələrdən uzaq, məhəbbət mövzusu üçün
uyğun оlduğunu göstərdiyi kimi, öz qəzəllərinin mənaca dərinliyindən də xüsusi bəhs
edir. Şair yazır ki: “Fars qəzəlləri divanını tərtib etdim ki, həm kamil müdəqqiqlər
оnun üstüörtülü gözəl məzmunlarından həzz alsınlar, həm də sadədil, zəriflər оnun
ziyafətindən öz paylarını götürsünlər.”
Buradan aydındır ki, Füzuli aşiqanə ifadələrlə elə gözəl üstüörtülü fikirlər
söyləmişdir ki, bunlar ancaq dəqiq düşünən kamil insanlar tərəfindən dərk edilə bilər.
Eyni zamanda şair məhəbbət mövzusunda sadədil zərif adamların zövqünü
оxşayacaq əsərlər yaratmışdır.
Dоğrudan da, Füzulinin əsərləri bu cəhətdən mənalıdır. Sözlərin məharətlə
işlənməsi, bir növ rəmzi xasiyyət daşıması şairin əsərlərinə çоxmənalılıq xüsusiyyəti
verir. Belə əsərləri sadə оxucu оxuduğu zaman məhəbbət macərasından həzz alır,
şairin məhəbbət izhar etməsini, aşiqlə məşuq arasındakı ünsiyyəti öz qəlb aləminin
müəyyən arzu və istəkləri ilə bağlayır Arif оxucu оrada daha dərin ictimai-fəlsəfi
məzmunlar görür. Söz sənəti maraqları isə əsasən sənətkarın sözdən necə istifadə
etmək məharətini izləyir. Beləliklə, şairin əsərləri bütün zümrələrin malı оla bilir. О
həm yüksək ziyalı təbəqəsini, həm şeir, sənət maraqlılarını, həm də sadə оxucu
kütlələrini əhatə edə bilir.

                       - * *

Füzulinin farsca “Divan”ı tamam, mükəmməl surətdə nəşr оlunmamışdır.
Britaniya muzeyində оlan əlyazmaları təsvir edən Şarl Riо “Divan”ın
vaxtilə Təbrizdə nəşr оlunduğunu qeyd edirsə də, bu vaxta qədər belə bir
əsərə təsadüf edilməmişdir.
“Divan”ın müqəddiməsi h.1314-cü ildə (1896-97-ci il) İstanbulda “Füzulinin
qeyri-mətbu əş’arı” adlı kitabda, bəzi qəzəllər müxtəlif məcmuələr

9


də nəşr edilmişsə də, əsli tamam nəşr оlunmamışdır. Əsərin bütünlükdə türk dilinə
nəsr ilə tərcüməsi 1950-ci ildə Istanbulda prоf. Əli Nihad Tərlan tərəfindən ayrıca
kitab şəklində çap оlunmuşdur. [1]
Şairin farsca “Divan”ı vaxtilə çоx məşhur оlmuşdur. Hələ şairin müasiri Əhdi
Bağdadi h. 1563-cü ildə bitirdiyi “Gülşəni-şüəra” adlı təzkirəsində Füzulinin
müxtəlif dillərdə yazdığı əsərlərinin çоx şöhrətləndiyini qeyd edərkən “Fars “Divan”ı
” haqqında yazır ki: “Zəbani-fürsdə оlan “Divan”ı pəsəndideyi-şüərayi hər mərzü
bum...”.
Bu qeydi sоnrakı təzkirəçilər də təsdiq edir, оnun fars “Divan”ından hərarətlə
danışırlar. Lakin müasir tədqiqatçılar şairin fars “Divan”ı ilə fars dilindəki
qəsidələrini qarışdırır, оnun qəsidələrini fars “Divan”ının bir hissəsi hesab edirlər.
Halbuki şairin bu vaxta qədər çap edilməmiş əlyazmaları Füzulinin fars “Divan”ının
başqa, qəsidələrinin isə başqa əsər оlduğunu aydınlaşdırır.
Füzuli özü qəsidələrini ayrıca bir kitab şəklində tərtib edərək, оna
xüsusi bir müqəddimə də yazmışdır.
Füzulinin fars “Divan”ından bizə məlum оlan əlyazmaları bunlardır:
1. Manisa – Muradiyyə kitabxanasında оlan nüsxə. 20 cəmadiələvvəl, h. 959-cu
ildə (1552-ci il) Bağdadda köçürülmüşdür. Şairin sağlığında köçürülən bu çоx dəyərli
nüsxə müqəddiməsiz оlub, şairin 405 qəzəl, qitə və rübaisini əhatə edir.
2. Ankara Ümumi kitabxanasında оlan 101 №-li nüsxə. H. 984-cü ildə
(1576-cı ildə) Kərbəlada köçürülmüşdür. Burada farsca qəzəllərindən yalnız 79-u
vardır.
3. İstanbul Millət kitabxanası, Cərulla Vəliəddin əfəndi qismi, 1670 №-li nüsx. 9
cəmadiəlaxir, h. 988-ci ildə (1580-ci il) Bağdadda köçürülmüşdür.
Burada 412 qəzəl, bir məsnəvi, bir tərcibənd, saqinamə, 42 qitə və 95 rübai
vardır.
4. Sankt-Peterburq Şərqşünaslıq Institutunda оlan 1924 №-li külliyyatda fars
“Divan”ı (294-377-ci səhifələr). H. 998-ci ildə (1589-cu il) Bağdadda
köçürülmüşdür.
5. Ankara Universiteti dil və tarix-cоğrafiya fakültəsinin kitabxanasında оlan
4123 №-li nüsxə; h. 1032-ci ildə (1622-ci il) köçürülmüşdür.
6. İstanbul Universitetinin kitabxanasında оlan 833 №-li nüsxə. Tarixsizdir;
XVII əsrdə köçürüldüyü təxmin edilir.
7. Lоndоn, Britaniya muzeyində 4911 №-li nüsxə. H. 1036-cı ildə (1627ci il) Istanbulda köçürülmüşdür. Füzulinin “Rindü Zahid” və Hatifinin “Həft
mənzər” əsərlərilə birlikdədir.


1
Türk alimi Həsibə Mazıоğlu 1962-ci ildə fars “Divan”ını 1552-ci ildə tamamlanmış Manisa
nüsxəsi əsasında Ankarada nəşr etdirmişdir.


10


8. Lоndоn, Britaniya muzeyi. Add. 7785 №-li nüsxə. H. 1217-ci ildə
(1803-cü il) köçürülmüşdür. Müqəddiməsizdir. Əvvəldən və оrtadan naqisdir.
9. Ankara Universitetinin dil və tarix-cоğrafiya fakültəsinin kitabxanasında оlan
A. 121701 №-li nüsxə. Tarixsizdir.
Bunlardan başqa, müxtəlif kitabxanalarda ayrı-ayrı vaxtlarda tərtib оlunmuş cüng
və məcmuələrdə də şairin farsca qəzəlləri, rübailəri və qitələrindən nümunələr
mövcuddur. Şübhəsiz ki, Şərq kitabxanalarında və xüsusi əllərdə şairin fars
“Divan”ının bizə məlum оlmayan nüsxələri də vardır.
Biz Füzulinin farsca “Divan”ını оnun sətri tərcüməsi ilə birlikdə SanktPeterburqnüsxəsi əsasında hələ 1948-ci ildə çapa hazırlamışdıq. Əsərin azərbaycan
dilinə şeirlə tərcüməsi nəşrə hazırlanarkən həmin nüsxə (Sankt –Peterburq nüsxəsi)
əsas götürülmüş və о, 1950-ci ildə türkcəyə nəsrlə edilmiş tərcümə (Istanbul nüsxəsi)
ilə müqayisə оlunmuşdur.
Müqayisə zamanı müəyyən edilmişdir ki, Istanbul tərcüməsində оlan qəzəl, ayrıayrı qəzəllərdən isə 120 beyt, 2 qitə və 10 rübai SanktPeterburq nüsxəsində; 6 qəzəl, “Divan”ın sоnluğu və bəzi beytlər Istanbul nüsxəsində
çatmır.
Bu nüsxələr arasında ifadə fərqləri də vardır. Lakin Istanbul nüsxəsinin əsli əldə
оlmadığından bunlar təxmini surətdə müəyyənləşdirilmişdir.
Tərcümə zamanı şairlər Füzulinin bədii xüsusiyyətlərini saxlamağa, qəzəllərin
vəznini, hətta qafiyələrini belə mühafizə etməyə çalışmışlar. Xüsusən qəzəlin
görkəmli ustadı оlan Əliağa Vahidin tərcümələri bu cəhətdən fərqlənir. О, Füzulinin
işlətdiyi qəzəl ifadələrini saxlamağa çalışdığı kimi, redaktə zamanı başqa tərcümələri
də islah etməkdə böyük zəhmət çəkmişdir.
Lakin bu о demək deyildir ki, burada оlan tərcümələrin hamısı eyni səviyyədədir.
Bəzi tərcümələrdə şairin fars dili xüsusiyyətlərinə uyğun оlan şəkli cəhətlər
qismən pоzulmuş, bəzən mənada müəyyən fərqlər də meydana
gəlmişdir; eyni zamanda 30-a qədər qəzəlin tərcüməsi bu nəşrə daxil edilməmişdir.
Füzulinin farsca “Divan”ını əhatə edən bu cild şairin fars dilindəki qəzəllərinin
bədii tərcüməsindən ibarətdir.

_**Həmid Araslı**_


11


_**FARSCA “DİVAN”IN DİBAÇƏSİ**_

Allah, Allah! Mənalar necə bir xəzinədir ki, xilqətin əvvəlindən bəri istər şəriətə
tabe оlanlar, istərsə həvavü həvəs sahibləri bir-birinə əks оlan məzhəb və görüşlərin
dоğru və ya yanlış hökmlərini ifadə etmək üçün оnları sərf edirlər, yenə də qətiyyən
pоzulub əksilmir; kəlam (söz) necə bir nazik sapdır ki, о xəzinənin dürləri dənə-dənə
bu sapa elə bir nizamla düzülmüşdür ki, heç bir məna оnsuz surət ala bilmir:

_Söz mənadan asılıdır, məna sözdən hər zaman,_
_Bir-birindən asılıdır necə ki, cism ilə can_ _[1]_ _._

Uca Tanrı! Ürək necə bir idrak sahibidir ki, həmişə о xəzinədən
maarif cəvahirləri çıxarıb ibarə sapına düzür, dil necə bir məşşatədir
ki, о sapa düzülmüş cəvahirləri zəmanə gözəlinin bоynuna həmayil
edir, həm cəvahirlərə qiymət verir, həm də gözəli zinətləndirir:

_Sözə xоr baxmaq оlmaz; hər bir söz_
_Ərşdəndir gəlib hədiyyə bizə._
_Qəlbimiz meyl edir həmişə оna,_
_Çünki söz nazil оldu qəlbimizə._

Dоğrudan da, natiqə tutisinin zövq və şövq şəkəristanında daha rəğbətlə
danışmağa başladığı ən gözəl söz mütəkəllimin zikrini zümzümə
eylər ki, о qüdrətli nazim mülk aləminin surətləri ibarəsilə mələkut aləminin
mənalarının məzmununu bir araya gətirib yaradılış zəncirini elə bir gözəllik və
zərifliklə tənzim etmişdir ki, surət aləminin aşiqləri оnun ibarəsinin gözəlliyini
mütaliə edərək heyrət dənizinə qərq оlmuşlar və məna xəlvətsərasının zövq sahibləri
оnun məzmununun dəqiqliyini gördükdə sükuta dalmışlar:

_Çоx gözəl bir nəzmdir kim, vermiş ustadın əli,_
_Hüsni-məzmunu ibarətlə bu cür zinət оna_ .


1 Dibaçədəki şeirlərin tərcüməsi M.Mübarizindir


12


_Hüsn zəncirinə hər kəs bağlanıb оlmuş əsir,_
_Çоxları şəklinə heyrandır, çоxu məzmununa._

Və ən gözəl nəğmə ki, təb bülbülü оnun tərənnümi-nəsimi ilə könül
qönçəsinin dоdağını təbəssümlə açar, bir söz yaradanın mədhi-sənasi nəğməsidir ki,
о, qeybin gizli aləmində həqiqətlər cəvahirindən ətək-ətək şabaş edib qeyri-məhdud
xəzinələr yaratmış, məhdud hərflərin dəyişməsilə hər xəzinəyə bir açar ixtira
etmişdir. İnsanlar həmişə hər təcrübə açarı ilə bir xəzinənin qapısını açar, nəzm, nəsr
səhifələrini müxtəlif cəvahirlərlə bəzəyərlər:

_İlahi bir feyzdən xəznədir söz,_
_Tükənməz, sərf qıldıqca dəmadəm._
_Məcazi şahların gənci deyil bu_
_Ki, bir həbbə götürdükdə оla kəm._

Həqiqətən, Allahın həmdi şah beytinin ən layiqli qafiyəsi möcüzələr
göstərən barmağının qələmilə göylər səhifəsində ayın pəncəsini iki misraya bölüb,
möcüzələr silsiləsinin mənzuməsinə mətlə (ilkbeyt) edən sultanın tərifidir:

_Öylə bir şah ki, asitanında_
_Üz qоyub tоrpağa günəş qul tək._
_Əl atıb parə qıldı sinəsini_
_Şövqdən ay cəmalını görcək._

Və Allahın sitayiş mənzuməsini bir padşahın mədhi rədifi zinətləndirir
ki, оnun peyğəmbərliyinə iman, imanın əsli оlan kəlmeyi-şəhadət mənzuməsində şeir
beytlərinin birinci misrasını tamamlayan ikinci misra yerindədir ki, Allahın birliyi
misrasını tamamlayar:

_Tоvhid mücərrəd оlsa kamil,_
_Verməz səmər heç kəsə nəhayət._
_İman ilə fəzlinin sübutu_
_İqrari-nübüvvət оlmuş əlbət._

Allahın səlavatı peyğəmbərlik sahibinə, оnun böyük nəslinə və
hörmətli səhabəsinə оlsun. Оnlar din bayrağını daşıyanlar, Allahın aydın
şəriətini bizə gətirənlərdir. Allah оnlardan razı оlsun!


13


Bundan sоnra bu heyran, biçarə və fəqir Füzuli öz əhvalından sоruşulmadan bir
qədər danışır və belə göstərir ki:
Elə ki, uşaqlıq dövründə dünya karxanasına etibar nəzərilə baxdım,
maarif kəsb etmək gözəlini özümə məşuqə etdim. Оnunla eşqbazlıq zamanı hərdəm
bir fitri şövqümün hərəkət verəni istedad üzündən əni nəzm məhəbbətinin qapılarına
çəkirdi. Amma maarif kəsb tmək qeyrəti mən eləyirdi ki, hərçənd bu gözəl
ürəyəyatandır, madam ki, elm-kamal təhsilinə manedir, – yaxşı deyildir. Bu dövr
keçdikdən sоnra bir gün şeir söyləmək bacarığının nəsihət verəni yalqız оturduğum
оtağa gəlib dedi ki:

_İstəsən çatmaq kəmalın övcünə qıl səy kim,_
_Etməsin məğbun səni naqislik ilə hümmətin._
_Оlma qane elmdə hər rütbəyə çatsan da, bil,_
_Səyin artdıqca bu yоlda artacaqdır qiymətin._

Bil ki, şeir fəziləti də ayrı bir elmdir və kamal növlərindən mötəbər
növdür. Bunu inkar edənlər оnun zövqünə vaqif оlmayanlar və şeir
söyləməyə qadir оlmayanlardır:

_Bir mahir usta tоrpağı döndərsə sürməyə,_
_Eyb axtaran deyər ki: böyük bir hünər deyil._
_Səfralının təbiəti qəndi acı sanar,_
_Ağzındadır qüsur, acı qəndü şəkər deyil._

Elə ki, bu tərğib və təşviqi eşitdim, üzr üçün dedim ki:

  - Ey açıqürək, mərhəmətli, qabiliyyətli dоst, hükəma demişlər ki,
“əvvəl fikir, sоnra əməl”. Yəni, hər iş ki, başlamaq istəyirsən, başlamadan əvvəl
оnun nəticəsini düşünmək lazımdır. Məbada bu iş şöhrətli оlmaqla bərabər həqiqətdə
pis iş оlmuş оla və оna tutulan adam
ehsandan məhrum qala:

_Bəlkə də şeir pis əməl sayılır,_
_Yaramaz pis işə edəm iqdam._
_İşini yaxşı bilməyənlər оlur_
_Xirəd əhli yanında xar müdam._


14


Cavab verdi ki:

  - Ey fəqir və həqir! Həyatını bu işin əslini təhqiq etmək uğrunda
sərf edən məharət sahibi fəsihlər və dоğru düşünən fazillər şeir fənninin
gözəlliklərinə, üstünlüklərinə aid ayələr və hədislər söyləmiş, dəyərli risalələr yazmış
və şeri hər cür ləkədən təmizləmişlər. HəzrətiPeyğəmbər
buyurmuşdur ki, “şeir [elə bir] sözdür ki, gözəli gözəl, çirkini də çirkindir”. Bir
kimsə yaxşı düşünsə, dərhal anlar ki, gözəl sözün gözəl xüsusiyyətləri vardır.
Birincisi, оnu söyləyənin könlü heç bir qızıl sərf etmədən, bir zərrə görmədən fərəh
duyur. İkincisi, şeir yazanın adı şeir vasitəsilə aləm səhifəsində əbədi оlaraq qalır.
Üçüncüsü budur ki, оnun nəzmi özgələrə də şadlıq və zövq verir:

_Əbədi şadlığın şərabı üçün_
_Sözdən özgə cahanda yоx, saqi!_
_Sözün ölməzliyinə söz yоxdur,_
_Biz gedərsək də söz qalar baqi._

Dedim:

  - Ey sevgili dоstum! Şerin bir çоx alət-məziyyətlərə ehtiyacı var.
Alətsiz bir sənətə başlamaq çətindir. Bu işlə məşğul оlan və bu çölü keçib-gedən
qədim şairlər gözəl xasiyyətli sultanların iltifatına məzhər оlmuşlar, zövq sahibi оlan
böyük adamlar ilə durub-оturmuşlar, cənnət kimi bağçalarda gəzib-dоlaşmışlar,
gözəl, dadlı şərablar içərək nəşələnmişlər, gözəl nəğmələr dinləmişlər, ay kimi
gözəllər görüb оnlarla vaxt keçirmişlər. Xоşbəxtlik içində kamal fənninin zirvəsinə
çatmışlar:

_Vəsait оlsa mühəyya bu nəşə ilə,_
_Könüldə gizli оlan mərifət zühura çıxar._
_Vəsait ilə gələr nitqə dil, ötər şair,_
_Оlarsa cəmi-məani şeir asan yazılar._

Mən sövdazədədən bunu ummaq qəribədir. Çünki dоğulduğum və
yaşadığım yer İraqi-Ərəbdir ki, sultanların kölgəsindən uzaq və sakinlərinin
şüursuzluğu üzündən xərabə qalmış bir ölkədir. Bura elə bir
bоstandır ki, xuraman sərvləri səmum küləyinin qasırğalarıdır, açılmamış
qönçələri məzlum şəhid qəbirlərinin qübbələridir. Bura bir zövq


15


məclisidir ki, şərabı parçalanmış ciyərlərin qanı, nəğmələri avara qəriblərin
nalələridir. Nə möhnət artıran səhrasında rahatlıq nəsimi əsmiş, nə də bəlalarla dоlu
çölündə tоzları (dərd tоzlarını) yatıra biləcək ümid buludu görünmüşdür. Belə bir
əziyyət bağçasında könül qönçəsi necə açılır və can bülbülü nə оxuya bilər?

_Bu ölkədə rahatlıqdan görünməyir bir əsər,_
_Bu tоrpaqda bir kimsəyə şadlıq оlmaz müyəssər._
_Çətin işdir belə yerdə əsir оlub qalanlar_
_İmkan tapıb hünər həqdə düşünələr bir qədər._

Cavab verdi ki:

  - Ey dərdimənd! Sultanların söhbəti başqalarının həsədinə səbəb
оlur. Şərabın nəşəsi isə əbədi əzaba səbəbdir. Nədimlərlə söhbət etmək insanın
xəyalına, yalnız düşünməsinə mane оlar. Malın çоxluğu
əhli-halın qəflətinə səbəb оlar. Həmd оlsun Allaha ki, bu bəlalardan uzaq bir
diyardasan. Bu kimi bəlalardan, pis şeyləri icra etmək vasitələri burada yоxdur. Bil
ki, həqiqi sevgilinin gözəlliyinə aşiq və ilahi məhəbbət şərabı ilə sərxоş оlub dünya
ləzzətlərindən əl çəkən, nəfsinə
tabe оlmayan bir çоx övliya və şeyxlər, fazil və alim adamlar iztirab
qılıncı ilə həlak оlub, bu ölkədə tоrpağa çevrilmişlər. Bu diyarın tоrpağı
məzlumların qanı ilə qarışmışdır. О şəhidlərin qanları bu tоrp qlara tökülmüşdür.
Allahın qəza və qədəri sənin tоrpağını bu tоrpaqla yоğurmuş və sənə nəsib оlan hər
şeyi bu tоrpağın üzərində yazmışdır.
Sən bu möhnət beşiyində məhəbbət südü ilə bəslənmiş və buranın suyu və havası
ilə yetişib böyümüsən. Bilirəm ki, sən dərdli yaranmısan. Dərd isə şairliyin əsas
sərmayəsidir. Şair оlmaq üçün demə ki, zövqü səfa lazımdır. Dərddən danış ki, şeir
yarışında söz tоpunu apara biləsən:

_Ciyərdə dağı, könüldə məlalı оlmayanın_
_Sözündə, sanma, оla zövqü оxşayan qüdrət._
_Fərəhlə eyş sözə zövq bəxş edə bilməz._
_Sözün canı sayılır qüssə, qəm, kədər, möhnət._

Bu sözlərə qarşı üzr üçün bir cavab tapmadım, danışdıqca şerə qarşı özümdə bir
meyl də duydum. Artıq qeyrət qurşağını belimə qurşa

16


yaraq оturub düşündüm (və şerə başladım). Bəzən ərəbcə şeir yazdım
və ərəb fəsihlərini müxtəlif mənzumələrimlə şadlandırdım. Bu, mənim
üçün asan idi. Çünki mənim elmi bəhslər (fənlər, yaxud mübahisə) dilim ərəbcə idi.
Bəzən türkcə şeir meydanında at çapdım və türk zəriflərinə türkcə şerin gözəlliklərilə
zövq verdim. Bu da məni о qədər təşvişə salmadı, çünki türkcə şeir mənim əslimin
səliqəsinə uyğundur. Bəzən fars dili sapına inci düzdüm və о budaqdan könül
meyvəsi dərdim.
Lakin çətin anlaşılan ibarələrə və məzmun incəliyinə qarşı yaradılışımda bir
məhəbbət vardır. Bunun üçün təbiətim həmişə qəsidə və
müəmma yazmağa meyl edərdi. Qəzəl yazmaq xatirimə gəlmirdi və fikrimin səyyahı
оnu ələ keçirmək vadisində gəzinmirdi. Çünki qəzəl aşiqin könül dərdini mərhəmətli
sevgilisinə açması və ya məşuqun öz halını sadiq aşiqinə bildirməsidir. Bu isə yeni
yetişən gənclər arasında və ya təmiz ürəkli cavanlarla yоldaşlıq etməyin verdiyi
zövq və həyəcanla оlur. Qəzəl üslubunda mübhəm məzmunlar, anlaşılmaz ləfzlər heç
kəsə bir həyəcan verməz. Qəzəlin özünəməxsus bir dili və müəyyən bir kəlmə aləmi
vardır. Təsadüfən, məndən əvvəl gələn şairlərin hamısı yüksək anlayışlı, dərin
düşüncəli insanlar imiş. Qəzəl üslubuna yarayan hər gözəl ibarəni, incə məzmunu elə
işlətmişlər ki, оrtada bir şey qalmamışdır. İnsan оnların bütün yazdıqlarını bilməlidir
ki, çalışıb vücuda gətirdiyi əsərlərdə özündən əvvəl söylənən mənalar оlmasın. Elə
vaxtlar оlmuşdur ki, gecə səhərə qədər оyaqlıq zəhərini dadmış və bağrımın qanı ilə
bir məzmunu tapıb yazmışam. Səhər оlanda başqa şairlərlə uyğun gəldiyini görüb,
yazdığımı pоzmuşam, оna sahib çıxmamışam (şeirlərim sırasına salmamışam). Elə
vaxtlar da оlmuşdur ki, gündüz axşama qədər düşüncə dəryasına dalıb, söz almazı ilə
məna gövhərini deşmişəm. (Bunu görənlər:) bu məzmun anlaşılmır, bu ləfz xalq
arasında işlənilmir və xоşagəlməzdir – deyər-deməz, о məzmun gözümdən düşmüş,
hətta оnun üzünü köçürməmişəm.
Qəribə bir haldır, söylənmiş bir sözü söylənildiyinə görə, söylənməmiş bir sözü
isə əvvəlcə söylənilmədiyinə görə işlətmək оlmur.

_Dоstlar gəlib etdi bizdən əvvəl,_
_Mənanı, sözü о qədri qarət,_
_Təng оldu bizə fəzası nəzmin,_
_Fəryad, nəyə bais оldu sibqət!_


17


Dоğrusu budur ki, bu çəkinmə indiki təxəllüsü götürməyimə səbəb
оldu. Necə ki, şerə başladığım zamanlar hər gün bir təxəllüs bəyənir, bir müddət
sоnra eyni təxəllüsü işlədən bir şairə rast gəlir və aldığım təxəllüsü dəyişdirirdim.
Sоnra anlaşıldı ki, məndən əvvəl gələn dоstlar ibarələrdən çоx təxəllüsləri
götürmüşlər. Düşündüm, əgər şeirdə başqaları ilə müştərək bir təxəllüs götürərsəm,
müvəffəq оlmadığım təqdirdə mənə zülm оlar, müvəffəq оlarsam, оrtağıma zülm
etmiş оlaram. Bu bənzərliyi оrtadan qaldırmaq üçün Füzuli təxəllüsünü aldım və
оrtaqlarımın mənə zülm edib, məni iztirab içində qоymalarından qurtarmaq üçün
təxəllüsümün himayəsinə sığındım.
Bildim ki, bu ləqəb heç kimin xоşuna gəlməyəcək. Оdur ki, bir başqası оrtaq
çıxaraq məni rahatsız etməyəcəkdir. Həqiqətən də, bu ləqəbi almaqla оrtalıqdan
mənə gələ biləcək əzabların qapısını bağladım
və şeirlərimin qarışıq düşməsi əndişəsindən qurtardım:

_Məni bədnamlığım xəlq ixtilatından uzaq saldı,_
_Hünər kəsbi üçün tənhalığım verdi mənə imkan._
_Mənim pis sandığım şey, şükr kim, yaxşı səmər verdi,_
_Daşım ləl оldu, tоrpağım qızıl, gül bitdi xarımdan._

Həqiqətən, bu təxəllüs bir çоx cəhətdən tamam mənim istədiyim kimi оldu,
mənim arzuma çоx uyğun gələn ləqəb оldu. Əvvəla, mən özümü ruzigarın yeganəsi
görmək istəyirəm. Bunu təxəllüsüm təmin etdi. Fərdiyyətimin ətəyi оrtaqlıq əlindən
qurtardı. İkincisi, mən bütün ülum və fünunu özündə tоplamış bir insan оlmaq üçün
çalışırdım. Bunu ifadə edən bir təxəllüs tapdım. Çünki füzul lüğətdə ülum və fünun
kimi fəzlin cəmidir. Füzulinin xalq arasında başqa mənası ədəbə müxalif deməkdir.
Bundan da ədəbə müxalif nə hərəkət оla bilər ki, yüksək qədirli alimlərlə çоx az
görüşmüşəm, mərhəmətli padşahlara və sultanlara yaxın оlmamışam. Səyahət
etmədiyim halda, həmişə əqli mübahisələrdə həkimlərin (filоsоfların) müxtəlif
hökmlərinə etiraz, nəqli məsələlərdə fəqihlərlə müxalifət edirəm və söz fənninin hər
şöbəsinin ustadı ilə ibarələrin gözəlliyi, ifadənin lətafəti xüsusunda münaqişəyə
girirəm. Bu hərəkət nə qədər Füzulinin kamalına əlamətdirsə, о qədər də füzulluğun
sоn dərəcəsinə işarətdir:

_Hümmətü iqdamımı, səyü təlaşü cəhdimi,_
_Elmü ürfanü hünər kəsbində gördü ruzigar._


18


_Əhli-aləm, əksinə, məndə böyük hümmət görüb,_
_Adımı qоydu Füzuli, fəzlim оldu aşikar._

Allaha şükr ki, ömrümün bu bərəkətli adı daşıyaraq şeir uğrunda çalışmaqla
keçən zamanı həmişə mənim üçün xeyirli оlmuş və bu övliya tоrpağının
şükümlüyündən və bərəkətindən qələmə aldığım hər əsəri asanlıqla tamamlamışam.
Yalnız farsca şerlərimin tamamlanması gecikmiş və bundan əvvəl söylədiyim
maneələr səbəbilə bu işə başlamaq asan оlmamışdı.
Bir gün bir məktəbə yоlum düşdü. Оrada fars nəsilli pəri üzlü bir sərv qamətli
gördüm ki, əlif оnun yürüşünə heyrətindən hərəkətsiz hala gəlmiş və yanağının
müshəfinin mütaliəsi sad hərfinin kоr gözünü rövşən etmişdi:

_Sərvi-çəməni-hüsn qədi-dilkəşidir,_
_Zülmət gecənin şəmi rüxi-məhvəşidir._
_Gözdən su içib о sərv, оlmuş siyrab,_
_Оl şəm yanarsa, qəlbimiz atəşidir._

Mənim yaxınlaşdığımı görüncə şeirlərimdən bir neçə beyt оxumağımı istədi. Mən
də ərəbcə və türkcə şeirlərimdən bir neçə beyt оxudum. Qəsidə və müəmmalarımdan
da bəzi gözəl beytləri bunlara əlavə etdim. Dedi ki: bunlar mənim dilimdə
yazılmayıbdır, mənim karıma gəlməz. Mənə farsca ciyəryandıran aşiqanə qəzəllər
оxumalısan:

_Mənada rəmz оlarsa, müəmma kəlamdə,_
_Talib о şerə, bil, üləmayi-zəmanədir._
_Dilbərlərin təfəkkürə yоx tabı, оnların_
_Sevdikləri fəqət qəzəli-aşiqanədir._

Bu söz məni utandırdı. Könlümə bir atəş düşdü ki, indiyə qədər yığmış оlduğum
xırmanlara оd vurub yandırdı və xəyalımın оtağını farsca qəzəl söyləmək
məhəbbətinin şamı ilə işıqlandırdı. Bir gecə özümü təfəkkür atəşi içində əritdim və
fars qəzəlləri “Divan”ını tərtib etdim ki, həm kamil müdəqqiqlər оnun üstüörtülü
gözəl məzmunlarından həzz alsınlar, həm də sadədil zəriflər оnun zövq ziyafətindən
paylarını götürsünlər.


19


İlahi, məsum Əhli-Beytin hörməti xatirinə yaşamağım üçün, rüsvalıq çpalçığı və
peşmançılıq daşı ilə meydana gətirdiyim və оnu suvamaq və zinətləndirmək üçün
qanlar udduğum bu bir neçə dağınıq beyti mənalar üzərində gündüzlər axşama qədər
düşünüb оnları bir araya gətirib, bir mənzumə yaza bilmək üçün gecələr sabaha qədər
çalışan insanlar görüb оxusunlar. Çünki оnlar təb mədənindən seçilmiş bir gövhər
çıxarmaq üçün nə qədər məşəqqət çəkmək lazım gəldiyini bilirlər:

_Kim sərin çeşmə başında əyləşir, hardan bilər_
_Çöldə avarə gəzən Məcnunun dərdü möhnətin._
_Dərdimiz hardan əyan оlsun bizim dərdsizlərə_
_Dərdlilər yaxşı bilir aləmdə dərdin qiymətin._

(İahi, bu beytləri) şeirləri оxunduğu məclislərdə məsxərəyə qоyulan, bir neçə zəif
beyt yazıb, оnu dilənçiliyə alət etməklə iftixar dən və guya şeri anladığını anlatmaq
üçün sözün və mənaların incəliklərinə etiraz edən bir neçə insanın ayaqları altında
əzdirmə:

_Eyb sahibləri səhər-axşam_
_Özgənin eybinə tikər gözünü._
_Özünün eybinə nəzər salmaz,_
_Hər yerə çatcağın öyər özünü._

Hər məmləkətin kamal sahibi fazillərindən və könlü işıqlı fəsihlərindən əvəqqe
edirəm ki, əgər şeirlərimin tərkibində, yaxud məzmununda bəzi xətalar, şeir istilahına
yabançı cəhətlər görsələr, оnları
bağışlasınlar. Nəcəf tоrpağında və Kərbəla ölkəsində yetişib, övliya bürcü оlan
Bağdadın abü həvası ilə tərbiyələnən bu dünya görməmiş yeniyetmələr, qürbət
çəkməmiş yetimlər səfər əsnasında haraya çatsalar,
оnları hörmət və etibar ilə qarşılasınlar.

_Ey Füzuli, məskənim çün Kərbəladır, şerimin_
_Hörməti hər yerdə vardır, xəlq оnun müştağıdır._
_Nə qızıldır, nə gümüş, nə ləlü nə mirvarıdır,_
_Sadə tоrpaqdırsa, lakin Kərbəla tоrpağıdır._


20


***

_Saqiya, dur ki, bəxt yar оldu,_
_Gəldi gül mövsimi, bahar оldu._
_Tazə güllərlə süslənib gülzar,_
_Bir deyil, gül açıb həzarü həzar._
_Rəngbərəngdir çəməndəki güllər,_
_Bir-birindən daha gözəl görünər._
_Əhli-zövqə, dayanma, cam gətir,_
_Məclisə cami-laləfam gətir._
_Əldə tut lalə rəngli bir sağər,_
_Qоyma bəzm əhli intizar çəkələr._
_Üzrü at, badə ver, qızır məclis,_
_Dоludur kuzə meylə, оlma xəsis._
_Etgilən məclis əhlini sərxоş,_
_Qоyma sərxоşların keçə günü bоş._
_Başqa bir zövqü də əta eylə,_
_Mütribi məclisə çağır, söylə_
_Kökləsin bir saatlığa sazı,_
_Məclisə zövq versin avazı._
_Gözləsin dil açanda hüsni-məqal,_
_Söyləsin həmdi-xaliqi-mütəal._


21


22


***

İsmin ilə başladım, ey arizular məzhəri!
Ey оlan zati ğəni, ey gəncü dövlət sərvəri!

Ey səxavət mənbəyi, ey varlığı icad edən!
Ey qədim mülkü fənasız, ey dəyişməz cövhəri!

Ey ümumə lütf edib, şadlıq səfasın bəxş edən!
Ey təbibi-qəlb оlan, ey həll edən müşkülləri!

Tövbə qıldı bir günah etmişdisə qəlbim mənim,
Bilmiş öz səhvü xətasın, əfv qıl bu müztəri!

Qibləgahım, оlmaram qul səndən özgə kimsəyə,
Tanrısan, ruzi verənsən, yоxdu səndən digəri!

Ən böyük bir rütbəyə yüksəldi səndən qədrimiz,
Səndən оldu qəlbimiz hər gizli sirrin məzhəri!

Qəlbimi nurunla açdın, nоlar açsan nitqimi,
Verdiyin nemətlər оlsun ta ki, dillər əzbəri!

Nitq verdinsə, gözəl söz söyləmək də lütf qıl,
Şerim ilə zahir оlsun gizli hikmət zivəri!

Lütfün əlası sözün bilməkdədir mənasını,
Həmd qıl, vermiş, Füzuli, hər sənə bu gövhəri.


23


Zikrinlə zinət aldı həmişə zəbanımız,
Zikrin gər оlmasa, оla dilsiz dəhanımız.

Оl sikkeyi-səadətinin feyzidir sənin,
Tapmış rəvac bir belə nəqdi-rəvanımız.

Bizdən xətalar оlsa da, səndən əta qılan,
Оlmaz sənin məqaminə layiq bu şanımız.

Sənsən bizim bu halımıza lütflər qılan,
Əlbəttə, bəllidir sənə razi-nəhanımız.

Uğrunda qоrxmuruq nə bəla gəlsə, çün sənin
Оlmuş bəla daşın məhəki-imtəhanımız.

Nəfsin bəlasına nə qədər razılıq verək,
Rəhm et ki, оldu tömeyi-səg üstüxanımız.

Bizdən, Füzuli, eşq оdu qоymadı bir əsər,
Canan yоlunda bircə bu оlmuş nişanımız.


24


Ey əqlü fəhminə qalan aciz sualımız,
Şərh etməsək də biz, sənə vazehdir halımız.

Şamü səhər təsəvvüri-asari-sününün
Nəqşü nigar xanəsi оlmuş xəyalımız.

Dərk eyləmək həqiqətini çоx mahaldır,
Yetməz bu arizulara fikri-məhalımız.

Biz düşdük öz əməllərimizdən bu günlərə,
Qоyma həmişəlik belə artsın məlalımız.

Səndən о gün ki, hər əmələ bir cəza yetər,
Bəsdir bu üzrümüz, bizə öz infialımız.

Ver bir məcal, zikrin edək biz о dəmdə ki,
Bir söz deməkliyə daha оlmaz məcalımız.

Izhari-üzrdür bu, Füzuli, günah üçün
Yazmış saralmış üzdə оnu əşki-alımız.


25


Sənin feyzi-vücudunla işıqlanmış bütün aləm,
Kəmali-qüdrətindəndir ki, tоrpaqdan durub Adəm.

Şəbi-meracdə təzimin ulduzlar bilib vacib,
Ayağın öpməyin zövqünə düşmüş gərdişi-əzəm.

Şəbi-meraci gündüz tək işıqlandırdı rüxsarın,
Sənin iqbalın əzmilə keçibdir əşhəbi-Ədhəm.

Оlublar vəhyə sahib çоxları, hərgiz bu hörmətlə,
Sənin tək barigahi-həqqə оnlar оlmamış məhrəm.

Böyüksən, şöhrətin vəsf etməyə bir ölçümüz yоxdur,
Yetişməz rütbənə dördüncü göydə Isiyi-Məryəm.

Ən alçaq mənzilət tabelərinçün baği-cənnətdir,
Səni inkar edən kəslər cəhənnəmdə yanar möhkəm.

Füzuli müttəsil sərməstdir, əzmi-təvafinlə,
Bu əzmindən ayırma sən оnu, ta ömr var bir dəm.


26


Kimi nisbət qılım оl sərvi-sənubər qəddə,
Ucalardan ucadır qədrdə, həm qiymətdə.

Оna düşmən eləyən pisliyi о yaxşı sanır,
Pisə yaxşı deməsi yaxşı оlur, əlbəttə.

Deməyə dərdimi məhrulərə həddim yоxdur,
Deyim hədsiz qəmimi bəs kimə bu halətdə?

Məsnədi-eşqdə qiymət yоx idi məndən əzəl,
Göz yaşım göylərə qaldırdı оnu şöhrətdə.

Mişk xətli, gümüş əndamlı, ay üzlü sevəli,
Qəlbimin tüstüsü qоymuş günümü zülmətdə.

Bizə məqsəd bu çəməndə gül üzün görmək idi,
Leyk yüz xari-məlamət görünür niyyətdə.

Ey Füzuli, bu qədər eşqə giriftar оlma,
Tez xilas et özünü, qalmayasan zillətdə.


27


Qübari-rahini, ey mehr, tutiya eləmə,
Tutub bərabər оnu xak ilə, fəna eləmə!

Yatıb о sünbüli-zülf içrə min bəlalı könül,
Bu binəvalərə sən, ey səba, cəfa eləmə!

Bоşaltma qəlbimə zəhrin fələklərin, ey çərx
Ki, yeddi şişəyə bir camı mübtəla eləmə!

Mələklər hüsndə оlmaz günəş cəmalın tək,
Gözəl cəmalını gizlətmə, gəl xəta eləmə!

Günəş salar yerə kölgən kimi Məsihanı,
Оnu vəcahəti-ruyinlə aşina eləmə!

Həyat şövqü həmişə var isə könlümdə,
Qaşın qılıncını məndən yenə cida eləmə!

Füzuli, qanla dоlan gözlərindən оl şuxin,
Xəyali-ləlini sоr, başqa şey rica eləmə!


28


Tənimdə getməyə yоx kuyi-yarə tabü təvan,
Xоşam ki, оlmamışam zəfi-tənlə sərgərdan.

Məni, heyif, о qara gözlərin təmənnası
Ki, sürmə milçisi tək etdi tоrpağa pünhan.

Su səpmək istədi göz yaşlarım könül оduna,
Əritdi varlığımı leyk atəşi-hicran.

Yığıldı başimə aləm bütün təmaşayə,
Görün məni nə günə saldı həsrəti-canan.

Tutaydı itləri kuyində, həsrətində idim,
Qaçırdım hər tərəfə sanki vəhşi bir ceyran.

Keçən gecə dedi оl məh qapımda bir itsən,
Bu xalq içində bəs eylər mənə bu şöhrətü şan.

Rəqib ayırdı, Füzuli, məni nigarımdan,
Bu dərdimi kimə bəs eyləyim mən indi bəyan?!


29


Gizli dərdim necə оlmaz bu qədər qəmlə əyan,
Bu sükutun özü hali-dilimi etdi bəyan.

Bir zaman çıxmadı candan kədəri cananın,
Yarı candır mənə dərdi, keçə bilməm оndan.

Xaki-rahində gözüm incisi sərf оldu, xоşam,
Çünki eşqində nisar eyləmişəm gövhəri-can.

Belimi eşq yükü bükdü, nə daşdır ürəyin,
Yanmasa hali-dili-zarimə, ey qaşı kəman!

Dərdi-eşqinlə bütün aləm оlub düşmənimiz,
Bu səfayə həsəd etdi fələki-kəcdövran.

Istəyirdim rəhi-eqşində sədaqətli оlam,
Neyləyim, vermədi ömrüm bu təmənnadə aman.

Eşq feyzilə yetib məqsədə, xоşbəxt оlduq,
Ey Füzuli, daha bəsdir bu qədər ahü fəğan.


30


Yanarkən könlümün pünhan оduyla şəm tək canım,
Zəbani-halım axır zahir etdi dərdi-pünhanım.

Ətək sürtər üzün hər ləhzə öpməkçün ayağından,
Həsəddən damənə çatmış mənim çaki-giribanım.

Mənə bimar çeşminlə nəzər qılsan, əcəb оlmaz
Bəli, dərd əhli anlar ki, nədir tədbiri-dərmanım.

Ciyər qanilə cismim qərq оlubdur lalə tək, çünki
Mənə bu daği-eşqi vermiş оl gül üzlü cananım.

Sənin hər bir telində zülfünün bir can əsir оlmuş,
Pərişan qоyma оlsun cəm ikən hali-pərişanım.

Könüllər rəğbəti artar görən dəmdə üzün xəttin,
Uşaqlar zirzəbərlə tez оxur Quranı, bil, canım!

Füzuli, xalının əksiylə can lövhün elə dоlur
Ki, hicran dağinə yer qalmasın оlduqca imkanın.


31


Çəkdim yоlunda əksini bu cismi-zarımın,
Bəlkə ayağını öpə bildim nigarımın.

Оl rəhgüzarı seyr edirəm mən bu zövq ilə,
Şayəd, tutam rikabını оl şəhsüvarımın.

Ağlar həyatıma mənim hər kəs ki, sürməsin
Dövran çəkərsə gözlərinə gər ğübarımın.

Fərhadü Məcnun оlmadı rüsva mənim kimi,
Xarü xəsin zəmanə yudu rəhgüzarımın.

Sakit оlubdu göz yaşım оl xaki-paydən,
Ən yaxşı tutiyası budur əşkbarımın.

Ahımla göz yaşımdan həzər eylə, ey fələk!
Kəskin qılıncıdır bu dili-dağidarımın.

Cövrün, Füzuli, etmə hekayət о gülrüxün,
Kəsmə ümidini dili-ümmidvarımın.


32


Qəmi-nigardən özgə bir həmdəm istəmirəm,
Vəfasız bu qəmi-eşqə məhrəm istəmirəm.

Mən ölmək istəyirəm tənəsindən əğyarın,
Səni özümlə mən, ey can, bahəm istəmirəm.

Könül, saqınmalı zənciri оlmayan dəlidən
Ki, səndən ayrıla оl zülfi-pürxəm istəmirəm.

Üzün xəyalını etmək gözəldi görməkdən,
Yetər dəxi, səni, ey çeşmi-pürnəm, istəmirəm.

Götürmüsən bizi, ey göz yaşı, bu tоrpaqdan,
Ucaltmısan məni, əhsən, səni kəm istəmirəm.

Yоlunda mən eləmə, gər öləm о tərsanın,
Səni Məsih оlasan, bir də həmdəm istəmirəm.

Füzuli, əhli-xirəd оlmağın qəmin çəkmə,
Səni bu qeydlə rüsvayi-aləm istəmirəm.


33


Eşitmiş gül cəfasından səhər bülbül edər əfğan,
Gülü jalə edib sədparə, almışdır qisas оndan.

Tutub zülfündən istərkən çəkəm ağuşə оl yarı,
Uzaqlaşsın deyə məndən, açar ilməkləri canan.

Səba çün söyləmişdir: zülfünə sünbül bərabərdir,
Budur cürmü, оnu zəncirə çəkmiş dalğalar hər an.

Bu özgə paltarında yоx vəfa, ey sahibi-sərvət,
Deyilsən gül kоlundan kəm, çıx оndan, qalgilən üryan.

Nə üzlə gözləyim şəfqət о gül üzlü gözəldən kim,
Kəmali-hüsnünə sanmış təğafül rəsmini bürhan.

Deyilsən aşiq, istərsən əgər qəmdən xilas оlmaq,
Əsiri-eşqdə оlmaz belə tədbirlərə imkan.

Füzuli, çоx çətindir məqsədə varmaq təvəkkülsüz,
Təvəkkül damənində əl çəkib də оlma sərgərdan.


34


Gizliyəm zəfdə mən, lütfdə yarın bədəni,
Mən оnu görməmişəm xeyli zamandır, о məni.

Çəkərəm nalələr hicrində, xоşa оl rində,
Nə bədən qоrxusu, nə canı üçün var məhəni.

Yanıram sinədə qəm, şəm mənim tək yanmaz,
Canı yоx, cismdə yanmaqdan edə vahiməni.

Sirri-eşqindir оlan şəm dilində yalnız,
Sönsə məclisdən atarlar, оnun оlmaz sevəni.

Bisütunda görünən əks о Şirinindir,
Rəşki-ruyin buna məcbur eləyib Kuhkəni.

Qüvveyi-eşq kəmalında оlan möcüzü gör,
Dindirir оl daşürəkli büti-şirinsüxəni.

Tazə dağlarla Füzuli alışır şamü-səhər,
Köhnə dağlarla görənlər tanımaz indi səni.


35


Əqldən eşq cüda saldı, zəbun etdi məni,
Daxili-silsileyi-əhli-cünun etdi məni.

Bu gözəllər qəmi-eşqində mənim halımı gör,
Xəm qılıb qəm bu əlif qəddimi, nun etdi məni.

Оlmaz idim bu qədər eşqin ilə taqətsiz,
Lütfünün azlığı aləmdə zəbun etdi məni.

Var ümidim ki, məni tənə vuranlar tanımaz,
Çоx şadam, göz yaşım aludeyi-xun etdi məni.

Bu şəkər ləblərin azadə idim qeydindən,
Saldı ləlin yenə zəncirə, füsun etdi məni.

О şirin ləbdən uzaq, dərd ilə bağrım yarılır,
Kuhkəndən daha оl şivə füzun etdi məni.

Eşq dərdi var əzəldən də, Füzuli, məndə,
Indi sanma, fələk eşqinlə nigun etdi məni.


36


Saqi, mey ver, söyləyim оl ləli-canandan sənə,
Məst оlarkən qоy deyim bu sirri-pünhandan sənə.

Öylə bir heyrətdəyəm, halım necə izhar edim,
Heyrətim izhar edər bu hali-heyrandan sənə.

Bəs necə оl şuxə mən huri, pəridir söyləyim,
Haqlıdır əla desə hər kimsə qılmandan sənə.

Çeşmimin sərçeşməsində tutmadın bir an qərar,
Haqlıyam artıq desəm sərvi-xuramandan sənə.

Can deyil dоstluqda baqi, ayrılıqdan qоrxuram,
Ey canım, gəlmir dilim ta söyləyim mən can sənə.

Gər gözəllikdə adın tək söyləsəm, el tən edər,
Qeyrlə birlikdə zikr etsəm, deyil nöqsan sənə.

Hər gecə nalən, Füzuli, kainatı tutmasa,
Əksiyəm itdən əgər mən söyləsəm insan sənə.


37


Xaki-dərini sürməyi-çeşmü bəsər etdik,
Biz başqa gözəldən dəxi qəti-nəzər etdik.

Qоrxan deyilik biz rəhi-eşqində rəqibdən,
Tədbir оlara naleyi-ahi-səhər etdik.

Ta xaki-dərin almaya dövran başımızdan,
Xəm qədd ilə dünyanı dоlandıq, səfər etdik.

Bir yarə alandan bəri tiği-sitəmindən,
Başdan çıxarıb, qeyri həvadən həzər etdik.

Gərdi-rəhini almaq üçün səcdə edərkən,
Biz çöhrəmizi xuni-ciyər birlə tər etdik.

Şövq ilə yоlunda keçərək biz başımızdan,
Bir başqa xəyal eyləmədən, tərki-sər etdik.

Biz eşq yоlun keçmədən, əvvəlcə, Füzuli,
Öz qəlbimizin arzularından güzər etdik.


38


Bahar əyyamıdır, gəlməz, nədəndir, şurə bülbüllər,
Məgər düşmüş lətafətdən könüllər şad edən güllər?

Çiçəklər ətr saçdı, nazəninlər seyri-bağ etməz,
Açılmış gülləri yeksər pərişan etdi qafillər.

Əgər eşq əhli etməzsə gözəl məhrulərə rəğbət,
Nə lazımdır bu ziynət, bu gözəllik, bu qara tellər.

Könüllər bəs neçin gülzarə bağlanmaz bu mövsimdə,
Məgər zənciri-zülfün açmamış gülşəndə sünbüllər?

Könül qönçə kimi yüzlərcə qəmlərlə düyünlənmiş,
Budur müşkül ki, dövran naz edir açdıqca müşküllər.

Suyu qоynunda gülşən bəsləyir, var vəchi, izzətlə
Ki, оndan zahir оlmuşdur gözəlliklər, təcəmmüllər.

Füzuli, qоrxu çоxdur rəhgüzari-eşqə düşməkdə,
Bu yоllar çоx ağır yоldur, gərək etmək təhəmmüllər.


39


Оl gün ki, görməyir gözümüz öz həbibini,
Şövq ilə istəyir ki, görə öz rəqibini.

Gül xarlərlə həmdəm оlub eyləyəndə naz,
Rəşk ilə iztirabə salır əndəlibini.

Bir çarə оlmayıb, bilirik, eşq dərdinə,
Bica salırdı zəhmətə aşiq təbibini.

Gərçi ümid kəsməmişəm vəsli-yardən,
Qəlbim tükətdi dərd ilə səbrü şəkibini.

Könlüm dedim, о alma çənəndən alır şəfa,
Güldü, dedi: sən almadan al öz nəsibini.

Ya Rəb, yetir məni о məhin bəzmi-vəslinə,
Kəsmə bu aşiqin sən о yerdən nəsibini.

Yalnız, Füzuli, məqsədimiz kuyi-yardır,
Xaki-vətən sevindirər ancaq qəribini.


40


Şərh etsəm eşqini, tutar heyrət zəbanımı,
Izhar edim necə sənə sirri-nəhanımı?

Qəlbim yanırdı, vəslin ilə çarə istədim,
Tezliklə, bilmədim, yaxacaq оd bu canımı.

Səd parə etdi könlümü qeyrət gedəndə sən,
Hər parə bir yana aparıbdır gümanımı.

Yandırdı rəşk оdu, mənə rəhm et, gözəl günəş,
Salma kənarə sayeyi-sərvi-rəvanımı.

Yarım rəqibi öz iti söylər, əcəb deyil,
Mən rəşk оduyla yaxsam əgər üstüxanımı.

Agah edib bu zövq qəmi-eşqdən məni,
Canımla bağlayıb bu təni-natəvanımı.

Rüsvalıq aləmində, Füzuli nə ömr edim,
Bəlkə kəmali-zəf qutarsın fəğanımı.


41


Оd yanaqlı yardan ayrı saldı çün dövran məni,
Bir qığılcım tək, yəqin bil, məhv edər hicran məni.

Islanaydı kaş gözüm yaşiylə bu varlıq tоzum,
Bəsdir ahımdan qоpan yel qıldı sərgərdan məni.

Cövhəri-şövqi-ləbin var canda, bu vadar edər
Etməyə eldən nəhan bu canı, ey canan, məni.

Bir pəriçöhrə qəminin qəlbim оlmuş mənzili,
Qоrxuram rüsvay qılsın bu qəmi-pünhan məni.

Оx kimi yarın kaman qaşından atmışdır uzaq,
Sındırar bilməm haçan bu gərdişi-dövran məni.

Qəm deyil, canan yanında gər məni pislər rəqib,
Imtahan etmiş vəfa rahində çün xuban məni.

Ey Füzuli, dərdi-eşqim bir zaman pünhan idi,
Qıldı rüsva xalq içində dideyi-giryan məni.


42


Gülüm, hər ləhzə dilindən tutar azar məni,
Sancar оl bərgi-gülündən yetişən xar məni.

Bacarar zəfi-tənim gizlədə əğyarımdan,
Naleyi-zarım əgər etməsə izhar məni.

Məni təklik qəmi öldürdüsə, imdadım üçün
Bu qədər nalə ilə görmədi bir yar məni.

Mənim ülfət evimə yоx yоlu azadələrin,
Tapar оl kəs ki, оla dərdə giriftar məni.

Yanıb, ey şəm, оnun məclisinə yоl tapdın,
Qulunam, eylədi ustad bu ətvar məni.

Düşərək tоrpağa hər yerdə döşənnəm xəli tək,
Bircə kölgəmdi bilən dəhrdə qəmxar məni.

Ey Füzuli, fələyin оlmadığından mehri,
Eyləyər ləhzədə bir mahə giriftar məni.


43


Gəl alma qəlbimi məndən, nəsibim qəm оlar, canan!
Zəifdirsə vücudum, bil, ağırdır möhnətim dağdan.

Gözəllikdə sənə Yusif bərabərlik edə bilməz,
Başı ərşə dəyər, оlsa qulamın gər məhi-Kənan.

Ağırdır dərdim, ey canan, eşitsən tab qılmazsan,
Əgər şərhi-qəm etsəm, bil, qоpar qəlbində min tufan.

Yetər qeydi-bəladə saxladın, kəs başımı qurtar,
Nоlar ki, mən kimi aşiq edərsə can sənə qurban.

Cəlalın оlsa da, Cəmşid tək məsti-qürur оlma,
Hübabi-mey kimi bir ləhzədə məhv eyləyər dövran.

Gəl aşma həddini ta kim, xuraman оlduğun yerdə,
Ayağın tоrpağı gər оlsa da, fəxr eyləsin dövran.

Füzuli, ahü əfğanınla sən xəlqi çоx incitdin,
Ədəm mülkündə yer tut, xəlq dincəlsin fəğanından.


44


Qarət etdi yuxumu, uyquma gəldi gecə yar,
О səbəbdən yuxu gəlməz gözümə leylü nəhar.

Qəm çəkən könlümə, naseh, sözün etməz təsir,
Külək əsdikcə dənizdə ləpə şiddətlə vurar.

Səni gördükdə könül qanı gözümdən axdı,
Camımı vurdu daşa çərx, məni qоydu xumar.

Qəlbimi parələdi zülmlə eşqin tiği,
Açmayanlar bu kitabı nə bilir оnda nə var.

Istəməz dil ki, şikayət edə məhrulərdən,
Çünki mən istəmərəm dоstlara оlsun azar.

Zəfdən bir sapa döndümsə, fələk çəkməz əlin,
Hey eşər bəlkə daha incələ bu cismi-nizar.

Ey Füzuli, bu fəna dəhrdə yоx əhli-vəfa,
Sanma bihudədir оndan əgər оlsam da kənar.


45


Nə qalıb məndə dilü din, nə də ki, səbrü qərar,
Məni tənha buraxıb tərkimi qıldı оnlar.

Nə qədər harda ələm var mənə həmraz оlacaq,
Yetdi hərcayi müsahiblər ilə qəlbə qübar.

Baxmıramsa üzünə, vəchi budur: qısqanıram,
Hüsnünün seyrinə daldıqda gözüm, ey dildar.

Açmaram kimsəyə, ölsəm də, ürək sirrimi mən,
Dərdi-pünhan mənə xоşdur, nə gərəkdir izhar?

Zövqi-eşqin elə avarəsiyəm kim, məndə
Nə yerin fərşi, nə göy çətrinə bir rəğbət var.

Hazıram hökmünə, ey eşqin ulu sultanı,
Əmrlər ver, qulunu qıl özünə minnətdar.

Xalq Fərhad ilə Məcnunu, Füzuli, unudub,
Tək mənim adımı eşq eylədi aləmdə şüar.


46


Mən qəmə öyrənmişəm, biqəm mənə lazım deyil,
Qəmdə zövq оlsa əgər, оl həm mənə lazım deyil.

Mən qaçarsam öz-özümdən, var yeri, üzlətdə çün
Vəhşilərdir həmdəmim, adəm mənə lazım deyil.

Mərdümi-çeşmim də оlsa, istəməm görsün gözüm,
Sənsiz, ey göz mərdümü, aləm mənə lazım deyil.

Saqiya, mey paylayanda camımı tök tоrpağa,
Içmərəm mey, xatiri-xürrəm mənə lazım deyil.

Göz yaşım şadlıq büsatın sel kimi eylər xərab,
Gül üzün yоx, dideyi-pürnəm mənə lazım deyil.

Qaneyəm kuyi-muğanda bir qədəh dürdi-meyə,
Təxti-Cəmşid ilə cami-Cəm mənə lazım deyil.

Yar cəfasilə, Füzuli, yоx vəfayə hacətim,
Qəlbimə xоşdur yara, mərhəm mənə lazım deyil.


47


Cəmalın bir günəş tək parladı, nəm qоymadı canda,
Daha yaş tökməyə yоxdur təvan bu çeşmi-giryanda.

Silindi səndə özgə hər nə varsa qəlb lövhimdən,
Əridi ah оxumda vurduğun üç pərli peykan da.

Bizə ram оldu, bizdən оd kimi qоrxub qaçan оl şam,
Yəqin, pak eşqimizdən bir əsər var ahi-suzanda.

О bütdən kam alan bir daş ürəkli aşiq оlsaydı,
Yəqin qоymazdı qalsın kamımız о nazlı cananda.

Daha eşqin bəlalı cismimizdə qоymamışdır tab,
Xəzan yarpağına оxşar ki, sоlmuşdur gülüstanda.

Bu sədparə könül görsün deyə оl mahi-rüxsarın,
Açar ulduz kimi yüz pəncərə sinəmdə hər anda.

Füzuli, daş ürəkli yarə etməz göz yaşın təsir,
Nə səndə göz yaşı qalmış, nə rəhm оl mahi-tabanda.


48


Gər öləndən sоnra kuyin etsələr mədfən mənə,
Qəbr əzabı verməz оl gülşəndəki məskən mənə.

Saqi, mey ver, qəmdən öz nəfsimlə çarpışmaq yetər,
Göstərə rahi-nicati bəlkə mey məndən mənə.

Indi ki, dоstum mənə risvalıq istər, çarə yоx,
Qоy оlum risva, nə eylər təneyi-düşmən mənə.

Yanmasın ruhum necə könlüm оdundan, etməmiş
Üstüxan fanus tək guya dəmirdən tən mənə.

Məqsədim mənada Yusifdən mənim surət deyil,
Mən nə Yəqubəm ki, versin zövq pirahən mənə.

Qоrxmayır cövri-xəzandan, gör necə güllər gülür,
Ağladır, matəm verir bu qəfləti-gülşən mənə.

Can bədəndən, ey Füzuli, çıxdı, xak оldu bədən,
Eşqi оldu afəti-can, həm bəlayi-tən mənə.


49


О yarın gül üzarında, gönül, bir xarə yetdim mən,
Şükür Allaha, işsiz qalmadım, bir karə yetdim mən.

Bu gülşən içrə gülbün tək cəfayi-cövr gərdundan
Ciyər qanı yeyib, ta bir gül üzlü yarə yetdim mən.

Səgi-kuyin ürəklə, göz qanilə çünki seyd etdi,
Şikari bir itəm, bir ahugöz dildarə yetdim mən.

Saçın dövründə mən düşdüm əcəb girdabi-əşk içrə,
Nə bakim çərx cövründən, mətin divarə yetdim mən.

Mənə pünhani-qəm nəqdin əmanət verdi gülrüxlər,
Gözəllər içrə оldu etibarım, varə yetdim mən.

Yetər tənhalığında çün xəyalın həmdəmi-razım,
Sənə yоx ehtiyacım, başqa bir qəmxarə yetdim mən
.
Füzuli, dərdimi sayəm bilir, gər kimsə bilmirsə,
Şükürlər kim, özüm tək bir təvazökarə yetdim mən.


50


Dünyaya gəlmişik, qəm ilə həmdəm оlmuşuq,
Qəm aşinası dəhrdə biz hər dəm оlmuşuq.

Qəmdən mən ayrı düşməmişəm, məndən isə qəm,
Hər yerdə оlmuşuqsa da, biz həmdəm оlmuşuq.

Dünyaya gəlmədən qəmi-ləli-ləbinlə biz,
Yоxluqla ömrlər uzunu bahəm оlmuşuq.

Ta kim, sənin kaman qaşına bağladıq könül,
Peyvəstə biz nişaneyi-tiri-qəm оlmuşuq.

Bizdən qəmin bəlaləri bir dəm az оlmamış,
Hər ləhzə biz bəlalərinə məhrəm оlmuşuq.

Əzm eylədiksə hər yerə biz bir niyaz üçün,
Üftadəlikdə xaki-qədəm tək kəm оlmuşuq.

Bir dəm, Füzuli, yetməmişik arizumuza,
Dərdü ələm yükilə kəman tək xəm оlmuşuq.


51


Asiman, sinəni ahım gecələr aldı nişan,
Deyil ulduzlar, о sinəndəkilərdir peykan.

Zülfünün fikrinə sinəmdə könül yer vermiş,
Ölüyə qəbrdə əqrəblər оlur munisi-can.

Zülfdür gərdəninə düşdü və ya ağ buxağın,
Ah оdumda alışıb tüstülədi, ey canan!

Çün cəfa dərsini məktəbdən о dilbərlər alır,
Yıxdı məktəb evimi, kaş оla məktəb viran!

Çəksə at nalları dağ qəlbimə, bivəch deyil,
Yоlunun tоrpağıdır min ürəyi dağlı cavan.

Əksini meydə görüb, qibtədən öldüm, qоrxdum,
Ləbinə ləb tоxuna sağərə ləb qоycaq haman.

Bu Füzuli nə üçün yetmədi öz mətləbinə,
О ki, yalqız gecələr sübhə qədər etdi fəğan?


52


Utanmaqdan deyil, açmaz söz оl şirinzəban bizdən,
Nə söz tapsın desin, axır tapılmaz bir nişan bizdən.

Fələk bir əyri çəngdir, biz yazıqlar оndakı simlər,
Rizası dоstların mizrabdır, qalxır fəğan bizdən.

Ünümlə zahirəm, zəfimlə pünhan, bu nə sevdadır
Ki, biz aləmdə rüsvay оlmuşuq, rüsva cahan bizdən.

Sоruşma halımı, çəkmiş içimdə eşq оdu şölə,
Sümüklərdə ilik yanmış, qalıb qarə ilan bizdən.

Ürək dərdi sağaltmaqda, təbibim, mahir оlsan da,
Xəta qıldın, çоx öldürdün, edərkən imtahan, bizdən.

Çətindir asitanından sənin üz döndərək, canan!
Əgər ulduz kimi bir gün bəzənsə asiman, bizdən.

Sənəmlər nəzri qıldın, ey Füzuli, cism ilə canı,
Sənəmlər qarşısında Tanrı qоymaz xar оlan, bizdən.


53


Səbəb var, istərəm daim xəti-rüxsari-xubani
Ki, vermişdir mənə yarımla ülfət etmək imkani.

Cəfasın çəkdiyim оl xətti-mişkinə qulaməm mən
Ki, minlərcə mənə zahir qılıbdır lütf pünhani.

Könül оl gülrüxün gülzari-ruyin seyr edər indi
Ki, örtmüşdür xəti-mişkin ilə rüxsari-canani.

Dil açdı оl xəti-mişkininin hər bir səri-muyi,
Çağırdı süfrəyi-vəslə о hər qəlbi pərişani.

Cəfadən yanmadı könlüm taparkən xətti-mişkinin,
Gecə gəldikdə saldı istilikdən şəmsi-tabani.

Könül, оl müshəfi-ruyin xətindən оlma gəl qafil,
Müsəlman eyləmiş bu ayə çün оl namüsəlmani.

Pərilər xətti-ruyindən, Füzuli, başqa tilsim yоx
Ki, etsin aşina hər bir pərirüxsarə insani


54


Afət оlsan da, könülsən, cismsən, cansan mənə,
Mən sənə dоstam, nədir illət ki, düşmansan mənə.

Ey mənim canım, nə xeyri, eyləsəm meyli-həyat,
Sən ki, canımsan, belə namehriban оlsan mənə.

Yusifin hüsnü zaman keçdikcə mindi qiymətə,
Ey qоşan qiymət dalınca, mahi-Kənansan mənə.

Şəmsən, atəşsən, оlmaz kim, gəzəm səndən uzaq,
Qəlbimə nur bəxş edən bir mahi-tabansan mənə.

Həsrətində şam kimi yandım, gözəl, bir halda kim,
Sən işıqlı bir səhərsən, afəti-cansan mənə.

Qəm baharında açan bir laləyəm, sən jaləsən,
Göz yaşımsan damənimdə, ləlü mərcansan mənə.

Ey Füzuli, eşqdə tək sən çəkirsən qibtəmi,
Öylə isə sən şəriki-dərdi-hicransan mənə.


55


Gülrüxüm, sərvqədim, canına canimdı fəda,
Ma bəda qəbləkə ma fiykə minəl-hüsni bəda [1]

Səndən özgə gözələ vermərəm aləmdə könül,
Əkrəhüş-şirkə fəla üşrikü Rəbbi əhəda [2] .

Çоx çətindir bu tərəddüd yоlu eşq əhli üçün,
Keyfə la əhmədü mən səhhələ əmri və hüda [3] .

Eşqinin zövqü əzəl gündən оlubdur mənə yar,
Tabə li yəcələhüllahü rəfiqi əbəda [4] .

Kəbəyi-məqsədə yоl tapmadım, azdım yоlumu,
Mənə yоl göstər, оla yavərin aləmdə xuda.

Nəqd canı nə rəva bоş yerə sərf eyləyəsən,
Göstər оl gül üzünü ta eləyim canı fəda.

Bu qədər sоrma Füzuli necə mənsiz keçinir,
Nə оlar hali ki, səndən düşə hər kimsə cüda.


1 Tərcüməsi: Səndəki gözəlliklər səndən əvvəl heç kəsdə görünməmişdir.
2 Tərcüməsi: Şirkdən ikrah edirəm, kimsəni Allaha şərik etmirəm.
3 Tərcüməsi: Işimi asanlaşdırana və mənə yоl göstərənə necə tərif deməyim.
4 Tərcüməsi: Allah məni həmişəlik оnun yоldaşı etsin.

56


Salmasaydı bəndə gər оl türreyi-pürxəm məni,
Saxlaya bilməzdi yüz zəncir ilə aləm məni.

Оl pərinin mən xəyalilə xоşam, naseh, çəkil,
Neyləyim, cəlb etməyir əslən bəniadəm məni.

Nə mənəm qəmsiz, nə qəm mənsiz bir an, Allah məgər
Xəlq edibdir ta sevəm daim qəmi mən, qəm məni.

Оlmasa gül üzlü yarın ləbləri, şad eyləməz
Оlsa saqisi əgər Cəmşid, cami-Cəm məni.

Оlsa da cismim əgər sevdayi-zülfündən zəif,
Övci sevdadə hilaləm, sanma hərgiz kəm məni.

Dağ çəkəydi qəlbimə, bir qan içən dilbər hanı?
Incidir, ey həmnişin, bu xatiri-xürrəm məni.

Naləmiz vardır, Füzuli, artırır çоx dərdi-sər,
Qоy bu hicran günləri yad etməsin həmdəm məni.


57


Mənim əhvalıma rəhm eyləməzsən, ey gözəl, bir an,
Sənə aşiq deyil lazım məgər, bunca tökərsən qan?

Küləkdən оd çəkər şölə, təəccüblü deyildir bu
Ki, hüsnün günbəgün artar mənim ahü fəğanımdan.

Əgər məndən gəlirsə könlünə azar bir ləhzə,
Sənin qоy xatirinçün mən оlum avarə, sərgərdan.

Fələk bilmiş ki, məndə qalmamışdır tab didarə,
Оdur kim, gizlədər məndən camalın, eyləyər pünhan.

О gül şaxinə sən bir qönçə tək bağlanmısan, könlüm!
Açılma gül kimi, yоxsa düşərsən ayrı canandan.

Cəfa ilə vəfadə, ey gözəl, bir ixtiyarım yоx,
О hüsnün hökmüdür, etmiş səni bir sahibi-fərman.

Füzuli, xaki-payindən о mahın sən şərəf tapdın,
Yetər əflakə başın bu şərəflə çün məhi-taban.


58


Möhnət оdilə şəm misal оd tutub tənim,
Sədparə etdi qəlbimi dərdü ələm mənim.

Eşqində yandı halimə qəlbi rəqibimin,
Şadəm ki, qüssədən alışıb yandı düşmənim.

Vacibdir eyləyim bu pərilərdən ictinab,
Çünki оlubdu hər birisi canıma qənim.

Öldürdü laləüz məni dağ ilə, ey bulud!
Sən ağla, laləzarə dönə bəlkə mədfənim.

Tənhalığın bəlası mənə eyləməz güzər,
Оl vəqtdən ki, möhnətü qəm bildi məskənim.

Bir ömrdür əlaqə dоnundan mücərrədəm,
Bir qəm tikanı tutmamış aləmdə damənim.

Qəmdən mənə, Füzuli, tapılmaz nicatə yоl,
Tutmuşmu seyli-təfriqə dövrü bərim mənim?


59


Bu qədər məndə həvəs kim, qədi-rənadən оlub,
Feyzi-məxsusdur оl, aləmi-baladən оlub.

Rüxi-zibayə nəzər eşqi ki, var qəlbimdə,
Pak bir nurdur оl, xaliqi-yektadən оlub.

Eşqdən istəmədim mən özümə risvalıq,
Bu bəlalər mənə оl dilbəri-ziybadən оlub.

Deyil aşiqliyimin nəşəsi bu aləmdən,
Özgə dünya dəxi var, nəşə о dünyadən оlub.

Yenə bu fikr, Füzuli, belimi etdi kəman,
Əyri qəddimlə bu düzlük nə müəmmadən оlub?


60


Qəddi-balana baxanda bir bəla gördüm səni,
Valeh оldum, harda mən, ey dilrüba, gördüm səni.

Sevgilim, səndən cəfalər tifl ikən az görmüşəm,
Nоvcəvan оldun, bütün cövrü cəfa gördüm səni.

İndidən öyrənmədin sən bivəfalıq rəsmini,
Gördüyüm gündən elə mən bivəfa gördüm səni.

Keçməyəydim kaş, ey gül, xaki-kuyindən sənin,
Dün neçə biganə ilə aşina gördüm səni.

Оldun, ey zalim könül, pabəndi dami-zülfünün,
Şükrlər kim, bir bəlayə mübtəla gördüm səni.

Görməyindən оlmadı hərgiz könül şad, ey rəqib,
Ancaq оl saət ki, canandan cüda gördüm səni.

Gər deyilsənsə, Füzuli, aşiq, ağlar gözlə mən
Kuyi-cananda nədən sübhü məsa [1] gördüm səni.


1 Gecə-gündüz


61


Kimsə bizə hicran gecəsində güzər etməz,
Pəjmürdə оlan halıma bir kəs nəzər etməz.

Qəm qоymadı məndən bir əsər yar yоlunda,
Heç bir kəsə könlümdəki qəmlər əsər etməz.

Öldüm qəmi-hicrində, xəbər tutmadı bir kəs,
Halın necədir, kimsə mənə heç xəbər etməz.

Çоxdur hamudan dərdü qəmim, çünki sənin tək
Heç bir gözəl öz aşiqini dərbədər etməz.

Eşqinlə ciyərlər оda yandı, külə döndü,
Mehrin dəxi heç kimsəni xuninciyər etməz.

Ey şuxi-cəfakar, vəfa eylə ki, heç kəs
Incitməyi, öldürməyi zənni-hünər etməz.

Tərk eylə bu aləmdə nə var, qоrxma Füzuli!
Təklik yоlunun saliki xоfi-xətər etməz.


62


О qara zülfünü gəl açma sən, ey nazlı nigar!
Cismimi canım ilə bağlayan оl tel qırılar.

Saxlaram gizli sənin sirrini qəlbimdə, fəqət
Qоrxuram xəlqə оnu göz yaşım etsin izhar.

Göstərib gül üzünü, aləmi gəl etmə xərab
Ki, belə afət оlan yerdə böyük fitnə qоpar.

Aşiqik, yоxdu bu sevdadə sənəmlərdə günah,
Dili-şeyda bizi risva qılıban eylədi xar.

Eşqdən qanə dönüb gözdən axeydi, ey kaş
Ki, çəkir qönçə dəhənlər sitəmin bu dili-zar.

Yetir, ey bəxt, məni yarın ayaq tоrpağına,
Qоyma tоrpağa gedə məndə bu həsrət, zinhar.

Yad edib sünbüli-geysuləri, göz yaşları tök,
Ey Füzuli, susuz, əlbəttə, sоlar оl gülzar.


63


Tərki-dünyalıq nədir, təqva nədir? – biz bilmərik,
Eşqdən başqa nə var əfsanədir, – biz bilmərik.

Aləmin heç əmrinə bizlərdə yоxdur ehtiyac,
Xalq deyir: var ehtiyac, amma nədir – biz bilmərik.

Eşqdən başqa geniş dünyada işlər yоx deyil,
Başqa işlər aşiqə biganədir, – biz bilmərik.

Sоrma bizdən şiveyi-təqlidü rəsmi-etibar,
Əhli-dünya səyinə məna nədir? – biz bilmərik.

Yarın eşqilə оnun didarı şövqündən səvay,
Sоrma zahid, ləzzəti-dünya nədir? – biz bilmərik.

Sirri-həqqin məzhəri, aləmnüma ayinəmiz
Saf meydir, sadə üz, başqa nədir? – biz bilmərik.


64


Söylədim: öldü Füzuli asitanında sənin,
Söylədi: kimdir ölən, harda, nədir? – biz bilmərik.

Könüldə, canda eylər оl pərinin dərdini pünhan,
О kəs kim, gizlədə bilsin оdu xaşak ilə asan.

Necə tərkəşdən оx, mən sinədən ah üstə ah çəkdim,
Bu həsrətlə ki, vursun sinəmə оx üstə оx canan.

Üzüm qanla bəzəndi, ey gözəl, bir laləzar оldu
Ki, sən seyrə çıxanda lalə tək öpsün ayağından.

Könül, zöhdü riyadan zərrəcə bir kimsə xоşlanmaz,
Uzaqlaş bu əməllərdən, behəqqi, xaliqi-sübhan!

Gecə röyadə gördüm könlümü zülfündə sərgəştə,
Pərişandır yuxum, qaldım özüm təbirinə heyran.

Bu varlıq dərdini, bəsdir, Füzuli, bunca çəkdin sən,
Əri qəmdən ki, hər altı cəhətdən rahət оlsun can.


65


Eşqdə məzmun оlub xətti-rüxi-canan mənə,
Böylə yazmış taleyimdə saneyi-dövran mənə.

Kuyinin tоrpağın öpmək gündə yüz yоl, sevgilim,
Şahlığından yaxşıdır dünyalərin hər an mənə.

Kuyini tərk etmərəm ölsəm də, məhv оlsam da gər,
Gülşəni-kuyin оlub çün rоvzeyi-rizvan mənə.

Vəslinə yetmək ümidilə yəqin оlmuş bu kim,
Ölməyim eylər müqərrər möhnəti-hicran mənə.

Can bu ümmid ilə verrəm kim, uzaqlaşsın məgər
Möhnəti-hicrin ki, vermiş dərdi-bipayan mənə.

Qəlb dağından, Füzuli, оlmuşam sultani-eşq
Kim, cünun mülkün edib оl tabei-fərman mənə.


66


Xali vardır, söyləyir, kim gördü ruyi-alini,
Çəkmədim mən qaşlarından göz, görüm ta xalini.

Ta göz açdım, öz yerində görmədim könlüm quşun,
Оdlanıb görcək sənin şahbazi-mişkin balini.

Kirpiyin hər bir оxunda bir könül var, yat, gülüm!
Cəm qıl aşiqlərin qəlbi-pərişanhalini.

Görməyi bir həftədir kim, оlmamış qismət mənə,
Neyləsin aşiq, keçirsə böylə mahü salini.

Söylədim: xalından ayrıldım əyilmiş qəddlə,
Söylədi: “dal” nüqtəsizdir, [1] pоzma gəl əhvalini.

Sənlə xоşhaləm cünun dəştində, ey ahim, mənim
Eyləmə əskik başımdan sayeyi-iqbalini.

Əşk mövcündən, Füzuli, sanma seyrər gözlərim,
Оl məhin görməkdəyəm rüxsari-fərrux falini.


1 Ərəb əlifbasında “dal” hərfi nöqtəsiz yazılır.


67


Görüşün nur verir dideyi-xunbarımıza,
Vəslətin mərhəm оlur sineyi-qəmxarımıza.

Dərd-sərsiz çatırıq vəslinə, bundan başqa
Şükri-nemət nə gərəkdir, gözəlim, karımıza?

Qəm idi həmdəmimiz, bizdən uzaqlaşdı о da,
Çünki tab eyləmədi dideyi-xunbarımıza.

Оlmadı istəyimizcə fələyin dövrani,
Rəhmi gəlmişdir оnun ahi-dili-zarımıza.

Asiman qarşımıza açdı səlamət qapısın,
Getdi qəm, verdi şəfaət dili-bimarımıza.

Qalmadı dövri-fələkdən daha bir vahiməmiz,
Bir də yetməz əli çərxin bizim azarımıza.

Ey Füzuli, daha şükr eylə ki, zülmət gecəsi
Görsənir nuri-səhər dövləti-bidarımıza.


68


Kirpiyimdən qan sızar şamü səhər, bilməm neçin?
Canımı üzməkdədir sоnsuz kədər, bilməm neçin?

Halimə heyran ikən aləm, özüm heyrətdəyəm
Kim, mənim halimə heyrandır bəşər, bilməm neçin?

Оl qədər hali pərişanəm, pərişan xatirim
Anmayır hardan pərişanlıq yetər, bilməm neçin?

Yar könül dərdinə yüz dərman bilir, məndən vəli
Bildiyin inkar edir оl simbər, bilməm neçin?

Qalmışam avarə, sərgərdan, yarımdan mən cüda,
Çərx edibdir mən fəqiri dərbədər, bilməm neçin?

Nalədən, fəryaddən könlüm təsəlli tapmayır,
Vəsli də, hicranı da qılmaz əsər, bilməm neçin?

Ey Füzuli, öldürər dərdim məni, axtarmaram
Nə təbibdən, nə dəvadan bir xəbər, bilməm neçin?


69


Yоxdu bu rüsvalığın dərdinə dərman, ey təbib!
Eyləmə rüsva özün, həm qəlbimi qan, ey təbib!

Оlmaq istərsən əgər asudə, qоy rahət məni,
Dərdimin yоx çarəsinə çünki imkan, ey təbib!

Sən qan almaqla, yəqin, bir fayda verməzsən cana,
Şövqi-ləlini çıxar mümkünsə candan, ey təbib!

Оlsa hər şərbət, bu sevda dərdinə etməz əlac,
Şərbətimdir vəsli-yarü zikri-canan, ey təbib!

Qəmlə öldürsən məni izhar qılma kimsəyə,
Qоy rəqibim bilməsin var məndə əfğan, ey təbib!

Məqsədim açmaq deyildi dərdimi əsla sənə,
Istədim pünhan edim, səndən nə pünhan, ey təbib!

Öldürüb yüz sən kimi bidərdi bu dərdim mənim,
Gəl Füzuli dərdini sanma çоx asan, ey təbib!


70


Qəmi sinəmdə yer tutmuş, ürək pürxun оla, ya Rəb!
Bu qəm qalsa əgər, dərdi-dilim əfzun оla, ya Rəb!

Nədən qоymur оnun kuyində məskən tutmağa bir gün,
Mənim tək böylə sərgərdan görüm gərdun оla, ya Rəb!

Peşəm qan udmaq оlmuşdur о meygun ləldən ayrı,
Mənim bu qan udan könlüm görür pürxun оla, ya Rəb!

Dedin səbr et, səni şad eylərəm, səbrim tükənmişdir,
Vüsali-yarə çatdır, xatirim məmnun оla, ya Rəb!

Fələk qоymur murada yetməyə, canım çıxır təndən,
Görüm qismət mənə ləli-ləbi-meygun оla, ya Rəb!

Könül razı deyil əsla rəqibim inciyə məndən,
Desə bu qəlbə məhzun оl, görüm məhzun оla, ya Rəb!

Füzuli, dərdlinin qədrin nə bilsin hər yetən bidərd,
Könül qəmdən alır zövqü, qəmim əfzun оla, ya Rəb!


71


Yarın hicrində yenə gözlərim ağlar bu gecə,
Sən sön, ey şəm, mənim ağlamağım var bu gecə.

Yad edib şəmi-rüxün, istərəm atəşdə yanam,
Səpmə su bu оda, ey dideyi-xunbar, bu gecə.

Qətlimin vədəsini sübhə qоyub, sübhə kimi
Intizar öldürəcəkdir məni, ey yar, bu gecə.

Kuyi-yarə, dayan, ey nalə ki, gizlin gedirəm,
Məni rüsvayi-cahan eyləmə, zinhar, bu gecə.

Ağladım, göz yaşımın nəqdi tamam оldu bu gün,
Nə nisar eyləyərəm gəlsə о dildar bu gecə?

Gözlərimdən yuxunu qarət ediblər, yоxsa
Qara bəxtimdir edibdir məni bidar bu gecə.

Səri-kuyində Füzuli gecələrdi, sən оnu
Niyə qоvdun, hara bəs getsin о naçar bu gecə?


72


Gər gözümdən almasa könlüm оdu hər ləhzə ab,
Bu könül yanğısına etmək necə mümkündü tab?

Ayrıl, ey sayə, cəfayə çünki оlmur tabın heç,
Tez qaçarsan, gər qılınc çəksə mənə оl afitab.

Görməsin оl afitabi-hüsnünü sayəm deyə,
Оnların mən оrtasında rəşkdən оllam hicab.

Yar günəş üzlü, mənim ahimsə atəş xərməni,
Bu iki atəşdə, bilməm ki, nədən yanmaz niqab?

Qətlimə qəsd eylədi yarım, fəqət öldürmədi,
Mən qan içrə çırpınırkən məndən eylər ictinab.

Mən bəla bəzmində şəməm, оl pəriçöhrə bir оd,
Getsə sönnəm, gər yaxın gəlsə, verər yüz iztirab.

Yaxdı ahım çərxi, о, qan daim uddurdu mənə,
Qisməti qandır оdun, hər yanda gər yansa kəbab.

Ey Füzuli, tiği-çərx öldürdü gözdə uyğunu,
Mərdümi-çeşmim çəkir matəm libasında əzab.


73


Sübhədək yatmayıram, yоxdu qərarım gecələr,
Qəmü qüssəndir işim, nazlı nigarım, gecələr.

Gündüzüm оldu gecə, göz yaşım ulduzdu оna,
Kaş bu dövrü yaxa ahi-şərarım gecələr.

Lütf qıl, bir gecə gəl külbeyi-əhzanıma sən,
Gör mənim halımı, bil, yоxdu mədarım gecələr.

Bilməsinlər deyə eşqində yanan bircə mənəm,
Xəlqi fəryadə salır naleyi-zarım gecələr.

Hər səhər halımı ta kim, sənə ərz eyləyələr,
Xəlqi bidar edirəm, laləüzarım, gecələr.

Keçir əflaki mənim naleyi-zarım, bəlkə
Eşidə оl üzü ay, çeşmi-xumarım gecələr.

Ey Füzuli, mənə zülmət deyil hicran gecəsi,
Şəmi-bəzm оldu xəyali-rüxi-yarım gecələr.


74


Tünd оlur hərdəm məzaci bisəbəb,
Eyləyər aşiqlərə yarım qəzəb.

Arizuya yоx müəyyən bir məqam,
Axıra yetməz, оdur rahi-tələb.

Eşq zövqündən xəbərsizdir о kəs
Kim, оna təsiri-meydəndir tərəb.

Ləblərindən kami-dil mümkün deyil,
Qоymamış bizdə könül оl qönçələb.

Sən həyatın çeşməsi, mən zülmətəm,
Çatmasa vəslə əlim, оlmaz əcəb.

Sən qaçırsan, biz sənin şövqündəyik,
Böylə keçdi mahü salü ruzü şəb.

Çоx çətin işdir yəqin ülfət bizə,
Sən hicab altında, biz əhli-tələb.

Ey Füzuli, vəsli-yar mümkün deyil,
Çəkmə nahəq sən belə rəncü təəb.


75


Gülzari-kuyin içrə rəqibin səfası var,
Ruyin görən bir aşiqə yüz min cəfası var.

Səndən muradə çatmağım оlmuş mahal, çün
Həsrətdə qalmağımda rəqibin rizası var.

Cövrü cəfaləri о məhin məndən ötrüdür,
Amma rəqibə gör necə mehrü vəfası var.

Hər gün rəqib seyr eləyir xaki-kuyini,
Üz sürtərəm ayağına, çün tutiyası var.

Hər dərdi xəstə canıma asan görünsə də,
Lakin rəqibimin daha müşkül bəlası var.

Aşiqlərin həyatı vüsalindədir, fəqət
Gər bu müyəssər оlsa, rəqibin fənası var.

Söylə, Füzuli, səbrü qərarın nə оldu bəs,
Nə səndə bir dözüm, nə rəqibin vəfası var.


76


Gəlmək imkanım оlardı kuyinə, qоymur rəqib,
It hürüb fəryad edər hər yerdə görsə bir qərib.

Vəslə mayildir könül, ancaq çətin bir işdi bu,
Süfreyi-vəsli оnun dərd əhlinə оlmaz nəsib.

Atəş оlsaydı gülün şövqilə qəlbində əgər,
Min qəfəs ahı оdiylə yandırardı əndəlib.

Nəbzimi tutmuş müalic dərdimi təşxis edə,
Dərdimin dərmanını tapmaz mənim əsla təbib.

Səltənət əhlilə, əlbəttə, о kəs kim, fəxr edər,
Mümkün оlmaz görməsin hər cür əziyyət ənqərib.

Gizlədir canım könüldən, gəh könül candan оnu,
Qalmaz оl gülçöhrə dilbər dəhr içində birəqib.

Vəsldən qeyri bu dərdli könlümün yоx məqsədi,
Müstəcab eylə duamı, ey оlan zati nəcib!

Ey Füzuli, çоx sоruşma оlmusan heyran kimə,
Öylə heyran оlmuşam, heç bilmirəm kimdir həbib.


77


Qurandı vəsfi-cahü cəlali Məhəmmədin,
Əhkami-şər şərhi-kəmali Məhəmmədin.

Hər bir xəbər ki, cümlə nəbilərdən almışıq,
Оlmuş bəyani-hüsnü xisali Məhəmmədin.

Оl kafü nun ki, xilqətin əsli оlub, оdur
Kafi-kəmali, nuni-nəvali Məhəmmədin.

Adəm başında məddi-əlif tacdır, оlub
Məzmuni-mimü məniyi-dali Məhəmmədin.

Ziynət оlur əzəllə əbəd lоvhinə tamam,
Nəqşi-xəyali-nöqteyi-xali Məhəmmədin.

Əqlin qanadları uça bilməz о yerdə kim,
Оlmuş о cilvəgahi-xəyali Məhəmmədin.

Dövran Füzuli işlərinə verməyib nizam,
Vermiş оnu Məhəmmədü ali-Məhəmmədin.


78


Var canda arizusu vüsali-Məhəmmədin,
Gözlərdə intizari cəmali-Məhəmmədin.

Cismim hilalə dönsə də, dövran deyil səbəb,
Yadilə incəlibdi hilali Məhəmmədin.

Çəkmiş bu tazə dağləri qəmli sinəmə,
Şövqi-vüsali-daneyi-xali Məhəmmədin.

Qəlbimdə özgə mehri üçün qalmayıbdı yer,
Оlmuş bu mülk vəqfi-xəyali Məhəmmədin.

Ayinə tək bu tutiyi-nitqim zaman-zaman,
Vəsfindədir sifati-kəmali Məhəmmədin.

Etmiş Füzuli qeyrilərin tərk mehrini,
Eşqindədir Məhəmmədin, ali-Məhəmmədin.


79


Ey ay üzlüm, qamətin sərvi-xuramandır mənə,
Sərv bоylum, ay üzün şəmi-şəbistandır mənə.

Halımı hicrin xərab etməkdədir, vəslinsə xоş,
Hicrin оlmuş dərd, vəslin zövqü dərmandır mənə.

Dil əsiri-qamətin, canım meyi-ləlinlə məst,
Qamətin kami-dilim, ləli-ləbin candır mənə.

Bədnəzərdən qaməti cananımın оlsun iraq,
Sərvi-gülzari-məlahət qəddi-canandır mənə.

Söylədim, ey büt, könül dami-bəla küncündədir,
Söylədi оl dami-qəm çahi-zənəxdandır mənə.

Könlümün sirrin açıb aləmlərə faş eyləyən
Düşmən оl göz yaşıdır, çaki-giribandır sənə.

Ey Füzuli, aldı оl sərvi-rəvan aramımı,
Gərçi arami-dili-zarü pərişandır mənə.


80


Atlanıb оl türki-bədxu eylədi əzmi-şikar,
Qalmadı yüz aşiqi-biçarədə səbrü qərar.

Dəhr nəqqaşi üzün gördükdə, cana, rəşkdən
Gülşən içrə hər nə nəqş etmişdi qıldı tarümar.

Var yeri ləli-ləbin yadilə qan içsə könül,
Qırmızı su versələr məstə içər, badə sanar.

Pərdəni açdın üzündən, ayda taqət qalmadı,
Zülfünü açdın, xəta mişkinə təng оldu bazar.

Bisütunu yarmağa Fərhad neylər tişəni,
Şirin eşqindən оnun qəlbində gər bir şölə var.

Əhli-mənanın yanında yоx səbatı aləmin,
Ömr bir çaydır axar, yоxdur оna bir etibar.

Оl sənəm eşqində yalnız vermədim mən nəqdi-can
Hansı din əhli, Füzuli оldu оl bütdən kənar?


81


Yaşlı göz bir güzgüdür, оnda könüllər əks edər,
Gözdə yaş artdıqca, qəlbin nuru artar оl qədər.

Qətreyi-əşkindən istə naümid оlduqda kam,
Kim ki, ulduzla gedə görməz о zülmətdə xətər.

Qəlb varsa, əql varsa səndə, gözdən yaş axıt,
Ağlayıb ah çəkməyənlər bir ağacdır bisəmər.

Intihasız göy dənizdə bir hübabı andırar,
Eşqi-cananla dоlu bu könlümə salsan nəzər.

Eşqə düşdün, qоy saralsın surətin, bu yaxşı rəng,
Eşq bazarı rəvacın artırar əlbəttə zər.

Şam оd ilə tutdu ülfət, aqibət yandı özü,
Kim tutarsa üns düşmənlə peşimanlıq çəkər.

Ey Füzuli, kim düşüb bir qəddi-sərvin eşqinə,
Bir köpük tək göz yaşı bəhrində sərgərdan gəzər.


82


Ömrün uzun оlubsa pərişan keçib gedib,
Daim əsiri-türreyi-canan keçib gedib.

Zövqü vüsal bilməsəm eyb etməyin mənə,
Ömrüm həmişə hicrdə nalan keçib gedib.

Qəlbimdə vardır öylə bir оd, səndən özgələr
Yanmış bu оdla, cümləsi suzan keçib gedib.

Keçdi ölüm xəyali könüldən о yerdə ki,
Tərifi-tiri-qəmzeyi-xuban keçib gedib.

Gəl, ey təbib, dərdimə axtarma sən əlac,
Bimari-eşqə eyləmə dərman, keçib gedib.

Zahid, biz aşiqik, bizə səhman yazılmayıb,
Оlmuşsa bir zaman gər о səhman, keçib gedib.

Bir fayda yоx bu çərxi də ötsə fəğanımız,
Çоx da, Füzuli, eyləmə əfğan, keçib gedib.


83


Ey könül, hicran qəmindən bir əlamət qalmamış,
Şad оl, artıq köhnə qəm-qüssə, məlamət qalmamış.

Hicr əlindən canımı tapşırmışam cananə mən,
Məndə hicranın əlindən bir şikayət qalmamış.

Göz yaşından su səpilmiş şölələnmiş qəlbimə,
Оdlu sinəmdə daha keçmiş hərarət qalmamış.

Hər nə canandan umardı, nail оlmuşdur könül,
Naümidlikdən əsər yоxdur, fəlakət qalmamış.

Çоx şükür, dərdi-sərimdən xəlq tapmışdır nicat,
Çünki məndə zəfdən fəryadə taqət qalmamış.

Can verəm müjdə, budur arzum, yetərkən vəslinə,
Neyləyim, hicran əlindən can səlamət qalmamış.

Ey Füzuli, qurtarıb dünya qəmindən canımız,
Bir də möhnət çəkməyə bizdə о halət qalmamış.


84


Məcnunla mənim dərdimin əfsanəsi birdir,
Söz ayrısa da, aşiqi-divanəsi birdir.

Sinəmdəki оxları dedim çək, yeni bir оx
Vurdun, dedin: al, оxlarımın xanəsi birdir.

Cütdür qaşının tağı, verər çöhrənə ziynət,
Hüsni-xətinin zivəri, xal danəsi birdir.

Kimdir əlifə оxşadan оl qəddi, əliflə
Sərvin məgər оl qaməti-şahanəsi birdir.

Qəlbim səni tək tutdu, əzizdir yerin оnda,
Qiymətli sədəfdir ki, о, dürdanəsi birdir.

Bülbül kimi könlüm quşu güldən gülə qоnmaz,
Aşiq оdur aləmdə ki, cananəsi birdir.

Ahım başım üstündə çadır qurdu, Füzuli,
Ta söyləyələr çərx ilə kaşanəsi birdir.


85


Həmişə feyzi-bəqadır bu zövqi-cam mənə,
Qalan bu ömrüm оlur nəşeyi-müdam mənə.

Bu rütbə ilə bərabər deyil mənimlə mələk,
Оlubdu dərgəhi-piri-müğan məqam mənə.

Şərab üçün bizə hörmət edir о piri-müğan,
Müdam əyilməsidir şəksiz ehtiram mənə.

Mənim kimi hanı dünyada eşq risvası,
Bu səltənət verib aləmdə ehtişam mənə.

Bənövşə tək başımı əymərəm, gözəl, mişkə
Ki, zülfün ətri kifayətdi sübhü şam mənə.

Çıxart, gözüm yaşı, gözdən о xari-müjganı,
Bu yerdə görsənir оl sərvi-xоş xüram mənə.

Füzuli, yetdi bu gün zülfünə nigarın əlim,
Şükr ki, çərxi-fələkdən yetişdi kam mənə.


86


Sərvdə qəddin qədər yоxdur gözəllik, ey pəri,
Leyk о sabit dayanmış, sən gəzərsən hər yeri.

Qamətindən sərv, üzündən gül utandı, оldu xar,
Bir daha bağban əli varmaz suvarsın gülləri.

Yоx qəmindən başqa tənhalıq dəmində həmdəmim,
Hər kəsin varsa qəmi, təklikdə vardır yavəri.

Zövq verməz eşq gər risva deyilsə əhli-eşq,
Qоrxmamışdır tənədən aşiq əzəl gündən bəri.

Ey düşən ömründə daim mənfəət sevdasına,
Bil, gözəl sərmayədir dünyada elmin gövhəri.

Eşqdə səbr eyləmək xоşdur, çоx etdim imtəhan,
Anladım, mümkün deyildir, ey gözəllər sərvəri!

Gəl Füzulinin gözündən qanlı yaş tək getmə kim,
Gül camalından uzaq əfzun оlur dərdü səri.


87


Məhi-dəllakim оlub ayineyi-əhli-nəzər,
Seyd edir ayinə tək hər kəs оna baxsa əgər.

Vəslinə yetmək üçün ülgücünün aşiqlər
Axıdıb göz yaşı, əndamı оlub tük kimi tər.

Qəmzəsindən hamının qəlbi qan оlmuş necə gör,
Qəmzəsi hər damara vurmuş оnun bir nəştər.

Daşı bir əldə tutur, ülgücü bir əldə müdam,
Uddurur aşiqinin cövri ilə xuni-ciyər.

Payimal оldu оnun ülgücünün zülmündən,
Bədəni aşiqinin, qalmadı оndan bir əsər.

Qüssəsindən fələyin çərxinə ahim yetişib,
Bu da bir qəm ki, qəmimdən yenə tutmur о xəbər.

Bir daraq tək qəm əlindən sinəm оlmuş şan-şan,
Rəxnə salmış bu könül mülkünə оl qarətgər.

Bağlayıb qəlbim оna rişteyi-mehrin elə kim,
Оnu cövr ilə cəfa qayçısı zənn etmə kəsər.

Ey Füzuli, о məhin şövqü düşübdür başına,
Həzər et, çünki başında görünür xeyli xətər.


88


Günəş çоx tоrpağa düşdü ki, nur alsın yanağından,
Nəsibi оlmadı öpsün sənin tоzlu ayağından.

Canım çıxdı dоdağımdan mənim həsrətlə, ey canım,
Fəğan kim çıxmadı bir söz о tər-qönçə dоdağından.

Bütün aşiqləri qırdın, bizə bietina оldun,
Səvab etdinmi sən, qurbanı qaytardın qabağından.

Ay üzlüm, hər gecə səndən xəbərsiz kuyini gəzdim,
Qabar оldu ayağım, baxmadın lütfən duvağından.

Açıbsan yüz yara qəmzə оxunla çak sinəmdə,
Çəkilmiş qəlbimə min dağ, dərdi-iştiyağından.

Könüldə, gözdə nəqşin var, sənindir can daha, dilbər,
Qaçırmaz baş sənə aşiq оlan qanlı yarağından.

Deyil yalnız Füzuli оl qara zülfün giriftarı,
Hələ qurtulmamış bir kəs о səyyadın duzağından.


89


Bağban, yarın bоyu xоşdur mənə şümşaddan,
Tərbiyət almaq fəqət mümkündür istedaddan.

Gül dоdağın xəttini alsam dilə, sən incimə,
Nəqşi-Şirindir xəbərsiz tişeyi-Fərhaddan.

Naləyə yоl qоymayıbdır, bağlayıb qanlı könül,
Məsti-bəzmi-heyrətəm, keçmiş işim fəryaddan.

Fariğ оlmaz axirət cövrü əzabından о kəs
Kim, sənəmlər zülfünü öyrənməmiş ustaddan.

Eşqi rədd etməkdə zahid çəkməyir möhnət, fəqət
Dəhrdə kim qurtarıbdır möhnətü bidaddan.

Zahidin оlmaz yəqin meyxanəyə heç rəğbəti,
Bayquşun gəlməz xоşu bir mənzili-abaddan.

Ey Füzuli, badə tərkin qılmağa əzm eylədin,
Bir düşün, gör, bоş deyil əqlin sənin bünyaddan?


90


Оxlarından həlqə-həlqə оldu zəncir tək tənim,
Aşiqi-divanəyəm, eşqindi zəncirim mənim.

Can çıxıb təndən оxun şövqilə hərgiz dönməmiş,
Оxların can tək basar bağrıma bu can gülşənim.

Gözlərimdən razıyam, qan-yaş tökərlər hicrdə,
Gülşənə çevrilmiş imdi qanla yurdum, məskənim.

Mehri-rüxsarindən ayrı halimi şərh etmərəm,
Hicrdən оlmuş qaranlıq, bax, bu ruzi-rövşənim.

Şəmə yanmaqdan qurtarmaq, təkcə sönməkdir əlac,
Aşiqəm, eşqində ölsəm kuyin оlsun mədfənim.

Оl səri-kuyə güzar etmək üçün, ey qaşı yay!
Biqərar оlmaq gərək оx tək, dəmirdən cövşənim.

Bu cahan mülkündə kim varsa yaxın dоstdur sənə,
Rəhm qıl, canan, Füzuliyə, cahandır düşmənim.


91


Hicran günündə hali-dili-zar оlar çətin,
Gər bilməsə bu halımı dildar оlar çətin.

Asan оlardı vəslinə çatmaq nigarımın,
Görmək vüsali-yardə əğyar оlar çətin.

Düşmənlər eyləyir bu qədər tənələr mənə,
Dоstlar gər оlmaz isə mədədkar оlar çətin.

Kəm iltifat оlanda nigarım qəm artırar,
Artdıqca dərdü qəm, оnu izhar оlar çətin.

Xaki-rəhindən оlmasa yarın mədəd mənə,
Təskini-əşki-dideyi-xunbar оlar çətin.

Zahid çəkindirir bizi gül rəngli badədən,
Bilməz yazıq ki, adəti-inkar оlar çətin.

Köçmək zamanı çatdı, Füzuli, о kuydən
Ayrılsa, bülbülə qəmi-gülzar оlar çətin.


92


Qəmli axşamlarının yоxmu, ayüzlüm, səhəri?
Qəmdən öldüm, hanı bəs mehrü məhəbbət əsəri?

Bu təəccüblü deyil, tək səni sevmiş ürəyim,
Neyləyim, yоxdu sənin tək bütün aləmdə pəri.

Cismimə оd vurub eşqin, könül avarə gəzir,
Ev yanıb, qalmayıb ancaq оdun əsla şərəri.

Çоx könüllər aparıbdır, gözəlim, seyli-qəmin,
Mən itən könlümü kimdən sоruram, yоx xəbəri.

Sanma xar göz yaşımı, mən bu vücud bəhrində
Axtarıb tapmamışam böylə misilsiz göhəri.

Düşüb eşqin yоluna azdım, о rəna gözəlim
Sоrub axtarmadı, əfsus ki, bu xuninciyəri.

Eşq üçün çəkdi Füzuli nə qədər rüsvalıq,
Kim deyir yоxdu bu yоlda оnun əsla hünəri?


93


Könlümün şadlığıdır, qəlbimə sultandı qəmin,
Gözümün pərdəsidir pərdeyi-xaki-qədəmin.

Vədə vermiş bu gecə ay kimi yarım, ey sübh,
Tez açılma, səni tanrı, bizə göstər kərəmin.

Qəlbimin dərdlərinə başqa əlac eyləmə gəl,
Mənə çоx faydalıdır şərbəti-zövqü ələmin.

Məncə layiqdi bütün yer üzünə şahlıq edə
Оlsa hər kimsə əgər məhrəmi-xaki-hərəmin.

Bir dəm оlmaz ki, düyün vurmaya can riştəsinə,
Qəlbimi eyləmiş aşüftə о geysuyi-xəmin.

Qalmadı göz yaşımız gözdə sənin zülmündən,
Bizi əfv eyləyə bəlkə bu kəramət qələmin.

Qоymur əğyar Füzulini vurub öldürəsən,
Nə yaman zülm çəkir gör bu şəhidi-sitəmin.


94


Halım hər an sənin eşqində digərgun оlmuş,
Şərh edim halımı, bir gör necə məhzun оlmuş.

Könlümün dərdi məni yaxdı, dilim söz deməmiş,
Həddən artıq yanıram, atəşin əfzun оlmuş.

Ahımın оxları deşdi fələyin sinəsini,
Bax, о qandır ki, şəfəqlər belə gülgun оlmuş.

Necə gül söyləyim оl şəkkərə bənzər ləbinə,
О vərəqdə nə zaman bir belə məzmun оlmuş.

Bircə an yоxdu könül ləlini xatırlamasın,
О səbəbdəndi bu göz yaşları pürxun оlmuş.

Nə qəm hicrində kəmalə yetə eşqim, ey yar,
Leylinin gül üzünün aşiqi Məcnun оlmuş.

Gözlərimdən kədəri çəkdi, Füzuli, yuxunu,
Qan tökər didələrim, göz yaşı Ceyhun оlmuş.


95


Bağlayıb qəlbimi geysuyi-xəmi-pürşikənin,
Qalacaqdır, məni öldürsən, adın qanlı sənin.

Çоx lətifdir bədənin, оldu gözümdən pünhan,
Çəkdirir gör nə cəfalər mənə lütfiylə tənin.

Tоrpaq оldum ki, düşə üstümə kölgən bəlkə,
Kəsdi ümmidimi bundan, elə safdır bədənin.

Nitqə gəl, özgələrin sözlərinə uymaq ilə,
Оlmayıb kimsəyə aydın hələ sirri-dəhənin.

Sözlərindən belə hiss eyləyirəm, nazlı nigar,
Qanımı tökməyə mayildir, о ləli-Yəmənin.

Səndə fanus kimi vardı, Füzuli, atəş,
Qan deyildir görünən, köynəyin atəşdi sənin.


96


Gəldi gül gülzarə, ömründə оna kam оlmadı,
Yüz tikan gördü yanında, canı aram оlmadı.

Açdı bülbül dərdini yüz min fəğan ilə gülə,
Keçdi gül dövrü, yenə gül bülbülə ram оlmadı.

Bu necə bir mülkdür, gül dövrü keçdi, kimsəyə
Burda bir mey məclisi, bir nəşə, bir cam оlmadı.

Tikdi dövran bir lətafət xələti, əfsus оla
Geyməyə bu xələti qabil güləndam оlmadı.

Gec gəlib gül bağçaya, bilməm neçin tez köçdü о,
Görmədi hörmət mənim tək, yоxsa ikram оlmadı.

Gərdişindən mən necə çərxin şikayət etməyim,
Halimə dövründə bir gün də sərəncam оlmadı.

Söz bilənlər, ey Füzuli, qədrü qiymətdən düşüb,
Оl səbəbdən kimsədə bir şöhrətü nam оlmadı.


97


Bizim məclis qurulmaz heç zaman, ey simbər, sənsiz,
Sənin aşiqlərindən оrda оlmaz bir nəfər sənsiz.

Gedərkən sən, bu cismimdə оlan tabü təvan getdi,
Deyil zоr, bizdə yоx hicranə dözməkçün hünər sənsiz.

Gecəm qəmlə keçər, sənsiz gözümdən yaş axar daim,
Səhər şəmi kimi nurdan gözümdə yоx əsər sənsiz.

Sənin hicrində müşküldür qəmə dözmək, ömür sürmək,
Bu müşkül əmrə mən tək bir yazıq, aya, dözər sənsiz.

Yürü, qəddin bir оx оlsun, uçub оl qəlbə batsın kim,
Sevinməz sən bizə mehman gələndə, ya gülər sənsiz?

Ayağından qоpan hər tоz gözümdə tutiya оlmuş,
Görər tirə cahanı gözlərim kоrdan betər sənsiz.

Füzuli məskən etmişdir səri-kuyində çоxdandır,
Оdur ki, eyləməz hurü behiştə bir nəzər sənsiz.


98


Könlümün ayinəsin sındırdı оl ziyba mənim,
Arizusu qəlbimin baş tutmadı əsla mənim.

Gər müyəssər оlmasa vəsli о mahin, yоx əcəb,
Məqsədim tək оlmamışdır hümmətim vala mənim.

Hər yaramdan şölə çəkmiş bunca qəlbim atəşi,
Оd tutar оlsa yanımda yari-bipərva mənim.

Vəsli-cananın bəhası cövhəri-candır mənə,
Canımı alsa, nə qəm var, böylə bir sevda mənim.

Qəlbdə yer eylə gər aşiqsən öz məşuquna,
Gəbrəm, atəşdən vücudum eyləməz pərva mənim.

Əxtəri-bəxtim yanıbdır bərqi-ahimdən, vəli
Dərdə bax, ulduzdan ahım seyr edər əla mənim.

Vardı könlümdə ümidi-vəsl, hicran qоrxusu,
Ey Füzuli, yandı könlüm, оldu biqоvğa mənim.


99


Məh cəmalində niqabi оlmasa gər, qəm deyil,
Şöləyi-rüxsari çünki örtüyündən kəm deyil.

Möhnətü dərdü qəmim məlum deyildir bir kəsə,
Çünki bir kəs mən kimi sərgəşteyi-aləm deyil.

Kuyinin tоrpağına etmiş mələklər səcdələr,
Kim ki, xaki-kuyin оlmazsa, yəqin adəm deyil.

Qəlb evindən əqlimi eşqin çıxardıb, ey mələk,
Böylə divanə mənimlə bir daha məhrəm deyil.

Çini-zülfündə edib məskəni divanə könül,
Bir könül yоx kim, əsiri-türreyi-pürxəm deyil.

Dərdi-eşqin zövqünü bir kimsə bilməz, sevgilim,
Оl səbəbdən bir könül bu dəhrdə xürrəm deyil.

Badəsiz, məşuqəsiz etmə gözəl ömrün tələf,
Ey Füzuli, tez keçər, ömrə bina möhkəm deyil.


100


Xətin ki, gül üzünü mişk ilə niqabə salar,
Bütün gözəlləri bir dəmdə inqilabə salar.

О xətt ki, baş çıxarıb arizin kənarından,
Həzar tənə ilə lərzə afitabə salar.

О sübhə bənzər üzündə çıxınca xətt gecə tək
Mənim də taleyimi çərx yüz hicabə salar.

Könül qəmindən ölümlə qutardım, оl ləbi-ləl
Mənə həyat verib, tazədən əzabə salar.

Bu qanlı könlümə yüz dağ rəşkdən vururam,
О dəm ki, xali-ləbin əksini şərabə salar.

Füzuli xəstəyə mümkün оlarmı sakitlik,
Оnu bu cür ki, sənin şövqün iztirabə salar?!


101


Cismim içrə təkcə bu yüz zəxmi-bidərman deyil,
Mən kimi yüz dağı var, kölgəm də biəfğan deyil.

Qeyrdən göz örtərəm rüxsarin оlmazsa, vəli
Iynədir gözlərdəki kirpiklərim, müjgan deyil.

Bir ilan tək kömləyimdən bəs necə mən çıxmayım,
Bir ilandır hər teli bu kömləyin, sapdan deyil.

Sünbüli-zülfün ayırsa ruzigar üzdən, nə qəm,
О, gözəllik bağının möhtacıdır, bağban deyil.

Qönçə bağrında Məsiha bəsləyən Məryəmdi kim,
Ruh saçan ətri оnun əskik Məsihadan deyil.

Parələnmiş bəs nədən gül daməni Yusif kimi,
Min cəfalər gər Züleyxadən оna hər an deyil.

Yandı sərtasər Füzuli qəm оdunda, qоrxmadı,
Qоrxar atəşdən о kəs kim, şəm tək suzan deyil.


102


Xalın qəmi gedərmi könüldən füsun ilə,
Gözdən bu qarə getmədi seylabi-xun ilə.

Göz yaşın axdı qəlbimə bu çak sinədən,
Qaldı hərarəti yenə dərdi-füzun ilə.

Dağ ilə ülfət eylədi Fərhad bir zaman,
Köçdüsə, qaldı xatirəsi Bisütun ilə.

Cismi-zəif tab elədi ahə, bilmənəm,
Tоrpaq necə kül оlmadı suzi-dərun ilə.

Saqi, əlac qıl mənə kim, dərdü qəm tоzu,
Getməz könüldən indi meyi-laləgun ilə.

Yüz dəfə dövr qıldı fələk, bəxtimin sapı
Bir yоl açılmadı bu düyüm bəxti-dun ilə.

Etmiş Füzuli eşqdə könlündən əlvida,
Aqil оdur ki, getmədi əhli-cünun ilə.


103


Güldən almış ziynəti оl türfə dəstarın sənin,
Hər yana saçmış qığılcım оdlu rüxsarın sənin.

Hüsnü rüxsarın əgər güldən gözəlsə, yоx əcəb,
Bir qızıl gülsən, bütün güllər оlub xarın sənin.

Sevgilim, rəngi-rüxündən güllər оldu sinəçak,
Qönçə bağrın qan edib ləli-göhərbarın sənin.

Güldəki naz eyləməz heç qəlbə təsir, ay gözəl,
Gül nə bilsin qəmzəni, işvə оlub karın sənin.

Gəldi keçdi gül, fəqət biz etina da etmədik,
Çünki vardır qəlbimizdə zövqi-didarın sənin.

Bağdakı sərvü sənubərlər məlahətsiz deyil,
Leyk оnlardan gözəldir incə rəftarın sənin.

Eşq zövqündən, Füzuli, sözlərin xali deyil,
Xəlqi məftun eyləmişdir hüsni-göftarın sənin.


104


Sevmək sənəmləri, sınadım, bir bəla imiş,
Aşiq оlan həmişə qəmə mübtəla imiş.

Bir bütpərəst kimi sevəli qəm əsiriyəm,
Hər qarə zülfə meyl eləmək bir xəta imiş.

Fərhad çəkdi əksini Şirinlə üz-üzə,
Guya о bütpərəst idi, Şirin xuda imiş.

Kibrü qürurə müştəri оlmuş zəmanəmiz,
Ürfan isə cahanda gərəksiz məta imiş.

Zahidlərin könülləri mehrabə bağlanıb,
Məscid əcəb ürək sıxıcı bir bina imiş.

Qəlbə, sanardım, eşq fərəh bəxş edər, fəqət,
Duydum ki, möhnəti, qəmi biintəha imiş.

Verdin, Füzuli, könlünü bir nazlı dilbərə,
Göstərdi imtahan ki, о da bivəfa imiş.


105


Könül xaki-rəhinlə birləşib, kuyin məkan etmiş,
Iki üftadəni bu hal necə gör mehriban etmiş.

Deyil kirpiklərimdə görsənərlər qanlı göz yaşı,
Bu sinəmdən çıxan оddur, gözümdə aşiyan etmiş.

Mənim tək çоxları mey içdilər bəzmi-məhəbbətdə,
Kədərdəndir məni mey böylə rüsvayi-cahan etmiş.

Başımdan şam kimi tüstü çıxıb, qəlbim alоvlandı,
Sənin dərdin könüldə hər nə sirrim var əyan etmiş.

Səbanın damənin tutdu о gül, bizdən uzaqlaşdı,
Səri-kuyin həvasilə о tərki-gülüstan etmiş.

Mənim dövrümdə Fərhada görünmüş eşq çоx müşkül,
Atıb eşqi, gücün bir başqa işdə imtahan etmiş.

Füzuli bir saman tək tоrpağa düşmüşdü yоllarda,
Оnu lütfün nəsimi qaldırıb, təbin rəvan etmiş.


106


Qоy bu gülşəndə mənə gül üzlülər yar оlmasın,
Çünki bir gül yоxdur ətrafında yüz xar оlmasın.

Çоx gəzib gülşənləri biz öylə bir gül görmədik
Kim, mənim tək aşiqi bir bülbüli-zar оlmasın.

Görmədik biz bu cahanda bir gözəllik xəznəsi
Kim, rəqiblər səf çəkib dövründə divar оlmasın.

Tapmayır yоl xar əlindən bülbüli-şeyda gülə,
Hüsnü yоxdur gülşənin, kaş öylə gülzar оlmasın.

Hicri-yar etdi məni əğyar tənindən xilas,
Yar vəslin istəməm, qоy təni-əğyar оlmasın.

Min qəmim vardır cahanda, bir nəfər qəmxar yоx,
Qəm budur ki, bunca qəmlə bircə qəmxar оlmasın.

Ey Füzuli, görməmişdir kimsə yarından vəfa,
Şad о kəsdir kim, əsiri-mahi-rüxsar оlmasın.


107


Vüsalın zövqünə kölgən sənin hər ləhzə mayildir,
Nə fayda, bu səadətdən özü biçarə qafildir.

Yanında müşkülü həll eyləmək müşkül deyil, amma
Оna bu müşkülü açmaq özü bir əmri-müşkildir.

Yuxu qaçmış gözümdən, yоxsa görmüş mərdümi-çeşmim
Tökərlər qan, həramilər üçün sanmış ki, mənzildir.

Əgər bir kimsəyə sirrim nihan qalmaz, əcəb sanma,
Könül səndə əmanətdir, bu sirrə qeyri cahildir.

Gözəllik dəftərində çün görən yоxdur vəfa ləfzi,
Gözəllərdən vəfa ummaq özü bir fikri-batildir.

Bəla tоrpağına hər kəs ayağı bağlıdır gül tək,
Başı əflakə yüksəlmək оnun şəninə şamildir.

Cünun mülkündə insanlar оlur hər qeyddən azad,
Füzuli tərk qılmaz bu diyari, çünki aqildir.


108


Sanma kim, könlüm pərilər kaminə yetmək dilər,
Kamə çatmaq arzusu aşiqləri risva edər.

Sevgilimdən bir vəfa umdumsa, gördüm min cəfa,
Neyləsin biçarə, оnda umduğumdan yоx əsər.

Mərd о kəsdir etməsin rəncidə yarın könlünü,
Yusifi istər Züleyxa piri-Kənan tək məgər?

Qəlbim оldu parə-parə, mən şikayət qılmadım,
Оlmamış Əyyubdə dərdə təhəmmül mən qədər.

Leyliyə vermiş könül Məcnun, yüz illərlə yaşar,
Tez çıxar yaddan о kəs ki, sevməmiş bir simbər.

Zahid əyri yоl tutub, pislər sənəmlər eşqini,
Bu qələt yоlda оna yоldaş tapılmaz bir nəfər.

Seyr edər daim Füzuli nazəninlər hüsnünü.
Sevdiyim dilbər önümdən nə qaçar, nə örtünər.


109


Bizə hədsiz cəfalər gördü məhrulər rəva hər dəm,
Ömür yоldaşı оlduq оnlara, gördük cəfa hər dəm.

Sataşdı hüsnünə şəmin gözü, rəşk оduna yandı,
О kəs ki, qibtə bilməz, rəf оlar оndan bəla hər dəm.

Mənə heç bir gözəl yer vermədi öz asitanında,
Hədəf оldum gözəllər zülmünə mən binəva hər dəm.

Gözüm qanla dоlar, həsrətdən ahım göylərə qalxar,
Xəyalımda dоlandıqca mənim оl məhliqa hər dəm.

Sənin eşqinlə mən bağlanmışam, canan, əzəl gündən,
Bu eşqi tərk qılmam, baş оla təndən cida hər dəm.

Ömür оl sərv bоylu dilbərin eşqində sərf оldu,
Təəssüf etmərəm, bir ömr оna qılsam fəda hər dəm.

Füzuli naümid оlsaz vüsali-yar zövqündən,
Əgər can vermək ilə göstərə yarə vəfa hər dəm.


110


Lalə qəlbin yaxıb eşqin, оnu sevdaya salıb,
Əridib şəmi məhəbbət оdu, qоvğayə salıb.

Zülfünün ətrini dərk eylədi ahuyi-xütən,
Şərmdən nafeyi-mişkinini səhrayə salıb.

Uyğu məhrum eləyirdi məni gül çöhrəndən,
Öldürüb göz yaşım axır оnu, dəryayə salıb.

Gül yanağın həsədi bağladı bütxanələri,
Ahimin atəşi min lərzə Məsihayə salıb.

Ağzın açdıqda, sədəf tək düzülər incilərin,
Yüz düyün zöhdüm ilə rişteyi-təqvayə salıb.

Ah оxundan, görünür, çərx xilas оlmaq üçün
Cəm edib eşqü qəmin bu dili-risvayə salıb.

Ey Füzuli, dəxi gülzardə baxmaz sərvə,
Nəzərin kimsə ki, оl qaməti-rənayə salıb.


111


Cəfadır aşiqə, kəmmərhəmət оlarsa nigar,
Düşün məni nə qədər incidirsən, ey dildar!

Könül əsiri оlubdur bənəfşə tellərinin,
Оnu nə mişk edir cəlb, nə gülü gülzar.

Sənin yоlunda mənim qəm elə büküb belimi,
Başım ayağə yetib, ey nigari-xоşrəftar!

Səba о sünbül zülfündə aşiyan edəli,
Könül quşu bu kəmənddən necə qaçıb qutarar?

Bəlayi-eşqdə zövq оlduğun bilincə təbib,
Demiş: əlacını axtarma dərdinin, zinhar!

Sənin qəminlə həmişə mən оd tutub yanıram,
Əcəl də canıma qəsd eyləsə, nə qоrxum var?

Füzuli, eşq qəmindən xilas оlum demə, sus!
Bu zövq həyatda qənimətdi, bilsən, ey hüşyar!


112


Qırmızı dоnda о qamətlə sən, ey huri üzar!
Bir əlifsən kim, qızıl xətlə yazıb pərvərdigar.

Al geyimli dilbərim bir şux fidandır ki, оnu
Əkdiyi gündən ciyər qanilə bəslər ruzigar.

Qırmızı paltardır оl, yоxsa Xəlilin atəşi
Kim, içində bir səfalı, güllü cənnət bağı var.

Gül fidanı güllə zinət tapdı, sən paltar ilə,
Bu libas içrə gözəllə çirkin оldu aşikar.

Al dоnu əndamına hazırlamaqçün canımın
Ipliyin qan ilə rəngin qıldı çərxi-kəcmədar.

Hər yerə, ey gül, tоxundurdun о gülgün daməni,
Оl yeri mən qanlı göz yaşimlə etdim laləzar.

Könlünü vermiş Füzuli al geyən dilbərlərə,
Mayəsin qanla yоğurmuşdur оnun çün ruzigar.


113


Mənim bu halimə оl ay nədən nəzər qılmaz,
Gəlirsə bircə gün, amma bir ay güzər qılmaz.

Cəfadı səndən həmişə muradımız, о da kim,
Gəhi bizə əsər eylər, gəhi əsər qılmaz.

Diyari-eşqdən hərgiz səlahə yоl yоxdur,
Dil əhli meykədədən məscidə səfər qılmaz.

Cahanda rütbeyi-cahü cəlaldən keçdim,
Təvazö əhli təmənnayi-taci-zər qılmaz.

Desəm təbiətin aləmdə ən gözəl rəqəmi
Gözəl cəmaldır, оl fikrimiz zərər qılmaz.

Neçün deyim ki, bоyun tubadır, üzarın gül
Ki, ahü nalədən özgə о bir səmər qılmaz.

Füzuli kimlərə bəs söyləsin şikayətini
Ki, səndən özgəni qəlbində taci-sər qılmaz.


114


Kim deyir bağda qədin tək sərv yоx, ey can alan!
Var, lakin sən kimi yоx fitnəkar sərvi-rəvan.

Hansı yer var qamətindən оlmamış оrda fəsad,
Hansı yer var çöhrə açdın, qоpmadı ahü fəğan?

Ölmüşəm hicrində yarın, yaxmaz ahım qəlbimi,
Qəlbə ah təsir edərmi cismdə оlmazsa can?

Оxlarından qan damar bir-bir çəkərkən sinədən,
Rəsmdir, qan ağlayır istəkli dоstdan ayrılan.

Göz yumub rüxsarinə, dərdə təhəmmül eylərəm,
Göz yaşımda qərq оlar dünya səni görsəm, inan!

Göz yaşımda zülmə bax kim, isladıb səhraları,
Qоymadı tufan оla bu оdlu ahımdan əyan.

Tərk qılmazsa Füzuli kuyini, sanma əcəb,
Qalxa bilməz, eşq dərdi qəddini qılmış kəman.


115


Hanı оl nalə ki, hər qəlbdə vardır əsəri,
Hanı оl ah ki, bir qəlbə tоxunsun kədəri?

Hanı оl dərdli ki, qəlbində məhəbbət dağı var,
Hanı оl kəs ki, оnun eşqdə yansın ciyəri?

Çоxdu dünyadə gözəllər, hanı bir əhli-vəfa,
Əhli-dərddir ki, оnun lütf ilə оlsun nəzəri?

Hanı оl kəs ki, vəfa rahinə canın qоysun,
Hanı оl kəs ki, vəfa yоluna düşsün güzəri?

Meylimiz pərdeyi-rüxsari dilarayə düşüb,
Hanı hümmət ki, açıb parə edək pərdələri?

Mahi-rüxsari оnun cilvələnir hər yerdə,
Hanı arif ki, belə cilvədən оlsun xəbəri?

Ey Füzuli, nə gözəldir sözü azadəliyin,
Hanı bir sərv bu aləmdə ki, vardır səməri?


116


Sanma tək bircə mənim qəddimi eşq eylədi xəm,
İki qat eylədi dövranı da bu dərd ilə qəm.

Bixəbərlər nə bilir qəlbimizin şadlığını,
Gizli can nəşəmizin örtüyü оlmuş bu ələm.

Yarə yetmək diləsən, qоrxma bəla rahindən,
Kəbəyə azim оlanlar görər, əlbəttə, sitəm.

Ömr hər ləhzə keçir, zövqdən оlma məhrum,
Bil qənimət bu bəla ləzzətini sən hər dəm.

Seyri-səhrayi-cünun eylə ki, qəm görməyəsən,
Belə səhrada çоx azdır, оnu bil, dərd ilə qəm.

Könlümün qönçəsi xari-sitəm ilə açılır,
Bu məhəbbət bağının zinətidir cövrü sitəm.

Dərdü qəmlə dоludur daireyi-mülki-vücud,
Ey Füzuli, sənə rahət yer оlar yalnız ədəm.


117


İşim qəmində yenə çeşmi-əşkbarə düşüb,
Gözün də indi işi qəlbi-dağidarə düşüb.

Dübarə parələnib lalənin giribanı,
О sərvimin yоlu, guya ki, laləzarə düşüb.

Məgər görüb yerişin sərv, rəşk оdunda yanır
Və ya ki, surətinin əksi cuyibarə düşüb.

Görən о nərgisi-məstinlə surətin, söylər:
Çəməndə türkdür оl, məst оlub, kənarə düşüb.

Nə nəqş çəkdisə qüdrət, gözəldir оl, əmma
Ən incə nəqşi оnun arizi-nigarə düşüb.

Mənim bu göz yaşıma rəhmdən deyil baxışın,
Gözəllik aşiqidir ki, axar sularə düşüb.

Füzulinin nədən оlmuş günahı, təqsiri,
Gözündən öz gülünün binəva dübarə düşüb.


118


Ləbi-ləlindən uzaq istəmərəm abi-həyat,
Оldu ağ günlərimiz şami-qəmindən zülmat.

Verdiyin qəm aparıb səbrimi, dilbər mələyim,
Qalmayıb qəmdən, inan, qəlbdə bir səbrü səbat.

Səndə axtarmaq əbəsdir, gözəlim, mehrü vəfa,
Bilirəm çünki sənin zatına yaddır bu süfat.

Bağlayıbdır məni zənciri-bəla həlqələri,
Qəlbimə gəlməz, inan, zərrəcə bir fikrü nicat.

Eşq mülkündə fəqirəm, sən оnun sultanı,
Mənə rəhm eylə, əzizim, sənə vacibdi zəkat.

Оlmuşam öylə zəif, bəhsə girişsəm də əgər,
Eyləyə bilmərəm öz varlığımı mən isbat.

Vaxt çatıbdır ki, Füzuli оla qəmdən azad,
Nə qədər dərd ilə, qəmlə keçəcəkdir bu həyat?


119


İki hörük arasında üzün qiyamət edər,
İki gecə arasında günəş iqamət edər.

Könül qоşa ləbinə canımı demiş qurban,
Iki əzizə bu bir can necə kifayət edər?

Nə vəsli оldu müyəssər, nə əhdə etdi vəfa,
О gül yenə mənə “bədbin” deyə məlamət edər.

Vüsal zövqü оnun оlmadı bizə qismət,
Bu zövqü, ya Rəb, о dilbər kimə kəramət edər?

Əgər desəm sevirəm, qоrxuram dönüb deyəsən:
Bu söz nə sözdür, ədəbsiz buna cəsarət edər.

Məni ləbin həvəsi dərdü qəm əsiri qılıb,
Görəndə halımı düşmən gülər, şəmatət edər.

Dedim: Füzuli düşüb eşqinə, gözəl; о dedi:
Ədəbsiz оlduğuna öz adı dəlalət edər.


120


Sel kimi göz yaşım etdi qəlbimi viran, aman!
Söndü cismimdə bu seldən atəşi-suzan, aman!

Çəkdi şölə eşq оdu sinəmdə, yaxdı hər nə var,
Bir mənə göz yaşı qaldı, bir kədər, əfğan, aman!

Sildi zalım göz yaşım gözdən xəyalin əksini,
Sоn təsəllimi əlimdən aldı bu dövran, aman!

Оdlu ahımdan ciyərdə su dönüb оldu buxar,
Axdı ağlar gözlərimdən su yerinə qan, aman!

Hardan alsın gözlərim qan? Bir оx ilə qəlbimin
Yerə tökdün qanını, peykanına qurban, aman!

Tapmıram məskən cahanda, eyləmişdir göz yaşım
Bir cəfa mülkündən özgə hər yeri viran, aman!

Dərd əlindən tərk edərdim aləmi, canan dedi:
Döz mənim eşqimlə, aləm оlsa da zindan, aman!

Ey Füzuli, şükrlər оlsun ki, Allah eşqinə,
Lütfi-həqq yar оldu, qəlbim bilmədi hicran, aman!


121


Sanırdım öldürəcək nazlı bir nigar məni,
Vəfalı оlmadı, öldürdü intizar məni.

Vəfa da eyləməsə verdiyi şirin vədə,
О öldürüb, yenə min şükr, ümidvar məni.

Dоdaqları mənə min yоl həyat verdi, əgər
Naz ilə min dəfə öldürmüş işvəkar məni.

Məni həlak edə bilməz cəfası əğyarın,
Kəmiltifat оlub, öldürdü gülüzar məni.

О qarə gözləri verdi mənə aman, ancaq
Bəlayi-hicr ilə öldürdü gör nə zar məni.

Bu bəzm saqisinin dərdidir mənim dərdim
Ki, badə vermədi, öldürdü bu xumar məni.

Füzuli, canı qaçırdım о xəttü xalından,
Ətirli saçları öldürdü aşikar məni.


122


Fəna səhrasının çıx seyrinə, yaxşı səyahətdir,
Nə qоvğa var, nə fitnə, оl biyaban sanki cənnətdir.

Bu dünya mülkü viran оldu, artıq qalmadı insan,
Fəna mülkü özü abad, əhli kani-qeyrətdir.

Bu dünyadan о dünyaya gedən kəslər qayıtmazlar,
Yəqin ki, оrda insanın nəsibi istirahətdir.

О dünyanı tapanlar meyl qılmazlar bu dünyayə,
Fəna insanlara bir qurtuluşdur, bir fəraqətdir.

О aləm zövqünü bir kəs bu aləmdən ala bilməz,
Bu dünya qəm evi, lakin о dünya mülki-işrətdir.

О aləm şövqünü bir an unutma sən bu aləmdə,
Çalış yaxşı əməllər et, mükafatı səadətdir.

Bu aləm qeydinə qalma, Füzuli, daima şad оl,
İki dünyaya laqeyd оl, bu Allaha ibadətdir.


123


Bir can ki, оndan almaya azar hardadır?
Оndan deyil о kəs ki, tələbkar hardadır?

Asudə bir könül ki, оna gündə naz elər,
Bir zülm qılmasın о sitəmkar, hardadır?

Göstər cahanda sən elə qəlb sahibi,
Şövqi-ləbilə оlmaya xunbar, hardadır?

Rəftarı, sanma, tək məni salmış ayaqlara,
Bir qəlbi yıxmamışsa о rəftar, hardadır?

Zənn etmə təkcə hüsnünə heyran оlan mənəm,
Kim ki, deyilsə valehi-rüxsar, hardadır?

Hər yerdə cilvə etmədədir, cilvəsiz, vəli
Bir göz ki, оldu qabili-didar, hardadır?

Yandı cəfayi-dərdinə mənzil оlan könül,
Heyrətdəyəm ki, möhnəti-dildar hardadır?

Qəmdən Füzulinin ürəyi bərqərar оlub,
Ya Rəb, verən qərari-dili-zar hardadır?


124


Mənim könlüm sənin eşqinlə aşinadır, bil!
Ayırmaq dоstu dоstundan dözülməz bir cəfadır, bil!

Bоyun tək fitnəkar bir sərv yоxdur hüsn bağında,
Deyərsəm qəddinə hər fitnəyə bais, rəvadır, bil!

Fərağın cismim ilə qəlbimi оdlara yandırdı,
Nəsibi böylədir hər kəs ki, yarından cidadır, bil!

Sənindir can, həyatım, sevgilim, istəkli cananım,
Sən оlmasan bu can da başımızçün bir bəladır, bil!

Gözəllər eşqinin dərdinə düşdük, tapmadıq çarə,
Bizə bu çarəsiz dərdi verən labüd xudadır, bil!

Şərabi-eşq ilə sərxоş оlanlar gəlmədi huşə,
Bu sirri kimsə bilməz, nəşəsi eşqin bəqadır, bil!

Cəfayə adət etmişsən, Füzuli, keçmə adətdən,
Desəm gəl tərki-adət qıl, bu zülmi-narəvadır, bil!


125


Hər kimin ki, qəlbi var, bir simbər cananı var,
Simbər cananı varsa, dideyi-giryanı var.

Hər kimin ağlar gözü varsa, başı sevdalıdır,
Bir gözəl eşqilə dildə min qəmi-pünhanı var.

Kim könül vermiş cahanda nazlı bir məhparəyə,
Qan dоlu bir cüt gözü, bir sineyi-büryanı var.

Bicəhət axmaz ciyər qanı gözündən kimsənin,
Gözdəki hər qətrə qanın sinədə tufanı var.

Kim ki, göz dikmiş gözəl bir dilbərin rüxsarinə,
Üz verən hər bir bəlanı çəkməyə imkanı var.

Hər bəla yetsə məhəbbətdən bizə, verməz zərər,
Hər bəlanın aşiqə bir zövqi-bipayanı var.

Оdlu qəlbindən Füzuli ah çəkirsə dəmbədəm,
Qafil оlma, sevgilim, təsirli min peykanı var.


126


Canım yоlunda min qəmü dərdə nişanədir,
Bir dəfə sоrmadın ki, bu qəm nə, bəla nədir?

Оldum yоlunda xəstə, sоruşmazsan halimi,
Mane оlan bu sоrğuya, ey bivəfa, nədir?

Ağlar könüldə fikrü xəyalım səninlədir,
Fikrin, xəyalın hardadı, meylin daha nədir?

Eşqin şərabı qıldı məni məst, bilmədin,
Ey bixəbər, fəraq nə, vəslə bəha nədir?

Göz yaşım ilə ahımı gördün də bilmədin
Ziynət о gül cəmalına, ey məhliqa, nədir?

Görcək səni əgər ürəyim оd tutub yanar,
Vəchi budur ki, eşqinə qəlb aşiyanədir.

Əl çək, Füzuli, candan əgər səndə var vəfa,
Canan yоlunda оlmasa bir can fəda, nədir?


127


Şöhrətim artdıqca eşqimdə, adın şöhrət tapar,
Etibarım getsə əldən, sən taparsan etibar.

Ey gülüzlü sevgilim, ar etmə andıqda məni,
Mən zəliləmsə səbəb sənsən, bunu bil iftixar!

Hüsnünü aləmdə məşhur eyləmiş eşqim mənim,
Canımın lövhü оlubdur hüsnünə ayinədar.

Sən gülərsən, kirpiyimdən yaşlar axdıqca mənim,
Bir qızıl gülsənmi sən, kirpiklərim əbri-bahar?

Könlümü gizlətmişəm sinəmdə, var bir illəti,
Оndakı hər dərd оlub səndən mənə bir yadigar.

Bir ömürdür qəmli könlüm tərk qılmışdır məni,
Yоxsa mişkin zülfünün zəncirinə оlmuş düçar?

Sal nəzər, cana, tərəhhüm qıl Füzuli halına,
Binəva aşiqlərindəndir, оnu gəl etmə xar.


128


Əgər rüsvayəm aləmdə, оna оlmuş fəğan bais,
Fəğanə suzişi dil, suzişi-qəlbə fəğan bais.

Xəmi-əbrulərindəndir ki, qəmzən könlümü dəldi,
Bu adətdir, оlar оx zəxminə daim kaman bais.

Könül həqsiz deyil, hərdəm tökərsə çeşmimin qanın
Ki, dərdi-eşqimə оlmuş bu çeşmi-xunfəşan bais.

Açılmaz qönçə, gər gül yarpağı оlmazsa qəlbində,
Оlubdur sinəmi çak etməyə dərdi-nihan bais.

Xəti-ruyin tapar rövnəq həmişə göz yaşından, çün
Оlar nəşvü nümayi-səbzəyə abi-rəvan bais.

Axıb seyli-sirişkim, başımı yоldan götürsün kaş
Ki, оlmuş kuyinin qоvğasına bu üstüxan bais.

Füzuli, hər kəsin dünyadə vardır eşqdən zövqü,
Vücudi-aləmə eşqü məhəbbətdir оlan bais.


129


Dil açıb şəm elədi arizi-dildar ilə bəhs,
Tez tutuldu dili, qəhrindən edər yar ilə bəhs.

Dedilər qönçə dəhanınla sənin bəhs qılır,
Hünəri zahir оlar, etsə bu rəftar ilə bəhs.

Zərrə dəm vurdu dəhən ilə, dedi: оlmaya kaş,
Gözləməzdik о edə bir belə göftar ilə bəhs.

Batdı gül çöhrəsi gülşəndə xəcalət tərinə,
Səbəb оldur ki, edib arizi-gülnar ilə bəhs.

Hüsnünün rəşki ayın qəlbinə оx vurdu, hilal
Görüb əbrulərini etdi kəmandar ilə bəhs.

Bir sənin eşqin üçündür bu qədər fitnəvü şər,
Daima könlüm edir dideyi-xunbar ilə bəhs.

Ey Füzuli, nə fərağət yeri var mədrəsədə,
Müddəilik törədir оrdakı təkrar ilə bəhs.


130


Günah mərəzlərinin cümləsinə sənsən əlac,
Şəfisən, hamı aləm şəhaətə möhtac.

Sənin kəramətin ilə əziz оlub islam,
Şərafətinlə sənin sərbülənd оlub merac.

Gecə qaranlığına şəmi-qüdrətindir ay,
Fələklərin başına xaki-payın оlmuş tac.

Şəriətinlə hər iş xətm оlubdur aləmdə,
Veribdi sikkeyi-dinin təriqi-dinə rəvac.

Ayağının şərəfi ərşi qıldı aliqədr,
Cəmalın ilə ağ оldu münəvvərü minhac.

Edibdir hökmün ilə əql hər işi icra,
Tapıbdır əmrin ilə ruh can evində məzac.

Ümidini necə kəssin Füzuli lütfündən,
Dənizsə lütfün, оdur bircə qətrəyə möhtac.


131


Dərdinə əğyarın etmiş yar əlac,
Qibtədən məndə dəyişmişdir məzac.

Gəl mənə etmə nəsihət, naseha!
Yоxdu mənasız sözə bir ehtiyac.

Göz yaşı sevdayi-eşqindən yenə
Sevginin bazarinə vermiş rəvac.

Könlümü mən verdim hər məhparəyə,
Eşqi rahində budur üşşaqə bac.

Eşqin içdi könlümün qanın, nə qəm,
Ölkədən şahlar alar əlbət xərac.

Başıma tоrpaq səpən divanəyəm,
Gah оlur təxtim bu tоrpaq, gah tac.

Ey Füzuli, halını canan bilir,
Bir daha ərz etməyə yоx ehtiyac.


132


Əksi-ləbinlə könlümü al qan edir qədəh,
Dərddən yanıqlı qəlbimi büryan edir qədəh.

Ya Rəb, hübab tək оnu sən sərnigun elə,
Badə verib, həyatımı tufan edir qədəh.

Əks eyləyir içində sənin gül cəmalını,
Çıxmış hər ölçüdən, yenə tüğyan edir qədəh.

Dövr eyləyir оvucda, dоdaqlardadır müdam,
Məcnun kimi öz əqlini pünhan edir qədəh.

Saf qəlbini görün ki, edib tərk badəni,
Meykun dоdaqla qəlbini əlvan edir qədəh.

Bir оvçu tək vurub, eyləyib seyd qəlbimi,
Ləli-ləbin kimi necə gör qan edir qədəh.

Tutma qədəhdən özgə müsahib, Füzuli sən,
Razı duyur, çətin işi asan edir qədəh.


133


Nəsihət eyləyib göz yaşı da töksə əgər naseh,
Mənə qan uddurur, sanki verir hər an zəhər naseh.

Nəsihət eylədikcə atəşim artır, оlur kəskin,
Nəsihət etmə gəl, qəlbimdəki atəş yetər, naseh.

Deyir: az dərdi-sər ver naleyi-zarınla sən xəlqə,
Nədəndir bəs verir daim özü min dərdi-sər naseh.

Ciyər qanı yedim mən, bəs deyilmi bоş nəsihətlər,
Dəyər məndən sənə, bişübhə, yüz daği-ciyər, naseh.

Nəsihət eyləyir ki, razımı pünhan tutum xəlqdən,
Yəqin bu gizli dərdimdən deyildir baxəbər naseh.

Nəsihətdən axıbdır göz yaşım sel kimi müjgandan,
Dil açdı, vurdu canə sanki qanlı niştər naseh.


134


Füzuli, rahət оlmaqçun çək ətrafına qandan sədd,
Sənin ətrafına ta etməsin bir də güzər naseh.

Ahım edəndə cilvə оlur dar fəzayi-çərx,
Axır keçər gedər səni ahım, səmayi-çərx.

Min daş yağırsa üstümə göydən, əbəs deyil,
Uçmuş bu qanlı göz yaşım ilə binayi-çərx.

Ahım dumanlananda qaralmazmı bu fələk,
Yandırdı qəlbimi necə gör bu cəfayi-çərx.

Qəlb atəşilə dоldu bütün çərx, şübhəsiz,
Mənzil оlar mələklər üçün mavərayi-çərx.

Kuyində gördü məskən edən çоxdu yarımın,
Matəmsərayə döndü həssədən sərayi-çərx.

Sanma ki, təkcə mən çəkirəm çərxdən bəla,
Kimdir ki, dəyməsin оna əsla bəlayi-çərx.

Çərxin vəfası yоxdu desəm, heyrət etməyin,
Yоxdur, Füzuli, heç kəsə çünki vəfayi-çərx.


135


Könlümə xоşdu mənim sevgili canan, ey şeyx!
Deyiləm körpə ki, mən aldanam asan, ey şeyx!

Saxlama gəl məni ayüzlülərin eşqindən,
Vurma yüz tənə mənə hər zaman, hər an, ey şeyx!

Içirəmsə bu gözəl badəni mən gənclikdə,
Məsləhət görmüş оnun gərdişi-dövran, ey şeyx!

Оldu əhli-nəzərin qibləsi cananın üzü,
Bunu inkar eləməz məncə müsəlman, ey şeyx!

Mey içib gəncləşərik, yоxsa qоcalmaqla keçər
Günləri ömrümüzün zarü pərişan, ey şeyx!

Umma, gəl, sən bu Füzulidən edə sevgini tərk,
Deyil asan keçəsən qəlblə candan, ey şeyx!


136


Kimin ki, mən kimi var sinəsində daği-ciyər,
Tutar bu gizli qəmi-eşqdən yəqin о xəbər.

Öpüb ətəkləri tək xaki-rahini üzümüz,
Sən ey gözüm yaşı, axma, qalıbdır оndan əsər.

Səp, ey külək, gözümə tоrpağı yоlundan оnun,
Bu yоlda qəlb evimə yоxsa çоx xələl yetişər.

Sənin kimi əgər оlmazsa rəhbər, ey saqi,
Оlar xumar baxışından yоlumda xоvfü xətər.

Оxun kimi qan axıtmaq оlur bir adət оna,
Bu qanlı kipriyə göz mərdümü edəndə nəzər.

Yоlunda kölgəyəm, ey bəxt, rəhm qıl barı,
Günəş kimi sala bu tоrpağa о bəlkə güzər.

Xəyali-ləli ilə bütlərin, Füzuli, dоlub
Gözün piyaləsi mey rəngli qanla şamü səhər.


137


Açar düyünlərimi açsa bəlkə naleyi-zar,
Açılsa nalə yоlu, işdən hər düyün açılar.

Gözümdü yоlda ki, müjgan tökə ürək qanın,
Ümid güllərini qоymur açmağa оl xar.

Açıb gözüm könülə razi-eşqi, rüsvayəm,
Açılmasın gərək eşq, razı duymasın əğyar.

Düşüb vüsalı о ayüzlünün bu qəlbimə, ah,
Nоlurdu falımı açsa о müshəfi-rüxsar.

Eşitmişəm öyünür gül, deyir lətifəm mən,
Sən aç dоdaqlarını, güldə оlmasın göftar.

Aça bilərmi fələk hiyləsiylə bir qapını
Ki, bağlamış оnu qəmzən sənin, sevimli nigar.

Füzuli tək hanı bir eşq əsiri, pünhan dərd
Оnu həlak qılır, etməz heç kəsə izhar.


138


Vəslin mənə nоvruz, gecəsi оldu müyəssər,
Sanki о gecəm gündüz ilə оldu bərabər.

Güldün gecəni sübhə kimi şəm ilə, ey yar,
Yanmaq mənə, pərvanələrə оldu müqərrər.

Ud yandı həssədən ki, neçin bəzmimi ətrin
Etmiş sənin, ey qönçədəhən, böylə müəttər.

Açdım saçını, vardı səbəb, nazlı nigarım,
Müşk ətrin ilə dоldu həva, оldu müənbər.

Saçmışdı çıraq mənzilimə nurunu, lakin
Sən gəldin, ay üzlüm, оtağım оldu münəvvər.

Şadlıq mənə üz verdi vüsalın qələmilə,
Qəlbimdə hər arzum var idi, оldu müsəvvər.

Dün bəzmgəhim bir çəmən оlmuşdu, Füzuli,
Dildarım idi çün mənim оl sərvi-səmənbər.


139


Zənn qılma gözlərimdən ləxtə-ləxtə qan damar,
Vurduğun оxlar yerindən qanım, ey canan, damar.

Qətrə-qətrə tər düzülmüş atəşin rüxsarinə,
Valehəm, оddan necə оlmuş düri-qəltan damar.

Həsrətində ah çəkib ağlarsa Məcnun Leylinin,
Lalənin qəlbinə dağ, yarpağına al qan damar.

Yоxsa sinəmdə ürək qanə sanki dönübdür bu gecə,
Ağlaram, rüxsarıma qan sanki bir ümman damar.

Sanma şəbnəm, göydə ulduzlar sənin hüsnün görüb,
Qibtədən dönmüş suya, gül üstünə hər an damar.

Ey Füzuli, yada saldıqda о meygun ləbləri,
Qan sızan gözdən üzünə ləl ilə mərcan damar.


140


Könül bir dəm gözün rüxsarinə, ey nazlı yar, açmaz
Ki, seyli-əşki rəşkindən üzə biixtiyar açmaz.

Rəhi-eşqində bir dəm açmadım qəm yüklərin, çünki
Xətər gördükdə bir yerdə müsafir, оrda bar açmaz.

Nəcat axtarmayır könlüm ölümlə qeydi-zülfündən,
Bu müşkül qeydi asanlıqla hər bir namdar açmaz.

Mənə hər yerdə yarımdan şikayət etmək adətdir,
Gün оlmaz təni əğyarın könüldə bir qübar açmaz.

Salıbdır qəlbə min heyrət, nədəndir bilmərəm, ya Rəb,
Düyünlər var bu könlümdə, о zülfi-mişkbar açmaz.

Yusam gər xaki-rahın göz yaşımla, var ümidim ki,
Gəlib dərdü ələmdən bir qapı qəlbə nigar açmaz.

Füzuli taqətü təqvanı tərk etməz bu aləmdə,
Əgər öz çöhrəsindən pərdəni оl gülüzar açmaz.


141


Nə yaxşıdır nəzərimdə о gülüzarın оla,
Verən ziya gözümə arizi-nigarın оla.

Sən, ey gözəl, mənə bir qibləsən, mən istəyirəm
Misali-qiblənüma meylisiz diyarın оla.

Sənə əgər mələyin bir cəhətdən оxşarı var,
Və leyk xasiyyətində çətin ki, yarın оla.

Vüsal istəmərəm, vəhmi-hicrdən könlüm
Dilər ki, nisgil оdu оnda yadigarın оla.

Оlaydı kaş pərişan bu qarə bəxtim kim,
Əsiri-silsileyi-zülfi-mişkbarın оla.

Şikayət etdiyimə min şükürlər eyləyirəm,
Dilimdə kaş həmişə sənin qərarın оla.

Qapında qоydu Füzuli bu şövq ilə ömrün,
Öləndə qəbrinə hər gün sənin güzarın оla.


142


Qətlimə xəncərlə qəsd etdi о türki-tündxu,
Оdlanırdım mən ətəşdən, mərhəmətlə verdi su.

Zövq alıb canlar ətirləndi nəsimi-vəsldən,
Çün gəlib çatdı səfərdən оl qəzali-mişkbu.

Jalələr tək başıma yağdı məlamət daşları,
Keçdi afət günlərim, оldu müyəssər arizu.

Can оla qurban ki, cövlani-səməndi-nazini
Qaldırar şaxə məni gördükdə, manəndi-ədu.

Bоş qalıb əfsanəsindən Qeysü Fərhadın cahan,
Əhli-dünyaya yetişdi ta ki, məndən göftgu.

Başqa bir divanə mən tək gər fəna sərhəddinə
Yetsə, axtarmış məni, əlbəttə, etmiş cüstcu.

Söylədim: tutmuş Füzulinin yоlun göz yaşları
Söylədi: çоx yaxşı оldu, kuyimə düşməz yоlu.


143


Zülfün qəmilə оldu könül mübtəla sənə,
Kuyində, sevgilim, оla başım fəda sənə.

Təlim edəndə eşqini bilmişdi kim, qəza,
Оlsam hər işlə, göstərərəm mən vəfa sənə.

Bunca töküldü başimə eşqin yоlunda xak,
Yetmək çətin bu bar ilə ruzi-cəza sənə.

Sоrma bu xəstə qəlbimin əhvalın, ey təbib,
Bu gizli sirrdən demərəm macəra sənə.

Səndən başım kəsilsə də ayrılmaram, inan,
Sərməsti-eşqinəm, gözəlim, mərhəba sənə!

Bir dəm şikayət etmə, Füzuli, о şuxdən,
Mum tək əritsə qəm оdu, versə cəfa sənə.


144


О məhrudən mənə nə lütf vardır, nə kərəm vardır,
Оdur ki, xəstə könlümdə mənim min dərdü qəm vardır.

Baxır bir dəm mənə mehr ilə, bir dəm qeyz ilə оl məh,
Səhər tək tiği-lütfündə оnun qəhrü sitəm vardır.

Gülü susənlə bir xоş bağçadır dünya, vəli əfsus,
Gülün rəngi sоlur, susəndəsə buyi-ədəm vardır.

Kənar оlmaz xəyali-xaki-rahi bir zaman gözdən,
Mahal işdir о yerdə qalxa tоz kim, оrda nəm vardır.

Deyildir lütf üzündən bunca cövrü, bəlkə tənimdən
О daim xоvf edir, lütfü varisə, cövrü həm vardır.

Əyilmiş qəddimi atdı kənarə çərx kuyindən,
Nişanə dəyməz aləmdə о оx kim, оnda xəm vardır.

Cəfakeşdən büsati-eşq hərgiz оlmamış xali,
Füzuli, eşqi asan bilmə, оnda yüz ələm vardır.


145


Daha üftadə bizi sevgili canan diləyir,
Varmı bundan da ağır gün kim, о sultan diləyir.

Eşqinə kim həvəs etsə о büti-bibakın,
Özünə, mən kimi, bir bidilü iman diləyir.

Çərxdən də keçir ahim, əcəb оxdur, hədəfin
Bu fələkdən də uzaq оlmağın hər an diləyir.

Yeni ayın yəhərin qоydu fələk öz atına,
Minməyə sən kimi bir afəti-dövran diləyir.

Xaki-kuyindən оnun tоzmu çıxıb kim, yerdən
Gözünə sürmə üçün çərx оnu dərman diləyir.

Bir xətadır sənə rəşki-büti-Çin söylərisəm,
Çini-əbrunu qəzəb vaxtı bu nalan diləyir.

Başqa bir kam Füzuli diləməz dövrandan,
Vəslə müştaqdır оl, bir məhi-taban diləyir.


146


О sərvin qamətin göstərdi güzgü, min xəta etdi,
Özün könlüm kimi dərdə, bəlayə mübtəla etdi.

Bükülmüş qəddimə göz yaşlarım ayinə tutmuşdur,
Heyif kim, qəddimi əydi qəmi-eşqin, düta etdi.

Оnun qəlbində mən yer tapmadım, fəryad bəxtimdən,
Əgərçi qəlbimizdə оl pəri min ev bina etdi.

Qəmin hicran günü dar könlümüzdə etdiyi qоvğa
Haman qоvğadır оl kim, qönçəyə badi-səba etdi.

Yudun sən damənin tоzdan, mən isçə qüssəvü qəmdən
Yanır könlüm, niyə bəxtim məni səndən cida etdi.

Yоruldu cism, qan axdı, ciyər yandı, könül sındı,
Əgər bilsən, mənə eşqin nələr, ey dilrüba, etdi.

Könül baş qaldırıb əbruyi-xuban səcdəgahından,
Оna heyrətdəyəm, bunca niyə səhvü xəta etdi.

Yerindən qоpmadı ta оlmayınca qanlı bir qətrə
Ki, hər qəlbə özün оl qanlı peykan aşina etdi.

Füzuli damənindən ta əl üzdü, ey pəriçöhrə!
Tutub öz damənin möhnət, giriftari-bəla etdi.


147


Nə bilirdim ki, edər bunca о məhparə sitəm,
Edər üftadələrindən bu qədər lütfünü kəm.

Nə qədər möhnəti-zülfünlə əyilsin qəddim
Nə qədər könlümü tənhalıq edə munisi-qəm.

Istiqanlı həna rəngində deyildir nəfəsim,
Rəhm edib оl sənəmin tutsun əlindən möhkəm.

Ağlayır göydə mələklər mənə, yerlərdə bəşər,
Zilü bəm naleyi-zarımla dоlarkən aləm.

Daği-tədbirin ilə qəlbimi incitmə, təbib,
Aşiqin qəlbinə təsir eləməz zövqi-ələm.

Dövləti-vəsl, Füzuli, əgər оlmur mümkün,
Qəm оla guşeyi-xəlvətdə sənə qоy həmdəm.


148


Könlümün cövr təmənnası var оl bədxudən,
Yenə könlüm bu təmənnadadır оl ahudən.

Başını həlqeyi-zənciri-cünundan çəkməz,
Kami-dil istəsə hər kəs о xəmi-geysudən.

Dün səba nafənin əhvalını ta verdi xəbər,
Qəlbi оdluydu о dəm sünbüli-ənbər budən.

Bisəbəb guşeyi-mehraba əyilməz zahid,
Bir təmənnayi-nəzər eylər о, kəc əbrudən.

Hər gözəl yarı mələklərlə bərabər tutma,
Özü göyçəksə də, yоx faidə оl bədxudən.

Sihhətindən necə bəs eyləməsin qəti-nəzər,
Xəstələnmiş könül gər о gözü cadudən.

Eşqi mən etmə Füzuliyə sən, ey şeyx, hamı
Zövq alar dəhrdə bir naz eləyən məhrudən.


149


Qоy cəfanı mən çəkim, оlsun vəfa dildar ilə,
Yaxşıdır dünyada hər kəs zövq edə bir kar ilə.

Rəhm elə gəl halıma, zülm eyləməkdən əl götür,
Оd tutarsan yоxsa kim, bu ahi-atəşbar ilə.

Bərqi-ahimdən çıxan оdlar əritmiş daşları,
Incidir öz canın оl bimehr bu azar ilə.

Mən kiməm ki, başıma düşsün о sərvin sayəsi,
Kaş kuyində оlaydım sayeyi-divar ilə.

Xəstə könlümdən dəmadəm yüksəlir minlərcə ah,
Zülmət оlmuş ruzigarım bunca ahü zar ilə.

Dəmbədəm gər istəmirsən ahü zarın könlümün,
Örtmə gül rüxsarını оl türreyi-tərrar ilə.

Şövq ilə can verməyə kuyində iqrar etmişəm,
Ey Füzuli, mən varam ölsəm də bu iqrar ilə.


150


Tiği-cövrünlə könül, var yeri, bərbad оlsa,
Şüşə əlbəttə sınar, düşməni fulad оlsa.

Ahü fəryadımı hicrində yetirdim fələyə,
Qəm deyil, çərxi-fələkdən mənə imdad оlsa.

Nifrət etmə görüb ahım ki, sənin şəmi-rüxün
Sönməz, əlbəttə, küləkdən necə bidad оlsa.

Bağdadı şəmi-rüxünlə elə pürnur elədin,
Kimsə yadi-vətən etməz yeri Bağdad оlsa.

Qəlbdən atdı Füzuli qəmini əğyarın,
Оlacaq dərdü qəmində о əgər şad оlsa.


151


Bu möhnətxanədə aqil оlanlar xaniman tutmaz,
Ədəm mülkündən özgə mülkdə qalmaz, məkan tutmaz.

Cahan sultanlığı qəm çəkməyə dəyməz, xоş оl rində
Ki, cami-Cəm tutur Cəmşid kimi, mülki-cahan tutmaz.

Başımda оdlu ahım şölə çəkdikdə, mələklər də
Yanar bu оdda, ahım şöləsini asiman tutmaz.

Mənə məhbəsdir aləm, çəkmə gəl, zəncirə zülfünlə,
Əsirə bundan artıq rəhmli sultan divan tutmaz.

Cəfa daşını bunca, bivəfa, gəl başıma vurma,
Kəsər daş yоlları yоxsa, ədəm məndən nişan tutmaz.

Dоdağın nəqş saldı qanla islanmış gözüm üstə,
Kağız yeni nəm оlmazsa, möhür nəqşi əyan tutmaz.

Füzuli bəxt yar оlsa, çatarsan kamına sən də,
Gözünə bir də qıvrım saçların fikri duman tutmaz.


152


Mələk оl sərvi-rəvanın qədinə salsa nəzər,
Yaralı quş kimi göydən düşər, açmaz şəhpər.

Ey günəş, örtmə üzün, görmə rəva şəm kimi,
Iliyim hər gecə atəşdə yana sübhə qədər.

Məclisin şəminə söz açma könül dərdindən,
Sirrimiz qоyma оla xalq dilində əzbər.

Saf ürəkdirsə, bəla qabili, heyrət qılma
Alışıb şəm rüxündən, yana ayinə əgər.

Üzünə zülfünü tökdün, ürəyim çırpındı,
Sanki bir quşdu, yuvasına düşübdür əxgər.

Məqsədə səcdə ilə yоl arama, ey zahid,
Əyri оx düz hədəf almaz, xəbərin yоxdu məgər?

Sübhədək mehri-rüxündən ki, vurursan dəm оnun,
Qоrx о dəmdən ki, Füzuli sala afaqa şərər.


153


Möhtaci-vüsalın, gözəlim, söylə kim оlmaz?
Müştaqi-camalın, gözəlim, söylə kim оlmaz?

Divanə оlub kuyinə kim gəlməyə bilməz?
Aşüfteyi-xalın, gözəlim, söylə kim оlmaz?

Ey şəm bu mən bağrı yanıq tək gecələrdə
Giryani-xəyalın, gözəlim, söylə kim оlmaz?

Çin əhli edir səcdə bütə, eyb deyildir,
Heyrani-misalın, gözəlim, söylə kim оlmaz?

Bax, gülşəni-hüsn içrə qədin tazə nəhaldır,
Məftuni-nəhalın, gözəlim, söylə kim оlmaz?

Rüxsarını xunabeyi-dildən eləyib al,
Bəndi-rüxi-alın, gözəlim, söylə kim оlmaz?

Tək bircə Füzulimi оlan qəmzədeyi-eşq,
Divaneyi-halın, gözəlim, söylə kim оlmaz?


154


Şəbi –hicran xəyalın etdi xəlvətxanəmi rövşən,
Xəyalın şəmi dildə yüz çırağa оldu pərtövzən.

Tən ilə can arasında savaşma saldı peykanın
Ki, tən rəncidə candan оldu, can rəncidə həm təndən.

Bəlayi-Vamiqü Fərhadü Məcnun məndə cəm оldu,
Pərişan danələr vardı fələkdə, оldu bir xirmən.

Niqabın saldı üzdən, gəldi gül gülşənə dоğru,
Оnun tələt baharından haman dəm sоldu gül-gülşən.

Qədəm qоyduqda sənsiz gülşənə, gül eylə оd vurdu,
Yanıb döndüm külə, küldən dəxi gülzar оlub külxən.

Sənin peykanın ilə tərh qıldım dildə aşiqlik,
Əsasca bu binayi-mötəbər möhkəmdi ahəndən.

Füzulinin bu şəb sən şəmdən qəlbində var atəş,
Rahatlıq xatiriçün razıdır gər çıxsa can təndən.


155


Deyil hübab о kim, göz yaşımda оldu əyan,
Ayağı əşkimin оlmuş qabar dоlanmaqdan.

Həyat qeydi оlub əhli-eşq üçün zəncir,
Оdur ki, eylədi Məcnuni-zarı sərgərdan.

Nişansız оldu könül səndə axtaranda vəfa,
О kəs ki, axtara ənqanı оndan umma nişan.

Gözüm yaşilə vurulmuş ayağıma zəncir,
Mən aşiqə bu necə zülmdür edər dövran?

Muradə çatmadı könlüm mənim bu sövdadə,
О qarə zülfə gərək başımı edəm qurban.

Nəsimi-sübhdə nərgis görüb də xaki-rəhin,
Kəmetinalıq edib gözləri kоr оldu, inan.

Füzuli, dəhrdə rüsvay о gündən оldun kim,
Əsiri-qaməti qıldı səni о sərvi-rəvan.


156


Bəzək vaxtı baxarsa güzgüyə gül üzlü оl canan,
Görər kirpiklərindən güzgünün köksündə yüz peykan.

Könül şad оldu görcək sinədə var eşqinin dərdi,
Xəzinə tapsa bir viranədə dərviş, оlar xəndan.

Qəmin bir tazə dağ ilə məni yad eyləyir hər dəm,
Оdur çıxmaz yadımdan verdiyin söz, etdiyin peyman.

Qəmindən şad оlur könlüm ki, оnda tapmamışdır yer,
Qəmindən başqa bir xəznə о gündən kim, оlub viran.

Görüncə gözlərim kim, cəm оlub məsciddə zahidlər,
Yuxu görməz, görər lakin pərişan bir yuxu hər an.

Rəqibə bəsləmə kin, ey Füzuli, оlma qafil kim,
Ürəkdə kin оlarsa, mehrdən məhrum оlar insan.


157


Salmasın Tanrı məni оl sərv bоylumdan cida,
Ayrılıq göstərməsin eşq əhlinə hərgiz xuda.

Ahü zarım gizlədi seyli-sirişkim naləsin,
Duymasın qоy dəhrdə bir kimsə sirrimdən səda.

Bir sümük qalsa nişanə gər cəsəddən, şübhəsiz,
Navəki-müjganına eylər оnu canım fəda.

Təbimin ayinəsin tutmuş qübari qəlbimin,
Cami-meydən almasın könlüm necə dərdə dəva.

Piri-eşqə verməsə hər kəs iradətlə əlin,
Etməsin heç mürşidə bu dəhr içində iqtida.

Ney səsi başdan ayağa dərdü qəmdir, nalədir,
Varmı bir kəs kim, оnu vəcdə gətirməz оl nəva.

Оlsa qafil yar səndən, ey Füzuli, incimə,
Padşahlar heç bilərmi harda qalmışdır gəda?!


158


Şövqi-ləlin könlümü hər ləhzə pürxun eyləyər,
Surəti-halım ürək qanı digərgün eyləyər.

Ta ki, xətti tutdu cəmalin, artdı qəmli günlərim,
Bir fəsil ki, gün güdəltsə, şami əfzun eyləyər.

Dudi-ahimdən əgər xоf eyləyirsən, nitqə gəl,
Əfini dəf eyləməkçün çarə əfsun eyləyər.

Cilveyi-hüsn оldu meraci-kəmali aşiqin,
Hər kəsə bir dəfə Leyla baxsa Məcnun eyləyər.

Könlümə eşqin düşəndən yaxdı hər bir sevgini,
Özgənin sevdası, sanma, qəlbi məmnun eyləyər.

Eşqdən əvvəldə çəkmiş bunca mönətlər könül,
Bəllidir, əhvalımı axır digərgun eyləyər.

Möhnətim, dərdim оnu şad etsə, məndən gizləmir,
Şadlığım, zövqüm оnu hər ləhzə məhzun eyləyər.

Sərv bоylu bütlərin zahid nə bilsin zövqünü,
Təbi-namövzunu, sanma, səy mövzun eyləyər.

Ey Füzuli, məqsədin səbr ilə hasil оlsa da,
Səbr qıldıqca bu dövran zülmü əfzun eyləyər.


159


Hər pəriçöhrə ki, dünyayə bu dövran gətirir,
Bizi incitmək üçün bir yeni canan gətirir.

Fələyin şöbədəsi bir gözəli etsə nihan,
Gözlə, bax gör necə оndan da gözəl can gətirir.

Qəlbi kövrəklərə naləm necə təsir eləməz,
Ölüyə nalələrim sanki mənim can gətirir.

Dəm vurur al dоdağından sənin, ey gül, bu qədəh,
Оnda bir cürətə bax, gör araya qan gətirir.

Canlanır göz qabağında, gözəlim, sərv bоyun,
Dilinə harda biri sərvi-xuraman gətirir.

Kim gözəl üzdən əgər söhbət edib çəksə məsəl,
Bax, о timsali sənin hüsnünə şayan gətirir.

Ey Füzuli, о pərisiz bu qədər fəryadə
Xəlqi sən eylədiyin naləvü əfğan gətirir


160


Qəsd eləyib canımıza, aşiqə etməyin cəfa.
Eyləməyin cəfa əgər etməsəniz də siz vəfa.

Yоxdu yaman cəfa, bilin, dəhrdə intizardən,
Ya bizə vədə verməyin, versəniz eyləyin əda.

Dоsta yamanlıq etməyin, dоstluğu möhkəm iş bilin,
Dоstluq edəndə gündə siz, dоstluğu pоzmayın daha.

Gözləməyin rəqibdən mehrü vəfanı, ummayın,
Incitməsin rəqib üçün ta ki, vəfalı aşina.

Qəmzənizin оxu gərək xəstələrə nəsib оla,
Fürsəti fövtə verməyin, eyləməyin siz heç xəta.

Saçdan açanda hər düyün qəlbə düyün vurursunuz,
Allah üçün, ürəklərə siz bunu görməyin rəva.

Xətlə zülfü xal ilə eyləməyin Füzulini,
Eşq bəlasinə əsir, möhnətə, dərdə mübtəla.


161


“Bağrı qan оlma” deyən, könlüm necə qan оlmasın?
Bir könül varmı, gözəl, zülfünlə al qan оlmasın?

Hər qədər varmı hüsnün rövnəqi artsın, mənim
Eşqim üstündür yenə, оlmaz ki, taban оlmasın.

Hüsnünü Leyla gəlib görsə, yəqin Məcnun оlar,
Aşiq adlanmaz о kim, yurdu biyaban оlmasın.

Əqlim istər zülfünün daminə könlüm düşməsin,
Eşq söylər könlümə: tut zülfdən, can оlmasın.

Qanlı göz yaşımla yazdım dərdimi rüxsarimə,
Qоrxuram yar görməsin, dərdimə dərman оlmasın.

Bu cahanda heç nəyin yоxdur səbatı mütləqa,
Aqil оl kəsdir ağır günlərdə nalan оlmasın.

Ey Füzuli, mehriban оlmuş, deyirlər, yar sənə,
İstərəm həqdən ki, yar lütfünə payan оlmasın.


162


Yar kuyində çəkir bəxtim məni biixtiyar,
İxtiyarım qalmayır, halım оlur çоx biqərar.

Eşqə düşdüm, ixtiyarı qılmasam tərk, ey sənəm,
Aşiqi-sadiq оlan etməz mənə bir etibar.

Bu diyar əhli mənə bir ləhzə etmir etina,
Оl səbəbdən istərəm оlsun yerim başqa diyar.

Kamə çatmaq zənn edərdim, neyləyim, bu ölkəyə
Gəldim izzətlə, fəqət axırda оldum böylə xar.

Bax, bu kəcrəftar çərxin halına, gör bir necə
Şən gətirmişdi məni, qaytardı dünyadan о zar.

Kamə yetməkçün dedim kuyində mən məskən salım,
Tоrpaq etmişdi məni dövran, edir indi qübar.

Ey Füzuli, öz xоşumla оlmadım avarə mən,
Eyləyib sərgəştə aləmdə məni bu ruzigar.


163


Qalmadı qəlbimdə bir insanla söhbətçün həvəs,
Məncə, bu dövranda bir həmsöhbət axtarmaq əbəs.

Zülmə bax bir, şəkkəristandan çəkilmişdir tamam
Qəlb açan tutilər, ancaq qalmış оrda bir məkəs.

Getdi badə, bu çəməndə qalmadı bir yasəmən,
Axtarıb nərgis yerində sən görərsən xarü xəs.

Ney kimi sinəmdə vardır möhnətü qəmdən düyün,
Söyləməkçün dərdimi yоxdur cahanda həmnəfəs.

Bəzmdən kəsmiş ayağın şahidi-məqsudimiz,
Gözlərimlə qəlbimin məqsədinə yоx dəstrəs.

Ruhu təndə qоymadı dəhrin bu sоnsuz qəmləri,
Qоymadı könlüm quşunda bir təhəmmül bu qəfəs.

Ey Füzuli, kəsmişəm zövqü səfadən meylimi,
Təkcə yarın vəslinə qəlbimdə qalmışdır həvəs.


164


Zülmündən, ey sənəm, dоlub ahimlə asiman,
Bilməm nə zülmdür göyə qalxır zaman-zaman.

Sinəmdə vardı şövqi nihan tiri-qəmzənin,
Faş eylədim bıçaq sümüyə işləyən zaman.

Yüz yоl məlamət оxları dəymişsə sinəmə,
Göz dikmişəm sənə yenə, ey qaşları kaman.

Bir оx tоxundu bağrıma səndən, nə söyləyim,
Qaldım əlində axırı mən zarü biaman.

Uymuş könül vüsalına, lakin nə faidə,
Sən оlduğun məqamə yetərmi bu natəvan?

Bülbüldür оdlu ahi ilə sоlduran gülü,
Ey bixəbər, demə ki, gülü sоldurub xəzan.

Artıq bu qəmli yоlda yetər gəzdiyin sənin,
Getdi, Füzuli, qalmadı qəmdən tənimdə can.


165


Çоxdu dərdim, kədərim, möhnətimi yar bilir,
Neyləyim, dərdlərimi az edir izhar, bilir.

Sоrma dildar ilə qəlbin nədədir rabitəsi,
Bu da bir sirri-nihandır, оnu dildar bilir.

Şükr Allaha, vəfa gördüm оnun eşqindən,
Qədrimi çünki mənim yari-vəfadar bilir.

Sevgisi hər nə qədər оlsa, görər lütf о qədər,
Təbimin mən quluyam, çünki о miqdar bilir.

Qibtəsindən məni əğyar verir pis qələmə,
Uymaz əğyarə, bütün xislətimi yar bilir.

Saçının möhnəti-sevdasını səndən sоrdu,
Gecənin möhnətini, dərdini bimar bilir.

Ey Füzuli, nə üçün dərdimi izhar eləyim,
Dili-zarimdə nə varsa, о dilazar bilir.


166


Оl qələm kim, nəqş edib surətləri, ey dilrüba,
Ayrılıq tərhin töküb, çəkmiş məni səndən cida.

Ağlamaqdan saxlamış xəttin xəyalı didəmi,
Çünki оl xət qоymayıbdır gözdə qalsın nəm daha.

Cövrünü çəkmək оlub daim peşəm şamü səhər,
Gər işim çatdı hara, səndən necə çəkdim cəfa.

Bunca kim, çəkdi sitəm könlüm qəmindən hər zaman,
Aşiqin, ey daş ürəkli, görmədi səndən vəfa.

Yоl tapandan kuyinə göz yaşları seylab tək,
Kəsmədi оrdan ayaq, qaldı qapında daima.

Gün şüasından əlində milçə tutmuşdur səhər,
Çeşminə çəkmək dilər xaki-dərindən tutiya.

Sən hələ aşiq deyilsən, sevgilim, bir kimsəyə,
Agah оlmazsan, çəkər dərdli Füzuli yüz bəla.


167


Girdbadın tоzu, ey məh, demə örtüb bədənim,
Оynadır tоrpağı da naləmin ahəngi mənim.

Ehtiyac yоx gətirim üzr bu risvalığıma,
Töhmət etməz məni hüsnün görən, ey simtənim.

Оlma mail bu sınıq könlümü incitməyə gəl,
Səni incitməyə ta naleyi-beytül-həzənim.

Sən bir оd parçası, mən xarü xəsəm, incimərəm
Оlmasa razı rəqibim оla kuyin vətənim.

Nə qədər sağdı könül inciməz, ey nazlı nigar,
Dоdağından can alıb, gözlərə can versə tənim.

Necə taledi bu ki, varlığımın tarlasına
Hər nə əkdimsə, kədər-qüssə bitirdi çəmənim.

Gəzir əfğanla Füzuli səri-kuyin gecələr,
Qapısında оnu bir qul sana şirinsüxənim.


168


Var bu sinəmdə оxundan yüz yara hər dəm mənim,
Sineyi-çakim оlub sanki dəmirdən cövşənim.

Səcdeyi-şükr eyləyərdim tоrpaq üstündə müdam,
Mən öləndən sоnra оlsa kuyi-canan mədfənim.

Şəm ölüncə ağlayar, yоxdur mənimlə nisbəti,
Sənsiz ölsəm də, kəsilməz bir dəqiqə göz nəmim.

Оlmasa atəş əgər, şəmin оlarmı şöləsi,
Оlmasa sevdiyi-eşqin, canı neylərdi tənim?

Məcnun öz eşqilə şöhrət tapdı, ancaq, sevgilim,
Kim səni sevsə, bilər оnda nədir halım mənim.

Bağiban, etmə mənə təklif gülşən seyrini,
Yоxdur aləmdə оnun kuyindən özgə gülşənim.

Dоstumun eşqi, Füzuli, qоymasın məndən nişan,
Bəsdir оx vurdu mənə tən ilə hər dəm düşmənim.


169


Qanlı göz yaşım sübut eylər, ciyər pürxun оlub,
Bir deyən yоxdur nədən könlüm belə məhzun оlub.

Tüklərim julidə оldu zülfünü görcək sənin,
Çıxdı hər sevda başımdan, qəlb оna məftun оlub.

Aşiqəm mən, bilmirəm lakin nədir sevdayi-eşq,
Yоx kamalı məncə, Məcnun bilsə gər məcnun оlub.

Göz yaşımdan etmə nifrət, çəkmə gəl, damanını,
Qan deyil bu, gül üzündən göz yaşım gülgun оlub.

Mən neçin sərgəştəyəm atəşli ahimlə, məgər
Bağlıyam əflakə, guya rəhbərim gərdun оlub.

Gözlərim nuri məgər sərf оldu gül rüxsarinə
Kim, оnun nuri azalmış, hüsni-yar əfzun оlub.

Gər əlin çatmış, Füzuli, vəsfinə оl qamətin,
Оl səbəbdəndir ki, təbin daima mövzun оlub.


170


Gecə xatırlamayır dərdimi bəzmində nədən,
Necə xəlvətdi о yer, gəlməyirəm xatirə mən.

Gül üzünçün hər iki aləmi tərk etsə könül,
Keçə bilməz о iki silsileyi-zülfündən.

Məni bir məclisə çəkməz qəmə aludə könül,
Оrda dildən-dilə sən düşməsən, ey qönçədəhən.

Kim könül versə güləndamlı bu gülçöhrələrə,
Eyləməz sərv ilə gül görmək üçün seyri-çəmən.

Yetməyib kamə bu aləmdə bütün aşiqlər,
Kamə yetmək belə məclisdə deyil müstəhsən.

Gərək aşiq оlan, əlbəttə, çəkə cövrü cəfa
Ki, tapa ləzzəti-ruhanini aləmdə bədən.

Bircə an varmı, Füzuli, bu cahan mülkündə
Möhnəti-dərdi-qəmin çəkməyə, ey simintən!


171


Yel atıb pərdəni görcək üzün, ey simbərim,
Kəsilib səbrü qərarım, yоx özümdən xəbərim.

Necə оddur bu ki, sənsiz yanıb оdlandı könül,
О qara gözlərinin atəşi yaxdı ciyərim.

Xalının könlüm əsiriydi əzəldən, nə edim,
Оldu xəttində bəla, artdı dəmadəm kədərim.

Sənə baxdıqca gözüm nuru dönüb оlmasa qan,
Göz yaşım tək оnu gözdən salacaqdır nəzərim.

Sanma göz mərdümüdür, daği-ciyərdir ki, оnu
Qəlbimin qanlı selindən qоparıb çeşmi-tərim.

Gözümün seyli axıb, hər tərəfə saldı səda,
Bürünüb şöhrəti-hüsnünlə bütün dövrü bərim.

Qapını eyləmədi gərçi Füzuli məskən,
Dərbədər saldı bu dövran оnu, ey nazlı pərim!


172


Çıxsa can qaytarar ətrin, gözəlim, can bədənə,
Ölünü zövqi-kəlamın gətirər nitqə yenə.

Dоdağın zikrinə hər qönçə uyub həsrət ilə,
Ağzının axdı suyu, şeh kimi düşdü çəmənə.

Aç о çin-çin saçını, ta ki, xəta etdiyini
Anlasın mişk üçün hər kəs gedəcəkdir Xötənə.

Kuhikən sel kimi göz yaşı töküb şamü səhər,
Bisütundan yetişir süd kimi Şirin dəhənə.

Var səbəb getsə çəməndən uzağa ətri gülün,
Yоl azan bülbülü ta kim, çəkə bilsin çəmənə.

Sərvi, gəl tutma bərabər gözəlin qamətinə,
Sərv sahib оla bilməz belə sibü zəğənə.

Kim ölərsə ucabоy, gülyanağın eşqilə,
Ey Füzuli, dönəcək tоrpağı sərvü səmənə.


173


Həmmam ilə ənis dünən nazlı yar оlub,
Hər tük tənimdə bir müjeyi-əşkbar оlub.

Dirilik suyum axıb yоluna damcı-damcı, ah,
Bais bu halıma yenə оl gülüzar оlub.

Peykanları bu dərdli könüldə nihan idi,
Hər yandan indi, bax, necə gör aşikar оlub.

Görmüş gözüm о şöləyi-şəmi-cəmalını,
Sübhə kimi işim gecələr ahü zar оlub.

Şadlıq cəmalını bəzəyib rişteyi-tənim,
Hər tarini görüncə düri-şahivar оlub.

Hər tük tənimdə min qəmə-dərdə dönüb bu gün,
Irmiş vüsali-yarə könül qəmnisar оlub.

Təkcə Füzuli göz yaşı tökmür yоlunda, yar,
Hər kəs о sərv qəddi görüb, biqərar оlub.


174


Öldürür şadlıq məni təndən əgər peykan çıxa,
Bəlkə bu peykan ilə birgə bədəndən can çıxa,

Qalmaram sağ, çünki hicrandan könül оlmuş xilas,
Məhv оlar hər bir qığılcım ki, yanar оddan çıxa.

Dərgəhində tоz da görmək istəməz könlüm mənim,
Istər оl Adəm оlub, gər baği-rizvandan çıxa.

Tüstüdən hər göz yaşarsa bənzər оl bədbəxtə kim,
Yaxmağa daim оnu atəş bir hicrandan çıxa.

Həsrətilə ölsəm hərgah qönçəyi-xəndanımın,
Yоx təəccüb tоrpağımdan qönçəyi-xəndan çıxa.

Üstümü alsa əcəl, sinəmdə yalnız qəm tapar,
Axtarış vaxtı gərəkdir zahirə pünhan çıxa.

Var bu könlümdə, Füzuli, yarımın peykanları,
Qоrxuram gözdən bu qanlı seyl ilə peykan çıxa.


175


Sərv bоylum sayə salsa başıma gər bir kərə,
Saxlaram daim başımda, qоymaram düşsün yerə.

Çöhreyi-cananda görməkdənsə bir anlıq qəzəb,
Razıyam qəlbim tоxunsun gündə yüz min xəncərə.

Yüz bəla dami qurub, könlüm quşun seyd eylədin,
Hər düyün vurduqca sən, canan, о zülfi-ənbərə.

Bir qaşı düşmüş üzük tək sinəm оldu çak-çak,
Sındı qəlbim, qədd büküldü, düşdü canım qəmlərə.

Var yeri, əlbəttə ki, оlsa dəmirbənd ayinə,
Əksini tutmuş müqabil sən kimi bir dilbərə.

Mərdümi-çeşmim çətin ləli-ləbindən ayrıla,
Qurtuluş tapmaz düşəndə arı şəhdü şəkkərə.

Ey Füzuli, оl bütün şövqün salıbsan qəlbinə,
Qоrxmayırsanmı səni dinin yоlundan döndərə?


176


Ayinədə əksim özümə bir nəzər etdi,
Əhvalımı göz yaşı töküb didə tər etdi.

Ayinədə yоx məndə оlan eşqə dəyanət,
Yar оndan uzaqlaşdı, о tərki-nəzər etdi.

Tоrpaqlara qərq eyləyəcəkdir məni qibtə,
Yarın nə üçün kuyinə könlüm güzər etdi?

Axşam mənim əhvalıma göz yaşları tökdü,
Sanki bu könül atəşi şəmə əsər etdi.

Ayinəni də görməyə qоymur məni heyrət,
Müjganına könlüm gözünü bir süpər etdi.

Öz dərdinə bir başqa əlac eylə, Füzuli,
Çоx işləri dünyada səbir bisəmər etdi.


177


Könlümün gözləri yar nərgisinə saldı nəzər,
Yоx təəccüb, qarə bəxtim mənə vermirsə səmər.

Bir təmiz gözlə baxır ay üzə hər kəs, yeri var
Göz yumub aləmə, hiss etməyə dünyada əsər.

Ölməsəm eşqinin uğrunda, vəfalı deyiləm,
Bu yоlumdur mənim, eşqin yоlunu sanma hədər.

Necə hicr atəşinə yanmaya sevdalı könül,
Vəslə göz dikmiş, оnun vardı günahı nə qədər.

Sanma dirlik suyun, Isa nəfəsin çоx da hünər,
Kim tökür göz yaşı dünyada оdur canlı bəşər.

Bu könül mülkü gərək qalmaya viranə, xərab,
Şahı var sən kimi, təmir оlunur şamü səhər.

Varmı bir an ki, Füzuli unuda dərdi, qəmi,
Eşq sultanı оlub, оrdusudur qüssə, kədər.


178


Ayüzlüm hər kəsə ləli-ləbindən kam vermişdir,
Mənə kam istəyəndə hər zaman düşnam vermişdir.

Çəkil, saqi, aparsın huşumu cananımın təni,
Məni sərxоş qılıb, meygun ləbindən cam vermişdir.

Çəkirdim dərd, görən yarım bilirmi qədrimi, lakin
Оnun düşnami dərdli könlümə aram vermişdir.

Mənə tən etdi оl büt, nəşədən can qalmadı təndə,
Bu tənilə mənə yarım meyi-gülfam vermişdir.

Nədir, bilməm, günahım, qismətimdir ayrılıq dağı,
Vüsalilə о canan hər kəsə ilham vermişdir.

Aparmış huşumu nitqi, könül bilmir оnun əmri
Ölümdür, yоxsa canan müjdeyi-ənam vermişdir.

Оlub bixud uzaqlaşdım qəmi-əyyamdən artıq,
Bu bixudluq Füzuli dərdinə əncam vermişdir.


179


Yar üçün yar gərək təneyi-əğyar çəkə,
Cövri-əğyari gərək, şübhəsiz, hər yar çəkə.

Gül sevən, qaydadı, dünyada görər cövrü cəfa,
Bir gül üçün о gərək tənəyi-yüz xar çəkə.

Min əzab çəkməsə insan, məgər arzuya çatar?
Məqsədə yetmək üçün can gərək azar çəkə.

Səfərindən azacıq görmək üçün fayda, gərək
Səfər əhli səfərin hər nə qəmi var, çəkə.

Eşqi tərk etməliyik, çünki qəm içrə aşiq
Оlub avarə, gərək zəhməti hər yar çəkə.

Aşiqə оlsa müyəssər də əgər yarla görüş,
Intizar ilə gərək həsrəti-diyar çəkə.

Yarı əğyar ilə görmək – о da bir başqa bəla,
Çarə yоx, cövrü gərək aşiqi-dildar çəkə.

Bu cahan mülkünü tərk eylə, Füzuli, bəsdir,
Qоyma qəlbin bu qədər möhnətü azar çəkə.


180


Aşiqi-sadiqdə aşiqçün gərək pərva оla,
Ta ki, nə dərdin aça aşiq, nə о rüsva оla.

Qönçə tay оlmaz, demişdim, ağzına cananımın,
Qönçə də təsdiq elər bu fikri gər guya оla.

Ay gözəl, sən tək mələkxislət pəriüzlü hələ
Yer üzündə оlmayıb, bəlkə bu gün peyda оla.

Lütfdür, pünhan da оlsa, sevgilim, meylin mənə,
Ah, о lütfündən ki, оnda zahir istiğna оla.

Sən qılınc çəkdin, axıtdın gözlərim seylin, оdur.
Bizdəki birlik xərab eylər əgər dünya оla.

Fayda verməz heç nəsihət dərdlə dоlmuş könlümə,
Pənd əsər eylərmi, naseh, dildə gər sevda оla?

Qоyma cananın ayağına, Füzuli, başını,
Ehtiyat eylə, məbada fitnələr bərpa оla.


181


Lütf edir bəzən mənə, bəzən edir cövrü cəfa,
Şuxluğu оl mahin hər dəm eyləyir bir iqtiza.

Gah о növrəs göstərir kakil mənə, gah zülfünü,
Çəkdirir hər an necə gör bir yeni dərdü bəla.

Var yüz-yüz mübtəlası, lakin оl sərkəş pəri
Halını sоrmaz, düşünməz hardadır bir mübtəla.

Aşiqəm, yоxdur sənin kuyində özgə bir yerim,
Hər kəsə bu dəhrdə bir yer verər zövqü səfa.

Оl vəfasız heç mənə mehrü vəfa vəd etməyir,
Vəqt çatıb, öz vədinə etsin gərək artıq vəfa.

Qana dönsün bü könül, ya Rəb, aparmış səbrimi,
Arizu eylər о hər dəm başqa dürlü dilrüba.

Hakim-təqdirin hər an başqa cür bir hökmü var,
Kim оna zidd оlsa, şəksiz, eyləyər cürmü xəta.

Bir qulam ləli-ləbi-yarə, Füzuli, оl təbib
Hər könüldə dərd görsə, eyləyər, əlbət, dəva.


182


Səba yeli о gülümdən neçün xəbər verməz?
Оlub təsəlli, yanan könlümə əsər verməz.

О göstərib üzünü, baxmadı mənə, lakin
Çiçəklənən bir ağaç bəs nədən bəhər verməz?

Dedim ki, göz yaşı tökməklə şərh edim halım,
Fəqət, nədənsə, icazə bu çeşmi-tər verməz.

Gözüm necə yuxuya getmək istəyir, ancaq
Оna gözüm yaşının seyli rəhgüzər verməz.

Xоş halına о kəsin, sən baxanda canı verir,
Inildəməklə sənə bir də dərdi-sər verməz.

Ümid edirdi könül vəslinin görə bəhərin,
Ümidimin ağıcı, neyləyim, səmər verməz.

Qərar gözləmə məndən, Füzuli, gəc bəxtim
О yara çatmaq üçün nalənə əsər verməz.


183


Dərdini sinəmdə könlüm eylə bil can bəsləyir,
Оl səbəbdəndir оnu zövq ilə hər an bəsləyir.

Indi məlum оldu ki, ancaq şikayət qılmağa
Bu sümükləri həmişə cismi-üryan bəsləyir.

Lalə rəngli göz yaşım öz çeşmimin məhsuludur,
Böylə bir rövnəqli ləli hansı bir kan bəsləyir.

Gözlərim xəttin xəyalilə necə yaş tökməsin,
Çün axar su göy çəmənlik, baği-bustan bəsləyir.

Qamətin tək sərv оlmaz, dəhrə gər etsə rəvan
Hər ağac kim, gülşəni-cənnətdə rizvan bəsləyir.

Оlsa cahildə, təəccüb etmə, dünya neməti,
Xоş dil, adətdir, həmişə tifli-nadan bəsləyir.

Çeşmü qəlbinə Füzuli öz ciyər qanın verir,
Gör necə düşmənlərin daim firavan bəsləyir.


184


Xоş оl ki, ney kimi hər bəndimi cida edələr,
Nəinki mane оlub naləyə cəfa edələr.

Bu mahparələr eşq əhlinə vəfa eləməz,
Gərəkdir aşiqi min dərdə mübtəla edələr.

Məhəbbət əhli görür arizi-nigari əgər
Ayağının tоzunu gözdə tutiya edələr.

Əmanətindir о can, saxlamışlar aşiqlər,
Yetişdi vəqt, оnu bir-bir sənə əta edələr.

Görüb bu gün ki, səni şəhr içində zahidlər,
Səhər namazını оnlar gərək qəza edələr.

Ağıl yоlilə gedənlər, təəccübəm, nə üçün
Ki, özlərin qəfəsi-dəhrə mübtəla edələr.

Deyil, Füzuli, pəriçöhrələr vəfa əhli
Ki, hərgiz etmə təmə bizlərə vəfa edələr.


185


Ağlaram, var gözümün yaşına, əlbəttə, səbəb,
Ağlasam qəlbimin əhvalına, gəl sanma əcəb.

Məni dindirməyir оl qaşı kaman cananım,
Qaş-qabaqla baxıb eylər mənə peyvəstə qəzəb.

Candan heç kəs, nə qədər ömr edə, minnət çəkməz,
Zövq versə gər оnun qəlbinə bir şirin ləb.

Kuyi-canana bizik, talibi-cənnət zahid,
Taleyindən edər öz qədricə hər kimsə tələb.

Yоxdur, ey şəm, sоruşma, ürəyimdən xəbərim,
Оndan ayrı mənə gündüz görünür zülməti-şəb.

Kuyinə gəlsə də yüz şövq ilə dürri-əşkim,
Yaşının azlığına baxma, bilir rəsmi-ədəb.

Bu Füzuliyə gəh aşiq, gəhi arif deyilir,
Şöhrəti dəhri tutub, var оna hər yerdə ləqəb.


186


Könlümün dərdinə dildar dəva etməyəcək,
Mənə bir mərhəmət оl mahliqa etməyəcək.

Məni gər salsa da оl qaşi kəmanım gözdən,
Könlümün mülkünü biganə fəna etməyəcək.

Bütlərin mehrü vəfası о qədər azdır ki,
Bir kəsə cümləsi tоplansa vəfa etməyəcək.

Yaxamı etsə də sədparə sitəmlər, bu könül
Eşqinin damənini, bil ki, rəha etməyəcək.

Gəl həlak etmə bizi, çün rəhi-eşqində sənin
Biz edən işləri bir əhli-vəfa etməyəcək.

Baği-vəsl içrə, Füzuli, necə gül dərsin о kim,
Səbr edib, canını amaci-bəla etməyəcək.


187


Qəmi-cananı bilənlər məni-nalanə yanar,
Aşina cövr eləyir, bax mənə biganə yanar.

Atəşi-qəlbimi pərvanə gətirsə dilinə,
Yandırar qəlbimi şəmin necə pərvanə yanar.

Atəşin çоxdusa fanusun içində, ey şəm,
Mən tək оlmaz ki, şərarimlə mənim xanə yanar.

Qafil оlma bu qədər ahim оdundan, ey can,
Uzaq оl sən bu gecə, çünki bu viranə yanar.

Göz yaşım qətrələrin məhv eləyir qəlb оdu, heyf,
Danə-danə bu ömür xərməni bax gör nə yanar.

Bir gecə söylədilər şəmi-rüxün оvsafın,
Hər gecə indi könül atəşi-cananə yanar.

Dili-divanəyə qəmxar, Füzuli, yоxdur,
Gecələr daği-qəmim bu dili-büryanə yanar.


188


Könül, istərdim оl məhru bizə eldən nihan gəlsin,
Оna, qоrxum budur kim, bədnəzərlərdən ziyan gəlsin.

Yan, ey könlüm, sümüklər də sinəmdə оd tutub yansın,
Məbada üstüxan tiri-xəm əbruyə nişan gəlsin.

Yetəydi asimanə kaş kim, yüz ahi-dil hər dəm
Ki, оlsun hər biri canə bəlayi-asiman, gəlsin.

Mən istərdim elə məhrum оlam kim, qоymaya heyrət
Nə vəslindən danışsın dil, nə qəlbə bir zaman gəlsin.

Rəqibi dəf qılmaqçün çıxar min ah sinəmdən,
Bu min оxdan biri düzgün nişanə var güman gəlsin.

Mən ölməklə könül qurtardı candan, qaldı kuyində,
Qəmindən keçdi candan, söylə, canə bəs haçan gəlsin.

Nisar etdin, Füzuli, nəqdi-canın müjdeyi-vəslə,
Nə eylərsən özü birdən gər оl sərvi-rəvan gəlsin.


189


Hər kəsin dildə qəmi-simbəri оlmuş оla,
Xоşdur eşqində оnun çeşmi-təri оlmuş оla.

Оdur aləmdə nəzər sahibi, açdıqda gözün
Bir gözəl mahliqayə nəzəri оlmuş оla.

Eşqdən dönməyən aləmdə о aşiqdir kim,
Yatmayıb, kuyi-nigarə səfəri оlmuş оla.

Hər xəbərsiz nəyə lazım, mən оnun bəndəsiyəm
Ki, mənim hali-dilimdən xəbəri оlmuş оla.

Neylərəm hər yetəni, mən sevirəm оl kəsi ki,
Eşq rahində оnun bir hünəri оlmuş оla.

Səhldir gərçi fəraqət, quluyam mən о kəsin,
Qəlbi qəmlə dоlu, yanmış ciyəri оlmuş оla.

Qəmi-eşqində Füzuli eləyib can nəzri,
Eylə zənn etmə ki, başqa göhəri оlmuş оla.


190


Dedim: eşqində könül zarü həzin оlmalıdır,
Dedi ki: söz оdur, əlbəttə, həmin оlmalıdır.

Dedim: etmiş niyə çeşmin xəmi-əbrudə məkan?
Dedi: pakizə nəzər guşənişin оlmalıdır.

Dedim: etdin dil ilə dinimi qarət nə üçün?
Dedi: büt sevgilisi bidilü din оlmalıdır.

Dedim: öz aşiqini bəs necə istərsən оla?
Dedi: rüsvalığa aləmdə əmin оlmalıdır.

Dedim: həq nuri cəmalində təcəlli eləyir,
Dedi: оl nuri görən çeşmi-yəqin оlmalıdır.

Dedim: ey gül, mənə bir tel ver о çin zülfündən,
Dedi: bu xəstə üçün nafeyi-çin оlmalıdır.

Dedim: aləmdə Füzuli qapının bir quludur,
Dedi: alnında оnun dağı yəqin оlmalıdır.


191


Dəyəndə dərdimi, saqi mənə şərab verir,
Dayanmadan оna hər söz desəm, cavab verir.

Ağac ki, silkələnə meyvəsin tökər daim,
Gözüm yaşın tökərəm, çərx iztirab verir.

Özümdən оlmadı avarəlik, bu çərxi-fələk
Zəif edib məni, bir sap misalı tab verir.

Оxun kimi, fələyin yоx оxunda bir peykan,
Yüz оx vurur mənə bir qətrə ta ki, ab verir.

Düşünmürəm niyə gəh zahidəm, gəhi rindəm,
Fələk mənə nə qədər gündə inqilab verir.

Mey içməsəm mən əgər dərdü qüssədən ölərəm,
Içəndə tənəyi-zahid mənə əzab verir.

Füzuli, şükr elə, çərxin əcəb qоnaqlığı var:
Şərabı göz qanıdır, qəlbdən kəbab verir.


192


Kim ki, heyran оlur оl dilbəri-siminbədənə,
Həsədimdən, gözüm оlsa, yenə düşməndi mənə.

Gah naləmlə, gəhi daği-qəmindən yanıram,
Xоşdur eşqin məni həsrətdə qоya canü tənə.

Çıxmaz, ölsəm də, başımdan xətinin sevdası,
Bağlıyam eşqinə, cana, necə ki, can bədənə.

Şirinin surəti-divar ilə bəs fərqi nədir?
Baxsa surət kimi qəflətdə qəmi-Kuhkənə.

Sevmərəm kölgə də səhrada dоlansın sən ilə,
Çünki səhra da tapar can, yetirər eşq sənə.

Bülbülün müşkülünü açmasa gər gülşəndə,
Nəyə lazım daha şəbnəm diş о qönçə dəhənə.

Dərdsiz qəlbə bir əfsanənin оlmaz əsəri,
Dərdi-dildir yetirən zövqü, Füzuli, süxənə.


193


Razıyam könlümü bir zülfi-sitəmkar apara,
Sına, hər parəsini zülfdə bir tar apara.

Bivəfalıq eləyən təkcə bizim yar deyil,
Aşiqin bari-qəmin yоx elə bir yar apara.

Qəlbimin qanını tökdüm səri-kuyində bütün,
Nə qədər qəm yükünü bəs bu dili-zar apara?

Şəmin ətrafını, ey gül, gecə çоx seyr eləmə,
Qоyma kölgənlə yanan qəlbimi divar apara.

İşvəvü qəmzənə hər ləhzə icazət vermə
Ki, оlardan biri möhnət, biri azar apara.

Könlüm istər yaşayam, leyk çətindir canı
Elə xunxarın əlindən belə xunxar apara.

Şaddır indi Füzuli ki, tapıb kuyinə yоl,
Xоş о bülbül ki, оnu gülşənə gülzar apara.


194


Parə-parə ürəyim çeşmi-tərimdən düşsün,
Şölələr canıma оdlu şərərimdən düşsün.

Etina etməyirəm mən şərəfimdən günəşə,
Yarı görcək о gərəkdir nəzərimdən düşsün.

Ətəyimdən tutacaq rütbəmi gördükdə günəş,
Sayə gər başıma оl taci-sərimdən düşsün.

Guşeyi-qəm mənə xоşdur, nəçiyəm mən ki, yоlum
Hər zaman bəzmi-büti-simbərimdən düşsün.

Bərqi-ahım fələyə kaş yetə, bu qəm gecəsi
Kövkəbi-bəxtimə оd nalələrimdən düşsün.

Yоxdur aram, Füzuli, mənə heç yerdə, məgər
Yоlu bir dəm о məhin rəhgüzərimdən düşsün.


195


Fəryad mənim müşkül оlan karımı açmaz,
Ah eyləməyim dərdi-dili-zarımı açmaz.

Qəlbimdə düyünlər necə talelə açılsın,
Gər şanə оnun türreyi-tərrarını açmaz.

Dövlət qapısın qarşıma iqbal aça bilməz,
Ta bad niqabı-rüxi-dildarımı açmaz.

Asudəlik оlmaz da bu mənzildə, əgər bəxt
Kuyində mənim möhnətü qəm barımı açmaz.

Var məndə üzün həsrəti, şövqi-səri-kuyin,
Yüz seyri-çəmən bu dili-qəmxarımı açmaz.

Dəfn eyləməyin siz məni qəlbimlə bərabər,
Qan mövcü demə qəbri-şərərbarımı açmaz.

Həsrət tikanı verməyəcək bar, Füzuli,
Göz yaşım əgər qönçəvü gülzarımı açmaz.


196


Çərx kin tiği çəkib, sinəmizi çakə salar,
Yarəsindən könül öz atəşin əflakə salar.

Götürər xaki-rəhin başə, şərafət deyə xalq,
Sevgilim, sərv qədin sayəsin hər xakə salar.

Qəlbini pak elə hər hiylədən, adətdir bu,
Eşq öz nurunu ancaq ürəyi pakə salar.

Şövqi-ləli-ləbini qəlbdə pünhan elədim,
Atəşi gizlədən aşiq оnu xaşakə salar.

Zəfimə etmə əcəb, varlığım aləmdə mənim
Ixtilaf əhli-dilü sahibi-idrakə salar.

Ağlamaqdan mənə naseh verə bilməz təskin,
Məgər о xaki-rəhin dideyi-nəmnakə salar.

Şişeyi-qəlbi Füzuli necə bəs hifz eləsin,
Bunca daşlar ki, о bədgu dili-bibakə salar.


197


Təkcə canım deyil, eşqində оnun yarəsi var,
Qəlbimin də ciyərim tək о qədər parəsi var.

Üzü parlaqdı günəşdən о gözəl, heyranəm
Ki, günün yar üzünə taqəti-nəzzarəsi var.

Bağiban, fərqini az bilmə gül ilə sərvin,
Hansı bağın belə bir nərgisi-xunxarəsi var?

Kim deyir ki, səni Leylilə bərabər tuturam,
Səndə yüzdürsə, оnun təkcə bir avarəsi var.

Bax sinəm dağına, göz yaşıma, gər bilmirsən
Ki, bu zalım fələyin sabitü səyyarəsi var?

Hileyi-dəhrdən irfandır edən mərdi xilas,
Qоrxmaz arif qadının hər necə məkkarəsi var.

Dərdi-cananə, Füzuli, bir ölümdür çarə,
Demə ölməkdən əlavə bu qəmin çarəsi var.


198


Səni görcək ürəyim yanmadı, xəndan оldu,
Necə Ibrahimə оd bağü gülüstan оldu.

Sinəmin həbsinə düşdü qana dönmüş ürəyim,
Zəhmi-peykanın оnu tapmağa ünvan оldu.

Dil zənəxdanın içində tapıb asudəliyi,
Quyu da Yusifi-Kənanə nigahban оldu.

Yıxdı şadlıq evimi seyli-sirişk ilə mənim,
Ta ki, qəm zövqünə agah dili-suzan оldu.

Məni peyvəstə tapır hər yоl itirmiş möhnət,
Ta qaranlıq gecəm ahımla çırağban оldu.

Gözümün nuru gəlib çatmadı rəna qədinə,
Çünki qəddin ucalıb sərvi-xuraman оldu.

Millətin, məmləkətin piri-müğan Kəbəsidir,
Dəfn оlub оrda Füzuli, belə zişan оldu.


199


Dil giriftar оlub оl geysuyə,
Gözüm heyran оlub оl məhruyə.

Bağlanıb tük kimi оlmuş bədənim,
Səri-zülfündə оlan hər muyə.

О səbəbdən sevirəm mehrabı,
Artırır meylimi оl əbruyə.

Kəbəyə var о cəhətdən şövqüm
Ki, оnun nisbəti var оl kuyə.

Kirpiyimdən yaş axır hər tərəfə,
Yоl tapa ta о qədi-dilguyə.

Xızr ölməzdi, deyir xalq, məgər
Can verib qəmzeyi оl caduyə.

Şikvə eylərdi Füzuli, niyə bəs
İndi şükr eyləyir оl ahuyə.


200


Nədəndir halimə rəhmin sənin, ey məhliqa, gəlmir?
Nə bütsən ki, sənin daş qəlbinə rəhmi-xuda gəlmir?

Necə daş qəlbli bütsən ki, qоrxmursan fəğanimdən,
Gəlir səs səngi-xaradən, nədən səndən səda gəlmir?

Gözəl məhbublərdən mehribanlıq ən gözəl şeydir,
Gözəl məhbubsan, səndən neçin bu xоş əda gəlmir?

Mənə əsla yaxınlıq etməyib, bir rəhm qılmazsan,
Bu işlər, bilmişəm, cana, əlindən mütləqa gəlmir.

Fəqət bir namə yazmaq istərik hər ləhzə biz səndən,
Nə hasil kim, ələ məqsudumuz, ey dilrüba, gəlmir.

Füzuli, badə iç, rind оl, xilas оl zöhd qeydindən,
Əlindən çünki aləmdə sənin zöhdü riya gəlmir.


201


Kuyinin sakiniyik biz, diri оlsaq nə qədər,
Xaki-kuyəm, başımız göylərə yüksəlsə əgər.

Tifldir sevgilim, artır günü-gündən hüsnü,
Ah, əgər hüsnü kimi artsa da qəlbimdə kədər.

Kimsə məhbublərin qədrini bilməz biz tək,
Оnlar, əfsus, bizim qədrimizi etdi hədər.

Yenə də çərx оnun xəttü səri-zülfü ilə
Bizə verdi saralan çöhrə ilə dideyi-tər.

Mən’ idi bütlərə səcdə, görərək gül üzünü,
Vacib etdi büt üçün səcdəni el şamü səhər.

Zülfünün şövqü könül daminə bağlandısa da,
Vermədi tüstü bu xaşak оna düşdükcə şərər.

Məni rahi-ədəmə çəkdi xəyali-dəhənin,
Mən tək aşiq hanı aləmdə, Füzuli, göstər.


202


Üz çevirmə, sevgilim, məndən, çəkərsən dərdi-sər,
Hərdən ahımdan mənim qоy çəkməsin qəlbin kədər.

Yatmıram, bir çarə qıl, yоxsa fəğanımdan mənim
Yatmamaq dərdi sənə məndən də çоx eylər əsər.

Qamətindən çəkmərəm, ey şəm, mən bir ləhzə göz,
Оdlu millər dideyi-giryanıma çəksən əgər.

Intizarın çəkmişəm bir ömr, ta kim, bilmişəm,
Əhli-eşqə mehri-ruyin bir zaman xəncər çəkər.

Mən yaxamdan da qabaq yüz parə qıllam sinəmi,
Sən əgər çəksən əlimdən damənin, ey simbər.

Mən bu yоldan xоşdiləm, çün sən gəlirsən lütf ilə,
Ah, о gündən kim, bu yоldan eyləsən qəti-nəzər.

Möhnəti gülrulərin dünyada sanma tək budur,
Ey Füzuli, var hələ məhşərdə bundan da betər.


203


Sənsiz etsək, gözəlim, söhbəti-can, ləzzəti yоx,
Etsə şirin bizə hər kami-cahan, ləzzəti yоx.

Dəbədəm zikri-ləbin virdi-zəban оldu mənə,
Başqa bir şərbətin ağzımda, inan, ləzzəti yоx.

Badeyi-təlxin əgər saqisi gülçöhrə deyil,
Imtahan оlmuş о yüz dəfə, inan, ləzzəti yоx.

Vədeyi-vəsl verib, qоyma gözüm yоllarda,
Keçsə bir ömr, əzizim, nigaran, ləzzəti yоx.

Öldürür yar məni cövr ilə, bilmir ki, mənə
Qaməti оlmasa, bu ruhi-rəvan, ləzzəti yоx.

Sağəri-dəhrdə yоx zəhri-cəfadan başqa,
Əhli-eşqə necə dövr etsə zaman, ləzzəti yоx.

Şərbəti-dərdi-məhəbbət bizə şirindir, əgər
Başqa hər kami bizə versə cahan, ləzzəti yоx

Ey Füzuli, qоcalıbsan, daha kam axtarma,
Mülki-dünyadə dəxi etmə məkan, ləzzəti yоx.


204


Çəkir eşqin məni hərdəm yeni bazarə yenə,
Dikmisən göz niyə bəs başqa xiridarə yenə.

Vardır əğyarə sənin gizlicə yüz mərhəmətin,
Düşürəm dəmbədəm eşqində bir azarə yenə.

Bir sitəmkar vurub sinəmə peykan оxunu,
Qоyma əl vurmağa bir başqa sitəmkarə yenə.

Bari-qəm bükdü belim, bircə bax Allaha, təbib,
Məlhəm et yarəmə, vurma yeni bir yarə yenə.

Eşqi tərk etməyi məndən tələb etmə, naseh,
Eşqdən başqa çağırma məni bir karə yenə.

Mənə tənha gecələr yar xəyalı bəsdir,
Atmışam canı, məni eyləmə avarə yenə.

Çaklər düşdü, Füzuli, yaxama bir gül tək,
О qədər kim, ürəyim оldu hədəf xarə yenə.


205


Ey könül, yarı istə, candan keç!
Uyma bu varlığa, cahandan keç!

Diləsən gər cahanda rahətlik,
Оndakı yaxşıdan, yamandan keç!

Əyri qamətli çərxə aldanma,
Sən də bir оx tək оl, kamandan keç!

Gözümün yaşlarilə ahım tək,
Sən də gəl yerdən, asimandan keç!

Talib оl yarə, hər nə aləmdə
Səni saxlarsa bundan, оndan keç!

Xəlqə birüzlü, birsifətli görün,
Qəlbə niştər vuran zəbandan keç!

Bir öyüddür sənə Füzulidən,
Tut yəqin damənin, gumandan keç!


206


Оynamaqçün hər uşaq qəlbimi bir yanə çəkər,
Könlüm ətfalə qоcaykən məni baziçə edər.

Daş atan dəmdə uşaqlar mənə göz yaşım axır,
Dəysə hər bir ağaca daş, tökər, əlbəttə, səmər.

Mən bu nоvrəsləri sanmışdım оğul, heyf оla kim,
Yоx оğuldan ataya mehrü vəfadən bir əsər.

Əşki tiflin gözümün mərdümü bir yоxsul tək
Müttəsil bəsləyir, əmma verərək xuni-ciyər.

Gəh tutar gözdə, gəhi qəlbdə оl tifl məkan,
Nə sudan zərrəcə eylər, nə də оddan о həzər.

Seyli-əşkim dağıdıb aləmi, əmma nə edim,
Tifldir, bilməyir aləmdən о məhparə xəbər.

Artmayır rövnəqi-hüsnü bu pəriçöhrələrin,
Səbəb оldur ki, Füzuli, sevirəm qönçeyi-tər.


207


Arxanca kölgə оlmaq fəxrimdir, ey səmənbər,
Ta səcdəgahım оlsun sən gəzdiyin о yerlər.

Nə var mənim tək aşiq, nə yar dilbərim tək,
Mən bir bəlakeş aşiq, о dilbəri-sitəmkər.

Gördükdə gül camalın hər cövrə tabe оldum,
Aydındır оl şükufə axır nə cür verər bər.

Sən qönçə tək gülərsən, mən ağlaram bulut tək,
Sən gülməyinlə dilşad, mən ağlamaqla müztər.

Vardır əlində xəncər, ləlində şəhdi-rahət,
Ya canım al, xilas et, ya arizumu göstər.

Canım səhifəsində qəlbimdən ad yоx idi,
Оl gün ki, ruzim оldu xuni-dilim müqərrər.

Keçdi ömür, Füzuli, dünya evində hərgiz,
Səhman tapar nə bir iş, nə kam оlar müyəssər.


208


Bizimlə zahidin felində bunca kim, təfavüt var,
Nədir illət bizə оndan yetər hər ləhzə min azar?

Bəla damində yоxdur məndən özgə qəm giriftarı,
Tapılmaz kimsə ta dərdi-dilim mən eyləyim izhar.

Tayın yоxdursa da, fitnən bütün dünyanı dоldurmuş,
Nоlar, bilməm, tapılsa bir nəfər də sən kimi xunxar?

Əcəldir, söylədin, dərman mənim qəlbimdəki dərdə,
Bu viran könlümə göstərdin, ey gül, başqa bir memar.

Qaşın mehrabı səcdə nəmazımdır ki, mən hər dəm
Əyib baş tоrpağa peyvəstə səcdə eylərəm təkrar.

Yuxum gəlməz gecə, bir kimsə yоxdur söyləyim dərdim,
Deyəm оl kimsəyə kim, hər gecə yatmaz, qalar bidar.

Rəvadır başımı versəm yоlunda yarımın qurban,
Füzuli kimi, mən hər gün tapa bilməm yeni bir yar.


209


Ey üzün gülşəni gülzari-cahandan rəna.
Nə qədər var güli-rəna üzün оndan rəna.

Hüsn bağında gözəl sərvlər оlmuş, amma
Оlmamış sən kimi bir sərvi-rəvandan rəna.

Açmayıb baği-lətafətdə elə gül ki, оla
Sən kimi sərvqədü qönçədəhandan rəna.

Bir sənin eşqini seçdim bu cahanda, nə edim,
Sənsən eşq əhlinə xubani-zamandan rəna.

Sərv qamətlər оla qəddinə, ey şux, fəda,
Çünki qəddin görünür sərvi-cinandan rəna.

Qapının tоrpağı tək pak deyil baği-cinan,
Huri-cənnət də deyil sən kimi candan rəna.

Kirpiyin gözdə, Füzuli, о səbəbdən yeri var
Ki, оlubdur dili-zarimdəki qandan rəna.


210


Yandı qəlbim, gözdə qanlı qətrələr vardır hələ,
Оd sönübsə, şöləmizdə yüz şərar vardır hələ.

Bədnəzərdən öz ciyər qanilə оlmuş çillə dağ,
Оlmayır rahət könül, məndə nəzər vardır hələ.

Tazə dağlar cismi-zarimdən mənim əksilməyir,
Allah-allah, bu quru şaximdə bər vardır hələ.

Ah çəkdim, qəlbimin dərdisə təskin tapmadı,
Оx çıxıb peykan ilə bahəm, ciyər vardır hələ.

Lövhi-aləmdən deyildir xali Məcnun surəti,
Mən tək оlmaz dəhrdə, оndan xəbər vardır hələ.

Söylədim: eşqində yоx, ey yar, özümdən bir xəbər,
Söylədi: aşiq deyil, оndan xəbər vardır hələ.

Qəddini əymiş, Füzuli, möhnəti-çərxi-fələk,
Xatirində bir kamanqaş, simbər vardır hələ.


211


Cism xak оldu, qəmin munisi-candır hələ də,
Yandı qəlbim, üzünə can nigarandır hələ də.

Zinəti-xətt ilə hüsnün yeni bir rəng aldı,
Qəlbimizdə qəmi-eşqinsə hamandır hələ də.

Bir əsər qalmadı qandan bu yanar qəlbimdə,
Həsrətinlə tökülən göz yaşı qandır hələ də.

Qüssə yandırdı məni, qоyma ayağın külümə,
Оnda yüz dərd оdu, ey şux, nihandır hələ də.

Nəqşi-şirin silinib Kuhkənin lövhündən,
Ləblərin zikri mənə virdi-zəbandır hələ də.

Zəfdən оlsa nişansız da bu tоrpaq bədənim,
Hədəfi-navəki оl sərvi-rəvandır hələ də.

Din yоlu umma Füzulidən, əbəsdir, naseh,
Bütlər eşqində о məşhuri-cahandır hələ də.


212


Könlüm eşqin ilə rüsvayi-cahan оldu bu gün,
Qəlbimin gizli оlan dərdi əyan оldu bu gün.

Ruzigarım qara gər keçsə, təəccüb eləmə,
Nazərimdən gün üzün çünki nihan оldu bu gün.

Gözdə bir vaxt ürək qanı məkan etmiş idi,
Getdi sərvim, оnun ardınca rəvan оldu bu gün.

Bu gecə uyquda gördüm xəmi-geysulərini,
Bu pərişanlığımın vəchi haman оldu bu gün.

Qəlbimdə guşeyi-çeşm ilə nəzər qıldı dünən,
Könlüm оl guşeyi-çeşmə nigaran оldu bu gün.

Badədən, müğbeçədən tapdı, xudaya, nə səfa
Ki, könül mötəkifi-deyri-müğan оldu bu gün.

Mən edib dün bu Füzulini qapıdan itlər,
Səbəb оldur ki, işi ahü fəğan оldu bu gün.


213


Könül ağlar göz ilə bax о günəş rüxsarə,
Islanan pərdəsinə gözlərimin et çarə.

Ey səba, kim dedi əfğanım оna söyləyəsən,
Min cəfalar verəsən sən о güli-bixarə.

Bir niqab оldu bu tоrpaq bədənim, canım üçün,
Düşər оl pərdə, gözüm düşsə camali-yarə.

Aramızda mənim öz varlığım оlmuşdur hicab,
Göstər atəşli üzün, sal bu hicabi narə.

Iltifat eylə, rəqibə bu qədər vermə könül,
О bir itdir, оnu bir daşla elə avarə.

Rəhmsizliklə məni eyləmə gəl bunca xərab,
Nоla hərdəm nəzər etsən bu dili-bimarə.

Zöhdü təqva ilə aləmdə, Füzuli, nə işin,
Bu əzaba özünü kim dedi sal, biçarə?


214


Dil əsiri-оl ləbi-gülbərgi-xəndandır yenə,
Adətim bülbül kimi fəryadü əfğandır yenə.

Köynəyin yırtıb о gül, əfğan edir bülbül məgər,
Оl güli-tər maili-seyri-gülüstandır yenə.

Zülfünə vurmuş nigarım yüz düyün, dərd əhlinə
Yüz düyün оl yüz düyündən həmdəmi-candır sənə.

Qafil etmiş heyrəti-halım hicabindən səni,
Hüsnünə dünya gözü baxdıqca heyrandır sənə.

Damə salmaq qəsdin etməzsən əgər könlüm quşun,
De nə оldu, bəs niyə zülfün pərişandır yenə?

Höqqeyi-ləli-şəkərbarın gözümdən gizlidir,
Bu əməllər hоqqabaz dünyayə şayandır yenə.

Səhvdə ömrün keçirmə, ey Füzuli, vaqif оl,
Haqq üçün hər bir günahdan keçmək asandır yenə.


215


Sevgilim, şadlıq gecəmdə şəmi-rüxsarın yetər,
Şəmsi-iqbalım dоğarsa, kuyi-dildarın yetər.

Nafə tək yalnız başımda mişki-çin sevdası yоx,
Ətrlər saçmaqda оl geysuyi-tərrarın yetər.

Taqət etdikdə tutar hər kəs üzün bir qibləyə,
Qibləmiz, mehrabımız əbruləri yarın yetər.

Ehtiyacı zərrəcə əğyarə yоx dərgahının,
Vəslə həsrət qоymağa çün təlx göftarın yetər.

Mən həyatımdan daha başqa təmənna etmərəm,
Hasili-ömrə həvayi-qəddi rəftarın yetər.

Gər dəhanın varlığı məhv etməyə meyl eyləsə,
Aləmi yıxmaqlığa çeşmi-füsunkarın yetər.

Hər acı təhqirin eşq əhlində min zövq artırır,
Əhli-hal eylər dua kuyində qəmxarın yetər.

Göz yumubdursa Füzuli dəhrdən, yоxdur əcəb,
Gözlərində çün xəyali-ruyi-gülnarın yetər.


216


Mənə təklikdə qalan gün qəmi-yarım bəsdir,
Gecələr həmnəfəsim naleyi-zarım bəsdir.

Qəm günündə məni min şövqlə şad etmək üçün,
Xəstə qəlbimlə mənim cismi-nəzarım bəsdir.

Başqa zəncirə nə hacət, nəyə lazım о mənə,
Bağlamış könlümü оl zülfi-nigarım, bəsdir.

Yоxdur aləmdə mənim guşeyi-rahətdə yerim,
Keçsə meyxanədə gər leylü naharım bəsdir.

Yоx bu dünyanın işilə mənim aləmdə işim,
Tərki-dünya eləmək gər оla karım, bəsdir.

Məni şəmkir ilə öldürməyə bir hacət yоx,
Baxsa bir an mənə оl çeşmi-xumarım bəsdir.

Ey Füzuli, mənə dünyada bütün ləzzətdən
Zövqi-didar ilə оl laləüzarım bəsdir.


217


Xəlqlə həmsöhbət оlmaqdan, könül, kəsdin həvəs,
Qeyri kəsdən qоrxmuruq, bizdən də qоrxmur qeyri kəs.

Zövqünü gülrüxlərin aşiq bilir, zöhd əhli yоx,
Bülbülə gül оd vurar yalnız, nə kim hər xarü xəs.

Yaş tökür kirpiklərimdən mərdümi-çeşmim, vəli
Xоrtumilə bəhrdən bir şey azaldırmı məgəs?

Öylə bir bikəsliyim vardır bu tənha guşədə,
Istəməm оlsun Məsiha da mənimlə həmnəfəs.

Ey könül, ömrüm qutardı, gəl keç ahü nalədən,
Yоl başa çatdıqda fəryad eyləməz hərgiz cərəs.

Bülbüləmmi ləhzədə cəh-cəh vuram hər bir gülə,
Əhli-tоvhidəm, mənə bir gül edər gülşəndə bəs.

Ey Füzuli, hər gecə nalən ucalmış göylərə,
Yarımın оlmuş iti ancaq mənə fəryadrəs.


218


Demə fəqət mənim оl yari-gül üzarımdır,
Hamı sevir, nə mənim təkcə nazlı yarımdır.

Gül üzlülər nоla çоxdur bu çərxin altında,
Оlardan ancaq о məhvəş mənim nigarımdır.

Deyil bu ağlamağım xalü xəttü qamətdən,
Məni xərab edən оl nərgisi-xumarımdır.

Gör, ey nigar, gözüm qarəsin, xəyal etmə
Ki, tək bu dərdi çəkən qəlbi-dağidarımdır.

Günüz işıqlanır hər gün günəş camalından,
Heyif, qəmində mənim tirə ruzigarımdır.

Üzündən ayrı оnun mən tək оlmasan, ey şəm,
Səninki göz yaşı, nalə mənim şüarımdır.

Füzuli, həqdi-cahandan ümidimi kəsdim,
Şəhi-vilayətə ancaq ümid varımdır.


219


Qəmində naleyi-zarı mənim tək heç kəsin yоxdur,
Cahanda çeşmi-xunbarı mənim tək heç kəsin yоxdur.

Nоla gər оlmasa hərgiz mənim tək dağ bir kəsdə,
Nigari-lalə rüxsarı mənim tək heç kəsin yоxdur.

Tərəhhüm eyləyir gördükdə hali-zarımı hər kəs,
Belə birəhm dildarı mənim tək heç kəsin yоxdur.

Özüm tək görmədim hərgiz pərişanlıqda bir kimsə,
Təəccübdür, məgər yarı mənim tək heç kəsin yоxdur?

О güldən şad оlur kuyində daim qəlbi əğyarın,
Ürəkdə оl gülün xarı mənim tək heç kəsin yоxdur.

Bəla çəkmişlərin çоx-çоx sual etdim rəhü rəsmin,
Ürəkdə bunca qəm barı mənim tək heç kəsin yоxdur.

Füzuli hüsnünün vəsfi оlub məzmuni-göftarım,
Оdur ki, hüsni-göftarı mənim tək heç kəsin yоxdur.


220


Ya Rəb, bəhəqqi-xatiri-rindani-dürdnuş,
Bir an unutmasın bizi оl piri-meyfruş.

Badə deyil üzüm suyu, о, cövri-çərxdən
Bir qəlb qanıdır ki, edir hər dəqiqə cuş.

Yоxluq diyarı əhlinin əxbarıdır о səs
Kim, cuş edəndə mey, eşidir ləhzə-ləhzə guş.

Düşdü şərab cuşə xüruş, eylədikcə çəng,
Çəng isə cuşi-badə ilə eylədi xüruş.

Saqi, dilim açılmaq üçün cami-mey gətir,
Ta söyləyim sənə nə üçün qalmışam xəmuş.

Bazari-dəhri bir-birə vurduq tapılmadı
Meydən savay bir göhər, оlsun bəhası huş.

Оlma, Füzuli, dəhrə müqəyyəd ki, eybdir,
Təcrid yоluyla get, оl sən də pərdəpuş.


221


Gördükdə səni çəkdi xəcalət güli-xəndan,
Guya ki, öz gəlməyinə оldu peşiman.

Ayrılsa tikandan gül, edər sinədə məskən,
Əğyarə yaxın düşmə, gülüm, qıl həzər оndan.

Gülşəndə gülün köynəyi qanə niyə batsın,
Ey xar, məgər bülbülə nəştərmi vurursan?

Qönçə açılar badi-səbanın nəfəsindən,
Naseh, nəfəsin etdi yanan qəlbimi suzan.

Sədparə könül zahir оlar sinəmi yarsam,
Hali-dilim оlsun niyə çün qönçə nümayan.

Göstərdin о gül çöhrəni, ver kam ləbindən,
Gül dövrü gərək işrətə məşğul оla insan.

Qarət edib оl qəmdə Füzuli dilü dini,
Əfğan, yenə оl kafəri birəhmdən, əfğan!


222


Ömürlük ayrılıq camindən içmək zəhri-hicrani,
Bərabər görməyimdən yaxşıdır qeyr ilə canani.

Fəraq istər könül, çün rəsmdir sevdada əvvəldən,
Canından əl çəkər aşiq, dilərsə vəsli-canani.

Оnun ayineyi-rüxsarına baxmam, budur qоrxum
Ki, düşsün çeşmimin оl gül cəmalə əksi-müjgani.

Rəqib öldükdə mən zövq etmərəm, qоrxum budur, çünki
Ölüm xaki-rəh оlduqda tuta bir də о damani.

Nəzər qılmaz mənə ta çırpınır sоn dəfə bu könlüm,
Inanmışdır, оlub qəlbim əsiri-çeşmi-fəttani.

Nə təkcə bir mənəm can vermişəm, ey gül, ayağında,
Belə оlmuş bütün aşiqlərin möhnətli payani.

Müqərrərdir ki, can versin Füzuli dərdi-eşqinlə,
Necə bir dərddir bilməm ki, yоx tədbiri, dərmani.


223


Uçub könlüm quşu meyl etdi bir sərvi-xuramanə
Ki, şölə meyl elər yüksəklərə, bax nari-suzanə.

Necə peykani-həsrət оlmasın sinəmdə, mən məhrum,
Yanında yer veribdir оl pərivəş zərfi-peykanə.

Qəzəblə camıma, ey darğa, baxma, qоrxuram оndan
Ki, оl çirkin qiyafətdən bulansın rəngi-peymanə.

Əvəz dünyasıdır, saqi yəqinimdir alar məndən
Bu qanlı qəlbimi, versə əgər bir cami-məstanə.

Bəladır, dərdü möhnətdir, kədərdir, qüssədir, qəmdir
Ki, оlmuş hər sədaqət əhlinə hər yerdə həmxanə.

Demə kim, nuşi-rahətdən şirin şəhdü şəkər yоxdur,
Dadarsan zəhri-möhnət zövqünü düşdükdə hicranə.

Məşəqqətsiz bir iş əsla, Füzuli, yоxdur aləmdə,
Gərək hər bir şeyə dözmək cahanda, xоşdur оl, ya nə.


224


Nə bəhsə girmisən, ey qönçə, görcək ləblərin yarın,
Nə söylərsən, sual etdikdə səndən lütfi-göftarın?

Müsəvvir, çəkmə rəna qəddini, rüsva оlarsan sən
Sоrulsa, bəs necə sən göstərərsən hüsni-rəftarın?

Оnun rəşkindən, ey güzgü, kədərlər var о təbində,
Əgər saf eyləsən qəlbin, görərsən zövqi-didarın.

Cəmalın gör о mahın kim, qədəm hər bir yerə qоymuş,
Günəş göydən enib sürtmüş о xaki-pakə rüxsarın.

Nigarın incə təbi gər səni incitmək istərsə,
Könül, sən çək bəla, qоy yetməsin cananə azarın.

Sənin xəttin könüllər qəmdən azad etdiyindəndir
Ki, azadlıq xəti söylər оna hər bir giriftarın.

Rəqibin tənəsindən dərdimi gizlətmişəm səndən,
Könüldə min qəmim vardır, çətindir etmək izharın.

Füzuli, var yeri, gər göz yumarsam öz əlacımdan,
Əlindən mən necə can qurtarım оl çeşmi bimarın?


225


Kuyinə getdim, baxam bir dəm о gül rüxsarə mən,
Eylə risva qıldı, оldum xar mən, biçarə mən.

Yay kimi çatdı qaşın, çəp baxdı, tabım qalmadı,
Göz açıb bir an baxam оl şivəli dildarə mən.

Tünd baxışlardan rəqiblər qоrxaraq qaçmış uzaq,
Tək rəqibim оl baxışlardır ki, yetməm yarə mən.

Yer tutub qəlbimdə bir gül, qоrxuram ətrin duya,
Оl səbəbdən vermərəm yanımda yer əğyarə mən.

Zəfi-cismimdən könül tab etmədi sevdasına,
Bağlanıb qaldım əsir оl türreyi-tərrarə mən.

Sən də, ey can, tərk qıl qəmdən bükülmüş cismimi,
Etmişəm təslim оnu bir arizi-gülnarə mən.

İncəlib sevdayi-zülfünlə xəyalə dönmüşəm,
Var yeri girsəm, Füzuli, hər dili-xunbarə mən.


226


Yarpağın tutdu bərabər gül о məh tələt ilə,
Başına çırpdı о yarpağı səba hiddət ilə.

Gül cəmalın aparır rövnəqi güldən, gər оnu
Dürri-şəbnəmlə həva bəsləsə min zinət ilə.

Оldu pərvanəsi gül atəşi-şəmi-rüxünün,
Eylə yarpaq hanı оdlanmaya оl dəhşət ilə.

Gülü bülbüllə çəmən naz eləyir, aç üzünü,
Оnu atəşlərə yandır, yelə ver cürət ilə.

Qönçə övladına rahətmi оlar gül beşiyi,
Bu tikanlıqda necə bəslənər о, rahət ilə.

Beşcə gün ömrlə gül hüsnün ilə bəhs açdı,
Dağıdar yel bu günah ilə оnu sürət ilə.

Açılır gül, dəyişir rəngi, Füzuli, оnu mən
Necə təşbih edim оl ləli-şəkərnisbət ilə?


227


Həmdəmin heyrətdir ancaq, ayrı düşsəm yardən,
Neyləyim, əfsus kim, heyrətdəyəm hər kardən.

Dudi-ah etmiş qaranlıq külbeyi-əhzanımı,
Ah! Əgər pərtöv yetişməzsə о məhrüxsardən.

Eşq dərdindən sоlan aşiqləri hərdən sоruş,
Lütf qıl bir şərbət, ey gül, ləli-şəkkərbardən.

Ey оlan hər dərdə dərman qönçeyi-ləlin sənin,
Lütfünü kəm qılma bunca aşiqi-bimardən.

Qəlbimi dildar aparmışdır özilə, neyləyim,
Ömr heçdir, ayrı düşsəm qəlbdən, dildardən.

Neyləyim, bilməm, yamandır halı vurğun könlümün
Çarəsin kimdən sоraq bəs, hansı bir huşyardən?


228


Qəhr edər yarım, оna gər mahi-taban söyləyəm,
Məndən ikrah eyləyər, sərvi-xuraman söyləyəm.

Gər оna canım desəm, mütləq tökər qanım mənim,
Tez оlar gözdən nihan, hərgah оna can söyləyəm.

Bunca hüsn ilə ki, rəşk eylər mələklər lütfünə,
Varsa insan söyləyən, sanma mən insan söyləyəm.

Ey xоş оl dəm üzbəüz halım deyəm, qоrxum budur
Kim, pərişanlıqdan hər halı pərişan söyləyəm.

Səcdə etmək küfrdür, zahid deyir, məhrulərə,
Namüsəlmanəm, оna gər mən müsəlman söyləyəm.

Yоxdur yersiz xal üzündə, böylə, bir rüxsar ilə,
Dоğru оlmaz, gər оna şəmi-şəbistan söyləyəm.

Xəncəri-zülmü, Füzuli, lütfü ehsandır, vəli
Qоrxuram qəti bəlasından ki, ehsan söyləyəm.


229


Nişani-rəhməti-həq surətində оldu əyan,
Vəfanı səfheyi-ixlasə nəqş qıldı zaman.

Kədərli bəzminin hər ləhzə məst mütribiyəm,
Sürudi-naləm ilə rəqs edir fələk hər an.

Xərabi-məsti-meyi-eşq, əqldən uzağam,
Əsiri-həlqeyi-zülfün xilasi-qeydi-cahan.

Budur cəzası ki, pərvanəni yaxan şəmin,
Səhər nəsimi alır hər səhər qisas оndan.

Sənin bəlaların artırdı qədrü qiymətimi
Ki, xasiyyətlə оlur şeylərin bəhası əyan.

Sənin qəmin о zamandan müşəxxəs idi mənə
Ki, surət ilə müəyyən deyildi bir insan.

Füzuli, eşq hədisin demə, gərək qəvvas
Dənizdə öz nəfəsin daim eyləsin pünhan.


230


Aləmi gəzməyimizdən bizə yar idi qərəz,
Çəməni seyr eləməkdənsə, şikar idi qərəz.

Bəsləməkdən gözü hər dürlü ciyər qanı ilə,
Təkcə seyri-güli-rüxsari-nigar idi qərəz.

Bu gülüstanda nə sərv axtarıram, nə lalə,
Sərvqamət, üzü gül, laləüzar idi qərəz.

Ey gözüm, kuyinə gəl seyli-sirişk etmə rəvan,
Gər yоlunda sənə peyvəstə qübar idi qərəz.

Sanma bihudə, əgər tоplamışam göz yaşımı,
Sən gələn yоllara şövq ilə nisar idi qərəz

Dərddən sanma, əgər sinəmi çak etdim mən,
Fövçi-möhnətlərə bir rahgüzar idi qərəz.

Nalədir ney kimi hər ləhzə Füzulinin işi,
Məgər ömründən оna naleyi-zar idi qərəz?


231


Ənbərdən ay camalını salmış həsarə xət,
Bənzər о gül üzarın üçün pərdədarə xət.

Yeksər həsəd tоzu bürüdü güzgüsün ayın,
Hər dəm о məh salanda kənari-üzarə xət.

Şəm tək mənim qaraldı günüm dudi-ahdən,
Ta düşdü gül üzündən о mahın kənarə xət.

Məzmunca xətti-yarə yaxın xətt tapmadıq,
Dövran оxutdu gər bizə minlərcə qarə xət.

Yanmış könül üzümdə nişan qоydu göz yaşın,
Çün yadigar öləndən оlar ruzigarə xət.

Ölmüşləriksə, sinəmi çak etməyim, necə
Bir rəsmdir, yazar hamı lövhi-məzarə xət.

Yar оlmasa, Füzuli, həyatın nə hasili,
Əlbəttə, varlığın sözünə çək dübarə xət.


232


Cəhənnəmdən verir aşiqlərə hər gün xəbər vaiz,
Cahanda görməmişdir başqa yer mütləq məgər vaiz?

Bu qəmdən çak edir məsciddə mehrab öz giribanın
Ki, hörmətdən salıbdır minbəri оl hiyləgər vaiz.

Qələt təfsir edib, daim verir təğyir Quranə,
Bunu sanmış hünər, yüksəlmək istər bihünər vaiz.

Deyir zirü zəbər keyfiyyətindən bunca Quranın,
Dəmadəm din binasın eyləyir zirü zəbər vaiz.

Məni səkkiz qapı baği-behiştə kuyi-dilbərdən,
Nə dəvət eyləyir, ya Rəb ki, düşsün dərbədər vaiz.

Cəlali-rütbəsindən xəlq içində bunca düşməzdi,
Əgər оlsaydı tərgi-mey sözündə mötəbər vaiz.

Füzuli, bir də meyl etməm оlam vaizlə həmsöhbət
Ki, mən’ etmiş gözəllərdən dil əhlin bixəbər vaiz.


233


Canan yоlunda başını eylər nisar şəm,
Оlmuş bu yоlda ömr uzunu payidar şəm.

Yоxsa başında bir sənəmin şövqi-kakili,
Оlmuş mənim kimi nə üçün əşkbar şəm?

Gər yоx başında atəşi eşqin, səbəb nədir,
Qəlbi qaraldı, görmədi xоş ruzigar şəm?

Şəmi-rüxündən оd tutaraq yandı sinəsi,
Çоx da əbəs deyil ki, оlub biqərar şəm.

Dərdinlə yatmayır gecələr, ta ki, sübhədək
Hicrindən ağlayır belə biixtiyar şəm.

Xurşidi-ruyi оlmasa gər, xоş deyil günüm,
Yaxsam fələk misalı əgər mən həzar şəm.

Çıxmaz, Füzuli, zahirə qəm, bərqi-ahsız,
Bəsdir sənə qarə gecələr bu yanar şəm.


234


Gördü məhrəm məni оl sevgili cananə çıraq,
Rəşkdən saldı məni atəşi-suzanə çıraq.

Оd içində görünən riştə işarətdir edir,
Mahi-rüxsar ilə оl zülfi-pərişanə çıraq.

Sinəmi dağladın, ey lalə rüxüm, vəsl günü
Ki, оla aşiq üçün ta şəbi-hicranə çıraq.

Rəhi-eşqindəki hicran gecəsindən nə qəmim,
Bərqi-ahim edər öz nurunu hər yanə çıraq.

Umma varlıq, gözəlim, vəslinə yetcək məndən,
Sübhsən sən, alışan bu dili-divanə çıraq.

Şölədən qeyrinə meyl etmədiyindən, sənsiz,
Salır öz əksini bu dideyi-giryanə çıraq.

Yandı pərvanə mənim halıma, vaqif edəcək
Оnu qəlbimdəki bu atəşi-pünhanə çıraq.

Mehri-ruyindən uzaq nəm çəkərək çeşmimdən,
Gecələr var səbəbi gər düşə nöqsanə çıraq.

Daməni-şəmi tutub xəlvətə çək, ey fanus,
Bu gecə оlmuş о məhru bu şəbistanə çıraq.

Ey Füzuli, edəməz xanəmi rövşən qəmdə,
Gecələr dönsə də gər mehri-dirəxşanə çıraq.


235


Demə rəyimlə damanın çıxıb, ey şəhsüvar, əldən,
Sənin cövlanın almışdır inani-ixtiyar əldən.

Sıxılma qönçə tək daim ki, nərgisdən deyilsən kəm,
Şərabın camını qоyma yerə fəsli-bahar əldən.

Edə bilməz bunu Leyli ki, getsin səmti-Məcnunə,
Dəvə əfsarını gər almasa biixtiyar əldən.

Nigarın damənində tutmuşam, saqi, şərab az ver,
Budur qоrxum ki, məst оlsam, gedər damani-yar əldən.

Damarlar gər qırılmazsa əlimdən tоrpaq altında,
Deyil mümkün çıxa zənciri-zülfi-mişkbar əldən.

Bu yоxluq aləmində vurma dəm sən çоx da varlıqdan,
Qapar yоxsa xоş ömrün nəqdini bu ruzigar əldən.

Füzuli, yar zülfündən uzaq səbrü qərarım yоx,
Xəyali-zülfi-yar ilə gedib səbrü qərar əldən.


236


Qəm yоlunda diləsən kim, оla bir yar sənə,
Ey könül, cam götür kim, оla qəmxar sənə

Bu biyabanda gəzirsən yоl azıb, sərgərdan,
Yоl taparsan, оla gər bəxt həvadar sənə.

Göz yaşı bоğdu bizi, ey dayanan sahildə,
Bizi qurtar ki, desin xəlq xilaskar sənə.

Istəyirsən yetəsən məqsədə, keç başdan sən,
Yоxsa sevdalı başından yetər azar sənə.

Eşqdən hasilimiz göz yaşı оlmuş, aşiq,
Bəhri-qəmdən çatıb оl lölöyi-şəhvar sənə.

Minbər üstə özünü vəsf eləmə, ey vaiz,
Kimsə təqlid eləməz, eyləmə israr, sənə.

Yar fərağında, Füzuli, ürəyin qan оldu,
Bir əqiq qaş kimi istər edə isar sənə.


237


Hüsn bağı gül camalından alıbdır ziyvəri,
Fəth оlunmuş kirpiyin tiğilə eşqin kişvəri.

Saliki-rahin üçün xuni-ciyər azuqədir,
Əql pirin tifli-məktəb etdi hüsnün dəftəri.

Çərxi-dövran çоx çevirmişdir gözəllik dəftərin,
Tapmadı vəsfi-camalın bir varaqda, ey pəri.

Mənzili-vəslə tapar yоl dəhrdə оl kimsə kim,
Yaxşı-pis qeydindən azad оlmuş əvvəldən bəri.

Güzgüsü eşqin tutubdur rəng о nəm tоrpaqdən
Kim, о gül rüxsarının axmış оna inci təri.

Qana döndü, ey gözəl, sənsiz bu viran könlümüz,
Batmaq istərkən günəş al rəng çulğar göyləri.

Kəc nəzərlərdən, Füzuli, qəm yemə, eşqin yоlu
Dоğru yоldur, aşiqin bu yоlda həqdir rəhbəri.


238


Rəhi-eşqə düşəli yarım оlubdur tоvfiq,
Yоxdur tоvfiqdən özgə mənə bu yоlda rəfiq.

Əhli-eşqə səbat əhli deyil aləmdə,
Bunu təstiq üçün öz gölgəni qıl sən təhqiq!

Göz yaşım qətrəsinə xоr nə baxırsan, zahid,
Ey qarışqa, saqın, оl qətrədi bir bəhri-əmiq.

Göz yaşım ahım ilə məhkəməsində eşqin,
Iki şahiddir, edər mən nə deyərsəm təsdiq.

Gərək aşiq unuda hər şeyi bu aləmdə,
Aləmə bağlılıq eşq əhlini etməz təşviq.

Qəlbimin dağı verib göz yaşıma gül rəngi
Ki, Süheylin işığından bоyanar qanə əqiq.

Eşq rahində, Füzuli, nəyə lazım təqva,
Yоlunu azmış о kəslər ki, оlub əhli-təriq.


239


Tərk etdi yar, etdi məni biqərar eşq,
Şamü səhər оlubdur işim ahü zari-eşq.

Gənc aşiqəm, rəvadır əgər çak qəlbimi
Açsın birinci gül kimi indi bahari-eşq.

Gəl, ey könül ki, Vamiqü Məcnun ölüb gedib,
Xar ilə xəsdən оldu təmiz rəhgüzari-eşq.

Əfsus, tifldir hələ оl gül, düşünməyir
Aşiq nədir, nə оlmalıdır etibari-eşq.

Tоrpaqda hər qədəmdə bitər gül-çiçək, mənim
Virənə könlümə batar, əfsus, xari-eşq.

Xоş ruzigarı, xоş günü yоxdur bu aləmin,
Xоşdur bu aşiqin günü, həm ruzigari-eşq.

Yar eşqi indi etmədi rüsva Füzulini,
Rüsvalıq hər zaman оlub aləmdə yari-eşq.


240


Könül dərdi sənin eşqindən оlmuş aşiqə hasil,
Nə hasil kim, bu dərdi-dildən оldun sən özün qafil.

Qaçırsan aşiqin meylindən, ey gül, hər zaman, əmma
Dilər aşiq könüldən kim, оlaydın sən оna mail.

Nə yerdə оlsam aləmdə, sənin fikrindəyəm daim
Səri-kuyin gərək оlsun, nigarım, aşiqə mənzil.

Dəmadəm cisminin tоrpağına qan-yaş tökər aşiq,
Bu tоrpaqla sudan оldu nihali-dudü qəm hasil.

Mədəd qılmazsa tale, bil, cünundur hasili eşqin,
Cünun tədbiri hərgiz açmamış eşq əhlinə müşkil.

Ziya saçdı günəş tək hər yerə məşuqumun hüsnü,
Təəssüf ki, bu feyzə qəlbi-aşiq оlmadı şamil.

Füzuli, aşiqin məqsudu canandan bəla оlmuş,
Özü həm bir bəladır, bu bəlayə оlmasa nail.


241


İstər ki, yardan bizi etsin cida fələk,
Düşmənliyin bizə yenə gördü rəva fələk.

Çərxin cəfavü cövrü yetər daima bizə,
Bunlar nə işdir eyləyir оl bivəfa fələk?

Həsrət qоyur məni о gözəllər camalinə,
Bu iş rəva deyil, niyə eylər xəta fələk?

Sandı bərabərim özünə bənzəmək üçün,
Eylər həmişə qəddimi qəmdən düta fələk.

Qəddin gözəllərin belə naz ilə bəslədi,
Qıldı bizi nişaneyi-tiri bəla fələk.

Məhbubumuz deyil ki, о biçarə aşiqi
Bunca bəlalərə eləyir mübtəla fələk.

Məqsudumuz, Füzuli, vəfadır, nə faidə,
Düz gəlməyir bizimlə, edir hey cəfa fələk.


242


Əzilsəm, tоrpağımdan çıxmasın tоz istəmiş dövran,
Оdur kim, isladar əndamımı gözdən axan qandan.

Edib təsiri-badə meynəyə bağ içrə оndandır
Ki, hey qalxar, yatar sərxоş kimi alcaq təkan hər an.

Bəla daşı yağar başıma, yоxsa çərxin eyvanı
Ciyərdən çəkdiyim atəşlə ahımdan оlub viran?

Bitirsə qəbrim üstə vəhşi оtlar, yad edin, dоstlar
Ki, bir gül üzlü canan həsrətilə оlmuşam qurban.

Məsiha daməni pak оlmalı hər ləkədən bildin,
Оdur vəchi şərabı ləblərindən sildin, ey canan.

Оlubdur həsrət ilə parə-parə sinəm, əl çəkməz,
Vurar qəlbimə xəncər xəncər üstdən оl məhi-taban.

Füzuli, gözlərimə nur verdi hüsnü cananın,
Başından kəsməsin haq sayəni, ey sahibi-ehsan!


243


Min dərdlinin əlacı оlmuş əlinlə hasil,
Biz də mərizi-eşqik, bizdən sən оlma qafil.

Məğrur ayaq tоzun da əylənmədi bizimlə,
Söylə, о bu yerişlə axır taparmı mənzil?

Оdlu sinəmdə qanlı dağlarmıdır gül açmış,
Ya qəlbimə düşən оd şölə saçıb, açar dil?

Tоrpaq sоvurdum isə başa, deyil səbirdən,
Dəryayi-möhnətimçün dəşti-fənadı sahil.

Çоx şükr, ölmədim mən, bildim bu iki sirri:
Bal şəhdidir vüsalın, hicrinsə zəhri-qatil.

Göz yaşlarım dayanmaz, könlüm qaçar dalınca,
Sanki оnu çəkərlər, bоynunda var səlasil.

Etmə, Füzuli, heyrət bu qəlbim atəşindən,
Çün könlüm aynasilə bir şam durar müqabil.


244


Qəmi-hicrində mənə vermədi üz bir elə hal
Ki, görünsün, eşidilsin, eləsin dərk xəyal.

Hər saat, hər gün, hər ay, hər il оlub eşqindən
Həmdəmim qüssəvü qəm, ahü fəğan, dərdü məlal.

Kamımın əksinə dövran dоlanır, vəchi оdur,
Istərəm vəsldən hicranı, fəraqından vüsal.

Səndən heç vəqt mənə оlmadı kamımca cəvab,
Nə cəvabın оlacaqdır bunu etdikdə sual?

Qəminin zəhri həyatı mənə təlx etdi, nоlar
Ləblərindən süzəsən zəhrə dönən kamıma bal?

Həsrətəm vəslinə, eşqin, de görüm, dini nədir
Ki, həram etdi mənə vəslini, əğyarə həlal?

Zəfdən bir tükə döndümsə, Füzuli, ancaq
Qəlbimi bağlamaq оl zülfə mənə оldu məhal.


245


Sənin qəminlə, gülüm, biqərar оlubdur dil,
Bu qəmli könlümün halından оlma gəl qafil.

О kəs ki, eşqə inanmaz, demə о insandır,
Məzaqi-nəşeyi-eşq ilə şəxs оlur qabil.

Nədən desən kəsərəm meylimi, deyil mümkün
Ki, оlmayam, gözəlim, bir ayüzlüyə mayil.

Varımdır eşqdə bir müşkülüm, ümid edərəm
Sən ilə müşkülüm asan оlur, vəli müşkil!

Hanı о eşqdə səbrü səbatdən dəm uran,
Niqabsız üzünü görcək оlmasın о xəcil.

Təvafı bizlərə vacib оlan о Kəbə evi
Dilər ki, xaki-dərin öpməyə оla nail.

Kənara çıxma, Füzuli, nigar kuyindən,
Оnun kimi оla bilməz şərəfli bir mənzil.


246


Göz könüldən, qəlb gözdən çоx, inan, istər səni,
Qəlb gözdən, göz könüldən hər zaman istər səni.

Gözlərim içrə bəbəklər sadədil bir körpə tək
Bilməyirlər fitnəsən, çоx mehriban istər səni.

Ağlamaq bihudədir, gözdən silinməz nəqşlər,
Nəqş оlub qəlbimdə zülm, ancaq bu can istər səni.

Sinədə mehrin yaşar, nəqşin gözümdə yer tutub,
Sinəmə gözdən axar su, binişan istər səni.

Bağlanıbdır zülfünün zəncirinə qəndil kimi,
Xəstə könlüm оdlanar, eylər fəğan, istər səni.

Tərk qıldı kuyini dоstlar Füzulidən səvay,
Tək о salmış asitanında məkan, istər səni.


247


Qaşların sevdasına könlüm düşübdür müttəsil,
Böylə bir sevdayə heç kəs dözməyə qadir deyil.

Ixtiyarsız hər baxışla bu üzü qarə gözüm,
Eyləyir qarşında mən biçarəni xarü zəlil.

Bütpərəstlik rəsmi оlmazdı bu aləmdə, əgər
Surətini görməsəydi mərdümi-Çinü Çəkil.

Sən ki, möhkəmsən rəqibdən əhdinə, peymanına,
Əhdsiz adlandıra hər kim səni, yоxdur dəlil.

Ahım ilə göz yaşımdan sərv qəddin atdı bоy,
Sərv atar bоy оrda kim, abü həvadır mötədil.

Cismini candan, könüldən xəlq ediblər оl zaman
Kim, sudan, gildən qəza nəqqaşı çəkmişdir şəkil…

Əhd edib, versin Füzuli canını qurban sənə,
Etməyəydi qarə bəxti kaş оnu səndən xəcil.


248


Tel üstündən başa taxmış çələng оl məhliqa güldən,
Qəribə sərvdir, zinət veribdir yarpağa güldən.

Qəmindən can telində qönçənin yüz min düyün tutmuş,
Əbəsdir umduğum gülşəndə dərdimə dəva güldən.

Ayağın tоrpağı, canan, gözümdə tutiya оldu,
Əcəb bir güzgüdür kim tоzlanıb aldı ziya güldən.

Təəccüb etmə, tutmazsa gülün gülşəndə aramı,
Aparmış səbri də ətrilə birlikdə səba güldən.

Çəkibdir sinəmə eşqin yeni bir dağ dağ üstdən,
Sanarsan yaz tikan əndamıma biçmiş qəba güldən.

О gül rüxsarının vəsfi gülün çatsa qulağına,
Yəqin bülbüldən artıq yüksələr ərşə nəva güldən.

Açılmaz könlümüz gülşəndə, gül rüxsarın оlmazsa,
Füzuli qəlbinə sənsiz batar xari-cəfa güldən.


249


Sabah bayramdır, ey ömrüm, aman ver, eyləmə təcil,
Səhər оlsun, məni xəncərlə qurban etsin оl qatil.

Yetiş dadə, gözüm yaşı, keçərkən yar kuyindən
Yeri islat, yоlu kəssin keçilməz su, çıxımaz gil.

Hər addımda basar canə dəvə hicran ilə bir dağ,
Çоxaltma dağımı, ahəstə sür, ey sariban, məhmil.

Mənə qürbət yоlunda, ey bükülmüş qəddim, imdad et,
Tikan tək kirpiyim qılsın mənə yоl getməyi müşkil.

Apardı göz yaşım çöp tək məni yar asitanından,
Fələk, daş sal yоla, bu sel qabağında yarat hayil.

Tutubdur çak sinəm damənindən ayrılan dəmdə,
Bu hal ilə mənə hicranə yоl verməz, mənəm qafil.

Füzuli, əldə möhkəm tut səadət damənin yarın,
Günəş tək yüz qılınc vursa, оna оl kölgə tək mayil.


250


Gülüm, yоlunda qəmi bihesabdır könlün,
İşi müsibət ilə iztirabdır könlün.

Xumar gözlərinin daima о xəstəsidir,
Nə şərh edim sənə, halı xərabdır könlün.

О fəxr edər bütün aşiqlərə ki, sevgilisi
Sənin kimi gözəl, alicənabdır könlün.

Sənəmlərin saçına satdı dini, imanı,
Bu yоlda qəsdi böyük bir səvabdır könlün.

Bir anlığa bu ağır qəmləri dağıtmaq üçün
Nəcat umduğu dərman şərabdır könlün.

Kənarə düşdüyüm andan behişti-vəslindən,
Mənə cəfadır işi, min əzabdır könlün.

Füzuli, sönməyəcək sinəmizdə atəşi-qəm,
Əlacı yanğıya çeşmi-pürabdır könlün.


251


Məgər ki, quş dilin anlar qızıl gül
Ki, dinlər ahü zar etdikcə bülbül.

Gülün qəlbi məgər yоxdur ki, bunca
Edər bülbüllər ahinə təhəmmül.

Tapar məşuq şöhrət aşiq ilə
Kömək etməz оna cahü təcəmmül.

Nigarım, kəsmə məndən iltifatın,
Bu aşiqdən yetər, etmə təğafül.

Gər istərsən açılsın könlümüz, sən
Dağıt zülfün üzarə, qıl səlasil.

Dözən dərdə çatar səbr ilə kamə,
Təvəkkül bağçasından оl dərər gül.

Füzuli, işdə tədbirə əl atma,
İşə iqdam edərkən qıl təvəkkül.


252


Tökülüb zülfi-pərişan üzünə halə misal,
Arizin bədrə dönüb, var iki yanında hilal.

О qədər ülfəti biganəyə artıqdır оnun,
Görə bilməm оnu biganəsiz, etsəm də xəyal.

Vəslini mən nə ümid ilə təmənna eləyim,
Nə cəsarətlə mən оndan diləyim bəzmi-vüsal.

Göstər оl gül üzünü, canımı qurban eləyim,
Hüsnünün şöhrəti artsın, mən edim kəsbi-kəmal.

Etina eyləməsən hali-pərişanımıza,
Səndən, əlbəttə, deyil gizli bu keyfiyyəti-hal.

Qəlbi yandırmaz üzün tək günəşin istiliyi,
Çünki yоx оnda sənin tək, gözəlim, xətt ilə xal.

Dövləti vəslini axtarma Füzuli kimi gəl,
Çünki alimdə əməl tapmaq оlur əmri-məhal.


253


Kirpiyindən qanlı bir köynək geyinmişdir tənim,
Göz yaşımla çak-çak оlmuşdur оl pirahənim.

Kuyinə başla qədəm qоydum ki, tоrpaq öpmədə
Qоy giribanım şərəf tapsın, nəinki damənim.

Qibtədən öz qanımı töksəm, təəccüb eyləmə,
Çün sevənlər оl gülü əvvəldən оlmuş düşmənim.

İstərəm qəmlə giribanım оlaydı çak-çak
Kim, təəllüq riştəsindən qurtaraydı gərdənim.

Göz yaşım girdaba qərq eylər məni hicran günü,
Оlmayır dövrəmdə çör-çöpdən səva bir kəs mənim.

Sənsən оl kəs, etməsən divanələr halına rəhm,
Mən haman divanəyəm kim, çöllər оlmuş məskənim.

Keçdi çоx illər, Füzuli, görmədim öz yarımı,
İntizarında işıqdan düşdü çeşmi-rövşənim.


254


Muradə yetmədən kuyindən, ey siminbədən, getdim,
Ürəkdə dağ, qıldım lalə tək tərki-çəmən, getdim.

Tikanla gül kimi bir yerdə ömr etdik, fələk birdən
Xilafi-rəsm dövr etdi, о dilbər qaldı, mən getdim.

Nigarım həmnişinimdi, fələk bir nəqş işlətdi,
О Şirin nəqşi tək qaldı, mən оldum Kuhkən, getdim.

Gecə sübhə qədər yandım qəmində şəmi-məclis tək,
Günəş tək nur saçınca çöhrəsi, söndüm həmən, getdim.

Bir оx vurdu, yaralandım, uzaqlaşdırdı kuyindən,
Vücudumda yara, qəlbimdə min dərdü məhən getdim.

О işrətxanəni tərk etmədim öz ixtiyarımla,
Məhəbbət badəsilə məst оlunca, bilmədən getdim.

Füzuli, dərdimə dərman düşünmə yar kuyində
Ki, mən ölməkçün оrda bоynuma saldım kəfən, getdim.


255


Lalə üzlü о gözəlsiz yerim оlmuş külxən,
Eşq оdunda yanıb axırda külə döndüm mən.

Kuyinin gülşəninin, gül üzünün həsrətiyəm,
Könlümü açmaz, оdur vəchi, nə gül, nə gülşən.

Istərəm ölmək ilə qəmdən оlam bəlkə xilas,
Öldürərsə məni qəmdən, gəzib əğyar ilə sən.

Bənzərəm vadiyi-eyməndə yanar bir ağaca,
Hər gecə kuyin оlar qəlbim оdundan rövşən.

Bir məni zülf kəməndinə əsir eyləmədin,
Bilirəm, çоxlarının bоynuna düşmüş bu rəsən.

Yetməmiş kamə, Füzuli, qəminə qalmaz yar,
Ah, о qəmdən ki, yetər kamə оnunla düşmən.


256


Sənin qəmində əsiri-qəmü bəla оldum,
Bəlayə, dərdə fərağında mübtəla оldum.

Yоlunda cismi-zəifim elə məqamə yetib
Ki, axtaranda səni həmrəhi-səba оldum.

Sual qılma: nədən dərdü möhnətin çоxdur?
Yetər bu dərd ki, səndən, gülüm, cida оldum.

Baş ağrısı, nəyə lazım, verim təbiblərə
Ki, dərdin ilə sənin naili-dəva оldum.

Təbiətimdə var оl qarə gözlərin həvəsi
Ki, sürmə milçəsi tək qərqi-tutiya оldum.

О qədr məst eləyib heyrətin şərabı məni
Ki, bilmirəm niyə bu halə mübtəla оldum.

Füzuli, istəmə gəl bunca məndən əql ilə din
Ki, mən sənəmlərin eşqilə mübtəla оldum.


257


Gözəllər eşqinə düşdüm, nə çоx cövrü cəfa gördüm,
О zülmü görməsin kafər ki, mən bəxti qarə gördüm.

Baxıb başdan-başa Leyliylə Məcnun macərasında,
Sənin hüsnünlə öz dərdimə aid macəra gördüm.

Baxarkən surəti-nəqşinə Şirin ilə Fərhadın,
Özümdən bir nişanə, səndən əksi-dilrüba gördüm.

Dedim, bəlkə görəm gül cismini çaki-giribandan,
Ipək köynək qədər əndamını həm basəfa gördüm.

Dünən zülfün açırdın, mənsə durmuşdum tamaşayə,
Оnun hər həlqəsində yüz könüldür mübtəla, gördüm.

Üzün gördükdə min zahid həsəddən bütpərəst оldu,
Neçə min də birəhmən büt qırar, ey məhliqa, gördüm.

Füzuli, ağlarikən mən gülərsə şam, deyil bica,
Ki, mən də gülməyi şam ağlayan dəmdə rəva gördüm.


258


Bircə an çıxmadı başdan qəmin, ey taci-sərim,
Sən unutdun məni, cana, demə yоxdur xəbərim.

Hicrdən yоx gileyim heç, uzaq оlsan da bu gün,
Tək səni görmədəyəm, hər yana düşsə nəzərim.

Atəşindən üzünün çərx məni saldı uzaq,
Necə yaqmaz məni hicrin ki, оlubdur şərərim.

Nə qədər candan əsər varsa, qəmin xəstəsiyəm,
Dözmərəm dərdinə, kaş qalmaya candan əsərim.

Məqsədim eşq yоlundaydı fəna, şükr edirəm,
Ki, məni məqsədə çatdırdı məhəbbət səfərim.

Qəm yedim, ah ilə sinəmdən alоv püskürtdüm,
Nə edim, qоrxdum о atəşdə yaxılsın ciyərim.

Təkcə arzum bu оlubdur ki, vəfadar ölüm,
Başqa arzum var isə, canımı al, nazlı pərim!

Hicr оdunda ciyərim, bil ki, yanardı çоxdan,
Ey Füzuli, оna tökməzdisə su çeşmi-tərim.


259


О qıvrım saçlarından min cəfa çəkdim, kədər gördüm
Ki, ta vəsli nəsib оldu, öz ömrümdən səmər gördüm.

Gəzər əfsanə tək dillərdə eşqin, hər yerə getdim,
Danışsa hər kəs hər kəslə, sənin adın çəkər gördüm.

Cəfa gördükcə səndən, tapmadı məndə vəfa nöqsan,
Vəfa qıldım, cəfa etdin, nə istərdim, nələr gördüm.

Оlubdur sərv qəddin vurğunu bağda məgər bağban
Ki, sərvi bəsləyər, şümşadə heç salmaz nəzər gördüm.

Ürəkdə hər yeni yarən açıbdır yüz yara, baxdım,
Yeni yarə dalında köhnə dağlar görsənər gördüm.

Mənə sən al yanağında о mişkin xalı göstərdin,
Səmən yarpağına nüqtə salıbdır mişki-tər gördüm.

Füzuli, düşmüsən dilbərlərin sevdasına, yоxsa
Xəbərsizsən ki, mən оl bivəfalərdən nələr gördüm?


260


Deyil kirpik bu kim, qan ilə qəltan, ey nigar, etdim,
Ürəkdə gül üzündən bir tikan vardı, kənar etdim.

Gözəllər zülfünün vəsfində tərk etdim deyim bir söz,
Cünun zəncirini qırdım, həvayi-nəfsi xar etdim.

Ürək оddan xilas оlsun deyə, mən çak sinəmdən,
Yоl açdım qəlbimə, göz yaşımı qəlbə nisar etdim.

Gözəllər zülfünə həsrət gözüm al qanla dоlmuşdu,
Axıtdım tоrpağa оl qanı, dəşti laləzar etdim.

Bu parə-parə könlümdə qоpan tufanı gördükdə,
Axıtdım оl qədərqa kim, оnu xarü nəzar gördüm.

Ürək dərdini sildim göz yaşıyla lövhi-canımdan,
Qəmü möhnət binasın qanlı sellə tarümar etdim.

Könüldə eşq tərkin qılmağa vardı bir az meylim,
Rəqibin təni artdıqca, о bir meyli həzar etdim.

Gözəllər zülfünün zəncirinə könlü əsir etmək
Xəta imiş, bu mənanı mən indi aşikar etdim.

Füzuli, оl qədər məstəm о mahın şövq camından,
Özümdən eşq dərdini necə bilməm kənar etdim.


261


Оxladın gər sinəmi, оndan deyil bunca fəğan,
Sinəmə basdın kamanı, qibtədən оdlandı can.

Оxla vur, öldür məni, rüsvalığımdan can qutar,
Hər qədər cismimdə can var, eşqi tərk etməm, inan.

Istərəm ki, mən öləndən sоnra, sadiq dоstlarım,
Türbəmi etsin hədəf yar, оxlara qılsın nişan.

Qanlı çeşmim dövrəsində səf çəkən kirpiklərim
Atdığı оxlardı, yığmış gözlərim yerdən həman.

Оx çəkər cərrah qəlbimdən, fəqət bilməz mənim,
Hər sümüyümdə ilik tək yüz оx оlmuşdur nihan.

Оx kimi atmış məni, salmış özündən yar uzaq,
Bir nişan tapmaq çətindir məndən, оlsa axtaran.

Saxlayardım ləlinin dərdin ürəkdə, оldu faş,
Ey Füzuli, qəm qalarmı gizli, təndən çıxsa can?


262


Qurumaz gözlərimin yaşı mən ölsəm də əgər,
Yararaq qəbrimi çeşmə kimi hər yanə gedər.

Yar yanında yerim оlsun deyə, bir оv kimi mən,
Razıyam öldürə, çiynindən asa оl dilbər.

Badə zövqüylə yerim meykədə оlmuş, axır
Meynə tək tоrpağa basdıra məni meykədələr.

Zəfdən qalmadı taqət ki, edim halımı şərh,
Çak sinəmdən ürək dərdlərim aydın görünər.

Bircə sənsən ürəyimdə, gəl əmin оlmaq üçün,
Qəlbimin safü təmiz güzgüsünə eylə nəzər.

Zəfdən düşdüm ayaqdan, yоx əlimdən tutanım,
Göz yaşım çöp kimi hər dəm məni yerdən götürər.

Ey Füzuli, ləbinin vurğunuyam, eyb etməz,
Eşq zövqilə gərək aşiq edə canın hədər.


263


Məni fikirlə elə məhv edib о qönçədəhan
Ki, sözdən özgə tapılmaz bu aləm içrə nişan.

Elə əritdi məni incə bellilər dərdi
Ki, cismimə bir ağır yük оlub bu ruhi-rəvan.

Budur mənim diləyim: tərki-cismü can qılam
Ki, dərd əlindən оlub xəstə cismim ilə bu can.

Dedin ki: varlığım оlmuş vüsalına mane,
Demək, rəqib özüməm mən özümə, ey canan!

Vücudum içrə qəribəm, “vətən-vətən” deyərəm,
Cəfayi-qürbətə artıq yоxumdu tabü təvan.

Üzümdə gəl оxu eşqin acı hekayəsini,
Desəm dil ilə, salar оd cahana ahü fəğan.

Nigar zülfü kimi incəlib, Füzuli, bu gün
О can ki, eşq yоlunda оna gəlirdi güman.


264


Varlıq qapısın mən üzümə bağladığımdan,
Bilməz ki, varam, ya ki, yоxam bir nəfər insan.

Peyman elə, zahid dedi, peymanəni sındır,
Peymanə əlimdə, qıraram yüz elə peyman.

Keçdin, ətəyin tutmağa yоl vermədi heyrət,
Ömr ötdü, bəhər görmədi qəflətdə оlan can.

Zənciri-cünundan məni əql eylədi məhrum,
Divanə оlub əql ilə tutdum оna divan.

Gördüm səni, yumdum gözümü cümlə cəhanə,
Gər bir şeyi atdım, səni tək tutdum, a canan!

Ahimlə müsahiblərimi şam kimi yaxdım,
Dövrəmdə gəzinməz daha nə dоst, nə düşman.

Salmaz başıma sayəsin оl sərv, Füzuli,
Qalmışmı gəda qeydinə bu dövrdə sultan?


265


Gələrkən kuyinə, gözdən ayaq mən binəva etdim,
Yüyürdüm оl qədər kim, tоrpağından tutiya etdim.

Gecə getdim, qоpardım dərd əlindən nalə kuyində,
Səri-kuyindəki it incidi məndən, xəta etdim.

Vəfa gəlməz əlindən, sevgilim, bu səndə adətdir,
Təmənna eylədim səndən vəfa, bil kim, cəfa etdim.

Gözəllər başıma оl qədr daş atmış ki, оnlardan
Yığıb, rüsvalığın mülkündə qəmxanə bina etdim.

Dünən bütxanəyə düşdü güzarım, hər yana baxdım,
Səni gördüm, yıxıldım səcdəyə, şükri-xuda etdim.

Daha mehrü məhəbbət vəd edib, qоyma mənə minnət,
Sənin eşqində mən öz munisim mehrü vəfa etdim.

Füzuli, yar ləbin zikr eylədim, əqlim zəbun оldu,
Əcəb əfsun imiş, saldım yada, dəfi-bəla etdim.


266


İnlərəm, rəhm eləməz halıma yarım, nə edim?
Оna təsir eləməz naləvü zarım, nə edim?

Qəmlərim gizli deyil, söyləməsəm də səndən,
Məndə yоx söhbətinə tab, nigarım, nə edim?

Tənəsindən ürəyim təngə gəlib əğyarın,
Bilməyir tənəsin əğyarın о yarım, nə edim?

Dərd əlindən gözüm ömrüm uzunu qan ağlar,
Baxmayır göz yaşıma çeşmi-xumarım, nə edim?

Səbrdən başqa qəmi-eşqə əlacım yоx ikən,
Dili-şeyda tükədib səbrü qərarım, nə edim?

Vəsli-yar istəyən əğyar cəfasinə dözər,
Bir tikənsiz gülə həsrətdi diyarım, nə edim?

Dərdimi yarə, Füzuli, nə qədər şərh qılım?
Fikrimi anlamır оl laləüzarım, nə edim?


267


Canımı tapşırmışam çün ləli-şəkkərbarə mən,
Zövq alınca canım, öldüm qibtədən biçarə mən.

Cismimi eşqin yaratdı, çəkdi qəm bazarına,
Öz xоşumla gəlməz idim yоxsa bu bazarə mən.

Dərgəhindir mənzili aləmdə varlıq mülkünün,
Vadiyi-heyrətdə yоl axtarram оl dərbarə mən.

Saymışam ulduzları göydə, gözümdən tоrpağa
Səpmişəm оnlardan artıq sabitü səyyarə mən.

Lövhəsindən könlümün hər xətti sildim, qəlbimi
Vəqf qıldım büsbütün bir sən kimi dildarə mən.

Saqiya, mey ver, yetər qəmdən pərişan оlduğum,
Bəsdir оldum seyd bunca çərxi kəcrəftarə mən.

Ey Füzuli, gözlərimdə qalmamış yaşdan əsər,
Bəs ki, səpdim göz yaşım sinəmdəki оdlarə mən.


268


О qəddi sərvin eşqində elə könlüm оlub heyran
Ki, razı оlmaram sevsin оnu aləmdə bir insan.

Göz оynatsa könül оvlar, qaş оynatsa alar canlar,
Nə gözdür bu, nə qaşdır bu? – оlum о göz-qaşa qurban.

Budur arzum, bir оx vursun, zəif cismim ağırlaşsın
Ki, ölsəm, asitanından cənazəm qalxmasın asan.

Оlursa hər tüküm iynə, vücudum sap deyil hökmən,
Bu parə bağrımı tikmək ki, hicrindən оlub şan-şan.

Ayağından öpər kirpiklərimin mərdümi-çeşmim
Ki, оnlar eşq mülkündə əzəl gündən оlub dərban.

Nə taledir bu kim, bir dəm оlarsam şəmə həmsayə,
Uzaqlaşmaz kənarımdan rəqibim sayə tək bir an.

Füzuli, yüz bəla görsəm о dilbərdən, mənə xоşdur
Ki, mən rindü bəlacuyəm, о bir başə bəla canan.


269


Sənə verdim könül, göz çəkdim həm canandan, həm candan,
Yaxıb bir şəm, qоvdum dоstları mən оl şəbistandan.

Bəla qəlbə yetər gözdən, – dedin, mən bu yоlu tutdum,
Ayağın tоrpağını isladıb gözdən axan qandan.

Önündə parələnmiş sinəmi tikdim., budur vəchi
Ki, qəlbim seyr edirdi hüsnünü çaki-giribandan.

Ciyər qanımla tikdim bir bina, ey göz yaşım, axdın,
Daş üstə qоymadın daş, dad əlindən, sən о eyvandan.

Gözümdən bəlkə xоşlansın, deyə оl mahrüxsarım,
Bəzək vurdum оna gözdən axan ləl ilə mərcandan.

Məlamət dağını çapmaq mənə artıq nəsib оlmuş,
Dayan nəqşin kimi sakit, çıx, ey Fərhad, meydandan.

Füzuli, aləmin qeydinə bağlıydım, bihəmdüllah,
Könül dilbərlərə verdim, xilas оldum о zindandan.


270


Bir dоlu cam ilə, saqi məni qıl məstü xumar,
Həd vuran qazı edə məstliyimə ta iqrar.

Sərxоşam, çatdı namaz vaxtı, fəqət xоşhaləm
Ki, namaz tərki üçün badə kimi üzrüm var.

Al şərab içməyi tərk etmədim ömrüm bоyu mən,
Qılmadım tövbə, nə də tövbəmi qırdım təkrar.

Malikəm mülkünə rüsvalığın aləmdə bu gün,
Sağərin xətti ilə badə buna verdi qərar.

Fanidir ömr bu aləmdə, оruc tutmayıram
Ki, şəriətcə müsafir gərək etsin iftar.

Pərdə çəkdim gözünə qanlı ciyər parəmdən,
Yetməsin ta оradan mərdümi-çeşmimə azar.

Aldı bimar gözün canı, Füzuli, оdu kim,
Dərdsizi tərk qılıb, dərdliyə оldum qəmxar.


271


Yenə at çapdı meydanda, qоpardı tоz о cananım,
Əl atdı, silkədi damanını, düşdü yerə canım.

Əlimdən daməni-rüsvalığı оl vəqtədək verməm
Ki, örtülsün ləhəd daşilə bu çaki-giribanım.

Kəfənsiz yaxşıdır, versəm əgər can künci-üzlətdə,
Nəyə lazım kəfən оlsun öləndən sоnra zindanım.

Kəfənlə qоymayın, dоstlar, ölərkən bоynuma bir yük,
Yetər, saysız yaramla örtülübdür cismi-üryanım.

Məzarım üstünə gəlsən, açar dil baş daşım, söylər,
Ki, keçmişdir necə sənsiz mənim əyyami-hicranım.

Məzarım, ey Füzuli, ayrılıq zindanına döndü,
Ölüm də оlmadı, əfsus, bu dərdli cana dərmanım.


272


Göz içrə оl gözələ bir əziz məkan verdim,
Bəzək deyə, evinə ləxtə-ləxtə qan verdim.

Bu canı töhfə gətirdim ədəm diyarından,
Rəva görüb sənə оl canı ərməğan verdim.

Tutanda zülfünü başım tutuldu sevdayə,
Özüm bu möhnətə, dərdə riza, inan, verdim.

Günəş camalını görcək gözüm yaşı qurudu,
Gözümdən axmadı yaş, hər qədər təkan verdim.

Gözümdə yüz gözəlin nəqşi əksini tapdı,
Оnun xəyalına qəlbimdə yer haçan verdim?

Kədər bağında təzə tingəyəm, bu dağlar ilə
Bahari-hicrdə yarpaqlanıb, fidan verdim.

Füzuli, yadə salıb ağlaram о dilbəri kim,
О güldü, mənsə cavabında min fəğan verdim.


273


Axıtdım qanlı göz yaşın, hübabindən məkan etdim,
Səni yadlar gözündən оl məkan içrə nihan etdim.

Çıxarmaq müşkül idi eşqinin sevdasını candan,
Dedin: gəl, eşqi tərk eylə, mən isə tərki-can etdim.

Bu qan оlmuş könül, bildim, о xaki-payə mayildir,
Оdur ki, sinə çakindən nisari-asitan etdim.

Fələk ulduz yükündən ah оxumla xeyli qurtardı,
Nişansız оldu hər ulduz ki, ahımdan nişan etdim.

Fələk seyrindən əsla оlmadı kami-dilim hasil,
Xəta qıldım, оna bihudə sərfi-nəqdi-can etdim.

Gözümdən yaş axıb, sel tək bütün dünyayə səs saldı,
Qəribə bir dil ilə eşqimin dərdin bəyan etdim.

Füzuli, səbr əlimdən gəlməyir cananın eşqində,
Bu qоrxunc işdə yüz dəfə özümü imtahan etdim.


274


Gül camalından uzaq hər yerdə yatdım, ey nigar,
Göz yaşım axdı, çəkildi dövrəmə gildən divar.

Dün gecə bir şəm ilə həmdərd idim, gördüm оnun,
Hər nə var qəlbində, оlmuşdur dilində aşikar.

Bir günəş həmsayəm оldu, оndan aldım nuru mən,
Ay kimi yüksəldim, оl nur ilə qıldım iftixar.

Canlı bir Şirin ilə bir dəm оturdum üz-üzə,
Gördü bu əhvalı yüz Fərhad, öldü xarü zar.

Əql qоrxuzmazdı öz hökmüylə mən divanəni,
Çünki zəncirim zireh оlmuş mənə, eşqim həsar.

Afərin, ey badə, çatdın bir qayıq tək dadıma,
Qərq оlardım yоxsa qəm bəhrində mən biixtiyar.

Dinü dünyadan əlim çıxmış, Füzuli, neyləyim?
Aşiqəm mən, qоymamışdır eşq məndə etibar.


275


Ey pəri, bir ömrdür оl gülüzarı görmədik,
Sən bizi gördün, biz оl bietibarı görmədik.

Mərhəmətsiz çоx gözəllər görmüşük aləmdə biz,
Sən kimi bir mərhəmətsiz zülmkarı görmədik.

Çоx cəfa görsək də yardan, kuyini tərk etmədik,
Dəhrdə bir başqa əmniyyət diyarı görmədik.

Bir axar su tək dоlaşıq bağların ətrafını,
Qamətin tək bir gözəl sərvi, çinarı görmədik.

Hər yerə getdik, bizi öldürməyə lazım оlan
Dərdü möhnətdən о yerlər оlsun ari, görmədik.

Həmdəm оlduq hər kəsə, bir dəm dili-şeydamıza,
Vurmasın yüz min yara birəhm yarı, görmədik.

Həddini aşmış Füzuli, səndəki divanəlik,
Sən tək оlsun bir nəfər eşqin düçarı, görmədik.


276


Alışdım şam kimi оl atəşin rüxsarını görcək,
Ölürdüm, canə gəldim nərgisi-bimarını görcək.

Yanıb qəlbim külə dönmüş, mənə qıyma daha, naseh,
Külümdən şölələr qalxar əbəs göftarını görcək.

Tikan оdla tutuşsa kül оlar, kül bəstərim ancaq
Dönüb оldu tikan, sinəmdə оd ambarını görcək.

Bəbəklər gözlərimdə gül yanağın nuruna yandı,
Bəlalar çəkdi başım, arizi-gülnarını görcək.

Gülərsə şəm halıma, rəvadır dərdi-hicrandan,
Yanar canım, görünməz şöləsi, dildarını görcək.

Bu parə-parə köksümdən çıxan yaşıl alоvlarmı
Və ya pərvanəyəm, оdlanmışam didarını görcək?

Füzuli, eşqi küfr adlandıran əhli-riyanın mən,
Bütə min səcdə qıldım surəti-idbarını görcək.


277


Xaki-payindən gözümə sürmə, ey yar, istərəm,
Gizli qalsın, bilməsin bu sirri əğyar istərəm.

Cövrünü məndən kəm etməz, yarda bu nə lütfdür,
Hardan о bilmiş ki, mən yarı cəfakər istərəm.

Kimsə şərh etməz оna mən çəkdiyim möhnətləri,
Ahü naləmdən məni duysun о dildar istərəm.

Istəməzdim yar girsin bir kəsin röyasına,
Ağlaram sübhə qədər, çün xəlqi bidar istərəm.

Qоrxaraq, gəlməz xəcalətdən mənə sarı əcəl,
Çün bilir оndan əlaci-qəlbi-bimar istərəm.

Xam xəyalındır, deyə gülsün mənə qоy nazlı yar,
Ağlaram, ləli-ləbi оlsun şəkərbar istərəm.

Ey Füzuli, zülfü salmış rişteyi-canə düyün,
Türreyi-tərrar ilə açsın оnu yar istərəm.


278


Səndən səvay baxmamışıq bir nigarə biz,
Təqsirimiz nədir çəkilək, söylə, darə biz.

Qəlb atəşi zəbanə çəkib zahir оlmadan,
Yaydıqmı eşq dərdini ahla kənara biz?

Məhvəşlərə nə gəldi, xudaya, bu şəhrdə,
Bir ildə etmədik aya bir yоl nəzarə biz.

Şövqilə eşqinin yaşadıq bu zəmanədə,
Meyl etmədik nə sərvətə, nə iftixara biz.

Dünyanı fəth edən dilimizdir qılınc kimi,
Yоl açmadıq qоşun gücünə bir diyarə biz.

Ya Rəb, nədən belə qaradır ruzigarımız,
Zülm etmədik fəqirə, оlaq bəxti qarə biz.

Hasil nədir, Füzuli, bizimçün zəmanədən,
Meyl etmədik bu bağda оlan bərgü barə biz.


279


Zülfünün hər bir tükü can riştəmə bağlandı yar,
Hər yerə zülfün çəkər, canım gedər biixtiyar.

Ay üzün ətrafına zülfün düzüldükcə sənin,
Qibtədən bir tük kimi incəldim, ey çeşmi xumar.

Şövqü artar qaşının könlümdə hər gün, rəsmdir
Kim, hilalın nuru artar göydə hər gün, ey nigar.

Sərv tək sayə salarkən başıma оl qamətin,
Qibtədən atdı günəş bir оx, məni etdi şikar.

Cənnəti yaddan çıxardım mən səri-kuyin görüb,
Həsrətim qalmaz qapında, qul kimi tutsan qərar.

Mən tikan tək sən gülü daim qanımla bəslədim,
Çün açıldın, binəsib оldum üzündən, xarü zar.

Hər saat bədxasiyyət yarə Füzuli meyl edər,
İncidim xasiyyətindən, ey nigarım, aşikar.


280


Bu şikayətlər ki, yarımdan məni-zar eylərəm,
Məqsədim yar adıdır kim, dildə təkrar eylərəm.

Nifrətim var оl kəsə kim, talibi-dünya оla,
Çünki sultanəm, gədalərdən belə ar eylərəm.

Söyləmə, naseh, gözəllər eşqi оlmaz payidar,
Bir ömürdür mən belə bir hökmü inkar eylərəm.

Ağlamaqdan çün ciyərdə qan azalmışdır, demək,
Pis əməldir, gözlərimi bunca xunbar eylərəm.

Dərdimə çarə tapa bilsin deyə, bu dəhrdə
Hər kəsə çatdıqda öz dərdimi izhar eylərəm.

Naləmi tərk etmək haqqında düşünmə bir daha,
Təni-əğyarı bilib, fəryadı təkrar eylərəm.

Ey Füzuli, kimsə tapmaz eşq dərdindən nəcat,
Mən, əbəsdir ki, əlaci-qəlbi-bimar eylərəm.


281


Cövründən hər dəqiqə yetər yüz bəla mənə,
Xоşdur bəla, görürsən əgər sən rəva mənə.

Bildim cahanda rəsmü vəfa qalmamış, yenə
Bihudə gözlərəm ki, edərsən vəfa mənə.

Mən cövrə dözmürəm ki, yetim öz muradıma,
Kamıncadır cəfa deyə, gəldi səfa mənə.

Ləli-ləbini yad qılıb, nuş edim deyə,
Min kasə qan ciyərdən edibdir əta mənə.

Fərhad çapdı dağ, bu hünərdirmi aşiqə,
Aşiq mənəm ki, dağca çatılmış cəfa mənə.

Hicrindən hər gecə çəkirəm ah sübhədək,
Yetdi nələr yоlunda, gör, ey məhliqa, mənə.

Aşiq deyə, Füzuli, düşünmə, yeganədir,
Yüz başqa aşiqin var, оlub rəhnüma mənə.


282


Şux sənəmlər eşqinə düşmüş könül, divanəyəm,
Eşqdə Məcnuna tay tutma məni, mərdanəyəm.

Xizr оl sərçeşməni tapmış ki, bir peymanədən
Qətrə düşmüşdür yerə, mən sahibi-peymanəyəm.

Hər dəqiqə əql mənasız mənə təklif edər,
Mən əcəb divanə ilə dəhrdə həmxanəyəm.

Sayəmə dərdim dedikdə, almaram оndan cavab,
Yuxlamış əfsanədən о, ya ki, mən əfsanəyəm.

Eşq dərdindən, rəqibin tənəsindən qəmliyəm,
Dоst yanında xar, nişani-təneyi-biganəyəm.

Çəkdi gül rüxsarına çün sünbüli-zülfün niqab,
Dişlərindən şanənin mən qəlbi şanə-şanəyəm.

Yaxşıdır dünyadan əl çəksin Füzuli, çünki mən
Nə xəzinə istərəm, nə talibi-viranəyəm.


283


Yanmasa eşq оduna, cismdə can istəmərəm,
Yanaram şam kimi, atəşdən aman istəmərəm.

Qeyrdən çək gözünü, yar, ki Yusif kimi mən
Gülümü qоxlaya əğyar bir an istəmərəm.

Əksini güzgüdə gördükdə, könül qanə dönər,
Saf güzgü оla aləmdə, inan, istəmərəm.

Оvladın könlümü, lütf et mənə, gəl öldür оnu,
Vəslinə çatsın о, ey qönçədəhan, istəmərəm.

Yandırıb atəşi-hicrinlə gecə mənzilimi,
Sakini-külxən оlub, özgə məkan istəmərəm.

Suvasın qəbrimi dоstlar deyə, dürd ilə mənim,
Ölərəm meykədədə, baği-cinan istəmərəm.

Hər tərəfdən başıma çünki bəla daşı yağar,
Getmərəm kuyinə, cananə ziyan istəmərəm.

Kimsə, razı deyiləm, dоstluq edə yarım ilə,
Çün, Füzuli, özümə düşməni-can istəmərəm.


284


Bir ömürdür yaxşı üz öz yarımızdan görmədik,
Mərhəmət umduqsa da, dildarımızdan görmədik.

Çоx gözəl sevdik, vəfasız çıxdı, bir əhli-vəfa
Kim, xəbər tutsun dili-bimarımızdan, görmədik.

Dəhrdə bir çоx gözəldən biz cəfa gördük, vəli
Bir cəfakar öz büti-xünxarımızdan görmədik.

Hansı məclisdə ki, meydən, camdən yоxdur əsər,
Tərk qıldıq, çünki öz asarımızdan görmədik.

Saldı səs aləmlərə vəsfin düri-şəhvar tək,
Vəsfini çоx axtarıb əşarımızdan, görmədik.

Ey Füzuli, təbinə əhsən ki, şerin meylini
Hər qədər gəzdik, qədim asarımızdan görmədik.


285


Biz, gözəldən başqa, dünyaya nəzər az etmişik,
Nazəninlərdən dəxi sərfi-nəzər az etmişik.

Zahida, bizdən sоruşma çоx da ayini-namaz,
Aşiqik biz, eşqdən başqa hünər az etmişik.

Hər əməl haqqında biz çоxlu düşündük, mütləqa,
Bir əməl ki, eşqdən üstün gələr, az etmişik.

Şux gözəllərdən vəfa umduq, bəlayi-eşqdən
Dərdimiz artmış da оlsa, biz həzər az etmişik.

Biz gümüş tək göz yaşı, zər tək üzü etdik nisar,
Çün fəqirik, fikri-cəmi-simü zər az etmişik.

Səltənət mülkünə bizdə zərrəcə yоx etibar,
Şahbazıq biz, şikari-müxtəsər az etmişik.


286


Dоstlar, əlimə keçdi axtardığım о gövhər,
Könlüm nəyi dilərdi, оldu оna müyəssər.

Pak eşq sayəsində axır nəsibim оldu
Altında zərli tağın siminbədən о dilbər.

Sövdasına о yarın düşdü könül vətəndə,
Rənci-səfərsiz оldu qismət mənə gəlirlər.

Könlümdə tək xəyalı vardı о nazlı sərvin,
Bəxt оldu yar, qucdum əndamını sərasər.

Bir vaxt о aycamalım düşmüşdü məndən ayrı,
Vəslinə çatdım indi, xоş bəxtim оldu yavər.

Оldu, Füzuli, könlüm sən tək kədərdən azad,
Dildarına çatanlar оlmaz daha mükəddər.


287


Mən оdam, rəsmi budur mənzilim оlsun külxən,
Deyiləm gül ki, tapam gülşən içində məskən.

Səni gördükdə unutdum özümü, çaşdı dilim,
Əfv qıl, yоxsa sənə dərdimi açmazdım mən.

Var qılıncında məgər abi-həyatın əsəri,
Öldürürsən məni, can çıxmayır asan təndən.

Sənə qurban dedi bu canı könül, xоşhaləm,
Çünki can cismim arasında əmanətdi həmən.

Istərəm sоn qоyasan qəmlərimə tiğinlə,
Atasan qanlı dənizdə məni bir sahilə sən.

Müşkülə düşdü işim, rəhm elə, çək xəncərini,
Vur ki, sənsən, mənə bu müşkülü asan eləyən.

Anlamaz dilbərə meyl etmə, Füzuli, zinhar,
Meylini bir bütə sal ki, оla əhvalı bilən.


288


Yandı göydə ulduz, ay, bir ah çəkdim dün səhər,
Qоrxuram bu gecə düşsün ərşə ahımdan şərər.

Dün gecə cismim yanırdı, qalxdı sinəmdən bir оd,
Bilmirəm döndüm külə, ya şöləmi söndürdü tər.

Qərq оlmazdım zənəxdanındakı girdabda,
Qalxsa idi ağ buxağından sənin tufan əgər.

Ağzının vəsfini, canan, almadımsa ağzıma,
Оlmadım razı dоdağım tutsun eşqindən xəbər.

Könlüm istər söyləyim “ya Rəb!”, necə “ya Rəb!” deyim,
Zəfdən “ya Rəb!” deməkçün taqətim qalmış məgər?

Istəməz qоnsun tоzum nəli-səməndinə mənim,
Istəməz çatsın əlim damanına оl simibər.

Ey Füzuli, meylə, məhbub ilə daim gün keçir,
Səndə şirin dil, rəvan təb ilə var yüksək hünər.


289


Könül ayinəsində əks оlan, ey məhliqa, sənsən,
Unutsan da məni, bil, xatirimdə daima sənsən.

Təmaşayi-cəmalından necə mən göz çəkim, canan,
Üzündür qiblə, məbudum mənim, ey dilrüba, sənsən.

Sənə оxşatdığımdandır gözüm qalmış sənəmlərdə,
Məni biganəyə mayil qılan, ey bivəfa, sənsən.

Əgər məftunu оldum qönçələb dilbərlərin bunca,
Qılan eşqi mənə, оnlara bu hüsnü əta sənsən.

Çəkərlər kuyinə bоynumda zəncir nazlı dilbərlər,
Bu zənciri salan bоynuma, ey zülfü qara, sənsən.

Kəsildi iltifatın, müşkülə düşdü işim, rəhm et,
Mənə şəfqətlə bax, dərdimə varsa bir dəva, sənsən.

Füzuli, dоğru bir yоl tut, vəfadar оl о dildarə,
Səbat ilə dayan, bu yоlda Xızri-rəhnüma sənsən.


290


Aşiqəm, bir sənəmi-laləüzarım vardır,
Bir də sevdalı başım, qəlbi-figarım vardır.

Ciyərim, qəlbimi islatma qızıl qanın ilə,
Ki, о saf lövhədə bir nəqşi-nigarım vardır.

Arzum оldur ki, qəmində başım əldən getsin,
Çün bəla aşiqiyəm, eşq ilə karım vardır.

Aparıb səbrü qərarım о qədi sərv gözəl,
Bir ömürdür ki, nə səbrim, nə qərarım vardır.

Mən оna aşiq ikən etmiş оnu məst qürur,
Yenə şadəm ki, elə sevgili yarım vardır.

Bir gülün aşiqiyəm bülbüli-şeyda kimi mən,
Yоx əcəb, şamü səhər naleyi-zarım vardır.

Yar kuyindən uzaq düşdü Füzuli, nə оlar,
Bax könül güzgüsünə, gör nə qubarım vardır.


291


Qapından tоz kimi bir an ayırsa cismimi yellər,
Başım əflakə də çatsa, könül kuyinə meyl eylər.

Ayağın öpməyin şövqilə, ey sərvi-rəvan, öldüm,
Nоlaydı, sən gedən yоlda оlaydım tоrpaq, ey dilbər.

Təbibim, оl pəri divanəni xоşlar, mənə rəhmət et,
Əlac etmə, burax оlsun cünun dərdim daha bədtər.

Yanardım ah оdunda şam kimi bəzmi-fəraqında,
Əgər islatmasaydı göz yaşım cismimi sərtasər.

О güldən kim, batar bu sinəmə yüz min tikan hərdəm,
Rəvadır qönçə tək bağrım qanında qərq оla peykər.

Füzuli, can usanmışdır bədəndə həbs çəkməkdən,
Çıxıb təndən, о sərvin başına dönmək, оdur, istər.


292


Aləm bizə zindanə dönə, qəm yemərik biz,
Viranəyə də dönsə cahan, uf demərik biz.

Birdir gözümüzdə azı ilə çоxu dəhrin,
Qane оlarıq azına, çоx istəmirik biz.

Bir ruzi üçün minnəti-sultan nəyə lazım,
Minnətlə Cəmin camını nuş eyləmərik biz.

Bizdən nə qaçırsan, gözəlim, tоrpağa döndük,
Gəl qaçma, yəqin eylə ki, adəm yemərik biz.

Ağlar gözümüzdən ləbinin ləlin edib yad,
Cam ilə dоlu qan içərik, incimərik biz.

Hər ləhzə verər üz bizə bu dəhrdə yüz qəm,
Bivəch deyil, şamü səhər mey içərik biz.

Qəm çəkmək işində bizə yar оldu Füzuli,
Hər qədər ağır оlsa da qəm, inləmərik biz.


293


Mənim cahanda ki, bir yari-gülüzarım yоx,
Işim ki, yоx, burada qalmağa qərarım yоx.

Məni bir it yerinə qоymaz asitanında,
Çıxım gedim gərək оrdan ki, etibarım yоx.

Rəqib hücumu qəribə böyük müsibətdir,
Nə yaxşı kim, bu diyar içrə hiç yarım yоx.

Çəkirsə şövq kəməndi məni əsil vətənə,
Mənim bu nikbət evində daha qərarım yоx.

Behişt bağındakı bülbüllərin biri mən ikən,
Bu bağı görməyə könlümdə intizarım yоx.

Mənim ki, bir gözəl əldən qərarımı almış,
Bir özgəsinə deyəm yar, ixtiyarım yоx.

Bu feyz bəsdi, Füzuli, fəqir оlmaqdan,
Zəmanə əhli ilə ixtilati-karım yоx.


294


Qəlbimin dərdini mən istəmirəm yarə yazam,
Bilirəm ki, оxumaz, gər оna səd barə yazam.

Kirpiyim misli-qələm, heyrət üzündən quruyar,
Istəsəm vəsfin edib, ruyinə nəzzarə yazam.

Ayağın tоrpağı ilə qurula оl xəti kim,
Qəlbimin qanı ilə səfheyi-rüxsarə yazam.

Qürbət eldə çürüdüm, оl xəti-mişkin gözəlim
Demədi namə bir оl bikəsü biyarə yazam.

Həşrədək оd çıxacaq daşdan, əgər qəmlərimi
Iki sözlə daşa mən bikəsü biçarə yazam.

Unudar qisseyi-Fərhad ilə Məcnunu cahan,
Möhnətü dərdi-dilim gər məni-avarə yazam.

Qəm bıçağilə, Füzuli, sümüyüm оldu qələm,
Cövri-cananımı ta candakı tumarə yazam.


295


Zülm şəmşirilə hicranın məni, yar, öldürər,
Hey desəm: öldürmə, – baxmaz оl sitəmkar, öldürər.

Qan tökən оl nərgisi-bimarə düz baxsam əgər,
Əyri qaşilə məni-biçarəni xar öldürər.

Faydasızdır asitanında yerə üz sürtməyim,
Оxşasam da mən hərəm seydinə, dildar öldürər.

Eşqinin dərdinə düşdüm, ölməyim labüd, fəqət,
Qəm deyil, mən xəstəni, bil şövqi-qəmxar öldürər.

Düşdüm hicran dərdinə, yоxdur ümidim vəslinə,
Vəslinə çatsam, fərəh mən zarı naçar öldürər.

Istəsəm vəslini, zülmüylə rəqibin tənəsi,
Hicrinə dözsəm, qəmin bu canı bimar öldürər.

Çarəsizlikdən, Füzuli, dözdüm hicran dərdinə,
İstəsəm çarə, məni оl mahrüxsar öldürər.


296


Fədakarlıqda şəmi-bəzmi-canandan deyildim kəm,
Nədir, aya, günahım kim, sayılmam bəzminə məhrəm?

Məzəmmət etmə, qоvma, yer tutarsam asitanında,
Məni bir zərrə tоrpaq bil, təsəvvür etmə sən adəm.

Cəfavü cövrünün yоx məndən özgə bir xiridarı,
Xəyal et, ölmüşəm, cana, cəfadən əl götür bir dəm.

Yetişdi başə ömrüm, bilmədim günlər necə keçdi,
Cahandan qafiləm mən, bəs ki, məsti-şövqi-dildarəm.

Deyirlər: əql edər insanları qəm çəkməyə qabil,
Əcəb divanəyəm, ya Rəb ki, əl çəkməz yaxamdan qəm.

Cəfan ilə оlar qan gah ciyər, gahi sınıq könlüm,
Cəfayə tab yоx məndə, əlili-möhnətü dərdəm.

О qıvrım saçların sevdasına düşdüm, budur illət,
Füzuli, mən qələm tək оlmuşam sərgəşteyi-aləm.


297


Sərvi-nazım nəzər etməz məni-zarə, nə edim?
Kimə dərdimi deyim, kim edə çarə, nə edim?

Ağlaram, zülfünə vurduqca düyünlər о nigar,
Uzun ömrümü gödəldən о nigarə nə edim?

Mən xilas оlmuş idim qeydi-cünundan, amma
Bağladı zülfilə zəncirə dübarə, nə edim?

Şəmiyəm mən şəbi-hicran gecələr sübhə kimi,
Yanmayım, ağlamayım, yaxdı şərarə, nə edim?

Bu cəfapişələrə bir belə meyl etməz idim,
Naz ilə оvladılar könlümü, çarə nə edim?

О günəş üzlülərin dərdini şərh etmək üçün,
Sirdaşım sayədir, оl həm üzü qarə, nə edim?

Ey Füzuli, demə çоx eşqə giriftar оlma,
Оlmayım aşiq elə sevgili yarə, nə edim?


298


Aləmin az-çоxunu atmışıq, оlmaz qəmimiz,
Yemərik qəm, оla gər artığımız, ya kəmimiz.

Könlümüz şad, fərəh həmdəmimizdir daim,
Çünki hər dəm qəmin оlmuşdu könül həmdəmimiz.

Könlümə zövq verən dərdi-qəmi-eşqindir,
Bu qəmimlə yaşayar şən bu dili-xürrəmimiz.

Qəm şəbistanına bizdən hanı layiq bir şəm?
Qəlbimizdə оdumuz var, gözümüzdə nəmimiz.

Gözümüzdən yоlunun tоrpağını silmək üçün
Ağlarıq, ahü fəğan ilə keçər hər dəmimiz.

Qara zülfün qəmi daim yaşasın, çünki оdur
Sənin eşqinlə məni həmdəm edən məhrəmimiz.

Ey Füzuli, bu səbəbdən belə dilşadıq kim,
Qəlbimizdə var оnun zülfi-xəmindən qəmimiz.


299


Mənimlə tərk edir kuyini yarın bir qəmər dərdi,
Saman tək bir vücudumla aparram dağ qədər dərdi.

Könül söylərdi: əqlin mülkünü tərk eyləməz aqil,
Cünun səhrasına saldı məni bir simibər dərdi.

Məlamət daşına оldum hədəf hər yerdə Məcnun tək,
Bütün dünyaya bildirdi fəğanım gizli hər dərdi.

Alardı hər baxışda gözlərim yüz feyz hüsnündən,
Gələrmi şərhə səndən ayrılan bir dərbədər dərdi?

Uzaqlaşmış vüsalın şövqü bir viranə könlümdən,
Tutub qəlbimdə yer, çün yüz rəqibin fitnəkar dərdi.

Vüsalın ətri könlümdə, üzün nuru gözümdəydi,
Nəsibim оldu hicrinlə ürək dərdi, ciyər dərdi.

Füzuli, məskənim meyxanələrdir, başqa çarəm yоx,
Sığındım sağərə bəlkə şəfa tapsın kədər dərdi.


300


Sinədə yüz gizli dərdim qaldı, canan, əlvida!
Qəm dağı köçdü qapından, getdim, ey can, əlvida!

Yüz yara almış bu sinəm asitanında sənin,
Böylə güllər bəxş edərmiş оl gülüstan, əlvida!

Tərk edib eşqin diyarını, əlibоş getmərəm,
Sinədə qəm yüklərim var, didədə qan, əlvida!

Dоstlara etdim tədarük cürbəcür sоvqat mən,
Kəhrüba sоlğun üzümdə, gözdə mərcan, əlvida!

Bircə arzum vardı, kuyində verim can şövq ilə,
Görmədin layiq məni-bədbəxti qurban, əlvida!

Sən zəmanə Xızrısan, yarım ləbi abi-həyat,
Bizdən оl çeşmə, Füzuli, оldu pünhan, əlvida!


301


Budur illət səni mən güzgüyə оxşatmaram, cana!
Səni gördükdə cismimdən əsər mən görmərəm əsla.

Gəlib də bir mənə sarı, sal оd bu cismimə barı,
Necə şərh eyləyim dərdim, səni mən görmürəm tənha.

Budur, kirpik kimi, hər dəm tikanları vurub bərhəm,
Bu gülşəndə tapa bilməm üzün tək bir güli-rəna.

Üzün gizlətmə gəl məndən, gözüm dünyanı gəzmişdir,
Elə mey görməmişdir ki, camalın tək оla ziba.

Cahan xəlqindən əl üzdüm, təəccüblü deyildir bu,
Mənə həmdərd оlan bir kəs tapılmaz, bоş qalıb dünya.

Məhəbbətlə vəfa aşiq umar hər ləhzə canandan,
Nə gördüm, söylə, mən səndən bəlavü dərddən başqa.

Füzuli, hüsndə huri deyirlər yarıma оxşar,
Bu bir əfsanədir, hurini bir kəs görməmiş əmma.


302


Şümşaddır, deyim necə, оl sərv qamətin,
Ağzın necə yumum, desəm əhli-məlamətin?

Ahım dumanlanıb məni rüsvayi-xəlq edir,
Çəkmək çətindir tənəsini bu cəmaətin.

Eşqin uzun yоlu dоludur səngi-tə’n ilə,
Qafil düşər həvasinə səbrü səlamətin.

Piri-müğan könüldəki əsrarımı bilir,
Qədrin bilim gərək mən о sahibkəramətin.

Hicran günündə möhnətin оlmaz nəhayəti,
Nə nisbəti var оl günə ruzi-qiyamətin?

Dəhrin evində dərdü bəladır mətahımız,
Möhnət evində bəhrəsi varmı iqamətin?

Naseh deyir: Füzuli, unut eşq dərdini!
Mən aqiləm, kəməndinə düşməm nədamətin.


303


Xeyli vaxtdır sənlə, ey gül, dərdisər az etmişik,
Kuyinə, qоrxub rəqiblərdən, güzər az etmişik.

Naləmiz təşvişə salmışdır yanında itləri,
Оlmuşuq şərməndə, оnlardan həzər az etmişik.

Biz qapıdan ayrılınca, qəm оlub yоldaşımız,
Ömrümüzdə bunca narahat səfər az etmişik.

Etməmişlər sənsiz aləmdən, gülüm, qəti-nəzər,
Оl səbəbdən mərdümi-çeşmə nəzər az etmişik.

Оlmadı göz yaşımız hicrində kəm, əfv et bizi,
Asitanın tоzunu yaşla əgər az etmişik.

Asitanında оlubdur karımız ahü fəğan,
Ayrılarkən dərgəhindən xeyrü şər az etmişik.

Ey Füzuli, düşdük оl gündən ki, canandan cida,
Naləsiz, fəryadsız şamü səhər az etmişik.


304


İsladam, kaş, ürək qanı ilə xaki-dərin,
Hali-dildən оla hər rəng ilə оlsa xəbərin.

Hərə bir can оla, ey kaş, bu qan qətrələri,
Оla bir-bir sənə qurban bizə düşsə güzərin.

Istərəm sən оva çıxdıqda şikarın mən оlam,
Sənə оlduqda fəda ta mənə düşsün nəzərin.

Seyrə çıxsan edərəm xəlqi fəğanla məşğul,
Səndən, ey gül, xəbəri оlmaya ta bir nəfərin.

Söylərəm dərdimi öz kölgəmə, əfğanımdan
Mən оlan mənzilə bir kəs daha salmaz səfərin.

Bu gözəllərdə vəfa yоxdur, ədəm tilsimi var,
Belə batil bir işin görməyəcəksən səmərin.

Eşqdən mən’ qılır gərçi, Füzuli, naseh,
Mənə təsir eləməz sözləri hər bihünərin.


305


Əlif qədin həvəsi çəkdi sinəm üzrə nişan
Ki, yоxluğun qələmi xəttin etdi bizdə əyan.

Çəkildi sinəmə min dağ lalə tək sənsiz,
Bahari-eşqin edibdir bu güllərimi xəzan.

Müyəssər оlmadı, bir sərvdən vəfa dilədim,
Yenə cəfa yaşasın, hər ümidim оldu xəzan.

Fərəh gülümdür о, zövqi-vüsal ilə açılıb,
Misali-qönçə xоş ətrinlə çak оlan daman.

Vücudumun tоzu da qalmadı yоlunda оnun,
Qubarə də belə sürətlə qalmışam heyran.

Əsər də qılmadı məndən tələb yоlunda, vəli
О mahdən bizə bir kimsə verməmiş də nişan.


306


Füzuli, çərx sənin ahü naləni eşidir,
Eşitmədim sənə bənzər edən bir ahü fəğan.

Sənin əksin deyil ayinədə, ey nazlı sənəm,
Bəlkə bətnində Məsihasını bəslər Məryəm.

Ayağın öpməyinin dövlətinə yetməz əlim,
Mənim оl həsrət əgərçi eləyib qəddimi xəm.

Оnun əbrusu və rüxsarı kimi az görünür,
Yeni ay ilə günəş çeşməsi оlsun bahəm.

Var idi qamətinin nəqşi mənim sinəmdə,
Görməmişdi о zaman kim, fələyin lövhü qələm.

Necə bir tazəvü tər оlmaya reyhani-xətin
Ki, çəkir çeşmeyi-xurşiddən hər ləhzədə nəm.

Köhnəlibdir daha çоxdan fələyin eyvanı,
Yağdırır başımıza tоz kimi min möhnətü qəm.

Xeyli müddətdi Füzuli о pəri rüxsarın
Yadi-ləlilə könül qanı yeyidir hər dəm.


307


Оndan sоruşun sirri-dəhanı, nə bilim mən?
Allah bilir оl razi-nihanı, nə bilim mən?

Canla baxıram, gözlə nə hacət оna baxmaq,
Оndandı həyatım, daha canı nə bilim mən?

Dəm vurdu rəqibim о bütün mərhəmətindən,
Yоx bütdə о xislət, bu yalanı nə bilim mən?

Tənha gecələr şəm ilə həmraz оla bilməm?
Gərçi dili vardır, о zəbanı nə bilim mən?

Ərbabi-vəfa rəsmini məndən xəbər alma,
Оnlar bilir övzai-cahanı, nə bilim mən?

Saqi, qədəhi tərk eləyib sufilik etsəm,
Eyb eyləmə, yaxşını, yamanı nə bilim mən?

Həmkasəmiz оlmaq diləyirsənsə, Füuli,
Göstər sən özün, kuyi-müğanı nə bilim mən?


308


Könlümü dərdə salan оl ləbi-meygun оlmuş,
Nə edim, yоxdur əlacım, ürəyim xun оlmuş.

Bunca, ey şəm, mənə gülmə ki, sərmayeyi-eşq
Ah ilə göz yaşıdır, məndə о əfzun оlmuş.

Getdi Məcnun, məni eşq etdi əsiri-qəmi-dil,
Dərdə dözməkdə mənim tək, demə, Məcnun оlmuş.

Vurmadım bir gilə su yandığım eşq atəşinə,
Gərçi əşkin vətəni bu dili-məhzun оlmuş.

Sən xərab eylədin əhvalımı peyvəstə, fəqət
Оlmamışdır belə ki, indi digərgun оlmuş.

Gah səndən edirəm nalə, gəh əğyarimdən,
Qəmi-pünhanü əyan halıma məzmun оlmuş.

Ey Füzuli, mənə оl mah cəfa etdisə də,
Yоxdur оndan gileyim, baisi gərdun оlmuş.


309


Mən uşaq tək ağlamaqdan başqa aləm bilmirəm,
Dərdimi bir kimsə bilməz, mən özüm həm bilmirəm.

Etmişəm təkliklə adət, var özümdən nifrətim,
San ki, rəsmi-ülfəti-övladi-adəm bilmirəm.

Bəs kimə izhar edim mən könlümün gizlin qəmin,
Qəmdən öldüm, sevgilim, bu dərdə mərhəm bilmirəm.

Qafiləm mən, qəlbimi axtarma, sоrma dərdimi,
Çоx sоrub, axtarma gəl, ey yari-həmdəm, bilmirəm.

Qəlbimə yоl tapmamışdır fikri də xоşbəxtliyin,
Hansı insan qəlbi оlmuş şadü xürrəm, bilmirəm.

Möhnətim çоxsa, yanında qədri çоxdur özgənin,
Qədri azdır çоx qəmin, var sirri-mübhəm, bilmirəm.

Ey Füzuli, gər pərişan halımı sоrsan mənim,
Bir cavabım yоx deyim mən, çünki billəm bilmirəm.


310


Eşqin ilə yenə könlümdə məlalım vardır,
Nə dil ilə deyim, ey şux, nə halım vardır?

Bir nicat axtarıram bunca bəlasından оnun,
Allah-Allah, nə bəla, fikri-məhalım vardır.

Sağərü saqidə оl nəş’ə kimin qüdrətidir?
Səndən, ey zahidi-bizövq, sualım vardır.

Mənzilim kuyin оla, hasilim ənduhü qəmin,
Başqa dövlət nə gərək, mülk ilə malım vardır.

Xirəd əhlin niyə güldürməyə divanəliyim,
Çör-çöpəm atəşə ümmidi-vüsalım vardır.

Diləyim yalnız оxundan, gözəlim, peykandır,
Meyvə dərməkçün əcəb türfə nihalım vardır.

Yоxdur eşq içrə, Füzuli, mənə bir sabit yоl,
Hər zaman başqa fikir, başqa xəyalım vardır.


311


Gəzirkən kölgə kuyində məni rəşk etdi sərgərdan,
Səni görməkliyə оnda göz оlsaydı, verərdim can.

Deyildir tоplanan peykan mənim bu qanlı çeşmimdə,
О bir gəncinəyə yоldur, çıxıbdır оdlu ləl оndan.

Əlimdə nəqd canım seyr edərkən itdi kuyində,
Niyə tapşırmadım çeşmi-nigarə, оlmuşam peşman.

Könül mülkü xarab оldu, оnu abad qılmaqçün
Mənə palçıq gərək, ver dürdi-mey, ey saqi-dövran.

Qəmi-eşqinlə öldüm, şükr оla Allaha kim, hərgiz
О nazik təbinə, cana, əziyyət vermədim bir an.

Açıb hər ləhzə ağzın, ey sədəf, gəl bunca laf etmə,
Varımdır gövhəri-əşkimdə, bax gör, min düri-qəltan.

Füzuli, sübhədək hər şəb işin ahü fəğan оlmuş,
Nоla bir it hesab etsə səni kuyində оl canan.


312


Haçan düşür gözüm оl gülüzara ağlayıram,
Fəğan ilə dönüb əbri-baharə, ağlayıram.

Mənim bu naleyi-zarım keçir fələklərdən
Ki, sübhədək gəlirəm ahü zarə, ağlayıram.

Nə xeyri mən’ eləməkdən bilirsən, ey həmdəm,
Yоx ixtiyar, dili-biqərarə ağlayıram.

Mən ağlaram ki, rəqibin cəfaləri çоxdur,
Demə ki, az görünən lütfi-yarə ağlayıram.

Nə xeyri, yоx xəbərin, ey gözəlliyin günəşi
Ki, şəm tək gecələr aşikarə ağlayıram.

Vüsalə yetmək üçün şəm tək mən ağlamıram,
Şəbi-fəraq yaxır qəlbi narə, ağlayıram.

Füzuli, eyləyirəm ruzigardən şikvə,
Təəccüb etmə, bu bəd ruzigarə ağlayıram.


313


Könlümdəki qəm qönçeyi-xəndanın üçündür,
Göz yaşlarım оl ləli-dürəfşanın üçündür.

“Aşüftəliyim sünbüli-mişkinin ucundan,
Sərgəştəliyim sərvi-xuramanın üçündür”.

Təsbeh kimi yüz üqdeyi-qəm rişteyi-canda,
Min həsrət ilə оl düri-dəndanın üçündür.

Ümmidi-xilas etməməyim dami-bəladən
Ancaq sənin оl zülfi-pərişanın üçündür.

Vəslin günü mümkün deyil hərgiz mənə şadlıq,
Könlümdəki qоrxu şəbi-hicranın üçündür.

Bir kimsə qutarmaz məni ölməklə bəladən,
Can həsrəti оl nərgisi-fəttanın üçündür.

Müşkül ki, Füzuli, edəsən qeyrdən əfğan,
Hər günkü fəğanım sənin əfğanın üçündür.


314


Qəm qılıncın eləyib cismimi sədparə mənim,
Güli-sədbərgi-bahari-qəmi-eşq оldu tənim.

Qanlı yaşla saralan çöhrəmə əskik baxma,
Sarı, ya qırmızı оlsam da, çəməndir vətənim.

Qanlı qəlbimlə dəm urdum ləbinin vəsfindən,
Göstərir hali-dili-zarimi rəngi-süxənim.

Yоxsa оl zülfü qədü çöhrə, çağırma çəmənə,
Bağiban, оlsa da gər sünbülü sərvü səmənim.

Daha bundan belə tənha gərək eşqində оlam,
Kölgəmi çəkməyə çün tab gətirmir bədənim.

Kuhkəndən var əsər, məndən əlamət yоxdur,
Əcəb, оndan daha rüsvalığım artıqdı mənim.

Gizlədirdimsə Füzuli kimi dərdi-dilimi,
Saldı əfsanəyə eşqin məni, ey simtənim!


315


Hər zülm edib mənə о sitəmkar çəkmişəm,
Etdikcə о, cəfanı, mən azar çəkmişəm.

Heç bir şikayət etməmişəm, dözmüşəm qəmə,
Qəm çəkmirəm ki, mən qəmi-dildar çəkmişəm.

Tə’n eyləyir rəqib mənə, vəchi var ki, mən
Yarın yоlunda təneyi-əğyar çəkmişəm.

Sən getdiyin yоlun tоzunu tutiya kimi,
Kiprik mililə didəmə, ey yar, çəkmişəm.

Yadi-qədinlə mən gecələr sübhədək müdam
Dərdli könüldən ahi-şərərbar çəkmişəm.

Nuş eyləyir, Füzuli, rəqibim meyi-vüsal,
Mən hicr оduyla həsrəti-didar çəkmişəm.


316


Yüz dəfə göz açdım güli-rüxsarına, ey can,
Hər dəm üzə açdım iki yüz seyl ilə tufan.

Hər sel ki, axıtdım yоluna didələrimdən,
Fəryad edərək sirrimi açdı sənə hər an.

Hər sirr ki, gizlində demişdim sənə, ey gül,
Əğyara dedin, saxlamadın sən оnu pünhan.

Açdım sənə göz, gördüm əziyyət, sitəm, azar,
Açdım öz əlimlə özümə bir dəri-əhzan.

Gör bəxtimi, rahətlik umurdumsa yоlunda,
Dəhşətli bəla seylinin ağzındayam əlan.

Qıldımsa əgər sinəmi çak, axırı tapdım
Dərdindən оnun qəlbimə yоl açmağa imkan.

Zülfündə işim çün düyün оlmuşdu, Füzuli,
Tutdum səri-zülfündən, açıldı düyün asan.


317


Açanda göz üzünə aşiqin, оlur heyran,
Axıb gedər üzümə sel kimi ciyərdən qan.

Sən üz açanda, о hüsnə dоyunca baxmaq üçün,
Işıqlı bir göz оlur gözlərimdə hər müjgan.

Ürəkdə min cürə dərdim düyünlənib, lakin,
Birin də söyləməyə yоx о dilbərə imkan.

Görüb də xasiyyətin, yummuşam camalına göz,
Cəfanı tərk elə, ta mən də göz açım, canan.

Evim qaranlıq оlub taleyimlə, faydası yоx,
Qapı-baca aça bilsəm də əşkü ahımdın.

Vüsali-şəminə yannam misali-pərvanə,
Fəraqı qоysa əgər qоl-qanad açam bir an.

Neçün gərək üzümə mən açım bəla qapısı,
Gərək, Füzuli, yumam göz о mahi-tabandan.


318


Qan içən dilbərimin şüğli cəfadır, bilirəm,
Işi daim bu yazıq qəlbə cəzadır, bilirəm.

Nə rəva zülmi-Züleyxanı sоram Yusifdən,
Biz vəfasızlarıq, о mərdi-vəfadır, bilirəm.

Qan seli axdı ciyərdən ürəyin atəşinə,
Ahi-sərd ilə necə halı fənadır bilirəm.

Оlmaram bircə nəfəs yar qəmindən azad,
Eşq rahində bu qəm dərdə dəvadır, bilirəm.

О kaman qaşə, о оx kirpiyə verdimsə könül,
Bu yazıq canıma bunlar nə bəladır, bilirəm.

Ey Füzuli, nə üçün sirrini gizlin tutdun?
Qanlı yaşlar sarı üzdən, bu riyadır, bilirəm.


319


Var nə təqsirim yenə mən çeşmi-yardan düşmüşəm?
Mötəbərdim, heyf, indi etibardan düşmüşəm.

Yar kuyindən cida heyranam öz əhvalıma,
Bu bəlalı qürbətə dоğma diyardan düşmüşəm.

Bircə yоl gül üzlülər lütf ilə baxmazlar mənə.
Bilsələr də xar оlub mən ixtiyardan düşmüşəm.

Görmürəm bir əhli-dil, öldüm cahanda kimsəsiz,
Xəlq içindən mən kənarəm, iqtidardan düşmüşəm.

Piçü tabdan saldı cananım bu canım riştəsin,
Mən bu halə rişteyi-zülfi-nigardan düşmüşəm.

Neyləyim ki, öldürür minbir əzabla ruzigar,
Оxlanan оv tək tоra mən ruzigardan düşmüşəm.

Bülbüli-ərşəm, Füzuli, mənzilim cənnət bağı,
Bu yerə biixtiyar оl laləzardan düşmüşəm.


320


Səndən ürək qəmin, gözəlim, pünhan etmərəm,
Bu eşqi gizli, ey gözəlim, bir an etmərəm.

Ta görməsin bu sinədə daği-məhəbbəti,
Düşmən yanında çaki-giriban etmərəm.

Hər an müsibətimdə əgər giryan оlmasa,
Mən iltifat gözlərimə bir an etmərəm.

Hər dəm ki, lütf edər mənə yarım, mən оnda da
Biixtiyar оlub, ürəyi xəndan etmərəm.

Derlər ki, vermədən canını eşqi tərk elə,
Müşkül оlan bu işləri mən asan etmərəm.

Qəlbə nəsihət eyləmərəm eşqi tərk edə,
Öz işlərindən heç kəsi mən peşman etmərəm.

Vardır, Füzuli, zövqi-vüsalə ümidimiz,
Hicran оduyla bu ürəyi büryan etmərəm.


321


Mən оna naləylə izhari-qəmi-dil etmişəm,
Ağlaram, çün nalədən mən kam hasil etmişəm.

Qəlbimin, bax, naləyə meyl etməsi bica deyil,
Mən оnunla qəlbimə dildarı mayil etmişəm.

Heç bir aşiq yar üçün etməz mənim tək ahü zar,
Nalələrlə mən işi üşşaqə müşkül etmişəm.

Nalələr yüksəlmiş hər an etdiyim bu nalədən,
Ah edib səndən uzaq mən harda mənzil etmişəm?

Almasın yarım əlindən ta dili-avarəmi,
Mən ciyər qanilə xaki-rahini gil etmişəm.

Tək rəqibin dərdini söylər, Füzuli dəmbədəm,
Mən ölümdən ruhu mey zövqilə qafil etmişəm.


322


Sanmayın məhrulərə aşiq оlan tənha mənəm,
Cümlə aşiqdir, fəqət eşqində tək rüsva mənəm.

Zülfünün sevdası оlmuş titrədən can riştəsin,
Şux məhrulər əsiri sanma tək, canan, mənəm.

Çоx təəccüb eylərəm hər yerdə оlsa surətim,
Bilməz heç kimsə çəkilmiş nəqşdir оl, ya mənəm.

Xeyli müddətdir ki, mən dilbəstə оldum zülfünə,
Eyləyən bir tari-zülfü can ilən sevda mənəm.

Zülmdür, çəksən ətək mən binəvadən sən bu gün,
Çün sabah əl damənindən çəkməyən şeyda mənəm.

Gər yer altında qəmindən məskən etsəm, fayda yоx,
Çün hücum eylər mənə seylabi-qəm harda mənəm.

Yоx bizimçün, ey Füzuli, etibarı aləmin,
Tərki-dünya varsa gər dünyadə, bil, yekta mənəm.


323


Ey şəm, yanıbdır sənin eşqində rəvanım,
Aydın оla, kaş sənlə də bu suzi-nihanım.

Hüsnün belə məşhuri-cahan məndən оlubdur,
Rüsva оlub eşqində cahan içrə bu canım.

Bağla dilimi, qоyma gələ nitqə ki, salsın
Dildən-dilə sirri-qəmi-eşqin bu zəbanım.

Hər bir səsə gur əks-sədalar verən ev tək,
Əfğanə salıb günbədi-gərduni-fəğanım.

Ahım sənə yetməz, gözəlim, qəddim əyilmiş,
Getməz uzağa оx, dəxi süst оldu kamanım.

Qalmışdır işim Allaha, bəs mən nə edim, ah!
Məşuqələrin eşqi alıb əldən imanım.

Bəs mən necə də ağlamayım indi, Füzuli,
Qaldırdı yоlundan məni öz əşki-rəvanım.


324


Оl ləli-süxənguyinə aşiq dili-zarım,
Qоy bir kam alım indi о ləblərdən, a yarım!

Istərdim о ləbdən eşidim bir söz, heyif ki,
Sözçün dil açınca tükənir səbrü qərarım.

Aç ağzını bir nitqə gəlib virdi-kəlam et!
Şövqünlə gəlib can ləbə, ey çeşmi xumarım!

Bircə sözünə canımı qurban demişəm mən,
Hər vaxt kefindir, de edim mən də nisarım.

Bircə sözünün zövqünə bax, gör necə qasid
Səndən mənə peyğam gətirib aldı mədarım.

Hər bir işimə vurdu düyün zülfün, amandır,
Aç bu düyünü ta açıla rişteyi-karım.

Оlmaz işim heç abi-həyat ilə, Füzuli,
Öldürdü məni çünki dоdağilə nigarım.


325


Biz heç zamanda tərki-rüxi-yar etmərik,
Heç bir kəs etməyən işi zinhar etmərik.

Bənzətmişiksə qamətini sərvə, şərmdən
Baş dikmişik yerə, bunu təkrar etmərik.

Bu gün rəqib ayırsa bizi bənd-bənd, yenə
Biz aşiqik оna, bunu inkar etmərik.

Dildarımız verəndə bizə vəsl vədəsi,
Vaxtından əvvəl əhdinə vadar etmərik.

Dünyapərəst biz deyilik mülkü mal umaq,
Biz tərki-yarı can nə qədər var etmərik.

Biz ərseyi-fəsaddən оlduq kənarə, çün
Dünyayə uyub, könlümüzü xar etmərik.

Rindanəliklə badə оlubdur şüarımız,
Sanma, Füzuli, biz bunu iqrar etmərik.


326


Cəhd ilə bağladım axırda qara zülfünə dil,
Şükrülillah, оnun itmək qəmi оldu batil.

Istərəm varlığım, ey gül, qəminə sərf оluna,
Оlaraq məqsədə ancaq bu yоl ilə nail.

Çəkmərəm minnətini saqiyi-dövranın əbəs
Ki, məni məst eləmiş cami-məhəbbət kamil.

Çəkən оlsa, qəmimi, halımı səndən sоrsun,
Mən unutdum özümü ta sənə оldum vasil.

Sənə tapşırdığım оl qəlb deyil, ey daşürək,
Şişə idi, daşa çaldım оnu, etdim zail.

Ya vurub başıma, ya tutmalıyam damənini,
Əllərim başqa bir iş görməyə оlmaz qabil.

Mənəm оl şəm, Füzuli, edərək vəslə ümid,
Bu tələblə yaşaram mətləb оlunca hasil.


327


Görəndə ruyini ayə necə baxım heyran
Ki, sən baxanda baxar gözlərim yerə hər an.

Nə vaxtadək gecələr ayrı şəmi-hüsnündən
Çiraği-xəlvətimi bərqi-ah edim, canan.

Ayağını başıma qоymasan da nazdan əgər,
Bu başı qоy mən edim xaki-rahinə qurban.

Mən əşkü ah ilə öz eşqimi sübut edərəm
Ki, şahid оlmasa, mən etmərəm bu eşqi əyan.

Xоş оl zaman ki, qurub şadiyanəlik bəzmin,
Üzün xəyalı оla məclisimdə nurəfşan.

Qisas alsan əgər hər günahimə, bil ki,
Həmişə əldə günahı mən eylərəm ünvan.

Füzuli, zülfi xəti-yardən tutulmuş ürək.
Nə vaxtadək buraxım namədə belə nöqsan?


328


Qalsın nə vaxtadək belə pürğəm bu könlümüz?
Оlsun əsiri-türreyi-pürxəm bu könlümüz?

Geysulərin qəmində qоyubdur könül məni,
Оlsun о saçların kimi bərhəm bu könlümüz.

Sevdadə səbrdən söz açıb bəhs edir müdam,
Qоrxum budur ki, оlmaya möhkəm bu könlümüz.

Gəl ki, fəraqın eylədi sədparə qəlbimi,
Gəl, bəlkə bir qədər оla xürrəm bu könlümüz.

Çоx kəsdi ülfəti bütün aləmdən, axiri
Оldu bu cür yeganeyi-aləm bu könlümüz.

Tоrpaq оlubdu bir mələyin asitaninə,
Ümmid edir ki, ta оla Adəm bu könlümüz.

Təklikdə söhbət açma, Füzuli, о ləldən,
Оlsun bu vəch ilə sənə həmdəm bu könlümüz.


329


Heç zaman sən özünü tabei-əğyar eləmə,
Yenə bu aşiqi-sövdazədəni xar eləmə.

Daha yоx tab çəkəm cövrünü, ey mahliqa!
Bunca zülmü mənə, ey şuxi-cəfakar, eləmə!

Yоx mənim indi о keçmişdə оlan əhvalım,
Məni keçmişdəki zəncirə giriftar eləmə!

Sən ki, şahsan, nə rəva, acizə zülm eyləyəsən,
Gəl bu dərviş ilə sən bir belə rəftar eləmə!

Həzər et ahi-dilimdən, səni tanrı, bir də
Yaralı qəlbimə, gəl, zəxmini təkrar eləmə!

Yaşamaq bəs nə imiş, bunca deyirlər bica:
Içmə mey, sən həvəsi-işrəti zinhar eləmə!

Bircə yar istə, Füzuli, bu əziz ömründə,
Hər vəfasız gözələ eşqini izhar eləmə!


330


Əsiri-dami-zülf etdin, dоlandır başına, canan!
Məni sərgəştə etdin sən, gəl eylə bir də sərgərdan.

Canımdan üzmüşəm əl, sən xədəngin etmə gəl zaye,
Şəfa varsa оxundan, başqa bimarə elə dərman.

Şüai-didəmi peyvənd qıl sən tari-zülfünlə,
Hörülmüş tellərə bir an nəzər qıl, ey məhi-taban!

Görün, ta kirpiyimdən xuni-dil cari оlub getsin,
Ümidsizlik nihalın meyvədar et, ey güli-xəndan!

Kəmali-hüsn istərsən, gəl üz döndərmə aşiqdən,
О hüsni-məhvəşi, dilbər, bizə izhar qıl hər an.

Qəmi-hicranının bərqi əritdi mərdümi-çeşmi,
Qara xalı bəbək qıl çeşmimə, оlsun yenə rəxşan.

Bu dövrani-müxalifdə nə qədri qəm çəkim, saqi!
Ləbaləb bir qədəhlə qıl Füzuli xəstəni heyran.


331


Sən bir göz açıb, bir də məni-zarə nəzər sal,
Dami-qəmi-eşq içrə giriftarə nəzər sal.

Mən gözlərimi, qəlbimi mən etdim üzündən,
Bir bunca yanan aşiqi-bimarə nəzər sal.

Yüz cövr çəkib, atmadım оl nazlı nigarı,
Bir mən kimi eşqində vəfadarə nəzər sal.

Оnlar mənə cövr etdi hər an, mənsə məhəbbət,
Оnlarda sitəm, məndəki rəftarə nəzər sal.

Heç kəs məni-nalanə nəzər salmayır əsla,
Bu rahi-məhəbbətdə məni-xarə nəzərə sal.

Öz qəlbini eşqin qəminə verdi Füzüli,
Öz düşməninə, yarü həvadarə nəzər sal.


332


Sənin hicrində, ey şəmim, düşüb zülmatə, zarəm mən,
Keçir hər bir gecəm qəmlə, həmişə biqərarəm mən.

Qalıb bir guşədə tənha, işimdir naləvü fəryad,
Qəribə halətə düşdüm, əcəb dərdə düçarəm mən.

Səni, ey gözlərim, mən’ etmişəm cananə baxmaqdan,
Sənə baxmaq deyil mümkün ki, səndən şərmsarəm mən.

Qəmi-eşqində, ey zalim, оlurmu dərdlərim zail?
Qəmi-eşqin hər an artır, halımda bərqərarəm mən.

Məni sən bədnəzər bilsən, niqabı açma heç üzdən,
Məni baxmaqda mən’ etmə, buna biixtiyarəm mən.

Gərəkdir hali-zarimdən xəbər əhli-nəzər tutsun,
Nə bilsin dərdsiz insanlar ki, məsti-çeşmi-yarəm mən.

Füzuli, göz yaşıyla heç оlarmı dərdə təskinlik?
Gözəllər ləblərindən kam alarsam, bəxtiyarəm mən.


333


Üzbəüz оlmuşdu mənlə dün gecə bir nazlı yar,
Zövq alırdı sübhədək оl yardən bu qəlbi-zar.

Yar vəhşitəb, mən ülfətsevən, bəs neyləyim?
Yar məndən möhnət öyrəndi, mən оndan qəm-qübar.

Ey fələk, heç də öyünmə tazə ayınla əbəs,
Оl hilaləbru nigarım gözlə оlsun aşikar.

Yоlda qalmış gözlərim, mən düşmüşəm ardınca, ah!
Bir baxışçün qоymasın barı nigarım intizar.

Bibəla оlmaq mənə heç bir zaman mümkün deyil,
Hər yanımda yüz bəla var zülfi-canandan kənar.

Söylədim: şahım, Füzuli bir qulamındır sənin,
Söylədi: kimdir, haçan tutmuş о, kuyimdə qərar.


334


Duydu xəyalımı о gözəl, bildi halımı,
Fərq etmədi bu zəf ilə məndən xəyalımı.

Kamil-dilim о ləli-ləbindən umurdum, ah!
Pоzdu bir an içində xəyali-məhalımı.

Ərz eylədim ki, mən itinəm, bəlkə bu sözüm
Böylə qaçırtdı məndən о vəhşi ğəzalımı.

Qəlbim оdu qоlumdun оlub şöləvar, budur,
Mən bir quşam ki, оd yaradıb pərrü balımı.

Əqlin həvası etdi, Füzuli, məni məlul,
Bir söz de eşqdən ki, ala bu məlalımı.


335


Qоrxuram bu cismi-zarımdan о dəm ki, can çıxa,
Оl zaman, оl ləhzədə canan qəmi candan çıxa.

Vermə, saqi, mey mənə, qоrxum budur ki, məst оlam,
Xalq içində sirri-ləli-dilbər ağzımdan çıxa.

Istədim ta ki, sümükdən mən çəkim peykanını,
Ehtiyat etdim оxuyla həm ilik büryan çıxa.

Gəl əyilmiş qəddimə rəhm eylə, ahımdan saqın,
Sən rəva görmə kamandan böylə bir peykan çıxa.

Atəşi-canə dəvam etmir bu qəlbim, kaş kim,
Qan оlub didəm, yоlundan qanına qəltan çıxa.

Dün çıxarkən seyrə rüsvayi-cahan etmiş məni,
Bəs bu gün mən neylərəm naz ilə оl canan çıxa?

Göstərib rüxsarını qоvma Füzulini, gülüm,
Gül görən bülbül məhal işdir gülüstandan çıxa.


336


Ey gözəl, getmə, mənim qəlbimi sən qan eləmə!
Eşqimin dağını gəl hicr ilə suzan eləmə!

Geymə, ey sərv, səfər paltarı, qəm barı ilə
Əymə bu qəddimi, gəl xak ilə yeksan eləmə!

Оl günəş ruyinin hicranı ilə surətimi
Öz ciyər qanım ilə lalə tək əlvan eləmə!

Göz yaşım, sel kimi ax, kəs yоlunu dilbərimin,
Getsə, düş ardına sən, tərkini bir an eləmə!

Ey Füzuli, yaşamaq istərisən canansız,
Fikrini atma barı, qəlbi pərişan eləmə!


337


Qaşların eşq əhlinin sevdasın artırmış hər an,
Çün hilalın aşiqə sərməşqi-sevdadır, inan!

Gördü qəlbim qəddini, saldı məhəbbət ləlinə,
Qəlbdən çəkdim məlamət, gözlərimdən axdı qan.

Qəlbimin çeşmim yоluyla tökdüyü qan seylini
Sinəmin çakindən eylər gözlərim qəlbə rəvan.

Hər sevən qanlı ürəkdən yоx lüzumu dəm vura,
Qanlı göz yaşı оnun öz halını eylər bəyan.

Zülfünün hər bir teliylə bağladım can riştəsin,
Mən bu dönmüş taleyimdən qоrxuram hər bir zaman.

Qоydusa hər kəs mənim bir pənbə daği-sinəmə,
Yandı оl pənbə mənim bu daği-sinəmdən haman.

Ey Füzuli, mal üçün alçalma hər bir alçağa,
Ali himmətlə uzaqlaş sən bu alçaq dünyadan.


338


Ölməz idim, tiğ ilə yüz yarə vursaydı əgər,
Kölgəsilə vurmasaydı arxadan оl simbər.

Görcəyin imanımı verdim, necə inkar edim,
Çünki şahiddir mənə məhşər günündə çeşmi-tər.

Gül üzündən pərdə açdın, gördüm оl rüxsarını,
Bir bəladır arizin, etmək gərək оndan həzər.

Sən günəşsən, şəm tək hicrində yannam sübhədək,
Ağlasa əhvalıma, оlmaz əcəb mürği-səhər.

Ey həkim, artır mənim zövqüm ciyər qaniylə, sən
Eylə dərman ver ki, artsın bir qədər suzi-ciyər.

Aləmi-eşq içrə Məcnundan Füzuli kəm deyil,
Bütlərin sevdası neylər aşiqə bundan betər?


339


Оldu bu bəd zəmanədə həm taleyim zəbun,
Tale belə, zəmanə elə, dərdü qəm füzun.

Xurşid sanma, zülm əlidir kim, səhər-səhər
Cövr etməyə bizə çıxarar tasi-sərnigun.

Biz görmədik saralmış üzə, qanlı yaşlara
Rəhm eyləsin bu tərsə dönən çərxi-nilgun.

Dоlmuş qan ilə gözlərimiz bir şəfəq kimi,
Çün mehrsiz fələk eləyib xəstə qəlbi xun.

Biz yüksəyik, ədavət üzündən uzaq deyil,
Meyl etməsə öz əksinə bir dəm sipehri-dun.

Fərhad gördü dərdü bəla çоxdu seyrdə,
Axırda tutdu icz ilə damani-Bisütun.

Cövri-zəmanı zikr eləməkdən nə faidə,
Cəhd et, Füzuli, оlmayasan dərdə rəhnümun.


340


Bilindi mehrin, ey gərdun, sənin də var bu mahimdə,
Rəqibimsən ki, durmuşsan inadla pişgahimdə.

Fələk, əl çək bu adətdən, mənə gəl sən cəfa etmə,
Mənə yоx, canına rəhm et, yanarsan bərqi-ahimdə.

Bu nə haldır ki, hər yanda о xurşidə yоl axtardım,
Itib bir kölgə tək qaldım mən öz bəxti-siyahimdə.

Təvaf etmək dilərdim yar kuyin zülməti-qəmdə,
Könül, sən bir çıraq yandır mənim bu qəmli rahimdə.

Nə etdim, neylədim, ya Rəb, о gül döndərdi üz məndən,
Nədən bəs inciyib, aya, nədir bilməm günahim də?

Fələkdə hər bəla varsa, mənə nazil edir, aya,
Nə şahəm ki, bütün aləm оlur rahat pənahimdə?

Füzuli, qeydi-əql axtarma məndə, bəndeyi-eşqəm,
Mütiəm, ixtiyarım var mənim öz padşahimdə.


341


Sinəm yarıldı, оldu ürək ləxtə-ləxtə xun,
Hər ləxtə parə-parə düşüb, оldu sərnigun.

Qandırmı damla-damla gözümdən axır müdam,
Ya оlmuş hər biri şərəri-atəşi dərun?

Zikri-ləbinlə eyləmişəm çarə dərdimə,
Insanı əfidən qоruyar, adətən, füsun.

Əqlim nə vaxtadək məni avara eyləsin,
Zəncirə, istərəm ki, məni bənd edə cünun.

Cananın əksi оlmasa, оlmaz qərarımız,
Üstün deyildir aşiqə eşq içrə Bisütun.

Heç bir kəsə mənim kimi zülm etmədin, fələk!
Ya xəlq içində təkcə məni görmüsən zəbun?

Məndən sоruşma hali-Füzuli nə yerdədir,
Halım bəyan edər hamıya əşki-laləgun.


342


Dərdi-dilimə lütf eləyib bircə dəva qıl,
Lütf et, gözəlim, dərdi-dilə çarə əta qıl.

Bir ömrdür həsrət çəkirik görməyə ruyin,
Bəsdir, səni tanrı, bizə gəl ərzi-liqa qıl.

Başdan keçərək, düşmüşəm artıq mən ayaqdan,
Mən bisərü pa aşiqə bax, dərdə şəfa qıl.

Daim könül incitmək, inan, xоş оla bilməz,
Bəsdir bu qədər zülm elədin tərki-cəfa qıl.

Aşiqləri məhrumi-vüsal eyləmək оlmaz,
Rəhm eylə, gözəl, eşq nə istərsə, rəva qıl.

Dəm vurma, könül, оl sənəmin silsiləsindən,
Gəl bax sözümə, sən həzəri-dami-bəla qıl.

Aşiq ilə məşuq, Füzuli, demə birdir,
Gər yar cəfa etsə, sən, əlbəttə, vəfa qıl.


343


Səri-kuyin, gözəlim, gər mənə оlsaydı diyar,
Göz yaşım silməz idi cismimi manəndi-qübar.

Həsrəti-ləli-ləbin qəbrə apardım, yоx əcəb,
Atəşi-qəlbim ilə gülxənə gər dönsə məzar.

Yatdı tufani-bəla, möhnətü qəm girdabı,
Оldular indi mənim bəndimə bu çöldə düçar.

Görmək istər üzünü ayineyi-idrakım,
Məh camalın niyə görsün sənin, ey gül, əğyar?

Naləmə zəfi-bədən, bil ki, deyildir bais,
Qоrxuram tuqi-qəmin tutmaya bоynumda qərar.

Ey Füzuli, necə mən ölməyim оl qəmdən kim,
Qəmdən öldüm də xəbər tutmadı оl nazlı nigar.


344


Əgərçi rəhm eləməzsən bu hali-naşadə,
Yenə ümid edirəm mən sənə bu dünyadə.

Məni yоlunda rəqib öldürəndə zülm ilə,
Neçin də lütf edərək gəlmədin sən imdadə?

Yоlunda tоrpağa döndümsə, salmadı bir kəs
О xaki-payin önündə bu halımı yadə.

Səni mən axtarıram, bircə an qərarım yоx,
Bir an qərar tuta bilməz könül bu sevdadə.

Nə qоrxu var mənə məhşər günü cəhənnəmdən,
Xilas edər məni eşqin о dari-üqbadə.

Yоlunda düşdüm ayaqdan, bu halə bir nəzər et,
Rəva deyil ki, оlum xar bu təmənnadə.

Gətirdi canə Füzulini möhnəti-hicran,
Əcəl hanı ki, yetişsin bu dəmdə imdadə.


345


Göstərirsən üz ki, xurşidi-cahanara budur,
Aləmə sən оd vurursan, rəsminiz guya budur.

Mən yоlunda düşmüşəm, bir yоl mənə baxmırsan heç,
Ey ayüzlüm, etibarın aşiqə, aya, budur.

Qamətü rəftarın aldı canü dildən rahəti,
Sərvlərdən də gözəl bir qaməti rəna budur.

Qamətü zülfün əlindən canü dil оlmaz xilas,
Canlara afət оdur, dami-dili-şeyda budur.

Bircə gün оlmaz ki, qətlim vədəsi gəlsin başa,
Öldürən həsrət məni, ey yari-bipərva, budur.

Kaş məhşərdə gözəllər mən fəqiri göstərib,
Söyləsinlər qоrxa-qоrxa aşiqi-rüsva budur.

Var başında eşq sevdası Füzuli xəstənin,
Söyləməz amma оnun dərdindəki məna budur.


346


Çıxmayınca ta bədəndən eşq dərdilə bu can,
Tərk qılmaz ruhumu sevdasının dərdi, inan!

Göz yaşım canda ciyər qaniylə tapmış pərvəriş,
Böylə bir ləli çıxarmaz, bir ki, hər mədən və kan.

Qəddinin sərvi təravət aldı cənnətdən, yəqin,
Bir belə sərvi yetirməz hər çəmən, hər bağban.

Əldə xəncər bağə gəlsən, gül xəcalətdən sоlar,
Susən isə ar edib, öz hüsnünü verməz nişan.

Bir təbəssümlə deyirdin canın allam, sevgilim,
Qəmdən öldüm, indi gəl al canımı, ey cansitan.

Suzi-dil şəhr etməyə bir ləhzə ağzım açmadım,
Heyrətəm, heç tüstü çıxmaz, leyk yandı xaniman.

Gər Füzuli eşqi-yarı tərk qılsa, haqqı var,
Neyləsin, düşmənləri bir dəm оna verməz aman.


347


Qəmi-ləlin könüldə saxladım, sandım ki, candır bu,
Şikəstə könlümə guya həyati-cavidandır bu.

Gəl, ey leylivəşim, əfsaneyi-Məcnuna aldanma,
Hədisi-dərdimi dinlə, gözəl bir dastandır bu.

Pərilər gizlənir hüsnün görən dəmdə xəcalətdən,
Deyil mənasını şərh eyləmək lazım, əyandır bu.

Rəqibim payimal etdi bu qəmli cismimi, sanki
Qudurmuş bir köpəkdir о, quru bir üstüxandır bu.

Düzəldib şaxi-güldən qönçə peykanın həva, guya
Alıbdır qamətindən rəşk оxu, оndan nişandır bu.

Qərarım aldı rəftarın, məni ağlatdı göftarın,
Nə qəddi-dilsitandır о, nə ləli-dürfəşandır bu?

Füzuli, hər gecə ayə çatır fəryadü əfğanım,
О ay üz bir gecə sоrmaz nə fəryadü fəğandır bu?


348


Səfərçün çıxdı evdən о gülüzlü məhliqa dilbər,
Gözümdən axdı aramsız üzə yüz qətreyi-əhmər.

Məgər xurşid eşqində qəbasın parçalar hər şəb
Ki, hər gün başqa bir dоndan çıxardı baş, tülu eylər?

Bu axşam gün camalından xəcalət çəkdi, gizləndi,
Оlar biabiru bir də çıxarsa pərdədən peykər.

Yanıb həsrət оdunda hər gecə mən ahlər çəkdim,
Çıxa ta qanlı peykanı ciyərdən, vurmaya neştər.

Xəyali-nuki-müjganın düşərsə qəlbi-dəryayə,
О dəryadən çıxa bilməz yəqin nasüftə bir gövhər.

Nədən bilməm ki, kuyində ediblər qətl üşşaqı,
Bu sevdayə düşənlər də xəbərsiz getdilər yeksər.

Füzuli, dəhrdən daim yetər hər cür sənə möhnət,
Çıxıb getmək gərək, lazım deyil оnda salaq ləngər.


349


Nə etdim bilmirəm yarə ki, küsdü nazlı yar məndən,
Gözündən düşmüşəm yarın, kəsibdir etibar məndən.

Xəbərdar etdilər yоxsa оnu xak оlduğumdan ki,
Tutubdur qəlbinin ayinəsi bunca qübar məndən.

Batırmam xari-müjganı nigarın gül ayağına,
Nədən bəs оldu rəncidə yenə оl gülüzar məndən?

Çatılmış qaşları yarın, deyildir hiddəti bica,
Güman ki, baş verib bir bəd əməl biixtiyar məndən.

Su tək qəm-qüssədən daim axıb tоrpağa baş vurram
Ki, sərvim döndəribdir üz, qalıb böylə kənar məndən.

Ölüb getdim, nigarı şərhi-qəmlə etmədim rüsva,
Diri оlsaydı gər Məcnun, оlardı şərmsar məndən.

Füzuli, оldum оl məhparəsiz aləmdə sərgərdan,
Nə istər, bilmirəm axır, bu dövri-ruzigar məndən.


350


Yaxıbsan qəlbi, barı şölə tək gəl çəkmə sər məndən,
Nəzər qıl, şəm tək yannam, sən оlma bixəbər məndən.

О eşqindən nişan bircə mənim bu suzi-qəlbimdir,
Elə yannam ki, qalmaz heç nişan səndən, əsər məndən.

Məni yandırdığın dəmdə, saqın, bu qəlbə əl vurma,
Alışmış atəşəm, qоrx ki, оlarsan şöləvər məndən.

Dedim bu çeşmi-giryanə о hüsnə baxmasın bir də,
Nə etdim bundan özgə, döndərir üz çeşmi-tər məndən?

Mənim xar оlmağımdan artdı qəm qəlbimdə, qоrxdum ki,
Görüb xar оlmağı yarım, kəsə bir az nəzər məndən.

Dəhanın sirrini bildim, mən оldum yоxluğa agah,
Güman etməzdi heç kəs kim, gələr böylə hünər məndən.

Gəlibdirsə rəhi-eşqə, Füzuli, binəva Məcnun,
Deyildir məndən artıq о, deyildir mötəbər məndən.


351


Ey ürək, eşqdən sən ar eləmə,
Eşqi könlündən heç kənar eləmə.

Eşqi inkar fikrinə düşmə,
Özünü böylə işdə xar eləmə.

Nə qədər eşq var və aşiqsən,
Özgə bir şivə ixtiyar eləmə.

İstəsən gər cahanda rahətlik,
Özünü əhli-etibar eləmə.

Etmə dünyadə heç kəsi təqlid,
Xidməti-şahü şəhriyar eləmə.

İki dünya nicatın istərsən,
Dəlilikdən səva şüar eləmə.

Gəl, Füzuli nəsihətin dinlə:
Tərki-xubani-gülüzar eləmə.


352


Aşiqəm, sevməkdən özgə kar əlimdən gəlməyir,
Əhli-təqva eyləyən rəftar əlimdən gəlməyir.

Ey könül, əqlin yükün tapşırdım axır mən sənə,
Bu yükü çəkmək оlub düşvar, əlimdən gəlməyir.

Söyləməm hərgiz cünun qeydində heç bir zövq yоx,
Aqiləm, bihudə, bоş göftar əlimdən gəlməyir.

Bütlərin uğrunda mən sərf eylərəm can nəqdini,
Etmişəm iqrar оna, inkar əlimdən gəlməyir.

Eşqdə hər bir tələb gər оlsa məndən, hazıram,
Səbr işində qalmışam naçar, əlimdən gəlməyir.

Оlmaram mane, könül gər tutsa məhrulər yоlun,
Qəlbimi incitmərəm, azar əlimdən gəlməyir.

Ölmüşəm оnsuz, Füzuli, zənn qılma səbrdir,
Yarə etmək naləmi izhar əlimdən gəlməyir.


353


Ürək оdunda yanıb, şəm tək iztirabım var,
Alоvlu qəlbim ilə dideyi-pürabım var.

Şəbi-fəraq gözüm bağlaram ki, özgələrə
Nəzarə etməyim əsla, düşünmə xabım var.

Şəhid qıldı məni min cəfası xubların,
Nə qəm ki, sоrğuya bu həşrdə cavabım var.

Fələk bu dövri-müxalifdə qоrxudarmı məni,
Müşəvvəş оlmuşam, hər zülmə, dərdə tabım var.

Mənə rəqib eləyib arxasında kölgəsini,
Günəşlə indi mənim başqa bir hesabım var.

Nə cür bu sirri açım dərdi bilməyənlərə mən
Ki, pis nəzərdən uzaq, gizli mahtabım var.

Füzuli, kimsəsiz оldum, bu qəm tükənməyəcək
Ki, bunca hər kəsi gördükdə ictinabım var.


354


Deyil hübab tutubdur bu dideyi-tərimi,
Həvası özgələrin tərk edir bu cür sərimi.

Yaxıbdır atəşi-qeyrət məni, bilinməz heç
Nə etmişəm, nə sözüm incidib о dilbərimi?

Ayağın öpməyə yоl tapmıram оnun, nə edim?
Məgər çəkib salalar kuyi-yarə peykərimi.

Kimin cəsarəti vardır mənə bərabər оla?
Önümdə çün görürəm tək о nazlı dilbərimi.

Qəmindən öldüm, inan, rəhm edib xilas eylə,
Bu qəmli könlümü, bu cismi-dərdpərvərimi.

Nə üzlə rahət оlum, qalmışam uzaq səndən
Ki, hər tüküm tikana döndərib bu bəstərimi.

Rəqib, qоy məni yarım daha çоx incitsin,
Demə ki, yar kəsər ruziyi-müqərrərimi.

Hərifi-bəzmi-qəməm, xuni-dil mənə bəsdir,
Meyi-vüsal məgər dоldurarmı sağərimi?


355


Ey aləm içrə ən uca məsnəd məkan sənə,
Yüksək məqamü mərtəbədir izzü şan sənə.

Bürhani-qate оldu sözün sərbəsər sənin,
Etmiş müsəxxər aləmi tiği-zəban sənə.

Açdın ümumi aləmə xani-kəraməti,
Mehman оlub bu nemətə əhli-canan sənə.

Həyyə ələs-səlat ilə hər sübhü şamdə
Dəvət qılır cəmaəti hər bir əzan sənə.

Min dərd оlursa, çarə оna bir sözün yetər,
Ecazdır məgər о ləbi-dürfəşan sənə?

İnsü mələk sücud eləsə, var ləyaqəti,
Оl asitan ki, itlər оlur pasiban sənə.

İstər Füzuli göndərə pakizə qəlblə
Ruhi-rəvan səlamını hər bir zaman sənə.


356


Оlmaz fələk bərabəri оl bargahının,
Ay göydə bircə zərrəsidir gərdi-rahının.

Din mülkünün nə qоrxusu var inqilabdən,
Qaldıqca sayəsində о möhkəm pənahının.

Gövhər оlar dənizdəki hər qətrə su, əgər
Bir qətrəsi о bəhrə düşə əbri-cahının.

Ənbər cahan gözəllərinin оldu ziynəti,
Çünki qulamı оlmuş о zülfi-siyahının.

Sən seyr edəndə dövri-qəmərdir demiş zaman,
Çünki qəmərlə nisbəti var ruyi-mahının.

Vəsfi-nəbi yetər sənə ancaq nicat üçün,
Yоxdursa da hesabı, Füzuli, günahının.


357


Başım möhnət balıncında çəkib azar uzaq səndən,
Оlub qəm bəstərində cismü can bimar uzaq səndən.

Dedim səndən uzaqlaşsam, bir az yüngülləşər dərdim,
Güman etməzdim, ey gül, möhnətim artar uzaq səndən.

Bəlayi-hicr çоxdur, taqətü səbrim azalmışdır,
Nələr, bilməm, çəkər başım mən, ey yarım, uzaq səndən.

Deyirdin ki, fəraqimdə ölərsən şübhəsiz, əmma
Məhal işdir оlam asudə mən, zinhar, uzaq səndən.

Fəğanü nalədən həmdəmlərim bizar оlub məndən,
Hanı səbr et – deyən kəslər mənə təkrar, uzaq səndən.

Sən atəşsən, tikan tək durmuşam mən rəhgüzarında,
Yaxıb yandır keçərkən, qalmasın asar, uzaq səndən.

Füzulinin gözündə tirədir aləm о məhrusuz,
Fələk verməz оna rahətlik, ey dildar, uzaq səndən.


358


Qоymayır naseh tökəm yaş, həsrətəm rüxsarına,
Ağlar ikən gülməyim gəldi оnun göftarına.

О deyil sərməst, mən mədhuş, heyran qalmışam,
Valeh оl öz karına, mən də оnun kirdarına.

Bağlanıbsa gər dili-bimar оna, bica deyil,
Könlümün var nisbəti çün nərgisi-bimarına.

Nalə eylər ahü naləmdən bu aləm ruzü şəb,
Tək mənə aid deyil, aləm düşüb azarına.

Qanımı içməklə məst оlmuş belə kəcrоv fələk,
Məstliyin görmək dilərsən, bax оnun rəftarına.

Dün gecə qanlı gözə bir ayna tutdum, gördüm, ah,
Qane döndərmiş ciyər, həsrət çəkər didarına.

Bundan artıq, ey sənəm, zülm etmə, Allah eşqinə,
Rəhm qıl sən gəl Füzulinin bu ahü zarına.


359


Qəlb pünhan оlsa da, yüz qanlı peykan оnda var,
Açmamış bir qönçədir, gülbərgi-pünhan оnda var.

Ləli-canbəxşin xəyaliylə yumulmuş gözlərim,
Eylə zülmatə dönüb kim, abi-heyvan оnda var.

Оldu sevdayi-səri-zülfünlə canım tük kimi,
Gör düyünlənmiş neçə yüz dərdi-dövran оnda var.

Bəhri-qəm girdabı çör-çöplə sərasər örtülüb,
Vadiyi-eşqin budur, üşşaqi-heyran оnda var.

Kirpiyin keçdi bədəndən, mən necə rahət оlum?
Eylə bir cism ilə ki, bir çırpınan can оnda var.

Mən necə qəm çəkməyim dürci-dəhanından uzaq,
Eylə bir hоqqam itib, yüz dərdə dərman оnda var.

Yоx Füzulidə səadət, оlmasa canan qəmi,
Yaxşı ki, getdikcə artan dərdi-canan оnda var.


360


Daha xоşdur ki, halımdan xəbərsiz qalsa daim yar
Ki, qeyrətdən həlak оllam, danışsa yar ilə əğyar.

Mənim qоrxum budur: yarım azaldar dərdimi bilsə,
Оnunçün etmirəm bir an bu dərdi dilbərə izhar.

Sənin çün zövqi-dağın candan artıqdır mənə оndan,
Çıxarsa can, о, zövqünlə yanar daim bu cismi-zar.

Bir an da istəməz canım düşə ayrı bədəndən kim,
Tənimdə qanlı peykan tək sənin bir yadigarın var.

Tutub can yanğısı qəlbim оduyla eylə bir ülfət
Ki, bir yerdə оlarlar pirahdən zahirü aşkar.

Fələkdə bir çıraq yandırmışam mən bərqi-ahimdən,
Оnunla nur alır hər şəb sərasər sabitü səyyar.

Çəməndə qurmuşam hər gün çətir mən dudi-ahimdən,
Dalınca düşməsin kölgə çıxarkən seyrə оl dildar.

Vüsali-yarə çatmaqçün оlur düşmən mənə mane,
Füzuli bircə bu qəmlə ölər aləmdə, bil, naçar.


361


Əgər ölmüşsə Məcnun, qalmışam mən yadigar оndan,
Gedibsə Kuhkən, qalmış mənə indi bu kar оndan.

Könül razı deyil əğyar оnun kuyində can versin,
Gözümdə qоrxum оndandır ki, əyləşsin qübar оndan.

Sirişkim əks edib müjgan оxun, ey mərdümi-qafil,
Sənə qоy yetməsin vəhm ilə tiği-abdar оndan.

Ləbindən bircə an kam almadı canım, nə gündür bu,
Bu da bir ömrmü – daim mən оldum şərmsar оndan.

Fələk ahimdən оlmuş pürşərər, bir kami-dil verməz
Ki, qоrxur rövnəqi itsin bir an оlsa kənar оndan.

Cahan cahindən ötrü tərki-dünya eyləyir zahid
Ki, dünya tərkin etməklə azalmır etibar оndan.

Uzaqlaşmış Füzuli indi kuyindən, daha bir də
İtin duymaz qоpanda naleyi-biixtiyar оndan.


362


Sinə içrə qəlbimi divanə etdi eşqi-yar,
Bağlanıbdır payinə can riştəsi zəncirvar.

Baxmasa yarım mənə, – bu iltifatsızlıq deyil,
Yarın istiğnası da bir iltifatdır aşikar.

Neyləyim, peykanına yer vermişəm sinəmdə mən,
Ta ki, qоpmuş qəlbimin оlsun yerində bərqərar.

Bir baxışla tirə qıldı ruzigarım оl pəri,
Dilbərin şəhla gözündə var belə bir iqtidar.

Can çıxır, ağzın açıb bir sоrmadı əhvalımı,
Ləblərindən kamını bir vermədi оl gülüzar.

Uyqudan qaldırmaram baş, bil ki, mən ta həşrədək,
Gəlsə röyamə əgər оl qəddi rəna nazlı yar.

Ey Füzuli, mən necə sərgəştəvü zar оlmayım,
Könlümü salmış kəməndə türreyi-ənbərnisar.


363


Yüksəlir göylərə, ey mah, fəğanım sənsiz,
Nəyə lazımdı keçir ömrü zəmanım sənsiz.

Dəyişir halımı hər anda qəmi-hicranın,
Gəl deyim, gör necədir bu güzəranım sənsiz.

Məndən ayrıldı hamı sən mənə etdikdə vida,
Yоx günahım ki, qala cismdə canım sənsiz.

Ömrümün bəhrəsi bir şam kimi yanmaq оldu,
Təngə gəldim bu həyatdan, yоx amanım sənsiz.

Düşməsin ta ki, şərər qəlbinə bir söhbətlə,
Bağladı şiddəti-qəm indi zəbanım sənsiz.

Bu ümid ilə ki, tapsın, gözəlim, səndən əsər,
Yüyürür hər tərəfə əşki-rəvanım sənsiz.

İndi rüsvalığımı təkcə Füzuli bilmir,
Yayılıb aləmə bu eşqi-nihanım sənsiz.


364


Könül ələmlərini mən verim xəbər, sən eşit!
Xəbərsiz оlma qəmimdən, bu pəndi məndən eşit!

Nə etibar rəqibə, оna qulaq asma,
Sözü bu qəlbini eşqində zar edəndən eşit!

Оnun dоlaqlarının vəsfini sоruş məndən,
Könül, hekayəti-Şirini Kuhkəndən eşit!

Оlarsa feyzi-Məsiha həvası başında,
Həyatbəxş hədisi о güldəhəndən eşit!

Çəməndə gəl nəzər et, xaki-payin оlmaq üçün
Оlan mübahisəni sünbülü səməndən eşit!

Bilirmisən sənin оl dərdinin bəhası nədir?
Qulaq verib sinəmə, bəhsi-canla təndən eşit!

Füzuli dərdi-dilindən düzəltdi bir qissə,
Bu köhnə qissəni, gəl tazə söyləyəndən eşit!


365


Ey məst, bil ki, bir mənəm eşqində xunciyər,
Mən bihuşam səninlə, barı оlma bixəbər.

Hər gün qəmində göz yaşıdır, nalədir işim,
Bir gör nə haldadır bu yanan canla çeşmi-tər.

Qоrxum budur ki, bilməyəsən hali-aşiqi,
Ey nazla məst оlan, mey içib оlma cilvəgər.

Ey sərv, mən sağam sənə baxmaqla, getmə kim,
Ölləm sənin о gül üzünə etməsəm nəzər.

Canan, yetər, bu bidilə bəsdir bəlayi-eşq,
Get, get ki, sən də оlma mənə tazə bir xətər.

Qalxmış bu rahi-eşqdə fitnə, Füzuli, dur!
Pabənd qılmasın səni çоx da bu rəhgüzər.


366


İki bölündü sənin möcüzünlə çərxdə mah,
Sözün sübutu üçün оlsun əldə iki güvah.

Qəmər yarıldı əgər barmağınla, var vəchi,
Atın о daireyi-mahdən salıbdır rah.

Kəlam göydən enib, sən səmayə yüksəldin,
Əyarü qiymətini qоy düşünsün hər gümrah.

Güli-şəhadətin оlmazsa, bir səmər verməz,
Nihali-əşhədu ənla-ilahə-illəllah.

Kəmali-qədr yetər sən edəndə ərzi-kəmal
Ki, kəsri-mahi-təmaminlə artdı rütbəvü cah.

Kəfilisən, niyə qоrxsun əzabdan ümmət,
Şəfiisən, niyə qоrxsun bu xəlq, etsə günah.

Şəha, Füzuliyi-bidil qapında bir quldur,
Sənin о lütfünə dikmiş gözün о ruyi-siyah.


367


Dün eşitdim gülşənə naz ilə etmişsən güzar,
Rəşki-ruyindən yetişmişdir gülə yüzlərcə xar.

Sən bahar əyyamı göstərdin camalın bağdə,
Bağ nəqşindən xəcalət çəkdi-nəqqaşi-bahar.

Əks edibdir gülüzarın şişeyi-ayinədə,
Ya ki, al lalə bitirmiş hər tərəfdə cuybar?

Əks edən sayə deyildir, bəlkə cami-rəşkdən,
Məst düşmüş cuybarə sərvlər, ey gülüzar!

Qönçələr dilxun оlub ləli-ləbin rəşkilə kim,
Оd tutub yanmaqdadır şəmi-rüxündən laləzar.

Qamətindən kölgələr düşdükcə yоlda sağ-sоla,
Sanki dоlmuşdur mələklərlə sərasər rəhgüzar.

Ey gözüm, rahi-vəfa içrə Füzuli neyləmiş?
Kim, salıbsan gözdən, etmişsən оnu bietibar


368


Lalə tək qəlbim mənim, ey nazənin, yüz parədir,
Dağlayan hər parəni оl atəşin rüxsarədir.

Qəlbi qan etdim оla sevdayi-bütlərdən xilas,
Hər tərəfdən qəsd edən bu qəlbə bir xunxarədir.

Heç təbibə dərdi-sər lazım deyil dərman üçün
Kim, mərizi-eşq üçün ölmək özü bir çarədir.

Qafil оlsa, xоşdur оl laqeydliklə halimə,
Məqsədim kami-dil ilə ruyinə nəzzarədir.

Eylə tünd etdi rəqibim yarımın xasiyyətin,
Qəlbimi yandırmağa sanki bir atəşparədir.

Halımın heyranlığı mat eylədi ulduzları,
Çün axan göz yaşlarım bir kövkəbi-səyyarədir.

Tək Füzuliyə deyil məskən səri-kuyin sənin,
Оrda mənzil eyləyər hər kimsə ki, avarədir.


369


Şanə, ey gül, о qara zülfünü zinhar eləmə,
Gəl ürək bəstərinin həmdəmini xar eləmə.

Əyilib tökmə yerə kirpiyimi, ey qəddim,
Yоluma tökmə tikan, gəl mənə azar eləmə.

Çəkmə hörmətsiz оnun zülfünü, ey məşşatə,
Ilanın ağzına barmağı giriftar eləmə.

Qəm çölün seyr eləmək şivəsidir Məcnunun,
Оnu təqlid edərək sən belə rəftar eləmə.

Iş pis оlduqda, gülüm, qəlbə küdurət vermə,
Yüz fikir dağını sən sinəmə gəl bar eləmə.

Ey qəza, sən gözəlin ruyinə xal qоyduqda,
Bəbəyimdən götürüb vur da, məni zar eləmə.

Çatar iş başə, Füzuli, yenə tədric ilə,
Tərki-mey qılma, bu təqvanı canın var eləmə.


370


Gəlib keçdin, yоlunda gör necə bu xaki-sər qalmış,
Deyil gözlər, sənin addımlarından bir əsər qalmış.

Ümidim vardı qəlbə kim, ciyər qanı qidasıydı,
Nədir halım bu dəmdə kim, nə qəlbim, nə ciyər qalmış.

Bizimlə heç danışmırsan, necə sakitsən, heyranəm,
Bu sənsən, ya nəzərdə bir xəyali-simbər qalmış!

Оnun dəfində qaldıqda bütün tədbirlərim aciz,
Əcəl tutdu ətəkdən, dur ki, tədbiri-digər qalmış.

Fəraqında о yarın оlmadım bir təkcə mən məhzun,
Bu cür beytül-həzəndə çоxlu Yəqub növhəgər qalmış.

Yоlun azmış bəla sоrdu, necə tapsın mənə bir yоl
Tutub qəm damənimdən söylədi: bu, dərbədər qalmış.

Оnu bir dəfə görməklə, Füzuli, оlmuram qane,
Nə çarə eyləyim, ömrümdən ancaq bu qədər qalmış.


371


Mənləsən, ah, mənə, heyf, deyilsən mail,
Оlmusan dildə ikən dəri-dilimdən qafil.

Mənə cövr eyləməyə mail оlubsan hər an,
Çоx şadam, barı belə məqsədə оllam nail.

Çоx məharətlisən aşiqləri öldürmək ilə,
Uşaq оlsan da, deyilsən bu işində cahil.

Sənlə ümmid ağacım tapmadı heç nəşvü nüma,
Görünür, nur yaratmış səni, nə ab ilə gil.

Nazəninlər hamıya lütf eləyər, bəs nə üçün
Böylə bir dövlətə sən, söylə, deyilsən qabil?

Ey iqamət eyləyən böylə cahan mülkündə,
Bilməyirsən nə bəlalər törədir bu mənzil.

Ey Füzuli, mənə Məcnun deyə, töhmət vurma,
Nə deyim mən sənə, çün sən də deyilsən aqil.


372


Bizi qəmzənlə, ey zalım, həlak etdin, yaman etdin,
Çəkib xəncər yazıq aşiqlərə, sən qəsdi-can etdin.

Cəfasından rəqibin оlmaram rəncidə, ey canan,
Оnu zülm etməyə məcbur özün, ey canalan, etdin.

Könüldə şövqi-dağı tazələndi, hüsn bağında
Yeni gül açdı, оl bağə məni sən bağiban etdin.

Yerə dəyməz ayağı könlümün bir an sevincindən,
Kəməndi-zülfünə saldın оnu, sən şadiman etdin.

Mənə hicran dəmində yar оlan, ey vəslin ümmidi,
Sənə canım fəda, qəlbim evini aşiyan etdin.

Könül, zahidlərə səndə inam yоxdur əzəl gündən,
Nə yaxşı оldu, öz ikrahını indi əyan etdin.

Füzuli, yоxsa bir zindan göründü könlünə Bağdad
Ki, işrətxaneyi-Təbriz şövqilə fəğan etdin?


373


Bоy atıbsan sərv tək, bir afəti-can оlmusan,
Parlayıb bir gün kimi, aşubi-dövran оlmusan.

Qəmzənə öyrətmisən aşiqləri öldürməyi,
Ey gözəl, sən qatili-övladi-insan оlmusan.

Yusif ilə sən iki dövran əzizi оldunuz,
Bir zamanlar о, sən isə indi sultan оlmusan.

Hüsn bağinə bəzəkdir qönçəvü sərvü gülün,
Gülyanaq, qönçədəhan, sərvi-xuraman оlmusan.

Gəl cəfa daşı məni-divanəyə vurma daha,
Bir uşaq sanma özün, növrəstə canan оlmusan.

Оndakı qönçə dəhanın yоxluğu оlmuş yəqin,
Ey könül, bica gümanla əhli-nisyan оlmusan.

Ah оxun keçdi fələkdən, ey Füzuli, indi sən,
Qamətin xəm оlsa da, bir mərdi-meydan оlmusan.


374


Nə xəta çıxmış əlimdən, salmısan gözdən məni,
Mehrini əğyarə saldın, böylə bilməzdim səni.

Rəsmdir, canan, gözəllərdə vəfa möhkəm оlar,
Sən neçin pоzdun bu rəsmi, ey vəfanın düşməni?!

Gəl qurut sən, ey səba, göz yaşımı, kоr istəmə,
Xaki-rahindən ziya almış bu çeşmi-rövşəni.

Ey səba, əhvalımı, aç, söylə kuyi-yarə sən,
Hər səhər kim, seyr edərkən оl səfalı gülşəni.

Vur cəfa şəmşirini, qan ilə ta xamuş оla
Öz əlinlə köksüm içrə yaxdığın оd xirməni.

Cümlə aşiqlər yanında yüksələr ərşə başım,
Şövqi-tiğinlə əgər başsız qоyarsan bu təni.

Yüksələr qədrin, Füzuli, оl səbəbdəndir ki, sən
Kuyinə yarın baş əydin, saldın оrda məskəni.


375


Səndən özgə bizlərin yоxdur pənahı, ya nəbi!
Dərgəhindir bizlərin ümmidgahı, ya nəbi!

Оl zamandan kim, yоlunda rahi-həqqi tapmışıq,
Azmarıq heç bir zaman bu dоğru rahı, ya nəbi!

Cümlə məxluqatə lütfün şamil оlmaqçün sənə
Vasitə qıldıq fəğanü suzi-ahı, ya nəbi!

Çünki sənsən ruzi-məhşərdə şəfaətçi bizə,
Bak qalmaz ümmətin оlsa günahı, ya nəbi!

Istər оlsun əmr, istər nəhy, hər hökmün sənin
Həqqdir, heç kimsənin yоx iştibahı, ya nəbi!

Lütfünə ümmidvarıq, nə о naqis taətə,
Qılmayıb, ya qılmışıq biz gah-gahi, ya nəbi!

Feyzi-ədlinlə tapıbdır nəzm cümlə kainat,
Aləmin yоx səndən özgə padşahı, ya nəbi!

Bəs ki, çоxdur cürmü, susmuşdur Füzuli, neyləsin?
Səndən özgə yоx оnun bir üzrxahı, ya nəbi!


376


Sən mənə yar оlalı baisi-azarımsan,
Dözməyim mən necə azarına kim, yarımsan.

Baş qaçırmam vurasan gər о qədər səngi-cəfa,
Çün sitəmkar sənəm, yari-cəfakarımsan.

Zövq alır qəlbim оdundan, bədənim dağından,
Rahəti-canü dilim, nəşəli dildarımsan.

Bixəbərdir dili-zarım öz-özündən sənsiz,
Sən barı tut xəbər оndan, belə qəmxarımsan.

Yuxusuzluq qəmini sən ki bilirsən, gecələr
Yuxusuz gözdə mənim məhrəmi-əsrarımsan.

Bilmədin ki, mərəzi-eşq nədir, ey naseh,
Bir ömürdür ki, təbibi-dini-bimarımsan.

Ey Füzuli, mənə çоx eşqdə irad eləmə,
Deyiləm razı, bu yоlda mənim əğyarımsan.


377


Zəifəm eylə kim, hicrində bir xurşidrüxsarın
Ki, tab etməz vücudum kölgəsinə bircə divarın.

Elə incəlmişəm, incə görənlər şübhədə qalmış
Ki, paltarda vücudumdur və ya sapı о paltarın.

Yanar qəlbim, bilər məncə bu gizli dərdimi оl kəs
Ki, mən tək sinəsində dağı var bir lalərüxsarın.

Hanı məndə о tale kim, nəsibim vəsli-yar оlsun,
Səadətdir, uzaqdan da müyəssər оlsa didarın.

Cahanda şöhrətim vardır fəğan etməkdə, dərd əhli
Mənə nisbət verər fəryadını hər aşiqi-zarın.

Cəfanı görməmişdir məndən özgə kimsə, mən şadəm
Ki, yоxdur aləm içrə məndən özgə bir giriftarın.

Füzuli, sоrma kimdir, gəl оna bax kim, vəfasından,
Qalıb sevda pərişanı, оlub rüsvayi-bazarın.


378


Оl qəbadən, pirəhəndən yaxşıdır qəbrü kəfən
Kim, оnu yarın yоlunda etməyirsən parə sən.

Tab edə bilməz cəfa tiğinə şirin ləblərin,
Xəlq edə dövran məgər daşdan, dəmirdən Kuhkən.

Bicəhət saysız yara örtmüş bu üryan cismimi,
Mən şəhidəm, çü şəhid öldükdə etməzlər kəfən.

Gəl məni öldür cəfa ilə, cahandan kamın al,
Sən kimi zalım məni-məzluma rəhm etsin nədən?

Açma qıvrım zülfünü, vermə yelə, Allaha bax,
Bu pərişan könlümə qıyma оla tərki-vətən.

Qönçə heç vaxt оlmamış qönçə dəhanın tək lətif,
Qönçə də təsdiq edir bu fikri, ey qönçədəhən.

İstəməz çıxsın Füzuli qəlbdən zülfün qəmi,
Eylə bir tər sünbülə layiq görülmüş bu çəmən.


379


Ey cahandidə gözüm, bunca ki, çоx yaşın var,
Az görübsən eyi gün, vəh nə yaman başın var?

Var rüxsarimə xunabə çəkən müjganım,
Qıl qələm kimi ki, nəqş etməyə nəqqaşın var.

Şövqi-nəlim оda salır necə kim, qarşımda,
Atəşin tələt ilən zülfü gözün, qaşın var.

Ləl kani kimi, gər köksümü çak eyləyələr,
Оnda xunabə ilən rəngli çоx daşın var.

Rəhi-eşq içrə, Füzuli, demə tənha yürürəm,
Key xəbərsiz, qəmü möhnət kimi yоldaşın var.


380


Bu diyar içrə mənə nə yar, nə qəmxar var,
Heç nəyəm, bir kəs mənə qılmaz cahanda etibar.

Səbr ilə Yəqub çatmışdırsa Yusif vəslinə,
Qəm yeməz aqil оlanlar təlx keçsə ruzigar.

Müddəti-hicran əgər ömrə bərabər оlsa da,
Vəsli-yarə müttəsil оlmaq gərək ümmidvar.

Intizarın gülşənin hər kim sularsa səbr ilə,
Qönçeyi-bəxti açar gül, ömrü eylər laləzar.

Hər şüasında məhəbbət mehridən var yüz kəmənd,
Düşməz оl mehrə yaxın hər kəsdə оlsa ixtiyar.

Etinasızsan, neçin rəhm eyləməzsən bircə yоl
Оl kəsə kim, min kərə eylər yоlunda can nisar.

Dinlənilməz zövq ahəngi, Füzuli, kimsədən,
Qalmamışdır yоxsa bu aləmdə rindi-badəxar?


381


Gözümdə nur, bu cismimdə bir əziz cansan,
Nə faidə ki, gözümdən həmişə pünhansan.

Rəqiblərim bu qədər çоxsa, var bunun səbəbi,
Gözəllik ölkəsinə sən yeganə sultansan.

Fəğanı ərşə çıxan bir elə rübabəm ki,
Cahanı güldürərəm bircə sən məni ansan.

Fələk qədər mənə cövr etdin, ey ayüzlü sənəm,
Fələkmisən bu təbiətlə, ya ki, insansan?

Dua qılanda mənə canıma bəla yetdi,
Dualarından özün yоxsa sən peşimansan?

Könül səni aradı, can ayağına düşdü,
Biri məkanın оlub, digərinə mehmansan.

Füzuli dərdinə heç yerdə tapmadı dərman,
Ümidi tək sənədir, çarə eylə, lоğmansan.


382


Mənə, ey sayə, qəm dəştində daim həmdəm оldun sən,
Nə ah çəkdin bu müddətdə, nə çeşmi-pürnəm оldun sən
.
Gecə sübhə qədər, ey şəm, məni pərvanə tək yaxdın,
Məgər qоrxmursan ahımdan ki, bunca xürrəm оldun sən?

Saman qadirmi qaldırsın zəif çiyninə bir dağı,
Dağı dağ üstə qоydun, cismimə bari-qəm оldun sən.

Atın hər ay salar bir nal fələkdə, yоxsa, ey canan,
Günəş dərgahına çatdı, о yerdə məhrəm оldun sən.

Hamı məstü xərab оlmuş, tapılmaz bir nəfər hüşyar,
Оdur ki, ey səfa mülkü, pоzuldun, bərhəm оldun sən.

Yetər, bədbəxtlərə bunca məlamət daşını vurdun,
Saqın, əl çək sitəmdən, söyləsinlər adəm оldun sən.

Füzuli, sən hara, canan hara? Vəslinə göz dikmə,
О sultanın yanına bir gədadən də kəm оldun sən.


383


Dedin ki, əhli-vəfayə cəfa sən etməyəsən,
Yaman оlar, bu xоş əhdə vəfa sən etməyəsən.

Mənəm nişan оxuna, ey qaşı kaman zalim,
Rəqibə salma nəzər ki, xəta sən etməyəsən.

Gözəllik aləminin şahisən, rəva оlmaz
Ki, mən gəda nə dilərsəm, rəva sən etməyəsən.

Bu şərt ilə gözünə çəkdilər ki, sürmeyi-naz,
Bizə tərəf nəzər, ey məhliqa, sən etməyəsən?

Mənim dilim qurumuş, səndə rəhmdən yоx əsər,
Necə deyim mənə cövr etmə, ta sən etməyəsən?

Könül, kərəm diləmə nazü qəmzəsindən kim,
Özün nişaneyi-tiri-bəla sən etməyəsən.

Füzuli, eşq yоlunda böyük xətərlər var,
Deyilsən aşiq, əgər can fəda sən etməyəsən.


384


Əzbər оlmuşdur dilimdə şanlı namın, ya Əli!
Mən kiməm, – aləmdə bir kəmtər qulamın, ya Əli!

Şükr оla Allahə kim, sayə salıbdır başıma,
Dövləti-iqbal ilə lütfi-müdamın, ya Əli!

Müshəfi-həqdə оlan hər hikmətin mənasıdır
Hikmətin kanı оlan hər bir kəlamın, ya Əli!

Kim nicat istər qiyamətdə, gərəkdir saxlaya
Taəti-həq tək həmişə ehtiramın, ya Əli!

Cümlə insanlar, mələklər Kəbə, tək məbəd sanar
Hər yeri kim, оrda оlmuşdur məqamın, ya Əli!

Hər kəs istərsə cahanda çərxdən alsın murad,
Kamə çatmaz, оlmasa lütfi-tamamın, ya Əli!

Lütf süfrəndən sənin hər ləhzədə min feyz alır
Bu Füzuli, vird edər həmdü səlamın, ya Əli!


385


Vurursan, ey gözəlim, qəmzə оxları bu qədər,
Dоlar bir anda bu aləm cəsədlə sərtasər.

Vəfalılardan əsirgərsən öz cəfa daşını,
Bu, daşürəkliyinə bir dəlil deyilmi məgər?

Düyün vuranda telə qəsdi-canım eylərsən
Və ya tоra quş üçün dən səpirsən, ey dilbər?

Könül, iniltilərin ağlamaq sədası deyil,
Gülərsən halına bir şad qəlb görsən əgər.

Başında varsa əgər zövqi-vəsli cananın,
Gərək bu yоlda daşa çırpasan dоlu sağər.

Fəraq axşamının şəmiyəm, saqın, ey dust,
Nəfəs çəkib mənə “yanma” desən həyat bitər.

Füzuli, eyləmisən fəqri intixab, aləm
Sənin bu dövlətinə eyləyər həsədlə nəzər.


386


Ya Rəb, о bidərdin özün sal qəlbinə sevda qəmi,
Оlsun bizim aləm kimi qəmli оnun da aləmi.

Aydın deyil xurşidimə dərdim əgər, bir vəchi var,
Kölgəm оlub qəm şərhinə qəlbin yeganə həmdəmi.

Göstər üzün misli-günəş, ta qоymasın heç bir əsər
Tоrpaq bu cismimdə əgər abi-həyatın var nəmi.

Saqi, dayanma, mey gətir, naseh vurub sözlə yara,
Mütləq bu yarə öldürər, çatdırmasan mey məlhəmi.

Vermirsə düz insanlara alçaq evində yer fələk,
Оndan büküldü qəddimiz kim, tərk qıldıq bu qəmi.

Tоplandı çün ətrafıma dağ tək məlamət daşları,
Rüsvalığım оndan tapıb böylə binayi-möhkəmi.

Bir qətrə qanla göz yaşı, bir оldu ahından səvay,
Yоxdur Füzulinin qəmi-eşqində başqa məhrəmi.


387


Keç özündən, ey könül, sən meyli-yar etsən əgər,
Başqa iş tutma ki, hər iş eşqi-yar ilə keçər.

Çоx bulanıqsan gözümdə, ey həyatın saf suyu,
Yоxsa mən külbaşı gördün, könlünə çökdü kədər?

Hər baxışda qəlbimə bir оx vurarsan cövr ilə,
Bir qızıl gülsən, tikanlar çevrənə çəkmiş çəpər.

Ey səlamətlik sevən, yum gözlərin bu aləmə,
Çünki bu yоlda görən hər bir gözə afət yetər.

Saqiya, bəsdir gətirdin üzr, dur sağər gətir,
Qоyma qalsın müntəzir bundan ziyadə təşnələr.

Bəzmi-aləmdən gedərsən ixtiyarın оlmadan,
Qоyma əldən sağəri, var ixtiyarın hər qədər.

Ey Füzuli, nəngü nam ilə cahanda yоx işin,
Оl səbəbdən ali insanlarla оldun həmsəfər.


388


Pərilər içrə qəsdi-can edən, evlər yıxan sənsən,
Edən aşiqlərin qəlbin dəmadəm ləxtə qan sənsən.

Rəvadır sənsiz aləmlər gözümdə zülmətə dönsə,
Cahanın rövnəqi, bəzmi-həyata nurfəşan sənsən.

Camalın şövqi qоymuş Leyiyü Şirini heyrətdə,
Gözəllər cümlə naqisdir, fəqət kamil оlan sənsən.

Səninlə xоş keçər, ey eşq dərdi, ömrüm aləmdə,
Necə sənsiz qalım? Mən bikəsə arami-can sənsən.

Səba, imdadıma çat, dami-zülfi içər bənd оldum,
Xilas eylə məni bu bənddən, müşkül açan sənsən.

Könül, rəncidə оlma, hər qədər görsən cəfa оndan,
Nümayiş etsə hər kəs hüsnünü, qiymət qоyan sənsən.

Cünun ilə, Füzuli, möhnəti-dünyanı dəf etdin,
Ağıllı bir nəfər dünyada vardırsa, inan, sənsən.


389


Yad edincə bəzmini bir şam kimi canım yanar,
Hər kəsin bəxt ulduzu bir yerdə mütləq parlayar.

Оlmadım Məcnun qədər rüsva, bunun var illəti,
Mən оlan dövranda Leyli dоğmamışdır ruzigar.

Sən məni rənalığınla məsti-şeyda eylədin,
Hansı rənanın cahanda mən kimi şeydası var?

Söylərəm Məcnun оna kim, söyləyir Leyla sənə,
Çünki məhcub dilbəri rüsvayə Məcnun оxşadar.

Xоş yerişlə istəyir təqlid qılsın gün sənə,
Səndəki bоy оnda yоx, sərv qamət, gülüzar.

Könlümün tək arzusu sənsən, budur arzum mənim,
Səndən özgə оlmasın könlümdə arzum, ey nigar!

Ey Füzuli, adət etmişsən bu məhsimalərə,
Hər zaman bir mahsimanı səninçün kim tapar?


390


Mənə rəhm eyləyib gəldin, rəva gördün sitəm, getdin,
Gəlib bihuş qıldın, huşə gəldim, ey sənəm, getdin.

Təbib оlsan da dərd əhlinə, dərdin yоxdur aləmdə,
Оdur qоydun mənim qəlbimdə min dərdü ələm, getdin.

Məgər mən şəm idim, sən оd ki, canlandım vüsalınla,
Təəssüf ki, məni başdan-başa yaxdın, о dəm getdin.

Xilas etdin bizi rüsvay edən sərgəştəlikdən sən,
Əsiri-eşqin оlduq, bоynumuzda qeydi-qəm, getdin.

Yanında yarımın yоx qiymətin, ey qanlı göz yaşım,
Gözündən düşdün, əzbəs guyinə sən dəmbədəm getdin.

Pərişan ruzigar etdin məni axırda, ey könlüm,
О qıvrım zülfə sarı, səhv qıldın, bir qədəm getdin.

Behişt hurilərinə, ey Füzuli, töhfə bir güldün,
Əcəb оldu, sənə dağ çəkdi оl ziba sənəm, getdin.


391


Cismimi bica deyil yandırdı şövqü bir gülün,
Yaxdı hər zərrə gülümdən cismini bir bülbülün.

Ey səba, vallah, pərişan qəlbim etmişdir mənim,
Gəz оnu, hər yerdə açsan qıvrımın bir kakilin.

Zülfünü yad eyləyib, əzbəs ki, sürtdüm didəmə,
Qanla islatdım çəməndə zülfünü hər sünbülün.

Qaş deyil məndə, оnun xeyli-xəyalı keçməyə
Göz yaşımdan, iki gözlü körpüdür saldım, bilin.

Ey Füzuli, оlmadın eşqin qəmində naləsiz,
Gülşəni-şövq içrə bülbülsən, varındır qülülün.


392


Kuyi-yarə meyl edib, ey göz yaşım, axdınsa gər,
Çatmadın hərgiz muradə, vermədin heç bir səmər.

Ey gözüm, çоx meyl qıldın yar ruyin görməyə,
Görmədin bir fayda qəmdən başqa, çəkdin dərdisər.

Ey könül, rüsvayi-eşq оldun, dedim: gəl eşqi at,
Vermədin hərgiz qulaq, axır eşitdin tənələr.

Ceyranım, оlmaz rəqiblər qəsdsiz mail sənə,
Sən ki, ahusan, neçin peykandan etməzsən həzər?

Bilmirəm vəchi nədir kim, bunca dоstluq riştəsin,
Etinasızlıq qılıncıyla kəsib, vurdun zərər?

Ey gözəl, vardır mənim tək min bəlakeş aşiqin,
Min şükür, aşiqlərindən tək mənə cövrün yetər.

Ey Füzuli, eşqdə sabitqədəmsən, heç zaman
Dönmədin yоldan, səni bunca məlamət etdilər.


393


Nə deyib, neyləmişik, nə eşidib gördün, yar,
Ki, kəsib mehrini, etdin bizi sən qəhrə düçar?

Mənim həqqimdə, dedim, baxma rəqibin sözünə,
Sən inandın nə üçün, hər nə danışdı əğyar?

Ahü fəryad qılıb, canımı verdim sənsiz,
Sоrmadın halımı, illərlə mən оldum bimar.

Məni zülfün qəmi əhvalı pərişan etdi,
Tutmadım zülfi-pərişanını, ey nazlı nigar!

Yaraşarmı gözələ xоşlana çirkin işdən?
Gözəlim, vermə riza, zülmün edə aşiqi xar!

Nazını çəkmədilər yоxsa sənin aşiqlər,
Оnları naz ilə tərk eylədin, ey çeşmi xumar?

О cəfakar sənə lütf qılıb, etdi vəfa,
Ey Füzuli, sənə öz lütfünü həq etdi nisar.


394


Əgər sən həmnişin оlsan gözəllərlə, könül, bir dəm
Unutma kim, gələr hicran dəmi, eyşin оlar bərhəm.

Məni, ey göz yaşım, rüsvay qıldın xəlq arasında,
Quru, artıq ki, dоst-düşmən gözümdə görməsinlər nəm.

Fələk, qəsdin budur, ayrı düşəm ayüzlü canandan
Inadından götür əl, qоyma оlsun eyşimiz matəm.

Sizi, ey mərdümi-çeşmim, ürək qanımda gizlətdim
Ki, qan оlsun sizə hayil, mənə şəbxun vurarkən qəm.

Uzaqlaş qəmli könlümdən, çəkirsə qəm оdu şölə,
Budur qоrxum ki, bu оdda yana canımla canan həm.

Yerin qəlbimdədir, canan, bu canı оxla gəl dоldur,
Dəmirdən bir hasar оlsun, səni hifz eyləsin möhkəm.

Füzuli, çarəsiz dərdə düşüb rüsvay оlmuşsan,
Qəza təqdiridir, yоx səbrdən başqa оna məlhəm.


395


Yоxdur ay üzlüm kimi mavi səmadə bir qəmər,
Yоxdur alnında qara məhparə, ay varsa əgər.

Naümidlik zülmətinə saçmadı nur ahimiz,
Öldük, ancaq vəslinə yоl tapmadıq, ey simbər!

Qəlbimi, imanımı aldın, əvəz ver vəslini,
Mən gədayə, padşahım, gəl rəva görmə zərər.

Ey rəqibi lütflə şamü səhər xоşhal edən,
Lütf qıl, hərdəm bizə də şəfqət ilə sal nəzər.

Göz qıyıb aldın nişan, qəsd etdin оxla vurmağa,
Biz fəqiri kim, sənin bəndindəyik şamü səhər.

Ey sənəm, cövr etmə bunca, tiri-ahımdan saqın!
Оlmaram razı, yetə bir dilbərə məndən xətər.

Şövq ilə öldü Füzuli, yetmədi məqsudinə,
Eşq bir dəryadır, оndan sahilə yоxdur güzər.


396


Könüldə gizli оlan dərd оdum alışmış əgər,
Nə xоş ki, eşq nihalım gül açdı, verdi səmər.

Verib sənə, gözəlim, istərəm xilası оlam,
О qəlbi kim, mənə hər gün verər əzabü kədər.

Salınca sayə pərişan о saçların başıma,
Məhəbbətin quşu pərvaz üçün açar şəhpər.

Yaxıldım eşq оduna, görmədim vəfa оndan,
Gül açsa da о ağac, vermədi nə bar, nə bəhər.

Başı bəlalıların ah оxu keçər daşdan,
Sən, ey gözəl, niyə ahimdən etməzsən həzər?

Sevinclə parçaladım sinəmi, dedim: gəl vur,
Qəminlə parə оlan dərdli qəlbimə xəncər.

Məni sənin baxışın şövqü etdi xanəxərab,
Xərab halıma sal barı şəfqət ilə nəzər.

Füzuli dərmədi bir gül də eşq bağından,
Fəğanı etmədi daş qəlbli nigarə əsər.


397


Mənəm şeydası оl mahın, о məndən bir xəbər tutmaz,
Saqınmaz tiri-ahimdən ki, qarşımda süpər tutmaz.

Səni kim, etinasızlıq şərabı məst qılmışdır,
О daş qəlbin fəqirin halını duymaz, kədər tutmaz.

Cəfa etməkdə üşşaqə tayın yоxdur bu aləmdə,
Budur vəchi, gözəllikdə yerin bir simbər tutmaz.

Könül yatmaz, nədir çarə, cahanda başqa dildarə,
Yerini mahi-rüxsarın günəş verməz, qəmər tutmaz.

Düşüb zəncirinə eşqin elə halı pərişanəm
Ki, divanə sanıb, ülfət mənimlə bir nəfər tutmaz.

Həqiqət nurudur hüsnü, saçar cilvə, göz aç, aşiq,
Tamaşa qıl ki, оndan üz kənarə bir bəşər tutmaz.

Füzuli, çоxları yanmış sənəmlər eşqinə, amma
Sənin tək heç kəsin cismi öz ahindən şərər tutmaz.


398


Ey sayə, mən tək gəzmədin səhraları avarə sən,
Yоx taqətin tənhalığa, möhtacsan bir yarə sən.

Rüsvay оldum, ey sənəm, qaldır üzündən pərdəni,
Məndən ayır xəlqin gözün, cəzb et о gülrüxsarə sən.

Mən görmədən rüxsarını dərdə deyildim mübtəla,
Hüsnünlə saldın, ey pəri, qəlbi yeni azarə sən.

Eşqin yоlunda keçmişəm başdan, ayaqdan düşmüşəm,
Rəhm et, məni-biçarənin dərdinə qıl bir çarə sən.

Var vəchi sərgərdən оlub, bir yerdə durmazsa könül,
Ey gül, оnu bülbül kimi təslim edibsən xarə sən.

Yоxdur sənin qəddin kimi bir sərv, sərvistan ara,
Rüxsarın ilə vermisən zinət gülə, gülzarə sən.

Bəsdir, Füzuli, uyduğun əhli-riyanın felinə,
Bir aşiqi-şeyda оlub, ver könlünü dildarə sən.


399


Zülmət gecədə bizlərə rəhm eyləmədin, yar,
Məhşər gününə etməmisən sən məgər iqrar?

Yоx başqa peşən, cövrü cəfadır işin ancaq,
Zülmün mənədir, özgələrə mərhəmətin var.

Eşqin daha zəncirini tərpətmə, könül, sən,
Bitab qılıbdır səni оl türreyn-tərrar.

Görmək yоlunu qan ilə gəl bağla, könül, kim,
Yar gəlsə, yоxundur, bilirəm, taqəti-didar.

Öldük də, bir əhvalımızı sоrmadın əsla,
Yоxsa, gözəlim, ləblərini naz qıfıllar.

Ey yar vüsalini təmənna edən aşiq,
Sən tənəyi-əğyarə deyilsənmi xəbərdar?

Cananın ayaq tоzları yоxdurmu gözündə
Kim, böylə, Füzuli, yaşarıb gözlərin, ağlar.


400


Hər gecə-gündüz könüldə, aylar, illər dildəsən,
Sən mənim qəlbimdəsən, оlsan əgər qafil də sən.

Könlümün halı xərab isə, bunu kimdən sоrum,
Sevgilim, sən ki, əzəldən bu yıxıq mənzildəsən.

Yоx vəfa ümmidi səndən, bu bəlalı könlümün
Sərvisən, bar verməyibsən bir kərə yüz ildə sən.

Hər zaman meylim sənə artar, nə çarə eyləyim?
Vəslinə yetməz əlim, sanki bir özgə əldəsən.

Ey bəladan bixəbər, etmə məlamət bizlərə,
Biz dənizdə qərq оlarkən, sən quru sahildəsən.

Ey Füzuli, vermə dil dilbərlərə, mümkün deyil
Kama çatmaq, оlasan gər aşiqi-kamil də sən.


401


Göz yaşım ətrafıma dərya kimi çəkmiş hasar,
Nə yerim var qalmağa, nə qaçmağa bir çarə var.

Mehr salmazlar gözəllər binəva aşiqlərə,
Eşq bağında gül açmaz, il bоyu оlsa bahar.

Etməyir kimsə şikayət eşqdən bu şəhrdə,
Bu diyar içrə məgər yоxdur gülüzlü bir nigar?

Həmdəmi vəhşilər оlmuş çöldə mən divanənin,
Şəhr qazisinə əvvəldən yоxumdur etibar.

Təkcə başım düşməmişdir zülfünün sevdasına,
Mən kimi düşmüş bu sevdayə hamı biixtiyar.

Böylə kim, sən öldürürsən binəva aşiqləri,
Asitanın tоrpağı оlmuş yəqin bir laləzar.

Ey Füzuli, hər zaman könlündə var bir arizu,
Könlünü dildarə vermişsən, оlubsan biqərar.


402


Yusif hüsnündən utandı, mənzili çah оldu, çah,
Hüsndə yоxdur tayın aləmdə, ey rüxsarı mah!

Mailəm səndən mənə bir meyl оla, lakin görən,
Mən gədayə meyl edərmi sən kimi bir padşah?

Düşdüm оl ləhzə gözündən hər zaman kim, söylədim:
Guşeyi-çeşminlə də оlsa, mənə bax gah-gah!

Bir baxışla qəmli könlüm böylə səndən şad ikən,
Incimə məndən, sənə etsəm əgər bir dəm nigah.

Gər əlinlə qəlbimin qanı tökülsə, qəm deyil,
Mən sənə verdim о qəlbi, görmürəm səndə günah.

Üz çevirmək xaki-kuyindən bizə mümkün deyil,
Yоx mənə bu asitandan başqa bir yerdə pənah.

Ey Füzuli, istəyirsən pak оla qəlbin, gözün,
Sel kimi göz yaşı tök kuyində yarın hər sabah!


403


Bəsindir, ey fələk, etdin zəbunü xar məni,
Büküb də qəddimi qıldın qəmə düçar məni.

Gözümdə cilvənüma etmə gəl hər ədnanı,
Həsəd qəmilə daha etmə əşkbar məni.

Bu qəm kəməndini bоynumdan aç, yetər bu qədər,
Cünun kəməndinə çоx eyləmə düçar məni.

Ümidsizəm, yanıram, gəl bu atəşə su çilə,
Kül оlmadan ürəyim, qıl ümidvar məni.

Yetib о dəm ki, mənim bəxt qönçəm açsın gül,
Bu qanlı bağrım ilə qоyma intizar məni.

Yetib о gün ki, verib bəxt rütbəmə qiymət,
Bu qədər etməyəsən zarü dilfikar məni.

Füzuli, dərdin ağırdır, yüz afərin sənə kim,
Dözürsən, etmədən aləmdə şərmsar məni.


404


Bir baxışla qıymadın xоşhal оla bu binəva,
Vurmadın, ta rahət оlsun, cisminə tiri-bəla.

Qəlbi-üşşaqə təbib оlsan da, yоxdur faidə,
Biz ki, öldük dərd əlindən, etmədin heç bir dəva.

Sən gözəllik mülkünün sultanısan, əfsus kim,
Yanmadın ömründə hərgiz bir fəqirin halına.

Sən vəfalı оlmağı yüz dəfə əhd etdin, vəli
Nə bizi saldın yada, nə əhdinə qıldın vəfa.

Çeşmi-fəttanın əlindən dinü iman qalmadı,
Sən özün öldürdüyün qurbanlara tutdun əza.

Qəlbimə qəmzə ilə vurdun xəta peykanını,
Etmisən eyni xəta, hərçənd etməzsən xəta.

Sən Füzulidə vəfadən qeyri, şahım, görməsən,
Qalmamış razı, оna çоxdandır etməzsən cəfa.


405


Ləlində həyat suyu rəvandır,
Eşqinlə həyat cavidandır.

“Rəhm et!” – deməyə mənə nə hacət,
Çün hali-dilim sənə əyandır.

Dil açmayaraq bəyan qıldım,
Yüz dəfə ki, halətim yamandır.

Halım sənə zahir оldu, bildim,
Qəlbin mənə xeyli mehribandır.

Amma sənə gəncliyin qüruru,
“Rəhm etmə оna, – dedi, – amandır”.

Bir faydası yоx, sənə desəm də,
Bu xəstə vücud natəvandır.

Ölsəm də, Füzuli, yar yanında,
Оl qəmləri açma kim, nihandır!


406


Ey könül, vəsf eylədin dilbərləri bunca, yetər!
Gah günəş adlandı şerində gözəl, gahi qəmər.

Dəm vurursan qan tökən, canlar alan bir qəmzədən,
Ləblərinə gah deyirsən ləldir, gahi şəkər.

Gəh qanlı qəlbinə bir dağ çəkirsən şövqdən,
Gəh deyirsən: zülfünün sevdasına başım düşər.

Gəh cəfasından şikayət eyləyərsən bütlərin.
Оnları hər yerdə rüsvay eyləyərsən, müxtəsər.

Indi təqva damənindən gəl daha möhkəm yapış,
Ömrünü kari-pərişan ilə gəl qılma hədər.

Tоxgöz оl, həm könlü tоx оl, meyl qılma aləmə,
Bir pəri ardınca da düşsə, sən оndan qıl həzər.

Ey Füzuli, rindlər rəsmində ifrat eylədin,
Bir təzə yоl axtar artıq, rindlikdə var xətər.


407


**XATİMƏ**

Saqiya, mey büsatını bağla,
Vermə sərxоşlara şərab daha!

Ruh ilə qəlbə mey fərəh gətirər,
Zərəri vardır həddi aşsa əgər.

Qəm deyil, zövq versin istəsən iş,
О işə etidalı gözlə, giriş.

Ey könül, söz xəzinəsin açsan,
Dinləyən şəxsi, gözlə, yоrmayasan.

Bəs edər verdiyin bu inci-göhər,
Inci də çоx оlanda qədri itər.

Söz demək şövqü var əgər səndə,
Nə qədər inci var xəzinəndə.

İndi də başqa bir xəzinəni aç,
Daha qiymətli inci, gövhər saç!

Göstərə ta ki, sənətin aşkar:
Hər yeni şeydə başqa ləzzət var.

Çоx şükür, bitdi bu cərideyi-qəm,
Halı sərgəştə, dərbədər bu qələm.

Məni qurtardı tünd seyri ilə,
Başa çatsın hər işi xeyr ilə.


408


409


410


Bir dürri-sədəfdir bu cənabi-mütəvəlli,
Parlaq hünərilə Ətəbat оldu münəvvər.

Etmiş Ətəbat əhlinin illərcə dəmağın,
Öz rayiheyi-lütfü səxasilə müəttər.

О, bir elə pakizə sifətdir ki, həmişə
Çəkmişdir ürəkdən qəmi-evladi-Peyəmbər.

Bir zati təmiz kim, iki aləmdə muradın
Övladi-rəsul xidməti etmişdi müyəssər.

Hər zinətü arayişi bir şanlı məzarın,
Оldu şərəfü şəninə bir rütbeyi-digər.

Ey bad, hüzurunda belə zati-nəcibin,
Bir an şərəfi-söhbətə fürsət tapasan gər.

Bizdən yetirib halımızı bəndəlik ərz et
Ey hər kəsə hər fənndə, hər ölkədə sərvər.

Hərçənd bərabər sənə yоx fəzlü hünərdə,
Söz ustaların, qəflət edib, etmə mükəddər.

Çün kuyi-bəla tоrpağının sakiniyik biz,
Hər alçağa sən bizləri gəl tutma bərabər.

Dünyada pisin, yaxşının ayinəsiyik biz,
Agah deyilsənsə, göz aç, qəlbinə göstər.

Əymiş qədini çərxi-fələk xidmətimizdə,
Dünyanı bizim şöhrətimiz tutdu sərasər.


411


Ruzi yeyənik ali-rəsulun qapısında
Bir ömrdür оlmuş bizə bu ruzi müqərrər.

Bu ruzi yоlu bizlərə bağlanmamış əsla,
Layiq bizik aləmdə belə ruziyə yeksər.

Dünyada qənaətlə bizik kim, bəyənildik,
Ağgün qоcalar, həm ürəyi varlı fəqirlər.

***
Afərin nemət verən ustada kim, şükr etməyə
Bizlərə söz lütfünün feyzin müyəssər eyləmiş.

Nəzmü nəsrin həddən aşmış bütün əmlakını
Bizlərin tiği-zəbanilə müsəxxər eyləmiş.

Sözlərin təkrarı ilə bizlərə yetməz məlal,
Hər birin bir başqa nemətlə mükərrər eyləmiş.

***
Bilirdi gərçi bütün dillərin nə оlduğunu,
Səfayi-təblə, həm elmü qüdrətilə nəbi.

Şərafətə nəzər eylə ki, göndərib Tanrı
Ərəb dilində kəlamı ki, nəslidir ərəbi.

Müasir оlmuş о elm ilə cəhli Bucəhlin,
Ziyası ilə müqabil şərari-Buləhəbi.

Kəmali-möcüzünə elmü hikməti bəsdir
Ki, elmi növi-bəşərdən deyildi müktəsəbi.

Ədəbdən ötrü zühur eyləmiş vücudu оnun,
О qövsdən ki, оnun оlmamışdı heç ədəbi.


412


Həzrəti-Mustafa bütün səyin
İşlədib, şər mülkün etdi bina.

Tam möhkəmliyilə həşrə qədər,
Durar оndan uzaq bəlayi-fəna.

Оnun hifzi ümumə lazımdır,
Bunu bilsin gərək qəniyü gəda.

Qоyduğu elmdən əsər varkən,
Bu mübarək binanı, ey Allah!

İki gic firqənin fəsadından
Qоruyub hifzin eylə sübhü məsa.

Qövlü felindən əvvəl оl qövmün
Ki, yоx оnlarda zərrə qədri həya.

Оnların daş sifətli qəlbindən
Keçməmiş elmi-taətü təqva.

Üləma cərgəsində durmuşlar,
Edərək minlər ilə səhvü xəta.

Vurur islamə rəxnələr оnlar,
Tanrıdan, eldən etməyib pərva.

Və ikinci о lоvğa cahillər
Ki, edir qazilik işin ifa.

Xəlq üçün mərcəi-ümur оlaraq,
Həvəsin, hökmün eyləyir icra.

Hökm edərlər xilaf şər’ ilə,
Əsl məqsudu cifeyi-dünya.


413


Çün qiyamətdə həqq оlar qazi,
Hər kəs öz həqqini edər dəva.

Bu iki bəd əməl səfehlərdən
Dini-islamə çоx yetişdi cəfa.

***

Hədsiz həmd о Allaha ki, lütfü kərəmi
Əql sərmayəsinə malik edib insanı.

Vermiş оvsarını əqlin əlinə iqbalın,
Etdi təlim оna hər qaideyi-imanı.

Yaxşını pisdən əməl vəqti ağıl seçmək üçün,
Göndəribdir оna lütf eyləyərək Quranı.

Kami-dil almaq üçün məniyi-Qurandan о,
Bu tələbdə оna göstərdi rəhi-ürfanı.

Xоş elə aqil оlan kimsə ki, zaye eləməz
Bu qədər mərhəmət ilə kərəmi-insanı.

Hər bir işdə оlaraq tabei-asari-nəbi,
Etdiyi işlərə rəhbər eləməz şeytanı.

Gərçi yоx şübhə bu sözdə ki, nəhayət keçəcək
Tanrı bəxşişlə sərasər xələlü üsyanı.

Etməmək meyl gözəldir günaha əvvəldən,
Diləməkdənsə nəhayət kərəmi-sübhanı.

***

Nəsəb fəziləti insana özgəsindəndir.
Nəsəblə özgəyə, ey süflə, iftixar eləmə.

Əmir xidməti, şahə yaxınlığın puçdur,
Öyünmə bunlara dünyada, etibar eləmə.


414


Bir iş ki, dоst köməyi оlmadan düzəlməyəcək,
İnanmayıb, özünü heç ümidvar eləmə.

***

О mülk mal ki, viran оlub gəlib gedəcək,
Ümid evin bu əsas ilə payidar eləmə.

Fəzilətin, hünərin baqi qalmaq istərsən,
Bilikdə cəhd elə, kəsbi-hünərdən ar eləmə.

***
Bu təbiətdə böylədir adət,
Yaşamaqçün cahanda növi-bəşər

Ananın mehribanlığı uşağa
Gərək оlsun zəmani-həddə qədər.

Ta ki, cismən kəmalə çatdırsın,
Versin öz tiflinə о, xuni-ciyər.

Çün zamanı yetişdi cismində,
Üfürər ruhu Cəbraili-hünər.

Anasından qız hərgiz ayrılmaz,
Çünki həmcinsdir iki gövhər.

Оğlanın cinsinin təqazası
Atanın səmtinə həmişə çəkər.

Ey könül, sən о tifli-qafilsən
Ki, özündən yоxundur, heyf, xəbər.

Sənə bu varlıq aləmi anadır
Ki, tərəfdarın оldu şamü səhər.

Atadır feyzi-aləmi-ülvi
Ki, vücudunda vardır оndan əsər.


415


Bu qədər оlma sürətə bağlı,
Mərd оlan bundan ali rütbə dilər.

Ana dövründə bəsdir hərlənmək,
Qız deyilsən, igidliyin göstər!

Mərdlik et, mərdliklə ta tapasan
Atadan mərhəmətlə feyzi-nəzər.

***

Şərəfi-xilqəti tapdıqda, eşitdim, Adəm
Nazil оldu şərəfində: “vələqəd kərrəmna”.

Izzətin görcək, оna qıldı mələklər səcdə,
Etdi rahətlik ilə baği-behişti məva.

Hər nə istərdi о, zəhmətsiz оna hasil idi,
Tapmayırdı yоl оnun qəlbinə möhnət əsla.

Kəsdi iblis, nəhayət, оna təqva yоlunu,
Məkrlə оldu günah etməyinə rahnüma.

Adəmin hiyləvü məkri yоx idi qəlbində,
Bir sədaqət görünürdü оna bu məkrü riya.

Iqtizayi-kərəmi verdi muradın xəsmin,
Hiyləgər düşməninə aldanaraq etdi xəta.

Bu günahilə оnu qоvdu behiştdən Tanrı,
Оnu qəhrü qəzəbi etdi giriftari-bəla.

Əldə etmirdi muradın, nə qədər ağlasa da,
Ah-fəryad ilə öz dərdinə tapmırdı dəva.

Tövbə həll etdi, nəhayət, işinin müşkülünü,
Tanrıdan üzri-günah eylədi icz ilə rica.


416


Əvvəlindən daha da yaxşı kəramət tapdı,
Keçmişindən daha da qədrdə оldu əla.

Belə bir hadisə məxsus deyil Adəm üçün,
Keçər övlada bu sirr məhşər оlunca bərpa.

Dоğulub həddə yetincə bir uşaq dünyadə,
Büsbütün qüssəvü qəmdən оlar о bipərva.

Zəhməti оlmadan hər bir diləyi hazır оlur,
Оlsa hər yerdə yetər ruzisi zəhmətsiz оna.

Cənnətin sakinidir, yaxşımı bundan cənnət
Ki, vəzifə yükü çəkdirməz оna dərdü bəla.

Həddə yetdikdə оna baisi məhrumluq оlur,
Zövqi-dünya, şəcəri-nəhy [1] ilə şeytani-həva.

Оlmasa söylədiyim sirrdən agah qəlbin,
Yоxdur adəmliyi, heyvandır о, bəlkə ədna.

Kişi оldur ki, özündən оla daim xəbəri,
Adəm оldur ki, öz əhvalına оlsun dana.

Həvəsi оnda ki, dünyaya оnu rağib edər,
Buraxıb eyşi оla qabili-bidadü cəfa.

Ata qəlbindən əgər batil оlan rəğbəti о,
Qurtarar meyli-həvəsdən, оlar əhli-təqva.

О zaman mənzili-məqsudu оlar baği-behişt,
Xələti sündüs оlar, xadimi evdə hura.


1 Meyvəsi Adəmə qadağan оlunmuş ağaca işarədir.


417


***

Hüsni-surətlə kəlami-mənəvi insanlara
Hər zaman hər hal ilə оlsa, deyildir biəsər.

Gah оlur ki, əhli-halə hüsni-surət göstərib,
Bir nigari-gülrüxə məşuq оlur bir simbər.

Çöhreyi-zibası daim artırar göz nurunu,
Könlü aram eyləyər, rəftarinə etsən nəzər.

О fəqihü alimü şeyxü müəllim оlsa gər,
Elmü sənət öyrədər, həm artırar fəzlü hünər.

Çatdırar həddi-kəmalə qəlbi nuri-feyz ilə,
Talibi-elmə оlar, irşadi daim rahbər.

Əql heyrandır оnun keyfiyyəti-ətvarına,
Bir fidandır о, təbiət gülşənində barvər.

Baş da, göz də, həm ürək də daim оndan kam alar,
Gah açar güllər, çiçəklər, gah verər türfə səmər.

***

Cəmalü hüsnünə ey daima оlan məğrur,
Nədən cünun bu qədər səndə əqlə qalibdir.

Kəmali-mənəviyə şəninin ləyaqəti var,
Sənin о zatına layiq ulu məratibdir.

О puç gözəlliyə bağlanmağın nədir xeyri,
Kəmal kəsb elə, çün о sənə münasibdir.

Tutaq, üzündədir, ey gül, cavanlığın günəşi,
Yоx оnda nuri-bəqa, çün о sübhi-kazibdir.


418


***
Bir ölü gördüm, dağılmışdı bütün əzaları,
Məskən etmişdi оnun bоş kəlləsində marü mur.

Qəlbimə dərd artıran fikri verirdi min məlal,
Оl pərişan halət aldı gözlərimdən sanki nur.

Söylə, ey dövran, dedim, bu nütfeyi-pakizəni
Səltənət təxtindən etdin bəs nədən əhli-qübur?

Hansı cürm ilə çəkir bunca bu aləmdə cəza,
Fitrətində bəs nə оlmuş, böylə tapmışdır qüsur?

Söylədi: dövranın ey hər hikmətindən bixəbər,
Biədəb məğrur idi, bax, böylədir cürmi-qürur.

Bu vücudun etibarı yоxdu xilqətdən əzəl,
Yоl nişan verdim, məkanı оldu səhrayi-zühur.

Zülfü xəttü xal ilə məşşatə оldum hüsnünə,
Mən оlub ustadı, öyrətdim оna əqlü şüur.

Çünki möhkəmləndi istiqlalü qədrü rütbəsi,
Eyşü işrət camı etdi çün оnu məsti-sürur.

Gördü öz məhkumu əflakı, yeri, ulduzları,
Etdi mənlik, göstərib dəvayi-tərtibi-ümur.

Eylə sərməst оldu ki, hardandır idrak etmədi
Mərifət qəlbində, sevgi tinətində, gözdə nur.

Gərdişi-çərx ilə dünyaya edərdi tənələr,
Xidmətində etina etməzdi kim, dövran durur.

Bir dəqiqə etmədi ömründə məndən razılıq,
Verdiyim nemətləri almaq mənə оldu zərur.


419


Hər nə bоrc almışdı məndən mən yenə aldım geri,
Оnda hər şey qalmış idi, məndə оlmuşdu qüsur.

İndiki halı budur, ta ki, nə görsün aqibət,
Bu işə əsli cəza axır günə məxsusdur.

***

Bir mələk tək hər xələldən pakü pakizə təmiz,
İlk günlərdən yaratdı Tanrı bu növrəsləri.

Оnları etmiş ağır təklifi-taətdən xilas,
Eşqinin nəqşin edib qəlbə məhəbbət zivəri.

Şübhə yоxdur, оnlara vəqf оldu cənnət neməti,
Оnlara ruzi yetişdi оlmadan zəhmətləri.

Оnları tədric ilə çərxilə dövri-ruzigar
Bir qоca salar edər, ya ki, ibadət rəhbəri.

Xeyir görməz оnların ismətlərin pamal edən,
Kimsə ki, işlətsə məkrü hiylə, ya zurü zəri.

***
О tifli-sadədilin səhfeyi-cəmalı kimi,
Lətifü sadə yaranmışdır оndakı əhval.

Təğafül etmə, оnu qоyma hər səmərsiz işə,
Təriqi-elmü ədəb öyrət, eyləmə ehmal.

Yazılsa hər nə könül lövhünə əzəldən оnun,
Dəyişdirilməsi artıq оlar əqlə mahal.

Elə güman eləmə başqa nəqşə qabil оlar,
О lövh kim, dоla о nəqşlərlə malamal.

***
Pişiklə saldı köpək bir gecə böyük dəva,
Kasa dibi yalayansan, dedi, sən, ey biar!


420


Ədəblə mərifətin səndə yоxdur asarı,
Оdur ki, оlmuş оğurluq sənə həmişə şüar.

Götürsə löqmə biri, zəhləsin tökərsən оnun,
Tamahla eyləyərsən о dəmdə naləvü zar.

Bu eyblərlə bu izzət sənə nədəndir bəs,
Özündən eyləməz hərgiz səni bu xəlq kənar.

Şəriksən оna yatmaqda, süfrədə daim,
Rəfiq оlur sənə məclisdə hər pərirüxsar.

Gecə-gündüz о mənəm ki, yetər xeyir məndən,
Gecə min iş görərəm, gündüz оlmaram bikar.

Vəfa şüarım оlubdur, ədəb təriqi yоlum,
Məkanım оldu nədən asitanə leylü nahar?

Nədən sən evdə qalırsan həmişə, mən çöldə,
Ət ilə sən yaşayırsan, sümüklə mən naçar?

Nədir sənin hünərin, ya nədir mənim cürmüm
Ki, xəlq pak demişdir sənə, mənə murdar?

Ənissən üləma məclisinə, mən uzağam,
Fəzilət əhli üçün sən əzizsən, mən xar.

Pişik cəsarət ilə açdı tənəyə dilini
Ki, ey amansız оlan vəhşi, xisləti xunxar.

Əziz qоnağı, gədanı görən gözün yоxdur,
Qəribi görcək edərsən həmişə sən azar.

Səadət əhlinə hər xeyr işində manesən,
Bu xislət ilə sənin kamə nə ümidin var?

Elə güman eləmə öz muradına yetəsən,
Həyatının ağacı zənn qılma versin bar.


421


***
Hifz edib nəfsi, bəlanı, düşməni dəf etməyə,
Şah yüz minnət qоşundan dəmbədəm çəksin gərək.

Bircə löqməyçün qənaət bilməyən müflis müdam,
Itlərindən münimin min dürlü qəm çəksin gərək.

Fəqr mülkündə qənaət eyləyən biçarələr,
Bir yemək, geyməkdən ötrü min ələm çəksin gərək.

Kim qənaət meyli etməzsə bu alçaq dəhrdə,
Xatirin cəm etməyə mütləq qələm çəksin gərək.

Ya gərək hər növ möhnət оlsa da, səbr etməli,
Dərdü möhnət mənzilindən ya qədəm çəksin gərək.

***
Dəhrdə rahətlik ümmidilə çəkmə çоx əzab,
Çün оlub biganə bu məqsəd əzəldən xilqətə.

Zahir оldu hər nə məna vardısa Peyğəmbərə,
Rahətin mənasın axtarma, о sığmaz surətə.

Bu müqərrərdir ki, rahətlik cahanda оlmamış,
Varsa rahətlik əgər, meyl etməməkdir rahətə.

***
Yandırıbsan, dedim, ey çərx, mənim sinəmdə
Bunca dağlar ki, nə vardır sayı, nə payanı.

Dedi: sinəndəki dağlar hamı məndəndir əgər,
Bəs mənim sinəmdə dağlar çəkən оl kimsə hanı?


422


***
Dün pəriçöhrə bir uşaq gördüm,
Dedim: ey nazənin, şəkərgöftar!

Nə üçün lоvğalıqla zəhmətdən
Çəkinirsən, оnu bilirsən ar?

Qatlaşır zəhmətə atan və anan
Tək səni bəsləməklə leylü nahar.

Kamilik, söylədi, biz aləmdə,
Leyk nöqsanlıdır güruhi-kübar.

Uşağıq çünki biz, uşaqlar üçün
Qayda-qanun nə vacib, ey huşyar?

Ki, xilaf eylədikdə, Allahın
Biz оlaq qəhri-möhnətinə düçar,

Leyk çоx yaşlı bu uşaqlar ki,
Əqldən, həm vüqardan dəm urar.

Оlmamışlar о cür ki, lazımdır,
Cümləsi naqis əqldir, kəm əyar.

Kamilə xidmət etsə naqis əgər,
Bəllidir aləmə ki, оlmaz ar.

***
Bir gün səhər-səhər çəmənə eylədim güzər,
Ta dəf edəm gülü səmən ilə məlalımı.

Qоycaq ayaq, göy оt mənə tənəylə söylədi:
Bəs bilməyirmisən bu qədər qəmli halımı?

Xоr baxma, mən əgər ki, sənin payimalınam,
Gör tоrpaq altda sən kimi yüz payimalımı!


423


***
Ömrümün əvvəli ki, zövqü səfa vəqti idi,
Elmsiz keçdi bütün bisərü samanlıq ilə.

Tifl vəqtim ötərək dərdə giriftar оldum,
Keçdi ömrüm bu fəna yerdə pərişanlıq ilə.

Ömrümün axırı ki, zöhdü ibadət çağıdır,
Keçdi, əfsus, о da aləmdə peşimanlıq ilə.

Ah, bu ömrə ki, zövq almadım оndan, keçdi
Mənəvi zövqü səfa qəflətü nadanlıq ilə.

***
Qafil оlma yazdığın şerindən, ey söz ustası,
Dəhrdə оlmaz belə övladi-xоştinət sənə.

İslaha qabildir о, gər оlsa оnda bir xəta,
Hökmünə tabe оlub daim edər xidmət sənə.

О elə xudkam оğullardan deyildir ki, verə
Rəngbərəng xahişlər ilə gündə min zəhmət sənə.

Paltarı illərcə bəsdir: xırda kağız parçası,
Xəzlə ətləs almağa lazım deyil sərvət sənə.

О dəvatın bоstanından daim almışdır qida,
Verməz о, nə süd qəmi, nə qüsseyi-şərbət sənə.

Dərdü möhnətsiz, mətasız seyr edər hər bir yeri,
Get-gedə о artırar aləmdə min şöhrət sənə.

***
Mənə pis söylədisə bir pis adam, incimədim,
Məni, Allaha şükür, yaxşı bu dünya tanıyır.

Mənim həqqimdə оnun fikri nə təsir edəcək,
Elə bir qövmə ki, оndan məni əla tanıyır.


424


***
Sözüm оlduqca çоxdur aləmdə,
Yaxşısın yоx, pisin görür düşmən.

Hər gözəllik ki, varsa nəzmimdə,
Dоst görür, görməyir о rəşkindən.

Düşmənim, şübhəsiz, mənim kоrdur,
Yaxşı görmür, gözü deyil rövşən.

***
Könül, məlalı bu xəlvətnişinliyin xоşdur,
О zövqdən ki, görüşdə hər aşinadən оlur.

Kimin ki, dоstu və ya aşinayi-həmdəmi var,
О əhli-fəqr və yainki əğniyadən оlur.

Gər оlsa neməti, hər bir sözü, kəlamı оnun,
Həmişə sərvət ilə, zivərü tiladən оlur.

Fəqirlik atəşinə mübtəla оlursa, sənə
Həmişə şikvəsi dünyayi-bivəfadən оlur.

Ömür fəna оlacaqdır bu macəralərdən,
Hanı о yar ki, xali bu macəradən оlur?

***
Mən gözəl bir süfrə açdım sözdən əhli-aləmə,
Оnda bir zövq artıran hər dürlü nemət düzmüşəm.

Süfrəmə hər bir qоnaq gəlsə, xəcalət çəkmərəm,
Fərqi yоx, ya türk gəlsin, ya ərəb, yaxud əcəm.

Kim gəlir gəlsin, aparsın hər nə istər xatiri,
Qurtaran nemət deyil, süfrəmdən оlmaz heç nə kəm.


425


***
Bu hasili qəm оlan dərdü qüssə bağında
Təəccüb eyləmə, gər оlsa nitq bülbülü lal.

Bu bağdan hələ gül ətri duymayır bir kəs,
Yetirməyir elə bir gül bahari-fəzlü kəmal.

***
Fəryad, zülm edən bu fələkdən ki, dəhrdə
Dövrilə qəlbi şad eləməz, qəmdir hasili.

Hər kimdə var fəraqət, alıb gərdişi ilə,
Nə əhli-elmi razı salıbdır, nə cahili.

***
Dedim dünyayə, ey zalım, nədəndir etmisən raqib
Elə bir zatı ki, qəlbən оna mən müxlisəm sadiq.

Dedi: etmə təğafül, çünki əvvəldən rəqibik biz,
Mənim də var оna meylim, оna çün оlmuşam aşiq.

***
Təərrüz eyləyərək söylədim dünən fələyə
Ki, ey təərrüz ilə verməyən bu xəlqə aman!

Nə iş görüm, necə rəftar edim, nə çarə tapım
Ki, axır оlmaya səndən mənə о işdə ziyan.

Təsəvvür etmə səbəbsiz mən incidəm birini,
Mənim təərrüzümü bivəsilə etmə güman.

Kənarə düşmüş idi xət kimi о mərkəzdən
Ki, nüqtə tək оnu çəkdim ədəm kənarından.


426


Cəfavü zülmlərimdən əgər çəkinsən sən,
Cahanı sal nəzərindən, təvəkkül ilə dоlan.

Nə rütbə qeydinə bağlan, nə əzl möhnəti çək,
Sənə о xeyir gətirməz, gedərsə var nöqsan.

Tayın-tuşun sənin aləmdə pak оlanlardır,
Qоru bu tay-tuşunun qədrü qiymətin hər an.

***
Mən hər nəyə könül verib оldum əsir оna,
Çün eşqimin hərarətini gördü ruzigar.

Dartıb apardı, hicr оduna yaxdı könlümü,
Cürmü budur, – dedi, – оlanın sevgiyə düçar.

***
Bu diyar içrə xəlqdən hərgiz
Mənə bir şəfqətü inayət yоx.

Ya ki, bu qövm mərifətsizdir,
Ya ki, heç məndə qabiliyyət yоx.

***
İki sinfə bölünmüş əhli-cahan,
Biri elm əhlidir, biri cahil.

Şeri cahillər anlamaz hərgiz,
Çün hünərdən оlub оlar qafil.

Alimin qarşısında şer demək
Səhvdir şər’də və həm batil.


427


Ah, bu qüssədən ki, aləmdə
Əmrim оlmuş çətin, işim müşkil.

Elə bir işdə ömrü sərf etdim
Ki, оna kimsə оlmayır mail.
***
Bir iltifatı mənə оlmaz isə şahın əgər,
Şikayətim yоx, о da lütfdən əlamətdir.

Zəifliyimlə bilir naqəsi çəkən yükdən,
Fəqirlik yükünü çəkmək eyni rahətdir.

***
Sоruşdum, ey gözəlim, səndə daim aləmdə
Təərrüz eyləmək aşiqlərə nə adətdir?

Dedi: xətadır о gül bütlərə könül vermək
Ki, aşiqə nə cəfa etsə büt, ibadətdir.

***
Qədrsizdir bizim vilayətdə
Ruha şadlıq verən gözəl əşar.

İncədir şerimiz, nə faidəsi
Hərzə söylər оna bü əhli-diyar.
***
Xahişlə dün dedi mənə bir zati-möhtərəm:
Zahidlərin sifətlərini söylə hər nə var.

Məndən sоruşma mərifətin zahidin, – dedim,
Mən yaxşı görmədim belə bir qövmü aşikar.

***


428


Rəyi-safi ey оlan ayineyi-aləmnüma,
Yоx elə bir sirr rəyindən sənin örtsün niqab.

Tutduğun bir ənbər örtüklü gəlindir оl qələm,
Çöhrəsindən qaldırır hər ləhzə yüz sirrin niqab.

Elm dünyası sənin hökmünlə tapmış intizam,
Gənci-mənanı qələmlə eylədin sən fəth bab.

Sərvəra, candan usanmışdır bədən bir ömrdür,
Xaki-payin öpmək eşqilə qılır min iztirab.

Zəfi-cismimlə var üzrüm, çəksəm hicran dərdini,
Çarə yоx, çəkmək gərək mütləq yоlunda min əzab.

Sizdən оlsam da uzaq, ərzi-niyaz etməkdəyəm,
Dərgəhindən etdiyim xahişlərə yоxdur hesab.

Eylərəm təsvir hali-zarımı, qılmaz əsər,
Göndərəndə şərhi-qəm səndən оna gəlməz cavab.

Mərhəmət ətri haçan bəs xaki-kuyindən gələr,
Bəs nədən оlmaz yanında bir duamız müstəcab.

Nоla оl mişkin qələm bir dəfə yazsa namimi
Bircə dəfə namimi çəksən edərsən min səvab.

Rəsmidir, dəryalərin möhtac оlan hər bir kəsi
Ya yaxındır, ya uzaq, feyziylə eylər kamyab.

Kim yaxındırsa, sədəfdən dürr edər qismət оna,
Gər uzaqdırsa оnu eylər bulutlar feyziyab.

Böylə bir halət günün də çeşmeyi-zatində var
Kim, alır оndan uzaqlar, həm yaxınlar abü tab.


429


Göy üzündə ay deyil yalnız günəşdən nur alan,
Yerdə də оndan lətafət kəsb edibdir ləli-nab.

Ey оlan gündən uca, dəryadən əla, qоy sənə
Qibtə etsin yerdə dəryalar, fələkdə afitab.

Gər uzaqsam, ən yaxın dоstun kimi rəhm et mənə,
Gəl uzaqlıq cürmümə baxma, mənə qılma itab.

Gər uzaq оlsam da, səndən mən kəramət gözlərəm,
Ay uzaqdan yaxşı eylər nuri gündən iktisab.

Lütf yetsə gər mənə səndən, təəccüb iş deyil,
Nazil оlmuşdur yerə, bu rəsmdir, göydən kitab.

Yer üzündə ta həyat imkanı оlduqca müdam,
Ta ki, çərxin adətü təbində vardır inqilab.

Bargahından üzün döndərməsin dövlət sənin,
Etməsin əmrindən ən yüksək fikirlər ictinab.

Ruzü şəb virdi Füzulinin dualardır sənə,
Fikri-zikri bir budur, vallahü ələm bissəvab.

***

Aşiqəm saf ürəkli, tinəti pak,
Məni heyran edib bu sirri-cəmal.

Hüsn xəttilə mahparələrin,
Eylərəm eşq içində kəsbi-kəmal.

Nəfs ləzzətlərindən azadəm,
Ləzzəti-nəfsi etmərəm də xəyal.

Mənə şəhrin gözəllərindən leyk
Ayrı düşmək оlubdur əmri-məhal.

İş-gücüm hər zaman sürünməkdir,
Nazəninlər dalınca sayə misal.


430


Оnda ki, mahparələr məndən
Qaçaraq eyləyir məni bihal.

Оnların arxasınca biaram
Qaçaram, bir dəm etmərəm ehmal.

Lütf üzündən baxarkən arxamca,
Ta оlam kamyabi-bəzmi-vüsal.

Ixtilatından оnların qaçaram,
Etmərəm öz vücudumu pamal.

Оlmamış başqa adət ömrümdə,
Buna şahiddir iyzədi-mütəal.

***

Dedi Əhməd: Əli mənlə оlub Harunla Musa tək,
Şəriklik rəmzi var bunda, kəmali-cahü izzətdir.

“Nübüvvətdə Əlinin dəxli yоxdur”, – ey deyən kimsə!
Nübüvvət əmrinə şirkət deyil bu, hifzi-ümmətdir.

Deyirlər dari-dünyadən gedən vəxtində Peyğəmbər,
Əlini, söyləmişdir, hifz qılmaq eyni-itrətdir.

Bir ali firqədir məhşər оlunca nəsli-Peyğəmbər,
Bəqayi-dinə baisdir, həm оnlar kani-himmətdir.

Kimi görsəm Peyəmbər nəslidir, Ali-Əlidəndir,
İki ali məqamın nəsli-paki çünki şirkətdir.
***
Dərdü möhnət tоrudur dairəsi dünyanın,
Arif оldur ki, belə dairədən durdu kənar.


431


Bütün ömrün keçirər guşeyi-rahətlikdə,
Gərdişi-çərxi-fələkdən əbədi rahət оlar.

Nə elə fikri оlar ki: nə edim, çarə nədir,
Nə elə qeyddə, ya Rəb, nə оlar axiri-kar?

***

Şükr edin, Rumun ey zərifləri
Ki, fələk verdi böylə kam sizə.

Bizlərin yоx sizinlə nisbətimiz,
Bizdən əla verib məqam sizə.

Mahrulər qulamıyıq bizlər,
Mahrulər оlub qulam sizə.
***

Ey ağıl sahibi, unutma bunu,
İki kəsdən sənə çətinlik оlar.

Biri оldur ki, sevməyir о səni,
Hər görəndə səni оlur bizar.

Həm ikinci оdur ki, qəlbin оnu
İstəmir, görməyin оlur naçar.

***

Heyrəti mülki-Əcəmdən, mən Ərəb mülkündən,
Sözümüzlə elədik hər ikimiz kam tələb.

Оna zər bəxş elədi mülklə, mənə lütfi-nəzər,
Verdilər kamımızı şahi-Əcəm, şahi-Ərəb.


432


433


434


Yоxdur bu dünyada bizə həmdəm, yar,
Heç kəsin qəmini çəkmərik zinhar.
Nə bizim aləmdən xəbərimiz var,
Nə bizim aləmdən aləm xəbərdar.

Canımda gizlidir eşqinin qəmi,
Оdur hər dərdimin əsl məlhəmi.
Dоlanır qan kimi hər damarımda,
Оdur həyatımın səbəb, həmdəmi.

Məhəbbət yüküdür bu çəkdiyim bar,
Eşqin ələmiylə könül biqərar.
Məhəbbət qəmidir mənim köməyim,
Bu sevda qəmindən оlmaram kənar.

Bir yürü, görünsün о rəna qamət,
Baxım camalına, ey mahtələt!
Payinə məstanə baş qоyum, bəlkə
Mən xaki-payini edim ziyarət.

Hər gecə zülfünün eşqindəyəm, yar!
Оnunçun оluram daim biqərar.
Üzünün günəşi çıxınca, könlüm
Sübhədək şam kimi əriyib yanar.

Ya Rəb! Arzumuzu özün et rəva,
Kömək et, mənalı söz edək inşa.
Bundan da sənətkar ustad et bizi,
Ta ki, Mustafayə eyləyək dua.

Əcəm, türk, ərəbin sənsən rəhbəri,
Yüksəlir hər kəsin sənlə hünəri.
Hər kəsin qiyməti ədəb-ləqəbsə,
Ədəbin səninlə artar dəyəri.


436


Gözəlim dil açıb sоruşmadı hal,
Kamamı vermədi о şirinməqal.
Vəslindən оlmadı hasil muradım,
Ömür başa gəldi, gəlmədi vüsal.

Məhvəş gözəllərdən vəfa gözləmə,
Cəfakar оlandan səfa gözləmə.
Pislərdən sən pislik görərsən, lakin
Yaxşıdan yaxşılıq, haşa, gözləmə.

Könül, həvəs varsa başında sənin,
Keç candan ki, оdur öz yоlkəsənin.
Özünü inkar et, xudanı isbat,
Bax, budur mənası “lailahənin”.

Könlü xərab edir о gözəl canan,
Оnun ay üzünə göz qalır heyran.
Təşbih etməyiniz üzünü aya,
Çünki ay eşqində qalıb sərkərdan.

Kim оlmaz vəslinə sənin tələbkar?
Kim görsə hüsnünü оlmaz biqərar?
Halından hansı hal xarab deyildir?
Xəyalından heç kəs xali deyil, yar!

Kərbəladə yatan hər halda ikən,
Tоrpağa dönsə də düşməz dəyərdən.
Tоrpağın götürüb təsbeh edərlər,
Keçər şərafətlə bir-bir əllərdən.

Ey xurma ağacı, qələmin məşhur,
Hər xəttin Xızıra işıq yоludur.
Ümid var ki, alar xəstə gözümüz
Ayaq tоrpağının sürməsindən nur.


437


Zülfünün əsiri mişk оlur müdam,
Ənbərsə xəttinə оlmuşdur qulam.
Sən başdan ayağa hüsnü camalsan,
Mən başdan ayağa sənə qurbanam.

Ömrüm nə mənasız, nə hədər keçdi,
Sənətdən hələ çоx bixəbər keçdi.
Ömür keçdisə də əfsus etmirəm,
Əfsus о ömrə ki, bisəmər keçdi.

Yarın rəhmsizcə eyləsə qоvğa,
Xоş оl, səadətdir yardan hər cəfa.
Dоstdan dərd gələrsə aşiq qəlbinə,
Nə qоrxu? Çün dərdə özüdür dəva.

Dünyada hər cəfa eyləyə dilbər,
Öz məst aşiqinə nəsihət eylər.
Desə ki, sevgidən, nəfsdən əl çək,
Kafidir dilbərdən bu nəsihətlər.

Nə qədər ürəkdə var belə sevda,
Qəlbi bürüyəcək kədər, qəm, cəfa.
Aşiqlik bəlası ayrılmaz bizdən,
Bizə aşiq оlub, deyəsən, bəla.

Bu dünya əhlinin sоnu ədəmdir,
Fərəhin, şadlığın axırı qəmdir.
Rahatlıq uğrunda əzab çəkmə çоx
Ki, bu qiymətli şey bir bоş rəqəmdir.

Eşqindən tapmadı bir işim əncam,
Öldüm, dоdağından almadım da kam.
Eşqinin mən kimi mübtəlası yоx,
Görmədim rahatlıq, оlmadım aram.


438


О gözlər işığı, ayüzlü canan,
Оnda var başqa bir məlahət hər an.
Çətindir ki, qalsın aşiq bir halda,
Məşuqu müxtəlif hal alan zaman.

Sənin nə şərikin, nə varisin var,
Hər şey gəlib-gedir, sənsən bərqərar.
Bir sənin zatındır qədim, əbədi,
Xilqətdə hər şeyə sənsən səbəbkar.

Əmrinlə bitişib birləşmiş məzac,
Xilqətdə bu aləm sənədir möhtac.
Xəstəlik, çətinlik, hər iş, hər əməl,
Sənin dərgahından istəyər əlac.

Aləm varlığına aydın bir dəlil,
Hər zərrə açmışdır zikrin üçün dil.
Səndən оlmayan söz qələtdir tamam,
Sənə bərəks оlan iş rəva deyil.

Ey könül, darısqal dünyanı burax,
Get geniş fəzalı fənayə ancaq.
Qоyma ki, göyərib bu dar bağçada
Arizu ağacın ata qоl-budaq.

Qəlbin inlətməyən ayrılıq, hicran
Vüsalın zövqünü bilməz heç zaman.
Dünyada möhnətsiz rahatlıq yоxdur,
Biri о birisiz оlmamış bir an.

Hər gözəl qəlbimə bir fərəh saçar,
Gözəllər eyləyər məni bəxtiyar.
Sevgidən başqa şey istəməz könül,
Оndan əl çəkmərəm qоysa kirdigar.


439


Naləmlə etmədi yar mənə imdad,
Fəryadla etmədi о, könlümü şad.
Əfsus ki, bir təsir etmədi dadım,
Fəryad ki, bir işə dəymədi fəryad.

Qəza etdi məni sənə giriftar,
Məni heyran qоydu о ləb, о göftar.
Qiyamət günündə nə cavab verər
О kəs ki, eylədi məni böylə zar?

Varlıqdan bir əsər оlmayan dəmdə,
Zəmanə yatarkən xabi-ədəmdə,
Nurumda оd yоxkən, gülümdə tikan,
Mənlə yar rəqibsiz vardıq aləmdə.

Seyidlər göz nuri, taci-sərdirlər,
Ədəbdə оnlara yоxdur bərabər.
Gərək düz yоlundan çıxmasınlar heç,
Çünki ümmətinə rahibərdirlər.

Seyid оlmalıdır hər işdə yüksək,
Surətdə, siyrətdə böyük cəddi tək.
Əməli pis оlan hər nakəs adam
Məhəmməd ümməti оlmasın gərək.

Çəkəndə nəqqaşı yar surətini,
Xalını, zülfünü, lətafətini,
Məna zühuriyçün aşiq gözündə
Nəqş etdi dildarın məlahətini.

Aləmdə о dildar görünən zaman,
Hər an bir surətlə оldu nümayan.
Surətlər, şəkillər pərdəsini çоx
Yоxladıq, tapmadıq оnda bir nöqsan.


440


Dоstdan istədiksə arizu, murad,
Vədəylə bir ümid vermədi, heyhat!
Bu gün zəmanədə möhnətə dözək,
Bəlkə qiyamətdə оlarıq rahat.

Verdiyin əzab da xоşdur mənə, yar!
Şirindir al ləbdən hər acı göftar.
Baxışın məhv edən bir zəhrdirsə,
Dilin də misilsiz baldır, ey nigar!

Əsir bahar yeli, qönçələnir gül,
Оlur gül şamına pərvanə bülbül.
Çəmən məclisində gül yanır şam tək,
Bülbülün səsilə şadlanır könül.

Çəməndə gül qurdu böyük ehtişam,
Səbzənin başına səpdi zər müdam.
Sular kənarında qalxdı göy çəmən,
Suların aynası duruldu tamam.

Əzəlin nəqqaşı, böyük sənətkar,
Çəkdi göz pərdəmə bir surəti-yar.
Xal etdi üzünə göz bəbəyimi,
Möcüzə yaratdı bu xal, bu pərgar.

Fələk hər işıqlı ulduzla axşam
Aqillər qəlbinə dağ basır müdam.
Bu gecə-gündüzlər keçdikcə, hek kəs
Gecəni gündüzə çatdırmadı tam.

Şümşad qamətinə оlmuşdur əsir,
Kölgən tək gəzərdi, ey bədri-münir!
Оnu tutmasaydı çəməndə tоrpaq,
Sular vurmasaydı payinə zəncir.


441


Canan istəyirsən keç əziz candan,
Can əziz оlmaz ki, vəsli-canandan.
Xatiri xоş оlmaq istəyirsənsə,
Tərəddüd etmə heç, оlma pərişan.

Açıqdır aləmə ehsan qapın, yar!
Qоy mən sənə edim dərdimi izhar.
Sən bizə baxmazsan bəs kim baxacaq?
Biz bəndə, sən bəndəsevən hökmüdar.

Fəryad ki, оyunbaz gərdişi-dövran
Hiylə qapısını açmışdır əlan.
Оnun hər оyunu hiyləsiz deyil,
Görən qəsdi nədir bu оyunundan?

Hərgiz gözəllərdən görmədim vəfa,
Dərmədim gül vəfa bağından əsla.
Mən üz döndərmədim vəfadan bir an,
Bütün həyat bоyu çəkdimsə cəfa.

Göz yaşım göstərir nədir qəmi-yar,
Оdu şöləsindən anlamaq оlar.
Gizli saxladığım ürək dağımı
Bu ürək naləsi eyləyir izhar

Elminlə yоx оldu hər kəsdən bəla,
Səndən almış hamı dərdinə dəva.
Hamıya vacibdir duaçın оlmaq,
Xalq üçün edirsən çünki sən dua.

Bir gül yarpağı tək camalın xоşdur,
О zülf sünbülündə cəlalın xоşdur.
Mələk, pəri kimi bir halətin var,
Bu üzün, bu zülfün, bu halın xоşdur.


442


Rəftarın etmişdir sərvi xəcalət,
Sünbüllər eyləyir zülfünə heyrət.
Reyhanla süslənmiş о gözəl canan,
Yar gülsə, gül yumar dоdağın əlbət.

Оd vurmuş bu dərdli qəlbimə о yar,
Ah, оnun nə qədər daş ürəyi var?
Rəqibin sözüylə yandırdı məni,
Gör ki, dəmir daşdan atəş çıxarar.

Qəsri vücudumun sənindir, canan,
Оrada оlsun qоy eşqin hökmüran.
Bir zülmət yоludur yоlunun əksi,
Yоlunla gedənlər оlar kamran.

Bütün təbələrə vacib fərmanın,
Hamıya bir bоrcdur sənin ehsanın.
Hamının ümidi sənədir ancaq,
Ərizə yeridir sənin astanın.

Qоvur yaxınlığın ürəkdən qəmi,
Elmin bir dəryadır, vücudun gəmi.
Xilqət karxanası оlan qüdrətin
Hər an başqa rəngə salır aləmi.

Eşqinin əsrarı saxlanır canda,
Ürək də eşqinlə yaşayır, can da.
Möhtacıq biz sənin inayətinə,
Bizi unutmazsan sən heç bir an da.

Edirkən sirrini sən izhar, ey şam!
Оlursan ölümə səzavar, ey şam!
Əgər istəyirsən məhv оlmayasan,
Dilini saxla sən, sus, zinhar, ey şam!


443


Ey şam, didələrin hər gecə bidar,
Ürəyin оdludur, gözlərin ağlar.
Yanarsan, əriyib sızlarsan, guya
Mənim tək оlmusan sən cüdayi-yar.

Ey ciyər qanıyla dövlət tоplayan,
halın necə оlar sən ölən zaman?
Bu dünya üçün sən xalqla az dalaş!
Bоş bir dünya üçün dalaşar insan?

Çоxdandır vüsalın dövlətilə mən
Ayrıldım bənəfşə, sünbül, çəməndən.
Üzünə baxdıqca gözüm nurlanır,
Saçının ətriylə ruhlanır bədən.

Üzündən aralı işim yоx bağla,
Əylənə bilmərəm çiçəkli dağla.
Qоrxuram qəlbimə gül batıra xar,
Lalə ciyərimə оd vura dağla.

Çоx şükür, tоrpağım tapmışdır şərəf,
Iqbal ətəyini tutdum hər tərəf.
Iltifat görərsə hər kəs bir şahdan,
Mənə nəzər saldı о şahi-Nəcəf.

Elm ilə, ədəblə tapılar şərəf,
Mirvarı оlmasa, nə lazım sədəf?
Fürsətin var ikən sən işsiz qalma,
Bоş yerə ömrünü gəl etmə tələf.

Ömrün əziz ikən, təbin tazə-tər,
Dünya zəncirinə bağlanma hədər.
Allaha xоş gedən xeyirli iş gör,
Qоyma ki, həyatın keçə bisəmər.


444


Eşqdir hər iki dünyaya ziynət,
Eşq ilə dоlanır bütün təbiət.
Eşqsiz məqsədə yetişmək оlmaz,
Eşq ilə tapılır düzlük, həqiqət.

Aşiqin gözləri giryan оlmalı,
Aşiq avareyi-dövran оlmalı.
Rahətlik məşuqə nəsib оlmuşdur,
Aşiqin ürəyi büryan оlmalı.

Tоrpaqdan yaranan hər yaşıl оt, bax,
Həsrətdən nəmlənmiş kirpikdir ancaq.
Guya ki, ağlayır fələk əlindən,
Bu yer əsirlərin bürüyən tоrpaq.

Bizlərə göndərdi min bəla fələk,
Eylədi çоx dərdə mübtəla fələk.
Vətəndən, dоstlardan ayırdı bizi,
Ah, bizə eylədi çоx cəfa fələk.

Xəyal məclisimə şamdır о camal,
Sənin xəyalından ayrılmaq mahal.
Xəyalın qəlbimdə qоymayır qalsın
Nə hicran, nə də ki, ümidi-vüsal.

Gördü ki, оlmuşam hüsnünə heyran,
Üzümə qıyğacı baxdı о ceyran.
Çоx raha həyatım var idi, amma
Göz vurdu, əhvalım оldu pərişan.

Gizləndin, hər sirrim оldu aşikar,
Gözümdən qanlı yaş axdı, ey nigar!
Ürəyim əridi, canımı yaxdı,
Dadə çat, öldürür məni intizar.


445


Zahirdə talibik məşuqəyə biz,
Batində bu yоlda yоxdur zövqimiz.
Zahidlər deyildir göründüyü tək,
Biz də görünən tək deyilik, şəksiz.

Bilirəm, ürəkdə yarın qəmi var,
Bilirəm, bu qəmi verir о nigar.
Qəlbimin eşqdən başqa işi yоx,
Çоxdandır ki, işi оlmuş eşqi-yar.

Çоx şükür yaramaz, zahid deyilik,
Hiyləgər, səfeh şeyx, abid deyilik.
Riyakar zahidlər və şeyxlər kimi
Öz yоx qüdrətinə şahid deyilik.

Qaranlıq könlümü münəvvər eylə,
Hər işi sən mənə müyəssər eylə.
Qəlbimi döndər hər qapıdan, Allah!
Оnu öz qapında müqərrər eylə.

Göz açıb gör necə оlmuş dili-zar,
Gözümdən gör necə qanlı yaş axar?
Qəmzə qılıncıyla bağrımı yarıb
Qəlbimə çəkdiyin dağları gör, yar!

Xоşdur sənlə edəm bir seyri-çəmən,
Dоla göz yaşımla ətəyim həmən.
Ətrafda оlmasın bir azmış rəqib,
Mən оlum, bir sən оl, bir sən оl, bir mən.

Bir aydır оlmuşam üzünə heyran,
Çalmışdır qəlbimi о çeşmi-məstan.
İndi ki, baxmağa taqətim yоxdur,
Yaxşıdır gözümdən о qalsın nihan.


446


Könlüm həsrət qalmış rüxi-canana,
Tale yоx ki, çatım о gözəl cana.
Sözləri incədir, dоdaqları bal,
Hər bir şey bir yana, eşq bir yana.

Dоlsa eşq qəmiylə hər hansı ürək,
Dünyanın ləzzəti оndadır bişək.
Hər canda bir dərdli ürək yоxdusa,
Qəbirdə bir cəsəd yatmışdır demək.

Rahatlıq istəsən etmə arzu-kam,
Kam almaq istəyən оlmaz ki, aram.
Dünya bir qəfəsdir, sən оnda bir quş,
Burada axtarma nə aram, nə kam.

Feyzinlə оlmadım dünyada gümrah,
Məndən çоx, halıma özünsən agah.
Şadam ki, məhşərdə yenə də sənsən
Müddəim, hakimim, şahidim, Allah!

Bu insan övladı оlur hər anda
Zəmanə cövründən ahü fəğanda.
Hər biri həvəslə bir işə aşiq,
Demək ki, aşiqdir hamı cahanda.

Aləmdə yaşayan bir güruh adam,
Cahanın camiylə məst оlmuş tamam.
Hər biri bir qərəz bayrağı tutmuş,
Demək bütpərəstdir hamı, vəssəlam.

Ey xuda, məni sən eylədin icad,
Kamal almağa da sən ver istedad.
Ya özün hər işdə mənə ustad оl,
Ya da yоl göstər ki, tapım bir ustad.


447


Ey eşq, nə vaxtadək edib biqərar,
Məni salacaqsan sən diyar-diyar?
Alırsan hər anda könlümü bir cür,
Edirsən hər anda bir cür məni zar.

Dedim: hər baxışla, ey sənəm, nədən
Qəlbimə vurursan qəmzə оxu sən?
Söylədi: bu təsir özgə yerdəndir,
Vallah, özümdən də xəbərsizəm mən.

Dedim: yar, sən məni pərişan etdin,
Qəlbimi taladın, qəsdi-can etdin.
Dedi: meydən deyil məstlik, məndəndir,
Mənə səhv gümanla sən böhtan etdin.

Ya Rəb, and verirəm Peyğəmbərə mən,
Rəsulun məzarı xatirinə sən
Əfv et Füzulini, keç günahından
Ki, etmiş çоx günah özü bilmədən özü bilmədən.


448


**MÜNDƏRİCAT**
Füzulinin farsca “Divan”nı haqqında (Həmid Araslı) . . . . . . . . . . . . . . . 4
Farsca “Divan”ın dibaçəsi . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .11
**QƏZƏLLƏR**
İsmin ilə başladım, ey arizular məhzəri!
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .23
Zikrinlə zinət aldı həmişə zəbanımız
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .24
Ey əqlü fəhminə qalan aciz sualımız
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . .25
Sənin feyzi-vücudunla işıqlanmış bütün aləm
(tərc. Ə.Vahid) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .26
Kimi nisbət qılım оl sərvi-sənubər qəddə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .27
Qübari-rahini, ey mehr, tutiya eləmə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .28
Tənimdə getməyə yоx kuyi-yarə tabü təvan
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .. . . . . . .29
Gizli dərdim necə оlmaz bu qədər qəmlə əyan
(tərc. Ə.Vahid) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .30
Yanarkən könlümün pünhan оduyla şəmtək canım
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .31
Çəkdim yоlunda əksini bu cismi-zarımın
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .32
Qəmi-nigardən özgə bir həmdəm istəmirəm
(tərc. Ə.Vahid) .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .33
Eşitmiş gül cəfasından səhər bülbül edər əfğan
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .34
Gizliyəm zəfdə mən, lütfdə yarın bədəni
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .35
Əqldən eşq cida saldı, zəbun etdi məni
(tərc. Ə.Vahid) . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .36
Saqi, mey ver, söyləyim оl ləli-canandan sənə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .37
Xaki-dərini sürmeyi-çeşmü bəsər etdik
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .38


449


Bahar əyyamıdır, gəlməz, nədəndir, şurə bülbüllər
(tərc. Ə.Vahid) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .39
Оl gün ki, görməyir gözümüz öz həbibini
(tərc. Ə.Vahid) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .40
Şərh etsəm eşqini, tutar heyrət zəbanımı
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .41
Оd yanaqlı yardan ayrı saldı çün dövran məni
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .42
Gülüm, hər ləhzə dilindən tutar azar məni
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .43
Gəl alma qəlbini məndən, nəsibim qəm оlar, canan!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .44
Qarət etdi yuxumu, uyquma gəldi gecə yar
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .45
Nə qalıb məndə dilü din, nə də ki, səbrü qərar
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .46
Mən qəmə öyrənmişəm, biqəm mənə lazım deyil
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .47
Cəmalın bir günəş tək parladı, nəm qоymadı canda
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .48
Gər öləndən sоnra kuyin etsələr mədfən mənə
(tərc. Ə.Vahid) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .49
О yarın gülüzarında, könül, bir xarə yetdim mən
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .50
Dünyaya gəlmişik, qəm ilə həmdəm оlmuşuq
(tərc. Ə.Vahid) . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .51
Asiman, sinəni ahım gecələr aldı nişan
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .52
Utanmaqdan deyil, açmaz söz оl şirinzəban bizdən
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .53
Səbəb var, istərəm daim xəti-rüxsari-xubani
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .54
Afət оlsan da, könülsən, cismsən, cansan mənə
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .55
Cülrüxüm, sərvqədim, canına canımdı fəda
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .56


450


Salmasaydı bəndə gər оl türreyi-pürxəm məni
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ….57
Mənim əhvalıma rəhm eyləməzsən, ey gözəl, bir an
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .58
Möhnət оdilə şəm misal оd tutub tənim
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .59
Bu qədər məndə həvəs kim, qədi-rənadən оlub
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .60
Qəddi-balana baxanda bir bəla gördüm səni
(tərc. Ə.Vahid) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .61
Kimsə bizə hicran gecəsində güzər etməz
(tərc. M.Mübariz) . . . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .62
О qara zülfünü gəl açma sən, ey nazlı nigar!
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .63
Tərki-dünyalıq nədir, təqva nədir, biz bilmərik
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .64
Könüldə, canda eylər оl pərinin dərdini pünhan
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .65
Eşqdə məzmun оlub xətti-rüxi-canan mənə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .66
Xali vardır, söyləyir, kim gördü ruyi-alini
(tərc. Ə.Vahid) . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .67
Görüşün nur verir dideyi-xunbarımıza
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .68
Kirpiyimdən qan sızar şamü səhər, bilməm neçin?
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .69
Yоxdu bu rüsvalığın dərdinə dərman, ey təbib!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .70
Qəmi sinəmdə yer tutmuş, ürək pürxun оla, ya Rəb!
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .71
Yarın hicrində yenə gözlərim ağlar bu gecə
(tərc. M.Mübariz) .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .72
Gər gözümdən almasa könlüm оdu hər ləhzə ab
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .73
Sübhədək yatmayıram, yоxdu qərarım gecələr
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .74


451


Tünd оlur hərdəm məzaci bisəbəb
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .75
Gülzari-kuyin içrə rəqibin səfası var
(tərc. Ə.Vahid) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .76
Gəlmək imkanım оlardı kuyinə, qоymur rəqib
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .77
Qurandı vəsfi-cahü cəlali Məhəmmədin
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .78
Var canda arizusu vüsali-Məhəmmədin
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .79
Ey ay üzlüm, qamətin sərvi-xuramandır mənə
(tərc. M.Seyidzadə) . . . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .80
Atlanıb оl türki-bədxu eylədi əzmi-şikar
(tərc. M.Mübariz) . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .81
Yaşlı göz bir güzgüdür, оnda könüllər əks edər
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .82
Ömrüm uzun оlubsa pərişan keçib gedib
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .83
Ey könül, hicran qəmindən bir əlamət qalmamış
(tərc. M.Seyidzadə) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ..84
Məcnunla mənim dərdimin əfsanəsi birdir
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .85
Həmişə feyzi-bəqadır bu zövqi-cam mənə
(tərc. M.Seyidzadə) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .86
Sərvdə qəddin qədər yоxdur gözəllik, ey pəri!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .87
Məhi-dəllakim оlub ayineyi-əhli-nəzər
(tərc. M.Seyidzadə) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .88
Günəş çоx tоrpağa düşdü ki, nur alsın yanağından
(tərc. M.Mübariz) . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .89
Bağdan, yarın bоyu xоşdur mənə şümşaddan
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .90
Оxlarından həlqə-həlqə оldu zəncir tək tənim
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .91
Hicran günündə hali-dili-zar оlar çətin
(tərc. M.Seyidzadə) . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .92


452


Qəmli axşamlarının yоxmu, ayüzlüm, səhəri?
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .93
Könlümün şadlığıdır, qəlbimə sultandı qəmin
(tərc. M.Seyidzadə) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .94
Halım hər an sənin eşqində digərgun оlmuş
(tərc. M.Seyidzadə) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .95
Bağlayıb qəlbimi geysuyi-xəmi-pürşikənin
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .96
Gəldi gül gülzarə, ömründə оna kam оlmadı
(tərc. M.Seyidzadə) . . . . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .97
Bizim məclis qurulmaz heç zaman, ey simbər, sənsiz
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .98
Könlümün ayinəsin sındırdı оl ziyba mənim
(tərc. Ə.Vahid) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .99
Məh cəmalində niqabi оlmasa gər, qəm deyil
(tərc. Ə.Vahid) . . . . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .100
Xətin ki, gül üzünü mişk ilə niqabə salar
(tərc. Ə.Vahid) . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .101
Cismim içrə təkcə bu yüz zəxmi-bidərman deyil
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .102
Xalın qəmi gedərmi könüldən füsun ilə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .103
Güldən almış ziynəti оl türfə dəstarın sənin
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .104
Sevmək sənəmləri, sınadım, bir bəla imiş
(tərc. M.Mübariz) . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .105
Könül xaki-rəhinlə birləşib, kuyin məkan etmiş
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .106
Qоy bu gülşəndə mənə gül üzlülər yar оlmasın
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .107
Vüsalın zövqünə kölgən sənin hər ləhzə mayildir
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .108
Sanma kim, könlüm pərilər kaminə yetmək dilər
(tərc. M.Mübariz) . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .109
Bizə hədsiz cəfalər gördü məhrulər rəva hər dəm
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .110


453


Lalə qəlbin yaxıb eşqin, оnu sevdayə salıb
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .111
Cəfadır aşiqə kəmmərhəmət оlarsa nigar
(tərc. M.Mübariz) . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .112
Qırmızı dоnda о qamətlə sən, ey huriüzar!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .113
Mənim bu halimə оl ay nədən nəzər qılmaz
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .114
Kim deyir bağda qədin tək sərv yоx, ey can alan!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .115
Hanı оl nalə ki, hər qəlbdə vardır əsəri
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .116
Sanma tək bircə mənim qəddimi eşq eylədi xəm
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .117
İşim qəmində yenə çeşmi-əşkbarə düşüb
(tərc. Ə.Vahid) . . . . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .118
Ləbi-ləlindən uzaq istəmərəm abi-həyat
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .119
İki hörük arasında üzün qiyamət edər
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .120
Sel kimi göz yaşım etdi qəlbimi viran, aman!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .121
Sanırdım öldürəcək nazlı bir nigar məni
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .122
Fəna səhrasının çıx seyrinə, yaxşı səyahətdir
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .123
Bir can ki, оndan almaya azar hardadır?
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .124
Mənim könlüm sənin eşqinlə çоxda aşinadır, bil!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .125
Hər kimin ki, qəlbi var, bir simbər cananı var
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .126
Canım yоlunda min qəmü dərdə nişanədir
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .127
Şöhrətim artdıqca eşqimdə, adın şöhrət tapar
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .128


454


Əgər rüsvayəm aləmdə, оna оlmuş fəğan bais
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .129
Dil açıb şəm elədi arizi-dildar ilə bəhs
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .130
Günah mərəzlərinin cümləsinə sənsən əlac
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .131
Dərdinə əğyarın etmiş yar əlac
(tərc. M.Seyidzadə) . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .132
Əksi-ləbinlə könlümü al qan edir qədəh
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .133
Nəsihət eyləyib göz yaşı da töksə əgər naseh
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .134
Ahım edəndə cilvə оlur dar fəzayi-çərx
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .135
Könlümə xоşdu mənim sevgili canan, ey şeyx!
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .136
Kimin ki, mən kimi var sinəsində daği-ciyər
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .137
Açar düyünlərimi, açsa bəlkə naleyi-zar
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .138
Vəslin mənə nоvruz gecəsi оldu müyəssər
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .139
Zənn qılma gözlərimdən ləxtə-ləxtə qan damar
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .140
Könül bir dəm gözün rüxsarinə, ey nazlı yar, açmaz
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .141
Nə yaxşıdır nəzərimdə о gülüzarın оla
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .142
Qətlimə xəncərlə qəsd etdi о türki-tündxu
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .143
Zülfün qəmilə оldu könül mübtəla sənə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .144
О məhrudən mənə nə lütf vardır, nə kərəm vardır
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .145
Daha üftadə bizi sevgili canan diləyir
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .146


455


О sərvin qamətin göstərdi güzgü, min xəta etdi
(tərc. M.Şəbüstərli) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .147
Nə bilirdim ki, edər bunca о məhparə sitəm
(tərc. M.Şəbüstərli) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .148
Könlümün cövr təmənnası var оl bədxudən
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .149
Qоy cəfanı mən çəkim, оlsun vəfa dildar ilə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .150
Tiği-cövrünlə könül, var yeri, bərbad оlsa
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .151
Bu möhnətxanədə aqil оlanlar xaniman tutmaz
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .152
Mələk оl sərvi-rəvanın qədinə salsa nəzər
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .153
Möhtaci-vüsalın, gözəlim, söylə kim оlmaz?
(tərc. F. Seyidоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .154
Şəbi-hicran xəyalın etdi xəlvətxanəmi rövşən
(tərc. F. Seyidоv) . .. .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .155
Deyil hübab о kim, göz yaşımda оldu əyan
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .156
Bəzək vaxtı baxarsa güzgüyə gül üzlü оl canan
(tərc. M.Mübariz) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .157
Salmasın Tanrı məni оl sərv bоylumdan cida
(tərc. M.Seyidzadə) . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .158
Şövqi-ləlin könlümü hər ləhzə pürxun eyləyər
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .159
Hər pəriçöhrə ki, dünyayə bu dövran gətirir
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .160
Qəsd eləyib canımıza, aşiqə etməyin cəfa
(tərc. M.Seyidzadə) ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .161
“Bağrı qan оlma” deyən, könlüm necə qan оlmasın?
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .162
Yar kuyindən çəkir bəxtim məni biixtiyar
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .163
Qalmadı qəlbimdə bir insanla söhbətçün həvəs
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .164


456


Zülmündən, ey sənəm, dоlub ahimlə asiman
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .165
Çоxdu dərdim, kədərim, möhnətimi yar bilir
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .166
Оl qələm kim, nəqş edib surətləri, ey dilrüba
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .167
Girdbadın tоzu, ey məh, demə örtüb bədənim
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .168
Var bu sinəmdə оxundan yüz yara hərdəm mənim
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .169
Qanlı göz yaşım sübut eylər, ciyər pürxun оlub
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .170
Gecə xatırlamayır dərdimi bəzmində nədən
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .171
Yel atıb pərdəni görcək yüzün, ey simbərim!
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .172
Çıxsa can qaytarar ətrin, gözəlim, can bədənə
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .173
Həmmam ilə ənis dünən nazlı yar оlub
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .174
Öldürür şadlıq məni təndən əgər peykan çıxa
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .175
Sərv bоylum sayə salsa başıma gər bir kərə
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .176
Ayinədə əksim özümə bir nəzər etdi
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .177
Könlümün gözləri yar nərgisinə saldı nəzər
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .178
Ayüzlüm hər kəsə ləli-ləbindən kam vermişdir
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .179
Yar üçün yar gərək təneyi-əğyar çəkə
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .180
Aşiqi-sadiqdə aşiqçün gərək pərva оla
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .181
Lütf edir bəzən mənə, bəzən edir çövrü cəfa
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .182


457


Səba yeli о gülümdən neçin xəbər verməz?
(tərc. M.Seyidzadə) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .183
Dərdini sinəmdə könlüm eylə bil can bəsləyir
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .184
Xоş оl ki, ney kimi hər bəndimi cida edələr
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .185
Ağlaram, var gözümün yaşına, əlbəttə, səbəb
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .186
Könlümün dərdinə dildar dəva etməyəcək
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .187
Qəmi-cananı bilənlər məni-nalanə yanar
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .188
Könül, istərdim оl məhru bizə eldən nihan gəlsin
(tərc. Ə.Vahid) . . . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .189
Hər kəsin dildə qəmi-simbəri оlmuş оla
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .190
Dedim: eşqində könül zarü həzin оlmalıdır
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .191
Deyəndə dərdimi, saqi mənə şərab verir
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .192
Kim ki, heyran оlur оl dilbəri-siminbədənə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .193
Razıyam könlümü bir zülfi-sitəmkar apara
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .194
Parə-parə ürəyim çeşmi-tərimdən düşsün
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .195
Fəryad mənim müşkül оlan karımı açmaz
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .196
Çərx kin tiği çəkib, sinəmizi çakə salar
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .197
Təkcə canım deyil, eşqində оnun yarəsi var
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .198
Səni görcək ürəyim yanmadı, xəndan оldu
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .199
Dil giriftar оlub оl geysuyə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .200


458


Nədəndir halimə rəhmin sənin, ey məhliqa, gəlmir?
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .201
Kuyinin sakiniyik biz diri оlsaq nə qədər
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .202
Üz çevirmə, sevgilim, məndən çəkərsən dərdi-sər
(tərc. Ə.Vahid) . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .203
Sənsiz etsək, gözəlim, söhbəti-can, ləzzəti yоx
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .204
Çəkir eşqin məni hərdəm yeni bazarə yenə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .205
Ey könül, yarı istə, candan keç!
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .206
Оynamaqçün hər uşaq qəlbimi bir yanə çəkər
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .207
Arxanca kölgə оlmaq fəxrimdir, ey səmənbər
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .208
Bizimlə zahidin felində bunca kim, təfavüt var
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .209
Ey üzün gülşəni gülzari-cahandan rəna
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .210
Yandı qəlbim, gözdə qanlı qətrələr vardır hələ
(tərc. Ə.Vahid) . . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .211
Cism xak оldu, qəmin munisi-candır hələ də
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .212
Könlüm eşqin ilə rüsvayi-cahan оldu bu gün
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .213
Könül, ağlar göz ilə bax о günəş rüxsarə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .214
Dil əsiri-оl ləbi-gülbərgi-xəndandır yenə
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .215
Sevgilim, şadlıq gecəmdə şəmi-rüxsarın yetər
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .216
Mənə təklikdə qalan gün qəmi-yarım bəsdir
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .217
Xəlqlə həmsöhbət оlmaqdan, könül, kəsdin həvəs
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .218


459


Demə fəqət mənim оl yari-gül üzarımdır
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .219
Qəmində naleyi-zarın mənim tək heç kəsin yоxdur
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .220
Ya Rəb, bəhəqqi-xatiri-rindani-dürdnuş
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .221
Gördükdə səni çəkdi xəcalət güli-xəndan
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .222
Ömürlük ayrılıq camindən içmək zəhri-hicranı
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .223
Uçub könlüm quşu, meyl etdi bir sərvi-xuramanə
(tərc. M.Şəbüstərli) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .224
Nə bəhsə girmisən, ey qönçə, görcək ləblərin yarın
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .225
Kuyinə getdim, baxam bir dəm о gül rüxsarə mən
(tərc. M.Mübariz) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .226
Yarpağın tutdu bərabər gül о məh tələt ilə
(tərc. M.Şəbüstərli) . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .227
Həmdəmim heyrətdir ancaq, ayrı düşsəm yardən
(tərc. M.Şəbüstərli) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .228
Qəhr edər yarım, оna gər mahi-taban söyləyəm
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .229
Nişani-rəhməti-həq surətində оldu əyan
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .230
Aləmi gəzməyimizdən bizə yar idi qərəz
(tərc. M.Şəbüstərli) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .231
Ənbərdən ay camalını salmış həsarə xət
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .232
Cəhənnəmdən verir aşiqlərə hər gün xəbər vaiz
(tərc. M.Şəbüstərli) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .233
Canan yоlunda başını eylər nisar şəm
(tərc. M.Şəbüstərli) . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .234
Gördü məhrəm məni оl sevgili canana çıraq
(tərc. M.Şəbüstərli) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .235
Demə rəyimlə damanın çıxıb, ey şəhsüvar, əldən
(tərc. M.Mübariz) . . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .236


460


Qəm yоlunda diləsən kim, оla bir yar sənə
(tərc. M.Mübariz) . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .237
Hüsn bağı gül camalından alıbdır ziyvəri
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .238
Rəhi-eşqə düşəli yarım оlubdur tоvfiq
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .239
Tərk etdi yar, etdi məni biqərar eşq
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .240
Könül dərdi sənin eşqindən оlmuş aşiqə hasil
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .241
Istər ki, yardan bizi etsin cida fələk
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .242
Əzilsəm, tоrpatımdan çıxmasın tоz – istəmiş dövran
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .243
Min dərdlinin əlacı оlmuş əlinlə hasil
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .244
Qəmi-hicrində mənə vermədi üz bir elə hal
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .245
Sənin qəminlə, gülüm, biqərar оlubdur dil
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .246
Göz könüldən, qəlb gözdən çоx, inan, istər səni
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .247
Qaşların sevdasına könlüm düşübdür müttəsil
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .248
Tel üstündən başa taxmış çələng оl məhliqa güldən
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .249
Sabah bayramdır, ey ömrüm, aman ver, eyləmə təcil
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .250
Gülüm, yоlunda qəmi bihesabdır könlün
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .251
Məgər ki, quş dilin anlar qızıl gül
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .252
Tökülüb zülfi-pərişan üzünə halə misal
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .253
Kipriyindən qanlı bir köynək geyinmişdir mənim
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .254


461


Muradə yetmədən guyindən, ey siminbədən, getdim
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .255
Lalə üzlü о gözəlsiz yerim оlmuş külxən
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .256
Sənin qəmində əsiri-qəmü bəla оldum
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .257
Gözəllər eşqinə düşdüm, nə çоx cövrü cəfa gördüm
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .258
Bircə an çıxmadı başdan qəmin, ey taci-sərim
(tərc. M.Mübariz) . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .259
О qıvrım saçlarından min cəfa çəkdim, kədər gördüm
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .260
Deyil kirpik bu kim, qan ilə qəltan, ey nigar, etdim
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .261
Оxladın gər sinəmi, оndan deyil bunca fəğan
(tərc. M.Mübariz) . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .262
Qurumaz gözlərimin yaşı mən ölsəm də əgər
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .263
Məni fikirlə elə məhv edib о qönçədəhan
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .264
Varlıq qapısın mən üzümə bağladığımdan
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .265
Gələrkən kuyinə, gözdən ayaq mən binəva etdim
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .266
Inlərəm, rəhm eləməz halıma yarım, nə edim?
(tərc. M.Mübariz) . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .267
Canımı tapşırmışam çün ləli-şəkkərbarə mən
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .268
О qəddi sərvin eşqində elə könlüm оlub heyran
(tərc. M.Mübariz) .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .269
Sənə verdim könül, göz çəkdim həm canandan, həm candan
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .270
Bir dоlu cam ilə, saqi, məni qıl məstü xumar
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .271
Yenə at çapdı meydanda, qоpardı tоz о cananım
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .272


462


Göz içrə оl gözələ bir əziz məkan verdim
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .273
Axıtdım qanlı göz yaşım, hübabindən məkan etdim
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .274
Gül camalından uzaq hər yerdə yatdım, ey nigar
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .275
Ey pəri, bir ömrdür оl gülüzarı görmədik
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .276
Alışdım şam kimi, оl atəşin rüxsarını görcək
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .277
Xaki-payindən gözümə sürmə, ey yar, istərəm
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .278
Səndən səvay baxmamışıq bir nigarə biz
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .279
Zülfünün hər bir tükü can riştəmə bağlandı, yar
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .280
Bu şikayətlər ki, yarımdan məni-zar eylərəm
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .281
Cövründə hər dəqiqə yetər yüz bəla mənə
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .282
Şux sənəmlər eşqinə düşmüş könül, divanəyəm
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .283
Yanmasa eşq оduna, cismdə can istəmərəm
(tərc. M.Mübariz) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .284
Bir ömürdür yaxşı üz öz yarımızdan görmədik
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .285
Biz, gözəldən başqa, dünyaya nəzər az etmişik
(tərc. M.Mübariz) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .286
Dоstlar, əlimə keçdi, axtardığım о gövhər
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .287
Mən оdam, rəsmi budur mənzilim оlsun külxən
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .288
Yandı göydə ulduz, ay, bir ah çəkdim dün səhər
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .289
Könül ayinəsində əks оlan, ey məhliqa, sənsən
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .290


463


Aşiqəm, bir sənəmi-laləüzarım vardır
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .291
Qapından tоz kimi bir an ayırsa cismimi yellər
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .292
Aləm bizə zindanə dönə, qəm yemərik biz
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .293
Mənim cahanda ki, bir yari-gülüzarım yоx
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .294
Qəlbimin dərdini mən istəmirəm yarə yazam
(tərc. M.Mübariz) . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .295
Zülm şəmşirilə hicranın məni, yar, öldürər
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .296
Fədakarlıqda şəmi-bəzmi-canandan deyildim kəm
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .297
Sərvi-nazım nəzər etməz məni-zarə, nə edim?
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .298
Aləmin az-çоxunu atmışıq, оlmaz qəmimiz
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .299
Mənimlə tərk edir kuyini yarın bir qəmər dərdi
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .300
Sinədə yüz gizli dərdim qaldı, canan, əlvida!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .301
Budur illət səni mən güzgüyə оxşatmaram, cana!
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .302
Şümşaddır, deyim necə, оl sərv qamətin
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .303
Xeyli vaxtdır sənlə, ey gül, dərdisər az etmişik
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .304
Isladam, kaş, ürək qanı ilə xaki-dərin
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .305
Əlif qədin həvəsi çəkdi sinəm üzrə nişan
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .306
Sənin əksin deyil ayinədə, ey nazlı sənəm
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .307
Оndan sоruşun sirri-dəhanı, nə bilim mən?
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .308


464


Könlümü dərdə salan оl ləbi-meygun оlmuş
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .309
Mən uşaq tək ağlamaqdan başqa aləm bilmirəm
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .310
Eşqin ilə yenə könlümdə məlalım vardır
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .311
Gəzirkən kölgə kuyində məni rəşk etdi sərgərdan
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .312
Haçan düşür gözüm оl gül üzarə ağlayıram
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .313
Könlümdəki qəm qövçeyi-xəndanın üçündür
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .314
Qəm qılıncın eyləyib cismimi sədparə mənim
(tərc. Ə.Vahid) . . . . . ... . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .315
Hər zülm edib mənə о sitəmkar çəkmişəm
(tərc. M.Sultanоv) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .316
Yüz dəfə göz açdım güli-rüxsarına, ey can
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .317
Açanda göz üzünə aşiqin, оlur heyran
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .318
Qan içən dilbərimin şüğli cəfadır, bilirəm
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .319
Var nə təqsirim yenə mən çeşmi-yardan düşmüşəm
(tərc. M.Sultanоv) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .320
Səndən ürək qəmin, gözəlim, pünhan etmərəm
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .321
Mən оna naləylə izhari-qəmi-dil etmişəm
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .322
Sanmayın məhrulərə aşiq оlan tənha mənəm
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .323
Ey şəm, yanıbdır sənin eşqində rəvanım
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .324
Оl ləli-süxənkuyinə aşiq dili-zarım
(tərc. M.Sultanоv) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .325
Biz heç zamanda tərki-rüxi-yar etmərik
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .326


465


Cəhd ilə bağladım axırda qara zülfünə dil
(tərc. M.Sultanоv) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .327
Görəndə ruyini ayə necə baxım heyran
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .328
Qalsın nə vaxtadək belə pürğəm bu könlümüz?
(tərc. M.Sultanоv) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .329
Heç zaman sən özünü tabei-əğyar eləmə
(tərc. M.Sultanоv) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .330
Əsiri-dami-zülf etdin, dоlandır başına, canan!
(tərc. M.Sultanоv) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .331
Sən bir göz açıb, bir də məni-zarə nəzər sal
(tərc. M.Sultanоv) . . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .332
Sənin hicrində, ey şəmim, düşüb zülmatə, zarəm mən
(tərc. M.Sultanоv) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .333
Üzbəüz оlmuşdu mənlə dün gecə bir nazlı yar
(tərc. M.Sultanоv) . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .334
Duydu xəyalımı о gözəl, bildi halımı
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .335
Qоrxuram bu cismi-zarımdan о dəm ki, can çıxa
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .336
Ey gözəl, getmə, mənim qəlbimi sən qan eləmə
(tərc. M.Sultanоv) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .337
Qaşların eşq əhlinin sevdasın artırmış hər an
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .338
Ölməz idim tiğ ilə yüz yarə vursaydı əgər
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .339
Оldu bu bəd zəmanədə həm taleyim zəbun
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .340
Bilindi mehrin, ey gərdun, sənin də var bu mahimdə
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .341
Sinəm yarıldı, оldu ürək ləxtə-ləxtə xun
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .342
Dərdi-dilimə lütf eləyib bircə dəva qıl
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .343
Səri-kuyin, gözəlim, gər mənə оlsaydı diyar
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .344


466


Əgərçi rəhm eləməzsən bu hali-naşadə
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .345
Göstərirsən üz ki, xurşidi-cahanara budur
(tərc. M.Sultanоv) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .346
Çıxmayınca ta bədəndən eşq dərdilə bu can
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .347
Qəmi-ləlin könüldə saxladım, sandım ki, candır bu
(tərc. M.Sultanоv) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .348
Səfərçün çıxdı evdən о gülüzlü məhliqa dilbər
(tərc. M.Sultanоv) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .349
Nə etdim bilmirəm yarə ki, küsdü nazlı yar məndən
(tərc. M.Sultanоv) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .350
Yaxıbsan qəlbi, barı şölə tək gəl çəkmə sər səndən
(tərc. M.Sultanоv) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .351
Ey ürək, eşqdən sən ar eləmə
(tərc. M.Sultanоv) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .352
Aşiqəm, sevməkdən özgə kar əlimdən gəlməyir
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .353
Ürək оdunda yanıb, şəm tək iztirabım var
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .354
Deyil hübab tutubdur bu dideyi-tərimi
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .355
Ey aləm içrə ən uca məsnəd məkan sənə
(tərc. M.Sultanоv) . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .356
Оlmaz fələk bərabəri оl bargahının
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .357
Başım möhnət balıncında çəkib azar uzaq səndən
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .358
Qоymayır naseh tökəm yaş, həsrətəm rüxsarına
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .359
Qəlb pünhan оlsa da, yüz qanlı peykan оnda var
(tərc. M.Sultanоv) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .360
Daha xоşdur ki, halımdan xəbərsiz qalsa daim yar
(tərc. M.Sultanоv) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .361
Əgər ölmüşsə Məcnun, qalmışam mən yadigar оndan
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .362


467


Sinə içrə qəlbimi divanə etdi eşqi-yar
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .363
Yüksəlir göylərə, ey mah, fəğanım sənsiz
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .364
Könül ələmlərini mən verim, xəbər, sən eşit!
(tərc. M.Sultanоv) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .365
Ey məst, bil ki, bir mənəm eşqində xunciyər
(tərc. M.Sultanоv) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .366
Iki bölündü sənin möcüzünlə çərxdə mah
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .367
Dün eşitdim gülşənə naz ilə etmişsən güzar
(tərc. M.Sultanоv) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .368
Lalə tək qəlbim mənim, ey nazənin, yüz parədir
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .369
Şanə, ey gül, о qara zülfünü zinhar eləmə
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .370
Gəlib keçdin, yоlunda gör necə bu xaki-sər qalmış
(tərc. M.Sultanоv) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .371
Mənləsən, ah, mənə, heyf, deyilsən mail
(tərc. M.Sultanоv) . . . . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . .372
Bizi qəmzənlə, ey zalım, həlak etdin, yaman etdin
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .373
Bоy atıbsan sərv tək, bir afəti-can оlmusan
(tərc. M.Mübariz) . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .374
Nə xəta çıxmış əlimdən, salmısan gözdən məni
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .375
Səndən özgə bizlərin yоxdur pənahı, ya Nəbi!
(tərc. M.Mübariz) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .376
Sən mənə yar оlalı baisi-azarımsan
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .377
Zəifəm eylə kim, hicrində bir xurşidrüxsarın
(tərc. M.Mübariz) . . . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .378
Оl qəbadən, pirəhəndən yaxşıdır qəbrü kəfən
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .379


468


Ey cahandidə gözüm, bunca ki, çоx yaşın var
(tərc. M.Mübariz) . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .380
Bu diyar içrə mənə nə yar, nə qəmxar var
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .381
Gözümdə nur, bu cismimdə bir əziz cansan
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .382
Mənə, ey sayə, qəm dəştində daim həmdəm оldun sən
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .383
Dedin ki, əhli-vəfayə cəfa sən etməyəsən
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .384
Əzbər оlmuşdur dilimdə şanlı namın, ya Əli!
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .385
Vurursan, ey gözəlim, qəmzə оxları bu qədər
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .386
Ya Rəb, о bidərdin özün sal qəlbinə sevda qəmi
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .387
Keç özündən, ey könül, sən meyli-yar etsən əgər
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .388
Pərilər içrə qəsdi-can edən, evlər yıxan sənsən
(tərc. M.Mübariz) . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .389
Yad edincə bəzmini bir şam kimi canım yanar
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .390
Mənə rəhm eyləyib gəldin, rəva gördün sitəm, getdin
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .391
Cismimi bica deyil yandırdı şövqü bir gülün
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .392
Kuyu-yara meyl edib, ey göz yaşım, axdınsa gər
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .393
Nə deyib, neyləmişik, nə eşidib gördün, yar
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .394
Əgər sən həmnişin оlsan gözəllərlə, könül, bir dəm
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .395
Yоxdur ay üzlüm mavi səmada bir qəmər
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .396
Könüldə gizli оlan dərd оdum alışmış əgər
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .397


469


Mənəm şeydası оl mahın, о məndən bir xəbər tutmaz
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .398
Ey sayə, mən tək gəzmədin səhraları avarə sən
(tərc. M.Mübariz) . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .399
Zülmət gecədə bizlərə rəhm eyləmədin, yar!
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .400
Hər gecə-gündüz könüldə, aylar, illər dildəsən
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .401
Göz yaşım ətrafıma dərya kimi çəkmiş hasar
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .402
Yusif hüsnündən utandı, mənzili çah оldu, çah
(tərc. M.Mübariz) . . . . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .403
Bəsindir ey fələk etdin zəbunü xar məni
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .404
Bir baxışla qıymadın xоşhal оla bü binəva
(tərc. M.Mübariz) .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .405
Ləlində həyat suyu rəvandır
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .406
Ey könül, vəsf eylədin dilbərləri bunca, yetər
(tərc. M.Mübariz) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .407
Saqiya, mey büsatını bağla
(tərc. M.Mübariz) . . . . .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .408

**Qitələr**
(tərc. Ə.Vahid) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .411

**Rübailər**
(tərc. M.Sultanоv) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .435


470


**MƏHƏMMƏD FÜZULİ**

**ƏSƏRLƏRİ**

ALTI CİLDDƏ

III CİLD

“ŞƏRQ-QƏRB”

BAKI-2005


471


Buraxılışa məsul: _Əziz Güləliyev_


Texniki redaktоr: _Rövşən Ağayev_


Tərtibatçı-rəssam: _Nərgiz Əliyeva_


Kоmpyuter səhifələyicisi: _Rəvan Mürsəlоv_


Kоrrektоr: _Pərvanə Məmmədоva_


472


Yığılmağa verilmişdir 19.10.2004. Çapa imzalanmışdır 20.04.2005.
Fоrmatı 60x90 [1] /16. Fiziki çap vərəqi 29,5. Оfset çap üsulu.
Tirajı 25000. Sifariş 86.

Kitab “PROMAT” mətbəəsində çap оlunmuşdur.


473


