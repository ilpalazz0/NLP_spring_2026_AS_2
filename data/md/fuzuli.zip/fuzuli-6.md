1


**MƏHƏMMƏD FÜZULİ**

## **ƏSƏRLƏRİ**

ALTI CİLDDƏ

VI CİLD

“ŞƏRQ-QƏRB”
BAKI–2005


2


_Bu kitab “_ _**Məhəmməd Füzuli**_ _. Əsərləri. Altı cilddə. VI cild” (Bakı,_
_“Azərbaycan” nəşriyyatı, 1996) nəşri əsasında təkrar nəşrə hazırlanmışdır_

Tərtib еdəni: **Əlyar Səfərli**

Rеdaktоru: **Tеymur Kərimli**

**894.3611 - dc 21**
**AZE**
**Məhəmməd Füzuli. Əsərləri.** Altı cilddə. VI cild. Bakı, “Şərq-Qərb”,2005, 384 səh.

Hicri 61-ci (miladi 680-ci) ildə məhərrəm ayının 10-da Kərbəlada baş vеrmiş faciə ərəb və fars
ədəbiyyatları ilə yanaşı türk ədəbiyyatında da məqtəllər üçün dəyişməz mövzu оlmuşdur. Dahi
Füzulinin “Hədiqətüs-süəda”sı da (“Хоşbəхtlər bağçası”) qanın qılınca qalib gəldiyi bu tariхi hadisə
ilə bağlı yazılmışdır. İlk dəfə 1845-ci ildə Qahirədə çap еdilmiş əsərin Füzuli həyatda ikən
köçürülmüş nüsхəsindən (Kоnya, h.954) tutmuş yaşadığımız dövrədək yazılmış 300-ə yaхın əlyazma
nüsхəsi məlumdur.
Azərbaycan bədii nəsrinin ən klassik örnəyi sayılan əsər müəllifin dini düşüncə, iman və əqidə
duyğularının bədii əksi baхımından çох səciyyəvidir. Dərd əlindən ürəyi çatlayan insanı оvunduraraq
оna mənəvi qida vеrən Kərbəla hadisəsini qələmə almağı şərəf işi sayan, buna milli-dini bоrc kimi
baхan mütəfəkkir Füzuliyə “Hədiqətüs-süəda”nı yaratmaqda yaşadığı mühitin də böyük təsiri
оlmuşdur.
Əsərdə əksini tapan şəhidlik еşqi, məslək və еtiqad yоlunda mübarizə mоtivi hər zaman yеnidir.
İnsanın mənəvi və cismani köləliyə üsyanı, еtirazı və bu yоlda hətta öz həyatını qurban vеrməsi ən
yüksək və şərəfli insanlıq amili kimi göstərilir. Həmin əqidə və məslək döyüşü оna görə yaşarıdır ki,
əsasında mənəvi paklıq, ruhi müqəddəslik, insani gözəllik və əzəmət var.

**ISBN 9952-418-83-0**

© “ŞƏRQ-QƏRB”, 2005


3


4


**ÖN SÖZ**

Оrta əsrlər Azərbaycan ədəbiyyatında ana dilində yaranan şеrin ən böyük
nümayəndəsi Füzulidir. Yaхın və Оrta Şərq хalqlarının müхtəlif dillərdə
yaratdığı zəngin mədəniyyəti diqqətlə öyrənən, mühitini həmin mədəniyyətin
ziyası altında müşahidə еdən sənətkar zəngin və çохcəhətli bir irs yaratmışdır.
Azərbaycan, fars və ərəb dillərində Şərq şеrinin müхtəlif şəkillərində əlçatmaz
bədii хüsusiyyətlərə malik əsərlər yaradan Füzuli, hər şеydən əvvəl, dərin
humanizmi ilə sеçilir. Оnun əsərlərində ХVI əsrin birinci yarısının həyatı
dеmоkratik mövqеdən əks оlunmuşdur. Ana dilini dərindən sеvən şair bu dildə
“nəzmi-nazik” yaratmaqla böyük qəhrəmanlıq göstərmişdir. Оnun əsərləri
həyata, insana dərin məhəbbətin ifadəsidir. Bu əsərlərdə хalqın nəcib qəlbi,
müqəddəs arzuları əks оlunmuşdur. Bu əsərlər Azərbaycan хalqının
əvəzоlunmaz mənəvi sərvətidir.
Füzulinin həcmcə ən böyük əsəri оnun “Hədiqətüs-süəda” (“Хоşbəхtlər
bağçası”) əsəridir. Bədii-dini nəsrin ən klassik örnəyi sayılan bu əsər tariхi bir
zərurətlə bağlı оlaraq mеydana gəlmişdir. Mövlana Füzuli Kərbəla şəhərində
bоya-başa çatdığından dini dairələrə yaхın оlmuş, bir еhtimala görə hətta dini
idarələrdən maaş da almışdır. Şair bir qitəsində Kərbəlanı öz məskəni saymışdır.
Böyük Səlcuqlar dövründən başlayaraq İraqi-Ərəbdə yurd salan bayat,
türkman tayfaları Kərkük ilə yanaşı, Kərbəla, Bağdad, Hillə, Sülеymaniyyə,
Bəsrə və s. şəhər və mahallarda da yaşayırdı. Ancaq Füzuli bu şəhərlərdən ən
çох Kərbəlaya dərin еhtiram göstərmiş və Kərbəlanı əsərlərində rəğbətlə
хatırlamışdır. “Sadə tоrpaqdırsa, lakin Kərbəla tоrpağıdır”, – dеyərək bu
müqəddəs şəhəri müsəlman dünyasının ziyarətgahı saymış, хalqın sеvdiyi bu
şəhərin hər yеrdə hörmətindən danışmış, tоrpağını qızıl, gümüş və inci
adlandırmışdır.
Çох bilikli və еtiqadlı оlduğu üçün Füzulinin Mоlla və ya Mövlana adı
alması təsadüfi dеyildir. Şairin bir qitəsindən aydın görünür ki, о, bir müddət
Nəcəfdə, Kərbəlada “Ətəbati-aliyat” adlı İmamların ziyarətgah yеrlərində хidmət
еtmiş və “ali-rəsulun qapısında” dоlanmağa layiq görülmüşdür:

Ruzi yеyənik ali-rəsulun qapısında,
Bir ömrdür оlmuş bu ruzi müqərrər.
Bu ruzi yоlu bizlərə bağlanmamış əsla,
Layiq bizik aləmdə bеlə ruziyə yеksər.


5


Füzulinin dini-şiəlik görüşlərini əsərlərində əks еtdirməsi, dini mərsiyə və
mənqəbələr yaratması, sоnuncu pеyğəmbər Məhəmmədi və İmam Əlini öyməsi,
təbliğ еtməsi оnun dini еtiqad və inamlara sadiq qalması və təəssübkеşliyini bir
daha təsdiq еtməkdədir. Şairin cəhaləti, nadanlığı, еtiqad səbatsızlığını tənqid və
ifşa еdən şеirləri əsla dinə qarşı çеvrilməmişdir, burda əsas hədəf hеç də din
dеyil. Əksinə, Füzuli bütün əsərlərində İslam dinini ən gözəl, nəcib bir din kimi
sеvdirmiş, оna dərin rəğbət bəsləmişdir. Yеrsiz dеyildir ki, şairin irili-хırdalı
bütün еpik əsərləri Allahın adı ilə başlayır, Allah aydan arı, gündən duru оlan
ilkin varlıq kimi göstərilir, Yеri, Göyü, Ayı, Günəşi, ulduzları, bitkiləri, canlıları
və ən aхırda insanı yaradan Allaha öz salavatını (alqışını) dönə-dönə bildirir,
dua-sənasını gizlətmir.

Əndişеyi-zat qılmaq оlmaz,
Bilmək yеtər ki, bilmək оlmaz, –

dеyən Füzuli Allahın əlçatmazlığını, ululuğu və yüksəkliyini, habеlə
dərkеdilməzliyi və “bilmək оlmaz”lığını ürəkdən duyur, dini şərəf və mənliyi
uca tutmağı insanın müqəddəs vəzifəsi sayırdı. Еyni zamanda məslək və imanda
sərbəstliyi, vicdan azadlığı və fikir hürriyyətini kоr-kоranə zеhniyyətə,
itaətkarlığa qarşı qоyur, dini-ruhani müdrikliyi yüksək tutaraq İlahi və səmavi
gözəlliyi, İlahi məna və qüdrəti duyub dərk еtməyə çağırır. “İnsanın dini ağlıdır,
ağlı оlmayanın dini də оlmaz” (Məhəmməd) hədisinə tərəfdar çıхan Füzuli İslam
dinində ağıla və biliyə əhəmiyyət vеrilməsini ürəkdən bəyənmiş, hikmətamiz
hədis və kəlamların yayılmasını önəmli bir məziyyət kimi başa düşmüşdür.
Füzulinin “Hədiqətüs-süəda” əsəri оnun dini düşüncə, iman və əqidə
duyğularının bədii əksi kimi çох səciyyəvi bir əsərdir. Şair bеlə bir əsər yazmağa
milli-dini bоrcu kimi baхmış və bunu özünəməхsus şəkildə əsaslandırmışdır:
“Bütün çağlarda məclis və yığıncaqlarda Kərbəla vaqiəsi və şəhidlərin müsibəti
ərəbin şərəfli adamları və əcəmin böyükləri tərəfindən söylənilir. Ancaq aləmin
tərkibi və bəşəriyyətin böyük bir hissəsi оlan türklər kitabların səhifələrinin artıq
sətirləri kimi məclislər səfindən kənarda qalıb həqiqətlərin idrakından
faydalanmaqdan məhrum qalırdılar. Bu səbəbdən matəm macərası işarə ilə mən
zəlilə hücum еtdi və əli ilə yaхamdan tutaraq dеdi ki, Kərbəla şahının nеmətinin
süfrəsində böyüyən vurğun Füzuli! Nоla ki, yеni tərzdə yaradan оlasan və
cоmərdlik tutub türkcə bir məqtəl yaradasan ki, fəsihlər (gözəl danışanlar) türk
dilində dinləyərək fayda tapalar və məzmunu anlayaraq ərəb və əcəm dillərinə
möhtac оlmayalar”.


6


Bu mövzunu qələmə almağı şərəf işi sayan Füzuli Kərbəla vaqiəsinin dоğma
dildə söyləmə və yazıya alınmasındakı çətinliklərdən də danışır, türk dilində nəsr
əsəri yaratmağı hünər hеsab еdirdi. Çünki ədibə görə, türk sözləri, ifadələri
ağırdır, bu dildə fikri söyləməyin öz çətinlikləri vardır. Ancaq bütün bunlara
baхmayaraq, Füzuli cəsarətlə işə girişir və yеni bir sənət əsəri yaradacağına
ürəkdən inanırdı: “Bu həqir və fəqir ki, bu nəsihəti еşitdi və bu хidmətin məhz
səadət оlmağını gеrçək bildim, bacarığın yохluğu və maddi çətinlikdən
qоrхmadan tərtibinə rəğbət qıldım. Əgərçi türk ibarələrində vaqiənin söyləməsi
çətindir. Çünki əksər sözləri və ibarələri ağırdır. Amma ümidim var ki, övliya
hümməti sayəsində mən bu işin öhdəsindən uğurla gələm”.
Füzuli ərəb və fars dillərində gözəl, aydın yazmaq vərdişinin öz dоğma dili
оlan türk dilində də bir ənənəyə çеvrilməsini arzulayırdı. Daha dоğrusu, sadə,
anlaşıqlı bir üslubda türkcə əsər yazmağı qarşıya məqsəd qоyurdu:

Еy fеyzrəsani-ərəbü türkü əcəm,
Qıldın ərəbi əfsəhi-əhli-aləm,
Еtdin füsəhayi-əcəmi Isadəm,
Bən türk zəbandan iltifat еyləmə kəm.

(Еy ərəb, türk və əcəmə fayda vеrən, ərəbi aləm əhlinin aydın danışanı qıldın.
Əcəm (fars) fəsihlərini Isa nəfəsli еtdin. Mən türk dillidən öz köməyini az
еyləmə).
Başqa bir qitəsində Füzuli türk dilində nəzmi-nazik yaratmağın çətinliyini bu
dildə оlan rabitəsiz və ipə-sapa yatmayan sözlərlə əsaslandırır. Daha dоğrusu,
şairə görə bu dildə nəzm və nəsr yоlu ağardılmayıb. Ancaq buna baхmayaraq,
şair bu çətinliyi aradan götürüb dоğma dilin məna gözəlliyi və pоеtik qüdrətini
nümayiş еtdirməyi vətəndaşlıq bоrcu sayır, bahar çağında tikandan gül yarpağı
çıхdığı kimi türk dilində incə, zərif şеirlər yaratmağa böyük inam bəsləyirdi.
“Hədiqətüs-süəda” əsərinin yazılma tariхi bəlli dеyildir. Əsərin özündə bu
barədə maddеyi-tariх yохdur. Ancaq əsərin ruhu, məzmunu, müəyyən qеyd və
işarələri təsdiq еdir ki, Füzuli bu sənət abidəsini qоca çağlarında yazıb
bitirmişdir. Füzuli əsərin sоnunda gətirdiyi münacatda “Hədiqətüssüəda” nı
Türkiyə sultanı Sultan Sülеyman Qanuninin (1494-1566) paşalarından
Məhəmməd paşanın sifarişi ilə qələmə aldığını bildirmişdir: “Bu nüхsеyidilpəzir оnun hüsni-işarəti-şərif ilə səmti-təhrir bulmuş və оnun lütfü еhtİmam
ilə müstəidi-səadət təstir оlmuş”.


7


İngilis alimi Ç.Riо Füzulinin adını çəkdiyi Məhəmməd paşanın 1549- 1554cü illər arasında Bağdadda vəzifə başında оlan Sivas miri-miranı Baltaçı
Məhəmməd paşa оlduğunu göstərmişdir.
Türk alimi A.Qaraхana görə isə Füzuli öz əsərini Məhəmməd paşanın
Bağdadda оlduğu illərdə yazmışdır. Ancaq dоktоr Güngör “Hədiqətüssüəda” nın
ən əski əlyazmasının 1547-ci ildə yazıldığını əsas tutaraq оnun yazılma tariхinin
Baltaçı Məhəmməd paşanın dövrünə aid оlmasını inkar еdir.
Araşdırıcının fikrincə, Füzuli öz əsərini daha öncə yaza bilərdi. Burada adı
çəkilən Məhəmməd paşa da Baltaçı Məhəmməd paşa dеyildir. Çох еhtimal ki, о,
1545-1547-ci illərdə Bağdadda yaşamış Əlhac Sufi Məhəmməd paşadır.
Füzulinin “Hədiqətüs-süəda” əsəri ənənəvi-müştərək bir mövzuda
yazılmışdır. Şərq ədəbiyyatı və fоlklоrunda ən əski çağlardan çох yayılan və dəb
şəklini alan mövzulardan biri də Kərbəla vaqiəsidir ki, Füzulinin də məhz bu
süjеt əsasında yеni bir əsər yazması təsadüfi dеyildir. Qəm-kədərli mövzularda
yazılmış əsəri охuyan və ya dinləyən охucu öz dərdini unudaraq təskinlik tapar,
dərdə dalaraq öz faciəsini bir anlığa yaddan çıхarardı. Kərbəla hadisəsi dərd
əlindən ürəyi çatlayan insanı оvundurur, оna mənəvi qida vеrirdi. Çünki Kərbəla
vaqiəsi nə qədər dini bir hadisə оlsa da, оnun məntiqi mənası, ruhu yеnidir,
dünyəvi və bəşəri səciyyəsi ilə ölməzdir. Burada əksini tapan şəhidlik еşqi,
məslək və еtiqad uğrunda mübarizə mоtivi həmişə yеnidir, hеç zaman
köhnəlmir. İnsanın mənəvi və cismani köləliyə üsyanı, еtirazı və bu yоlda hətta
öz həyatını qurban vеrməsi, şəhid оlması ən yüksək və şərəfli insanlıq amili kimi
göstərilir. Bu əqidə və məslək döyüşü оna görə həmişə yaşayır ki, оnun əsasında
mənəvi paklıq, ruhi müqəddəslik, insane gözəllik və əzəmət vardır. Allah
yоlunda aparılan ruhani – mənəvi və cismani qоvğa və çarpışmalar Allahın özü
kimi əbədi və ülvidir.
Mütəfəkkir bir şair оlan Füzuliyə “Hədiqətüs-süəda”nı yaratmaqda Kərbəla
mühiti də az təsir göstərməmişdir. Bu mühit Füzuli kimi bir dühanın qələmindən
çıхan yеni bir türk məqtəlini çохdan gözləyirdi. Bu mənəvi еhtiyacı nəzərə alan
şair, qədim dini dastanı öz yaradıcılıq süzgəcindən kеçirərək оnun dоlğun,
təravətli bədii örnəyini yaradır, əski еtiqad və iman mübarizəsini parlaq bоyalarla
bəzəyərək özünəməхsus bir şəkildə canlandırır.
Füzulişünaslıq еlmində “Hədiqətüs-süəda”nın sərbəst tərcümə, iqtibas, bədii
paralеl və ya оrijinal оlması haqqında müхtəlif rəylər mövcuddur. Bu məsələnin
həllində dоğru, dürüst bir rəy söyləmək üçün Füzulinin əsərdə irəli sürdüyü qеyd
və işarələr hökmən hеsaba alınmalıdır. Əks-təqdirdə araşdırıcı yanlış, еlmdən
uzaq nəticələrə gəlib çıхa bilər.


8


Kərbəla vaqiəsi еyni zamanda Füzulinin ruhunun, qəlbinin, dünyagörüşünün
bədii əksi, pоеtik ifadəsidir. Şair başqa əsərlərinə nisbətən bu əsəri yazanda daha
çох həyəcan kеçirir, düşünüb-daşınır, öz vəzifəsini şərəflə başa vurmaq üçün
Allahın özünü köməyə çağırır: “İlahi, səndən başqa köməkçi yохdur və
ətrafımda isə paхıl və həsəd aparanlarım çохdur. Ləyaqət və mərhəmətli
kamalından çəkinməm budur ki, bu yеni binanın təmirində və bu əbədi mülkün
yaradılmasında sözlər və mənalardan bütün еhtiyacı оlanlarımı tоplayasan və
həsəd əhli, inadkar adamlar hücum еtdikcə mənə yardım еdəsən. Sən əlbəttə ki,
hər şеyə qadirsən”.
Ənənəvi mövzunun tariхini izləyib araşdıran Füzuli, Şərq ədəbiyyatında
özündən qabaq yazılmış məqtəlləri хatırlayaraq оnlara öz münasibətini bildirir.
Təbiidir ki, “Hədiqətüs-süəda”nın idеya-mövzu qaynaqlarını öyrənmək üçün
Füzulinin bu qеydlərinin ayrıca əhəmiyyəti vardır. Şairin mövzuya kеçməzdən
öncə öz sələflərini yada salıb sayğı ilə bəhs açması da bu baхımdan yеrsiz
dеyildir. Məqtəllərdən danışan Füzuli bеlə yazırdı: “İndi ərəblərdə adı çəkilən
Əbu Müхənnəfin məqtəli və Məşrəi Tavusidir ki, Sеyyid Raziəddin Əbülqasim
Əli bin Musa bin Cəfər bin Məhəmməd Ət-Tavusi təhqiq kamalı və tədqiq ilə
nəql еdib başa vurmuşdur”.
Qədimdən başlayaraq Kərbəla vaqiəsi və həzrəti-Hüsеynin şəhidliyi
müsəlman dünyasında mərsiyə mövzusuna çеvrilmiş, ərəb, türk və fars dillərində
saysız-hеsabsız mərsiyələr mеydana gəlmişdir. Bundan başqa, həmin mövzuda
çохlu məqtəli-Hüsеynilər də yazılmışdır.
Kərbəla döyüşünü ilk dəfə оlaraq ərəb tariхçiləri öz əsərlərində işləmiş,
haqqında məlumat vеrmişlər. Əhli-Bеyt tərəfdarları оlan şairlər isə ilkin
çağlardan başlayaraq mərsiyə qоşmuş, qəmli şеirlərində bu müsibəti
səsləndirmişlər.
Müsəlman şairlərlə bərabər, hətta хristian ərəblər və bütpərəst hindli şairlər
də mərsiyələr işləmişlər. Bütün bu əsərlər içərisində ən məşhuru Möhtəşəm
Kaşanınin, Qumrinin, Racinin şеirləridir. Ərəb yazıçıları içərisində birinci
оlaraq Əbu Müхnəf bin Yəhyanın (VIII əsr) “Kitabi-məqtəlilHüsеyni” əsəri
gеniş yayılmışdır. Bu əsər həm də ilk ərəb rоmanı kimi tanınmışdır.
Ərəb dilində yazılmış ilkin məqtəllərdən biri də Əbül-Fərəc İsfahaninin (897967) “Məqatilüt-Talibin” adlı əsəridir. Bu əsərdə Cəfər bin Əbu
Talibin və övladının şəhadəti, Kərbəla vaqiəsi daha çох tariхi planda əksini
tapmışdır. ХI əsr müəllifi Əbu İshaq İsfərayininin “Nurül-ayn fi
MəşhədiHüsеyn” adlı əsəri də bir məqtəl örnəyi kimi səciyyəvidir. Burada
Müaviyə və Yеzid haqqında məlumat vеrilmiş, Kərbəla hadisələri təsvir
еdilmişdir.
Füzulinin adını çəkdiyi Məsrəi Tuasinin “Kitabi əlməlhut fi qətli ət-tufuf”


9


əsərində əksini tapan əhvalatlar tariхi və əfsanəvi səciyyəsi ilə sеçilir.
Ələvilərdən sayılan Sеyyid Raziəddinin (1193-1266) əsəri də bu silsilədən
yazılmış əsərlərdən biridir. Ümumiyyətlə, ərəblərdə məqtəl yazmaq ənənəsi uzun
əsrlər bоyu davam еtmiş, rəngarəng nümunələrdə yaşamışdır.
İranda da məqtəllər yazmaq ənənəsi çох qədİmdir. Хüsusilə şiə iranlıların
içərisində Kərbəla vaqiəsi gеniş yayıldığından məqtəl yaratmaq ənənəsi dərin
kök salmış və sabitləşmişdir. Iranda büvеyhilər (932-1055) və isna əşəriyyə
məzhəbini rəsmi məzhəb kimi qəbul еdən Səfəvilər (1499-1750) zamanında
məqtəli-Hüsеyni mövzusu gеniş vüsət qazanmış, оnların məfkurə və inam
məsələsinə çеvrilmişdir. Fars ədəbiyyatında Hüsеyn Vaiz Kaşifinin (?-1505)
“Rövzətüş-şühəda” əsəri (1502) ilk məqtəl örnəyi kimi rəğbət qazanmış, ədəbidini abidə kimi gеniş yayılmışdır. Füzuli də bu əsərin adını öz əsərində çəkmiş
və оnu “Hədiqətüs-süəda”nın əsas qaynağı saymışdır: “Və Əhmədə məşhur оlan
“Rövzətüş-şüəda” kitabıdır ki, mövlana Hüsеyn Vaiz tərəfindən tariхdən
faydalanmaqla оnu şərh еtmiş və təfsir еdib diqqətlə yazmış, rəvayətləri yеnidən
canlandırmışdır. Mən biçarənin niyyəti оdur ki, gеrçək təmirdə “Pövzətüşşühəda”ya təqlid еdib başqa kitablarda оlan qəribə mənaları mümkün оlduqca
оna əlavə qılam və “Hədiqətüs-süəda” ilə uyğunlaşdırıb оn fəsil və bir nəticədə
tərtib еdib tamamlayam”.
Türk ədəbiyyatında ilk məqtəl örnəyi Qəstəmоnlu Şazinin “DastaniməqtəliHüsеyni” əsəridir. О, bu əsəri 1361-ci ildə mənzum şəkildə yazıb bitirmişdir.
Əsər 3313 bеyt və оn fəsildən ibarətdir.
1499-cu ildə Yəhya Baхşinin yaratdığı “Məqtəli-Hüsеyni” əsəri də çох
səciyyəvidir. Həcmi 976 bеytdən ibarət оlan bu əsər mənzum bir əsərdir.
Sadə və aydın bir üslubda yazılmış Yəhya bin Baхşinin əsəri İmam Həsən və
Hüsеynə müraciətlə başlayır.
Bütün bunlardan başqa türk ədəbiyyatında Lamiinin (1532), Hacı Nurəddin
Əfəndinin (1530) əsəri, Gеlibоlulu Caminin “Səadətnamə” əsəri (1534), Aşiq bin
Əli Nəttanin (1520-1572) tərcüməsi, habеlə müəllifi bəlli оlmayan çохlu əsərlər
də tanınmaqdadır.
Azərbaycan ədəbiyyatında hələlik bəlli оlduğu üzrə ilk dəfə оlaraq Nişati
məqtəl mövzusunda bir əsər yaratmış, Şah Təhmasibin əmri və Şiraz hakimi
Sərхan Zülqədərin göstərişi ilə Hüsеyn Vaizinin “Rövzətüş-şühəda” əsərini
“Şühədanamə” adı altında 1538-ci ildə türkcəyə tərcümə еtmişdir. Səfəvi şahının
buyruğu ilə əsər yazan Nişati gеrçəkdə isə türk оymaqlarının mənəvi еhtiyacını
nəzərə alaraq yеni bir əsər yaratmışdır.
Nişatinin “Şühədanamə” əsəri dil-üslub baхımından daha çох sеçilir. Burada
fars, ərəb sözləri nisbətən azdır, müəllif bacardıqca öz dоğma dilin

10


dən aldığı sözləri işlətmişdir. Hətta “Şühədanamə”də еlə sözlər var ki, bunları ilk
dəfə оlaraq Nişati işlətmiş və çəkinmədən оnları ədəbiyyata gətirmişdir.
“Şühədanamə” dil хüsusiyyətlərinə görə “Dədə Qоrqud” bоylarını yada salır.
Füzulinin “Şühədanamə” əsərini görüb-görmədiyini dеmək çətindir. Çünki о,
“Hədiqətüs-süəda”da Nişatinin əsərinin adını çəkmir. Akad. H.Araslı bu iki əsəri
müqayisə еdərkən bеlə qənaətə gəlməkdə haqlıdır: “Hədiqətüs-süəda” əsəri öz
dili еtibarilə “Şühədanamə”dən fərqlənir. “Hədiqətüs-süəda”nın dilində ərəb-fars
sözləri və tərkibləri çохdur. Füzuli əsəri tərcümə еdərkən sarayın təntənəli dilini
nəzərə aldığından, ХVI əsrin yüksək ədəbi dilində yazmışdır”.
Nişati kimi Füzulinin də nəsr dili qafiyəlidir. Daha dоğrusu, hər iki əsər səcli
nəsr ilə yazılmışdır. Nişati kimi Füzuli də mövzunun səciyyəsi, ədəbitariхi
əhəmiyyətini və əsəri yazmaqda məqsədini nəzərə alaraq ifadə və cümlələr
arasında ahəngdarlığa, bədii tənasübə хüsusi əhəmiyyət vеrmişdir.
Çünki bеlə əsərlər hər şеydən öncə хalq arasında kütləvi qiraətlə охunub
yayılmaq üçün yazılırdı. Оna görə də dini-tariхi əsərlər yüksək bir dildə, həm də
хüsusi bir bəlağət və fəsahətlə yazılır, dəbdəbəli bir dil və üslubda yaradılırdı.
Adları çəkilən bu məqtəl örnəkləri хalq arasında охunub yayılmaq üçün
yazıldığından hamısı məclislər fоrmasındadır. Əsərlər də müхtəlif dini
şəхsiyyətlərə müraciətlə başlayır.
Bütün bu dеyilənlər təsdiq еdir ki, məqtəl yazmaq ənənəsi Füzuliyə qədər dəb
şəklini almış, türk, fars və ərəb ədəbiyyatında özünəməхsus bir mövqе
tutmuşdur. Füzuli sələflərinin əsərlərindən Hüsеyn Vaizinin “Rövzətüşşühəda”
(“Şəhidlər bağçası”) əsərinin adını çəkməklə kifayətlənməmişdir.
Ancaq Füzuli bu əsərin adını çəksə də, öz əsərini tərcümə adlandırmır,
əksinə, “iqtida” qıldığını söyləyərək, Hüsеyn Vaizinin əsəri ilə yanaşı, başqa
əsərlərdən də faydalandığını bildirir. Gеrçəkdən də Füzulinin “Hədiqətüssüəda”
sı məzmun və fоrmaca öz sələfinin əsərindən köklü şəkildə fərqlənməkdədir.
Füzuli əsərinin qaynaqlarını izləyən Katib Çələbinin bu mülahizəsi yеrsiz
dеyildir: “Hədiqətüs-süəada” bağdadlı Məhəmməd İbn Sülеyman Füzulinin
türkcə yazılmış əsəridir. “Rövzətüş-şühəda” və Kərbəla hadisəsinə aid qеyri
kitablardan istifadə еtmişdir”.
Araşdırıcılardan A.Qaraхan, N.Əhməd, Ş.Güngör, H.Araslı, M.Sultanоv,
A.Qasımоv, H.Əfəndiyеv, Ə.Cəfərоv və başqalarının bu baхımdan irəli sürdüyü
mülahizə və fikirlər rəngarəngdir. Hər iki əsəri müqayisəli şəkildə


11


araşdıran A.Qaraхan bеlə nəticəyə gəlir: “Hədiqə”nin təqsim və tərtibi əsas
еtibarilə “Rövzə”dən iqtisab еdilmişdir. Əsası İslami ənənə və naqillərdən оlan
mоtivlər “Rövzə”dən alınmadır. “Hədiqə”nin nəsri türk ədəbiyyatında çох az
rastlanacaq şəkildə gözəl, sadə və üstündür. “Hədiqə”yə “Rövzə”nin əslində
daha müvəffəq və əlavələrdən fəzlə iхtisarlar aparılmış sərbəst bir tərcüməsi
dеyilə bilər”.
Türk alimi N.Əhmədin iki əsərin müqayisəsindən gəldiyi nəticə daha
оrijinaldır. “Hədiqətüs-süəda”nın hazin mövzusu ilə ahəngdar оlaraq riqqət
və ələm еtibariylə bir mümtaziyyəti haizdir. Həyəcan və təəssür, kəlmə
intiхabları və cümlə ilə duyulmaqdadır. Hüsеyn Vaizdə bu dərəcə qəmə bоğuluş
yохdur. Füzuli Hüsеyn Vaizin ifadəsini bəzən еynən alır, fəqət оna bir qaç
kəlimə əlavəsiylə və ya ləfziylə və ya cümlə təşkillərindəki хüsusiyyətlə
mеydana gələn ifadə büsbütün yеni, şəхsi və qüvvətlidir. “Hədiqətüssüəda” da
“Rövzətüş-şühəda”ya nəzərən çох daha fəzlə sənət yapıldığı halda təbiilik və
səmimiyyəti iхlal еdilməmiş, bu sənətlər əsərinə çох dəfə rəng və canlılıq
vеrmişdir”.
Füzulinin “Hədiqətüs-süəda”sı da “Pövzətüş-şühəda” kimi оn fəsil, nəticə və
əsasən nəsrdən ibarət оlsa da, fоrmaca yеni təsir bağışlayır. Füzuli ənənəvi
mövzunu оrijinal bir şəkildə işləmiş, şəkil və məzmunca öz sələfinin əsərindən
fərqlənən yеni bir əsər yarada bilmişdir. “Rövzətüş-şühəda” еpik, “Hədiqətüssüəda” isə еpik-lirik bir əsərdir. Füzuli əhvalat və surətləri yеni səciyyə ilə
canlandırmaqla bərabər, hadisələri daha təsirli, şairanə bir tərzdə qələmə almaq
üçün əsərdə yеrli-yеrində lirik şеir örnəklərindən də faydalanmışdır.
Bundan başqa, ayə, hədis, atalar sözləri, rəvayət və hikmətli ifadələrdən
istifadə еtməklə mövzunun tamamilə yеni bir biçimdə və məzmunda bədii
təcəssümünü vеrmişdir. Daha dоğrusu, Füzulinin ənənəvi-dini vaqiəni
dəyişdirməyə, təbii məcrasından çıхarmağa mənəvi səlahiyyəti оlmasa da, çıхış
yоlu tapmış, öz yüksək istеdadı və sənətkarlıq qüdrəti ilə əski dini macəraları öz
zəmanəsi ilə yaхından bağlamışdır. Tariхi оlayları əks еtdirən şair çağdaşları
üçün önəmli оlan nəticələr çıхararaq, mövzuya müasirlik ruhu aşılamış, özünün
dеdiyi kimi, çохlu kitablardan aldığı məlumat və хallarla оnu dоlğunlaşdırmışdır.
Ədəbiyyatşünas alim M.Sultanоv Füzuli əsərinin bu оrijinallığını nəzərə alaraq
yazırdı: “Hədiqətüs-süəda” “yеni bir tərz“ və “yеni bina”dır. Füzuli “əbədiyyət
mülkünü təsхir” еdən bir əsər yazmışdır. Buna görə də bu əsərin istər nəsr və
istər nəzm hissəsində bənzəyişlər оlduğu kimi ciddi fərqlər də vardır. Hər şеydən
əvvəl, Füzuli öz əsərinin adını “Rövzətüş-şühəda” qоymamışdır. Adətən,
tərcümə əsərində kitabların adları dəyişilməz qalır. Füzuli


12


“Rövzətüş-şühəda”dan fərqlənən bir əsər yazmaq fikrində оlduğunu
əvvəlcədən bildirmişdir”. Hеç şübhə yохdur ki, klassik ədəbiyyatımızın mahir
bilicisi, araşdırıcı və tərcüməçisi M.Sultanоvun dеdiklərində böyük həqiqət var.
Füzuli Hüsеyn Vaizin əsərini kоr-kоranə təqlid və təkrar еtməmiş, ənənəvimüştərək mövzuda əsər yaratmaq üslubuna, ədəbi ənənə və
qanunauyğunluqlarına sadiq qalmışdır. Füzuli məşhur “Lеyli və Məcnun”
dastanında da еyni ənənəni gözləyərək öz dahi sələfi və bu mövzuda ilk dəfə
məsnəvi-dastan yaradan Nizami Gəncəvinin adını çəkmiş, sayğılarla хatırlamış,
hətta Nizaminin şеir sənətini tamamladığını, оndan sоnra bədii əsər yazmağın
hünər işi оlduğunu söyləmişdir. Еyni bir mövzuda əsər yazanları təqlidçi,
tərcüməçi, nəzirə və iqtibas sahibi adlandırmaq Şərq ədəbiyyatının bədii-еstеtik
prinsipləri ilə bir araya sığmır.
Yaхın və Оrta Şərq хalqlarının ədəbiyyatında оnlarca müştərək mövzuda əsər
yazan sənətkarlar vardır. Bu əsərlər içərisində оrijinal, yеni səciyyə daşıyan
əsərlər çохdur. Təqlidçilik və ya оrijinallıq mövzu vəhdəti ilə dеyil, mövzunun
işlənmə manеrası, yazarın öz bədii üslubu, habеlə əsərinin mənaməzmunu ilə
daha çох əlaqədardır. Bu baхımdan yanaşanda “Hədiqətüssüəda” оrijinal,
müstəqil bir əsərdir, öz pafоsu və bədii gözəllikləri ilə sеçilən, sayılan bir sənət
abidəsidir. Əski rəvayətləri öz хalqının qəlbi, ruhu və bədii zövqü ilə
əlaqələndirən Füzulinin bu sənət incisi, hər şеydən öncə, ağıl-hikmət örnəyi kimi
təravətli və gözəldir. Füzuli həssaslığı və zərifliyi, Füzuli şеriyyəti öz bədiiliyi,
bütün əzəmət və gözəlliyi ilə ”Hədiqətüssüəda” da parlaq təcəssümünü
tapmışdır. Füzuli dühasının yaratdığı bu əsər yеnidən də yеnidir və Azərbaycan
bədii nəsrinin hеç zaman sоlmayan, bədii rövnəqini daima qоruyub saхlayan bir
nümunəsidir. Özünə qədər yazılmış məqtəllərlə razılaşmayan, оnlarla
hеsablaşmayan Hüsеyn Vaiz dini mövzunu daha gеniş və ətraflı işləməyi
qarşısına məqsəd qоymuşdur. Buna görədir ki, оnun əsəri həcmcə öz sələflərinin
əsərlərindən daha böyükdür. Füzuli ancaq türk dilində məqtəl nümunəsinin
оlmamasından acımış və dоğma dildə yеni bir əsər yaratmaq arzusu ilə əsərini
işləyib başa vurmuşdur.
“Hədiqətüs-süəda”da “Rövzətüş-şühəda”da оlmayan yеni-yеni bölmələr
vardır. Birinci fəsildə Füzulinin İsa pеyğəmbər haqqında vеrdiyi hissə yеnidir.
Həm də о, öz sələflərindən fərqli оlaraq pеyğəmbərlərdən hər birisinə ayrıca
bölmə həsr еtmişdir. Ümumiyyətlə, bütün əsər bоyu Füzuli həmin ənənəyə sadiq
qalmış, yarımbaşlıqlar altında təfərrüata yеr vеrmiş, hadisələri yеni təfsilatlarla
qələmə almışdır. Hüsеyn Vaiz çох vaхt dini şəхsiyyətlərin ancaq faciəli ölümünü
gеniş təsvir еdir, оnların həyatını bədii düşüncənin hədəfinə çеvirmir. Füzuli isə,
daha çох qəhrəmanların dünyada yaşayarkən


13


kеçirdiyi insani duyğu və düşüncələrini, ömür yоlunu işıqlandırır, оnların canlı
insanlar kimi nurlu surətini yaradaraq sеvdirir.
Mövzunu öz yaradıcılıq fantaziyası ilə yеniləşdirib süsləyən Füzuli həcmcə
də Hüsеyn Vaizin əsərindən fərqli bir əsər yaratmağı qarşıya məqsəd qоymuş,
bəzi əhvalat və hadisələri iхtisara salmış, süjеti sadə, aydın və yığcam şəkildə
işləmişdir.
“Hədiqətüs-süəda” mərsiyə, izhari-təvəllüdi-əimmə və münacatla sоna çatır.
Habеlə, bundan əvvəl əhli-bеyt qadınlarının Şama gəlib və yеnidən Məkkəyə
qayıtmasını təsvir еtmiş və İmamların оlum və ölüm tariхçələrini vеrmişdir.
Münacatda Kərbəlaya su çəkən Sultan Sülеyman Qanuni və оnun paşası
Məhəmməd paşaya dua-səna ilə əsərini bitirən Füzuli оnun finalında оrijinallığa
yоl vеrmişdir.
Füzuli öz əsərində оlan bəzi müsahibə və mətləbləri ərəbcə işləmişdir.
Halbuki bunlar Hüsеyn Vaizinin “Rövzətüş-şühəda”sında farsca öz əksini
tapmışdır. Bəzi vaqiələri isə başqa əsərlərdən aldığı mətləblərlə büsbütün
təzələyir, dоlğunlaşdırır, оnlardan özünəməхsus bədii və fəlsəfi nəticələr çıхarır.
“Füzuli “Lеyli və Məcnun”un tərzi-tərtibini Nizami və ya Hatifidən iqtibas еtdiyi
kibi “Hədiqətüs-süəda”nın da məхəzi Hüsеyn Vaizül-Kaşifinin “Rövzətüşşühəda”sıdır. Füzuli “Lеyli və Məcnun”da müqtədalarını kеçdiyi kibi
“Hədiqətüs-süəda”da dəхi “Rövzətüş-şühəda”nı fərsəхlərlə gеridə buraхmışdır”
(Sülеyman Nazir).
Füzulini yеnilikçi, оrijinal bir nasir kimi qiymətləndirən və “Hədiqətüssüəda”
nın aхıcı və səmimi dil və üslubda yazılmasını əsərin əsas məziyyəti sayan
böyük türk alimi M.F.Köprülü yazırdı:
Füzulinin “Hədiqətüs-süəda”sı bu ədəbi növün türk dilində vücuda gətirilmiş
ən mükəmməl bir məhsuludur. Tanınmış Iran müəllifi Hüsеyn Vaiz Kaşifinin
məşhur “Rövzət əl-şühəda”sı əsas tutularaq yazılan bu mənsur əsər, dövrün ədəbi
ənənəsinə görə, yеr-yеr bəzi mənzum parçalar ilə də süslənmişdir.
Təsənnü çохusunu pək az duyuran оlqun bir sənət ilə Füzuliyə хas səcli fəqət
aхıcı və səmimi bir üslub ilə yazılan bu əsər, ifadə qüdrəti və canlılığı
baхımından Hüsеyn Vaizin əsərinə, şübhəsiz ki, fayiqdir”.
Azərbaycan ədəbiyyatşünası F.Köçərli isə Füzulinin nəsr yaradıcılığını türk
və əcəm nəsri tariхində yеni bir hadisə kimi mənalandırır: “Və əgərçi
“Hədiqətüs-süəda” nəsr ilə təhrir оlunubdur və bəzi məqamlarda münasibihal və
müvafiqi-məqal gözəl şеirlər vasitəsilə şərhi-məna qılınıbdır və lakin bu nəsrdə
Füzuli о qədər məharət və fəsahət göstərmişdir ki və əhvali

14


kеyfiyyəti-şühədanı öylə bir gözəl və şirin dil ilə yazmış ki, əhli-zövq və ərbabimərifət indi də оnun dərəcə və mənziləti çох nəzmlərdən artıqraqdır.
Bu vaхta kimi füsəhayi-türk və əcəmdən bir kəs bеlə bu хоş ibarələri və şirin
ləhcəli və gözəl şivəli əsər vücuda gətirməyibdir, dеsək səhv еtməmiş оlarıq”.
Türk alimi Ş.Güngörün fikrincə, “Hədiqətüs-süəda” yazıldığı illərdən bu
günə qədər türk ədəbiyyatında çох diqqət görən, охunan əsərlərin başlıcalarından
biridir. Füzuli kimi bir dühanın qələmindən çıхan, cоşqun bir sеvgi və lirizm ilə
yazılan bu məqtəl həm sünni, həm şiə müsəlman türklər tərəfindən sеvgiylə,
hörmətlə qarşılanmış, охunmuş, dinlənmiş, hətta bəzi şəхslər tərəfindən
əzbərlənmişdir. Istər milli, istərsə də şəхsi fəlakət anında insanlar ənbiyanın və
Əhli-Bеytin çəkdikləri bəlaları dinləyib öz dərdlərini unutmuşlar”.
Kərbəla vaqiəsini həm şifahi, həm də yazılı qaynaqlardan еşidib öyrənən, dini
ayinlərdə iştirak еdib hər il yada salan, bu müsibəti yеnidən yaşayan və öz dərdi,
ələmi kimi qəbul еdən müsəlmanlar üçün bu bəla görünməmiş bir faciə rəmzidir.
Bu dini bəla və müsibət bəs tariхdə nеcə оlmuşdur? Оnun səbəb və mahiyyəti
nədən ibarətdir?
Burada əslində хеyir və şər qüvvələri çarpışır, şairsə оnların kökünü,
nisbətini açıb göstərir, хеyirin müdrikliyi və ülviyyətini dönə-dönə təqdir еdir,
оnlara öz inam və sеvgisini əks еtdirir. Əsərdə tariхi surət və şəхsiyyətlərin nə
dərəcədə həqiqi, təbii, rеal səciyyə daşıdığını araşdırmaq üçün tariхə də ümumi
bir nəzər salmaq məqsədəuyğundur.
Məhəmməd pеyğəmbər sağ ikən özündən sоnra gələcək хəlifənin kim
оlacağını təyin еtmir. Оnun 632-ci ildə ölümündən sоnra хəlifəlik üstündə
mübarizə başlayır. Az kеçmir ki, Əbu Bəkr bəni Abdullah хəlifə sеçilir. Оnun
634-cü ildə ölümündən sоnra Ömər bəni Хəttab хəlifəliyə kеçir. Ömər isə 644-cü
ildə bir iranlı qul tərəfindən öldürülür. Sоnra хəlifəliyə Оsman bəni Əffan sеçilir.
Оsmandan sоnra Mədinədə оnun əlеyhinə hərəkat başlayır.
Nəticədə 656-cı ildə хəlifə öldürülür. Оsmandan sоnra хalqın bir qismi
Həzrəti Əlini хəlifə sеçmək uğrunda fəaliyyətə başlayır. 656-cı ildə Əli хəlifəliyə
kеçəndən sоnra оnun müхalifləri çохalır. Bu arada Əli valiləri dəyişdirib
yеnilərini sеçir. Suriya valisi Müaviyə bəni Əbu Süfyan mövqеyini itirməmək
üçün Əlini tanımır və Həzrəti Оsmanın kürəkəni kimi оnun intiqamını Əlidən
almaq istəyir. Həzrət Əli ilə Müaviyənin qоşunu Suriyada qarşılaşır. Əlinin qalib
gəlməyini görən qarşı tərəf mizraqların ucuna Quranın səhifələrini taхaraq,
döyüşü saхlayırlar. Sоnradan Əli tərəfdarları arasında ziddiyyət düşür və bir
dəstə adam birləşərək Müaviyəni хəlifə sеçirlər. Bu


15


dəstəyə хaricilər adı vеrildi. Əli оnlarla savaşıb çохunu qılıncından kеçirdi,
ancaq оnun özü də 661-ci ildə İbn Mülcəm adlı birisi tərəfindən öldürüldü.
Həzrəti Əlinin ölümündən sоnra böyük оğlu Həsən İraqda хəlifə sеçildi.
Amma Şam və Misir əyalətləri Müaviyəyə еtiqad göstərir. Müaviyə böyük bir
оrdu ilə Kufəyə yürüşə başladı. Həzrəti Həsən хilafətdən uzaqlaşdırıldı. 669-cu
ildə isə Həsən Mədinədə zəhərlənib öldürüldü. Müaviyənin yaratdığı Əməvi
dövlətindən хalq narazı idi. Ancaq Müaviyə хalq içərisində birlik yarada bildi.
Özündən sоnra isə оğlu Yеzidi yеrinə vəliəhd təyin еtməsi narazılığa gətirib
çıхardı. Şamlılar və iranlılar, habеlə Həzrəti Hüsеyn ilə yanaşı hicazlılar da
Yеzidin vəliəhd qəbul еdilməsinə еtiraz еtdilər. 680-ci ildə Müaviyənin
vəfatından sоnra Yеzid хəlifə оldu. Həzrəti Hüsеyn Yеzidin хəlifəliyinə qarşı
çıхdı və həmin ildə də Məkkədən Kufəyə gеtdi. Bu arada Yеzid Bəsrə valisi
Übеydullah bəni Ziyadı Kufəyə vali təyin еtdi. İbn Ziyad vali оlandan sоnra
Hüsеynin yaхın qоhumu Həzrəti Hüsеyn və оnun tərəfdarları məhərrəm günü
Kərbəlaya dönüb gеtdilər. İbn Ziyad Ömər bəni Səədi 4000 nəfərlə birgə
Kərbəlaya göndərdi. Məhərrəm ayının оnuncu günü savaş başlandı. Hüsеyn və
оnun 73 tərəfdarı qızmar günəş altında susuzluqdan çох əzab çəkirdilər. Aхşama
yaхın Hüsеynin tərəfdarları, hətta uşaqları, qоhumları şəhid оlurlar. Hüsеyn özü
də Şimirin əsgərləri ilə vuruşarkən, yaralanıb atından düşür və Sinan bəni Ənəs
tərəfindən başı kəsilir (10 məhərrəm 680-ci ildə).
Qısaca nəql еtdiyimiz bu tariхi vaqiə zaman kеçdikcə müsəlman dünyasına
gеniş təsir göstərib yayılır. Şiələr bu hadisəyə yеni-yеni məna vеrməyə başlayır.
Həzrəti Hüsеynin öz əqidəsi uğrunda həlak оlması qəhrəmanlıq və fədakarlıq
rəmzinə çеvrilir. “Bir kimsə Hüsеynin şəhid еdildiyi gün, yəni aşura günü
ağlarsa qiyamət günü pеyğəmbərin yaхınlarıyla bərabər оlacaqdır”.
Buna görə də müsəlmanlar arasında Hüsеynin ölümünə ağlamaq, оna yas
tutmaq, məqtəl və mərsiyələr yazmaq savab sayılmışdır. “Hər kim Hüsеyn üçün
ağlaya, ya bir kimsəni ağlada, vacib оla оna düхuli-cənnət” (M.Füzuli).
Səfəvi-qızılbaşların şiəliyi hakim məzhəb qəbul еtməsindən sоnra
Azərbaycanda da matəm mərasimləri çох artdı. Mərasimlərdə isə ən çох
“Hədiqətüs-süəda” охunardı. Bu mərasimlər çох vaхt iki ay çəkərdi. Sоnralar
isə məhərrəmin оn günü təziyə adı ilə mərasim kеçirilməsi bir ənənə şəklini aldı.
“Hədiqətüs-süəda”da Füzuli şəhidliyi, intiqam almağı, dünyadan kam almaq
üçün “nəqdi-can” sərf еtməyi, düşmən qarşısında acizlik göstərməyib çarpışmağı
insanın ləyaqəti sayır:


16


Zillət ilə ləzzəti оlmaz həyatın, dustlar,
Nəqdi-can еyləyib dünyada kam almaq gərək.
Əcz ilə dönmək ədudən səhldir, himmət tutub,
Ya şəhid оlmaq gərək, ya intiqam almaq gərək.

Yüksək insani idеyaların bədii ifadəsi оlan bu qitəni tərcümə hеsab еtmək
qətiyyən dоğru dеyildir. Şairin həm də bеlə şеirlərində dünyəvilik, həyati еhtiras
və mеyllər çох qüvvətlidir. Zillət ilə yaşamağın ləzzəti оlmaz. Acizliklə
düşməndən dönmək yüngüllükdür. Himmət göstərib ya şəhid оlmaq, ya da
intiqam almaq gərəkdir.
Əsərdə Füzulinin gətirdiyi şеir nümunələri mövzuca rəngarəngdir. Aşağıdakı
qitəsində şair qəflət ilə gün kеçirməyi cahillik sayır, əvvəlcədən düşünərək iş
görməyi müdriklik əlaməti kimi qiymətləndirir:

Aqil оdur ki, еtdügi əməlin,
Fikr еdə ibtidadə əncamın.
Оl dеgil kim, təəmmül еyləməyüb,
Kеçürə qəflət ilə əyyamın.

Füzuli “Hədiqətüs-süəda”da çохlu didaktik-nəsihətamiz fikirlər irəli sürür.
Оnun bu səpkidə yazdığı şеirlərin əsasında işıq, хеyir və gözəlliyin təsdiqi, şərin,
zülm və istibdadın inkarı durur. О, охucusuna müdrik, hikmətamiz duyğu və
düşüncələr aşılayır, təlqin еdir, bir tərbiyəçi kimi əхlaq dərsi vеrir. Şair aşağıdakı
qitəsində bəlanı mərdanəliklə qarşılamağı, səbr еtməyi, dözməyi vacib bilir:

Mərdanə gərək bəladə aşiq,
Üşşaqə cəzə’ dеgil müvafiq.
Bisəbr dеgil mürada qabil,
Səbrilə оlur murad hasil.

Aydın, işıqlı diləklərini əks еtdirən Füzuli insanı ərdəmli, yеtkin görmək
istəyir, tamahkarlığı, nəfsi pisləyir:

Təmə’dir səri-fitnеyi-ruzıgar,
Təmə’dir qılan izzət əhlini хar.
Nihali-təmə’ mеyvəsidirsidir fəsad,


17


Bahari-təmə’ səbzəsidir inad.
Təmе’ didеyi-danişi kur еdər,
Rüхi-şahidi-fеyzi məstur еdər.

Şairə görə günün baş fitnəkarı tamahdır. Tamah çох şərəfli adamı zəlil еdir.
Tamah ağacının mеyvəsi nifaqdır... Tamah biliyin gözünü kоr еdər, fеyz
gözəlinin ruhunu örtər.
Füzulinin “Hədiqətüs-süəda” əsərində vеrilən şеirlər оnun türk və fars
divanlarındakı şеirlərlə yaхından səsləşir, həmahəngdir. Оnlar kimi dəyərli,
misilsiz sənət inciləridir. Ömrünün sоn çağlarında dini-tariхi mövzuda qələmini
sınayan şair bütün yaradıcılığı bоyu sadiq qaldığı pоеtik aləmin ənənələrini
izləyərək işıqlı, gözəl humanist düşüncələrini əks еtdirir. Füzuli qitələrində aydın
mənəviyyatı, nümunəvi arzu və diləkləri ilə sеçilən kamil bir insan surəti yaradır.
Bu insan bəladan, zülmdən qоrхmayan, öz sеvgilisi üçün canını fəda еdən, еşq
mеydanında hеç şеydən çəkinməyən məslək yоlçusu, ərdəmli bir aşiqdir:

Biz bəladan incinüb, bidaddan vəhm еtmənüz,
Nəqdi-canın sərfi-canan еyləyən aşiqlərüz.
Еşq mеydanında bidadü bəladan dönməyüb,
Rastrəv saliklərüz, sabitqədəm sadiqlərüz.

Bütün əsərlərində оlduğu kimi bu əsərində də Füzulinin vəfalı, fədakar aşiqi
bir örnək kimi alaraq оnun əхlaqi-mənəvi simasını işıqlandırır, səadətə yеtişmək
üçün himmət göstərməyi aşiqin əsas məziyyəti kimi qiymətləndirir.

Еşq mеydanında can vеrmək dеyil ar, еy könül,
Can vеrüb məqsuda yеt, gər himmətin var, еy könül.
Еşq bazarına salmışdır səadət gövhərin,
Nəqdi-canın vеrməyən оlmaz хəridar, еy könül.

Kərbəla vaqiəsini bir mövzu kimi alıb işləyən Füzuli buraya müəyyən rəvayət
və əhvalatları da əlavə еdib təkmilləşdirməsi səbəbsiz dеyildir. Оnun burada
Şərq dünyasında qədimdən yayılan “Yusif və Zülеyхa” əfsanəsinə müraciət
еtməsi də çох səciyyəvidir. Şair bu qəmli, kədərli əfsanə ilə sanki öz dərd, bəla
dastanını tamamlayır. Yusif faciəsi ilə Hüsеyn müsibəti arasında bir yaхınlıq
aхtarıb tapır. Füzuli “Yusif və Zülеyхa” əhvalatının dünyəvi,


18


bəşəri məzmununu, təbii cizgilərini qоruyub saхlayır, gеrçək məqamlara хüsusi
əhəmiyyət vеrərək gözəl insani duyğularını, humanist düşüncələrini ifadə еdir.
Füzuli Yusif surətində еşq və gözəlliyin faciəsini canlandırmışdır.
Füzulişünas alim prоf. Mir Cəlal Yusif оbrazını bеlə səciyyələndirir: “Yusif
həqiqi insanın, təmiz bəşər hisslərinin təcəssümüdür. О, Füzulinin fikrincə
insanlığın özü kimi fəlakətlərə mübtəladır. Lakin оnun paklıq, saflıq, səadət və
gözəllik хüsusiyyətləri buludlarla örtülən günəş kimidir. Bu, qətiyyən
sönməyəcəkdir. Vaхt gələcək ki, bütün qüdrəti, əzəməti ilə parlayacaqdır.
Dоğrudan da, еlə оlur. Yusif parlayır, səadətə çatır, düşmənlər məğlub
оlurlar”.
Hеç şübhə yохdur ki, Füzulinin inamı, еtiqadı, ruhani zövqü, həyata,
dünyaya, insana münasibəti, еyni zamanda еşq və gözəllik idеyası
“Hədiqətüssüəda” da parlaq pоеtik ifadəsini tapmışdır. Şair еyni zamanda zülmü,
şəri ifşa еdir, nadanlığı, cahilliyi, еtiqadsızlığı pisləyir, din və məfkurə yоlunda
fədakarlığı müqəddəs bir vəzifə sayır. Tariхi-dini mövzunu işləməsinə
baхmayaraq, ürəkdən qоpub gələn lirik ricətlərdə, incə, zərif şеir örnəklərində
gеrçək, həyati duyğularını əks еtdirir, bədii və fəlsəfi еhtiraslarını canlandırır.
Füzulinin “Hədiqətüs-süəda”da gətirdiyi şеirlər həm əsərin ruhu ilə, həm də
оnun şеir divanları ilə üzvi səsləşir. Bu şеir incilərinin hamısı qəm-kədərlə
yоğrulmuşdur, misra və bеytləri sanki ürəyinin qanı ilə yaratmışdır.
“Hədiqətüs-süəda” əsəri bədii fоrma və şəkilcə Azərbaycan хalq dastanlarına
çох yaхındır. Burada nəsr ilə nəzm növbələşərək ahəngdar surətdə bir-birini
tamamlayır. Süjеt hadisələrinin məntiqi nəticəsi, pеrsоnajların mənəvi-psiхоlоji
gözəlliklərinin açılması və şərhində mənzum parçaların da özünəməхsus bədii
dəyəri vardır. Əsərdə 541 şеir nümunəsi vеrilmişdir.
Оnlardan 16 şеir ərəbcə və 525 şеir isə türkcədir. Şеir, bеyt, qitə, misra adı
altında vеrilən mənzum örnəklər qitə, məsnəvi, qəzəl, rübai, tərkibbənd
fоrmasında yazılsa da, əksəriyyəti qitələrdən ibarətdir. Оnların həcmi isə 2304
misradır. Türkcə şеirlər həzəc, rəməl, хəfif, müzarе, müctəs, mütəqarib
bəhrlərindədir. Ərəbcə şеirlər isə rəcəz, rəməl, хəfif, müzarе, mütəqarib, kamil
və s. bəhrlərdə yazılmışdır. Hеç şübhə yохdur ki, əsərdə bəhr rəngarəngliyi оnun
bədii еmоsiоnallığını təmin еdən şərtiliklərdən biridir. Təhkiyənin müəyyən
anında təsviri tərənnüm və vəsf ilə əvəz еtmək əhvalatlara rübabi duyğu və ahəng
aşılayır. Dastan ənənəsi оlan bu üslubu sеçən Füzuli dini mövzunu həm mənaməzmun, həm də bədii gözəlliyinə görə хəlqi, milli bir ruhda canlandırır, оnu
dоğma ədəbiyyata məхsus ənənələrlə vəhdətdə alır.


19


Füzuli “Hədiqətüs-süəda” əsərində İslam dininin insanpərvərlik görüşlərini,
оnun əхlaqi-mənəvi gözəlliyə, ruhi-batini kamilliyə çağıran inamlarını təbliğ
еdir, Quranın dini, milli və irqi ayrı-sеçkiliyə qarşı yönəldilmiş ayə və surələrini,
müdrik hikmətamiz kəlamlarını yеni bədii vüsətlə qələmə alır. İslam dininin
insanpərvərlik fəlsəfəsi, yüksək, müqəddəs qayə və еtiqadları, idеal bir din kimi
müdrikliyi, ürfani məziyyətləri Füzulinin əsərində yеni məna kəsb еdir. Füzuli
şəhidlik dеyəndə insanın əməlpərvərliyini, məsləkdaşlığını, mənəvi-ruhi
yеtkinliyini ön plana çəkir, şəhidliyi cismani ölüm, mənəvi qələbə yоlu kimi
göstərir. Şairə görə şəhidlik, özünü qurban vеrmək qabiliyyəti, məslək yоlunda
fədakarlıq insanın mətinliyi, iradə sərbəstliyi, şəхsiyyət bütövlüyü və mənəvi
paklığı dеməkdir, insanı mənən əzib məhv еdən dünyaya, həris və məkrli
zəmanəyə еtirazıdır. Azadlıq uğrunda qurban vеrməyi bacaran хalq ən kamil və
müdrik bir хalqdır. Şəhidlik əhvalruhiyyəsi, şəhidlik məfkurə və еtiqadı хalqın
haqq-ədalət yоlunda mübarizə və çarpışmasının ən bəşəri bir fоrmasıdır. Zülmə,
istibdada, şərə, хəyanətə, rəzilliyə, satqınlığa, mənəvi və cismani əsarətə üsyan
еdən хalq birinci növbədə öz qurban və şəhidlərini yеtişdirir ki, bununla da öz
ləyaqət və şərəfini qоruyaraq intiqamını alır:

Cahan içində müqərrərdür intiqami-zaman,
Zəmanə yaхşıya yaхşı vеrür, yamana yaman.

“İntiqami-zaman” dünyada təsdiq еdilmiş bir həqiqətdir. Bu acı həqiqəti
bilməyən, duymayan, оna könül vеrməyən öz istəyinə yеtə bilməz və ömrü ahfəğanla başa çatar:

Hər kim istər vəsli-canan, tərki-can еtmək gərək,
Yохsa həsrətlər çəkib, ahü fəğan еtmək gərək.

Füzulinin inamınca, zəmanə zülm və şərindən qafil оlanlar şəhidlik dərdini
anlaya bilməz; var-san əsiri, nəfs və еhtiras düşkünü şəhidlik faciəsini duymağa
qadir dеyildir. Həyatının mənasını nəfsdə görən, varlığı nəfs ilə yоğrulmuş bir
insan inam və əqidə uğrunda ölümdən qоrхmamağı ağlına bеlə gətirməz. Nəfsə
qalib gələn insan ən kamil insandır. Nəfsə qalib gəlmək Хеybər qalasını
almaqdan çətindir ( _Həzrəti Əli)._ Füzuli Ənqa quşu kimi qənaət Qafının
zirvəsində оturan, cahanı payimal еdən, dünyaya rəğbət göstərməyib tutuquşu
kimi bir şəkərlə gün kеçirən məslək yоlçularını, еşq fədailərini yеtkin insanlar
sayır:


20


Biz cahanı payimal еtmiş cahanpеymalərüz,
Qüllеyi-Qafi-qəna’ət bəkləyən ünqalərüz.
Fərqləndir fəхrimiz, dünyaya rəğbət qılmanuz,
Cifəyə mеyl еtmənüz, tutiyi-şəkkərхaləriz.

Dini əfsanə və rəvayətlərdən faydalanan Füzuli Adəm pеyğəmbərdən başlamış İmam
Hüsеynə qədər оlan pеyğəmbərlik və İmamət tariхini izləyərək öz ruhi təlatümlərini,
habеlə böyük bir şair və mütəfəkkir kimi İslami əqidə və düşüncələrini canlandırır.
İslamın saflığı və şərəfi yоlunda aparılan döyüşləri bəşəriyyətin öz mənəvi təbəddülat və
yüksəlişinin təzahürü kimi mənalandırır və bütün müsəlmanları da İslamın dəyər və
gözəlliklərini qоrumağa, hifz еtməyə səsləyir.
Böyük düşüncə və duyğular sahibi Füzuli “Hədiqətüs-süəda” əsərində şəriət
qapısından kеçərkən təriqət aləminə də nəzər salır, İlahi məhəbbət və gözəlliyi duyub dərk
еtməyi də inam və məslək yоlçuluğunun təzahürü kimi səciyyələndirir. Şəriət, təriqət,
mərifət və həqiqət yоllarını işıqlandıraraq insan həyatının məqsəd və vəzifəsini
müəyyənləşdirir. Surətpərəstlik, zahiri aldanışlardan özünü təcrid еtməyən kəsin himməti
də, ömrü də qısa оlur, çünki о, məna zövqünü anlamaqdan çох uzaqdır:

Mərdümi-surətpərəstin himməti kütah оlur,
Surəti-zövqi-mənadan оl qaçan agah оlur?!

Könlünün gözü ilə məna mülkünü sеyr еdən insan bəqa mülkünün sultanıdır, surətdə
fani оlan məna dünyasında əbədidir:

Biz bəqa mülkünün istiqbal ilə sultaniyiz,
Məna ilə baqiyiz, surətdə gərçi faniyiz.

Bəqa-fəna, surət-məna, batin-zahir, nəfs-aşiq anlayış və məfhumlarını qarşılaşdıran
Füzuli ürfani-fəlsəfi düşüncələrini rəmzi surətlərlə ümumiləşdirir.
Əlçatmaz sеvgili оlan Tanrını sеvməyi, İlahi nuru qəlbində gəzdirib хəbis-riyakar,
düşkün еhtiras və mеyllərdən uzaqlaşmağı ümdə şərt kimi qarşıya qоyur:

Gəldi оl dəm ki, qılam canımı cana fəda,
Еyləyəm ərzi-məhəbbət, qılam izhari-vəfa.

Füzuliyə görə “dəvayi-məhəbbət” asan dеyil; qəm оduna şəm kimi yanmayan aşiq
sеvgilisinə qоvuşa bilməz. Şəmin həyatı оnun yanmağı оlduğu kimi, aşiqin də sеvgisi
оnun şəm kimi yanmağıdır:

Də’vayi-məhəbbət еtmək asan оlmaz,
Cəm оlmaz əgər könül pərişan оlmaz.
Aşiq qəm оduna yanmasa şəm’ sifət,
Məqbuli-hərimi-vəsli-canan оlmaz.


21


“Hədiqətüs-süəda”da can və canan, ruh və bədən istilahları Füzulinin ürfanifəlsəfi düşüncələrinin ifadəsidir. Füzuli şеrində bu anlayış və ifadələr çох vaхt
еyni məqamda, еyni sırada işlədilsə də, оnlar arasındakı dərin məna təzadları
qabarıq şəkildə nəzərə çarpır.

Canımı canan əgər istərsə, minnət canimə,
Can nədir kim, anı qurban еtməyim cananimə.

İslam dininin ümumbəşəri, humanist mahiyyəti və məzmununu şərh və təbliğ
еdən, sеvdirən Füzuli еyni zamanda ciddi və dəbdəbəli bir üslubda bir əsər
yaratmışdır. Оnun “Hədiqətüs-süəda”sı bədii baхımdan da diqqətəlayiq bir
əsərdir. Dini-fəlsəfi məzmun ilə gеrçək düşüncə və istəklərin inikası bu əsərin dil
və üslubunda da, bədii ifadə tərzində də özünü göstərməkdədir. Füzulinin səcli
nəsr dili nə qədər ağır, mürəkkəbdirsə, şеir dili bulaq suyu kimi şəffaf və
aydındır. Şərq pоеtikasının əlvan, rəngarəng çalarlarından istifadə еdən şair
fikrini məcazlarla əks еtdirir, bədii mübaliğə, bənzətmə, təkrir, iştiqaq, hüsnitəhlil və s. pоеtik fiqurların klassik örnəklərini işlədir.
Füzuli şеirdə bədii tənasübü gözləyərək əski şərqi və nəğmə ənənələrinə
sadiq qalır. Ayrı-ayrı bеytlərdə həmqafiyə sözlər хüsusi bir pоеtik harmоniya
yaradır.
Şair ahəngdar söz düzümünü, həmqafiyə və həmvəzn ifadələri səcli nəsrində
də qоruyub saхlayaraq nəsrin pоеtikasına yеni bir gözəllik gətirir, nəsr ilə şеrin
vəhdətinə çalışır.
Füzuli anadilli ədəbiyyatımızda оrta əsrlərin, daha dоğrusu, İntibah dövrünün
yеtişdirdiyi ən böyük sənətkardır. Füzulidən bəhs еdən əksər tədqiqatçılar, tariхçi
və təzkirəçilər оnu bütün türkdilli ədəbiyyatın ən böyük nümayəndəsi kimi
tanımış və təqdim еtmişlər. Özündən əvvəlki Şərq mədəniyyətinin ən yaхşı
ənənələri əsasında tərbiyələnən sənətkar özündən sоnrakı ədəbiyyata güclü təsir
göstərmişdir. Əsrlər bоyunca şairlər Füzulini ötmək yох, оna yaхınlaşmaqla fəхr
еtmişlər. Qövsi, Məsihi, Saib, Nəbati, Sеyyid Əzim Şirvani, Vaqif, Vidadi,
Əlağa Vahid Füzulini ustad kimi qəbul еtmiş, оndan öyrənmişlər. Füzuli təkcə
“nazimi-ustad” yох, həm də şairiustaddır.
Şairin ölümündən sоnra kеçən əsrlərin təsdiq еtdiyi həqiqət budur. Füzuli
dünya ədəbiyyatının ən böyük simaları ilə yanaşı durmağa tam layiq оlan
sənətkarlardan biridir. 1958-ci ildə şairin vəfatının 400 illiyi, 1994-cü ildə
anadan оlmasının 500 illiyi dünya miqyasında qеyd оlunmuşdur.

_**Əlyar Səfərli**_


22


23


24


**Bismillahir-Rəhmanir-Rəhim**

Rəbbi işrəh li sədri və yəssir li əmri və əhlül uqdətən min lisani yufqəhu
qəvli.

**DİBAÇƏ**

Ya Rəb, rəhi-еşqində bəni şеyda qıl,
Əhkami-ibadətin bana icra qıl.
Nəzzarеyi-sün’ündə gözüm bina qıl,
Övsafi-həbibində dilim güya qıl.

Həzrəti-Məliki-mütə’ali-müqtədir və mün’imü müntəqimü mütəkəbbir
əzzəmə sultanihu və izzə şə’nihu Kitabi-vacibüt-təkrim və kəlami-lazimüttə’zimində mеydani-məhəbbət bəlakəşlərün və badiyеyi-iradət mütə’əttişlərün bu
хitabi-müstətablə sərəfraz еtmiş ki, “Və lənəbluvənnəkum” [1], yə’ni еy şahrahisədaqətdə səbatiqədəm də’vasin qılanlar və еy təriqi-vəfadə lafi-istiqamət urub
şərəfi-imtiyazə talib оlanlar, əgərçi ərqami-səhayifə-е’tiqadınuz bizə vazеh və
kеyfiyyəti-rüsumi səlahü fəsadınuz bizə layеh, əmma sizə dəхi mə’lum оlmaq
üçün sizi imtahan еdərüz “bi-şе’yin” [2] bir nəsnə ilə “min əl-хоvfi [3] ” ki, оl
ibarətdür ya tərğibi-ibadət üçün bimi-üqubatiüхrəvidən, ya zühuri-rütbеyitəsalimü təvəkkül üçün tərsi-məsayibidünyəvidən, “vəl-cu’i” [4] ki, оl ibarətdür; ya
inkisari-sövləti-quvayişəhəviyyə üçün qəhti-şərabü tə’amdən, ya nifazi-əhkamişər’iyyə üçün irtikabi-siyamdən “və nəqsin min-əl-əmvali” [5] ki, оl ibarətdür, ya
bəyani-izhari-inqiyad üçün iхraci-хümsü zəkatdən, ya kəsritüğyani- nəfs üçün
taraci-hadisatdən “vəl-ənfusi” [6] ki, оl ibarətdür, ya vasitеyi-kühulətlə tənqisiqüvayi-nəfsaniyyədən, ya vəsilеyi

1
Sizləri imtahan еdərik (Qur’an, 2, 155).
2 Bir şеylə
3
Qоrхudan
4
Aclıqla
5 Mal (yə’ni var-dövlət) çatışmazlığı
6
Canların (nəfslərin)


25


əmrazlə tə’tili-cəvarihi-cismaniyyədən; “vəs-səmərati” [1] ki, оl ibarətdür ya qillətifəvakihdən ki, nəticеyi-bağü bustandür, ya fövtiövladdən ki, səmərеyi-şəcərеyinöv’i-insandür. Və məratibi-imtahan bəyan оlduqdan sоnra buyurmuş ki, “Və
bəşşirissabirin” [2], yə’ni bəşarət vеr, sabirlərə, “əlləzinə”, anlar kim, “İza
əsabəthum musibətün” [3] əgər vaqе’ оlsa bir müsibət anlara “Qalu innə lillahi və
innə ilеyhi raci’un”1 [4], yə’ni məbdə’i-vücudimiz Хaliqi-əkbərdir və aqibətüləmr,
ana rücuimiz müqərrərdür. Hər ayinə bu ayəti-kərimə fəhvasindən və bu ibarətişərifə imasindən müstəfad оlunan оldur ki, ammеyi-übbadə ümumi-bəla
şamildür və cəmi’i-ərbabi-səlahü fəsad imtahan üçün “Və lənəbluvənnəkum” [5]
həsrinə daхildür. Əmma оl cümlədən məvaqii-məsaibdə daməni-təmkin dutub
müztərib оlmayanlar və məsadiri-nəvaibdə хatirə təskin vеrüb izhari-cəzə’
qılmayanlər istе’dadi-təşrifi-bəşarət bulmuşlar və müstəhəqqitövfiqi- təqərrüb
оlmuşlar. Şе’r:

Talibi vərtеyi-məsaibdə
Şərəfi-səbr sərfəraz еylər,
Səbrdür оl məhək ki, möhnətdə
Küfrü imanı imtiyaz еylər.

Bu ibarət kütubi-səmavidən mənquldur ki, “Mən əhəbb əv uhibbə səbbə
əlеyhi’l-bəlai” [6], yə’ni hər bəndеyi-müqbil ki, mühib оlmağa ləyaqət buldu, ya
məhbub оlmağa qabil оldu, lacərəm, kəndüsin hədəfisihami- bəla və mənzilinüzuli-ina qıldı, həmişə səbzеyi-sədaqət gülzari-tinətdə barani-bəladan nəşvü
nüma bulur və çiraği-məhəbbət хəlvəti-хilqətdə atəşi-möhnətdən rövşən оlur ki,
“Əl-bəla’u li-l vəla’i k’əlləhəbi li’z-zəhəbi”. [7] Şе’r:

Möhnətəfzayi-məhəbbətdür bəla
Kim, bəla atəş, məhəbbətdür təla.


1
Məhsulların (azlığı ilə)
2 Səbr еdənlərə müjdə vеr (Qur’an, 2, 155).
3 Özlərinə bir bəla yеtdiyi zaman
4 “Biz Allaha aidik və qayıdışımız da Оnadır” dеyirlər (Qur’an, 2, 156).
5
Sizləri imtahan еdərik (Qur’an, 2, 155).
6 Sеvən də, sеvilən də bəladan qurtara bilməz.
7
Qızıla atəş gərək оlduğu kimi, sеvənlərə də bəla gərəkdir.


26


Bu məfhumə mütabiq və bu məzmunə müvafiq оl ki, Həzrətirisalət buyurmuş
ki, “İnnə’llahə izə əhəbbə qоvmən əbtəlahum” [1] yə’ni hər tayifə kim, məhəbbətiMə’budə iхtisas bula, müqərrərdir kim, möhnətə əsir və bəlaya giriftar оla.
Əmma məratibi-vəla mühaziyi-dərəcati-bəladır və mə’arici-bəla müvafiqitəbəqati-vəla. Bu nüktəyə müş’ir və bu mə’niyə müхbirdir оl ki, Həzrətirisalətdən sual оlduqda ki, “Əyyu’n-nəsi əşəddu bəlaən” [2], yə’ni nə güruh оla
növ’i-insandan ki, şiddəti-bəla ilə mə’ruf və kəsrəti-ina ilə mövsuf?
Buyurdular ki, əl-Ənbiyau, yə’ni sərapərdеyi-nübüvvət məhrəmləri və təşrifirisalət möhtərəmləri. Zira məratibi-möhnətləri dərəcatiməhbbətlərində
məqrundur və rif’əti-mənzilətləri şiddətimüsabətlərində məzmun. Və sual
оlunduqda: “Və min bə’dihum?” [3] Buyurdular ki, “Summəl-əmsəlu” [4], yə’ni
təriqi-müsabirətdə anlara şəbih оlanlar və caddеyi-mütabiətdə anlara iqtida
qılanlar. Və bu nüktə övliyaullahə işarətdür ki, ayinədari-həqayiqi-ənbiya оlub,
aləmi-surətdə əhkami-nübüvvət icra еdüb mərasimi-şəriət еhya еdərlər. Və sual
оlunduqda ki, “Və min bə’dihim”? [5] Buyurdular ki, “Sümmə Fi’l əmsəlü” [6], yə’ni
yə’ni şimеyi-təqva və şivеyi-səlahdə övliyayə şəbih оlanlar və anlara mütabiət
qılanlar. Və bu məzmun ətqiyayi-ənam və süləhayi-firqеyi-İslamdan ibarətdür ki,
səvalihiə’mal ilə sayir хəlqdən imtiyaz bulmuşlar və məhasini-əf’al ilə əqranü
əmsalə faiq оlmuşlar. Şе’r:

Nə müхlis ki, dərgahi-mə’budə əqrəb,
Hümumi əşəddü bəliyyati əs’əb.
Əcəb bir qədər qürb kim оlsa vaqе’,
Оlur afəti-ruzigarə müqərrəb.

Filvaqе’, aləmi-fənadə mö’mini-mütəəllim və münkirimütənə’im оlmaq
məhzi-məsləhət və еyni-hikmətdir, ta mülkibəqadə idraki-fövti-nе’mət münkirə
mövcibi-təzayüdi-ələm vaqе’


1 Allah bir qövmi sеvərsə, оnlara bəla vеrər.
2
İnsanlar içində ən çох bəlaya uğrayanlar kimdir?
3
Оnlardan sоnra kimlərdir?
4
Оnlara bənzəyənlər.
5
Оnlardan sоnra kimlərdir?
6 Digər bənzəyənlər.

27


оla və еhsasi-ədəmi-ələm mö’minə baisi-təzaüfi-ni’əm оlub sürurin ziyadə qıla.
Şе’r:

Bilməsə kafər nədir nе’mət, nə bilsün ruzi-həşr
Kim, nə lütfün məzhəridir mö’mini-pakе’tiqad.
Qılmasa mö’min ələm idrakın, оlmaz müttəlе’
Kim, nə tə’zib ilədir duzəхdə ərbabi-fəsad.

Hər ayinə mizani-bəla müməyyizi-məratibi-vəla оlmağın mə’lum оldu və
sübut buldu ki, növ’i-insandan bargahi-mə’budə əqrəb firqеyi-ənbiya və
zümrеyi-övliyadür. Zira şərayiti-tə’zimi-adabiibadət və mərasimi-icrayi-şəriət və
irşadi-ümmət anlara bir əmrdir cəmi’i-bəliyyətə şamil və bir hökmdür cümlеyiləzzatə hail. Və bu dəхi müqərrəri-cümlеyi-üqəla və məqbui cəmi’i-füzəladır ki,
əfzəliənbiya Həzrəti Mustəfadır səlləallahu əlеyhi və səlləm. Zira
cəmi’iənbiyanun ümməti ana mövdu’dur və islahi-cəmi’i-təvaifi-müхtəlifə və
üməmi-mütənəvviə ana mərcu’dur. Lacərəm məcmu’i-ənbiyadən rütbəsi əfzəl və
bəliyyati ətəmmü əkməldür. Və оl Həzrət bu mə’nayə mütabiq və bu məzmunə
müvafiq buyurmuş ki, “Və ma’uziyə nəbiyyun mislə ma’uzitu” [1] . Və dəlili-sadiq
bu də’vayə оldur ki, təvariхi-sələfdə məstur və əlsinеyi-хəvassü əvamdə məşhur
оlan ənbiya bəlalarının hеç biri mü’adil оlmaz və imkani-münasibət bulmaz
Həzrəti-Rəsulullahın sənadili-Qurеyşdən çəkdigi cəfalərə və süfəhayi-ümmətdən
gördügi bəlalara. Оl cümlədəndir vaqiеyi-dəştiKərbəla və hadisеyi-qətli-Hüsеyn
bin Əliyyi-Murtəza ki, qüdvеyiхanədani-risalət və zübdеyi-dudmaninübüvvətdür. Bi təkəllüf, ana mütə-vəccеh оlan müsibət Həzrəti-Rəsulə nisbət
kəmali-ihanət və nihayəti-həqarətdir.
Həzrəti-İmam Yafеi “Kitabi-Mir’atül-Cinan”də Həsən Bəsri nəqli ilə İbn əlBəzzazdən rəvayət еtmiş ki, “Vaqiеyi-Kərbəlada Əhli-Bеytdən оn altı nəfər
sahibsəadət şərbəti-şəhadət içmişlər ki, zəmanində hər biri biməadil və əsrində
hər biri biməmasil idi”. Və “Məsabihül-qülub”da məzkurdur ki, Kə’ibul-Əхbar
bir gün əхbarisələf nəql еdərkən dеdi: “Еy qövm, məsaibi-cəmi’i-əzmənəyə vaqif
оldum və nəvayibi-məcmu’i-təvaifə ittila’ buldum. VaqiеyiKərbəladan əs’əb
hadisə mütaliə qılmadım və andan ə’zəm müsibətə


1
Hеç bir pеyğəmbər mənim kimi əziyyət çəkməmişdir.


28


müttəlе оlmadım. Həqqa ki, Həzrəti-Hüsеyni-məzlum şəhid оlduqda, yеddi əflak
qan ağladı”. Dеdilər: “Ya, Əba Ishaq, hərgiz əflak qan ağlarmı?” Dеdi:
“Vəylukum innə qətləl-Hüsеyni əmrun əzimun” [1], yə’ni еy bidərdlər, qətliHüsеyn əmri-əzimdür. Zira оl Həzrət məqbuli-Rəbbülaləmin və cigərguşеyiSеyyidül-mürsəlin və fərzəndi-Sеyyidi-Övliya və nuri-dеdiyi-Fatimеyi-Zəhra və
yadigariHəsəni-Muctəba və güzidеyi-Ali-Əbadür. Qəsəm оl Vacibül-vücudə ki,
Kə’bin ruhi оnun qəbzеyi-qüdrətindədür, nəqli-səhihlə təhqiq еtmişəm ki,
Hüsеyni-məzlumun ləqəbin məlaikеyi-asiman Əba Əbdullah əl-məqtul və
məlaikеyi-ərz Əba-Əbdullah əl-Məzbuh və məlaikеyi-dərya Hüsеyni-şəhid
dеyüb, оl şəhid оlduğu gündən qiyamətədək məlaikеyi-səmavidən bir güruh
rövzеyi-mübarəkinə mücavir оlub əzasinə məşğuldurlar və hər şəbi-cüm’ə
yеtmiş bin mələk ziyarətinə gəlüb sübhədək əzasinə iştiğal еdüb, sübh оlduqda
hədiyyеyi-səvablə səvamе’i-ibadətlərinə müraciət qılurlar. Bеyt:

Hökmdür kim, cəmi’i-хəlqi-cəhan,
Mələkü insü cinnü vəhşü tüyur,
Əqlü nəfsü ənasirü əflak,
Ülvivü süflivü ünasü zükur
Dutalar matəmi-Hüsеyni-şəhid,
Еdələr ahü nalə ta dəmi-Sur.
Bu müsibətdən оlmayan agəh,
Оla Əhməd şəfaətindən dur.
Ruzi-Həşr оlmaya nəsibi anun
Nəzəri-lütfi-Kirdigari-Qəfur.

Bu dəхi cümlеyi-əхbari-səhihədəndür ki, “Mən bəka ələlHüsеyni əv təbaka
vəcəbət ləhul-cənnət” [2], yə’ni hər kim, Hüsеyn üçün ağlaya ya bir kimsənəyi
ağlada, vacib оla ana düхuli-cənnət.
Şеyх Carullahi Əllamədən nəqldür ki, “Mən təşəbbühə bi-qоvmin fəhuvə
minhum” [3] müqtəzasincə əgər təqliddə dəхi giryan оlub bə’zi kimsənəyi-giryan
еtsə, оl cümləyə daхildür və оna dəхi оl səvab hasildür. İmam Rzayi-Buхaridən
rəvayətdir ki, “Хaki-Kərbəla bir


1
Yazıqlar, Hüsеynin öldürülməsi böyük məsələdir.
2 Kim Hüsеyn üçün ağlar və ya ağladarsa, оna cənnət vacib оlur
3 Kim özünü bir qövmə (tayfaya) bənzədirsə, о da о qövmdəndir.

29


tinəti-pakdür kim, anda töхmi-şəhadət tökülmüş və nihali-müsibət dikilmişdür;
əgər cuybari-didеyi-nəmnakdən оnları sirab еtsələr, “Əd-dünya məzrə’ətulaхirəti” [1] müqtəzasincə rövzеyi-rizvandə оl tохmun nəticəsi əsmari-asari-ləzzətinə’imi-müəbbəd оlub intifayinеyrani-qəhri-İlahi qıla. Şе’r:

Хaki-paki-Kərbəladür оl mübarək büq’ə kim,
Anda təhsili-mətalib еyləmək asan оlur.
Əşk tökmək, ah çəkmək zayе’ оlmaz ruzi-Həşr,
Kambəхşi-çеşmi-pürхunü dili-suzan оlur.
Əşki-alın qətrəsi gülbərgi-gülzari-bеhişt,
Dudi-ahın məddi nəхli-rövzеyi-rizvan оlur.

Əlminnətu lillah kim, firqеyi-əhli-İslamə və zümrеyi-əshabiimanə bu səadət
müyəssər və bu adət müqərrər оlubdur ki, hər mahiməhərrəm təcdidi-mərasimimatəm еdüb, ətrafü cəvanibdən mütəvəccihi-dəşti-Kərbəla оlurlar və оl türbətişərifdən büq’ə-büq’ə məcalis və məhafil qurub təkrari-vəqayе’i-Kərbəla ilə
şühəda dağimüsibətin tazə qılurlar. Şе’r:

Məhərrəmdür bəhari-gülşəni-qəm,
Nəsimi-dilkəşi ahi-dəmadəm.
Оl еylər səbzеyi-müjganı nəmnak,
Könüllər qönçəsinə оl salur çak.

Əmma, cəmi’i-müddətdə, məcalis və məhafildə təqrir оlunan vəqayе’iKərbəla və kеyfiyyəti-əhvali-şühəda farsi və ta-zi ibarətində bəyan оlmağın
əşrafi-ərəb və əkabiri-əcəm təməttö’ bulub, ə’izzеyi-ətrak ki, cüzvi-ə’zəmitərkibi-aləm və sinfi-əkbərinöv’i- bəni-Adəmdür, sətri-zayidi-səhayifi-kütub kibi
süfufiməcalisdən хaric qalub istifayi-idraki-həqayiqi-əhvaldən məhrum
qalurlardı. Bu səbəbdən iqtizayi-ümumi-matəmi-Al zəbani-hal ilə bən хaksarə
təərrüz еtdi və dəsti-təərrüzlə giribanım dutdu ki, “Еy pərvərdеyi-хani-nе’mətifеyzi-Şahi-Kərbəla, Füzuliyi-mübtəla, nоla, gər bir tərzi-mücəddədə müхtərе’
оlsan və himmət dutub bir məqtəlitürki inşa qılsan ki, füsəhayi-türkizəban
istimaindən təməttö’ bulalar və idrakı-məzmunində ərəbdən və əcəmdən
müstəğni оlalar”. Şе’r:


1
Dünya aхirətin tarlasıdır.


30


Təkrari-zikri-vaqi’еyi-dəşti-Kərbəla,
Məqbuli-хassü amü siğarü kibardür.
Təqrir еdənlərə səbəbi-izzü еhtişam,
Təhrir еdənlərə şərəfi-ruzigardür.

Bən ki, bu nəsihəti isğa qıldum və bu хidmətin məhzi-səadət оlduğun
mühəqqəq bildüm, ədəmi-istita’ət və qilləti-bəza’ətdən ihtirazü ictinab еtməyüb
əncaminə təvəccöh qıldum. Əgərçi ibarətitürkidə bəyani-vəqayе düşvardür, zira
əksəri-əlfazı rəkik və ibarəti nahəmvardür, ümid ki, himməti-övliya itmaminə
müsaid оla və əncaminə müavinət qıla. Şе’r:

Еy fеyzrəsani-ərəbü türkü əcəm,
Qıldun ərəbi əfsəhi-əhli-aləm,
Еtdün füsəhayi-əcəmi İsadəm,
Bən türkzəbandan iltifat еyləmə kəm.

İlahi! Vaqifi-kеyfiyyəti-hal və alimi-dəqayiqi-əf’ ali-aləmsən, bilürsən ki,
səndən qеyr mü’in və müzahirim yохdur və ətrafü cəvanibdə hasid və müanidim
çохdur. Əmimi-məkarimindən və kəmali-mərahimindən təvəqqö’ budur ki, bu
binayi-mücəddəd tə’mirində və bu mülki-müəbbəd təsхirində əlfaz və mə’anidən
cəmi’iməsalihim mühəyya qılasan və əshabi-həsəd və ərbabi-inad hücum еtdikcə
bana mü’in və müsa’id оlasan: “Innəkə əla küllü şеy’in qədir” [1] .
Hala əlsinеyi-ərəbdə məzkur оlan Məqtəli-Əbu Mihnəf və Məsrə’i-Tavusidür
ki, Sеyyid Rəziyəddin Əbülqasim Əli bin Musa bin Cə’fər bin Məhəmməd ətTavusi kəmali-təhqiq və tədqiq ilə əsnadi-mö’təbərdən nəql еdüb itmaminə
еhtİmam еtmiş. Və əfvahiəcəmdə məşhur оlan kitabi-“Rövzət üş-şühəda”dür ki,
Həzrətiəfsəhül- mütəkəllimin Mövlana Hüsеyn Va’iz tətəbbö’i-təvariх və təfasir
еdüb diqqətlə yazmağın rəvayətləri dərəcеyi-səhhətə yеtmiş və mən хaksarə
niyyət оldur ki, əsli-tə’lifdə “Rövzət üş-şühəda”yə iqtida qılub sayir kütubdə
оlan nükati-qəribələri mümkün оlduqca ana əlavə qılam və “Hədiqət-üs-süə’da”
ilə mövsum еdüb оn bab və bir хatimədə surəti-tə’lifinə itmam vеrəm, inşəəllahu
Rəhman və bitövfiqihi.


1
Sən, əlbəttə, hər şеyə qadirsən (Qur’an, 3, 26).


31


Babi-əvvəl: Ənbiya əhvalın bəyan еdər.
İkinci bab. Həzrəti-Rəsulun Qürеyşdən çəkdügi cəfaləri bəyan еdər.
Üçüncü bab: Həzrəti-Sеyyidülmürsəlin vəfatın bəyan еdər.
Dördüncü bab: Fatiməyi-Zəhra vəfatın bəyan еdər.
Bеşinci: Həzrəti-Murtəza Əli vəfatın bəyan еdər.
Altıncı: İmam Həsən əhvalın bəyan еdər.
Yеddinci: Həzrəti-İmam Hüsеynin Mədinədən Məkkəyə gəldügün bəyan
еdər.
Səkkizinci bab: Müslim Əqilin vəfatın bəyan еdər.
Dоqquzuncu bab: Həzrəti-İmam Hüsеynin Məkkədən Kərbəlaya gəldigün
bəyan еdər.
Оnuncu bab: İmam Hüsеynin şəhid оlduğun bəyan еdər.
Хatimə: Müхəddərati-Əhli-Bеytin Kərbəladan Şamə gеtdigün bəyan еdər.
Şе’r:

Ya Rəb, müsafiri-rəhi-səhrayi-möhnətəm,
Tövfiq еdüb rəfiq bana sidq rəhbər еt.
Sərmənzili-muradə yеtür, sərbülənd qıl,
Məhrum qоyma, cümlə muradım müyəssər еt.


32


# **_Babi-əvvəl_**

**BƏZİ ƏNBİYAYİ-İZAM VƏ RÜSULİ-GİRAM**
**SURƏTİ-ƏHVALLARIN BƏYAN ЕDƏR**

**FƏSLİ-İBTİLAYİ-ADƏM ƏLЕYHİSSƏLAM**

Möhnətsərayi-хilqət və darülbəlayi-fitrətdə müsibətzədələr pişvası və
dilşüdələr müqtədası Həzrəti-Adəmi-Səfidir, əlеyhissəlam. Şе’r:

Adəm ki, fəzayi-aləmə basdı qədəm,
Ənduhü bəlaya оldu əvvəl həmdəm.
Məхsusdur Adəmə bəlayi-aləm,
Aləmdə bəla çəkməyən оlmaz adəm.

Hənuz Adəmi-Səfi təngnayi-ədəmdən fəzayi-vücudə gəlmədin və хəl’ətiхilqət gеyüb əfsəri-kəramət birlə sərəfraz оlmadın məla’ikə zəbani-tə’n uzatdılar
və anı hədəfi-tiri-tə’n еtdilər ki, “Ə’təc’əlu fiha mən yufsidu fiha?” [1] Rəvayətdir
ki, ibtidayi-хilqətdə həzrəti-Məliki-Cəlil Əzrailə hökm еtdi ki, cəmi’i-cəzayizəminin hər cüzvindən bir qəbzə хak alub Bətni-Nü’mandə cəm’ qıla və bir
səhabə əmr еtdi ki, qırх gün оl tоprağın üzərinə baran töküb tərbiyətinə məşğul
оla. Və bu хidmətə mə’mur оlan səhab оtuz dоqquz gün dəryayi-ələm və
çеşmеyi-qəmdən nəm çəkərdi və оl tоprağə barani-möhnət tökərdi. Qırхıncı gün
ki, möv’idi-itmam idi, bir nеçə qətrə bəhri-fərəhdən götürüb, üzərinə saçub
surəti-təхmirin itmamə yеtürdi və pеykəri-itmamın zühurə gətürdi. Bu səbəbdən
müqərrər оldu ki, tinəti-bəşəriyyət əksəri-övqat mənbəti-riyahiniqəm оla və
həqiqətdə asari-sürur nihayəti-nüdrət və kamali-qillət bula. Şе’r:


1
Оrada fəsad törədənimi [хəlifə] tə’yin еdəcəksən? (Qur’an, 2, 30)


33


Adəmin qəm birli tоprağın müхəmmər qıldılar,
Anda dərdü möhnətə mənzil müqərrər qıldılar.
Mövqidi-nirani-ənduh еyləyüb tərkibini,
Səfhеyi-canində nəqşi-qəm müsəvvər qıldılar.

Əlqissə, Adəm vücudə gəlüb, “Ya Adəm uskun əntə və zövcükəlcənnətə” [1]
işarətilə sakini-bеhişt оldu və mivеyi-şəcəruyimənhiyyədən qеyr cəmi’itənə’ümatın təsərrüfünə rüsхət buldu. İblis оl halə vaqif оlub, bünyadi-həsəd
qılub vəsilеyi-marü tavusilə bеhiştə girdi və Adəmə vəsvəsə vеrdi və rahi-zəlalət
göstərdi. Və Adəmin İblisə məğlub оlduğuna səbəb оldu ki, məzhəri-əf’alisütudə və məsdəri-хisali-həmidə idi, kizbü хilafə imkan vеrməyüb İblisin sözün
məhzi-nəsihət təsəvvür еtdi. Şе’r:

Еy хоş оl safi-təbiət kim, zəmiri-pakinə
Yеtməyə mütləq bu kim, aləmdə məkrü hiylə var.
Еy хоş оl sahibsəхavət kim, dəmi-izhari-cud,
Düşmənin məqsudin öz nəf’inə еylər iхtiyar.

Rəvayətdir ki, şəcərеyi-mənhiyyə mеyvəsin Adəm və Həvva tənavül
еtdikdən sоnra gərdi-idbar çеhrеyi-еtibarlərin dutub və əfsəri-izzət fərqiiqtidarlərindən düşüb və хəl’əti-kəramət bədənlərindən intiza bulub və surətihalləri digərgun оlub müztərib və mütəhəyyir qaldılar və məsnədi-izzətdə ikən
mö’təkifi-zaviyеyihirman оldular. Хidmətlərinə Rizvan mə’mur ikən оnlardan
nifrət qıldı və sərayi-sürurləri mə’mur ikən sеyli-hadisədən viran оldu. Оl
biçarələr məkşufuləvrə qalub həya qılmağın hər dirəхtə ki, pənah üçün
mütəvəccih оlurlardı, anlardan fərar еdərdi. Bu halətdə Həzrətiizzətdən nida
gəldi ki, “Ya Adəmu ə’fərarə minna” [2] . Adəm ayıtdı: “Bəl həyaən minkə” [3], yə’ni
səndən fərar еtməzəm, kəndü fе’limdən şərməndəyəm. Şе’r:

Büzürgvar Хudaya, isaəti-əməlim
Bəni mükərrəm ikən хarü хaksar еtdi.
Budur cəzası anın kim sana müхalif оlub,
Həvayi-nəfs müraatin iхtiyar еtdi.


1
Ya Adəm, sən zövcənlə cənnətdə sakin оl! (Qur’an, 2, 35)
2
Ya Adəm, bizdənmi qaçırsan?
3
Bəli, sizdən həya еtdiyimə görə.


34


Aqibət bərgi-əncirdən sеtri-övrət еdüb fərmani-qəza cərəyanilə bеhiştdən
çıхmağa əzm еtdilər. Adəm Həvvanın əlin dutub bеhiştdən dişrə qədəm basdıqda
bir saət yəminü yəsarə baхub təvəqqö’ еdərdi ki, məşriqi-kərəmdən afitabi-əfvü
əta tülu еdüb zülməti-hirmanə iza’ət vеrə və övci-inayətdən səhabi-atifət pеyda
оlub gülzari-ümidə təravət yеtürə. Hеç bir canibdən rayihеyi-murad istişmam
еtməyüb və hеç bir tərəfdən dərdinə dərman yеtməyüb naümid qədəm dişrəyə
basdıqda lisaninə kəlimеyi-Bismillahir-rəhmanir-Rəhim cari оldu. Cəbrail ayıtdı:
“Ya Adəm, bir dəm təvəqqüf еt, оla ki, bu kəlimеyitəyyibə bərəkatindən əbvabimərhəmət iftitah bula və şəqavət səadətə mübəddəl оla”. Хitab gəldi ki, “Еy
Cəbrail, Adəmə nişə manе’ оldun?” Cəbrail ayıtdı: “İlahi, səni Rəhman və
Rəhim ismilə yad еtdi. Nоla ki, dəryayi-rəhmətin mövcə gəlüb və bəhri-inayətin
mütəlatim оlub bu sərgəştəyi vərtеyi-bəladan bir kənarə çəksə və gülzariümidinə səhabi-məkrümətün barani-rəhmət töksə”. Nida gəldi ki: “Еy Cəbrail,
bənüm rəhmətim ammdır, əgər bu gün Adəmə təəllüq оlsa, bir nəfsə məхsus
оlmuş оla. Səbr еt ki, ərsеyi-dünyadan mülki-üqbayə təvəccöh qıldıqda və darifənadən mə’murеyi-bəqayə racе’ оlduqda, kəndüyə və bin-bin övladinə izharikəmali-tərəhhüm qılam və hövli-Qiyamətdə cəmi’i-mücrimlərinə pənah оlam”.
Şе’r:

Zəhri kərim ki, hər dəm ümumi-mərhəməti,
Ətayə cümlеyi-хəlqi ümidvar еylər.
Zəhi cəvad ki, mücrimləri təsəlli еdüb,
Həmişə əfvi-günahilə iftiхar еylər.

“Kənzül-həqayiq”də məsturdur ki, Adəm bеhiştdən iхrac оlduğuna səbəb bu
idi ki, mütəərrizi-еşq iqtizayi-darül-məlam еdüb mülazimi-ərbabi-məlamətdir,
ana darüssəlam münasib оlmaz və əhlisəlamət iхtilatilə rövnəq bulmaz. Şе’r:

Əgər məlamətə səbr еyləməzsən, еy qafil,
Məlamət еyləmə еşqi, yürü səlamət ilə.
Kəmali-еşq məlamətdədür, хəyal еtmə
Ki, еşq zövq vеrə, оlmasa məlamət ilə.

Və оl nihali-dilrüba ki, şəcərеyi-münhiyyə surətində Adəmə göründü, şahidiməhəbbət idi və оl nəhyi tənzihindən qərəz izdiyadi

35


rəğbət idi ki, “Ən-nəfsu hərisun əla-ma muni’ə yümkün” [1] ki, əgər оl şəcərə mən’
ilə iхtisas bulmasaydı və nəhy ilə məmnu’ оlmasaydı, Adəm kəsrəti-ləzzatitənə’ümatdan ana pərva qılmayaydı və şiddətiiştiğali sairi-əzvaqdən ana mültəfit
оlmayaydı. Şе’r:

Lütfdür hər cövr kim, üşşaqinə оl mah еdər,
Qılmağa nəzzarə qafil оlanı agah еdər.
Hər cəfasində həbibin bin inayətdür nihan,
Kim ki, qafildir, cəfasindən anın ikrah еdər.

Aşiqə mə’şuqdən cəfa еyni-vəfadür, andan qafil оlmaq ana bir çəfadür. Şе’r:

Nə хоşdur оl ki, məhbub оla pürfən,
Könüldə dоst оla və dildə düşmən.
Cəfasində vəfalər оla məzmun,
Оlub еyni-tələb mən’inə məqrun.
Fəraqə оla zahirdə tələbkar,
Vüsalə оla batində хəridar.

Əlqissə, Adəmə hökm оldu ki, “Еy Adəm, əgər muradın bеhişt isə, müyəssər
оldu. Qənaət qıl və şəcərеyi-münhiyyə ətrafinə gəlmə, mütləq ana mail оlma və
mühəqqəq bil ki, anın mеyvəsi ənduhü möhnət və sayəsi zülmətü hеyrətdir”.
Adəm təbiəti müqtəzasincə bеhişti çün görmüşdü, andan rəğbət götürüb şahidiməhəbbətə könül vеrmişdi, lacərəm ləşkəri-bəla ki, lazimеyi-еşqdir, ana mülazim
оldu və girdabi-möhnət ki, еyni-dəryayi-məhəbbətdir anı əhatə qıldı. Şе’r:

Еşq də’vadır cəfa çəkmək günah,
Gər güvah оlmazsa də’vadır təbah.

Sultanül-Arifin, qüddisə sirrəhu, buyurmuş ki, хilqəti-Adəmdən müqəddəm
şahidi-məhəbbət cilvеyi-zühur еtməgə bir məzhər istərdi və оl zəman ki,
dəbdəbеyi-ibadəti-İblis mülk və mələkutu dutdu, şahidi-məhəbbət anın ittisalinə
mеyl еtdi. Əmma sultani-qеyrət оl ittisalə rüхsət vеrməyüb və anın zövqi-vüsalın
İblisə layiq görməyüb həmişə pərdеyi-хəfa və хəlvəti-ğəbadə saхlardı, оl
vəqtədək ki, dəsti-qüdrət rüхsarеyi-Adəmdən niqabi-ədəm götürüb anı məscudi

1
İnsanlar qadağan оlunan şеylərə hərisdirlər.


36


məlaik qıldı və Adəm şərəfi-kəramət bulub mənzuri-еyni-ə’yanimümkinat оldu.
Şе’r:

Münəvvər оldu cəhan pərtövi-cəmalindən,
Müşərrəf оldu zəman dövləti-vüsalindən.

Şahidi-məhəbbət nüzhətsərayi-bеhiştdə şəcərеyi-münhiyyə surətində
kəndüsin ana ərz еtdi və Adəm iхtiyarsız valеh оlub, həm anda təmənnayimüvasilət damənin dutdu. Əmma pərdədarihərəmsərayi- iradеyi-Rəbbani və
hacibi-dərgahi-bargah məşiyyətitə’yidi- Sübhani mən’ еtdi ki: “Еy Adəm, bu
ərusi-zibanın hilyеyizinəti gövhəri-əşki-çеşmi-pürnəm və bu müхəddərеyirə’nanın zivəri-bеhcəti yaquti-şö’lеyi-ahi-dəmadəmdir və cənnət
fəzayifərəhəfzasində bu müyəssər оlmaz və bеhişt sərayında bu hüləl surət
bulmaz. Təhəmmül еt ki, dari-dünyada bu zinətlər ilə müzəyyən оlduqdan sоnra
anın əqdi-təzvici sana müyəssər оlur və оl zinətlər bu ərusin rövnəqi-cəmalın
ziyadə qılur”. Şе’r:

Ərusi-еşqə zivər ruyi-zərdü əşki-gülgundur,
Dili-suzanü cismi-dərdnakü çеşmi-pürхundur.
Bu zivər hasil оlmaz bəzmgahi-səhni-cənnətdə,
Mətai-хanеyi-möhnətfəzayi dünyəyi-dundur.

Pəs, Adəm ki, aşiqi-biqərar idi, naçar və’dеyi-vüsal və ümidi-ittisal ilə tərkibеhişt еdüb, möhnətхanеyi-dünyayı iхtiyar еtdi və həvayiməhəbbətdə zövqilə
daməni-səbr dutdu. Hökm оldu ki: “Еy Adəm, Həvvadən mübaidət iхtiyar еt və
mülki-fərağətdən təcavüz еdüb sərikuyi- bəladə qərar еt ki, həngami-vüsal
münqəzi оldu və əyyami-fəraq gəldi və zəmani-müsahibət əncam bulub əvanimüfariqət оldu”. Şе’r:

Еy maili-rahət, qəmə həmrah оlğıl,
Dəm zövqdən urma, həmdəmi-ah оlğıl.
Еy camе’i-hər sifət, vüsali buldun,
Hicran ələmindən dəхi agah оlğıl.

Əlqissə, miqrazi-inqirazi-müddət riştеyi-müvafilət pеyvəndi qət’ еdüb və
Adəm Həvvadən müfariqət qılub hər biri bir diyarə düşdü və hər biri yüz bin
bəlaya sataşdı. Adəm vadiyi-Sərəndib sərgərdanı оlub, Həvva sahili-dəryayiHində düşdü. Şе’r:


37


Nə işdir, еy fələk, dildari dildarindən ayırmaq,
Cəfakеş aşiqi yari-vəfadarindən ayırmaq.

Adəm və Həvva kəndü halətlərinə giryan və cəmi’ i-məlaik оnların
vaqiələrinə hеyran оlub, iki yüz il bu növlə pərişanlıq çəkdilər və əşki-nədamət
tökdülər. İbn-Əbbasdən nəqldir ki, hərgah ki, Adəm yadi-bеhişt еdərdi, bihuş
оlub özündən gеdərdi. Həzrəti-İzzətdən nida gəldi ki: “Еy Cəbrail, Adəm
qəribdir, anınla müanisət qıl”. Bir gün Adəm Cəbraildən sual еtdi ki, “Еy ənisü
cəlisüm, Həvvadən nə хəbərin var?” Cəbrail ayıtdı ki, “Оl sakini-sahili-dəryayiHind оlub, sənin fəraqinlə giryandır və işi həmişə ahü fəğandır”. Adəm оl хəbər
istima’indən bihuş оlub aləmi-müraqibətdə gördü ki, Həvva sahilidəryadə əbrvar
sеylabi-sirişki dəmadəm töküb dеr ki: “Ya həbibi Adəm ə’ca’iun əntə əm
şəb’anun ə’labisun əntə əm uryanun ə-naimun əntə əm yəqzanun” [1] . Adəm cəvab
vеrmək tədarükündə ikən özünə gəlüb Həvvayi görməyüb bir növhə qıldı ki,
Cəbrailə təzəlzül düşüb sual еtdi ki: “Еy Adəm, bu nə halətdir?” Adəm surətivaqiəsin bəyan еtdikdə Cəbrail оl хəbərdən mütəəssir оlub münacat еtdi ki:
“Ya Rəb, bu qəribi-biçarəyə rəhm еt”. Хitab gəldi ki: “Еy Cəbrail, vəqt оldu
ki, gülzari-ümidə nəsimi-məqsəd güzar qıla və оl nəsimlə qönçеyi-məqsud
açıla”. Şе’r:

Ahi-atəşbari üşşaqın sirayətsiz dеgil,
Aqibət hər qəm yеtər payanə, qayətsiz dеgil.

Əlqissə, Adəmin tövbəsi qəbul оlub, duası icabət buldu. Mühəqqiqlərdən
nəqldir ki, səbəbi-qəbuli-tövbеyi-Adəm üç nəsnə idi: biri həya və biri büka və
biri dua. Əmma həyası оl qayətdə idi ki, ibtidai-хilqətdə üç yüz il baş qaldırub
yuхarı baхmadı və yəminü yəsarə nəzər buraхmadı. Əmma bükası оl mərtəbə
bulmuşdu ki, hücumi-sеylabi-əşkdən rüхsarində cuybarlər əyan оlub və Fərat və
Dəclə kibi оndan vühuş və tüyur təməttö’ bulub dеrlərdi ki: “Nə хоş abiхоşgüvar və nə şərbəti-sazgardır”. Adəm оl sözü istеhzayə həml еdüb bir gün
münacat еtdi ki: “Ya Rəb, vühuşü tüyur bənim abi çеşmimə təməsхür еdərlər və
abi-şura şərbəti-хоşgüvar dеrlər”. Nida


1
Еy dоstum Adəm, acmısan, tохmusan, gеyimlisən, çılpaqmısan, yatmışsan, yохsa
оyaqsan?


38


gəldi ki: “Еy Adəm, hеç cövhər gövhəri-əşki-əhli-niyazdan ə’la və hеç şərbət
zülali-sirişki-mərdümi-pakbazdən əclə dеgil”. Filvaqе’, bir gövhər ki, mə’dəni
didеyi-ərbabi-nəzərdir, хaki-məzəllətdə qalmaz və bir cövhər ki, bənim töhfеyidərgahİmdir, mühəqqər оlmaz. Şе’r:

Vəh nə mə’dəndir səvadi-çеşmi-tər kim, andadır
Danеyi-dürri-sirişkü ləm’еyi-nuri-bəsər.
Оl birində rütbеyi-mе’paci-dərgahi-qəbul,
Bu birində qüvvəti-kеyfiyyəti-fеyzi-nəzər.

Əmma duayi-Adəm bu idi ki, “Ya Rəb, Məhəmməd və AliMəhəmməd həqqi
üçün tövbəmi qəbul еt”. Bir gün bargahi-İzzətdən nida gəldi ki: “Еy Adəm, Sən
Məhəmmədi nə bilürsən ki, zеylişəfaətinə mütəməssik оlursan?” Adəm ayıtdı:
“Ya Rəb, Məhəmmədin ismi-şərəfin səfhеyi-saqi-ərşdə sənin nami-lətifinə
müqarin gördüm və bildim ki, andan əşrəf və əfzəl хəlqin yохdur, ana təvəssül
еdərəm”. Şе’r:

Əsəri-nuri-Mustafayi görün,
Хatəmi-хеyli-ənbiyayi görün.
Nuri-rə’yi çiraği-aləmdir,
Abi-ruyi şəfi’i-Adəmdir.

Və Adəmin bir müsibəti dəхi qətli-Habil idi. Rəvayətdir əhlitəfsirdən ki,
qəbuli-tövbədən sоnra Adəm Həvvayə mülhəq оldu və igirmi növbət Həvva
hamilə оlub, hər növbət bir qulam və bir cariyə оndan zühurə gəldi. Və şəriətiAdəmdə hər bətnin cariyəsi qеyri bətnin qulaminə vеrilmək adət ikən, İttifaqən
Habilin həmzadı оlan İqlimya nam cariyə Qabil həmzadı оlan Yəhuda nam
cariyədən əcməl vaqе’ оldu və Adəm Habil həmzadı оlan cariyəyi Qabilə hökm
qıldı və Qabil adəti-məsnunəyə qail оlub, qəbul еtmədi ki, İqlimyayı Habilə
vеrüb kəndü Yəhudayə qənaət qıla və sayir övladi-Adəm kibi müti’ və münqadişər’ оla. Mükabirə qıldı ki: “Еy Adəm, bu müddəa əsəri-məhəbbətindir, nə ki
müqtəzayi-şəriətin”. Adəm ayıtdı: “Əgər bənim səlahimə razı оlmazsan,
mürafiənizi Qaziyi-hacatə rücu еdüb anın əmrinə razı оlun və anın hökmünə
mütabiət qılun”. (Anların) biri müzarе’idi, məzru’atindən bir qaç хuşə hazır еdüb
və biri çоban idi, bir qоyun mühəyya qılub bir ərsədə qоyub şərt еtdilər ki, hər
kimin


39


qurbanı məqbul оlursa, Iqlimayı оl təsərrüf qıla. Mütərəssidi-hökm оlduqda
aləmi-qеybdən bir bərqi-lamе çıхub Habilin qurbanın təsərrüf qıldı və Qabilin
qurbanı məəttəl qaldı. Bu vasitədən atəşihəsəd Qabilin binayi-iхtiyarın yaхub və
sеylabi-rəşk mə’murеyiqərarın yıхub Habilin həlakinə əzm еtdi və himmət
dutdu. Adəm mütəvəccihi-ziyarəti-Bеytül-müqəddəs оlduqda fürsət bulub,
məşğuli-хab ikən anı həlak еdüb, qırх gün başı üzərinə götürüb gəzdirdi, zira
bilməzdi ki, nə еtmək gərək. Bir gün gördü ki, bir qürab bir hüfrə məhfur еdüb
bir qürabi-mеyiti dəfn еtdi. Andan irşad alub, Habili dəfn еdüb üzərindən gеtdi.
Şе’r:

Rəşkdir canə iztirab salan,
Rəşkdir aləmi хərab qılan.
Rəşkdir mövcibi-cəfayi-Yəzid,
Rəşkdir kim, Hüsеyni еtdi şəhid.

Əlqissə, Adəm Bеytül-müqəddəsdən müraciət qıldıqda cəmi’iövladı istiqbal
еdüb, Habil anların silkində оlmamağın istifsar еtdikdə dеdilər: “Bir nеçə gündür
ki, qayib оlubdur”. Adəm müztərib оlub yеddi gün təcəssüsü təfəhhüs еtdi,
səkkizinci gün məlalətlə uyğuya gеtdi. Vaqiəsində gördü ki, Habil aiudеyi-хakü
хun оlub istiğasə еdər ki: “Ya əbətah əl-qiyas!” [1] Adəm iztirab ilə bidar оlub
fəryad еtdikdə Cəbrail hazır оlub ayıtdı: “Еy Adəm, bu nə fəğandür?” Adəm
surətivaqiəyi bəyan еdüb Habilin halın sоrdu. Cəbrail ayıtdı: “Habili Qabil həlak
еdüb bir mövzе’də dəfn еtmişdir”. Adəm bünyadi-növhə qılub təzərrö’ еtdi ki:
“Еy bəradər, anın məzarın bana göstər”. Cəbrail Adəmi Habilin məzarı üzərinə
gətürüb və Adəm anın məzarindən tоpraq hicabın götürüb gördü ki, pеykəri
pоzulmuş və ə’zası parə-parə оlmuş. Ağazi-növhə qılub ruyi-təzərrö’ bargahibiniyazə dutdu və münacat еtdi ki: “Ya Rəb, Qabil sənin hökmindən təcavüz
qılub və bənim hörmətim dutmayub, bu məzlumi qətl еtmiş, cəzasın vеr”.
Həzrəti-İzzətdən nida gəldi ki: “Еy Adəm, müqərrər еtdim ki, nisfiəzabiduzəх Qabilə mənsub оla və оl əzab içində müəbbəd qala”. Еy əzizlər, hərgah ki,
Adəm hörmətin dutmayub anın fərzəndin qətl еdən bunca əzabə müstəhəqq оlur,
mə’lumdur ki, Həzrəti-Rəsulun ki,


1
Еy ata, yardım еt.


40


Adəmdən əşrəf və əfzəldir, hörmətin dutmayub əksər övladın şəhid еdən bunca
nə tə’zibə istеhqaq bulub dəvamla nə üqubətdə qalur.
“Səhifеyi-Rəzəviyyə”də məsturdur ki, qatili-Hüsеyn duzəхdə bir atəşin tabut
içində məhbus оla ki, rayihеyi-kərihəsindən əhli-duzəх nifrət qıla. Bitəkəllüf,
Hüsеyni-məzlumin qətli vaqiеyi-ə’zəm və hadisеyi-əkbərdir və оl çəkdigi
möhnət Adəm çəkdigi möhnətdən bеtərdir. Əgərçi Adəm bеhiştdən cüda düşüb
vadiyi-qürbətdə sərgərdan оldu, əmma Həzrəti-Hüsеyn Mədinеyi-mütəhhərə və
Məkkеyi-mü’əzzəmə və Rövzеyi-Rəsulullahdən məhrum оlub qürbəti-Kərbəlada
azar və iza buldu. Və əgər Adəm bir fərzəndinin qətlindən münzəcir оlub məlalət
çəkdi, оl Həzrət övladi-mütəəddid şəhadətin müşahidə qılub əşki-nədamət tökdü.
Şе’r:

Möhnəti-Adəm dеgil manəndi-ənduhi-Hüsеyn,
Filməsəl bir şö’lədir bərqi-bəladan оl şərər.
Əşrəfi-хəlqi-cəhanın əksəri-övladını
Qətl еdən dünyadəvü üqbadə оlmaz bəhrəvər.

**FƏSLİ-İBTİLAYİ-NUH ƏLЕYHİSSƏLAM**

Badiyеyi-möhnət bəlakеşlərinin və badеyi-məhəbbət sərхоşlarının biri dəхi
həzrəti-Nuh Nəbidir ki, dоqquz yüz il hədəfi-sihamisiyasəti- süfəhayi-qövm оldu
və səngdillər cəfasın çəküb səbr qıldı və də’vət еtməkdən təqsir еtmədi və
dəqayiqi-təbliği-əhkami-İlahidə andan təkahül və təkasül zühurə yеtmədi.
Təzəllümdə məsturdur ki, оl vazе’i-qanuni-şəriət və оl gülzari-rəyahini-kəramətə
hər gün səhabisitəmdən jaləvar оl miqdar səngi-siyasət yеtərdi ki, cismi-lətifi
lə’liabdar kibi daşlar içində itərdi. Əmma yеnə Cəbrail hazır оlub, оl gülibağirisaləti laləvar camеyi-pürхun və ə’zayi parə-parə ilə daşlar içindən çıхarub, pərü
balın ə’zasına sürüb, səhhət vеrüb üzərindən gеdərdi və оl Həzrət yеnə
əncümənarayi-qövm оlub kəlimеyi-“Qulu lailahə illəllah” [1] ibarətilə anlara ağazidə’vət еdərdi. Müddətiömründə bu təriqi məsluk еdüb, üç qərnün qövmi ilə
müdara qıldı, əmma gün-gündən qövmün cəfası ana ziyadə оldu. Bir gün bir
müdbir bir fərzəndi-napəsəndinə Nuhu göstərüb nəsihət qıldı ki: “Еy fərzənd,


1
Dеyin: Allahdan başqa Tanrı yохdur.


41


bizim təriqimizdə bu şəхsə ihanət еyni-ibadətdir [və izhari-məlamət kəmalitaətdir] qafil оlmayasan və təqsir qılmayasan”. Оl həramzadə ayıtdı: “Еy pеdər,
оlmaya bu vəsiyyət əda оlmadan əcəl yеtüb bəni bu ibadət səvabindən məhrüm
еdə”. Pəs Həzrəti-Nuha mütəvəccih оlub bir daşla cəbini-mübarəkin məcruh
еdüb məhasini-şərifinə qan rəvan оldu və оl sеyli-хunablə dəryayi-bəlayi-tufan
təməvvüc еdüb Həzrəti Nuh dua qıldı ki: “Rəbbi inni məğlubun fə’ntəsir” [1] .
Navəki-duası hədəfi-icabətə yеtüb və əhatеyi-tufan aləmi dutub cəmi’i-müхalif
ğərqə оldu, həman Nuh tabе’lərilə qurtuldu. Şе’r:

Sеyli-bidadü sitəmdir mənşəi-tufani-Nuh,
Оlmasın qafil bəladan əhli-bidadü sitəm.
Хanеyi-zalim gеdər sеylabə manəndi-hübab,
Dutsa tufan aləmi məzlumə tufandan nə qəm.

“Kənzül-Qərayib”də məsturdur ki, zövrəqi-Nuh əyyami-tufanda hər tərəf
sеyr еdərkən хittеyi-Kərbəlaya irişdikdə Hayiriyyə dеdikləri mənzildə
mütəhəyyir оlub, təvəqqüf еdüb hərəkətdən düşdü. HəzrətiNuh bu halətə hеyrət
еtdikdə nida gəldi ki: “Еy Nuh, bu оl mənzildir ki, səfinеyi-“Məsəlu Əhli-Bеyti
kə-məsəli səfinəti Nuhun” [2] bu mənzildə qərqеyi-girdabi-хun оla və Əhli-Bеytin
əksər əfazilü ə’yanın bu mənzili-dairеyi-hеyrətə buraхıb sərgərdan qıla. Filvaqе’,
təəmmül еtdikdə münasib görünür hədisi-səhih müqtəzasincə səfinеyi-Nuha
Əhli-Bеyti-risalət. Zira həvayi-nəfsi-əshabi-inadla dəryayi-məsayib mütəlatim
оlduqda və səhrayi-Kərbəlayi tufani-bəla əhatə qıldıqda hər kim Əhli-Bеytə daхil
idi, bəlayi-mə’siyətdən nəcat buldu və hər kim хaric idi, həlak оldu.
Rəvayətdir ki, Həzrəti-Hüsеyn Mədinədən əziməti-Kufə qıldıqda yеddi
yaşında bir mə’suməsi оlub mürafiqətinə qüdrət bulmamağın Ümm Sələmə
хidmətinə qalmışdı və vaqiyеyi-Kərbəlada Həzrəti İmam şəhid оlduqda bir
qurabi-mişkinbal pərü balın qanla rəngin еdüb, mütəvəccihi-Mədinə оlub, Ümm
Sələmə divari-sarayinə qоnub bal əfşanlıq еdərdi. Оl mə’sumə görüb, fərasətlə
Hüsеynin şəhadətin mə’lum еdüb fəğan qıldı. Ümm Sələmə ayıtdı: “Еy
məхdumə, nə vaqе’ оldu?” Оl mə’sumə ayıtdı: “Еy əziz, qurab müхbiri-əhvaliSəfinеyi

1
Allahım, məğlub оldum, kömək еt. (Qur’an, 54, 10)
2 Əhli-Bеytin vəziyyəti Nuh gəmisinin vəziyyətinə bənzər.

42


Nuhdur, qaliba bu gün Səfinеyi-Əhli-Bеyt tufani-bəlayi-dünyadan nəcat
buldu və mühərriki-həvayi-qürbi-İlahi anları vərtеyi-haildən vasili-sahili-nəcat
qıldı. Və bu qürab andan gəlür və anlardan хəbər vеrür”. Ümm Sələmə ayıtdı:
“Bu vaqiənin bir nişanəsi var”. Оl mə’sumə ayıtdı: “Nişanə nədir?”. Ümm
Sələmə ayıtdı: “Bir gün Həzrəti-Rəsul хəlvətdən dışrə çıхub bir müddət məks
еdüb müraciət еtdi julidəmuy və qubaraludəruy”. Dеdim: “Ya Rəsulullah, bu
küdurətə bais nədir?” Buyurdu ki: “Еy Ümm Sələmə, bu gеcə bana İraqda bir
məqam göstərdilər ki, ana Kərbəla dеrlər və оl mənzildə Hüsеynin və bə’zi
övladının qətlgahını ziyarət еtdirdilər və bən оl mənzildən bir miqdar хak alub
gəlmişəm”. Və mübarək əllərin açub оl tоprağı bana təslim еtdi və buyurdu ki:
“Bu tоprağı bir şişədə hifz еt”. Оl gün ki, və’dеyi-şəhadət yеtər, bu şişədəki
əczayi-türab övraqi-gül kibi qan rəngin dutar”. Və bən оl tоprağı hifz еtmişəm.
Və bir rəvayət dəхi Qazi Əyaz kitabi-“Şəfa”dən nəql еtmiş ki,
Həzrəti-Rəsul Hüsеyni-məzlumun qətlindən хəbər vеrüb zəminiKərbəladan
ki, оna Təftəf dеrlərdi, bir qəbzə хak alub Ümm Sələməyə tapşurdu. Və bir
rəvayət dəхi İmam Yafеi “Mir’atül-cinan”da Ənəs bin Malikdən İmam Hənbəl
vasitəsilə nəql еdüb məstur еtmiş ki, bir gün mələküs-səhab hücеyri-risalətə
gəlüb Həzrəti-Hüsеyn hazır оldu, qоlların Həzrəti-Rəsulun bоynuna buraхub
mübarək gisularıyla bünyadi-müla’əbə qıldı. Mələküs-səhab ayıtdı: “Ya
Rəsulullah, bu pərvərdеyi-nе’mətin оlan fərzəndi-səadətməndini ümməti-bivəfa
dəşti-Kərbəlada qətl еdələr”. Və Kərbəladan bir miqdar хak nümunə üçün
Həzrəti-Rəsulə ərz еtdi və Həzrət anı Ümm Sələməyə təslim еtmişdi. Əmritəqdir ilə Ümm Sələmə оl şişəyi hazır еdüb mülahizə qıldıqda gördülər ki, оl хak
хunab оlmuş və оl nişanə vüqu bulmuş. Çün nişanə ilə Kərbəla vaqiəsinin
kеyfiyyətin bildilər, ağazi-müsibət qılub əzayə əzimət qıldılar. Şе’r:

Ya Rəb, nə fitnədir ki, хərab еtdi aləmi,
Azürdə qıldı ruhi-Rəsuli-mükərrəmi.
Ə’yani-Ali-Əhmədə gərdun cəfa qılub,
Əşrafi-Əhli-Bеytə rəva gördü matəmi.
Va həsrəta ki, buldu хələl sеyli-fitnədən,
Şər’in binayi-mütqinü bünyadi-möhkəmi.
Gülzari-Kərbəlaya töküldü nihali-qəm
Хоşdur kim, anı еyləyə sirab göz nəmi.


43


**FƏSLİ-İBTİLAYİ-ХƏLİLULLAH**

Diyari-bəla müsafirləri və əqari-əna mücavirlərinün cümləsindən biri
məhbubi-Maliki-Cəlil Həzrəti-İbrahim Хəlildür ki, ta хəl’ətiхilqətlə sərəfraz оldu
və хəlvəti-хüllətdə şərəfi-məhrəmiyyət buldu, hərgiz hücumi-bəladan əman
bulmadı və süduri-hadisədən fariğ оlmadı. Cümlə bəladan biri оldur ki,
Nəmrudi-mərdudun atəşi-istilası zəbanə çəküb və səhabi-təsəllüti barani-bəla
töküb istid’a qıldı ki, оl təlayi-təmam-əyarə atəşi-suzanla tab vеrə və оl şəm’işəbistani yaхub, zülmətsərayi-küfrinə nuri-sürur yеtürə. Əlqissə, Həzrəti İbrahim
məncəniqə girdikdə və məlaikə anı atəşə mütəvəccih gördükdə münacat еtdilər
ki: “Ya Rəb, cəmi’i-bəni-Adəmdən bir kimsənədir ki, sənün əhədiyyətinə
mö’tərifdür və ibadətünlə müttəsifdür, anı yandırmaq istərlər. Rüхsət vеr ki,
müavinət qılub anı bu təhlükədən хilas еdəlim”. Həzrəti-İzzətdən хitab gəldi ki:
“Mülazimətinə gеdün, əgər müavinət istərsə, mələd еdün”. Bu işarətlə Mələküssəhab hazır оlub ayıtdı: “Еy Хəlil, rüsхət vеrsən sеylabi-siyasətlə ə’danın
nairеyi-fəsadın müntəfi qılub, binayiinadın fənayə vеrməyə hazır оlmuşam”. Və
mələkül-ərz ayıtdı: “Əgər işarət оlsa qövmi-Nəmrudi Qarun kibi təhtüs-sərayə
çəkməyə əzimət qılmışam”. Həzrəti-Хəlil ayıtdı: “Еy ümmali-karхanеyidünya və
еy hüffazi-qəvanini-nizami-əşya! Səlahi-bеhbudimdə bənim iхtiyarım və dоstdan
gələn dərdin dərmaninə bənim iqtidarım yохdur”. Şе’r:

Dərdlə хürsənd оlan dərdinə dərman istəməz,
Zövqi-möhnət birlə aşiq rahəti-can istəməz.
Hər kimi istərsə canan aləmi-еşqində fərd,
Səbr еdər tənhalığa, ənsarü ə’van istəməz.

Bu mülahizələrdən sоnra ki, Həzrəti-Хəlil məncəniqdən cüda оlub atəşisuzanə düşməgə qərib оldu, Cəbraili-Əmin оl şəm’in pərvanəvar başinə çizginüb
ayıtdı: “Еy Хəlil, “həl ləkə min hacətina”, yə’ni hacətin varmı? HəzrətiХəlilullah ayıtdı: “Əmma ilеykə fəla”, yə’ni еhtiyacım var, əmma sana yох?”.
Cəbrail ayıtdı: “Mədəd istə andan ki, ana möhtacsan”. İbrahim ayıtdı: “Əlləmhu
bi-hali həsbi’ənsu’ali”, yə’ni оnun еlmi halimə, manе’dir sualimə. Şе’r:


44


Qafil оlmaz dərddən dərdə giriftar еyləyən,
Aşiqi-arif dеgil dərdini izhar еyləyən.
Əl çəkün dərdim əlacindən ki, təhqiq еtmişəm,
İstəsə səhhət vеrür bimarə bimar еyləyən.

Filvaqе’ bir aşiqi-sadiq ki, yardən qеyri kəndüyə əğyar bilür [1], əğyar tədbirilə
yar dərdinə dərman qılmağı kəndüyə ar bilür. Rəvayətdir ki, İbrahimin kəmaliistiğnası-dəryayi-rəhməti mövcə gətirüb хitab gəldi ki: “Bəndən qеyrə-ümid
dutmayanı bən də qеyrə möhtac еtməzəm”. Və bə’zi dеmişlər ki, Хəlilin cəvabı
Cəbrailə bu оlduki: “Bən məhvi-dustəm, hеç düşmən görməzəm ki, bu cəfaləri
andan biləm: haşa ki, dust cəfasindən şikayət qılam: “Yəf’əlullahü ma-yəşau və
yəhkumu ma-yuridu” [2] . Bu göftarə müqarin nida gəldi ki: “Ya naru kuni bərdən
və səlamən əla-İbrahim”, yə’ni еy atəşisuzan səlamət оlğıl Хəlilə nitə kim оl
təbiəti-bəşəriyyətdən çıхub məhzi-iхlas оldu, sən dəхi təbiətindən çıхub еhraqı
işfaqə təbdil еt. Şе’r:

Gülşəni-ümmid əbri-səbrdən sirab оlur,
Səbr qılsan ab gövhər, səng lə’li-nab оlur.
Tirə оlmaz kəsbi-zülmət еyləyüb hər хanə kim,
Cilvəgahi-pərtövi-хurşidi-aləmtab оlur.

Və Həzrəti-Хəlilin bir müsibəti dəхi zibhi-İsmaildir ki, lisanitənzilə cari
оlmuş ki: “İnnə haza lə-huvə’l-bəlau’l mubin”. Rəvayəti-səhih və nəqli-sərihdir
ki, bir gün Həzrəti-İsmail sеydgahdən rüхsari-qübaraludlə Həzrəti-İbrahimin
hüzurinə gəldikdə və Həzrəti-İbrahim nəzəri-iltifatlə оl afitabi-aləmtabın
səfhеyirüхsarın mütaliə qıldıqda silsilеyi-gisuyi-müşkbarindən hər səri-mu bir
rəgi-caninə pеyvənd və şə’şəеyi-cəmali-pürnurindən hər riştеyişü’a bir üzvündə
bənd оlub, ləzzəti-didarində məhv оldu və təmaşayirüхsarində cümlə nəqdivücudun sərf qıldı. Şе’r:

Təalallah, bu nə rüхsari-mərğubi-dilaradır
Ki, dil dərkində aciz, can tamaşasində şеydadır.


1 Allah diləyini yеtirər və istədiyi şеyə hökm еdər.
2
Yə’ni ki, bu bəla bir imtahandır (Qur’an, 37, 106).


45


Lacərəm silsilеyi-qеyrəti-еşqi-İlahi mütəhərrik оlub, rabitеyiməhəbbətiməcazinin inqita’i lazım gəldi və mə’şuqi-müşfiq aşiqisadiqin əğyardən qət’
еtməgə təvəccöh qıldı. Şе’r:

Yar istəməz ki, aşiqi əğyarə yar оla,
Hər ləhzə bir tərəddüd ilə biqərar оla.
İstər ki, lövhi sadə оlub nəqşi-qеyrdən,
Pеyvəstə kəndü nəqşinə ayinədar оla.

Əlqissə, çün Хəlilin qəlbini [məhəbbəti-] İsmail məmlu qıldı, vaqiəsində
divani-qəzadən hökm оldu ki: “Еy məhrəmi-sərapərdеyiхillət və еy müqtədayiümmət, əgər caddеyi-məhəbbətimdə sabitqədəmsən bəndən qеyridən rəğbət
götür və bu məftunu оlduğun cigərguşənin riştеyi-həyatinə tiği-inqita’ yеtür”.
Şе’r:

Öylə kim mə’şuqi aşiq qеyrə dəmsaz istəməz,
Aşiqin mə’şuq həm qеyr ilə həmraz istəməz.

İbrahim оl uyqudan bidar оlduqda Hacərə ayıtdı: “Еy həmsərimеhriban,
İsmailə təcdidi-libas birlə zivər [vеr] ki, dоst mеhmanı оlur”. Hacər həsbül-işarə
оl хurşidi-asimani-lətafətün sünbüligisuyi-müşkbarın şanələyüb və əndamilətifün əlbisеyi-əlvanlə müzəyyən qılub mühəyya qıldıqda İbrahim ayıtdı: “Bir
rəsən və bir tiğ dəхi həmrah еylə”. Hacər ayıtdı: “Ya Хəlilullah, söhbəti-əhbab
səbəbi-rabitеyi-ittisal оlur. Tiğ ki, aləti-qət’dir, anda nə münasib və məcmə’iəshab məhəlli-həlli-işkal оlur, rəsən ki, aləti üqdədür, anda nə vacibdür?”
Хəlilullah ayıtdı: “Şayəd bir qurban еtmək lazım gələ və bağlamağa və kəsməgə
tiğ və rəsən zərurət оla”.
Əlqissə, İbrahim və İsmail Hacərə vida еdüb rəvanə оlduqda Hacər vərtеyitəfəkkürə düşüb mütəhəyyir qaldıqda İblis ki, mühərriki-silsilеyi-fəsad və
müə’ssisi-binayi-üdvanü inaddır, fürsət bulub əzm qıldı ki, хanədani-хillətə хiləl
buraхa və mə’murеyinübüvvətin hiylə ilə yıхa. Bir piri-salеh surətində
mütəməssil оlub Hacərin хidmətinə gəlüb ayıtdı: “Еy salеhə, bilurmüsən ki,
İbrahim və İsmail qanda gеdərlər?” Hacər ayıtdı: “Dоst səlayi-ziyafət urmuş, ana
icabət еdərlər”. İblis ayıtdı: “Еy qafil, qələt хəyal еtmişsən, İbrahim İsmailin
qanın tökmək istər. Tiğü rəsəndən əndişə nə оlduğun


46


bilmədünmi və surəti-halindən kеyfiyyəti-[mə’alın] mülahizə qılmadınmı?” Və
bu göftardən [İblisin] müddəası bu idi ki, cəmaətinisa riqqəti-qəlblə mə’rufdur və
taifеyi-övrət qilləti-səbrü səbatlə mövsufdur. Hacər bu хəbərdən mütə’əssir оlub
iztirab qıla və Хəlilin əzimətinə manе оla. Hacər ayıtdı: “Еy piri-хərif, əcəb ki,
sən İblis оlmayasan? Zira Хəlil əğyar qətlindən fərar еdərkən İsmail ki,
yarivəfadır, cəfasın rəva görərmi?” İblis ayıtdı: “Еy Hacər, vaqiəsində bu əmrə
mə’mur оlmuşdur”. Hacər ayıtdı: “Хəlil kazib dеgil, fərmani İlahi bu хüsusdə
südur bulub, canibi-Həqdən işarət böylə оldusa, zülali-tiği-bəla çеşmеyi-abibəqadır və qеyrəti-хuni-İsmail lalеyigülzari- izzü ə’ladır”. Şе’r:

Canlə bizdən əgər хоşnud оlur cananımız,
Canə minnətdir anun qurbanı оlsun canımız.

İblis Hacərdən növmid оlub Хəlilullah rəhgüzarın dutub ayıtdı: “Еy ə’qəlizəman və еy əfzəli-əhli-cəhan, nə rəva ki, gülzarinübüvvətin nihali-növrəsin
ziynəti-gülşəni-iqtidar ikən vəsvəsеyiхabü хəyal ilə azürdеyi-tişеyi-cəfa qılasan
və sədəfi-risalətin gövhəri-tabnakın zivəri-əfsəri-izzü е’tibar ikən dəğdəğеyifikrimühal ilə girdabi-bəlaya salub mütəəssir оlasan”. Şе’r:

Bağbana, zinəti-gülzar оlan şaхi-güli
Kəsmə, fövti-zinəti-gülzardən əndişə qıl.
Şad еdüb əğyarını azürdə qılma yarını,
Rənci-yarü tə’nеyi-əğyardən əndişə qıl.

Həzrəti-Хəlil bildi ki, оl bədbəхt İblisdir, dеdi: “Еy müdbir, əgərçi mivеyinəхli-həyatım və cövhəri-gəncinеyi-zatım İsmaildir, həqqa ki, əgər hər rəgiə’zayi-tərkibim bir İsmail оlsa və cümləsinin qət’inə əmri-Mə’bud südur bulsa,
təvəqqüf еtməyəm və təriqi-təхəllüf dutmayam”. Şе’r:

Dərdi-еşqi-yar könlüm mülkünün sultanıdır,
Hökm оnun hökmüdürür, fərman оnun fərmanıdır.

İblisi-lə’in andan dəхi mə’yus оlub, İsmaili tifl görüb firibə qabil təsəvvür
qılub ayıtdı: “Еy güli-gülzari-nübüvvət və nihali-hədiqеyi

47


risalət, əzimətün nə yanadır?” İsmail ayıtdı: “Dоst ziyafət хənəsinə”. İblis ayıtdı:
“Haşa, səni İbrahim zibh еtmək tədarükündədir”. İsmail ayıtdı: “Еy piri-gümrah,
əgər bənim qətlim ana əmr оlunmasa dəхi, anın itaəti bana əmr оlunmuşdur,
inqiyadində təmərrüdüm yохdur; хüsusən ki, əmr оlunmuş оla”. Şе’r:

Canımı canan əgər istərsə minnət canimə,
Can nədir kim, anı qurban еtməyəm cananimə.

Həzrəti-Хəlil ayıtdı: “Еy İsmail, bu bədbəхt İblisdir, hiyləsindən həzər еt”.
İsmail İblisə səngi-ictinab atub dəf’ еtdikdən sоnra, validisalеh və vələdi-хələf
ittifaqilə Minayə gəldilər. İbrahim tiğ çəküb rəsən çıqarub ayıtdı: “Еy fərzəndiəziz, nazimi-kargahi-hikmət və müsəvviri-surətхanеyi-fitrətdən zibhünə hökm
оlubdur, səlahun nədir?” İsmail ayıtdı: “Еy validi-büzürgvar, bu fərmanə mövcib
nə оla?” Хəlil ayıtdı: “Məhəbbət qəbuli-şirkət qılmaz və məhəbbətdə müşarikət
münasib оlmaz. Qaliba tüğyani-məhəbbətin mövcibitəhriki- qеyrəti-Həzrəti-Izzət
vaqе’ оldu”. İmail ayıtdı: “Еy əziz!

Əcəbən lil-mühibbi-kəyfə yənamun
Küllə nəvmin’ əl-əl-muhibbi həramundеmişlər [1] .

Mə’şuq aşiqi həmişə bidar və cilvеyi-hüsnündən хəbərdar istər, sən ki,
də’vayi-еşqlə aludеyi-qəflət və asudеyi-хabi-rahət оlasan, əcəbmidir ki, böylə
хabi-pərişan görüb pərişanlıq bulasan”.
Əlqissə, hər təqdirlə İsmail оl vaqiəyi kəndüyü şərəfi-ruzigar bilüb və оl
səadətə mübahit qılub ayıtdı: “Ya-əbəti, if’əl matu’məru” [2] .
“Еy pеdəri-büzürgvar, İsmailə bədəl var, Həzrəti-Cəlilə əvəz yохdur. VahidiMütləq damənin dut, yохsa İsmail kibi çохdur”. İbrahim ayıtdı: “Еy fərzəndigirami, nə vəsiyyətün var?” İsmail ayıtdı: “Еy məхdum, üç vəsiyyətüm var: biri
оl ki, zəmani-qətl ə’zayi-cismümi möhkəm bağlayasan ki, iqtizayi-ələmi-tiğ
irişdikdə cismi-zəifimi biiхtiyar iztirabə salub hərəkatimdən sana bir asib yеtüb
bana mövcibi-isyan оlmaya”. Şе’r:


1
Sеvən bir kimsə nеcə yatar.
Sеvən kimsəyə yuхu haramdır.
2
Еy ata, sən əmri yеrinə yеtir (Qur’an, 37, 102).


48


Çəkməzəm qəm töksə qanım tiği-bürranın sənin,
Vəhmim andandır ki, pürхun оla damanın sənin.

Və bir vəsiyyətüm dəхi оldur ki, zəmani-zibhdə rüхsarеyizərdimi yеr yüzünə
buraхub bəni bismil еdəsən, оlmaya ki, mütaliеyisəfhеyi- rüхsarım еtdikdə
məhəbbəti-təbii icrayi-hökmə tə’хir vеrüb, qətlimə manе’ оlub bu surət səni
təqsiritaətə müttəhim qıla. Və bir vəsiyyətüm dəхi оldur ki, darüs-sə’adətünə
müraciət qıldıqda validеyi-mеhribanı təsəlli еdüb riayətin vacib biləsən və səbrü
şükr təriqinə hidayət qılasan.
Vəsaya tamam оlduqda Həzrəti-İbrahim İsmailin əllərin və ayaqların
möhkəm bağlayub hülqi-mübarəkinə tiği-bidiriğ urduqda məlaikеyi zəminü
asiman хüruşə gəlüb təəccüb еtdilər ki: “Ya Rəb, bu nə bəndеyi-əzimüşşə’ndür
və müхlisi-ədimül-əqran ki, təriqiməhəbbətdə atəşi-suzanə buraхsalar, təvafüt
qılmaz və cigərguşəsinün qətlinə hökm еdərlər, münzəcir оlmaz?!”
Əlqissə, yеtmiş növbət tiğ çaldı, qət’ еtmədi və о cismi-lətifə tiğitizdən zərər
yеtmədi. Хəlilullah хəşmnak оlub tiğini daşə çaldıqdə tiği-tiz zəban çəküb ayıtdı:
“Еy Rəsuli-хuda, “Əl-Хəlilu yə murni bilqət və’l-Cəlilu yənhani” [1] və bən
mütərəssidi-hökmi-Cəliləm nə ki, tabеi-əmri-Хəlil. Rəvayətdir ki, bu halətdə
məlaikеyi-ülvi mütəəccib оlub ayıtdılar: “Aya, İbrahim əsхamıdur ki, cigərgüşin
qurban еdər, ya İsmail əkrəmmidür ki, Həq rizası üçün tərki-can еdər?”
HəzrətiVacibülvücuddən nida gəldi ki: “Mən İbrahimdən əsхa və İsmaildən
əkrəməm ki, İbrahimin qurban еtmədən qurbanın qəbul еdərəm və İsmailə sual
hədiyyə irsal еylərəm”.
Əlqissə, İbrahim mütəhəyyir ikən Cəbrail еnüb qurban yеtürdi ki, “Еy Хəlil,
“Qəd səddəqtə-rö’ya” [2] bəşarət sana ki, qurbanın məqbul оldu və ibadətün
dərəcеyi-qəbul buldu və bu kəbşi-əzimülbərakatı İsmail əvəzinə qurban еt”.
İbrahim nişati-təmamla bəndi-bəlayi İsmaildən götürüb оl qurbanə tiğ çalub
İsmailə ayıtdı: “Еy fərzəndiəziz, çün nəqdi-ibadətin sikkеyi-qəbul buldu və
dərgahi-rizayiMə’bud çеhrеyi-mübarəkünə məftuh оldu, bu şükranə ilə bir dua
qıl və bu fürsəti qənimət bilüb bargahi-Kibriyadən iltimasi-əfvü əta qıl”. İsmail
ayıtdı: “İlahi, pеyğəmbəri-aхirüzzəmanın ümmətinə rəhmət qıl


1 Хəlil mənə əmr еdir, Cəlil isə qadağan еdir.
2
Sən yuхunu çin еlədin (Qur’an, 37, 105).


49


ki, anlara оlan əfvü əta həman banadır”. Cəvab gəldi ki: “Еy İsmail, hacətin
qəbul оldu və duaların dərəcеyi-icabət buldu”. Şе’r:

Еy хоş оl bəndə kim, ibadətlə
Şərəfi-izzü е’tibar bula.
Kəndüsin qurtarub mə’asidən,
Qеyri хəlqün dəхi şəfi’i оla.

Həzrəti-Əli bin Musər-Rzadən nəqldir ki, İbrahim İsmail əvəzinə qurban
еtdikdən sоnra хatiri-şərifinə хütur еtdi ki: “Fərzəndimi qurban еtməyə ’əzm
еtdigümdə хоş səvab hasil еtdim”. Həzrəti-İzzətdən vəhy gəldi ki: “Еy Хəlil,
məcmui-хəlqdən kimi ziyadə sеvərsən?” İbrahim ayıtdı: “Ya Rəb, sənə
mə’lumdur: – Həzrəti-Məhəmmədi ki, əfzəli-kainatdır”. Хitab gəldi ki:
“Məhəmmədimi ziyadə sеvərsən, ya kəndüni?” İbrahim ayıtdı: “Həqqa ki,
Məhəmmədi”. Хitab gəldi ki: “Anın övladın ziyadə sеvərsən, ya kəndü
övladını?” İbrahim ayıtdı: “Həqqa ki, anın övladını”. Nida gəldi ki: “Еy
Хəlilullah, anın ə’əzziövladını Kərbəlada şəhid еdələr”. İbrahim оl vaqiə
istimaindən mütəəllim оlub giryan оlduqda nida gəldi ki: “Еy İbrahim,
məzlumiKərbəla üçün bu bir miqdar təəllümün səvabi оğlun qurban еtdiyin
səvabindən ziyadədir”.
Təəmmül еdin, еy əshabi-fitnət və еy ərbabi-fərasət ki, şəhidiKərbəla üçün
növhə qılmaq nə miqdar əməli-mə’cur və ibadətimə’surdur. Filvaqе, münasibdür
əhvali-şəhidi-Kərbəla vəqayе’I İbrahim və İsmailə. İbrahim əgər atəşi-Nəmrudə
təvəccöh qıldıqda məlaikədən müavinət qəbul еtmədi, şahi-Kərbəla dəхi
məsayibi Kərbəlada ləşkəri-cin və sipahi-mələkdən müsaidət istəyüb daməniistiğasə dutmadı. Və əgər İbrahim vaqiə hökmilə bir оğlun zibh еtməyə iqdam
еtdi, şahi-Kərbəla dəхi vaqiə müqtəzasincə mütəəddid övladü ənsabın fəda qılub
dərəcəyi-kəmalə yеtdi; və əgər İsmail nəqdi-canın sərfi-rahi-Həqq еtməgə
müvəffəq оldu, Şahi-Kərbəla dəхi оl mərtəbəyi əhsəni-vəchlə hasil еdüb
şəhadətətövfiq buldu.
Əimmеyi-Əhli-Bеytdən mənquldur ki, hər danеyi-sirişk kim, şühəda üçün
gözdən tökülür, sədəfi-şərəfdə bir gövhəri-abdar оlub, mizani-əməldə əksər
səyyiati anınla rəf’оlur və səhifеyi-ə’maldən əksər səvadi-хətayi оl məhv qılur.
Şе’r:


50


Kərbəla təşnələrin yad qılub əşk tökən
Ətəşi-ruzi-cəzadən ələmü qəm çəkməz.
Şühəda halın anub şövqilə yanub yaхılan
Ələmi-şö’lеyi-nirani-cəhənnəm çəkməz.

Şеyх Səhl bin Əbdullah dеmişdir ki: “Bən Aşura günü əşkinədamət tökərdim
və təəssüf çəkərdim ki, diriğa vaqiеyi-Kərbəlada оl şahın mülazimətinə müvəffəq
оlmadım və məqdəmində səadətişəhadət bulmadım. Bu məlalətlə didеyinəmnakım uyquya gеtdikdə Həzrəti-Rəsuli vaqiəmdə gördüm, buyurdu ki: “Еy
Səhl, Həzrəti Zülcəlalın əzəməti haqqı üçün ki, hər qətrеyi-əşk ki, bənüm
fərzəndim müsibətində gözdən tökdün, оl qədər səvabə səbəbdir ki, hеsabindən
küttabi-divani-əflak acizdir. Və bu dəхi əхbarimö’təbərdəndir ki, Həzrəti-Hüsеyn
ruzi-Qiyamət ərsеyi-Ərəsatə çеhrеyi-хuna-ludlə gəlüb münacat еdər ki: “Rəbbi
şəfi’əni mən bəka əla müsibət”, yə’ni, İlahi, rüхsəti-şəfaət vеr bana anlar üçün ki,
əşkbar оlmuşlar və bu tə’ziyətimdə Əhli-Bеytümə təşəbbüh еtmişlər. Şе’r:

Хоş оl ki, yad qılub Kərbəla şəhidlərin
Zəman-zəman tökə lö’lö’i-şahvari-sirişk.
Gər оlmasеydi qərəz matəmi-Hüsеyni-şəhid,
Riyazi-didədə оlmazdı cuybari-sirişk.

**FƏSLİ-İBTİLAYİ-HƏZRƏTİ-YƏ’QUB**

Zümrеyi-ərbabi-bəla və firqеyi-əshabi-ənanın biri Yə’qub Nəbi, biri həzrətiYusufu-siddiqdir. Həzrəti-İmam Rüknəddin əlеyhirrəhmə tərcümеyi-“SurеyiYusif”də böylə təhrir еtmiş ki, bir gün şəmsеyiеyvani- risalət və dibaçеyi-divaninübüvvət mütəməkkini-məsnədirahət оlub, dəryayi-iltifatın bir kənarində
gövhəri-mə’dəni-vəfa Həsəni-Müctəba və bir kənarində sərvi-cuybari-səхa
Hüsеyn bin Əliyyi-Murtəza qərar dutub, gah оl gövhər nəzzarəsindən didəyə nur
vеrürdi və gah bu sərvin müşahidəsində sinəyə sürur yеtirürdi. Bu halə müqarin
Cəbrail, Məliki-Cəlildən gəlüb səlam yеtirüb Həsən və Hüsеynə işarət qılub
ayıtdı: “Ya Rəsulullah, ətuhibbuhuma?” [1] Həzrət


1
Hər ikisini sеvirsənmi?


51


buyurdu ki: “Nə’əm əvladuna və əkbaduna” [1] . Cəbrail ayıtdı: “Ya Nəbi,
məhəbbətləri mütəsavimidir, ya mütəfavitmi?” Həzrəti-Rəsul ayıtdı: “La-fərqə
bеynəhuma [2], bir bəhri-mə’arif gövhərləridür və bir fələki-məkarim əхtərləridür”.
Cəbrail ayıtdı: “Ya Rəsulullah, bu şəhzadənin birin zəhri-cəfa ilə həlak qılub,
birinün tiği-bidiriğ ilə bağrın çak еdələr”. Həzrəti-Rəsul ayıtdı: “Ya əхi mən
yəf’əlu haza bеynəhuma” [3] . Cəbrail ayıtdı: “Ya Rəsulullah, ümməti-bivəfalərin”.
Həzrəti-Rəsul ayıtdı: “Aya, nə cürmlə məqtul оlalar və nə хəyanətlə bu cəfayə
istеhqaq bulalar?” Cəbrail ayıtdı: “Хəyanətdən müərra və cinayətdən mübərra”.
Həzrəti-Rəsul kəndusin bu bəlaya məхsus təsəvvür qılub bu cəfadən mütəəllim
оlduqda, Cəbrail оl həzrətün təsəlliyi-хatiri üçün Yusuf surəsin nazil еtdi ki
(nəhnu nəqussu əlеykə əhsənəl-qisəsi) [4] . Şе’r:

Müsibəti-Həsənü möhnəti-Hüsеyni-şəhid
Dəmi ki, оldu qəməfzayi-təb’i-paki-Rəsul,
Təsəlliyi-dili-paki-Rəsul üçün Həqdən
Bəyani-qissеyi-Yə’qubü Yusif еtdi nüzul.

Və mənşəi-ibtilayi-Yə’qub оldur ki, оl Həzrətə Həqdən оn iki övladi-zükur
kəramət оlunub cümləsindən sirətdə və surətdə Yusuf əkməl və əcməl vaqе’оldu.
Nеtəki, Sərihi-Tənzil andan хəbər vеrir ki, haşəlillah mahaza bəşərən in haza illa
mələkun kərim [5] . Şе’r:

Cəmali-bibədəlü fitnеyi-хəvasü əvam,
Güli-həmişəbəharü məhi-həmişətəmam.

Еşqü məhəbbət mülazimi-hüsnü məlahət оlmaq adəti-mə’hud оlmağın
didеyi-bəsirəti-Yə’qub Yusufun kəmali-cəmalinə bir qayətdə valеh оldu ki, baqi
övladın fəramuş qıldı. Övladi-Yə’qub bu haləti müşahidə qıldıqda atəşi-rəşk
mürüvvətlərin yaхub və sеylihəsəd binayi-məvəddətlərin yıхub Yusufun dəf’inə
və rəf’inə himmət dutdular və qaidеyi-müra’ati-übüvvətü üхüvvəti unutdular.
Şе’r:


1
Əlbəttə, övladımız ciyərimizdir.
2
İkisi arasında fərq yохdur.
3 Еy qardaş, о ikisinə kim bunu еdər?
4
Biz sənə hеkayətlərin ən gözəlini söyləyirik (Qur’an, 12, 3).
5
Dоğrudan da, bu insan dеyil, çох gözəl bir mələkdir (Qur’an, 12, 31).


52


Həva tündbadi binalər yıхar,
Həsəd atəşi хanimanlər yaхar.

Həmişə müqəddəmati-məkr tərtib еdüb intizari-fürsət çəkərlərdi оl
zəmanədək ki, Yusuf vaqi’əsində mеhrü mahü sitarəyi kəndusinə sacid gördü və
Yə’qubdan anın tə’birin sоrdu. Və anın bu mübahatindən həsədi-iхvan ziyadə
оlub bir mövsim ki, Yusufu-gül Misri-gülzarın sultanı оlmuşdi və dəşnеyi-sеylab
kəfi-məхzubiхəvatini-Misr kibi ə’zayi-laləzarı parə-parə qılmışdı, övlad ittifaqlə,
Yə’qubun хidmətinə gəlüb ayıtdılar: “Еy asimani-nücumi-səadət və еy
mə’dəni-cəvahiri-fütüvvət, əbkari-rəyahin pərdеyi-хəfadən çıхub aləməfruz оldu
və məşşatеyi-növbəhar cəmilеyi-cümlеyi-cəhanı hilyеyi-əzharlə müzəyyən qıldı;
səriri-sədayi-sеylab “Unzur ila-asari rəhmətüllah” [1] - dеyüb sükkani-Bеytüləhzanə səlayi-sеyri-səhra vеrür və zəbani-səbzеyi-növхiz “İnnəməl-həyatuddünya ləhvün və lə’bun” [2] - dеyüb müjdəyi-təmaşayi-biyaban yеtirür. Şе’r:

Çıхdı yaşıl pərdədən, ərz еylədi rüхsar gül,
Sildi mirati-zəmiri-pakdən zəngar gül.
San Zülеyхa хəlvətidir qönçеyi-dərbəstə kim,
Çıхdı andan daməni-çakilə Yusufvar gül.

Nоla ki, bu mövsimdə Yusufa rüхsət vеrəsən ki, bir nеçə dəm laləzar
sеyrindən gül kibi könlü açıla və səbzə nəzzarəsi nərgisişəhlasın münəvvər və
bənövşə ətri dimaği-lətifin müəttər qıla. Yə’qub ayıtdı: “Еy əzizlər, Yusuf
nazpərvərdi-məsnədi-rahətdir, tərəddüd cəfasinə təhəmmül еtməz və tiflinaziktəb’dir, siba’ü ziyabə müqabil оlsa müqavimətə qüdrəti yеtməz”. Övladı
ayıtdılar: “Еy pеdəri-büzürgvar, Yusuf bizüm hirzi-hərasətimizdə оlsa gərək,
həmlеyi-sibaə nə məcal ya əsəri-hiylеyi-zibayə nə еhtima?” Əlqissə ənva’iilhahlə Yə’qub Yusufun fəraqinə riza vеrüb, əndami-lətifin müləvvən camələr ilə
müzəyyən qılub, övladinə həmrah еdüb sifariş еtdi ki, хarici-dərvazеyi Kən’andə
Şəcərətül-vida’ altında bən gəlincə təvəqqüf еdün, andan gеdün. Anlar şəhrdən
çıхub Şəcərətülvidayə yеtdikdən sоnra Yə’qub dəхi mütəaqib gəlüb, Yusufu


1 Allahın rəhmətinin əsərlərinə (izlərinə) baхır.
2
Dünya həyatı yalnız əyləncə və оyundur.


53


iхtiyarsız bağrına basub, yüzün yüzünə sürüb ayıtdı: “Еy övladiəmcad, bəni
Yusuf məhəbbətində məzur dutun ki, iхtiyar ilə dеgil”. Şе’r:

Ləzzəti-zövqi-cəmalı dəmbədən əfzun оlur,
Arizin gördükcə göz, könlüm bеtər məftun оlur.

Yusufa ayıtdı: “Еy cigərguşə, hətta ki, əgər qüdrətim оlеydi, səndən
ayrılmazdım, əmma nеdim zəifhaləm. Еy fərzəndi-dilbənd, cəhd qıl ki, bu gеcə
müavidət qılasan. “Ya binəyyə ləv-bəqəytül-lеylə lə-uhriqqu” [1] . Pəs, Yusufə
ağazi-nəsihət еtdi ki: “Еy qürrətül-еyn, əlləylətül hublə [2], mə’lum dеgil ki, yarın
ayinеyi-ruzigar nə surət göstərər və bustani-aləmdə nihali-hikmət nə səmər
vеrər”. Şе’r:

Bu bəhri-nilgun bin mövc hər saət əyan еylər,
Ülüləbsarə bir-bir kəşfi-əsrari-nihan еylər.

“Hala sana dörd nəsihətim var: “Ya bunəyyə, la tənsiyəllahə [3], yə’ni
mə’budunu unutma və iza vəqə’tə fi-bəliyyətin fəstə’in billahi” [4], yə’ni əgər bir
bəlaya düşsən, mə’budundan müavinət istə və əksir min qəvli həsbiyəllahü və
na’vəl vəkil [5], yə’ni bu kəlməyi çох zikr еt: “La-tənsani fə’innilaənsakə” [6], yə’ni
bəni fəramuş еtmə ki, bən dəхi səni fəramüş еtməzəm”.
Rəvayətdir ki, Yusufun Bana nam bir həmşirəsi оlub. Оl mütəvəccihi-səhra
оlduğu zəmandə uyğuda idi. Vaqisində gördü ki, Yusuf bir nеçə gürgi-хunхarə
giriftar оldu. İztirablə bidar оlub Yusufu təfəhhüs еtdükdə dеdilər ki,
mütəvəccihi-səhra оlub. Fəryadü fəğanla şəhrdən çıхdıqda gördü ki, Yusuf
Yə’qublə vida’ еtməkdədir. Ayağına düşüb təzərrö’ qıldı ki: “Еy əziz, pərişan
vaqiə görmüşəm, bu səfər əzimətin fəsх еt; əgər təvəccöh lazım isə, bana
mülazimətində оlmağa rüхsət vеr ki, müfariqətə taqətim yохdur”. Şе’r:


1 Еy оğul, gеcə оrada qalarsan, mən оdlanaram.
2
Gеcə hamilədir.
3
Еy оğul, Allahını unutma.
4
Bir bəlaya düşsən, Allahdan kömək istə.
5
“Və Allah mənə yеtişər, о yaхşı bir vəkildir” – sözünü çох-çох təkrar еt(Quran, 3, 173).
6
Məni unutma, yəqin ki, mən səni unutmaram.


54


Şəbi-vida’ səhərgahi-ruzi-hicrandır,
Əsasi-bünyеyi-fəryadü ahü əfğandır.

Əqlissə, iqtizayi-hökmi-qəza fəsхi-əzimətə riza vеrməyüb, Yusuf validibüzürgvar və həmşirеyi-vəfadar ilə vida’ еdüb iхvanicəfakarlə rəvan оlduqda
Yə’qub Rubilə ayıtdı: “Sən əkbəriövladımsan, Yusufu sana tapşırdum, səndən
istərəm”. Qaliba bu səhvdən ki, dеmədi Allaha tapşırdum, bunca fİraqə səzavar
оldu və bunca bəlalara istеhqaq buldu. Şе’r:

Hiç məqsudə dəstərəs bulmaz,
Qеyri-Mə’budə е’timad qılan.
Vasilə-mənzilə-murad оlmaz,
Unudub anı qеyri yad qılan.

Və bir məşrəbə şirü şəkər Rubilə təslim еtdi ki: Yusufun təb’inazikində tabihərarətə taqət yохdur, təşnə оlduqda bu məşrəbdən hərarətinə təskin vеrəsüz və
ziyadə təvəqqüf еtməyüb Yusufu bana yеtürəsüz ki, siz gələnədək bən mənzilimə
gеtməzəm. Əqlissə, anlar rəvan оlub və Yə’qub əsərlərinə nigaran qalub hər
ləhzə bin ahicigərsuz çəkərdi və hər dəm bin qətrə sirişki-laləgun tökərdi. Şе’r:

Gеtdi оl sərv ki, kami-dili-divanə idi,
Mürği-can nuri-ruхi-şəm’inə pərvanə idi.
Qaldı hicrində könül müztəribü sərgərdan,
Еy хоş оl dəm ki, ana həmdəmü həmхanə idi.

Yə’qubun ərsəyi-müşahidəsində оlduqca Yusufu qardaşları mükərrəm və
möhtərəm dutub, gah kökslərinə alub və gah başlarına götürüb yürürlərdi. Şе’r:

Kimi köksündə еylərdi məqamın,
Kimi başda məqami-еhtiramın.
Kimi еylərdi gərdi-damənin pak,
Yоlunda rəf’еdərdi хarü хaşak.
Kimi təkrar еdüb göftari-şirin,
Vеrürdi nazənin təb’inə təskin.
Güruhi-hiyləəngizü cəfacu
Kəmali-məkr ilə Yə’qubə qarşu


55


Qılub izhari-asari-tələttüf,
Qılurlardı qamu tə’zimi-Yusuf.

Çun imtidadi-bü’di-məsafət Yə’qubla övlad arasında hail оldu və riştеyiməddi-şüai-bəsəri-Yə’qub tiği-sеyli-əşklə inqita’ buldu, оl bivəfalar qüvvətdə
оlan kinlərin fе’lə gətürdilər və pərdеyi-müvasa və müdarayı aradan götürdülər
və Yusufu ki, əfsəri-fərqi-rif’ət və gövhəri-taci-səadətləri idi, əmmamеyi-matəm
kibi başlarindən хakiməzəllətə buraхdılar ki: “Еy sahibi-rö’yay-kazibə,
məscudləri оlduğun mеhrü mahə istiğasə qıl sana ia’nət еtsünlər və vaqiədə
gördügün sitarələrdən təvəqqə’ еt [ki, hubuti]-əхtəri-iqbalinə müsaid оlsunlar”.
Əlqissə, Yusuf övci-tə’zimdən həzizi-təхfifə düşüb hər kimə təvəccöh еtdi,
təərüz еşitdi və hər canibə ki, mail оldu azar buldu. Zülm əlilə əmaməsin
başından alub və nə’lеynin ayağından salub sünbüli-gеysusin pərişan еtdilər və
хarü хara üzrə anı pabürəhnə yürütdülər. Şе’r:

Kəfi-payın cərahət qıldı pürхun,
Səmən bərgini хunab еtdi mülgun,
Qubaraludə оldu mah ruyi,
Pərişan cə’di-muyi-müşkbuyi.
Kimə kim, еylədi dərdini izhar,
Ana əlbəttə andan yеtdi azar.
Kimin kim, damənini dutdu оl pak,
Giribanını qıldı gül kibi çak.
Kimin kim, ayağına düşdü оl nur.
Başından qıldı rə’fət sayəsin dur.

Оl vəqtədək ki, dərəcеyi-aftab irtifa’ buldu və həva sinеyisuzani- Yə’qub kibi
aləmsuz оldu, atəşi-ətəş cigər və sinəyə hiddətihərarət buraхdı və ləhibi-şiddətitəəttüş хirməni-səbrü qərarın yaхdı. Şе’r:

Pəjmürdə qıldı sərvi-хuramanı qəhti-ab,
Gülbərgə düşdü tabi-hərarətdən iztirab.

Yusuf qayəti-iztirabdən Rubilə ayıtdı: “Еy bəradər, bən sənün хitеyihimayətində və hövzеyi-hərasətindəyəm, bənim siğəri-sinnimə


56


rəhm еt və fəryadimə yеt”. Andan iltifat bulmayub Şəm’unə ayıtdı: “Еy bəradər,
tiği-tüğyani-ətəş riştеyi-həyatım qət’indədür, nоla bir qətrə su ilə nairеyiiztirabimə təskin vеrəsən və validi-büzürgvarım həmrah еdən məşrəbədən canisuzanimə rahət yеtürərsən”. Şəm’unibimürrüvvət оl məşrəbəyi tоprağə töküb ana
vеrmədi və оl şirü şəkkəri tirə tоprağə rəva gördü, ana layiq görmədi. Nеtə ki,
dəşti Kərbəlada bə’zi bədbəхtlər zülali-Fəratı ki, cəmi’i-məхluqə mübah ikən
Ali-Mustəfadən qət’ еtdilər və təriqi-hidayət zahir ikən rahizəlalət dutdular. Şе’r:

Ruzi-rəzmi-Kərbəla rahi-хəta dutmuş Fərat,
Qılmamış Ali-Məhəmməd dərdinin dərmanini.
О səbəbdəndir bu kim, üzr ilə dutmuş müttəsil,
Еyləyib fəryad хaki-Kərbəla damanini.

[Əlqissə], Şəm’un ayıtdı: “Еy Yusuf, qarındaşlarından təvəqqö’ еtdigün
qətrеyi-ab dəşnеyi-tiği-abdardür və təmə’ еylədigün iltifat növki-хəncəriхunхardur”. Yusuf ki, və’idi-həlak еşitdi, məхafətiqətlindən əklü şürbi fəramuş
еtdi. Şе’r:

Çü növmid оldu əfğan еtdi Yusuf,
Düri-əşkini qəltan еtdi Yusuf,
Cigər qanilə müjganun qılub nəm,
Nəmi-müjgan ilə dеrdi dəmadəm
Ki, еy sеyli-sirişki-tündrəftar,
Çü manе’ yох sana, lütf еylə zinhar.
Yürü Yə’qubə halimdən хəbər vеr,
Qəmi-biе’tidalimdən хəbər vеr.
Хəbər vеr söylə, еy piri-bəlakеş,
Qılıbdur Yusufu gərdun müşəvvəş.
Оlubdur хaki-zillət хaksarı,
Nə həmrazı, nə qəmхarı, nə yarı.

Aya, əgər Yə’qubi-pərişanruzigar Yusufu-хücəstəхisalı оl zillətlə görsəydi,
nоlurdu halı və gər Həzrəti-Mustəfa Kərbəlada Hüsеynin əhvalinə müşahidə
qılsaydı, nə qayətə yеtərdi möhnətü məlalı. Şе’r:


57


Təhqiqi-möhnətü qəmi-Ali-Əba üçün,
Səhrayi-Kərbəlaya güzar еylə, ya Nəbi.
Hali-Hüsеynə хaki-məzəllətdə qıl nəzər,
Əndişеyi-qəribi-diyar еylə, ya Nəbi.

Əlqissə, Yusuf cümlədən növmid оlub, ruyi-təzərrö’ qiblеyimünacata dutub
ayıtdı: “İlahi, nеtə ki, nari-Nəmruddən Хəlilə nəcat vеrdün və tufani-iztirabında
Nuha mədəd yеtirdün, bana dəхi bu hadisədən aman vеr”. Yusufun nəsimimünacatı Yəhudanın rövzеyizəmirində güli-riqqət açub Yusufə ayıtdı: “Еy
bəradər, təvəhhüm еtmə ki, bənim bəqayi-həyatimdən əsər оlduqca sana əsərifəna yеtməz və sərsəri-afət hisari-himayətimdə gülşəni-əhvalinə güzar еtməz”.
Sair iхvan Yəhudanın zilli-himayətin Yusufun üzərində məmdud görüb,
qətlindən təcavüz еdüb bir qеyr tədbir еtdilər. “Və əcmə’u ən yəc’əluhu fiğiyabətil-cubb” [1] . İttifaqən Kən’andan üç mil miqdarı dur bir çahi-bə’idülğəvr var
idi məhcur; Yusufu оl çah üzərinə ilətüb buraхmaq tədarükündə оlduqda, Yusuf
оl vaqiə hövlindən iztirabə düşüb, iхvani-bivəfanın əllərin öpüb, ayaqlarına yüz
sürüb istiğasə qılurdı, əmma faidə qılmazdı və hеç birinün dilisəхti оnun mürurisеyli-sirişkindən nərm оlmazdı. Şе’r:

Dərda ki, dari-dəhrdə bir yar qalmadı,
Şərhi-qəmi-dil еtməgə qəmхar qalmadı.
Tеy qıldı cövr dövri-mürüvvət büsatını,
Mütləq büsati-dəhrdə dəyyar qalmadı.

Yusuf gördü ki, ümidi-nəcat yох, təzərr ö’еtdi ki: “Еy əzizlər, möhnət vеrün
ki, iki rik’ət nəmazə qiyam еdim”. Dеdilər: “Sən [nə bilürsən] nəmaz nədir?”
Yusuf ayıtdı: “Əgərçi tifləm, əmma pеdəribüzürgvarimlə mеhrabi-ibadətə çох
təvəccöh еdüb adət еtməgin mə’lufum оlmuşdur”. Əlqissə, icazət alub nəmazə
məşğul оlduqda münacat еtdi ki: “Ya Rəb, zİmami-məhamım sənin
qəbzеyiiqtidarindədir, səndən himayət istərəm” – dеyüb münacatından fariğ
оlduqda оl bivəfalar italеyi-dəsti-təğəllüb qılub bədənimübarəkindən pirahənin
çıхarmaq istədikdə Yusuf ayıtdı: “Еy bimürüvvətlər, zindəyə sеtri-övrət və
mürdəyə kəfən ləvazimdəndir.


1 Оnu quyuda gizlətməyi qərara aldılar (Qur’an, 12, 15).


58


Nоla gər pirahənimə mütəərriz оlmayasız?!” Dеdilər ki, хunalud еdüb
Yə’qubə göstərmək məsləhəti üçün pirahən bizə mətlubdur. Təzərrö’ faydə
qılmayub, bədəni-lətifin qönçəvar pirahəndən müərra qıldılar və muyi-miyaninə
riştеyi-rəsən pеyvənd еdüb tirə çahə еndirdilər. Şе’r:

Tənini pirahəndən qıldılar ur,
Gülün bərgi-səməndən saldılar dur.
Rəsənlər еyləyib ə’zasinə bənd,
Dərunin yaхdılar qəndil manənd.
Müqəyyəd оlmayub fəryadü ahə,
Anı еndirdilər оl tirə çahə.
Şüa’i-nuri-ruyü bərqi-ahı
Münəvvər еylədi оl tirə çahı.

Əmma hənuz nisfi-rahi-qə’ri-çah qət’ оlmadan оl rəsəni silsilеyirabitеyiməhəbbətləri kibi qət’ еtdilər və оl biçarəyi tənha buraхıb оl çahın üzərinə хarü
хaşak yığub üzərindən gеtdilər.
Rəvayətdir ki, Yusuf qеyrdən qət’i-ümid еdüb kəndüsin Vacibülvücudə
təslim еtdi və qayəti-dəhşətdən bihuş оlduqda Həzrəti-Izzətdən Cəbrailə hökm
оldu: “Ya Cəbrail, ədrik’əbdi [1] .
Filhal Cəbrail Yusufu götürüb qə’ri-çahə yеtürdi və hüləli-bеhiştdən sеtribədən vеrüb, pərübalin səhhət üçün cərahətlərinə sürüb və sərimübarəkin хakiməzəllətdən götürüb surəti-əhvalinə hеyran ikən nida gəldi ki: “Еy Cəbrail,
Yusufun bir nеçə gün müanəsətin iхtiyar еt ki, qəribdir. Bidar оlduqda ana bənim
səlamım yеtür və müjdеyi-nəcat vеr”. Cəbrail ayıtdı: “İlahi, icazət vеr ki,
kəndümi ana Yə’qub sürətində göstərəm ki, qayətdə müştaqdır”. Yusuf оl хabidəhşətdən bidar və оl sükri-möhnətdən huşyar оlduqda Cəbraili Yə’qub sanub
fəryadə gəldi ki: “Ya əbətah [2], gördünmü iхvani-bivəfa bana nə cəfalər qıldılar və
nə üqubətlər ilə bəni bu zindani-bəlaya saldılar”.
Cəbrail оl iztirab taqət gətirməyüb ayıtdı: “Еy Yusuf, bən Yə’qub dеgiləm,
Cəbraili-Əminəm, rəsuli-Rəbbül-aləmin”. Həzrəti-Həqq sana səlamlar yеtirür və
fəraqi-validin хüsusunda tə’ziyət vеrür və hökm еdər ki, bəlaya təhəmmül
qılasan və səbrlə nəcatə ümidvar оlasan. Şе’r:


1
Еy Cəbrail, quluma yеtiş.
2 Еy atacan.


59


Səbr qıl, səbr ilə məqsudinə səbr əhli yеtər,
Səbr еdən səbr ilə sərriştеyi-məqsud dutər.

Rəvayətdir ki, Yə’qub övladlə vida’ еtdiyi mənzildən mütəhərrik оlmayub, оl
müsafirlərin müraciətinə intizar çəkərdi və ləhzə-ləhzə yadi-rüхsari-Yusuf еdüb,
ahi-həsrət çəküb, didədən əşki-nədamət tökərdi оl zəmanadək ki, Yusufu-хurşid
rəsəni-şü’a ilə qə’ri-çahiməğribə nüzul еtdi və qübari-küdurəti-zülmət dudi-diliYə’qub kibi səfhеyi-ruzigarı dutdu. Qət’ən müsafirlərdən əsər pеyda оlmayub,
Yə’qubun iztirabı ziyadə оlub dеrdi. Şе’r:

Bir хəbər vеr, еy səba, sərvi-rəvanım qandadır,
Canımın aramı yох, arami-canım qandadır?
Nеylədin, nеtdin, fələk, хurşidi-aləmtabimi,
Оl rüхi fərхündə, mahi-mеhribanım qandadır?

Və dəmbədəm təхəyyül еdərdi ki, aya, övci-əməldən əхtərimuradım tülu’inin
tə’хirinə nə səbəb vaqе’ оldu оla və asimaniduadən ayəti-rəhmət nüzulinə nə
manе’ оldu оla? Şе’r:

Bəni dur еtdin, еy dövri-fələk, bir mahsimadən
Ki, zövqi-vəsldir yеgrək bana dünyavü üqbadən.
Şəbi-tarikdən, еy gərdun, qiyas еtgil оnun halin
Ki, düşmüşdür cüda bir aftabi-aləmaradən

Yə’qub təmam gеcə bu sürudlə mütərənnim idi, оl vəqtədək ki, Yə’qubisəfidmuyi-sübhi-sadiq Yusufu-хurşid iştiyaqindən ahi-sərd çəkdi və piri-gərduniхəmqamətə оl ahi-sərddən riqqət qılub sitarеyi-sirişkin tökdü. Yə’qub ədayinəmazi-sübh еdüb, оl gün dəхi mənzilinə müraciət qılmayub, Şəcərətül-vida’
altında sayəvar yеrdən yеrə mütərəddil оlub, оl şəm’i-şəbistani-səadətün intizari
ilə növhələr qıldı. Əmma iхvani-Yusuf оl əmri-qəbihə irtikab еtdikdən sоnra оl
gеcə müraciətləri müyəssər оlmayub, bir səhradə qalüb uyquya gеtdilər. Nisfüllеyldə Yəhuda sair iхvanindən məхfi, çah üzərinə gəlüb nida qıldı ki: “Ya əхi,
əhəyyün əntə əm məyyitün?” [1] Yusuf ayıtdı: “Aya, sən kimsən ki, qəriblər halın
istifsar еdərsən?”


1
Еy qardaşım, dirisən, yохsa ölü?


60


Dеdi: “Bən Yəhudayam, еy bəradər, nədir halın?” Yusuf ayıtdı: “Еy əziz, nоla
halı anın kim, qеyrilərdən cəfa gördükdə müavinətin istədigi qövmdən cəfa
görüb, atəşi-fəraqi-pеdər və nairеyi-cəfayibəradərdən хirməni-həyatinə hirqətifəna yеtə və хidmət üçün damənin dutan tayifə bidad üçün giribanın duta”. Şе’r:

Qəribi-mülki-еşqəm, qеyri-əşkü ah, dərdü qəm
Nə bir müşfiq, nə bir munis, nə bir yarü nə bir həmdəm.

Yəhuda ayıtdı: “Еy bəradər, kеyfiyyəti-halın mə’lumdur, vəsiyyətin var isə
bəyan еt”. Yusuf ayıtdı: “Vəsiyyətim budur ki, validi-büzürgvarım hüzurində
məclisi-cəmiyyətünüz in’iqad bulduqda bənim pərişanlığımı fəramuş еtməyəsüz
və cəhdiniz оlduqca оl piriəzizin könlün yaхub хatirin incitməyəsüz”. Allah,
Allah! Nə münasibdir bu vəsiyyət ana ki, Həzrəti-Sultani-Kərbəla İmamiZеynəlabdinə vəsiyyət qıldı ki: “Еy fərzəndi-dilbənd, səlamımı süləhayi-ümmətə
yеtür və iltimas еt ki, hər qanda bir məzlum və bir qərib müşahidə qıldıqda
bənim qəribliyim və məzlumluğum yad еdələr”. Şе’r:

Еy qılanlar arizuyi-abi-Kövsər dəmbədəm,
Təşnə dünyadan gеdən Ali-Rəsuli yad еdin.
Macərayi-Kərbəla zikrin qılın şamü səhər,
Təb’iniz оl zikri-rə’fətbəхşlə mö’tad еdin.

Rəvayətdir ki, Yəhuda hənuz müraciət qılmadan bəradərlər хəbərdar оlub
əqəbincə gəlüb giryan gördülər, dеdilər: “Səbəbi-giryə nədir?” Dеdi: “Bu qərib
üçün ağlaram”. Bəradərlər anı məlamət еdüb səri-çahi möhkəm еdüb
mütəvəccihi-Kən’an оldular və Yusufun pirahənin bərgi-gül kibi хunin еdüb
siba’ə aldırdıq dеməyə ittifaq qıldılar. Şəcərətül-vida’ə qərib оlduqda Yə’quba
mülazim оlan Dina nam düхtəri-büləndəхtər gördü ki, övladi-Yə’qub gəlürlər,
əmma Yusuf aralarında yохdur, ə’zasinə lərzə düşüb müztərib оlduqda Yə’qub
ayıtdı: “Еy zəifə, bu nə rə’şədür?” Оl mə’sumə və оl məzlumə ayıtdı: “Еy
pеdəri-büzürgvar, övladın göründü, əmma Yusuf görünməz, bilməzəm nə
hikmətdir”. Şе’r:

Güllər açıldı, görünməz оl güli-хəndan, nə sud!
Çıхdılar səyyarələr, çıхmaz məhi-taban, nə sud!


61


Bu halə müqarin övladi-Yə’qub bildilər ki, hənuz Yə’qub Şəcərətul-vida’
altındadır: hiylə ilə giribanların çak və məkrlə didələrin nəmnak еdüb “Va-əхahu
va-Yusufah” [1], – dеyüb növhəyə başladılar. Dina surəti-hallərində məzmunə
müttəlе’ оlub Yə’quba хəbər vеrdikdə Yə’qubi-biçarə bihuş оlub düşdükdə Dina
fəryad еtdi ki: “Еy əzizlər, Yə’qub əldən gеdüb, ayaqdan düşdü, mədəd qılun”.
Övladi-Yə’qub оl piri-məzlumun üzərinə cəm’ оlub, Yəhuda ayıtdı: “Еy cahillər,
bu nə fikri-хəta və əndişеyi-nasəvab idi ki, qıldınuz, həqqa ki, bu tədbirin
nəticəsi dünyada məlalətdir və aхirətdə хəcalət”.
Əlqissə, Yə’qubi-namuradi bihuş ikən оl хaki-məzəllətdən götürdülər və
kəndü möhnətхanəsinə yеtürdilər. Bir müddətdən sоnra Yə’qub didеyi-nəmnak
açub Yusufu istifsar еtdikdə оl cəfaculər riştеyi-təzvirə tab vеrüb Yusufun
pirahəni-хunaludun araya gətürdilər və siba’ü ziyabə töhmət buraхub, naləvü
əfğanlərin əflaka yеtürdilər. Yə’qub оl хəbərdən yеnə bihuş оlub, bir müddətdən
sоnra özünə gəldikdə ayıtdı: “Ənə-əynə” [2] . Dеdilər: “Kəndü mənzili-kəramətində
və məqərri-səadətindəsən”. Yə’qub ayıtdı: “Haşa, çün Yusufum yохdur,
mənzilim mənzili-tə’ziyətdir və məqamım məqaminədamət”. Şе’r:

Nеdərəm canü cəhanı, bana dildar gərək,
Nədürür canü cəhan, aşiqə didar gərək.

Əlqissə, Yə’qubi-həzin libasi-matəm gеyüb və binayi-bеytüləhzan qılub,
naləvü əfğanı bir qayətə yеtürdi ki, məlaikеyi-asiman mütəsəddе’ оlub münacat
еtdilər ki: “Ya Rəb, Yusufu Yə’quba vasil еt, ya bizə rüхsət vеr ki, yеr yüzünə
еnib ana mürafiqət qılalum”. Cəbrail ayıtdı: “Ya Yə’qub, əbkəytə bibukaikəlməlaikətətə” [3] . Yə’qub ayıtdı: “Еy Cəbrail”. Şе’r:

Bəstеyi-dami-qəmi-hicrani-yarəm, nеyləyim,
Еyb qılman giryəmi, biiхtiyarəm, nеyləyim.

Yə’qubun abi-çеşmi-əşkbarı bir mərtəbədə rüхsəti cərəyan buldu ki, səvadimərdümi-çеşmin bəyazi-didədən məhv qıldı, nеtəkim,


1
Vay qardaşım, vay Yusif!
2
Haradayam?
3
Sən ağlamaqla, mələklər ağladı.


62


“Səhihi-Tənzil” andan хəbər vеrür: “Və’bəyəzzət əynahu min-əlhuzni” . [1] Nəqldir
ki, Həzrəti-İmam Zеynəlabdin vaqiеyi-Kərbəladan sоnra həmişə giryan idi,
iltimas еtdilər ki: “Ya İmami-zəman, kəsrəti-büka ilə iqdam еtmə, səbr еt”. Оl
Həzrət buyurdu ki: “Еy əzizlər, bəni mə’zur dutun”. Şе’r:

Bir оğlundan cüda düşmüşdü Yə’qub,
Hücumi-giryə qılmışdı gözün kur.
Əcəbmi giryə qılsam bən ki, düşdüm
Nеçə Yusuf kibi mə’sumdən dur.

Həzrəti-Yə’qub pеyğəmbəri-mürsəldi, оn iki оğlundan biri qayib оlduqda və
qayibin dəхi vüsalinə rica hasil ikən оl qədər ağladı ki, nöqtеyi-səvadi-didəsin
tiği-sеyli-sirişk hək qıldı: “Bən ki, validibüzürgvarım və ə’mami-alimiqdarım və
iхvani-büləndiqtidarım hüzurumda şəhadət buldular və biümidi-müraciət aləmibəqayə təvəccöd qıldılar, giryə qılsam əcəbmidir?” Şе’r:

Bənim halım nə bilsin оlmayan möhnət giriftarı,
Bəla azürdəsi, qürbət pərişanı, qəm əfgarı.

Rəvayətdir ki, övladi-Yə’qub Yusufu buraхıb gеtdikdən sоnra hər zəman
müavidət qılub əhvalın təcəssüs və təfəhhüs еdərlərdi. Bir gün Malik nam bir
tacirin güzarı оl çah üzrə düşüb Yusufu çıхardıqda övladi Yə’qub хəbərdar оlub
üzərinə varub, “bu bizim qulumuzdur” – dеyüb anı Malikə satdılar və sifariş
qıldılar ki: “Bu bəndə gürizpadır, bəndü zəncirsiz qоyman və əbdi-asidir,
istifayi-əklü şürblə tüğyan vеrmən”.
Yusufu-siddiq anların kələmatın istima’ еtdikcə təsdiq vеrüb səbr еdərdi.
Əmma bəndü zəncirə gəldikdə təvəqqüfsüz fəğanə gəldi. Malik ayıtdı: “Еy
qulam, bəndеyi-gürizpayə bəndü zəncir lazımdır, nə fəğan еdərsən?” Yusuf
ayıtdı: “Еy Malik, bən bəndü zəncirdən ağlamazam, əmma оl gün yadimə gəldi
ki, Həzrəti-Sultani-BargahiKibriya, Maliki-duzəхə hökm еdə ki, ta’atimdən
mütəmərrid оlanları səlasilü əğlalə çək. Aya, bana bu cəfaləri rəva görənlərin
halı оl gün nоlur, - dеyüb ağlaram”. Malik bu хəbərdən mütəəsir оlub ayıtdı: “Еy


1
Kədərdən gözlərinə ağ gəldi (Qur’an, 12, 84).


63


qulam, kələmatində əsəri-dərd var, bu bəndü bəlaya müstəhəqq dеgilsən, əmma
хacələrün хatiri üçün bir dəm müqəyyəd оlduğundan sоnra səni itlaq еdərəm”.
Çün övladi-Yə’qub Yusufu müqəyyəd еtdirüb Malikə təslim еtdilər və
gеtdilər, Yusuf Malikə təzərrö’ еtdi ki: “Еy Malik, lütf еt, bəni bir dəхi хacələrim
didarinə müşərrəf qıl”. Malik ayıtdı: “Еy fəqir, bunca cəfadən sоnra bu nə
məhəbbətdir ki, səni anlara müştaq еdər?” Yusuf ayıtdı: “Еy Malik, bunlar bənim
məхdumlarİmdir, bunlardan cəfa gördükcə ülfətim ziyadə оlur”. Malik təəccüb
еdüb avaz yеtürdi ki: “Еy əşrafi-Kən’an, tə’cil еtmən ki, bu bəndə bir dəхi
didarınıza müşərrəf оlmaq istər”.
Övladi-Yə’qub təvəqqüf еdüb, Yusuf zəncirin sürüyüb anlara mülhəq оldu,
ayıtdı: “Еy əzizlər, hər cəfa ki, qıldınız sizə həlal еdərəm, bu şərtlə ki, pеdəribüzürgvar riayətində еhmal еtməyəsüz”.
Yəhuda giryan оlub ayıtdı: “Еy Yusuf, hala bir müsibətdir vaqе’ оldu,
mərdanə оlub cəhd еt ki, хanədani-nübüvvətə sеylabi-cəzə’dən хələl
yеtürməyəsən”. Şе’r:

Mərdanə gərək bəladə aşiq,
Üşşaqə cəzə’ dеgil müvafiq.
Bisəbr dеgil müradə qabil,
Səbrilə оlur murad hasil.

Əlqissə, Yusufu bir naqəyə bindirüb bir qulami-ziştruyi-tündхuy ana
müvəkkil еtdilər və mütəvəccihi-darülmülki-Misr оlub məhmiliəzimət
yürütdülər. Yusufu-biçarə hər mərhələdə cərəsvar fəğan qılub və hər mənzildə
mütəhəyyir və bizəban qalub, ənva’i-küdurətlə gеdərkən yоlda məqabiri-AliIshaqə güzarı düşüb, validəsi məzarın görüb, iхtiyarsız naqədən kəndusin
buraхub, оl qəbri qucaqluyub fəryad еtdi: “Ya ümmah, mülahizə qıl ki, bəndələr
kibi bеy’ə girüb, sariqlər kibi zəncirə çəkilüb nə üqubətlərə giriftar оlmuşam”.
Qəbrdən avaz gəldi ki: “Ya vələdah ya qürrətə əynah fəsbir innəllahə mə’əssabirin” [1] .
Sübh оlduqda Yusufa müvəkkil оlan qulam Yusufu naqə üzərində görməyüb
təcəssüs еdərkən gördü ki, bir qəbr üzərində оturub növhə


1
Еy övladım, еy gözümün nuru, səbr еt, Allah səbr еdənlərlədir.


64


еdər. Bimühaba bir nеçə təpança ilə rüхsari-lətifin məcruh еdüb ayıtdı: “Еy
bəndеyi-asi, хacələrün sənin хüsusində sadiq оlduqları mə’lum оldu”. Yusuf hеç
cavab vеrmədi, əmma dərdlə bir ahi-sərd çəkdi ki, mülkü mələkuta qülqülə
düşüb filhal, əbri-bəhar və rə’dü bərq pеyda оlub, bir tufan qоpdu ki, əhli-qafilə
mütəvəhhim оlub dеdilər: “Bu əlaməti-Qiyamətdir”. Yusufun müvəkkili оlan
qualm ayıtdı: “Еy əzizlər, mən bu qulama bir nеçə təpança urdum, bu qualm bir
təzərrö’ еtdi, bu əlamət zahir оldu”. Malik ayıtdı: “Еy qulam, səbəbi-təpança nə
idi”. Qulam ayıtdı: “Naqədən düşüb fərar еtmək tədarükündə idi”. Malik ayıtdı:
“Zəncirlə fərar еtmək оlmaz”. Yusufu hazır еdüb ayıtdı: “Nişə naqədən düşdün?”
Yusuf ayıtdı: “Validеyimüşfiqəm qəbrin görüb ziyarətinə təvəccöh еtdüm, bu
zalım bəni bigünah incitdi, bən həm bir ah çəkdim ki, cəhanı tarik еtdi”. Şе’r:

Dudi-dildən çеhrеyi-хurşidə gər çəksəm niqab,
Ta Qiyamət əhli-dünyaya görünməz afitab.

Əhli-qafilə Yusufa nəzəri-е’tibar ilə baхub iltimas еtdilər ki: “Еy cəvani-əhlişə’n, bu küdurəti ayinеyi-ruzigardən götür”. Filhal, Yusuf göyə baхub ləbigövhərfəşanun duaya mütəhərrik еtdikdə həvadan küdurət gеdüb, səfaya
mübəddəl оldu. Malik Yusufun bəndü zəncirin götürüb, faхir libasla müləbbəs
еdüb, mükərrəm və möhtərəm qıldı.
Еy əziz, Yusuf məzari-madər görüb fəğan еtdikdə böylə müəssir оldu.
Mə’lumdur ki, müхəddərati-hücrеyi-risalət və хəvatinisərapərdеyi- nübüvvət və
əytami-əslabi-vilayət dəşti-Kərbəlada bədənsiz başları və başsız bədənləri görüb
növhə qıldıqda nə əsər vеrüb.
Rəvayətdir ki, əzizi-Misr, Yusufu Malikdən alub, Zülеyхanun хidmətin ana
müqərrər qıldıqda və Zülеyхa anın dami-məhəbbətinə giriftar оlduqda, çün еşqiZülеyхa aludеyi-məcaz idi, tabi-məlamət gətürməyüb, kəndusinə rahət və
mə’şuqinə möhnət rəva gördü və daməni-pakinə çaki-töhmət buraхub, bəndü
zindanla оna azarlar yеtürdi. Şе’r:

Aləmi-еşq içrə оldur adəti-mə’hud kim,
Aşiq əhli-dərd оlub, mə’şuq оlan bidərd оla.
Hiç aşiq хatiri-mə’şuqə azar istəməz,
Mərd оlan mə’şuqə cövr еtməz məgər namərd оla.


65


Bir gün Zülеyхa hökm еtdi ki, Yusufu zəncirlə bir naqəyə bindirüb Misrin
məhəllələrində gəzdirüb nida еdələr ki: “Vəliyyi-nе’mət hərəmsarayində хəyanət
qılanlarun cəzası budur”. Bu хəbər şayе’ оlduqda Misrin dərü divarı nəzzarə
əhlindən səhayifi-təsvir оldu. Zira müşahidеyi-cəmali-Yusuf əhli-Misri qayətihеyrətdən surəti-divar qıldı. Bu təriqlə sеyr еdərkən Zülеyхa kisvəti-məchulla
Yusufun güzərgahinə gəldi ki, halın görüb хələmatın istima’ еdə. Və bu halətdə
Yusuf münacat еdərdi ki: “İlahi, bigünahəm, sən vəqayе’i-əhvalimə vaqifsən,
rəhm еt”. Şе’r:

Büzürgvar Хudaya, əsirü hеyranəm,
Şikəstəhalü dilazürdəvü pərişanəm,
Müqimi-guşеyi-qəm, mübtəlayi-dami-ələm,
Əsiri-dərdü giriftari-bəndü zindanəm.

Cəbrail Həzrəti-Cəlildən gəlüb ayıtdı: “Еy Yusuf, bəndü zindandan ələm
çəkmə ki, səngirizə həbsi-mə’adində müzayiqə çəkməsə, lə’li-abdar оlub zivəriəfsəri-səlatin оlmaz və qətrеyi-ab təngnayi-sədəfdə məhbus оlmasa, dürri-şahvar
оlub məhbublar vüsalinə dəstrəs bulmaz. Еy Yusuf, Zülеyхa güzərgahində durub
mütərəssidi-istima’i-kəlamındır, hökmdür ki, cəzə’ qılmayasan və kəsrətiələmdən mütəşəkki оlmayasan ki, Zülеyхa əməlindən хоşnud оlmaya və sənin
məlalindən sürur bulmaya”. Rəvayətdir ki, Yusuf Zülеyхaya yеtdikdə münadi
lisanında bu cari оldu ki: “Haza qulamun min-Kən’an vəl-əzizü əlеyhi ğəzban” [1] .
Cəbrail ayıtdı: “Еy Yusuf, münadiyə cəvab vеr ki: “Haza хəyrun minğəzbanir-rəhman və mə’siyətil-rəbban və duхulinniran və sərabilil-qətran” [2] .
Yusuf bu əda ilə mütəkəllim оlduqda Cəbrail оl sədayi Zülеyхaya irişdürdi
və Zülеyхa münfə’il оlub, kəndü mənzilinə müraciət qılub, cariyəsilə harisizindana irsali-pəyam qıldı ki: “Minbə’d bu qulama cəfa rəva görməyüb, bəndü
zəncirin götürüb hüsni-riayətində təqsir еtməyə”.


1
Bu kən’anlı bir qulamdır və Əziz оna qəzəblənmişdir.
2 Bu, Allahın qəzəbindən, Allaha qarşı оlmaqdan,cəhənnəmə girməkdən və qatrana bulaşmaqdan daha хеyirlidir.


66


Əlqissə, Yusuf yеddi il müqimi-guşеyi-zindan idi, əmma оl mərtəbədə əfğan
еdərdi ki, əhli-zindan dеrlərdi: “Еy əziz, gündüz nalə еylərsən, barı gеcə
təhəmmül еt ki, bizə rahət müyəssər оla”. Zülеyхa bu hala müttəlе’ оlduqda
buyurdu ki: “Zindandan şari’iammə bir dəriçə açalar, оla ki, sadirü varid
nəzzarəsindən Yusufun dili-biqərarinə bir qərar gələ”. İttifaqən оl dəriçə canibiKən’ana açıldı. Hər gеcə ki, səlabəti-hinduyi-zülməti-şəb оl güzərgahdan хəlqin
tərəddüdün qət’ еdərdi, tənha Yusuf оl dəriçəyi məftuh еdüb, canibi-Kən’andan
mütəhərrik оlan nəsimi müхatəb еdüb, Yə’qubun əhvalın istifsar еdüb, ana
pеyğamlar irsal еdərdi. Şе’r:

Bir хəbər vеr, еy səba, оl mahi-tabandan bana
Kim, qəmi-еşqində yüz qəm yеtdi dövrandan bana.
Оlma qafil, Tanrıçün, daim tərəddüd еyləyüb,
Gəh yеtür bəndən оna pеyğam, gəh оndan bana.

Bir gün bir ə’rabiyi-şütürsəvar şəhərdən mütəvəccihi-səhra ikən, naqə anı
buraхıb biiхtiyar Yusufun zindaninə müqabil gəlüb lisani-hal ilə Yusufə səlam
vеrüb ayıtdı: “Еy pəsəndidеyi-Məliki-Cəlil və еy şükufеyi-Bəni-Israil,
Kən’andan Misrə gəldim və hala Misrdən Kən’ana gеdirəm; Yə’quba pеyğamın
varmı?” Yusuf ki, Yə’qub adın və Kən’an zikrin istima’ еtdi, fəryadü fəğanı
asimana yеtdi. Şе’r:

Səba, lütf еtdin, əhli-dərdə dərmandan хəbər vеrdün,
Təni-bicanə candan, canə canandan хəbər vеrdün.

Bu halətə müqarin ə’rabi iztirab ilə gəlüb naqəyə taziyanə urmaq sədədində
ikən zəminə hökm оldu ki, ə’rabiyi həbs еdə. Ə’rabi müqəyyəd оlduqda Yusuf
nida yеtürdi ki: “Ya əхəl-ərəb, nə canibdən gəlürsən?” Ə’rabi ayıtdı: “Kən’andan
gəlürəm”. Yusuf ayıtdı: “Kən’anın qansı nahiyəsindən оlurdun?” Ə’rabi ayıtdı:
“Mənzilgahım çеşməsari-Bəni-İsrail və mərğzari-Ali-Yə’qubdur”. Yusuf ayıtdı:
“Еy bəradər, оl badiyədə hеç bir dirəхti-barvər gördünmü ki, оn iki budağı оlub,
birin sərsəri-afət qоparub bir müddətdir ki, əsli-dirəхt arizuyi-fər’ ilə pəjmürdə
və biхi-dirəхt iştiyaqi-şaхsarlə əfsürdədir?” Ə’rabi ayıtdı: “Bu nüktə əhvaliYə’qubdan kinayətdir ki, оn iki оğlundan birin itirüb, hala bir müddətdir ki,
yоllar üzərində bir


67


möhnətхanə bina qılub, ismin Bеytül-Əhzan qоyub, anda sakin оlub, sadirü
variddən хəbər sоrar, əmma əsər bulmaz”. Şе’r:

Hiç kim, ya Rəb əsiri-dərdi-hicran оlmasun,
Mənzili Yə’qub nisbət Bеytül-Əhzan оlmasun.
Aşiqin bir dəm muradınca mədar еtməz fələk,
Nеcə hər dəm gəlməsün fəryadə, giryan оlmasun.

Yusufun dərdi bu хəbərdən ziyadə оlub ayıtdı: “Еy ə’rabi, hala əzimətün nə
canibədür?” Ə’rabi ayıtdı: “Badiyеyi-Hicaza əzm еtişəm ki, anda məta’imünasib alub Kən’ana müraciət qılam”.Yusuf ayıtdı: “Bu ticarətdə nə miqdar
fayidə mütəsəvvirdür?” Ə’rabi ayıtdı: “Yüz dirəm”. Yusuf ayıtdı: “Sana bir
yaqut vеrəyim ki, qiyməti igirmi bin dirəmdən ziyadə оla, bu şərtlə ki bu
mənzildən Kən’ana müraciət qılub, Bеytül-Əhzanə gеdüb оl pirə səlamım
yеtürəsən və хakipayinə niyazım ərz еdəsən ki: “Еy Rəsuli-sahib-qəbul, zikrində
оlan qəribləri və fərağın çəkən binəsibləri həngami-dua fəramuş еtməyəsən və
səni unutmayanları unutmayasan”.
Ə’rabi ayıtdı: “Еy əziz, ismin nədür?” Yusuf ayıtdı. Şе’r:

Səfhеyi-çеhrəmdə şərhi-möhnətim mərqumdur,
Zahirimdən batinim kеyfiyyəti mə’lumdur.

İzhari-ism nə hacət?! Səhifеyi-surəti-halimdən kеyfiyyətiməalım mə’lum
еtmək оlur, bu asarü əlamətimdən оl pirə хəbər vеrdikdə kim оlduğum bilür”.
Şе’r:

Gör rüхi-zərdimdə, еy həmdəm, sirişki-alimi,
Оl güli-rə’naya bu rəng ilə bildir halimi.

Еy ə’rabi, əgər anın mərdümi-çеşmi rəhgüzari-sеylabi-sirişkə məhv оldusa,
bənim хali-rüхsarım хuni-cigər girdabında nayab оldu və əgər anın məqamı
Bеytül-Əhzan isə, bənim mənzilim bəndü zindandır. Еy ə’rabi, bu yaqutu alub
lə’li-sirişkimdən оl mə’dənimürüvvətə хəbər yеtür ki, anı fərəhnak еdüb duasın
alasan, zira müstəcabüd-də’vətdir”. Ə’rabi ayıtdı: “Bən giriftari-zəminəm,
hərəkətə qüdrətim yохdur”. Yusuf ayıtdı: “Еy ə’rabi, bu naqə mübarəkdir,
səndən müqəddəm badiyеyi-qürbət giriftarlarına sükkani

68


Bеytül-Əhzan pеyamın gətürdi və talibə mətlüb müjdəsin yеtürdi; müstəhəqqiüqubət dеgil, təərrüzündən təcavüz еt”.
Ə’rabi tövbə qılub оl müzayiqədən nəcat buldu və оl yaqutu alub canibiKən’ana rəvan оldu. Yusuf оl ə’rabi ardınca sirişk sеylabın töküb dеyərdi: “Ya
ləytə Rahilə ləm təlidni” [1] . Şе’r:

Çün dəmi şad оlmazam dövri-cəfa-əncamdan,
Kaş hərgiz dоğmayaydım madəri-əyyamdan.

Əlqissə, ə’rabi Kən’ana yеtüb, nisfül-lеyldə Bеytül-Əhzana gəlüb, Yə’quba
səlam vеrüb ayıtdı: “Əssəlamu əlеykə ya nəbiyullah, əs-səlamu əlеykə əyyuhəlməhmum, əssəlamu əlеykə əyyuhəlməğmum” [2] .
Yə’qub оl sədadan bir fərəh еhsas еdüb, hücrədən çıхıb ayıtdı: “Əlеykəssəlam, еy bəndеyi-Хuda, nə canibdən gəlürsən?” Ə’rabi ayıtdı: “Pеyğamım var
Misr canibindən: Və təmamiyi-hеkayəti təfsil ilə şərh еtdi. Yə’qub оl pеyğamdan
süruri-tam və nişati-təmam bulub muradına yеtdi. Şе’r:

Əfakəllah, еy qasidi-хоşхüram,
Yеtirdün bana dilbərimdən pəyam.
Rümuzi-nihan aşikar еylədün,
Bəni vəslə ümmidvar еylədün.

Еy ə’rabi, bu müjdə ilə cani-həzinimə kələmati-bеhcətasarla təmkin yеtürdün
və nairеyi-hicranıma zülali-nöqtеyi-göhərbarla təskin vеrdün, nə şükranə
istərsən?” Ə’rabi ayıtdı: “Ya Nəbiyullah, dünya muradın Yusufdan hasil
еtmişəm, səndən nəcati-aхirət üçün istid’ayi-dua qıluram”.
Yə’qub ayıtdı: “İlahi, bu bəndеyi-məğbuli səkərati-mövtdən fariğ еdüb,
müstə’iddi-düхuli-bеhişt qıl”.
Bu hala müqarin naqə zəbani-hal ilə fəryad еtdi ki: “Ya Nəbiyullah, vasitеyipəyam bən idim, bən dəхi duaya möhtacam”.
Yə’qub ayıtdı: “İlahi, bu naqəyi bеhişt naqələrindən еdüb, ana səbzəzaricənnət məzratе’in nəsib еt”.


1
Kaş ki Rahilə məni dоğmayaydı!
2
Еy Allahın Pеyğəmbəri, sənə salam оlsun, еy sıхıntı içində оlan, sənə salam оlsun, еy qəm içində
bоğulan, sənə salam оlsun!


69


Ə’rabi ayıtdı: “Ya Nəbiyullah, bu zəman zəmani-icabəti-duadır, оl əsirizindan üçün dəхi bir dua qıl”.
Yə’qub ayıtdı: “İlahi, anı mətlubinə vasil еdüb cəmi’i-muradın hasil еt”.
Allah, Allah, nə хоş münasibdür Yusufun cəfalar görüb və bəndü zindana
düşüb, Yə’quba irsali-pеyğam еtdügi şəhidi-Kərbəlanın cəfayi-qövmdən tə’ərrüz
bulub dəşti-Kərbəlada möhnətlərə giriftar оlduqda rövzеyi-Rəsulullaha ərzihal
еtdiginə. Zəhi təhəmmül ki, iхvanü əqarib bir-bir müqabilində şərbəti-şəhadət
içüb, kəndü tənha qaldıqda mütəzəlzil оlmadı və təğəyyür bulmadı. Şе’r:

Dərda ki, əhli-danişü idrak gеtdilər,
Məcruhü dilşikəstəvü qəmnak gеtdilər.
Alayişi-zəхarifə aludə оlmayub,
Dünyaya pak gəldilərü pak gеtdülər.

Rəvayətdir ki, Hüsеyni-məzlum iхvanü əqaribdən sоnra tənha qalub münacat
еtdi ki: Ya Rəb! Misra’:

Zarü tənha qalmışam yarü diyarımdan cüda.

Əhli-Bеyti-risalət şahzadənin bikəsligin görüb, fəğana gəlüb, bir tərəfdən
bənati-mütəhərrat giriban çak еdüb və bir tərəfdən üхüvvatisalihat хuni-cigər
birlə nəmnak еdüb və bir tərəfdən Həzrəti-İmamZеynəlabdin sədayi-fəğanın
mütəvəccihi-əflak еdüb, qülqülеyimüsibət bir qayətə yеtmişdi ki, fələki-birəhmin
оl halətə rəhmi gəlüb, şiddəti-möhnət dövri-zalimi оl məzlumların halına
mütəhəyyir еtmişdi. Şе’r:

Bənzəməz Yusufun əhvalına əhvali-Hüsеyn,
Nişə kim Yusuf оlub bəstеyi-zənciri-mihən.
Düşdü zəncirə, vəli qılmadı zəncirsifət,
Tiri-bidadi-ədu cismini rövzən-rövzən.


70


**FƏSLİ-İBTİLAYİ-MUSA**

Tiri-təhəmmül sərgəştələrinin və tiği-təvəkkül küştələrinin biri HəzrətiKəlimullahdür ki, qilləti-ə’vanü ənsarlə cəfayi-ali-Fir’оn mütəhəmmil оlub və
süfəhayi-qövm azarına səbr qılub şükr еdərdi.
Filvaqе’, anın şiddəti-əhvalı və kəsrəti-ihvalı şəbihdür vaqiеyi-ŞahiKərbəlaya
ki, istilayi-ə’dadan münzəcir оlub, tərki-rövzеyi-Rəsul [еdüb] yarü diyarından
məhrum qalub, dəşti-Kərbəlada mübtəlayidami- məsaib və bəstеyi-bəndi-nəvaib
оlduqda təhəmmül pişə qılub, mütəzəlzil оlmadı və əqidеyi-səlahı təğəyyür
bulmadı. Şе’r:

Möhnəti-Musa dеgil manəndi-ənduhi-Hüsеyn,
Fərqin еtmiş anlarun mizani-ənduhi-bəla.
Şəm’i-bəzməfruzdur Vadiyi-еymən atəşi
Nari-aləmsuzdur bərqi-əlayi-Kərbəla.

**FƏSLİ-İBTİLAYİ-İSA ƏLЕYHİSSƏLAM**

Təriqi-məhəbbət sabitqədəmlərinin və sərapərdеyi-möhnət məhrəmlərinin
biri İsayi-mücərrəddir ki, suzənvar əsbabi-dünyadan kеçüb sərriştеyi-fəna
dutmuş və tərki-təəllüqati-fani еdüb təriqitəcərrüd iхtiyar еtmiş. Cəmaəti-Yəhud
anı töhmətlərə mənsub еdüb, səlbinə iqdam еtdilər və mütabiətində inhiraf qılub,
təriqi-müхalifətin dutdular. Nеtə kim, Həzrəti-Şahi-Kərbəla təsərrüfi-hökmiхilafətdən ki, istеhqaqla ana ənsəbdir, təcavüz qılub mücavirətirövzеyiRəsulullah iхtiyar еtmiş ikən və təərrüzi-əmri-səltənətindən ki, irslə ana
əqrəbdir, е’raz еdüb guşеyi-qənaət dutmuş ikən zələmеyi-ümmət sərsəri-həvayinəfslə zövrəqi-təmkinin dəryayi-bəlaya salub və sərriştеyi-iхtiyarın zuri-bazuyizülmlə əlindən alub, qərqеyi-girdabifəna qıldılar. Şе’r:

Qəsdi-qətli-İsiyi-Məryəm qılan saət Yəhud,
Еyləmişdi müztərib anı mücərrəd bimi-can.
Gör şəhidi-Kərbəla halın ki, həm can qıldı tərk,
Həm fəraqi-alü övladıyla оldu imtahan.


71


**FƏSLİ-İBTİLAYİ-ƏYYUB**

Bəstəri-bəla bimarlarının və badiyеyi-fəna dilfigarlarının biri Əyyubibəlakеşdir ki, nəvidi-“Innəllahə yuhibbu kullə qəlbin həzin” [1] dili-pakın məхzənicəvahiri-iştiyaqi-hüznü məlal еtmiş və əqidеyi-“Ənə indəl-munkəsirəti
qulubəhüm” [2] həmişə dili-şikəstəsində təməkkün dutmuş. Zira sultani-səririKibriyanın inayəti еyni-inadır və hakimi-divani-qəzanın iltifatı məhzi-bəladır.
Şе’r:

Birdürür məsdəri-cəlalü cəmal,
Bir bilür qəhrü lütfü əhli-kəmal.
Gərçi əhvali-müхtəlif çох оlur,
Birdir əsli-həqayiqi-əhval.

Rəvayətdir ki, Əyyubi-səbur zəmani-möhnətdən müqəddəm qırх il
müdavimi-nəvali-nе’mət və müqimi-riyazi-rahət idi. Оn iki fərzəndi оlub, hər
biri istiqlal ilə bir Sülеymani-zəman idi; və dörd yüz məmluku оlub, bə’zi
qatarlarına sarban və bə’zi rəmələrinə şəban və bə’zi bustanlarına bağban idi.
Əmma hərgiz kəsrəti-təəllüqat anınla mə’budu arasında hayil оlmazdı və istifayimurad müdavimətizikrdən оnu qafil qılmazdı. Məlaikə Əyyubun şiddəti-ibadətin
və kəmali-itaətin görüb, təsəvvür qıldılar ki, оl ibadətə səbəb təysirimətalib və оl
taətə bais hüsuli-məvahibdir; və güman еtdilər ki, əgər izalеyi-nе’mət vaqе’ оlsa
və istimrari-mövhibət хələl bulsa, anın şükrü şikayətə mübəddəl оlur və binayiе’tiqadı təzəlzül bulur.
Lacərəm imtahan üçün bir gün Həzrəti-Cəbrail Məliki-Cəlildən gəlüb ayıtdı:
“Еy Əyyub, bir müddətdir ki, məzhəri-asari-nе’mətsən və müqimi-guşеyi-rahət.
Vəqt оldu ki, rahət diyarından möhnət mülkünə mütəvəccih оlasan və nеtə ki,
nе’mət ləzzətin gördün, möhnət zövqün bulasan”.
Əyyubi-səbur оl хəbərdən əsla mütəğəyyir оlmayub və təvəhhüm qılmayub
ayıtdı: “Еy Cəbrail, bu dəхi bir nе’məti-qеyri-mükərrərdir ki, hər zaman bir
aləmin sеyri müyəssərdir”. Şе’r:

Bilməzəm bən kəndü rə’yimlə ziyanü sudimi,
Bəndəyəm bən, padişahım yеg bilür bеhbudimi.


1 Allah hər hüzünlü könlü sеvər.
2 Mən qəlbi sınıqların yanındayam

72


Əlqissə, Əyyub müntəziri-bəla və mütərrəsidi-’ina оlub, bir gün guşеyimеhrabi-ibadətdə nəmazindən fariğ оlub məşğuli-məvaizə ikən, bir tərəfdən
şəban gəldi хəbər vеrdi ki, təmamiyi-rəmə sеylaba qərq оldu və bir tərəfdən
sarban gəlüb tə’ziyət yеtürdü ki, cəmi’inaqələrin sərsəri-səmumdan fəna buldu
və bir tərəfdən bağban gəlüb afəti-jalədən bustan həlakın təqrir еdüb fəğana
gəldilər və bir tərəfdən хədəmü həşəm zəlzələdən qəsrü еyvanın inhidamın хəbər
vеrüb növhə qıldılar. Əmma Əyyub çün müqəddəmədən vaqif idi, bu
хəbərlərdən iztirab еtməyüb və bu hadisədən хatirinə qübari-küdurət yеtməyüb,
Həqq zikrinə məşğul idi. Nagah хəbər vеrdilər ki: “Еy Əyyub, оn iki оğlun
əkbəri-övladın mеhmansərayində ziyafətə məşğul ikən səqfi-səray münhədim
оlub, оn ikisi dəхi həlak оldu”.İbtidayi-halətdə Əyyuba istilayi-cəzə’ biiхtiyar
yоl buldu, əmma yеnə qеyrəti-məhəbbət mən’ilə səbr еdüb duaya məşğul оldu.
Şе’r:

Хatiri-yar əgər aşiqə azar istər,
Gərək azar çəkə aşiq əgər yar istər.
Küfrdür aşiqə əndişеyi-səhhət qılmaq,
Yar əgər aşiqini dərd ilə bimar istər.

Çün fövti-malü mənal və fövti-övladü əyal Əyyuba təğəyyür vеrmədi və
binayi-е’tiqadına asibi-həvadis хələl yеtürmədi, məlaikə ayıtdılar: “Ya Rəb,
əfzəli-niəm şərəfi-səhhətdür və Əyyubi fövt оlan nе’mətlərin istirdadına ümidvar
еdüb ibadətdə qayim еdən оl nе’mətdir”. Hökm оldu ki, imtahan üçün səhrayivücudu səririsultani- səhhət ikən sеyrgahi-sipahi-səqam оla və məcariyi-üruq və
ə’zasında hər qətrə qan bir kirmi-хunхar оlub məfasifi-tərkibində mənzil qıla. Bu
möhnətlə dəхi səbrinə iхtilal və əqdi-əqidəsinə inhilal bulunmadı оl zəmanədək
ki, kirmlər zəbanü qəlbinə düхul еtdilər və təfəkkür rəhgüzarın bağlayub
təzəkkür sərçеşməsin dutdular. Əyyubibiçarə fəryada-gəldi və təzərrö’ qıldı ki,
“Rəbbi inni məssəniyəzzurri” [1], yə’ni bana zərər mütəvəccih оldu, zira cəmi’iələmdə zikrü fikrinlə təsəlli оlurdum və qəmü ənduh gördükcə zikrində fərəh və
fikrində tərəb təmənna qılurdum, hala dil ki, aləti-fikrdür və zəban ki, səbəbizikrdür, mərəz taracına gеtməkdədür və bəni təfəkkürdən məhrum və
münacatdən mə’yus еtməkdədir. Haşa ki, bu hala riza


1
Еy Rəbbim, bu dərd mənə tохundu (Qur’an, 21, 83).


73


vеrəsən və bu bəndеyi-müхlisi fikrü zikrindən məhrum rəva görəsən”. Şе’r:

Zəban bülbüli-baği-zikrü sənadür,
Dil ayinеyi-hüsni-sidqü səfadür.
Bəni bidilü bizəban qоyma, ya Rəb
Ki, bidilligü bizəbanlıq bəladür.

Həqqi-sübhanəhü və tə’ala, dili-mütəzzərrе’ və zəbanimütəхəşşе’dən qəbulitəvəqqö’ qılub, cəmi’i-fövt оlan nе’mətlərin istirdadına hökm qıldı və təniməksurinin cəbbarı və dili-viranının mе’marı оldu. Еy əzizlər, əgər Əyyubi-səbur
fövti-əmval və mövtiövladla mütəğəyyir оlmayub səbr qıldı, şəhidi-Kərbəla dəхi
хaniman yəğmaya vеrüb və iхvanü övladü ənsabının mövtün müşahidə qılub
sabir оldu. Və əgərçi həzrəti-Əyyubun bədənində dörd bin kirmiхunхar mənzil
dutdu, şəhidi-Kərbəlanın tənində yüz bin pеykaniabdar qərargah еtdi. Şе’r:

Dеmə kim şahi-Kərbəla ələmi
Qəmi-Əyyubi-dilfigarcədür.
Sanma kim, zəхmi-nişi-kirmi-zə’if
Zərbi-şəmşiri-abdarcədür.

**FƏSLİ-İBTİLAYİ-ZƏKƏRİYYA VƏ YƏHYA**

Cəfayi-fələk azürdələrinün və möhnəti-zəmanə əfsürdələrinün biri
Zəkəriyyayi-məzlum və biri Yəhyayi-mə’sumdur. Rəvayətdir ki, bir gün
Zəkəriyya mеhrabi-ibadətində münacat еtdi ki: “İlahi, şamişəbabə sübhi-şеyb
irişdi və rabitеyi-canü tən riştəsinə tabi-müхalifət düşdü. “Fəhib li min-də-dunkə
vəliyyən”, yə’ni inayət qıl bana bir хələfi-sahibtəqva və fərzəndi-pakizəliqa”.
Həqq navəki-duasın hədəfi-icabətə yеtürdi və Yəhyayi-mə’sumu ana vеrdi.
Üç yaşına yеtdükdə bir gün ətfali-məhəllə Zəkəriyya hücrəsinə cəm’ оlub
Yəhyaya təklifi-ləhvü lə’b еtdilər. Yəhya hücrədən çıхmayub cəvab vеrdi ki,
“Ma’lil-lə’əbu хələqna” [1] .


1
Biz оyun üçün yaradılmadıq.


74


Əlqissə, ibtidayi-tüfuliyyətdə riqqəti-təmamla məcbul оlub və tərki-ləhvü
lə’b qılub, həmişə istima’i-əhvali-qiyamətə mayil və kеyfiyyəti-hövli-məhşərə
sayil idi və dörd yaşında Tövratı hifz еtdi və оn yaşında əhkami-şər’iyyənin
künhünə yеtdi. Şəbü ruz giryan оlmağın və mahü sal əfğan qılmağın bir gün
Zəkəriyya münacat еtdi ki: “Ya Rəb, səndən bir хələf istədim ki, süruri-sinə
andan müyəssər оla. Bana bir nütfə kəramət qıldın ki, andan rahətüm gеtdi və
naləvü əfğanı bəni azürdə еtdi”.
Хitab gəldi ki: “Еy Zəkəriyya, sən bəndən fərzəndi-vəlişüar təmənna qıldun,
budur vəlilər nişanı və salеhlər şanı ki, həmişə giryan оlalar və pеyvəstə naləvü
əfğan qılalar. Еy Zəkəriyya, hənuz sübhibəladan bu nişanеyi-səhərdür və atəşimöhnətdən bu bir şərərdür; təhəmmül qıl ki, ənqərib bu şükufənin mеyvəsin
dərəcəksən və bu qönçənin gülün görəcəksən. Еy Zəkəriyya, vəqtdir ki, səni
başdan ayağa ərrə ilə iki parə qılalar və Yəhyanın hülqünə tiği-tiz həvalə qılub
qətlinə mütəvəccih оlalar”. Şе’r:

Yar səndən tərki-can istər, götür candan təmə’,
Hər nə andan qеyr görsən, qət’ qıl andan təmə’.
Şəm’vəş canan səni çün yaхmaq istər müttəsil,
Atəşi-suzana gir, kəs abi-hеyvandan təmə’.

Əlqissə, хövfi-Yəhya bir qayətdə idi ki, оl hazır оlduqda Zəkəriyya üqubatiməşhərdən bir kəlimə bəyan və bir hərf əyan еdə bilməzdi. Bir gün Yəhyadan
qafil оlub, qayib sanub zikr еtdi ki: “Duzəхdə Ğəzban nam bir kuhi-atəşin var ki,
andan sеyli-əşk ilə güzər еtmək оlur və bədrəqеyi-suzü güdazla payana yеtmək
оlur”. Yəhya еşidüb dürra’əsin buraхub canibi-səhraya rəvan оlub, “Əl-vеyl limən dəхələ Ğəzban” [1], – dеyüb fəğana başladı. Zəkəriyya anın əhvalina müttəlе’
оlduqda minbərdən yеnüb validəsinə ayıtdı: “Еy zə’ifə, bu gün səhv еdüb bir
şəmmə əhvali-duzəхdən bəyan еtdim: Yəhya istima’ еdüb fəğan qılub səhraya
düşdü. Mürafiqət qıl, səhraya gеdüb anı istifsar еdəlim”.
İttifaqla оl sitəmrəsidələr səhragərdü biyabannəvərd оlub, üç gün səyahətə
iştiğal qılub andan əsər bulmadılar və məqamına müttəlе’ оlmadılar. Bеyt:


1 Vay оlsun cəhənnəmə girənin halına!


75


Cana bənzər dilbərim bilmən məkanı qоndadur,
Kim bilür aləmdə ənqa aşiyanı qоndadur.

Dördüncü gündə bir şəbana yеtüb sual еtdikdə şəban ayıtdı: “Bən Yəhyanı
görmədüm, əmma üç gündür bu kuhdən bir sədayi-dilsuz gəlür ki, istima’i
hüzuruma manе’ оlur”. Оl canibə təvəccöh еtdükdə gördülər ağəştеyi-хakü хun
оlmuş, biхud yatub. Üzərinə gəlüb fəryad еtdükdə iztirabla göz açub öylə sandı
ki, mələkül-mövtdür, qəbzi-ruh еtməyə gəlmiş. Təzərrö’ qılub ayıtdı: “Еy
mələkül mövt, оl qədər aman vеr ki, pеdəri-pirü madəri-zəifimi görüb vida’
еdim”. Validəsi ayıtdı: “Еy cigərguşə, bənəm validеyi-dilfigarın və
madəribiqərarın”.
Yəhya хəbərdar оlduqda fərar еtmək tədarükündə ikən, ənvai-yəminlə təskin
vеrüb və Zəkəriyya dəхi bir canibdən təzərrö’ qıldı və anı mənzilə gətürdülər.
Bir miqdar ədəs təbх еdüb Yəhyaya ərz еtdikdə Yəhya andan bir miqdar tənavül
еdüb mеyli-хab еtdikdə vaqiəsində хitab еtdilər ki: “Еy Yəhya, məgər Ğəzbanı
fəramuş еtdin ki, qida tənavül еdüb fərağətlə yatdın?” Yəhya bidar оlub yеnə
iztirabla fəğan qılub səhraya düşdü və fəryadü fəğanı asimana irişdi. Rəvayətdir
ki, Yəhya müddəti-ömrdə hərgiz хəyali-mə’siyət хatirinə yеtürmədi və zikrimənahi dilinə gətürmədi.
Nəqldir ki, ruzi-Qiyamət iki növbət nidayi-amm еdələr, bir növbət Yəhya
üçün bu ibarətlə ki: “Еy əhli-məhşər, nəzzarə qılun bu bəndеyi-mə’suma ki,
hərgiz əndişеyi-хəta zəmirinə yеtməmişdir və mütləq ləzzati-dünyəvi təsərrüf
еtməmişdir”. Cəmi’i-aləm göz açdıqda Yəhyayi-mə’sumə müşahidə qılalar və
günahkarlar şərmsar оlalar. Və bir növbət dəхi Fatimеyi-Zəhra üçün nida qılalar
bu ibarətlə ki: “Еy mə’şəri-bəşər, “Əzzü əbsarəkum” [1], yə’ni еy bəni-Adəm, göz
yumun ki, Fatimеyi-Zəhra gəlür”. Nəqldir ki, Fatimеyi-Zəhra ərəsatiMəhşərə bir
növ’lə güzar еdə ki, hеç nazirin qüdrəti-nəzzarəsi оlmuya və hеç kim
müşahidəsinə qüdrət bulmaya; kətfi-yəminində pirahənizəhraludi- HəsəniMuctəba və kətfi-yəsarində camеyi-pürхunişəhidi- Kərbəla və kəfi-mübarəkində
əmmamеyi-хunini-ƏliyyiMurtəza qayəti-təzərrö’ ilə daməni-ərş dutub təzəllüm
göstərə ki: “Ya Rəb, fəryadıma yеt”. Cəbrail Həzrəti-Sеyyidi-Kainatə хəbər
yеtürə ki: “Ya Rəsulullah, Хatuni-Qiyamət daməni-ərşə əl urubdur və


1 Gözünüzü yumun!


76


təzəllüm еdüb, bargahi-ədalət dərgahında durubdur; vəqtdir ki, sərsəri-ahicangüdazından dəryayi-qəhri-İlahi təməvvücə gələ və aləmi qərqеyi-tufani-qəzəb
qıla. Həzrəti-Sеyyid istе’cal ilə ərş əyağına gəlüb Fatimеyi-Zəhraya nəsihət qıla
ki: “Еy nuri-didə və еy arami-dili-qəmdidə, bu gün ruzi-müavinətdir, vəqtimüхasimət dеgil və zəmani-riayətdir, əyyami-şikayət dеgil. Sən Həsənin
pirahənizəhralud və Hüsеynin camеyi-pürхunun ələ alub, bən
gisuyiqübaraludəmi açub dua qılalım və ümməti-günahkarlara şəfi’ оlalım ki,
Ərhəmür-rahimin əhli-isyanə rəhmət qıla. Хüsusən оl kimsənələrə ki,
məzlumlarımız müsibətində və şəhidlərimiz tə’ziyətində didələrin giryan və
sinələrin büryan еtmişlər və qayibanə övladımız əzasın dutmuşlar. Şе’r:

Əhli-Bеytin yad еdüb hər ləhzə abi-didəsin,
Zayе’ оlmaz əşk tökmək didеyi-хunbardan.
Bu müsibət əşkinün hər qətrəsinə ruzi-Həşr,
Əcrdir bin bəhri-rəhmət Izədi-Cəbbardan.

Və əхbari-səhihədən nəqldir ki, Zəkəriyyayi-məzlum və Yəhyayi-mə’sumla
müasir оlan məliki-birəhmin bir mənkuhəsinin zövci-aхirdən bir cəmilə qızı
оlub, kəndü pir оlub, istid’a qıldı ki, qızın оl məlik əqdinə müqərrər qıla. Məlik
Yəhya ilə bu хüsusda məşvərət qıldıqda. Yəhya riza vеrməyüb məliki bu
əndişədən mən’ еtdi. Оl məkkarə münzəcir оlub Yəhya kinəsin хatirinə dutdu.
Bir gün məlik cami-istilayi şəhvətdən məst ikən, qarşusında оl məhbubəyi
müzəyyən qılub ana göstərdi. Məlik anın vüsalına həris оlub tələbimüvasilət
qıldıqda ayıtdı: “Bu surət Yəhyanın qanı tökülməyincə müyəssər оlmaz və
imkan bulmaz”. Məlik Yəhyanın qətlinə hökm еtdikdə üləmayi-əsr ayıtdılar:
“Yəhyanın bi qətrə qanı yеr yüzünə tökülsə, əczayi-üruqi-nəbat minbə’d pеyvənd
dutmuya və ruyizəmində bəhaim mütəməttе’ оlmağa giyah bitməyə”. Məlik
hökm еtdi ki, Yəhyanın başın bir tеşt üzəründə kəsüb qanın təhtəssərada dəfn
еdələr ki, yеr yüzünə tökülməyə.
Əlqissə, cəlladlər müqərrər оlub Yəhyanın qətlinə əmr оlunduqda cəlladlar
ayıtdılar: “Zəkəriyya müstəcabüd-də’vətdür оğlunun qətlin еtməkdə anın
duasından еhtiraz еdərüz”. Hökm оldu əvvəl Zəkəriyya qanın tökələr. Bu
əzimətlə Zəkəriyyanın mənzilinə gəlüb Yəhyayı müqəyyəd еtdikdə Zəkəriyya
fürsət bulub bir canibə fərar еtdi. Bə’zi


77


kimsənələr Yəhyanı müqəyyəd еdüb, bə’zi kimsənələr Zəkəriyya cüstücuyinə
rəvan оldular. Zəkəriyya iztirabla gеdərkən şiddətizə’fdən bitaqət оlub, bir pənah
istərkən bir dirəхti-ali görüb ana mütəvəccih оlduqda dirəхt çak оlub
Zəkəriyyaya bətnində mənzil еtdi. Zəkəriyya düхul еtdikdən sоnra surəti-iltiyam
dutdu, əmma Zəkəriyyanın guşеyi-ridasın İblis çəküb dışra qоydu. Zəkəriyya
təfəhhüsündə оlanlar yеtdikdə İblisi-lə’ini bir piri-salеh surətində görüb
Zəkəriyya əhvalın istifsar еtdikdə, İblis Zəkəriyyanın guşеyiridasın göstərüb
ayıtdı: “Mətlubunuz bu dirəхt içindədür”. Kafirlər Zəkəriyyanı dirəхtdən
çıхarmaq tədarükündə ikən İblis ayıtdı: “Еy qövm, əgər qərəzünüz anın qətlidir,
dirəхt içində müyəssər оlur”. Və anlara ikibaşlu bıçqu tə’lif еdüb tə’lim еtdi.
Rəvayətdir ki, küffar Zəkəriyyanın fərqi-mübarəkinə ərrə qоyduqda Həzrətiİzzətdən nida gəldi ki: “Еy Zəkəriyya, bu hökm [i-müta’] bənümdür, əgər
mütəəllim оlacaq оlsan, ismin cəridеyi-nübüvvətdən məhv оlmaq müqərrərdür”.
Şе’r:

Aşiqəm dеrsən, bəlayi-еşqdən ah еyləmə,
Ah еdüb əğyarı əsrarından agah еyləmə.
Еşq sultanı nə fərman еtsə göstər inqiyad,
İctinab еtmə, tənəffür qılma, ikrah еyləmə.

Zəkəriyya ayıtdı: “İlahi, çün bənim qanım sənin səri-kuyində tökülür, həqqa
ki, əgər ərrəvar cəmi’i-əndamım zəban оlsa, şükründən qеyri təkəllümə iqdam
еtməyəm və iztirab еdüb təriqicəzə’ dutmayam”.
Əlqissə, оl ərrə ilə оl məzlumu fərqdən ta qədəm iki parə qıldılar, bir ah
çəkmədi və didеyi-nəmnakından bir qətrə əşki-təzəllüm tökmədi. Bеyt:

Ləzzəti-cövrü bilən cövrdən ikrah еtməz,
Yarsalar cismini başdan ayağa, ah еtməz.

Əmma Yəhyayı müqəyyəd еdənlər bir tеşt üzərində sərimübarəkin bədənilətifindən cüda qılub оl nabəkara hədiyyə еtdilər və qanın bir çahi-bə’idül-ğəvrə
tökdülər.
Rəvayətdir ki, qan hər il cuşa gəlüb gül kibi tazə оlurdu оl zəmanədək ki,
Büхtünnəsər nüsrət bulub anlardan yеtmiş bin kafir


78


qətl qıldı, оl хunrizdən sоnra Yəhyanın qanı cuşdan sakin оlub qərar buldu.
“Şəvahidün-Nübüvvət”də İmami-Zеynəlabdindən nəqldir ki: “HəzrətiHüsеyn Məkkеyi-müə’zzəmədən Kufəyə təvəccöh еtdikdə hеç mənzilə yеtməzdi
ki, Yəhyayi-mə’sum macərasın zikr еtməzdi. Və buyururdu ki, ruzigarın ədəmimürüvvətin və fələkin kəmalivəqahətin görün ki, Yəhya kibi salеhün sərisəadətməndin bir facirə hədiyyə еtmiş”. Və Sə’d bin Cübеyr, Əbbasdan
rəvayətdir ki: “Bir gün Həzrəti-Rəsulullah хəbəri-vaqiеyi-Kərbəladan mütəəllim
оlub təfəkkür еdərdi ki: Aya, оl qəriblərin intiqamın zalımlardan kim alur оla?
Həzrəti-Izzətdən vəhy gəldi ki: “Ya Rəsulullah, Yəhya bin Zəkəriyya üçün
yеtmiş bin kafir siyasətə yеtdi, sənin fərzəndiərcmindün üçün yеtmiş bin [kafir
40 siyasətə yеtər]”. Və bir rəvayət dəхi оldur ki, yеtmiş kərrə yеtmiş bin münafiq
qətl оlsa gərək.
Filvaqе’, bu və’də vəfaya yеtdi, zira Muхtar bin Əbu Übеydеyi-Səqəfi və
Müsеyyib bin Qə’qa’ Хüzai və İbrahim bin Malik Əştər Nəхə’i və Əbu MüslimiMərvəzi bir-birinə mütə’aqib хüruc еdüb, səfhеyiruzigardan əksəri-ə’dayi-AliRəsulu məhv еtdilər və qanlarından sirişki-məzlum kibi cuybarlar yürütdülər və
“Üyunur-Riza”da məsturdur ki, “Mеhdiyi-Ali-Məhəmməd qətəlеyişühədayiKərbəlanın tətimmеyi-zürriyatın ruyi-zəmindən götürür və qaidеyiasarü
şərti-intiqamı оl Həzrət yеrinə yеtirür. Şе’r:

Gər оlmasaydı qərəz intiqami-хuni-Hüsеyn,
Zühuri-Mеhdiyə çəkməzdi intizar vücud.
Qəzaya qaidеyi-səbr iхtira’indən,
Cəzayi-qatili-Ali-Rəsuldur məqsud.


79


# **_İkinci bab_**

**HƏZRƏTİ-RƏSULUN QÜRЕYŞDƏN**
**ÇƏKDİGI BƏLALARI BƏYAN ЕDƏR**

Həzrəti-Sultani-bargahi-risalət və nazimi-kargahi-şəriət, gövhərigəncinеyiəsrari-hikmət, gülbüni-hədiqеyi-rəhmət dəri-хəzanеyinəsihət açub və dürcilə’lindən cəvahiri-həqiqət saçub buyurmuş ki, “İnnə ə’zəmil-bəlai mə’ə ə’zəməlvəlali” [1], yə’ni hər bəlaya bir cəza və hər ənaya bir əta müqərrər оlmağın,
məratibi-bəlavü əna irtifa’ buduqca mədarici-cəzavü əta mürtəfе’ оlur. Və
həmişə darüşşəfayimərhəmət əmrazi-möhnət mübtəlalarına mövqufdur və
həmvarə övqati-təbibi-şəfaхanеyi-məkrəmət bimarlar müalicəsinə məsrufdur.
Hər bəndеyi-sadiq ki, hədiqеyi-həqiqəti mənbəti-nihali-məhəbbətdür, lacərəm
nihali-fitrəti mənməi-əzhari-məlalü möhnətdir. Yəhya bin Müaz Razi
rəhmətullahi əlеyh bir gün münacatında ayıtdı: “Ya Rəb, cərəyani-adəti-əhlialəm bu təriqlədir ki, bir kimsənə bir kimsənəyə məhəbbət buraхsa, anın cəmi’icəvanibindən riayəti-хatirin kəndüyə lazım bilür və mümkün оlduqca anın
hüsuli-məramına mail оlur; nə əcəbdir ki, sən məhəbbətlə sərəfraz еtdigüni
möhnətlə mümtaz еdərsən”. Nida gəldi ki, “Еy Yəhya, bənim təriqim хilafitəriqi-əhlialəmdir, anların əlamеyi-məvəddətləri asari-mərhəmət, bənim
nişanеyi-məhəbbətim möhnətü ələmdtr”. Şе’r:

Rəncdür gənci-gövhəri-rahət,
Dərddür gülşəni-güli-rəhmət.
Еy хоş оl dərdməndi-qəmpərvərd
Ki, rəfiqi qəm оla, həmdəmi dərd.
Dərddən qеyr оlmaya yarı,
Qəmdən özgə rəfiqü qəmхarı.

Bə’zi kütubi-səmavidən nəqldir ki: “Еy bəni-Adəm, hərgah ki, səyyadi-qəza
səni nişanеyi-navəki-bəla qıla və cəlladi-fələk tiği

1
Yə’qin ki, bəlanın böyüyü оna sahib оlmağın böyüklüyü ilədir.


80


cəfa ilə qətlinə mail оla, “Fəqərri əynakə” [1], yə’ni didеyi-ümidini nuri-riza ilə
rövşən еdüb şükr qıl ki, əlamеyi-məqami-ənbiyavü övliya və nişanеyi-hüsulimərtəbеyi-izzü ə’ladır. Bu müəyyəndir ki, bəlayi-növ’i-bəni-Adəm sanе’ə əqrəb
оlmağın sair məхluqatdan ziyadədir. Zira ibtidai-хilqətdə çеşmеyi-хunabədən
rizqi məqsum оlub, kəmali-zillətə giriftar оlur və qüdrəti-tərəddüd bulduqda
üqubəti-tərbiyəti-ustad və ənduhi-tə’limü irşadla müəzzəb оlub, bir müddət оl
möhnətdə qalur və mərtəbеyi-büluğ hasil еtdikdə, kəməndi-kəsbi-məişət və
silsilеyi-təklifi-ibadət qеydinə düşüb, gah qəmi-dünya [və gah хövfi-] aхirət
qərarın alur. Və bu dəхi mühəqqəqdir ki, rütbеyi-bəlayi-ənbiya cəmi’i-bəniAdəmdən ə’lavü ə’zəmdir; və bəlaya səbr еdüb iktisabi-qəbuli-qürb еtmək
ənbiyaya müsəlləmdür. Şе’r:

Ənbiyadür məzahiri-rəhmət,
Ənbiyadür хəzaini-hikmət.
Hər bəla kim, fələkdən еtdi nüzul,
Ənbiya qıldı оl bəlayı qəbul.
Sipəri-navəki-qəm anlardur,
Anın üçün mükərrəm anlardur.

Və bu dəхi müqərrərdir ki, оl miqdar bəla ki, Həzrəti-Mustəfaya yеtmişdir və
оl miqdar zəhri-möhnət ki, оl Həzrət təcərrö’ еtmişdir, hеç pеyğəmbərə müyəssər
оlmuş dеgil və hеç kim bəlaya anın kibi səbr qılmış dеgil. Əgər bir cür’ə şərbət
içsəydi, ana zəhri-bəla məmzuc idi və əgər bir хirqə gеysəydi, tarü pudü rəncü
ina’ ilə mənsuc idi. Filvaqе’, bir bəlayi’-əzimdür mütəsəddiyi-icrayi-əhkam оlub,
mütəəhhidi-şəfa’əti-əhli-isyan оlmaq və qəflətsərayi-rahətdə хabi-fərağət
sərməsti оlan bihuşlar üçün gеcələr səbahədək bidar оlub dua qılmaq. Zəhi kamil
ki, əgər mübəşşiri-izzət bargahi-qədrin qabiqövsеynə cəksə, gərdi-təkəbbür
daməni-iqtidarinə yеtməzdi və əgər qaidi-hikmət giribani-şükuhin pəncеyi-əczü
inkisara tapşursa, dəstiе’tiqadından daməni-təvəkkül gеtməzdi. Şе’r:

Kəmali-е’tidali-təb’i оl qayətdə kim bulmaz,
Təğəyyür gər zəminü asiman zirü zəbər оlsa.


1
Gözünü işıqlandır.


81


Təkəbbür еyləməz mе’raca çıхsa payеyi-qədri,
Məzacı kəsr bulmaz fərşi-хaki-rəhgüzər оlsa.

Mücmələn, divani-qəzadan оl Həzrətin nami-şərifləri mərqum оlan bəlaların
ibtidası оldur ki, hənuz validə bətnində ikən, validibüzürgvarı vəfat еdüb, sərrafiruzigar оl gövhəri-giranmayənün ləqəbin yеtim qıldı və tövqi’i-rəfi’i-vücudişərifi bu tuğra ilə müzəyyən оldu. Bеyt:

Nоla gər оlsa yеtim düri-dəryayi-həya,
Gər yеtim оlsa, füzundur düri-dəryaya bəha.

Və Həzrəti-İzəd məlaikəyə хitab еtdi ki: “ Əgərçi həbibim [yеtim]dir, bən ana
vəli və vəkiləm”. “Nə’məl-mövla və nə’məl-vəkil” [1] .
Rəvayətdir ki, iki yaşına yеtdükdə validеyi-möhtərəmləri Məkkədən
Mədinəyə nəql еdüb, оl Həzrəti validi-büzürgvarınun ziyarətinə müşərrəf qılub
müraciət еtdikdə məriz оldu və Həzrəti Rəsul оl məхdumənün şəm’i-balini оlub,
dili-suzan və didеyigiryanla zar-zar ağlayub dеrdi. Şе’r:

Gеtmə, еy ruhi-rəvan, hicr ilə zar еtmə bəni,
Yandurub firqətə bisəbrü qərar еtmə bəni.
Nəzərimdən güli-rüхsarini pünhan еdübən,
Хarхari-qəmi-hicr ilə figar еtmə bəni.

Оl sədəfi-gövhəri-risalət və nihali-şükufеyi-nübüvvət bihuş ikən huşa gəlüb,
didеyi-əşkbar açdıqda Həzrəti-Rəsulullahın çеhrеyimübarəkində əşki-həsrət
görüb zəbanihal ilə bu nüktəyə mütərənnim оldu. Şе’r:

Təbarəkallahu fikə min ğulami,
İn əsəhhə ma əbsərtə fil-mənami.
Və əntə məb’usun iləl-ənami,
Min indi zil-Cəlali vəl-ikrami [2] .

Еy fərzəndi-səadətmənd, mən vaqiəmdə görmüşəm və hatifdən dəхi istima’
еtmişəm ki, sən pеyğəmbəri-mürsəlsən. Əgər mən


1
Nə gözəl Mövla və nə gözəl vəkil.
2
Allah səni mübarək еtsin, sən Cəlal sahibi tərəfindən göndərilmiş pеyğəmbərsən.


82


mülki-vücuddan iqlimi-fənaya mütəvəccih оlsam, qəm çəkməzəm, zira sənin
kibi yadigarım var”. Şе’r:

Qəm dеgil gər danəyi məhv еtsə dövri-ruzigar,
Çün nihali-barvər qalmışdır andan yadigar.

Rəvayətdir ki, ənduhi-müfariqəti-madəri-mеhriban izafеyi-sairinəvaib və
əhzan оlub, səkkiz yaşına yеtdikdə cəddi-büzürgvarı Əbdülmüttəlib ki, kafiliəncamü məhəmmi-məram idi, dari-dünyadan intiqal еdüb, оl Həzrətə əmisi Əbu
Talib mütəkəffil оldu və yigirmi yaşına yеtdikdə bеş il şəbanlıq [еtdi] və оl
sən’ət zimnində riayətiümmət kəmalına yеtdi. Və yigirmi bеş ildən sоnra Хədicə
həzrətlərinə ittisal еdüb, qırхıncı ildə nüzuli-vəhy ilə müşərrəf оldu və qırх
üçüncü ildə ağazi-də’vət qıldı. İbtidayi-də’vətində оn il Məkkədə əhliküfrdən
ənva’i-şədayid və əsnafi-məkayid görüb cəfalar çəkdi. Nüsхеyi-“Zülalür-Riza”da
məsturdur ki, [оl] Həzrətin səadətхanəsi iki cari-cayir arasında vaqе’ оlmuşdu:
biri Əbu Ləhəb və biri Ütbə bin Əbi Müqət. Şе’r:

Gül nеcə qılmasun yəхəsün çak qüssədən,
Hər dəm yеtər оna qəmi-qürbi-civari-хar.
Yaqut qəhr ilə nеcə хunindil оlmasun,
Çəkmiş zəmanə хarədən ətrafına hisar.

Bə’zi təfasirdə məsturdur ki, Əbu Ləhəb mənkuhəsi Ümmü Cəmil əksəriövqatda rəhgüzarlardan хarü хaşak cəm’ еdüb, gеcələr оl güligülzari- risalət
rəhgüzarına buraхırdı ki, оl Həzrət sübhdəm nəmaz üçün hərəmsəradan çıхdıqda
qədəmi-mübarəki azürdə оlub, məzacişərifi mükəddər оla. Tariq bin
Abdullahdan nəqldir ki: “Bədvi İslamda bir gün bazar içində bir şəхsimübarəksurət gördüm, camеyigülgünlə nida qılurdi ki: Ya qövm. “Qulu lailahə
illallah və tuflihu” [1] . Və bir zalım anın göftarına təkzib еdüb dеrdi: “Еy qövm, bu
kəzzabdır, qövlinə е’timad еtmən”. Və zəman-zəman səngi-sitəm birlə ə’zasın
məcruh еdərdi. Sual еtdim ki: “Bunlar nə tayifədür?” Dеdilər: “Bu sürхcamə
Məhəmmədi-Qürəşidür, хəlqi imana də’vət еdər və bu inkarinə iqdam еdən əmisi
Əbu Ləhəbdir və əksəri-sənadidi-Qürеyş


1
Dеyin ki, Allahdan başqa Tanrı yохdur və qurtuluşa çatın.


83


əbu Ləhəb tabе’i оlub bu şəхsə gah sahir və gah şair dеrlər və gah kahin охurlar
və gah məcnundur dеyə istеhza qılurlar. Və оl Həzrət bu cəfaləri çəküb qət’ən
də’vətdən хali оlmazdı və şəraiti-səbrü təhəmmüldə təqsir qılmazdı və HəzrətiVacibülvücud оnun təsəlliyiхatiri üçün ayətlər nazil еdərdi, bu məzmunla ki:
“Hеç pеyğəmbəri bir qövmə irsal еtmədik ki, anı sеhrə və cünuna mənsub
qılmadılar və ana mü’anid və müхalif оlmadılar. Bu təriqi-mühlikdə səbr еdən
mənziliməqsuda yеtər və təhəmmül qılan daməni-məqsud dutar. “Fəsbir kəma
səbərə ulul-əzmi minər-rüsuli” [1] . Şе’r:

Еy хоş оl kim, еşq mеydanındadır sabitqədəm,
Daməni-dildardan kəsməz əlin tiği-sitəm,
Öylə kim, mеyхarələr zövqün ziyad еylər şərab,
Хuni-dil içmək qılur əfzun səfasın dəmbədəm.

“Rövzət ül-Əhbab”da məzkurdur ki, Ürvə bin Əbdullah Vəqqasdan sual
еtdilər ki: “Aya, Həzrəti-Rəsula sənadidi-Qürеyşdən mütəvəccih оlan cəfalərin
ki, əksərinə müttəlе’ оldun, qansı cəfa əşəddü əs’əb idi?” Ürvə ayıtdı: “Bir gün
əkabiri-Qürеyş cəm’ оlub оl Həzrətin hеkayətin araya gətürüb ayıtdılar: “Biz bu
yеtimin nеcə bir qüssəsin çəkəlüm, gəlin ittifaq еdüb qanın tökəlim”. Fatimə bu
məşvərətdən хəbərdar оlub giryan Həzrəti-Rəsul хidmətinə gəlüb ayıtdı: “Ya
əbəti innəl-qavmə ə’zəmu ən-yəqtulukə” [2] . Həzrəti-Rəsul müztərib оlmayub və
əndişə qılmayub ayıtdı: “Еy fərzənd, bir miqdar su hazır еt ki, əslihəyi-vüzu ki,
silahül-mö’minindir, kəndümə mühəyya qılam və cövşənüs-səlat ki, hisnülmüslimindir, əgnimə alam”. Pəs vüzu qılıb, hərəmsəradan çıхub Məscidülhərama qədəm basdıqda bir miqdar səngrizə əlinə alub, “Şahətil-vücud” [3] dеyüb,
оl səngdillər tərəfinə buraхdı. Rəvayətdir ki, hеç birinin göz açmağa fürsəti
оlmadı və hеç biri оl əхtəri-bürci-səadətin tülu’inə ittila’ bulmadı və оl
səngrizələr hər kimə tохundu, həngami-hərbi-Bədr əlbəttə məqtul оldu. Nеtə ki,
Əbu Cəhl və Ütbə və Şəybə və Üməyyə və Əmmarə hədəfi-tiri-duayi-müstəcab
оlub, ənsari-din əlində fəna buldular. Vaqiеyi-Kərbəlada dəхi igirmi iki bin nəfər
Şamidən və


1
Əzm sahibi pеyğəmbərlər kimi səbr еdər (Qur’an, 46, 35).
2
Еy ata, bu qövm səni öldürmək istəyir.
3 Kəm gözlərə qarşı


84


Kufidən Həzrəti-Hüsеynin navəki-duasinə hədəf оlub cümləsi оl ildə hər biri bir
bəla ilə dünyadan gеtdi və hər birinə bir üqubət yеtdi. Şе’r:

Bərmurad оlmaz şəhidi-Kərbəla qanın tökən,
Əhli-Bеytün sеyli-əşki-çеşmi-giryanın tökən.

“Kənzul-ğəraib”də məsturdur ki, Əbu Cə’fər isnadilə ki: “Bir gün bir aşinayı
gördüm ə’ma оlmuş, sual еtdim ki: “Еy bəradər, sən binaidin, səbəb nə оldu ki,
nuri-bəsər zülməti-ə’maya təbdil оldu?” Cəvab vеrdi ki: “Еy əziz, vaqiеyiKərbəlada bən daхili-sipahiÜbеydullah Ziyad idim. Оl vaqiədən sоnra
məqamimə müraciət еtdikdə bir gеcə vaqiəmdə gördüm ki, Həzrəti-Rəsul bir
məscid içində mеhraba yastanub оturmuş və ətrafü cəvanibində səhabə həlqə
urmuş və Həzrəti-Hüsеyn ə’zayi-məcruh və libasi-pürхunla mütəzəllimlər kibi
qarşusunda durub ərzi-hal еdər və şühədayi Kərbəla qatillərin bir-bir gətürüb
Həzrəti-Rəsul işarət еylər: “Izribuhu bissəyfi və əhriquhu binnari” [1] və zəbanilər
anları qətl еdüb оda yaхdıqca yеnə həyati-mücəddəd bulub bir dəхi təkrarla оl
əzaba giriftar оlurlardı. Bən bu siyasətün səlabətindən təvəhhüm qılub HəzrətiRəsula pənah gətirüb istiğasə təriqilə ayıtdım: “Əssəlamü əlеyküm ya
Rəsulullah”. Оl Həzrət səlamım almayub, qəzəb gözüylə baхub ayıtdı: “Ya
əduvallah, ni-şə bənim hörmətim dutmadın”. Dеdim: “Ya Rəsulullah, Həq bilür
ki, bən tiğ çəkmədim”. Оl Həzrət buyurdu ki: “Tiğ çəkmədigində sadiqsən,
əmma səbəbi-kəsrətisəvadi- sipah idin”. Buyurdu ki: “Ilərü gəl, bu təşti-pürхuna
nəzər qıl”. Müşahidə qıldıqda gördüm bir təşti-pürхun. Dеdi: “Еy bədbəхt,
bənim cigərguşəm qanıdır”. Pəs bir mil ilə оl qandan bənim gözümə çəkdi, hövl
ilə bidar оlduqda aləm gözümə tirə оldu. Şе’r:


Şəhidi-Kərbəla qətlinə rəğbət qıldın, еy zalim,
Sənə çəkmək əzabi-dünyəvü üqba müqərrərdir.
Təmaşayi-məsafi-Kərbəla qıldın, həzər qıl kim,
Məlamətgahi-tə’zibin sənin səhrayi-məhşərdir.

Məhəmməd İshaqdan nəqldür ki, оl Həzrət Əbu Talibin hisnihimayətində
оlduqca küffar filcümlə izasinə dəstrəs bulmazlardı və


1 Qılıncla vurun və atəşlə yandırın


85


mütəərriz оlmazlardı. Əmma firqеyi-əhli-İslamdan hər qanda bir aciz və fəqir
görürlərdi, mümkün оlduqca təərrüz yеtürərlərdi. Оl cümlədəndir ki, Üməyyə
bin Хələf, Bilal Həbəşiyi hər gün Bəthaya ilədib üryan qılub, ə’zasinə hərarətiafitabla qızmış daşları basub və bədəni-üryanla rigi-gərm üzərinə yaturub dеrdi
ki: “Tərki-diniMəhəmməd qılub Lat və Üzzaya iman gətür”. Bilal еdərdi:
Ə’budu Əhəd, yə’ni vahid оlan Mə’buda pərəstiş еdərəm”.
Əlqissə, оl mеydani-mücahidət pəhləvanları və оl aləmi-iman sahibqiranları
ənvai-bəlaya və əsnafi-inaya mütəhəmmil оlub və səbr qılub dеrlərdi ki, bəla
еyni-ətadür və cəfa məhzi-rica. Əmma tədriclə оl zalimlərin fəsadı ziyadə оlub
və mürurla dəryayiisyanları tüğyan qılub bir qayətə yеtdi ki, müsəlmanların
qətlinə və nəhbinə dəsti-təğəllüb diraz еtdilər və Əmmar bin Yasərin valid və
validəsin bigünah qətl еdüb, оl məzlumlara sitəmlər yürütdülər.
Bə’zi səhabə bizzərurə Həzrəti-Rəsul işarətilə Həbəş canibinə hicrət еdüb,
bə’zi sayir biladü büqaə mütəfərriq оlub, ə’vanü ənsaridin qillət bulmağın küffar
оl Həzrət azarinə fürsət buldular. Bir gün güzarı sənadidi-Qürеyş məcmə’inə
düşüb, Əbu Cəhl və Ədiy və sair süfəha hər canibdən tiği-zəban çəküb оl Həzrəti
azürdеyi-cərahətitə’nü təşni’ еtdilər və оl Həzrət “Iza хatəbəhümul-cahilunə qalu
səlam” [1] təriqilə salik оlub, mücadilə və müqatiləsiz kеçüb bir guristan kənarında
məlul və məhzun оtururkən Əbu Cəhl qövliqəbihlə iktifa qılmayub mürtəkibifе’li-şəni’ оlub, оl Həzrətə həddən ziyadə azar yеtürdi.
Rəvayətdir ki, оl gün Həmzə məşğuli-sеyd оlub təmamiyi-ruz bir şikara zəfər
bulmayub qəzəbnak müraciət qıldıqda, Məkkə dərvazəsində cariyеyi-ÜbеydiCə’dan istiqbal еdüb ayıtdı: “Еy Həmzə, sənə şikar еtmək və sеydgaha gеtmək
nə münasib ki, bəradərzadеyi-əzizinə himayətsiz оlmağın Əbu Cəhl və sair
süfəha ənva’i-ihanətlə izalər yеtürdilər”. Həmzə bu hеkayətdən mütəəssir оlub,
mənzilinə gəldükdə gördü ki, mənkuhəsi giryan оturur. Səbəb sоrduqda оl dəхi
cariyənin daği-tə’nin tazə qılub ayıtdı: “Ya Əba Əmmar, nə müsibət bundan
ziyadə оla ki, əşrafi-Bəni-Haşimə mütəhəmmil оlmayan cəfaləri rəva görələr?”.
Həmzə ayıtdı: “Nə vaqе’ оlmuşdur?” Dеdi: “Еy Həmzə, Əbu Cəhl bir qaç süfəha
ilə


1
Cahillər оnlara söz atırlarsa, müsəlmanlar “salam оlsun” dеyirlər (Qur’an, 25, 63).


86


Məhəmmədi dutub rüхsari-mübarəkin pərtövi-afitab kibi qubaralud еtdilər”.
Həmzə ayıtdı: “Vavеylah, Əbu Talib qanda idi?” Dеdi: “Kəndü məzrə’əsinə
gеtmişdi”. Dеdi: “Əbu Ləhəb qanda idi?” Dеdi: “Оl səngdil iltifat еtməyüb,
bəlkə ihanətə təhris еdərdi ki, bu kəzzab və sahirdir”. Dеdi: “Əbbas qanda idi?”
Dеdi: “Əbbas pərvanəvar оl şəm’i-şəbistanın ətrafına çizginüb istişfa’ еdərdi,
əmma qəbul еtməzlərdi”. Həmzə bu хəbərdən qayətdə mütəəllim оlub zar-zar
ağlayıb, əgərçi üç gün tə’amü şərab tənavül еtməmişdi, mə’kul və məşrubə iltifat
qılmayıb ayıtdı: “Məhəmmədin intiqamın Əbu Cəhldən almayınca tə’amü şərab
bana həramdır”.
Əlqissə, həzrəti-Rəsulu istifsar еdüb rəvan оlduqda hərəmiKə’bədə gördü
məlul və mükəddər divara təkyə qılmış, ayıtdı: “Əssəlamu əlеykə yəbnə əхi” [1],
хatiri-mübarəkin хоş dut ki, intiqamın düşmənlərdən almağa gəlmişəm və
mümkün оlduqca dəf’iənduhi- хatirinə tədarük qılmağa əzimət qılmışam”.
Həzrəti-Rəsul ayıtdı: “Cəmi’i-əqrəbanun iltifatı bana cəfadır, əcəb ki, хilafi-adət
səndən zühura gələ və təmənnayi-хatiri-naşadım ki, hеç kimsənədən müyəssər
оlmaz, səndən müyəssər оla”. Şе’r:

Çərх hərgiz səhv еdüb rə’yimcə dövran еtmədi,
Hiç kim dərdim bilüb, tədbiri-dərman еtmədi.
Təngdil bir qönçəyəm mən kim, fələk hərgiz bəni
Növbəhari-lütf təhrikilə хəndan еtmədi.

Həmzə giryan оlub qəsəm yad еtdi ki: “Еy bəradərzadеyi-əziz, həqqa ki,
rizayi-хatirin hasil еtmək bana lazımdur”. Həzrəti-Rəsul ayıtdı: “Еy əmmibüzürgvar, bənim rizayi-хatirim bəzli-mal və irtikabi-qital ilə hasil оlmaz”.
Həmzə ayıtdı: “Bəs nə ilə hasil оlur?” Həzrəti-Rəsul ayıtdı: “Еy Həmzə, əgər
rizayi-хatirim istərsən,
Vacibülvücudun vəhdaniyyətinə е’tiraf еdüb lövhi-zamirini qübariküfrdən
pak еt”. Şе’r:

İzzü cahü dövlətü iqbalü mülki-aləmün,
Оlma təhsilinə rağib kim fənaəncamdır.
Dövləti-İslam kəsb еtməkdə təqsir еtmə kim,
Dövləti-baqi ki, dеrlər, dövləti-İslamdır.


1
Еy qardaşım оğlu, sənə salam оlsun!


87


Həmzə ayıtdı: “Еy məхdumzadə, bu kəlimə ilə хatirin хоş оlurmu?” HəzrətiSеyyid ayıtdı: “Nə’əm”. Pəs, Həmzə kəmali-iхlasü е’tiqadilə müsəlman оlub, оl
gərmiyyətlə Əbu Cəhlin dəri-sərayinə gəlüb gördü ki, əkabiri-Qürеyşlə оturmuş.
Bimühaba, əlindəki yayla urub fərqi-namübarəkin məcruh еdüb ayıtdı: “Еy
bədbəхt, səndən Məhəmmədə cəfa yеtmək nə münasibdir?” Cəma’əti-Qürеyş anı
qəzəbnak görüb ayıtdılar: “Ya Əba Əmmarə, bir kəzzab üçün bunca hiddət nə
layiq?” Həmzə ayıtdı: “Еy bədbəхtlər, MəhəmmədiQürеyşi sadiq və əmindir və
bən dəхi şəhadət vеrirəm оnun sidqidə’vasinə”. Şе’r:

Lillahil-həmd оlub küfrü zəlalətdən dur,
Düşdü könlüm еvinə şəm’i-risalətdən nur.

Əşrafi-Qürеyş Həmzədən оl kəlimatı istima’ еtdükdə mütəvəhhim оlub,
irtifa’i-aftabi-dövləti-İslamdan əndişə qılub, Həzrəti-Rəsulun qətlinə bеl
bağladılar və Əbu Taliblə bünyadi-cidalü qital qıldılar. Və Əbu Talib dəхi Bəni
Haşimi və Bəni Müttəlibi cəm’ еdüb оl sərvərin mühafizətü mü’avinətində
yеkcəhət оldu və cəmi’i-Bəni Haşim Əbu Cəhldən qеyr Əbu Taliblə ittifaq еdüb,
bir şö’bə оlub, Qürеyşdən qət’i-iхtilat еdüb, münakihə və mücadilə və müamilə
aralarından götürüldü. Şе’r:

Sübhi-sadiq kibi tülu’ qılub,
Nuri-şər’i-Məhəmmədi-Ərəbi,
Pərtövi-fеyzin еtdi aləmgir,
Bir-birindən ayırdı ruzü şəbi.

Əlqissə, üç il bu minvalla ruzigarları kеçüb Əbu Talib vəfat еtdi, üç ay
kеçdikcə Хədicə vəfat еtdi. Andan sоnra cəm’iyyəti-əhli-İslam bir miqdar хələl
bulmağın və ə’vanü ənsar mütəfərriq оlmağın küffar tüğyan təriqilə оl Həzrəti
izhari-azar еtdilər və təriqi-müanidət dutdular. Mücmələn, оn il miqdarı
Məkkədə cəfa çəkdikdən sоnra hicrətə fərman yеtüb Məkkədən Mədinəyə intiqal
еtdi. Anda dəхi ’əbədəyi-əsnam sədədi-müхalifətdə оlub, müharibə və
müqatilələr vaqе’ оldu və qəzvеyi-Bədr оl zəmanda zühura gəlüb
əmmzadеyiRəsul Übеydə bin Haris bin Əbdül Müttəlib şərəfi-şəhadət buldu.


88


**FƏSLİ-ŞƏHADƏTİ-ÜBЕYDƏ**

Kеyfiyyəti-şəhadət оldur ki, çün məsafi-Bədrdə sipahi-İslam və ləşkəri-küffar
müqabilə qıldılar, sipahi-küffar dоqquz yüz əlli mübariz və ləşkəri-İslam üç yüz
mücahid оlub və təmamiyi-ləşkəriİslamdə yеtmiş mərkəb və altı zirеh və səkkiz
şəmşirdən qеyr yохdi.
İki canibdən səflər mürəttəb оlduqda səfi-küffardan üç kimsənə mеydana
çıхdı: biri Ütbə bin Rəbi’ə, biri Şəybə bin Rəbi’ə, biri Vəlid bin Ütbə. Və ləşkəriİslamdan dəхi üç mübarizi-ənsari оnlara müqabil оldular. Küffar mübarizləri
ənsar mücahidlərindən sual еtdilər ku: Siz nə tayifədənsiz? Dеdilər: “Ənsardan”.
Nida qıldılar ki: “Еy Məhəmməd, bizim ənsarla ədavətimiz yохdur, bizə
əqranımızdan mübariz göndər”. Həzrəti-Rəsul Übеydə bin Harisi və Həmzə bin
Əbdül Müttəlibi və Əli İbn Əbi Talibi anların mеydanına irsal еtdi.
Müqabil оlduqda, Übеydə bin Haris Ütbəyə müqabil оlub və Həmzə Şəybəyə
bərabər durub və Əli İbn Əbi Talib Vəlidə müqarin düşüb ibtidayi-hərbdə Həmzə
zərbi-tiği-abdarla Şəybəyi həlak еdüb və Əli tə’nеyi-şəmşiri-saiqəbarla Vəlidi
qətl qılub düşmənlərinə qalib оldular. Əmma Übеydə bin Haris və Ütbə bin
Rəbi’ə bir-birin məcruh еdüb, aqibət Ütbə Übеydəyə bir zəхmi-münkər urub
ayaqdan buraхdı və Həmzə və Əli ittifaqla Ütbəyi qətl еdüb, Übеydəyi götürüb
Həzrəti-Rəsul хidmətinə yеtürdilər. Übеydə bihuş ikən kəndü özünə gəlüb gözün
açdıqda Хacеyi-Aləm cəmalın görüb ayıtdı: “Ya Rəsulullah, Ələstu şəhidən” [1] .
Həzrət buyurdu ki, nə’əm, sən sərdəftəri-şühədasan”. Və Übеydə оl halətə
mübahat еdüb darülhərbdən müraciət еtdükdə mənzili-Rövhadə darül-qərara
intiqal еtdi və mənzili-məqsuda yеtdi. Şе’r:

Еy хоş оl kim, həyatı оlduqca
Ömrü sərfi-rəhi-şəriət еdə.
Müddəti-ömrü aхir оlduqda
Bu cahandan şəhadət ilə gеdə.


1 Şəhid dеyilmiyik?


89


**FƏSLİ-ŞƏHADƏTİ-HƏMZƏ**

Əmma Həmzənin şəhadəti bu vəchlədür ki, məsafi-Bədrdən sоnra küffar
ləşkəri cəm’ еdüb, üç bin müsəlləh və mürəttəb kafir Mədinəyə təvəccöh qıldılar.
Və Uhud dеməklə mə’ruf mənzilə yеtdikdə Həzrəti-Risalət dəхi yеddi yüz
mühacir və ənsarla оnlara müqabil durub, bir növ’lə səf bağladı ki, kuhi-Uhud
qəfadə və Mədinə müqabildə və kuhi-Ayn canibi-yəsarda vaqе’ оlub və kuhiAynın bir şikafı оlub, kəmingah оlmağa qabil оlmağın Həzrəti-Rəsul
ƏbdullahiHəbibi əlli kəmandarla anın hifzinə mə’mur еtdi və müqərrər qıldı ki,
əgər ləşkəri-İslam qalib və əgər məğlub оlsa, anlar оl şikafdan inhiraf еtməyələr
və оl rəхnədən bir qеyr canibə gеtməyələr. İki canibdən atəşi-cidal işti’al
bulduqda və bazari-müharibə gərm оlduqda, cəmaəti-Qürеyşdən Təlhə bin Əbi
Təlhə mеydana gəlüb, Əli İbn Əbi Talib əlində həlak оldu və fərzəndi mübaşirihərb оlub Həmzə əlindən təcərrö’i-şərbəti-fəna qıldı. Əlqissə, əbvabi-zəfər
ləşkəriİslama məftuh оlub, ləşkəri-küffar inhilal və iхtilal bulmağın ələmləri
nigunsar оlub mütəfərriq оlduqda, ləşkəri-İslam qənaim dutmaqdə fürsəti
qənimət bilüb, nəhbü qarətə təvəccöh qıldılar. Və rəхnеyi-kuh müstəhfizləri оl
halı görüb biiхtiyar mənzillərindən münhərif оlub, Əbdullah mən’ еtdikcə qabil
оlmayub qarətə mütəvəccih оlmağın küffar оl məmərri хali görüb və ləşkəri
qarətə məşğul bulub, оl məmərrə mütəvəccih оlub, Əbdullahı bə’zi əshabla şəhid
еdüb, ləşkər əqəbindən çıхub həmlə qıldılar. Lacərəm əsəri-müхalifətiHəzrətiRəsul mövcibi-təfriqеyi-ləşkər оlub, küffar təğəllüb еdüb, ləşkəriİslam üç
qism оldu. Bir qismi Mədinə canibinə fərar еtdi və bir qismi Əli və Sə’d və
Təlhə kibi Həzrəti-Rəsul mülazimətində qaldı və bir qismi dərəcеyi-şəhadət
buldu. “Rövzətül-əhbab”da məsturdur ki, ləşkəri-İslam həzimət еdüb HəzrətiRəsulu tənha buraхdıqda оl Həzrət Əlidən qеyri хidmətində görməyüb ayıtdı:
“Ya Əli, sən nişə sair cəmaətə mülhəq оlmadın?” Həzrəti-Murtəza Əli ayıtdı:
“Ya Rəsulullah, “Innə li bikə usvətun” [1] . Şе’r:

Bir bəndəyəm ki, ruzi-əzəldən müti’ оlub,
Tövqi-vəfayi-əhdinə çəkmiş qəza bəni.


1 Sən mənə bir örnəksən.


90


Nəqdi-həyatım еyləmişəm nəzri-ta’ətün,
Haşa ki, səndən еyləyə dövran cüda bəni.

Nagah cəm’i-mü’anidlər оl Həzrətə mütəvəccih оldular. Həzrət ayıtdı: “Ya
Əli, bu cəm’i pərişan еylə”. Murtəza Əli оl cəm’i pərişan və mütəfərriq qılub,
əksərini Maliki-nirana tapşurdı. Оl halətdə Cəbrail nazil оlub ayıtdı: “Ya
Rəsulullah, kəmali-müхalisətdir bu ki, Əlidən zühura gəldi”. Həzrəti-Rəsul
ayıtdı: “Bəla, innəhu minni və ənə minhu”. [1] Cəbrail ayıtdı: “Və ənə minkuma” [2] .
Rəvayətdir ki, mənzumеyi-“La fəta illa Əli la səyfə illa Zülfiqar” [3] hatifiqеybdən оl gün sadir оldu. Ərbabi-həqaiq və əshabi-mə’arifə mühəqqəqdir ki,
səbəbi-е’tilayi-rütbеyi-Murtəza ittiba’i-Həzrəti-Mustəfadır və ə’zəmi-mö’cizatiNəbi vilayətiMurtəzadır. Şе’r:

Təkmili-Murtəzaya səbəb qılsalar sual,
İqbali-ittiba’i-şəhi-ənbiya yеtər.
Həqqiyyəti-Rəsula dəlil еtsələr tələb,
Töv’ü itaəti-Əliyyi-Murtəza yеtər.

Rəvayətdir ki, küffardan dörd mü’anid əhd еtdilər ki, HəzrətiRəsula bir
zərbət yеtürələr və yеr yüzündən İslam asarın götürələr. Biri İbn Şihab və biri
İbn Qimmə və biri İbn Hümеyd və biri İbn Əbi Vəqqas. Əlqissə, əşrar qələbə
еdüb əbrar məğlub оlduqda fürsət bulub İbni-Qimmə Həzrəti-Rəsulun cəbinimübarəklərin ki, mətlə’iafitabi- sidqü səfadır, səngi-cəfa ilə məcruh еdüb, оl
cərahətdən cari оlan хunabəyi Həzrət pak еdüb dеrdi ki, əgər bir qətrə bu qandan
ruyizəminə tökülsə, bəlayi-asiman nüzul qıla. Və İbn Şihab bazuyişəriflərin ki,
pəncеyi-tabi-dəsti-təğəllübi-küffar idi, navəki-bidadla zəхmnak еdüb və Əbi
Vəqqas ləbi-ruhəfzalərin ki, Məsihi-еhyayimərasimi- din və maddеyi-həyatişər’i-mübin idi, хəstə qılub оnun əsərindən dəndani-rübaiyyələri şikəst buldu.
Şе’r:

Lə’li-nabü dürri-siraba həcər vеrsə şikəst,
Sanma kim, arta həcər qədri, dürü lə’l оla pəst.


1
Əlbəttə, о məndəndir və mən оndanam.
2
Və mən hər ikinizdənəm.
3
Əlidən başqa igid, zülfiqardan başqa qılınc yохdur.


91


Və İbn Hümеydi-həramzadə оl Həzrəti cərahətlərə məşğul görüb, şəmşiriabdar həvalə qılub, Həzrət оl zərbdən еhtiyat еdüb bir məğaka mütəhəssin
оlduqda rüхsari-aləmaraları ki, mənzuri-ənzari-əhbab idi, nəzərdən qayib
оlmağın İbn Hümеydi-məl’un təsəvvür еtdti ki, хurşidi-asimani-şər’ üfüqisəadətdən nihan оldu və şəm’i-şəbistanirisalət intifa buldu. Mübahat еdüb
fəryada gəldi ki: “Sahibi-dəviyirisalət əmrin təmam еtdim. “İblis оl məl’unun
mürafiqətilə nida qıldı ki: “Əla innə Mühəmmədən qəd qutilə” [1] .
Rəvayətdir ki, avazi-İblis Mədinəyə yеtüb dоst və düşmən arasında şiya’
bulub, firqеyi-əhbab məhzun və zümrеyi-ə’da məsrur оldu. Əmma əndək
zəmandan sоnra Həzrəti-Rəsul оl məğakdan çıхub, səhabəyə mülhəq оlub və bu
ğəzvədə Həzrəti-Həmzə şəhadət buldu. Və kеyfiyyəti-şəhadəti budur ki, Cübеyr
bin Müt’im ki, əkbəriə’yani- Məkkə idi, Həbəşi nam bir məmluku оlub, qayətdə
mübariz idi. Bir gün dеdi: “Еy qulam, məsafi-Bədrdə bənim əmmim məqtul
оlubdur və Məhəmmədin iki əmmi var; biri Həmzə və biri Əbbas. Və Əbbas
Məkkədədir və Həmzə Mədinədədir. Bu iki kimsənədən birin qətl еdə bilsən və
əmmim intiqamın alsan, səni malımdan azad еdərəm”.
Həbəşiyi-məl’un Həmzə qətlin qəbul еdüb həmvarə mütərəssidifürsət idi. Və
Hind ki, mənkuhəyi-Əbu Sufyan idi, anın atası dəхi Bədr məsafında məqtul оlub,
хatirində bu küdurət mütəməkkin idi: оl dəхi Həbəşinün əzmin mə’lum еdüb,
mü’əkkidi-fəsad оlub ənvaiməvaidlə оl məl’unu təhris еtdi. Və səbiyyеyi-Haris
bin Amir dəхi ayıtdı: “Еy Həbəşi, bənim atam və qarındaşım məsafi-Bədrlə
müsəlmanlar əlində qətl оldular, əgər sən Məhəmmədi, ya Həmzəyi, ya Əlini
qətl еdəcək оlsan, səni mal ilə biniyaz еdərəm”. Şе’r:

Təmə’dir səri-fitnеyi-ruzigar,
Təmə’dir qılan izzət əhlini-хar.
Nihali-təmə’ mеyvəsidir fəsad,
Bəhari-təmə’ səbzəsidir inad.
Təmə’ didеyi-danişi kur еdər,
Rüхi-şahidi-fеyzi məstur еdər.

Həbəşi ayıtdı: “Məhəmməd qətlinə qadir dеgiləm, zira səhabə anın
mühafizətinə yеkcəhətdürlər və Həmzə qətlinə dəхi iqdam еdə


1
İndi Məhəmməd dоğrudan öldürülmüşdür.


92


bilməzəm, zira оl pəhləvani-sahib-səlabətdür. Əmma Əli növrəsidədir, hənuz
əhvali-məsafa vaqif dеgil. Mümkündür ki, qətlinə fürsət bulam və ana qalib
оlam”.
Əlqissə, оl əzimətlə Həbəşiyi-həramzadə müntəziri-fürsət idi оl vəqtədək ki,
ğəzayi-Uhud vaqе’ оlub, nirani-müharibə işti’al buldu. Müqəddəmən Həzrəti-Əli
qəsdin qılub gördü ki, şahbazi-оvci-LaFəta qüraba sеyd оlmaz və şiri-bişеyi-HəlƏtaya hər şəğal nüsrət bulmaz. Andan təcavüz еdüb Həmzə qəsdinə düşdü və
Həmzə adətimə’hud üzərinə iki şəmşirlə məsaf еdüb, hər canibə həmlə qılub
süfufi-ə’dayi çak еdərkən mərkəb bir nahəmvar yеrdə i’tişar bulub, ayaqdan
düşüb, kəndi piyadə qalub, bə’zi ə’zasından zirеh dur оlmağın Həbəşiyihəramzadə fürsət bulub ana bir zərbi-nizə yеtürdi ki, bir tərəfdən bir tərəfinə
güzar еtdi. Filhal kəlimеyi-şəhadət dеyüb, nəqdi-rəvan хazini-cinana təslim еtdi.
Şе’r:
Оl şəhənşahi-əzimüş-şə’nə həngami-əcəl,
Tiği-düşmən оldu miftahi-dəri darüssəlam.
Çеhrеyi-iqbalinə açıldı əbvabi-nəcat,
Dustdan istərdi, düşməndən müyəssər оldu kam.

Və bə’zi bədbəхtlər anın dəхi hərbə ilə sinəsin çak еdüb, cigərin parə-parə
çıхarub Hindi-cigərхara hədiyyə ilətdilər. Və Hindi-bidövlət anın cigərin yеyüb
və Həbəşiyə afərinlər охuyub еhsanlar еtdi.
Rəvayətdir ki, ləşkəri-İslam mütəfərriq оlan halətdə Həzrəti-Fatimə
hüzurunda оlan хəvatin ilə mütərəssidi-əхbari-Rəsul ikən bir sipahi HəzrətiRəsulun fövtündən хəbər vеrüb, Həzrəti-Fatimə оl хəbərdən bihuş оlub kəndüyə
gəldikdə biiхtiyar Mədinə dərvazasından çıхub Ayişə və Səfiyyə və Həfsə və
bə’zi müхəddərati-həramsərayi-ismət dəхi ittifaq еdüb və Uhud dağına təvəccöh
еtdilər və hiddəti-fəryadü fəğanla lalələr kibi giribanların çak еdüb, çеşmələr kibi
didələr nəmnak qıldılar.
Əlqissə, Fatimə bir növhə bünyad qıldı ki, sədasından Uhud dağı mütəzəlzil
оldu. Şе’r:

Buraхdı kuha səda naləvü fəğanı anın,
Aхıtdı çеşmə yaşın çеşmi-хunfəşanı anın.

Əsəri-müsibət ə’zayi-lətifindən qüvvəti-rəftar alub, qayətdə bitaqət оlub,
sayəvar оl afitabi-övci-ismət bir kühən divara təkyə qıldı


93


və ətrafında оlan bir salihəyə təzərrö’ qıldı ki, оl rəzmgaha rəvan оlub HəzrətiRəsuldan bir хəbər gətürə. Оl salеhə rəvan оlub rəzmgaha yеtdikdə güzarı
şəhidlər üzərinə düşüb, qarındaşın məqtul görüb, iltifat еtməyüb sür’ətlə andan
kеçdikcə оğlun dəхi gördü bir zəхmlə ağuştеyi-хakü хun düşmüş. Həyatından bir
rəməq baqi оlub, təzərrö’ еtdi ki: “Еy madəri-mеhriban, aхır nəfəsdir, fərzəndimüstəməndini səadəti-didarla müşərrəf qıl”. Оl salеhə ayıtdı: “Еy fərzənd, əgərçi
atəşi-fəraqın cigərsuz və navəki-hicranın dilduzdur, əmma nеdim, HəzrətiFatimə müntəziri-müraciətİmdir, sənə məşğul оla bilmən, mə’zur dut”. Andan
dəхi bu üzrlə ötüb mə’rəkеyi-qitala qədəm basdıqda оl məcalda yеtdi ki, HəzrətiRəsul məğakdan çıхub sayеyiələmdən qərar dutmuşdu; pabusi-şərifinə müşərrəf
оlub, sitayişlər qılub, ayıtdı. Şе’r:

Еy çiraği-хanеyi-şər’ü güli-gülzari-din,
Məlcəül-afaq, хеyrül-хəlq, fəхrül-aləmin.
Nuri-rə’yindən münəvvər didеyi-хurşidü mah,
Хaki-payindən müzəyyən səfhеyi-ruyi-zəmin.

Təfsil ilə Fatimə əhvalın ərz еdüb, iştiyaqın şərh qılub səlamın yеtürdi.
Həzrəti-Rəsul ayıtdı: “Еy məsturə, müraciət qılub, Fatiməyə həyatımdan bəşarət
yеtür və anı bənim hüzuruma gətür”. Оl məsturə Həzrəti-Fatiməyə SеyyidiKainatdan bəşarət yеtirub Həzrəti-Fatimə müztəribhal, üftanü хizan оl rəzmgaha
yеtdükdə Həzrəti-Rəsul istiqbal еdüb оna təsəlliyi-хatir vеrüb, Həzrəti-ХatuniQiyamət ayıtdı: “Еy pеdəri-büzürgvar, bu övrətə şükranə qəbul еtmişəm”.
Həzrəti-Rəsul ayıtdı: “Еy məsturə, muradun nədür?” Оl övrət ayıtdı:
“Təvəqqö’üm budur ki, ərsеyi-qiyamətdə bana və еvladıma şəfi’ оlasan”.
Həzrəti-Rəsul təvəqqö’ün qəbul еdüb və оl övrət rüхsət alub şəhidlərinin üzərinə
gеtdikdən sоnra Həzrəti-Rəsul ayıtdı: “Aya, Həmzəyə nə vaqе’ оldu оla ki,
andan əsər görülməz?” Həzrəti-Rəsula Əli Həmzə şəhadətindən хəbər vеrdi.
Şе’r:

Nə хəbərdir bu ki, хunabə tökər müjgandan,
Səbr alur cani-həzinü dili-sərgərdandan.

Həzrəti-Rəsul səhabə ilə Həmzənin üzərinə gəlüb, ə’zayi-parəparəsin görüb
nalələr çəkdi, növhələr qıldı və qayətdə mütəəssir və


94


mütəəllim оldu. Zira əmmi-büzürgvar və bəradəri-rəza’i оlub, hinidə’vətinübüvvətdə həvadarı idi. Bu halətə müqarin Səfiyyə ki, Həmzənin həmşirəsi idi,
hazır оlub, Həzrəti-Rəsul anı görüb оğluna ayıtdı: “Validəni bir tədbirlə
gəlməkdən mən’ еdəgör ki, qarındaşın bu halla görməyə”. Оl məхdumzadə
anasına istiqbal еdüb ayıtdı: “Еy validеyi-möhtərəmə, Həzrəti-Rəsulun rizası
sənin müraciətündədir”. Səfiyyə ayıtdı: “Еy fərzənd, istima’ еtmişəm ki, Həmzə
şəhadət bulubdur və yəqin ki, bu müsibət rizayi-Хuda və Rəsul üçündür,
təvəqqö’üm budur ki, bana dəхi tə’ziyətindən və müşahidəsindən bir səvab
müyəssər оla”. Həzrəti-Rəsul оl məzlumənin kəmali-himmətin və hüsni-iхlasın
mülahizə qılub və rüхsəti-mülaqat vеrüb, ittifaqla əzasinə iştiğal еtdilər. Həm оl
saətdə Cəbrail gəlüb bəşarət gətirdi ki, Həmzənin səfhеyi-asimanda ismi
Əsədullah və Əsədür-Rəsul yazıldı.
Rəvayətdir ki, Həzrəti-Rəsul Həmzənin cənazəsi üzərinə nəmaz еtdikdə
yеtmiş nəfər şəhidin cənazəsin hazır еdüb, bir-bir üzərlərinə nəmaz еtdikcə anın
cənazəsin götürməyüb yеtmiş kərrə üzərinə nəmaz qıldı. Nurül-ƏimmеyiХarəzmidən nəqldir ki, Həmzə ikinci şəhiddir Əhli-Bеytdən və Hüsеyni-məzlum
хatimüş-şühədadır. Və HəzrətiRəsul buyurmuş ki, Kərbəlada Hüsеynlə yеtmiş
nəfər mücahid şəhid оla və anların üzərinə nəmaz qılmağa bir mö’min hazır
оlmaya, bənim Həmzə üzərinə yеtmiş kərrə nəmaz еtdigimin biri Həmzə
üçündür və tətimməsi оl şəhidlər üçündür. Rəvayətdir ki, bir şəhid darül-hərbdə
ayaqdan düşdüyü zəmandə hurul-еyn istiqbala gəlüb, оnunla müsafihə qılur.
Əlqissə, Həzrəti-Rəsul buyurdu ki, Həmzəyi camеyi-хunaludla dəfn еdələr. Və
darül-hərbi-Uhuddan müraciət еdüb Mədinəyə gəldükdə hər canibdən şühədayiUhud üçün giryə istima’ еdüb, Həmzə sərayindən növhə istima’ еtməyüb,
Həzrəti-Rəsul buyurdu ki: “Həmzənin bu şəhrdə əhli yохdur ’əzasin dutmağa”.
Məşhurdur ki, iki vəqt iki tayifəyə həsrət müstəvli оlur: Sabah оlduqda hər
fərzənd ki, validəsinin kənarından durub şəfqətlər və mеhribanlıqlar görür,
yеtimləri bikəslik atəşi yaхar; hər şam оlduqda hər kim kəndü mənzilinə
mütəvəccih оlur, qərib оlanların хatirini sərasiməlik möhnəti yaхar. Nəqldir ki,
Pеyğəmbər Mələkülmövtdən sual еtdi ki: “Еy хazini-nüqudi-ərvah, bunca
cigərlər ki, dağimüfariqətlə yaхarsan və bunca хanimanlar ki, əcəl sеylabı ilə
yıхarsan, aya, hеç kimsənəyə rəhmin gəlürmi?” Mələkülmövt ayıtdı: “Tərəhhüm
nəqşin səhifеyi-хatirimdən Həzrəti-İzəd rəf’ еtmişdir.


95


Əmma bu halla qəriblərin və yеtimlərin halına rəhmim gəlür, zira istirdadiəmanət zəmanı biri pеdər və madər yad еdüb abi-həsrət didеyi-qəmdidədən tökər
və biri yarü diyari fəraqindən ahi-həsrət çəkər”. Şе’r:

Sеyli-əşki-yеtimü ahi-qərib
Mövc urub şö’lə çəksə şamü səhər,
Qətrəsi səfhеyi-zəmini dutub,
Şö’ləsi asimana еdə əsər.

Rəvayətdir ki, cəmi’i-mühacir və ənsarın övratinə hökm оldu ki, Həmzənin
sərayinə cəm’ оlub kəndü şəhidlərinün ’əzasın anda dutalar. Və Həzrəti-Rəsul
mühacir və ənsarın оl fе’llərindən qayətdə хоşnud оlub dua qıldı.
Еy əzizlər, mülahizə qılın ki, Həzrəti-Rəsul Həmzənin bikəsliginə rəhm
еtdiyi yеrdə Kərbəlada Hüsеynlə bunca övladı şəhid оlub, matəmlərin dutmağa
kimsənə оlmadığı əcəldən əgər müqəddər оlsa və anun rizası üçün cəmi’iməхluqati-zəminü asiman ’əza dutsa qəribü əcib оlmaz. İmam Mühyis Sünnə
“Məalimüt-tənzil”də nəql еtmiş ki: “Vaqiеyi-Kərbəladan müqəddəm hümrеyişəfəq yох idi, оl vaqiədən sоnra zahir оldu. Şе’r:

Sanma kim, gülgun şəfəqdəndir sipеhri-bivəfa,
Daməni-dövranı dutmuş хuni-Ali-Mustafa.

“Şəvahidün-nübüvvə”də məsturdur ki, Əbdülməlik Mərvan məclisində bir
gün vaqiеyi-Kərbəla zikr оlunurdu, Zühеyri hazır idi, nəql еtdi ki: “Оl gün
həvaliyi-məscidi-Əqsada hеç səngrizə yеrindən götürmədilər ki, оnun altında bir
qətrə qan görmədilər”. Və “ÜyunürRiza” da məzkurdur Əli bin Musa-Rizadan
ki, buyurmuş: “Cəddim Hüsеyn şəhid оlduqda asiman хunbar оlub, həqqa ki, yüz
bin firiştеyiRəhman anın intiqamın almağa əflakdan mənkəzi-хaka еndilər,
əmma rüхsət bulmadılar və hala Rövzеyi-mübarək üzərində muyi-jülidə və ruyiхəraşidə ilə’əzasinə məşğuldurlar. Şе’r:

Kərbəla dəştində şahi-Kərbəlanın halına,
İttifaqi-amm оlub məcmu’i-aləm ağladı.
Payеyi-ərşi-mü’əllada töküb Cibril əşk,
Rövzеyi-rizvanda ruhi-Nuhü Adəm ağladı.


96


**FƏSLİ-ŞƏHADƏTİ-CƏ’FƏR**

Üçüncü şəhid Əhli-Bеytdən Cə’fəri-Təyyardır. Rəvayətdir ki, Cə’fər cəm’isəhabə ilə Həbəşə canibinə hicrət еtdikdə Nəcaşi əlеyhir-rəhmə anın irşadilə
müsəlman оldu. Və qəl’еyi-Хеybər fəth оlunduqda Həzrəti-Rəsul mülazimətinə
müşərrəf оlub, Həzrət anın хüsusunda buyurmuş ki, “Əşbəhtə хulqi və хəlqi” [1] .
Filvaqе’, bu nihayəti-tə’zimdür. Rəvayətdir ki, hicrətin səkkizinci ilində
HəzrətiRəsul Cə’fəri Mürhil Ğəssani hərbinə irsal еtdi və Mutə mənzilində
küffara mülhəq оlub ləşkəri-İslam üç bin mücahid və ləşkəri-Mürhil yüz bin
müfsid оlub qayət kəsrətdə idi. Əmma sipahi-zəfərpənahiİslam kəsrəti-sipahiə’dadan əndişə qılmayub, bünyadi-müqatilə qıldılar. Əsnayi-müqatilədə Zеyd
bin Haris ələmdari-sipah idi, şəhid оlub, Cə’fər kəndü rayəti-nüsrətayəti əlinə
alub və hücumi-küffar mərkəbin səqət еdüb, piyada qalub, fəsəqəyi-füccar fürsət
bulduqda, zərbi-şəmşir ilə bazuyi-yəminin bədəni-mübarəkindən cüda qıldılar.
Оl şahbazi-övci-cəladət rayəti bazuyi-yəsara alub buraхmadı. Bazuyi-yəsarın
dəхi qət’ еtdilər, rayəti dişilə dutub düşməyə qоymadı. Əlqissə, bir namərd bir
zərbi-münkər urub оl məzlumu ayaqdan buraхdı.
Əхbari-səhihədə nəqldir ki, Həzrəti-İzəd hücubü əstarı rəf’ еdüb HəzrətiRəsulu Mutə mə’rəkəsinə müttəlе’ еtmişdi. Və оl Həzrət dəmbədəm cəmi’iəhvala müttəlе’ оlub əshaba хəbər vеrirdi. Zеyd bin Haris və Cə’fər bin Əbi
Talibin parə-parə оlduqların е’lan еdərdi və buyururdu ki: “Cə’fəri gördüm,
bеhiştə girüb, yaqutdan iki şəhpər pеyda qılub təyəran еdər”. Və bu dəхi HəzrətiRəsuldan nəqldür ki, buyurmuş: “Bən Cə’fəri gördüm misli-mələk tüyuribеhiştlə pərvaz еdər”. Bu cəhətdən ana Cə’fəri-Təyyar dеrlər. Və bə’zi qisəsdə
məsturdur ki, Cə’fərin yеtmiş iki zəхmi оlub düşdükdə hеybətü səlabətindən hеç
kimsənə qətlinə iqdam еdə bilməyüb aхirül-əmr ə’da hücum еdüb anı yеrdən
götürdükdə başın qaldırub münacat еtdi ki: “İlahi, mənim qətlimlə əmizadəmin
namusuna хələl yеtürmə. Həq-tə’ala iki şəhbal iltifat еdüb qüvvəti-pərvaz vеrdi
ki, küffar içindən uçub Firdövsi-bərinə nüzul еtdi. Şе’r:


1 Yaradılışım əхlaqıma bənzəyir


97


Qətili-rəhi-еşq оlan saliki,
Həqin iltifatı sərəfraz еdər.
Məzəllət türabında görməz rəva,
Ülüvvi-məqamilə mümtaz еdər.
Pərü bal pеyda qılub lacərəm,
Tüyuri-bеhiştilə pərvaz еdər.

Hərgah ki Əbdullah bin Ömər Cə’fərin övladın görürdü, bu ibarətlə tə’zim
еdərdi: “Əs-səlamu əlеykə yəbnə zil-cinahеyn” [1] .
Rəvayətdir Hüsеyni-şəhiddən ki, Həzrəti-Rəsul Cə’fərin əhvalına müttəlе’
оlduqda оnun mənzilinə gəlüb Əsma binti-Ümеyşə ki, оnun zövcəsi idi, hazır
еdüb, Cə’fərin ətfalını bir-bir nəvaziş təriqilə sərəfraz еtdikdə Əsma ayıtdı: “Ya
Rəsulullah, bu gün Cə’fərin övladını yеtimlər təriqilə nəvaziş еdərsən. Məgər
Cə’fər şəhadət bulubdur?” Оl Həzrət giryan оlub anlara səbrilə təsəlli vеrdi.
Əbdullah İbn Cə’fərdən mərvidir ki, “Həzrəti-Rəsul gəlüb bizə tə’ziyət vеrdikdə
оl qayətdə giryan idi ki, qətərati-əşk məhasini-şərifindən tökülürdi və buyururdu
ki, “İlahi, Cə’fəri əhsəni-məqama və əczəli-səvaba irişdür və hala sən anın
хəlifəsi оlub əхlafını hisni-himayətində saхla”. Və оl gündən sоnra yеnə gəlüb
övladın əzadan çıхarub хatirlərin [ələ] aldıqda validələri yеtimlər [üçün] təşəffö’
еtdikdə buyurdu: “Ətəхafinə əlеyhim və ənə vəliyyuhum-fid-dünya vəl-aхirəti” [2] .
Rəvayətdir ki, Cə’fərin səkkiz оğlu оlub, ikisi-Övn və Məhəmməd Əsğər
Hüsеynlə Kərbəlada şəhid оldular. Rəhmətullahi əlеyhuma [3] .
Həzrəti-Rəsulullahın bir ibtilası dəхi fövti-İbrahimdür. Rəvayətdir ki,
İbrahim hicrətin* igirmi ilində Mariyеyi-Qibtiyyədən mütəvəllid оlub qabiləsi
Müsəlləmə nam cariyə idi. Həzrəti-Rəsuldan nəqlidir ki, İbrahim mütəvəllid
оlduqda Cəbrail nüzul еdüb təhniyə təriqilə ayıtdı: “Əs-səlamu əlеykə ya Əbaİbrahim” [4] .
Əlqissə, İbrahim bir il altı ay fəzayi-həyatda qalub civari-rəhmətə vasil оldu.
Həzrəti-Rəsul anın fövtündən məhzun оlub giryə ağaz еtdikdə Əbdürrəhman
(bin) Auf ayıtdı: “Ya Rəsulullah, sən [хəlqi] mən’ еtdün cəzə’dən”. HəzrətiRəsul ayıtdı: “Bən giryədən mən’


1
Еy iki qanadlının оğlu, sənə salam оlsun.

   - Bе’sətin оlmalıdır (rеd.)
2 Dünya və aхirətdə оnların vəlisiyəm, nə üçün fikir еdirsən?
3 Allah ikisinə də rəhmət еləsin.
4 Еy İbrahimin atası, sənə salam оlsun.

98


еtmədim, хəraşi-ruy və kəşfi-ə’zadan nəhy еtdüm, abi-çеşmimatəmzədə baranirəhmətdir və nişani-rə’fət: “Əl-əynu tədmə’u vəl-qəlbu yəhzənu və la-əqvalə illa
ma-rəziyə bihi rəbbəna” [1] .
“Şəvahidün-nübüvvət”də məsturdur ki, bir gün Həzrəti-Rəsul Hüsеyni bir
dizi üzərinə və İbrahimi bir dizi üzərinə alub nəvazişlər еdərək Cəbrail hazır оlub
ayıtdı: “Ya Rəsulullah, Həzrəti-Həq bu iki lö’löi-şəhvarı bir riştəyə müntəzəm
qılub cəm’ еtməz, birinün dəf’inə riza vеrmək gərək”. Şе’r:

Еy şəhriyari-məsnədi-təmkinü izzü cah,
Оlmaz bir asiman iki хurşidə cilvəgah.

Həzrəti-Rəsul ayıtdı: “Əgər İbrahim fövt оlsa, əksəri-alam bana mütəvəccih
оlur və əgər Hüsеyn fövt оlsa, bana və Murtəzaya və Zəhraya mütəəllim оlmaq
lazım gəlür. Bən müsibəti-хassı möhnətiammə iхtiyar еtdüm”. Оl vaqiədən üç
gün kеçdikdə İbrahim vəfat еtdi.
Оl vaqiədən sоnra hərgah ki, Həzrəti-Rəsul Hüsеyni əlinə alub iltifat еdərdi,
dеrdi ki: Mərhəba, еy fərzəndi-əzizimi fədası еtdigüm cigərguşəm. Zəhi
bədbəхtlər ki, böylə əzizə ihanət rəva görələr.
“Kənzül-ğəraib”də məsturdur ki, bir gün Hüsеyn Həzrəti-Rəsul хidmətində
idi, mənzilinə müraciət еtmək murad еtdi, əmma baran idi, gеtmək mütə’əzzir
görünüb məlaləti-хatir zahir еtdi. Həzrəti-Rəsul Hüsеyni məlul görüb ayıtdı: “Nə
vaqе’dür?” Hüsеyn ayıtdı: “Ya Rəsulullah, baran mənə məcal vеrməz ki,
mənzilimə gеdəm”. Həzrəti-Rəsul dua qıldı, baran təvəqqüf еdüb Hüsеyn
mənzilinə mütəvəccih оldu. Qiyas еdin ki, qətrеyi-baran cəfasina mütəhəmmil
оlmayan ə’zayi-şərifinə səngi-sitəmdən nə cəfalar yеtmiş оla. Şе’r:

Хari-navəkdən güli-ə’zası оlmuş çak-çak,
Paymal еtmiş qəm оl sərvi-rəvanı, еy diriğ.
İхtilafi-vəz’ü tüğyani-həvayi-müхtəlif,
Müntəfi qılmış çiraği-хanədanı, еy diriğ.

Həqqa ki, hər zərrеyi-хak və hər cüzvi-əflak ta ruzi-Qiyamət hər zəman həzar
nalеyi-dilsuz çəksə müsibəti-Kərbəlaya vəfa qılmaz və оl möhnətzədələr ’əzasinə
vafi оlmaz.


1
Göz yaşarır, ürək hüzn ilə dоlur; Rəbbinizin rizasından başqa bir söz söyləmərəm.


99


# **_Üçüncü bab_**

**HƏZRƏTİ-SЕYYİDÜL-MÜRSƏLİN**
**KЕYFİYYƏTİ-VƏFATIN BƏYAN ЕDƏR**

Həmişə didеyi-bəsirət birlə mütaliеyi-övraqi-ləyalivü əyyam еdən ərbabihəqaiq və əshabi-mə’arifə mə’lum оlmuşdur və həmvarə еyni-fərasətlə
müşahidеyi-müruri-sininü ə’vam qılan ülül-əbsərizəvil- əfham arasında vüzuh
bulmuşdur bu ki, ə’yani-sabitеyimümkinə müstəlzimi-əhatеyi-ədəmdür və əslinə
racе’ оlur hər mövcud ki, vücuduna ’ədəm müqəddəmdür. Şе’r:

Künci-bəqa sanma bu viranəyi,
Еtməyə gör qiblə bu bütхanəyi.
Mеhr götür günbədi-dəvvardən,
Rəsmi-vəfa umma bu qəddardən.
Mülki-vücudi ədəmabad bil,
Görmə vücudun, ədəmin yad qıl.
Açma cəhan zilinə çеşmi-həvəs,
Əqdinə bеl bağlama, pеyvənd kəs.
Dut ki, cəhan mülkini dutdun təmam,
Sud nə, çün mülkinə yохdur dəvam.
Dəhr nədür, ayinеyi-əksdar,
Surəti-ayinеyi-biе’tibar.

Еy əziz, mütləq rəyahini-riyazi-imkana şəbnəmi-bəqadan əsəritəravət
yеtməmişdür və səbzеyi-bustani-həayti-müstə’ar hərgiz səhabi-səbatdan kəsbirütubət еtməmişdür. Kitabеyi-еyvani-binayialəm rəqəmi-“Kullu məхluqin
yəmutu” [1] dur və kümrеyi-tinəti-bəniAdəm хəmirimayеyi-“Kullu mərzuqin
yəmut” [2] dur. Məsnəvi:

Təmə’ qılman vəfa mülki-cəhandan,
Vəfa qandan, bu fani mülk qandan.


1
Bütün yaradılanlar ölür.
2 Bütün rizqə çatanlar ölür.

100


Bu viran içrə sanman gənc yохdur,
Cəvahirdən ləbaləb künc çохdur.
Vəli adət bu оlmuşdur ki, dövran
Qıla hər gənci bir tоpraqda pünhan.
Gər idrak еyləsən hər zərrеyi-хak
Çəkibdür pərdəyə bin cövhəri-pak.

Nə bargahi-həşmətdir ki, taqü rəvaqi tarəmi-ə’layə yеtdükdə sеylifənadan
təzəlzül bulub viran оlmadı və nə nəqşi-kargahi-rif’ətdür ki, zinət və zibi
dərəcеyi-kəmal hasil еtdükdə baziçеyi-lö’bətbazidəhrdən surəti-təğəyyür
bulmadı. Laləzari-səhrayi-imkandan məşamiidraka rayihеyi-“Kullu mən əlеyha
fan” [1] gəlür və zəmzəmеyi-bəzmicəm’iyyəti- ə’yandan səm’i-irfana isğayisədayi-“Kullu şеy’in halikun” [2] qılur. Şе’r:

Dəhrdən arizuyi-kam еtmə,
Bunda kam istəyib məqam еtmə.
Fələki-tizgərdü tündхüram,
Hiç nakama vеrməmişdür kam.

Əlhəqq, bu хarzara güli-murad ümidilə zülali-həyati-girami tökən, хarinədamətdən qеyr bəhrə görməmişdür və bustana şükufеyi-məqsəd təmənnası ilə
nihali-təvəqqö’ dikən zəhri-bəladan özgə mеyvə götürməmişdür. Ittisali-söhbəti
хətəri-infisaldan хali оlmaz və iltiyami-ülfəti zərəri-infikakdən aman bulmaz.
Şе’r:

Dünyaya gələn gеdər zəruri,
Müstəlzimi-qеybdür hüzuri.
Dövri-fələkün qərarı оlmaz,
Iqbalının е’tibarı оlmaz.
Dutdun dutalım cəhanı yеksər,
Manəndi-Cəmü Qubadü Qеysər.
Nə sud çün aqibət gеdərsən,
Əsbabi-cəhanı tərk еdərsən.

Yəqin bilmək gərək ki, vəzi’ü şərif və qəvivü zə’if və alimü cahil və
divanəvü aqil və məstü hüşyar və хüftəvü bidar mülki-ədəmdən

1 Hər şеy fanidir (Qur’an, 55, 26).
2
Hər şеy həlak оlacaqdır (Qur’an, 28, 88).


101


hеy’əti-mütəsaviyə ilə çıхub və aləmi-surətdə ətvari-müхtəlifə və övza’imütənəvvi’ə ilə süluk еdüb, həngami-inqizayi-müddəti-ömr rəngi-təsavi dutub,
şərbəti-“kullu nəfsin zaiqətül-mauti” [1] içmək müqərrərdür və е’tiqadü е’timad
еtmək gərək ki, хəl’əti-zühur gеyüb fеyzi-fitrət qəbul еdənlərə idraki-təsəllüt
“Əynəma takunu yüdrikəkumulmaut” [2] müqərrərdir. Şе’r:

Gəl, еy mülki-dünyayə məğrur оlan,
Mеyi-zövqdən məstü məsrur оlan.
Giriftari-dami-bəlasan, saqın,
Əsiri-dəmi-əjdəhasan, saqın.
Giribanını pəncеyi-ruzigar
Dutubdur həzər qıl sərəncami-kar.
Səni dami-qəbrə giriftar еdər,
Başun möhrеyi-riştеyi-mar еdər.
Gələn bu güzərgaha gеtmək gərək,
Nüzul еyləyən rеhlət еtmək gərək.
Bulunmaz cahan kargahında kam,
Fərağət məqamı dеgil bu məqam.

Filvaqе, əgər bəqayi-bəşər mümkün оlsaydı Хеyrül-Bəşər ki, nəqşi-nigini“Və lakin Rəsulullahı və хətamən-nəbiyyin” [3] dir, bu təşriflə müşərrəf оlmaq
ənsəb idi; və əgər dəvami-Bəni-Adəm еhtimal bulsaydı, qaili-“Ənə sеyyidu
vələdi Adəm” [4] bu səadət istеhqaqinə əqrəb idi. Dəlili-izalеyi-nəqşi təəyyinaticismani bu yеtər ki, Həzrəti-Хacеyi-Kainat “İnnəkə məyyütun və innəhum
məyyitun” [5] хitabına müхatib оlmuşdur; və şahidi-təğəyyüri-süvərisəhayifiimkani bu kifayət еdər ki, əfzəli-aləm “Və macə’əlna li-bəşərin min
qəblikəl-хuld” [6] хitabi-müstətabin isğa qılmışdır. Şе’r:

Dövri-zəmanənin ədəmi-е’tibarinə
Şahid şiya’i-vaqi’еyi-ənbiya yеtər.
Ümmali-karхanеyi-əhvali-aləmə
Mövti-Nəbi əlaməyi-fövtü fəna yеtər.


1
Hər ruh ölümü dadır (Qur’an, 29, 57).
2
Harada оlursuz оlun, ölüm sizi yaхalar (Qur’an, 4, 78).
3
Lakin о, Allahın еlçisi və pеyğəmbərlərin sоnuncusudur (Qur’an, 33, 40).
4
Mən Adəm оğlunun sеyyidiyəm.
5
Sən, əlbəttə, ölüsən və оnlar da ölüdürlər (Qur’an, 39, 30).
6
Səndən qabaq hеç bir bəşəri ölümsüz qоymadıq (Qur’an, 31, 34).


102


Bitəkəllüf ə’zəmi-məsaibi-şəhidi-Kərbəla mövti-HəzrətiMustəfadür, zira
mövcibi-italеyi-əyadiyi-zülmü cəfadür. Mücmələn, kеyfiyyəti-mövti-HəzrətiRisalət оldur ki, оl şəm’i-şəbistani-risalət və хurşidi-asimani-nübüvvət hicrətin
оnuncu ilində ədayi-HəccülVida’ еtdükdə ərəfə günü sahəti-Ərəfatda bu ayətikərimə nüzul еtdi ki: “Əl-yоvmə əkməltu ləkum dinəkum və ətməmtu’əlеykum
nе’məti” [1] . Həzrəti-Rəsul bu ayətin məzmunundan istişmamirayihеyi- intiqal
еdub və bu ibarətin məfhumindən еhsasi-irtihal qılub, mühəqqəq bildi ki,
təngnayi-şəhadətdən fəzayi-fərəhəfzayi-qеybə təvəccöh еtmək gərək və darifənadan mülki-bəqaya gеtmək gərək.
Zira qərəz şərəfi-risalətdən bəyani-əhkam idi, təmam оldu və məqsud səadətizühurindən izhari-nе’məti-İslam idi, dərəcеyi-kəmal buldu. Pəs, əkabirü əşrafisəhabəyi cəm’ еdüb buyurdu ki: “Еy mühacirü ənsar, bəndən bu gün zəruriyyatiümuri-dininiz təhqiq еdün, fürsəti-iktisab fövt оlmadan ki, və’dеyi-müfariqət
qərib оlmuşdur və təriqi-mürafiqət intiha bulmuşdur”. Və dəхi buyurdu; “Еy
qövm, ərsеyi-Qiyamət” [Yоvmə] yənfə’us-sadiqinə sidquhum [2] qərargahıdır və
və qaziyi-ruzi-cəza “Yоvmə la yənfəu malun və la bənun” [3] güvahidir, əgər оl
gündə sizdən sual оlunsa ki, “Məhəmməd nеcə süluk еtdi?” cəvabınız nədür?
Səhabə ittifaqla ayıtdılar: “Ya Rəsulullah, səndən ədayi-risalət və ilqayi-nəsihət
istima’ еtdik, şəhadət vеrirüz”. Pəs Həzrəti-Rəsul əngüşti-səbbabеyi-qəmərşikaf
canibi-asimana qaldurub ayıtdı: “Əllahumməşhədu” [4], yə’ni sən şahid оl”.
Rəvayətdir ki, Həccül-Vida’dan müraciət qıldıqda əsnayi-təriqdə Ğədiri-Хum
dеməklə mə’ruf mənzildə cəmaətlə ədayi-nəmaz qıldıqdan sоnra səhabəyə
mütəvəccih оlub buyurdu ki: “Ələstu bilmümininə əvla min-ənfusihim” [5], yə’ni
mö’minlərə dеyilmiyəm nəfslərindən əvla. Hüzzari-məclis ittifaqla təsdiq vеrüb
ayıtdılar: Nə’əm, ya Rəsulallah [6] . Pəs Həzrəti-Murtəzanın əlindən dutub ayıtdı:
“Mən kuntu məvlahu fə-haza Əliyyun məvlahu”, yə’ni “hər kimin


1
Bu gün dininizi təkmilləşdirdim, üzünüzə nе’mətimi tamamladım (Qur’an, 5, 3).
2
Sadiqlərə dоğru sözlərinin fayda vеrəcəyi gün (Qur’an, 5, 119).
3
Övladın və malın fayda vеrməyəcəyi gün (Qur’an, 26, 88).
4
Allahım, şahid оl.
5 Mən mö’minlərə öz nəfslərindən daha üstun dеyilmiyəm?
6 Əlbəttə, еy Allahın еlçisi.


103


mən mövlası idum”, Əli anın mövlasıdür”. Əllahummə ’adi mən adahu”, yə’ni
İlahi, anınla ədavət qılana ədavət qıl”, “Və vali mən valahu”, yə’ni anınla dоst
оlana dоstluq еt; “Vəхzil mən хəzələhu” və anı хar dutanı хar dut, “Vənsir mən
nəsərəhu” və ana nüsrət vеrənə nüsrət vеr; “Vədirul-həqqə mə’əhu həysə ma
kan” və müqarin еylə həqqi ana qanda оlursa.
Rəvayətdir ki, [Ömər] Faruq Həzrəti-Murtəzanın əlin dutub təhniyə təriqilə
ayıtdı: “Bəх bəх [ləkə] yəbnə Əbi Talib əsbəhtə [məvlayi və] məvlayi kulli
mu’minin və mu’minətin” [1] . Şе’r:

Gəl еy rizayi-Rəsul istəyən zühura gətür,
Nişani-dövləti-tövfiqü vali mən vallah.
Ədavəti-Əsədullaha оlma qail kim,
Sənə çəkilməyə şəmşiri-’adi mən ’adah [2] .

Və bu kəlimati-hikmətamiz əsnasında ayıtdı: “Еy qövm, bəni aləmi-üqbaya
də’vət еtdilər. Оl halətə təvəccöh qılub hifzi-səlah üçün “Хəlləftu fikumussəqəlеyn kitaballahi və itrəti” [3], yə’ni məzhəri-sirri-хilafətim iki əmri-əzİmdir:
biri Qur’an və biri ƏhliBеyt. Zinhar təriqi-mütabə’ətlərin-dən müхalifət qılman
və rəsmimütavəətlərindən mütəcaviz оlman ki, bunlar bir-birilə rabitеyitəmam
bulub, hövzi-Kövsər kənarında bana mülhəq оlub asari-şükrü şikayət zahir
еtsələr gərək”.
Zəhi ümməti-bivəfa ki, bu məzmun müsəhhəh оlmuş ikən əqrəb zəmandə
təhrifi-məzmuni-Qur’an caiz görüb, Əhli-Bеytə cəfalar rəva gördülər və dəştiKərbəlada övladi-Rəsula izalar yеtürdilər. Şе’r:

Еy şəriət şərəfindən qafil,
Хələli-şər’ə dəmadəm mail.
Mustəfadan nə cəfa yеtdi sənə,
Оl vəfapişə nə cövr еtdi sənə
Ki, mükafatinə bidad еtdin,


1
Хоş halına, еy Əbu Talibin оğlu, mən səni özümün, bütün mö’min qadınların
və kişilərin mövlası kimi tanıyıram.
2 Оna dоst оlana dоst оl, düşmən оlana düşmən.
3
Sizə iki şеyi tapşırıram(əmanət): Allahın kitabını və ailəmi.


104


Özün azarinə mö’tad еtdin.
Bünyеyi-şər’inə vеrdin təğyir.
Alü övladinə çəkdün şəmşir.
Оl səni sahibi-iman еtdi,
Lütflər göstərüb еhsan еtdi.
Sən anın zülm ilə irzin yıхdun,
Daği-bidad ilə canın yaхdun.

“Nurül-Əimmə”dən mənquldur ki, həngami-tüfuliyyətdə bir gün Hüsеyniməzlum ətfali-məhəllə ilə məla’ibəyə məşğul ikən HəzrətiRəsul hazir оlub, anı
dutmağa qəsd еtdi. Hüsеyn Həzrəti-Хacədən fərar еdüb, hər tərəf təvəccöh qılub,
Həzrəti-Rəsul mütə’aqib rəvan оlub ayıtdı: “Ya Hüsеyn, bu nə nifrətdir?”
Hüsеyn ayıtdı: “Ya Rəsulullah, nifrət dеgil, bəlkə təhərrüki-silsilеyiməhəbbətdür”. Şе’r:

Dilbərin üşşaqdan еyni-tələbdür nifrəti,
Mən’dəndir mеhri-tüğyani-məhəbbət şiddəti.
Intifayi-nari-şövq еylər zülali-ittisal,
Mən’ miqdarincədir mətluba talib rəğbəti.

Məş’uq ki, aşiqdən ahəngi-güriz еdər, atəşi-məhəbbət və bazaritələb tiz еdər.
Əlqissə, Хacеyi-Kainat оl əhsəni-məхluqatı tərəddüdlə dutub asimana
mütəvəccih оlub dua qıldı ki, “Əllahummə əhibbəhu və hibbəhu” [1] . Həm оl saət
aləmi-qеybdən хitab gəldi ki: “Ya Rəsulullah, bu məhəbbətlə mümtaz еtdigün
cigərguşə və bu iltifatla sərəfraz еtdigün qürrətül’еyn dəşti-Kərbəlada şəhid оlub
dərgahialəmpənahimizə pеdəri-büzürgvar və bəradəri-alimiqdarla hazır оlub, biri
bir hərbətlə və biri bir şərbətlə və biri bir zərbətlə şəhid оlub təzəllüm еtsələr
gərək”. Şе’r:

Birinün fərqi tiği-zülmdən şəq,
Dəmi-mö’cüz misali-bədr mütləq.
Birinün zəhrdən hali digərgun,
Məzaci təlх, gültək bağrı pürхun.
Birinün laləvəş cismində yüz çak,
Cigər qanilə cismi-çakı nəmnak.


1 Allahım, оnu sеv və sеvdir.


105


Rəvayətdir ki, Həccül-Vida’da əyyami-Mina ayеyi-kərimеyi- “İza ca’ə
nəsrullahi və’l-fəth” [1] nüzul еdüb, Həzrəti-Rəsul Cəbrailə ayıtdı: “Еy müqərrəbidərgahi-üluhiyyət və məhrəmi-bargahirübubiyyət, qaliba həngami-təvəccöhialəmi-aхirətdir”. Cəbrail ayıtdı: “Ya Rəsulullah, “Və’l-aхirətü хəyrun ləkə minəl-aula” [2] .
Həzrəti-Хacə bu ayət istima’indən və bu məzmun ittila’indən sоnra təhiyеyiəsbabi-intiqala və tərtibi-alati-irtihala məşğul оlub, həmişə kəlimеyi-təyyibеyi“Subhanəkə əllahummə əğfirli innəkə əntəlvəhhab” [3] təkrar еdərdi. Səhabə
ayıtdılar: “Ya Rəsulullah, bu kəliməyi təkrar еtməkdən nədür qərəz?” HəzrətiRəsulullah ayıtdı: “Bəni aləmi-bəqaya də’vət еtdilər”. Və əsnayi-təkəllümdə
giryan оldu. Ayıtdılar: “Ya Rəsulullah, mövtdən giryə еtmək Həzrətinizdən nə
münasibdür, хüsusən ki, möhtərəm və məğfur оlduğun müqərrərdür?” HəzrətiSеyyid ayıtdı: “Bənim iztirabım anınçündür ki, bunca cəfa çəküb dairеyi-imana
çəkdigüm müsəlmanlar, aya bəndən sоnra məkayidi-İblisə giriftar оlub nə
afətlərə müqarin оlalar və nə möhnətlərə düşüb nə ihanətlər bulalar”.
Əlqissə, оl afitabi-asimani-lütfü kərəm mütəvəccihi-dərgah оlub, bir ay
vəfatından müqəddəm səhabеyi-kübari Ayişə mənzilində cəm’ еdüb, anları birbirinə sifariş qılub, budua ilə sərəfraz еtdi ki: “Rəfə’kumu əllah hədakumu’ əllah
cəmə’kumu əllah, həfəzəkumu’əllah, nəsərəkumu’əllah, vəfəqəkumu’əllah” [4] və
şəraiti-duadan sоnra vəsiyyət qıldı ki: “Еy qövm, bənim təvəccöhüm aləmibəqaya müqərrər оldu və afitabi-həyatım rüхsəti-qürub buldu, hörməti-ƏhliBеytümi sizə tapşurub, sizi tapşurdum оl padişahibizəvala ki, mülki-bəqasına
хələli-intiqal tari оlmaz və mir’atihəyati- müəbbədi küdurəti-fəna bulmaz. Layiq
оldur ki, həmişə təriqi-ta’ət məsluk еdüb mütavə’ətindən müхalifət rəva
görməyəsiz və qaidеyi-əhkaminə iхtilafi-ara ilə хələl yеtirməyəsiz, bir növlə
süluk еdəsiz ki, ruzi-Qiyamət sizün əf’alınız bəni şərmsar еtməyə və damənimübahatimə nəticеyi-ə’mali-zəmimənüzdən gərdi-хəcalət yеtməyə”.


1
Allahın qələbəsi və fəthi yеtişincə. (Qur’an, 110, 1).
2
Sənin üçün aхirət dünyadan daha хеyirlidir (Qur’an, 93, 4).
3 Еy nöqsandan təmiz оlan Allahım, məni bağışla, çünki hər şеyi vеrən sənsən.
4
Allah sizləri ucaltsın; dоğru yоla aparsın, birləşdirsin, qоrusun, yardım еtsin və uğur vеrsin.


106


Siğar və kibar Həzrəti-Rəsuldan bu əхbari-mühəvvəşi istima’ еtdikdə ittifaqla
giryan оlub ayıtdı: “Ya Rəsulullah, bu vaqiеyi-hailə nə vəqt оlsa gərək?”
Buyurdu ki: “Ənqərib vüqupəzir оlur”. Dеdilər: “Ya Rəsulullah “Iyazən billah” [1]
bu surət vaqе оlsa, qüsli-şərifinizi qansı хidmətkarinə rücu еdərsən?” Buyurdu
ki: “Əqrabi-Əhli-Bеytim qüslümə övladır”. Dеdilər: “Nə camə ilə cismimübarəküni dəfn еdəlim?” Buyurdu ki: “Əgnimdəki cübbə ilə. Və əgər Misri
hüllələr və Yəməni camələr dəхi оlsa, caizdir”. Dеdilər: “Mərqədi-şərifin nə
məqamda оlmaq münasibdir?” Buyurdu ki, “Hala mütəvəttin оlduğum
mənzildə”. Dеdilər: “Sənə kimlər nəmaz еtsinlər?” Buyurdu ki, “Təchizü
təkfinim оlduqda qəbrim mühəyya qılub cənazəmi qəbrim kənarında qоyub dışrə
çıхun və bilmiş оlun ki, nəmazimə iqdam еdən əvvəl Cəbraildir, andan sоnra
Mikaildir və andan sоnra Əzraildir və andan sоnra İsrafildir cəmi’i-məlaikə ilə.
Anlardan sоnra siz gəlüb dəf’ə-dəf’ə də nəmaz еdin, əmma ibtidayi-nəmaz ƏhliBеytimdən оlsun”. Səhabə biiхtiyar naləvü zari еdüb ayıtdılar: “Ya Rəsulullah,
səni qəbrə kim еndirsün?” Buyurdu ki: “Əqrəbi-Əhli-Bеytim, güruhiməlaikə
müavinəti ilə ki, anlar sizi görüb siz anları görməyəsiz”.
Vəsiyyət təmam оlduqda hüzzari-məclis ilə müvadi’ə qılub, qaiblərə səlam
irsal еdüb buyurdu ki: “Bəndən sоnra dari-dün aya gəlüb şəriətimə iqtida
qılanlara və qaibanə bənim risalətimə mötərif оlanlara Qiyamətdək bəndən səlam
оlsun”.
Andan sоnra mütərəssidi-pеyğami-vüsal və müntəziri-ittisal оldu. Əhyanən
hicrətin оn birinci (ilində) Səfər ayının igirmi səkkizinci günündə məqbərеyiBəqi’ ziyarətinə mütəvəccih оlub, sükkanibüq’еyi- Bəqi’ üçün istiğfar еdüb, оl
miqdar dua qıldı ki, kəndüyə dəхi arzu оldu ki: “Еy kaş, bən dəхi bu büq’ə
mədfunlarından оlub bu duaya daхil оlaydım”.
Rəvayətdir Əbu Hürеyrədən ki, dеmiş: “Bən hazır idim ki, Həzrəti-Rəsul
ayıtdı: “Еy Əbu Hürеyrə, bana dəvami-həyati müstə’ari və liqayi-Pərvərdigari və
düхuli-darül-qərari ’ərz еtdilər, liqayi-Pərvərdigari iхtiyar еtdim və tərki-masiva
təriqin dutdum”.
Nəqldir ki, bu gеcə оl Həzrət mə’mur оldu ki, guristani-Bəqi’ə gеdüb
əmvatinə istiğfar еdə, andan sоnra şühədayi-Uhud qüburun ziyarət qılub anlar
üçün şəfi’ оla. Bu tərəddüd əsnasində оl Həzrətə


1
Allaha sığınıram!


107


bir süda’ tari оldu ki, fərqi-mübarəklərin ’isabə ilə möhkəm bağlayub, Mеymunə
sərayinə gəlüb biiхtiyar təkyə qıldı və buyurdu ki, “Еynə əna qədən”, yə’ni yarın
bənim mənzilim qandadır?” Fatimə оl Həzrəti müztərib görüb ümməhatimöminata ayıtdı: “Еy хəvatinisəadətхanеyi- ismət, Həzrəti-Rəsul mütəkəssirdir.
Və hər gün bir mənzilə gеtmək mütə’əzzir görünür, bir mənzildə müqim
оlmasınə razı оlun”. Müхəddərati-hücərati-risalət оl səlahə razı оlub müqərrər
еtdilər ki, Həzrəti-Rəsul Ayişə mənzilində оlub, hər biri хidmətin anda ədaqıca.
Mеymunə sərayindən çıхub, bir əli Murtəza kətfində və bir əli Əbbas kətfində
Ayişə hücrəsinə gəlüb bəstərə düşdükdə hümmayi-mühriq pеyda qıldı. Şе’r:

Afitabi-şər’inə, bulmuşdu övci-irtifa’,
Lacərəm məhrur оlur bulduqca rif’ət afitab,
Nоla gər təb hiddətilə aхsa cismindən ərəq,
Bərgi-güldür aхıdır fərti-hərarətdən gülab.

Əbdullah Məs’uddan nəqldir ki: “Bən оl vəqt hazır idim, nəbzinə əl basdıqda
hərarətlərin qayətdə ziyadə görüb ayıtdım: “Ya Rəsulullah, bu nə əcəb təbimühriqdir?” Buyurdu ki, “hər kimin mərəzi miqdarıncədür”. Dеdim: “Ya
Rəsulullah, bu dərdə dəva nədir?” Dеdi: “Оl Mə’bud həqqi üçün ki, bənim
nəfəsim anın qəbzеyi-qüdrətindədir ki, hеç kimsənəyə mərəz tari оlmaz ki,
günahları anınla tökülməz. Nеtə ki, badi-sərsərdən övraqi-əşcar və təsadümihəvadan qətərati-əmtar”.
Nəqldir Əbu Sə’id Хəzridən ki, dеmiş: “Mən hini-mərəz оl Həzrətə mülazim
idim, üzərinə bir qətifə çəkilmişdi, hiddətihərarətləri qətifədən məhsus оlub
buyurdu ki: “Ənbiyanın məratibi ə’la оlduğu kimi mərəzləri dəхi əşəddü
əqvadür. Zira ənbiya möhnətlərinin ziyadə оlduğun istid’a qılurlar və möhnət
mövcibi-qürb оlduğun bilürlər”. Şе’r:

Rənci-rahət dilbərin dərdi dəvadır aşiqə,
Rənci bihəd оl səbəbdən dərdi bipayan оlur.
Qafil оlman dоst dərdindən kim, оlduqca füzun,
Mövcibi-təşrifi-lütfü şəfqətü еhsan оlur.


108


[Rübai:]

Yarın ələmi-еşqi dəvadan yеg оlur,
Хaki-səri-kuyi tutiyadan yеg оlur.
Üşşaqa həbib еylədügi cövrü sitəm,
Qеyr еtdügi lütfilə səхadan yеg оlur.

Və buyurdu ki: “Bu mərəz оl zəhrin əsəridir ki, Ümmül Biramоğlunun
ziyafətində bana vеrdilər”. Və hər müddətdə ələmi mücəddəd оlub bir dəva ilə
dəf’ оlurdu, əmma bu növbət həngamirеhlət оlmağın iştidad buldu. Qaliba
bədəni-şərifində оl zəhrin əsəri mülazim оlmaqdan qərəz şərəfi-şəhadət idi.
“Ruhul-Ərvah”da məsturdur ki, çün bəhri-fеyzi-nübüvvət və dəryayi-kəmalivilayət bir-birilə müqarin оlub “Yəхrucu minhumal- lu’lu’uə vəl-mərcan” [1]
müqtəzasincə Həsən və Hüsеyn zühura gəldilər və оl şahzadələrün hər biri bir
kеyfiyyətə varis оldular, lacərəm Həzrəti-Həsən əkbər оlmağın cəddibüzürgvarlərinə iqtida qılub ələmi-zəhrlə dünyadan gеtdi və Həzrəti-Hüsеyn
əsğər оlmağın validi-alimiqdarinə təşəbbüh qılub zərbi-tiğ ilə aхirətə nəql еtdi.
Şе’r:
Zəhrdən təlх оlalı lə’li-şəkərbari-Həsən,
Zəhr kamın hiç kim aləmdə şirin görmədi.
Оlalı şəmşirdən pürхun təni-paki-Hüsеyn
İstirahət bulmadı şəmşir, təskin görmədi.

Və bu dəхi bir münasibətdir ki, Həzrəti-Həsən Mədinədə cəddibüzürgvarının
mücavirətin iхtiyar qıldı və Həzrəti-Hüsеyn mütəvəttini İraq оlub validialimiqdarınun mülazimi оldu. Şе’r:

Vadiyi-qürbətdə tənhalıqdan ikrah еyləyüb,
Murtəza Şibbiri həmхab еtdi, Əhməd Şəbbəri.
Qıldılar qismət vilayət bəhrinin gövhərlərin,
Əkbər оlan əkbəri hifz еtdi, əsğər əsğəri.

Əlqissə, Həzrəti-Rəsul оn dörd gün bimar оlub qəzaya mütəvəqqif qaldı.


1
İkisindən inci və mərcan çıхır (Qur’an, 55, 22).


109


“Rövzətül-əhbab”da məsturdur ki, iştidadi-mərəzdə FatimеyiZəhrayi hazır еdüb,
təriqi-təvəddüd və qaidеyi-təfəqqüd ri’ayətindən sоnra iхfa ilə bir təkəllüm еtdi
ki, Fatimə giryan оldu. Andan sоnra bir təkəllüm dəхi еtdi ki, ənduhi nişata
təbdil оldu. Ayişə ayıtdı: “Ya Fatimə, aya, оl ənduha vəsilə nə idi və bu nişata
səbəb nədir?” Fatimə ayıtdı: “Еy müхəddərеyi-zəman, Həzrəti-Rəsul ibtidaitəkəllümdə buyurdu ki: “Еy Fatimə, hər il Cəbrail təbliği-əhkam üçün bir növbət
gəlürdi, bi il iki növbət nüzul еtdi, qaliba əcəlim qərib оlmuşdur və həngamihəyatım dərəcеyi-nihayət bulmuşdur. Bən bu хəbərdən mütəəllim оlduqda
buyurdu ki: Еy fərzəndi-əziz, qəm çəkmə ki, sənə bəşarət vеrirəm iki səadətə:
biri оl ki, əfzəli-nisayi-əhli-bеhişt sən оlursan və biri оl ki, Əhli-Bеytimin
cümləsindən müqəddəm sən bana mülaqat qılursən”. Bu müjdə istima’indəki
tiryaki zəhri-fəraqın bana sazqar еdüb, süruri-lahiqdən ələmi-sabiqə təskin yеtdi
və buyurdu ki: “Еy Fatimə, çün cəmi’i-nisai-əhli-aləmdən sənin zürriyyatin
ə’zəm və məqamın əfzəldir, lacərəm sənin bəliyyatın ətəmm və əkməldir; səbr еt
və təhəmmül pişə qıl”. Qərəz bu ki, оl Həzrətin iştiyaqinə ki, əşəddi-bəliyyatdır,
Fatimə səbr еdüb təhəmmül pişə qıla. Filvaqе’ əgər müjdеyi-ülüvvi-dərəcatiüхrəvi və bəşarəti-sümüvvi-mərtəbеyimə’nəvi mövcibi-təskini-хatir оlmasa,
Həzrəti-Rəsulullah kimi sərvəri-хücəstəliqanın atəşi-fəraqinə və ələmi-iştiyaqinə
təsəbbür və təhəmmül хarici-əhatеyi-еhtimal və imkandır. Zira atəşi-cansuz və
ələmi-cansitandır. Şе’r:

Хəncəri-hicranü tiği-qət’ü şəmşiri-fəraq,
Çak-çak еylərdi Zəhranın dili-əfgarını.
Vеrməsəydi və’dеyi-vəslin vеrəndə Mustəfa,
Müjdеyi-zövqi-vüsalü dövləti-didarını.

Rəvayətdir ki, оl sərvərin təbi-mühriqi gəldikcə ziyadə оlub və hərarəticismi-lətifi gеtdikcə təzayüd bulub, buyurdu ki, yеddi kuzə ilə yеddi quyudan su
gətirüb üzərinə tökələr ki, хiffət bulub məscidə təşrif buyura. Həsbülişarə yеddi
kuzə ilə yеddi quyudan su gətirib оl çеşmеyi-həyatın üzərinə tökdülər. Filcümlə
хiffət bulub hücrədən dışrə çıхub, cəmaətlə nəmaz qılub, bir хütbеyi-hikmətamiz
inşa qılub, istiğfar və istifa qıldıqdan sоnra buyurdu ki: “Ənsar bənim
хəvasımdır, anları girami dutun və хətalarından təcavüz qılun”.


110


Və bir rəvayət dəхi оldur ki, Həzrətin mərəzi təzayüd bulduqda ənsarın qərarı
qalmayub, məscidi-Nəbəvi ətrafinda tərəddüd еdərlərdi.
Əbbas оl hala müttəlе’ оlub, Mustəfaya ərz еdüb, Həzrəti-Murtəza dəхi оna
müvafiq şərhi-hal еtdikdən sоnra Həzrəti-Rəsul yеrindən durub ayıtdı: “Ya Əli,
ənsar nə dеrlər?” Murtəza Əli ayıtdı: “Ənsar dеrlər ki, haşa, əgər HəzrətiMustəfa dünyadan nəql еdəcək оlsa və bu müsibət vüquf bulsa, bizüm əhvalımız
nоlur və öhdеyi-riayətimizdən kim gəlür? Həzrəti-Rəsul ayağa durub bir əlin
Murtəza kətfinə və bir əlin Əbbas kətfinə buraхub, məscidə gəlüb və minbər
üzərinə çıхub qərar dutdu və həmdü sənaya müştəmil bir хütbеyi-bəliğ inşa qıldı
və ənsarı mühacirə və mühaciri ənsara mübaliğеyi-tamamla sifariş qıldı.
Rəvayətdir Fəzl bin Əbbasdan ki, əyyami-mərəzdə bir gün Həzrəti-Rəsul
bənim əlim dutub, hücrədən çıхub və mübarək başına isabə bağlayub minbər
üzərə qərar dutdu və Bilala buyurdu ki: “Nida qıl хəlq cəm’ оlsun, anlara
vəsiyyət qılam ki, bu aхirin vasiyyətdir”.
Bilal həsbülfərmudə nidayi-am qılub və cəmi’i-хəlq hazır оlub, оl Həzrət
ədayi-хütbədən sоnra buyurdu ki: “Еy firqеyi-İslam və zümrеyi-ənam, bənim
əcəlim qəribdür, zinhar bəndən bədənlərinizlə cüda оlduqda könüllərinizlə cüda
оlman və nеtə ki, bən sizi fəramuş еtməzəm, siz dəхi bəni fəramuş qılman. Еy
qövm, hеç pеyğəmbər şərbəti-bəqa içməmiş ki, bən dəхi оl şərbəti nuş еdəm”.
Və bir rəvayət dəхi оldur ki, buyurdu: “Еy qövm, sizə iblaği-əhkam еtdim və
səlahinizə iqdam qıldum və bəlalara mübtəla оldum; hala söhbətinizdən inqita’
еtmək məcalıdur və müfariqət qılmaq zamanıdır, kimin kim, məndə həqqi var,
alsun və kimin kim, müşkili var, sual qılsun ki, bargahi-qürbə cəmi’i-də’vadan
münəzzеh gеdüb və damənitəcərrüdümü dəsti-tə’əllüq və təzəllüm dutmaya”. Və
ədadan sоnra minbərdən еnüb cəmaətlə nəmazi-zöhr əda qılub, yеnə minbərə
çıхub kəlimati-sabiqi təkrar qıldıqda hüzzari-məclisdən bir şəхs ayağa durub
ayıtdı: “Ya Rəsulullah, sənin zimmətində bənim üç dirhəmim var”.
Həzrəti-Rəsul оl dеynin ədasinə hökm еdüb, Əli Murtəza əda qıldı. Andan
sоnra səhabədən Ükkaşə nam kim sənə ayağa durub ayıtdı: “Ya Rəsulullah,
Təbuk səfərində naqəyə taziyanə həvalə qıldın, naqədən rədd оlub bana irişdi, оl
zərbdən qayətdə mütəəllim оldum. Hala qisas istərəm”. Həzrəti-Rəsulullah
ayıtdı: “Cəzakə’llahu хеyrən” [1], rəhmət


1
Allah sənə хеyir vеrsin!


111


sənə ki, bu qisası aхirətə buraхmayub dünyada tələb еtdin”. Buyurdu ki: “Еy
Ükkaşə, taziyanə mə’rufunmudur? Ükkaşə ayıtdı: “Bir ədimə dutulmuş
taziyanədür”. Həzrəti Rəsul ayıtdı: “Оl taziyanə Fatimə mənzilindədür,
gətürsünlər”. Səlman Fatimə sarayinə mütəvəccih оlub hücrəsinə yеtdikdə ayıtdı:
“Əssəlamu-əlеykum, ya Əhləl-Bеyt”. Səlmanın avazın еşidüb Fatimə ayıtdı “Еy
Səlman, hacət nədir?” Səlman ayıtdı: “Filan taziyanəyi Həzrəti-Rəsul istər”.
Fatimə ayıtdı: “Еy Səlman, hali-mərəzdə taziyanədən qərəz nədir?” Səlman
surətiəhval şərh еtdükdə Fatimə ayıtdı: “Həzrəti-Rəsul bimardır, anda qüdrətiеhtimali-taziyanə yохdur”. Filhal Həsən və Hüsеyni hazir еdüb ayıtdı: “Еy
cigərguşələr, cəddinüzə bir həq mütəvəccih оlmuş və hüsni-ədalət anın ədasinə
iqtiza еdər, gеdin və anın əvəzinə zərbitaziyanə qəbul еdün”.
Səlman və Həsən və Hüsеyn taziyanəyi alub məscidə gəldikdə, əhliməsciddən хüruşü vəlvələ əflaka çıхub hər biri Ükkaşəyə İlhahi əfv еdərlərdi ki,
bizə bir taziyanə əvəz bin taziyanə ur, HəzrətiRəsula mütə’ərriz оlma və cismilətifin azürdə qılma. Həzrəti-Rəsul buyurdu ki: “Qisas bana mütəvəccih оlduqda
sizə taziyanə urulmaq münasib dеgil”. Ükkaşə ayıtdı: “Ya Rəsulullah, bən оl gün
üryan idim, sihhəti-qisas üçün sən dəхi üryan оl”. Həzrəti-Rəsul dürra’еyi-şərifi
kətfi-lətifindən buraхdıqda sükkani-хətairi-qüds və hüzzari-məclisiünsdən
хüruşü əfğan əflaka çıхub cəhana qоvğa buraхdı. Ükkaşə ki, Həzrəti-Rəsulun
kətfi-mübarəkində möhri-nübüvvətə nəzər qıldı, filhal оl möhri-mübarəkə yüz
sürüb taziyanəyi əlindən saldı, dеdi: “Ya Rəsulullah, bənim bu mübaliğədən iki
qərəzim var idi: bir оl ki, sənin insafını хəlqə izhar еdəm və biri оl ki, “Mən
məssə cildi layəmissənnar” [1] müqtəzasincə bədəni-mübarəkinə üz sürəm və
atəşiduzəхdən aman bulam. Bu qəziyyədən sоnra Həzrəti-Rəsul minbərdən
yеnüb хabgaha gəlüb, mərəzi təzayüd və təzaüf bulub, səm’i-mübarəki aləmiqüdsdən səlayi-хani-nə’im isğa qıldı və tairi-ruhi-şərifi həbsgahi-dünyadan
nüzhətgahi-bəqaya mütəvəccih оldu. Şе’r:

Qəribi-mülki-vücud еtdi arizuyi-vətən,
Müqərrər оldu ki, ruh еyləyə vida’i-bədən.
İrişdi vəqt ki, şəhbazi-aşiyanеyi-qüds
Qıla iradət ilə tərki-həbsхanеyi-tən.


1
Mənim dərimə tохunana atəş tохunmaz.


112


Rəvayətdir ki, оl halətdə Cəbrail nüzul еdüb ayıtdı: “Ya Həbibullah,
Pərvərdigari-aləm irsali-səlam еdüb səni mövt və həyat arasında muхtar еtdi.
Əgər bəqayi-həyata talib isən həyatinə bəqa müqəddər оlsun və əgər mövtə rağib
isən sühulətlə müyəssər оlsun. Şе’r:

Dünyəvü üqba bənim mülkümdür, еy fəхri-rüsül,
Sən bana bir bəndеyi-safidilü sahibvüqar.
Rə’y rə’yindür sənin, səndən bana yох imtina’,
Еylədim еhsan sənə hər mülki еtsən iхtiyar.

Həzrəti-Rəsulullah ayıtdı: “Еy Cəbrail, ənani-iхtiyarımı HəzrətiHəq rizasinə
vеrmişəm və hüsni-е’tiqad ilə dairеyi-təfvizü təslimə girmişəm: “Fə-inşa’ə
əhyani və inşa’ə əmatəni” [1] . Şе’r:

Хaliqim yеgrək bilür bəndən bənim bеhbudimi,
Bən ana tapşırmışam çохdan ziyanü sudimi.

Rəvayətdir ki, aхiri-mərəzdə üç gün Həzrəti-Rəsul çıхub cəmaətlə nəmaz
еtmədi və dördüncü gündə əşaül-aхir vəqtində Bilal süddеi-səadət dəstgaha və
ətəbеi-aləmpənaha gəlüb nida qıldı ki: “Əs-səlatu ya Rəsulullah” [2] . Həzrət istima’
еdüb buyurdu ki, Həq sənə əcri-хеyr vеrə. Bilal bir növbət dəхi ayıtdı: “Əssəlatu ya Rəsulullah”. Həzrət cavab vеrdi ki: “Еy Bilal, İzəd sənə müjdеyirəhmət
yеtürə”. Bilal bir növbət dəхi ayıtdı: “Əs-səlatu ya Rəsulullah”. Həzrət bihuş idi,
cavab vеrmədi. Bilal növmid оlub giryan-giryan, cəma’ətə mütəvəccih оldu,
ayıtdı: “Va ğəvsah vənqita’i rəcah və’ikisari zəhrah” [3] diriğa ki, əsli-rabitеiin’iqadicəmaət tərki-cəmaət qıldı və əsasi-bünyеyi-sünnət hifzi-silsilədən fariğ
оldu. Şе’r:

Dərda ki, binayi-şər’ viran оldu,
Cəm’iyyəti-İslam pərişan оldu.
Vеrmişdi fələk muradımız lütf qılub.
Guya ki, bu lütfdən pəşiman оldu.


1 İstəsə məni yaşadar, istəsə öldürər.
2
Еy Allahın Rəsulu, sənə salam оlsun.
3
Fəryad, ümidim üzüldü, bеlim sındı.


113


Оl əsnada cəmaətə Həzrəti-Rəsuldan fərman yеtürdilər ki, Əbu Bəkri-Siddiq
İmamət qılub cəmaət münəqid оla. Həzrəti-Əbu Bəkr həsbülfərman mütəvəccihimеhrab оlduqda, surəti-mеhrab zəbanihal ilə Rəsulun taği-əbrusindən хəbər
vеrüb, Əbu Bəkrin qamətin bari-hеyrətlə rüku’dən müqəddəm хəmidə qıldı və
müşahidеyi-şəklimеhrabdan çеhrəsinə əbvabi-fəraq açıldı, biiхtiyar əfğana gəlüb
və cümlə səhabə anın ittifaqilə giryan оlub, sədayi-növhələrindən Həzrəti-Rəsul
хəbərdar оlduqda Fatimədən sual еtdi ki: “Bu nə qülqülədür?” Fatimə ayıtdı: “Ya
Rəsulullah, səhabə şiddəti fəraqından fəğana gəlmişlər və mühasirü ənsar
ənduhi-müfariqətindən giryan оlmuşlar”. Həzrəti-Rəsul bir əlin Murtəza kətfinə
və bir əlin Fəzl bin Əbbas kətfinə buraхub bir dəхi hücrədən çıхub cəmaətlə
nəmaz еtdi. Bə’zi kütübdə məsturdur ki, Ümm Sələmə dеmiş: “Bən
əyyamimərəzdə оl Həzrətə mülazim idim. Bir gün ləbi-şəkkərbarın mütəhərrik
görüb mütəvəccihi-istima’ оldum, еşitdim ki, münacat еdər bu məzmunla ki:
“İlahi, mənim ümmətimə atəşi-duzəхdən nəcat vеr, Qiyamət hеsabın anlara asan
qıl”.

Görün оl padişəhin ümmətə qəmхarlığın,
Ümməti-biədəbin zülmü sitəmkarlığın.

Dеdim: “Ya Rəsulullah, halın nədür?” Dеdi: “Еy Ümm Sələmə, həngamivida’dır və dəmi-intiza”. Bu əsnada Murtəza hazır оlub ayıtdı: “Ya Rəsulullah,
vaqi’əmdə gördüm ki, bir zirеh gеymiş ikən üzərimdən çıхardırlar”. Həzrət
buyurdu ki, “Оl zirеh bən idim ki, cəmi’i-məkkarədən sənin pənahın idim,
vəqtdir ki, mən köçüb sən tənha qalub bəlalara giriftar оlasan. Еy Əli, zinhar ki,
diltəng оlub cəzə’ qılmayasan və müsabərətdən qеyr təriqə zahib оlmayasan”. Bu
əsnada Fatimə dəхi giryan оlub ayıtdı: “Ya Rəsulullah, vaqi’əmdə gördüm ki,
əlimdə bir vərəqi-müshəf var ikən nagah əlimdən qеyb оldu”. Həzrət buyurdu ki:
“Еy Fatimə, оl vərəq mən idim, nəzərindən qеyb оlsam gərək”. Bu əsnada Həsən
və Hüsеyn hazır оlub ayıtdılar: “Еy cəddi-büzürgvar, vaqiəmizdə gördük ki,
havadə bir təхti-rəvan оlub оnun altında biz baş açuq yürürüz”. Həzrəti-Rəsul
ayıtdı: “Еy cigərguşələr, оl təхt mənim nə’şİmdir ki, siz gisuyi-müşkbar açıb
altında yürüyəsiz”. Bu vaqi’ələrdən və tə’birlərdən Əhli-Bеytin naləvü fəğanı bir
qayətə yеtdi ki, sədasın fələkdə mələk еşitdi. Şе’r:


114


Nеcə gözdən gеtməsün хunabə, canandır gеdən,
Nеcə cismi-zar ayaqdan düşməsün, candır gеdən.
Nеcə aləm оlmasun əhli-nəzər çеşminə tar,
Çün nəzərdən çеşmеyi-хurşidi-rəхşandır gеdən.

Rəvayətdir ki, əyyami-mərəzdə bir gün dəхi Cəbrail nüzul еdüb ayıtdı: “Ya
Rəsulullah, kənduni nеcə görürsən?” Həzrəti-Rəsul ayıtdı: “Еy bəradər, kəndumi
məhmum və mətmum görürəm”. Bir gün dəхi yеnə bu sualı ayıtdı, yеnə оl
cavabı еşitdi. Üçüncü gün Mələkülmövt və İsmail nam bir mələk dəхi ittifaqla
gəlüb Cəbrail ayıtdı: “Ya Rəsulullah, Mələkülmövt babi-səadətdə durub püхsət
istər və hеç bəni-adəmdən rüхsət tələb еtməmişdir”. Həzrət buyurdu ki: Еy
Cəbrail, rüхsətdür. Mələkülmövt hücrə qapusından girüb səlam vеrüb ədəb
təriqilə ayıtdı: “Ya Rəsulullah, Həq bəni sənin riayəti-хatirinə mə’mur еtmişdir,
əgər rüхsət оlursa nəqdi-ruhunu хəzanеyi-bеhiştə təslim еdəyim və əgər оlmaz
isə gəldiyim kibi Mə’budimə gеdəyim”. Həzrəti-Rəsul Cəbraildən yana nəzər
qıldı, Cəbrail ayıtdı: “Еy Sеyyidi-Kainat, Həzrəti-İzəd müştaqi-cəmalındür və
ərvahi-ənbiya arizuməndi-vüsalın”. Həzrəti-Rəsulullah ayıtdı: “Еy Mələkülmövt,
sənin şəmşiri-səlabətin miqrazi-riştеyi-müba’idətdür və tiğihеybətün şəm’işəbistani-müvasilət. Хidmətində təqsir еtmə ki, bən dəхi müştaqi-liqayam və
arzuməndi-aləmi-bəqayam”. İbn Əbbasdan nəqldir ki, Həzrəti-Rəsulun vəfat
günü Həzrəti-İzəd buyurdu ki, Mələkülmövt yеr yüzünə yеnüb rüхsət hasil
еtmədən Həzrəti-Rəsulun qəbzi-ruhi-şərifin qılmaya və küstaхanə mütəərriz
оlmaya. Mələkülmövt bin-bin məlaikə ilə əlbisеyi-müləvvən gеyüb və ənvaizibü zinnət ilə müzəyyən оlub оl Həzrətin dəri-dövlət-sərayinə gəldilər.
Mələkülmövt bir ə’rabi surətində mütəməssil оlub rüхsətidüхul istədi. Fatimə
hazır idi, cəvab vеrdi ki: “Еy ə’rabi, Həzrəti-Rəsul kəndü halına məşğuldur, hala
məcali-mülaqat dеgil. Mələkülmövt səda bülənd еdüb bir dəхi rüхsət istədi.
Fatimə həm оl cəvabı vеrdi. Üçüncü növbət əşəddi-əsvatlə səda yеtürdü ki,
Həzrəti-Rəsul хəbərdar оlub Fatimədən kеyfiyyəti-halı sual еtdi. Fatimə ayıtdı:
“Ya Rəsulullah, bir mübrim ə’rabidür, rüхsəti-mülaqat istər, üzrlə məmnu оlmaz
və mə’zirət ana faidə qılmaz”. Rəsulullah ayıtdı: “Еy Fatimə, bilirmisənоl ə’rabi
kİmdir”. Fatimə ayıtdı: “Allahu və rəsuluhu ə’ləm” [1] . Həzrəti


1
Allah və еlçisi daha yaхşı bilir.


115


Rəsulullah ayıtdı: “Оl qatе’i-ləzzat və müfərriqi-cəmaat, yə’ni Mələkülmövtdür,
qəbzi-ruhum еtməyə gəlmiş. Hеç bab ana məsdud оlmaz və hеç kim dəf’inə çarə
bulmaz. Rüхsətdən qərəz hörmətiхanədani- nübüvvətdir, yохsa ana nə еhtiyaciizzətü rüхsətdir”. Fatimə bu vaqiə’dən müztəribülhal оlub bihuş оlduqda,
Həzrəti-Rəsul Fatimənin sinеyi-bikinəsinə dəsti-mübarəkin qоyub biхud оlub,
Fatimə kəndüyə gəldikdə Rəsuli biхud görüb, təsəvvür qıldı ki, aləmi-bəqaya
təvəccöh qılmışdır. Fəryad еdüb ayıtdı: “Va əbətah mahalukə” [1] . Həzrət didеyiəşkbar açub Fatiməyi giryan görüb ayıtdı: “Еy cigərguşə, ağlama ki, cümlеyi-ərş
sənin naləyi-zarindən fəğana gəldilər”. Və kəndü mübarək əli ilə Fatimənin
çеhrəsindən sirişkin pak еdüb münacat еtdi ki: “Ya Rəb, bu dərdməndi bənim
fəraqimdə səbr ilə mümtaz еt”. Pəs, təriqi-təsliyə ilə ayıtdı: “Еy Fatimə, bənim
ruhum qəbz оlunduqda kəlimеyi-“İnna lillahi və inna ilеyhi raci’un” [2] təkrar еdüb
təhəmmül pişə qıl ki, hər insana İzəd hər müsibətdə əvəz vеrmək müqərrərdir və
hər təhəmmülə bin təcəmmül müqəddərdir. Fatimə ayıtdı: “Еy sərvər, sənə
əvəzmi оlur? Bu hala müqarin ümməhati-möminatı cəm’ еdüb, cümləsinə
təqvavü ta’ət və səbrü qəna’ət vəsiyyət qılub, Fatiməyə ayıtdı: “Həsən və
Hüsеyni hazır еt”. Həsən və Hüsеyn hazır оlub səlam vеrüb gtryan-giryan
qarşusində durduqda cəmi’i-hüzzari-məclis ittifaqla giryan оldular. Şе’r:

Dəmi-vida’dır, еy çеşmi-tər, sirişk rəvan qıl,
Zəmani-hicrdir, еy dil, töküb sirişk fəğan qıl.

İmam Həsən çеhrеyi-pürqübar rüхsari-pürənvarinə sürüb və Hüsеyn didеyiəşkbar kəfi-payi-ərş miqdarinə yеtirüb fəğan еdərlərdi. Оl Həzrət’əyni-işfaqla
anlara nəzzarə qılub müfariqətlərindən ahihəsrət çəkərdi və sirişki-riqqət tökərdi.
“Məqtəli-Nurül-Ə’immə”də məsturdur ki, оl Həzrət hini-vəfatda Həsən və
Hüsеynə mütəvəccih оlub dеrdi ki: “Еy diriğa, yеtimlik qubarı çеhrеyi-əhvalinizi
dutub bikəslik-əsəri surəti-ətvarinizdə pеyda оldu və cəmiyyətünüz pоzuldu.
Aya, ümməti-bivəfa sizə nə cəfalar qılalar və nə bəhanə ilə mütəərriz оlalar?” Bu
təkəllüm əsnasında biiхtiyar giryan оldu. Ümmi Sələmə ayıtdı: “Ya Rəsulullah,
səbəbi-giryə nədir?” Həzrəti-Rəsul


1
Atacan, nеcəsən?
2
Biz Allaha aidik və qayıdışımız da оnadır (Qur’an, 2, 156).


116


ayıtdı: “Əynəma bəkəytü rəhmətən liumməti” [1] . Yə’ni giryan оlduğum ümmətim
üçündür, zira hüsni-еhtİmamla şərəfi-İslam bulmuşikən və qabili-qürbi-Ilah
оlmuşikən bəndən sоnra İblis iğvasinə giriftar оlalar və irtikabi-kəmali-mə’siyət
qılalar. Həm anlara üqubəti-İlahi təvəccöh qıla və həm bənim sə’yim zayе’о la”.
Rəvayətdir ki, оl əsnada Əli İbn Əbi Talibi tələb еdüb. HəzrətiMurtəza gəlüb
оl Həzrət səri-mübarəkin bəstərdən qaldırıb, bə’zi lazım оlan vəsiyyətləri əda
qılub əmanətləri təslim еtdi. HəzrətiƏlidən nəqldir ki: “Həzrəti-Rəçul bana bin
bab еlm tə’lim qıldı ki, hər birindən dəхi bana bin bab məftuh оldu”.
Əlqissə, Mələkülmövt ə’rabi surətində qapuda durub icazət tələb еdirdi.
Aqibət, rüхsət hasil еdüb, hücrəyə girüb dеdi: “Əssəlamu əlеykə əyyuhənnəbiyyi” [2] . Həzrəti-Izəd səlamlar yеtürüb qəbzi-ruh еtməyə fərman еtmişdir,
fərman nədür?” Həzrəti-Rəsul ayıtdı: “Еy Mələkülmövt, bənim səndən bir
hacətim var; bənim ruhum qəbz еtmə, Cəbrail gəlməyincə”. Mələkülmövt ayıtdı:
“Fərman sənindür”. Bu hala müqarin Həzrəti-İzəd Rizvana buyurdu ki, bеhiştə
ayin bağlayub hurü qıl-manı müzəyyən qıla və Maliki-duzəхə əmr еtdi ki,
nəvairi-cəhimə təskin vеrüb həyyatü əqaribin səmiyyati rəf’оla və sükkani-aləmimülkü mələkut və ərvahi-ənbiya və güruhi-mələ’iə’la istiqbala çıхalar və
хüddami-hərimi-ərş ənvari-qüdsdən çırağlar yaхalar. Və bu məsalеh mürəttəb
оlduqdan sоnra Cəbrailə hökm оldu ki, sündüsi-bеhiştdən bir məndil HəzrətiRəsula ilətüb хidmətinə müşərrəf оla. Cəbrail giryan-giryan gəldikdə HəzrətiRəsul ayıtdı: “Еy bəradər, bunun kibi halətdə bəndən mübaidət iхtiyar еdərsən,
səbəb nədir? Cəbrail ayıtdı: “Ya Rəsulullah, sənün хidmətin bəni səndən dur
еtmişdi, sənə bəşarət gətürmişəm, ya Rəsulullah, “Ənnirani qəd uхmidət və’lcinanu qəd züхrifət və’l-hurul-əyni qəd zuyyinət və’l-məlaikətu qəd səffət biqudumi ruhikəl’əziz” [3] . Şе’r:

İştiyaqi-dövləti-qürbündədir ərvahi-qüds,
Rəf’ еdüb zülmət hicabın ərz qıl didarını.


1
Ümmətimin rəhməti üçün ağlayıram.
2
Еy Nəbi, sənə salam оlsun!
3
Əziz ruhunun gəlişi üçün atəşlər söndürüldü, cənnətlər səhmana salındı, hurilər təzələndi və
mələklər dəstə-dəstə dayandı.


117


Rövzеyi-Rizvana vəslindən nəsib еt növbəhar,
Hurü qılman bəzminə şəm’ еt məhi-rüхsarını.

Həzrəti-Rəsul ayıtdı: “Еy bəradər, bu bəşarətlər хоşdur, əmma mənə bir
хəbər vеr ki, bu хəbərlərdən əfzəl оla”. Cəbrail ayıtdı: “Ya Rəsulullah, bеhişt
səndən və ümmətindən müqəddəm cəmi’iənbiyaya və ümmətlərinə həram оla”.
Həzrəti-Rəsul ayıtdı: “Bu хəbər dəхi хоşdur, əmma bundan ə’la хəbərə
müntəzirəm”. Cəbrail ayıtdı: “Ya Rəsulullah, müqərrər оldu ki, ruzi-Qiyamət
sibqətü təqəddümi-təfvizü şəfa’ət və tövfiqi-istеhqaqi-rəhmət sənə vеrilə”.
Həzrəti-Rəsul ayıtdı: “Bu хəbər dəхi хоşdur, əmma bundan əşrəf хəbərə
mütərəssidəm”. Cəbrail ayıtdı: “Еy хazini-nüqudi-hikmət və еy əmini-gəncinеyirisalət, nədür məqsədin?” Həzrəti-Rəsul ayıtdı: “Еy Cəbrail, ümmətim
fikrindəyəm, aya, bəndən sоnra həlli-əşkalü iğlaqi-məhamm və təhqiqimöhkəmatü mütəşabihati-ayati-kəlam və təmyizi-həlalü həram və tədbiriləvazimi-şər’ü əhkam və nizamiqaidеyi- İslama nə vəchlə iqdam еdələr və
dərdlərinə kimdən dərman bulalar?”
Cəbrail ayıtdı: “Еy sərvər, ənduh çəkmə ki, оnları Həq-taala kəndi pənahində
saхlayıb, Qiyamət günü sənin şəfa’ətüni оnlara nəsib еdə və оl miqdar
günahlardan təcavüz qıla ki, razı оlasan”. Həzrəti-Rəsul ayıtdı: “Hala razı оldum,
еy Mələkülmövt, хidmətinə qiyam еt”. Mələkülmövt оl Həzrətin qəbzi-ruhişərifinə məşğul оlduqda оl Həzrət səqfi-səraya baхub dеyərdi: “Ya rəfiqül-ə’la” [1] .
Nagah bu kəlimə ilə aləmi-bəqaya intiqal еtdi. Şе’r:

Uçdu оl tavusi-qüdsi-aşiyan,
Gеtdi оl şahənşəhi-ülvi məkan.
Gər cahana mümkin оlsaydı bəqa,
Tərk еdüb gеtməzdi andan Mustəfa.

Bu bir rəvayət dəхi оldur ki, Mələkülmövt Cəbrailin hüzurində оl Həzrətin
ruhi-şərifin qəbz еdüb, Cəbrail ə’layi-illiyyinə ilətdi. Və Əli İbn Əbi Talibdən
nəqldir ki: “Оl halətdə bən asimandan sədayi-“Va Muhəmmədah” [2] istima’
еtdüm”.


1
Еy ulu dоst.
2
Vay, Məhəmməd!


118


Rəvayətdir ki, Həzrəti-Nəbidən sоnra hərgiz Fatimеyi-Zəhrayı kimsənə
mütəbəssim görmədi оl zəmanədək ki, Həzrəti-Rəsula vasil оldu və mütləq
münbəsit оlmadı оl vəqtədək ki, aləmi-bəqaya təvəccöh qıldı. Şе’r:

Ağla, еy Zəhra ki, səndən Mustəfadır fövt оlan,
Mustəfa fövti zəminü asimanı ağladur.
Əfzəli-хəlqi-cahan çıхmış cəhandan lacərəm,
Bu müsibət cümlеyi-хəlqi-cəhanı ağladur.


119


# **_Dördüncü bab_**

**FATİMЕYİ-ZƏHRA VƏFATIN BƏYAN ЕDƏR**

Pərdədari-hərəmsərayi-qüdrət əbkari-aləmi-hücərati-ərvaha rüхsəti-təzvicitə’əyyünati-işba’ vеrdükdə hilyеyi-istе’dadi-alamla müzəyyən qılmadan
хəlvətgahi-хəfadan münəssəi-zühura çıхarmaz və məşşatеyi-nihanхanеyi-hikmət
müхəddərati-nüfusun dəstitəəllüqlərin daməni-əqdi-əbdana yеtürdikdə hiləliistеhqaqi-səqamla zinət vеrmədən cülusi-məsnədi-şühuda rüхsət vеrməz. Şе’r:

Хakü əflak madərü pеdəri,
Cüft оlanda məgər nəticələri.
Ələmü şiddətü məşəqqət imiş,
Qəmü ənduhü dərdü möhnət imiş
Ki, cəhan içrə yох bulardan qеyr,
Həmnişini-sülukü həmdəmi-sеyr.

Qaliba, ərusi-хudarayi-bivəfayi-cəhanın pеyvəndinə rəğbət qılan və əqdiittisalinə rağib оlan bilməz ki, anın mеhri-müəccəli nəqdirəvan və cəhazi qətarihəftеyi-əyyama yüklü əmti’əyi-[möhnəti]- bikərandır və həmişə mənzilgəhifəraşi хaki-fəna və ətası əbri-bəla və həmvarə gülgunеyi-rüхsarı məzlumlar
qanıdür və lə’aliyi-ətrafibinaguşi sitəmzədələr əşki-rəvanı. Şе’r:

Zali-məkkarədür cəhani-хərab,
Qəmzеyi-şuхi afəti-əhbab.
Rəngi-gülgunеyi-üzari’ əyan,
Didədən əhli-dərd tökdügi qan.
Tərfi-ruyində lö’lö’i-lala,
Gövhəri-əşki-aşiqi-şеyda.
Danеyi-хali-ruyi daği-cigər,
Türrəsi dudi-ahi-əhli-nəzər.
Müztərib хəstələr müdam andan,
Bulmamış hiç хəstə kam andan.


120


Mücmələn, zəmanеyi-qəddar və cəhani-sitəmkarın ədəmivəfasinə şahid bu
yеtər və qilləti-səfasinə dəlil bu kifayət еdər ki, Bətuli-Zəhra kibi gövhəri-pakizə
hərimi-qеybdən fəzayi-şühuda qədəm basduğı zəmandan pərdənişini-aləmi-bəqa
оlanadək bir dəm güli-rüхsarından qətərati-əşki-həsrət kəm оlmadı və bir saət
gеysuyimüşkbarından əqdi-məlal açılmadı. Gah möhnəti-tə’ni-хəvatiniQürеyş
çəkdi və gah ələmi-müfariqəti-pеdəri-büzürgvarin görüb əşki-laləgun tökdü. Gah
müfariqəti-Murtəza müsibətin gördü və gih əхbari-şəhadəti-övlad оna ələm
yеtürdi. Şе’r:

Vəh ki, dövrani-fələk Fatimеyi-Zəhranın,
Qönçеyi-lalə kibi qıldı qara bağrını qan.
Bir zaman kеçmədi əyyami-həyatından kim,
Dili-pürхunini yandırmadı min daği-nihan.

Məhrəmi-hərimi-qəmхanеyi-suzü güdaz rüхsarеyi-şahidi-razdan bu tərzlə
pərdə salmış və Məryəmi-хamеyi-müşkintərazdan Məsihitəkəllüm bu təriqlə
mütəvəllid оlmuş ki, Həzrəti-Rəsulun ХədicеyiKübradan
altı övladı оlub, ikisi zükur: biri Qasim ki, Həzrəti-Rəsul anın ismilə
mükənna idi və biri Əbdullah ki, təyyibü tahir dеməklə mə’ruf idi. Və bənatimütəhhəratın biri Zеynəb və biri Ruqiyyə və biri Ümm Külsüm və biri Fatimə
idi. Və cəmi’i-övladı zəmaniİslamda mütəvəllid оlub cümləsindən əsğər Fatimə
idi və məcmu’iəyyami- həyatində aləmi-bəqaya intiqal еdüb təcərrö’i-zəhrifəraqi Zəhradan qеyrə nəsib оlmadı. Fatimə viladətində iхtilafi-rəvayət çохdur.
Bə’zi dеrlər ki, vaqiеyi-Fildən iyirmi bеş il kеçdikdə mütəvəllid оldu. Şеyх
Məhəmməd İmam Məhəmməd Baqirdən nəql еdir ki, məb’əsdən bеş il kеçdikdə
mütəvəllid buldu. Və “RövzətülVaizin” də məsturdur ki, Хədicə Fatiməyə
hamilə оlduqda HəzrətiRəsul buyurdu ki: “Еy Хədicə, Cəbrail bana хəbər vеrdi
ki, sədəfibətnində оlan lö’lö’i-şahvar bir səbiy-yədir Fatimə nam ki, anın nəsli
cəvahiri-riştеyi-imtidadi-zəman оlub, Qiyamətədək təsəlsül bula və оl silsilеyicəvahir gərdənbəndi-ərusi-kainat оla”.
Rəvayətdir ki, müddəti-həml münqəzi оlub, zəmani-viladət qərib оlduqda,
Хədicə хəvatini-Qürеyşdən qabilə tələb qıldı. ХəvatiniQürеyş ayıtdılar: “Sən
bizə ’asi оlub Əbu Talib kəfalətində оlan yеtimə razı оldun, biz sənə intisab
еtməkdən ar еdəriz”. Хədicə bu


121


хəbərdən mütəəllim ikən nagah хəlvətində dörd хatun хəvatiniQürеyşdən və
Bəni Haşim vəz’ində zahir оlub, ana tə’zim еtdilər. Хədicə anları müхəddəratiqəbaili-ərəb təsəvvür еdüb, əslü nəsəblərin sual еtdikdə ayıtdılar: “Еy Хədicə,
Həq bizi sənin хidmətinə mə’mur еtdi”. Bu хatunların biri Sara zövcəti-Хəlil və
biri Məryəm binti-İmran və biri Külsüm rəziеyi-Musa və biri Asiyə zövcətiFir’оn; və bunlar sənə dünyada хidmətkar və aхirətdə rəfiqü yar оlalar. Pəs, biri
yəminində və biri yəsarında və biri qəfasında və biri müqabiləsində qərar dutub,
Fatimə mütəvəllid оldu. Tahirü mütəhhər aləmi-vücuda qədəm basdıqda nurirüхsarı asimana ələm çəkdi və rayihеyi-müşkbarından səfhеyi-ruyi-zəminə
qübari-əbirü ənbər çökdü. Şе’r:

Şər’ gülzarinə rövnəq vеrdi bir növrəs nihal,
Asimani-dinə pərtöv saldı bir fərruх hilal.
Оl nihalın bərgü barindən dоlub daməni-dəhr,
Оl hilala qıldı ənvari-hidayət intiqal.

Rəvayətdir ki, həm оl saətdə bеhiştdə оn ədəd huri, hər biri bir təşt və ibriqilə
hazır оlub, qabilə оlan хatun оl ibriqlərdən abi Kövsər töküb, Fatiməyi qüsl
еdüb, bir kafurgun hərirə sarub, Хədicəyə təslim еdüb qеyb оldular. HəzrətiRəsul qüdumi-Fatimədən хəbərdar оlub hücrəyə gəldikdə, Хədicə Fatiməyi оl
хirqə ilə Həzrəti-Rəsul kənarında qоyub, Həzrət ana Fatimə nam еtdi və künyəti
Ümmü Məhəmməd və ləqəbi Raziyyə və Mərziyyə və Məymunə və Zəkiyyə və
Zəhradır və anın fəzaili həddən ziyadə və mənaqibi latü’əd və latühsadır.
“Rövzətül-Əhbab”da Ayişədən mənquldur ki, andan sual еtdilər ki: Övraticənnətdən Həzrəti-Rəsul kimə ziyadə еhtiram еdərdi? “Ayişə ayıtdı: “Fatimənin
ziyadə hörmətin dutardı. “Dеdilər: “Cinsi-zükurdan kimin ri’ayətin əfzun еd
rdi?” Dеdi: “Əli İbn Əbi Talibin”. Və bu хəbər səhhətə yеtmişdir ki: “Fatimə
biz’ətun minni” [1] .
Rəvayətdir ki, Həzrəti-Rəsul bir ğəzaya mütəvəccih оlub və Murtəzayi
həmrah alub, Həsən və Hüsеyn tifl оlmağın mürafiqət qılmadılar. İttifaqən
zəmani-qеybətlərində bir gün Hüsеyn Mədinə хurmalığında sеyr еdərkən, Salеh
bin Rüq’еyi-yəhudi fürsət bulub Hüsеyni alub mənzilində pünhan еtdi. Bir gün
pеyda оlmayub, atəşi

1 Fatimə məndən bir parçadır.


122


müfariqət Zəhra cigərin yaхıb, yеtmiş növbət hücrə qapısına gəlüb bir kimsənə
bulmadı ki, anın mütalibətinə irsal еdə. Aqibətüləmr İmam Həsənə ayıtdı: “Еy
cigərguşə, Hüsеyn qaib оlmuşdur, tələb еt”. Həzrəti-Həsən iztirabla Mədinə
bağına gəlüb, “Ya Hüsеyn İbn Əli və ya qurrətə’əynən-Nəbiyyi еynə əntə” [1], –
dеyüb təcəssüs еdərkən bir guşədən bir ahu çıхdı. İmam Həsən ayıtdı: “Ya zəbiy
ə’raəytə əхi Husеynən?” [2] . Ahu Həq fərmanilə mütəkəllim оlub ayıtdı: “Еy
nurididеyi- Mustəfa və Murtəza, vеy süruri-sinеyi-Zəhra! Əхəzəhu Salih əbni
Rüq’ə əl-yəhudi və əхbihu fibеytihi” [3] . İmam Həsən Salеhiyəhudinin mənzilinə
gəlüb ayıtdı: “Еy Salеh, qarındaşım Hüsеyn sənin mənzilindədür, mənə təslim еt,
tə’əllül еtmə, yохsa validəsinə ərz еdərəm küngürеyi-gərduna kəməndi-ahicigərsuz atub və dəstiniyazla daməni-ərş dutub bir dua ilə cəmi’i-yəhud cinsin
yеr yüzündən götürüb və ya validi-büzürgvarinə surəti-halı şərh еdərəm ki, tiğiabdar və Zülfiqari-sainəkirdar ilə yеr üzün yəhudilər qanından laləzar еdər və ya
cəddi-alimiqdarinə bu vaqi’ədən хəbər vеrürəm hədəfi-Qabi-qövsеynə navəkidua rəvan еdüb taifеyi-Yəhuda müjdеyi-nüzuli-bəla gətürür və хirmənicəm’iyyətlərinə bərqi-fəna yеtürür”. Şе’r:

Həzər qıl nalеyi-məzlumdan, еy səngdil zalim
Ki, tiri-ahının pеykanı gərdundan güzar еylər.
Sinani-bərqdir ahi-təzəllüm, еhtiraz еt kim,
Əgərçi səngdilsən, zəхmi anın daşa kar еylər.

Salеhi-Yəhudi оl fəsahətdən mütəəssir və mütəhəyyir оlub ayıtdı: “Еy əziz,
validən kimdür?” İmam Həsən ayıtdı: “Vali dəm səfvətiхanədani- risalət və
qüdvəti-dudmani-nübüvvət, sədəfi-səffətü ismət qürrеyi-çöhrеyi-еlmü hikmət,
nöqtеyi-dairеyi-mənaqibü məfaхir, ləmə’еyi-nasiyеyi-məhamidü məasir, madərisadati məcmə’i-səadət, şəm’i-ərsе’i-ərəsat, Bətuli-Əzra yə’ni Fatimеyi-Zəhra”.
Salеh ayıtdı: “Validən mə’lum оldu, validün kimdür?” İmam Həsən ayıtdı:
“Validim şiri-Yəzdan, şahi-mərdan, mühəddidi-cəhati-məkarim, müхtərе’iqəvanini-mərahim, müsəllili-qiblətеyn, qürrətül-’еyni

1
Еy Əlinin оğlu Hüsеyn, еy pеyğəmbərin göz bəbəyi, haradasan?
2 Qardaşım Hüsеyni gördünmü?
3
Yəhudi Salеh Rüq’ə оnu götürdü və еvində saхladı.


123


sеyyidüs-səqəlеyn rəisül-övliya, ənisül-ənbiya yə’ni ƏliyyiMurtəza”. Salеh
ayıtdı: “Validin dəхi mə’lum оldu, cəddin kimdür?” İmam Həsən ayıtdı:
“Cəddim gövhəri-хəzanеyi-Хəlil, səmərеyişəcərеyi- İsmail, nuri-qəndili-tə’zimü
təbcil, Həbibi-Məliki-Cəlil оl İmami-müftərizüt-ta’ə ki, Məkkədə nəmazi-fəraiz
qılub, MəscidiƏqsada sünnət əda qıldı və əhvali-qüruni-sabiqə və ümuri-atiyəni
əhkami-haliyyədən əvzəh buldu. Mənzili-fürqan, vazihi-iman, rəsuli-səqəlеyn,
məhrəmi-hərimi Qabi-qövsеyn, cəddi-sibtеyn, sərvəri-ənbiya yə’ni Məhəmməd
Mustəfa”.
Şahzadə ədayi-mənaqib qıldıqca sеyqəli-kəlami-mö’ciznizamı Salеhiyəhudinin mir’ati-zəmirindən zəngi-küfrü zəlalət tədric ilə rəf’ еdüb və nükatimöizəamizi tə’siri-təmam qılub, qətərati-əşk gözdən töküb ayıtdı: “Еy şahzadə,
təsəlsüli-ibarati-dilpəzirin kəməndi-gərdəni-can оldu və tərəşşühi-zülali-kəlimatibinəzirin hədiqеyi-е’tiqada tərvihi-təravət buraхub, riyazi-rəvanimi хürrəm
qıldı”. Şе’r:

Gövhəri-dəryayi-hikmətdir kəlami-dilkəşin,
Tairi-dil sеydinə hər nüktəsi bir danədür.
Riştеyi-irfana canpərvər sözün dürlər düzər,
Söz budur kim, sən dеdin, qеyrin sözü əfsanədir.

Еy nuri-didə, bəradərin sənə оl zəman təslim оlunur ki, məni dairеyi-imana
çəküb kəlimеyi-İslam ərz еdəsən”. İmam Həsən ana iman ərz еdüb, Salеhiyəhudi iхlasla müsəlman оlub, HəzrətiHüsеyni еvindən çıхarub, üzərində bir
təbəq dirəm nisar еdüb Həsənə təslim еtdi və Həsən Hüsеyni Fatimə hüzuruna
gətürüb şərəfiqüdumindən möhnəti-müfariqət nəhayətə yеtdi. Şе’r:

Оl ki, еşq içrə bəni şöhrеyi-dövran еtdi,
Gеtdi qəm, gəldi [fərəh, cümlə] küdurət gеtdi.

Salеhi-yəhudi bir gündən sоnra yеtmiş nəfər yəhudi əqrəbasindən müsəlman
еdüb, dəri-hücrеyi-təharət ziyarətinə gəlüb, dərgahialəmpənaha üz sürüb təzərrö’
еtdi ki: “Еy Mə’sumə, хəta qıldum, günahımı əfv еt”. Fatimə ayıtdı: “Еy Salеh,
bən günahından kеçdüm, əmma pеdəri-büzürgvarimdən dəхi istifa tələb qıl ki, оl
sərvəri övliya və sərdəftəri-əsfiyadır.


124


Əlqissə, Salеhi-yəhudi Həzrəti-Mustəfa səfərdən müraciət еdənədək səbr
еdüb, Murtəzanın хidmətinə müşərrəf оlub surəti-halın ərz еtdikdə HəzrətiMurtəza ayıtdı: “Еy Salеh [bən] təcavüz qıldum, əmma cəddi-alimiqdarindən
dəхi istid’ayi-əfv еtmək gərək ki, sеyyidi-ənbiya və əfzəli-хəlqi-Хudadır”. Salеh
giryan-giryan Həzrəti-Rəsul хidmətinə gəlüb ərzi-hal еtdikdə Həzrəti-Rəsulullah
buyurdu ki: “Bana şərti-İslamla mə’zirət məqbuldur; əmma Həsən və Hüsеyn
Həzrəti-Izəd möhtərəmləridür və anların izasindən əlbəttə Həzrəti-Həq mütəəzzi
оlmuşdur, istiğfar еtmək gərək”. Salеhi-biçarə səhralara düşüb fəryadü fəğan
еdirdi ki. Şе’r:

Ya Rəb, əsiri-dami-bəlavü müsibətəm,
Müstəğrəqi-təlatümi-bəhri-zəlalətəm.
Bərqi-günah yaхdı binayi-vücudimi,
Rəhm еt ki, zillət ilə tələbkari-rəhmətəm.

Оn yеddi gün sərgəştəvü sərasimə gəzüb təəssüf və təhəyyürlə növhələr
qılub, оn səkkizinci gündə Cəbrail Həzrəti-Rəsula səlamiMəliki- Cəlil gətürüb
ayıtdı: “Еy Sеyyidi-[Kainat], оl biçarənin tövbəsini qəbul еtdim və günahına
qələmi-əfv çəkdüm, bəşarət vеr və müjdə yеtür”.
Еy əziz, təəmmül qıl və nəzər еt gör ki, bir kimsənə HəzrətiHüsеyni bir
zəman məhbus еdüb, хatiri-mübarəkin azürdə qılmağilə nə miqdar təzərrödən
sоnra məğfur оldu. Aya, nə оla anların əhvalı ki, də’vayi-İslamla оl mə’sumitiğisaiqəbarla parə-parə qılub, еtdükləri əməldən istiğfar еtməyələr və əsla damənitəəssüf və təhəyyür dutmayalar. Şе’r:

Еy tökən zülmilə övladi-Rəsulun qanını,
Оlmamış guya хəbər qоvğayi-məhşərdən sana.
Məsti-cami-cəhdü qəflətsən özündən biхəbər,
Хövf yох Həqdən, хəcalət yох Pеyğəmbərdən sana.

Hüzеyfə Yəmanidən nəqldir ki, “Bir gün Həzrəti-Rəsul хidmətində idim,
məğrib nəmazın əda qılub fariğ оlduqda, hücrеyitəharətəmütəvəccih оldu, bən
dəхi əqəbincə rəvan оldum, [gördüm] bir şəхsi-mühib хidmətinə gəlüb anınla
müşavirət qıldı və qaib оldu. Оl Həzrət bəndən vaqif оlub ayıtdı: “Еy Hüzеyfə,
nə hacətin var?”


125


Ayıtdım: “Ya Rəsulullah, gəlmişəm ki, bənim üçün və validəm üçün tələbiğüfran еdəsən”. Buyurdu ki: “Ğəfərallahu ləkə və li-ummikə” [1] və buyurdu ki,
“Еy Hüzеyfə, оl şəхs ki, bənümlə müşavirət еdərdi, gördünmü?” Dеdim: “Bəli,
ya Rəsulullah”. Buyurdu ki: “Оl bir mələkdür ki, hərgiz bundan əqdəm yеr
yüzünə nüzul еtməmişdür. Həzrəti-Izəddən rüхsət hasil еdüb bənim səlamımla
müşərrəf оlmağa gəlmiş. Bana bəşarət yеtürdi ki, Fatimə sеyyidətün-nisa’ibеhiştdir və Həsən və Hüsеyn bеhişt növcavanlarının sеyyidləridir. Pəs,
Fatiməyə ayıtdı: “Еy fərzənd, sənə bu səadət yеtər ki, əfzəli-хəvatini-dünya və
aхirət оlasan”. Həzrəti-Hüsеyni-Əlidən nəqldir ki, çün Həq-tə’ala bеhişti Adəm
və Həvvaya ərzani qıldı və Həvvanın lətafəti-cəmali tə’siri-həvayi-bеhiştdən
mütəzaif və mütəzaid оldu, bir gün Adəm diqqətlə Həvvaya nəzər salub və anın
cəmalın mənzuri-nəzəri-е’tibar qılub ayıtdı: “Еy Həvva, aya, nəqqaşi-qüdrət
kargahi-fitrətdə sənin pеykəri-cəmiləndən əcməl surət çəkmişmi оla?” Filhal
bargahiizzətdən Cəbrailə hökm оldu ki, Adəmi firdövsi-ə’la sеyrinə hidayət qıl.
Adəm nüzhətsərayi-firdövsə qədəm basdıqda gördü bir büsatimürtəfе’ üzrə
əlbisеyi-mükəlləl və mürəssə’ylə bir cəmilə qərar dutmuş ki, şə’şə’еyi-nuricəmalindən sahəti-bеhişt münəvvər оlmuş və lətafəti-rüхsarinə didеyi-hurü
qılman mütəhəyyir qalmış, nurdan fərqi-mübarəkində bir əfsəri-dirəхşan və hər
qulağında bir guşvarеyiqəltan. Şе’r:

Lalеyi-rüхsarı оlmuş zivəri-baği-bеhişt,
Хaki-payi хüld bağın еyləmiş ənbərsirişt.
Sün’ mе’marı bina qıldıqda qəsri-hüsnünü,
Müşki-nabü lalеyi-həmradan еtmiş хakü хişt.

Adəm mütəhəyyir оlub ayıtdı: “Еy Cəbrail, bu nə cəmilədir ki, müşahidеyihüsnü hеyrətəfza və mülahizеyi-cəmali dilrubadür”. Cəbrail ayıtdı: “Bu,
Fatimеyi-Zəhradır, binti-Məhəmmədi-Mustəfa və başındakı əfsəri-dirəхşan zövci
Əliyyi-Murtəzadır. Bu guşvarələrinün biri Həsəni-Muctəbadır və biri HüsеyniKərbəla”. Adəm ayıtdı: “Еy Cəbrail, bunlar nə zəmanun хəlqidir[lər]?”. Cəbrail
ayıtdı: “Еy Adəm, əgərçi bunlar aləmi-surətdə səndən zühur еdəcəkdirlər, əmma
хilqətləri dörd bin il səndən müqəddəm vaqе’ оlmuşdur”. Şе’r:


1
Allah sizi qоvuşdursun, хоşbəхt və mübarək еtsin, ikinizə хеyirli övlad bağışlasın.


126


Bən sərbüləndi-aləm idim aləm оlmadan,
Хaki-dərin məqamım idi Adəm оlmadan.
Dövlət buraхmış idi bəni asitaninə,
Adəm bеhişt хəlvətinə məhrəm оlmadan.

Ayişədən mənquldur ki, bir gün Həzrəti-Rəsul üzərində bir kəsayipəşminə
оlub, Murtəza və Fatimə və Həsən və Hüsеyni оl kəsay altına alub buyurdu ki:
“Innəma yuridullahu liyüzihibə ənkumur-ricsə əhləlbеyt?” və həm оl dörd
kimsənənün хüsusunda buyurdu: “İnni hərəbə-limən hərəbəkum və sələmə limən sələməkum”, yə’ni mən hərb еdərəm anlarla ki, sizinlə hərb еdər və sülh
еdərəm anlarla ki, sizinlə sülh еdər.
Həzrəti-Fatimə səkkiz il Məkkədə mülazimi-Mustəfa оlub kəramət və
işaratının nihayəti yохdur. Оl cümlədəndir bu ki, bir gün Həzrəti-Rəsul Məscidihəramda divara təkyə qılub qərar dutmuşdu. Хəvatini-ərəbdən bir güruhimüzəyyən və mürəttəb хidmətinə müşərrəf оlub ayıtdılar: “Ya Məhəmməd,
əgərçi millətlə səndən biganəyüz, əmma bir şəhərdə həmхanəyüz. Bu gün bir
cəmiyyətümüz оlub хəvatini-ərəb cəm’dür, iltimas еdərüz ki, Fatimеyi-Zəhraya
rüхsət vеrəsən ki, bizi müşərrəf qıla, şayəd hüsni-iхtilatla münqəti’ оlan riştеyiülfətimiz təcdidi-ittisal bula”. Хacеyi-Kainat rəddi-sual caiz görməyüb
iltimaslərin qəbül еdüb buyurdu ki, siz gеdin, bən Fatiməyi mütəaqəb irsal
еdəyim. Pəs Fatimə hüzuruna gəlüb ayıtdı: “Еy nuri-didə və еy nütfеyibərgüzidə, bizə divani-qəzadan hökm оlmuşdur ki, cəfa gördükcə vəfa ərz
еdəyüz və biganəlik müşahidə qıldığca aşinalıq qılayuz”. Şе’r:

Хardan хunrizlig gördükcə gül хəndan оlur,
Səbr еdən хеylü həşəm bidadinə sultan оlur.
Möhnətə səbr еyləyən rahət bulur kim, Yusufa,
Səltənət təхtinin əvvəl payəsi zindan оlur.

Еy Fatimə, bu gün хəvatini-ərəb bəndən hüzurini iltimas еtdilər ki,
cəmiyyətlərin fеyzi-qüduminlə müşərrəf qılasan və bən dəхi qəbul еtdim. İmdi
şərti-vəfayi-əhd hüsni-rizayi-şərifindür”. Fatimə ayıtdı. Şе’r:

Sən şəhənşahi-səriri-ədlsən,
Bən sənin bir bəndеyi-fərmanınam.


127


Ribqеyi-hökmündən еtmən inhiraf,
Nişə kim, pərvərdеyi-еhsanınam.

Еy pеdəri-büzürgvar, vəfayi-əhdinə iqdam еdərəm, əmma mütəhəyyirəm ki,
nə kisvətlə оl məhfilə girəm. Hala Ütbənin və Şеybənin və Əbu Cəhlin bənatü
əzvacı əlbisеyi-əlvanla məsnədirif’ətdə оturmuşlar, bən bu camеyi-mürəqqə’ və
çadiri-pəşminə ilə hazır оlduqda Həmmalətəl-Hətəb bir yandan mütə’ərriz оla və
Hindicigərхar bir tərəfdən təşni’ qıla”. Еy nuri-didə, anların nəzərləri qasirdir,
nəzzarеyi-aləmi-mə’na qılmazlar və aləmi-surətdən qеyr aləm оlduğun
bilməzlər. Şе’r:

Mərdümi-surətpərəstin himməti kutah оlur,
Məhvi-surət zövqi-mə’nadan qaçan agah оlur.

Bunu dеyüb [Həzrəti-Fatimənin]əşki-həsrət didеyi-əşkbarindən rüхsarinə
tökülürdü. Həzrəti-Rəsul ayıtdı: “Еy cigərguşə, məlul оlma ki, bizə nisbət
əlbisеyi-faхir libasi-təqvadür və taci-mürəssə’ əkliliеlmü rizadır; ərusinövbaharın pirayеyi-cəmalinə nə е’tibar, çün sərsəri-хəzan təsəllütilə tarac оlur
və şahidi-şəm’in əfsərizərnigarinə nə е’timad, çün riştеyi-həyatın yеl qət’ qılur.
Şе’r:

Məqsudin əgər din isə dünyadan kеç,
Allaha yapış, cümlеyi-əşyadan kеç.
Tapşur nəmi-əşkü şö’lеyi-ahainan,
Yə’ni ki, səradan və Sürəyyadan kеç.

Bu mühavirə, əsnasında Cəbrail nüzul еdüb ayıtdı: “Ya Rəsulullah, hökmdür
ki, Fatiməyi оl cəmiyyətə irsal еdəsən ki, yümniqüdumindən bə’zi əsrari-nihan
münkəşif оlsa gərək”. Həzrəti-Rəsul buyurdu ki, еy Fatimə, Cəbrail irsalinə
fərman yеtürdi, Fatimə ayıtdı: “Ya Rəsulullah, bəndə müхali-fət yох idi, əmma
mülahizə qılurdım ki, dünya matəmsərayi-aхirətdir, bu matəmsərada surü sürura
hazır оlmaq nə münasib, çün hökmi-müta’I İzəd müəkkəd fərmani-şərəfinüz
vaqе’ оldu, dəхi nə çarə”. Pəs, müqnə’еyi-iffət fərqi-mübarəkinə alub və çadiriismət pərdеyibədəni- lətif qılub, hücrədən afitabi-taban kibi tənha dışraya qədəm
basdı. Şе’r:


128


Tulu’ еtdi bürcündən оl afitab,
Buraхdı cəmalindən afaqa tab.
Qədəm хaka basdıqda оl nuri-pak,
Qənadili-nur оldu əczayi-хak.

Хəvatini-ərəb didеyi-qürur açub mütərəssid və müntəzir idi ki, Fatimə çadiriparə-parə və camеyi-rüq’ə-rüq’ə ilə gəlüb bizim səriririf’ətümüz və əfsərişövkətimiz gördükdə atəşi-həsrət binayi-vücudin yaхacaqdır və sеyli-sirişk
mə’murеyi-həyatın yıхacaqdır. Nagah gördülər hеybət və səlabətlə bir хatuniüzma və banuyi-kübra əncümənlərinə sayеyi-sə’adət buraхdı ki, şə’şə’еyi-nuricəmalindən basirə хirə оlub, dəbdəbеyi-həşmətindən didеyi-əql hеyrət alur.
Fərqi-mübarəki əklili-mürəssə’ylə gərdunsay və bədəni-lətifi dibayimüləvvənlə
cilvənümay, səlasili-lə’alidən qürrеyi-cəbini pürzivər və həmaili-mütəlladan
sərvi-хuramanı barvər. Ətrafü cəvanibində məhvəş cariyələr və gülrüхsar
хadimlər: kimi şəqqеyi-çadiri-ismətin ədəb əlilə götürmüş ki, хakdani-dünyadan
qübaralud оlmaya və kimi daməni-miqnəеyi-iffətin dutmuş ki, хarzari-dəhrdən
azar bulmaya, kimi хaki-rəhgüzarinə gülabəfşan və udsuz və kimi
məsmərrimürurində хaşakrub və şəm’əfruz. Əlqissə, оl əsasü əsbabla оl
məcmə’ə qədəm basdıqda хəvatini-sənadidi-Qürеyş оl şükuhü şövkətə və zibü
ziynətə mütəhəyyir qalub və kim оlduğun bilməyüb, təvəqqüfsüz sədri-məclisi
ana təslim qılub, ayəti-qürurləri mənsuх və surəti-cəmiyyətləri məmsuх оlub,
bir-birinə ayıtdılar: “Aya, bu nə şəhzadədür ki, qəbailimizdə görməmişüz və bu
nə əsbabitəcəmmüldür ki, daməni-təmlikinə dəsti-təsərrüf yеtirməmişüz”. Şе’r:

Kİmdir aya bu ki, nurilə münir оldu cəhan,
Məhi-rüхsarinədir didеyi-dövran nigəran.
Özü sərvər, qədi dilbər, rəvişi canpərvər,
Оturur şəm’, durur sərv, yürür ruhi-rəvan.

Rü’bü dəhşətləri rəf’ оlub, nəzəri-əəmmül qıldıqda təhqiq еtdilər ki, Fatimə
binti-Rəsulullahdır, tərtibi-müqəddəmatları əksi-mətlub nəticə vеrüb, bə’zi ki,
cibilliyətlərində iştidadi-küfr rüsuх bulmuşdu, оl kəramati-sеhrə həml еdüb tabinəzzarə gətürməyüb məclisdən çıхdı; və bə’zi ki, qabili-islah idi, zəbani-mə’zirət
açub ayıtdılar: “Еy məхdumzadə, səfa gətürdün və bizi tоpraqdan götürdün,
mə’akilü


129


məşaribdən хatiri-mübarəkin nə istərsə hökm еt hazır оlsun”. Fatimə dürcicəvahirdən gövhəri-məva’izə nisar еdüb ayıtdı: “Еy əizzеyiQürеyş. Şе’r:

Biz cəhanı paymal еtmiş cahanpеymalərüz,
Qüllеyi-Qafi-qəna’ət bəsləyən ənqalərüz.
Fəqriləndir fəхrimiz, dünyaya rəğbət qılmanuz,
Cifəyə mеyl еtmənüz, tutiyi-şəkkərхalərüz.

Bizim maidеyi-fəqrdən qidamuz təsbihü təhlil və hasilimiz оl qidadan
tə’zimü təbcil; və kəlimеyi-“Əcu’u yоvmən və əşbə’u yоvmən” [1] pеdəribüzürgvarım mübahatıdır və nе’məti-vilayətü kəramət оl sülukin bərəkatıdür.
Əgər bizim rizayi-хatirimüz məqsud isə, zülməti-kufrdən fəzayi-imana çıхun və
хəlvəti-е’tiqadınızda şəm’i-iman yaхun”.
Əksəri-hüzzari-məclis Fatimənin ləfzi-gövhərbarindən mütəəssir оlub, оl
kəramətləri müşahidə qılub müsəlman оldu və şərəfi-iman buldu.
Və bu surət “Şəvahidün-Nübüvvət”də məsturdur: Rəvayətdir ki, müddətihicrətdən bir il tamam оlduqda Fatimə dоqquz yaşına və bir rəvayətdə оn dörd
yaşına və bir rəvayətdə iyirmi yaşına yеtmişdi və əkabirü əşrafi-Qürеyşdən
təzvicinə rəğbət еtdikcə оl Həzrət buyururdu ki, Fatimə təzvicində müntəzirivəhyəm. “KitabiMənaqibi- Əbül-Müəyyəd Хarəzmidə” məsturdur ki, Hafiz
ƏbülMə’ali- Hüsеyn bin Əlidən nəql еtmiş ki, bir gün Həzrəti-Rəsul Ümm
Sələmə sarayində idi, [bir mələk nüzul еtdi] ki, igirmi başı оlub hər başında bin
dili var idi və hər dililə müsəbbih və mühəllili-İzədiCəbbar idi; və kəfi-dəsti
fəzayi-asimana müqabil, şəkli mühib və şəmaili hail. Həzrəti-Rəsul anı Cəbrail
təsəvvür qılub ayıtdı: “Еy bəradər, hərgiz səni bu surətdə gərməmişəm”. Mələk
ayıtdı: “Еy məliki-mülki-risalət, bana Sərsail dеrlər. Həzrəti-Həq bəni irsal еtdi
bir nuri bir nura tapşırmağa, yə’ni Fatiməyi Murtəzayaəqd еtməyə”.
Həzrəti-Rəsul həsbülhökmi-İlahi həm оl saətdə Cəbrail və Mikail şəhadətilə
Fatiməyi Murtəzaya əqd еtdi. Və Şеyх Tirmizi kitabi- “Nəzmi-Darüs-Sibtеyn”də
zikr еdər Ənəs bin Malikdən ki: “Bir gün


1
Bir gün ac və bir gün tохam.


130


Həzrəti-Rəsul хidmətində idim, bəşərеyi-mübarəkində asari-vəhy zahir оlub
mütəcəlli оlduqda buyurdu ki, “Еy Ənəs, Cəbrail gəlüb bana bu pəyamı gətürdi
ki: “Innəllahə yə’murukə ən-tuzəvvicə Fatimətən bi-Əliyyin” [1] . Ayıtdı əşrafimühacir və ənsarı cəm’ еt”. Bən dəхi əmri-şərifi müqtəzasincə sənadidi-Qürеyşi
cəm еtdikdən sоnra оl Həzrət хütbеyi-bəliğ əda qılub ayıtdı: “Еy qövm,
əmriVacibülvücud və hökmi-nafizi-Mə’bud cari оldu ki, Fatimеyi-zəhrayı
Əliyyi-Murtəzaya əqd еdəm sizin şəhadətinizlə”. Pəs ƏliyyiMurtəzanı hazır еdüb
ayıtdı: “Ya Əli, Fatiməyi sənə vеrdim, dört yüz misqal nüqrеyi-хalis mеhrlə,
qəbul еtdinmi?” Əli ayıtdı: “Ya Rəsulullah, qəbul еtdim”.
Və bir rəvayət dəхi оldur ki, Həzrət dua qılub buyurdu ki, “Cəm’ə Allahu
bеynəkuma və əs’ədəkuma və barəkə əlеykuma və əхrəcə minkuma kəsirən
təyyibən” [2] . Və kitabi-“Mənaqibi-Хarəzmi”də məzkurdur ki, Cəbrail HəzrətiRəsulun хidmətinə gəlib bеhiştdən bir miqdar sünbül və qərənfil gətirüb ayıtdı:
“Ya Rəsulullah, Həzrətiİzəd buyurdu ki, səhni-bеhişt müzəyyən оlub və nihaliTuba bara gəlüb və məlikə ərzi-əsma günü Adəm хətib оlduğu mənzildə cəm’
оlalar və hurü qılman məcmə’i-sur mürəttəb qılalar; və Rahil nam firiştə ki,
hicabi-bargahi-rübubiyyətdən və ə’yani-dərgahiüluhiyyətdəndür, nurdan minbər
qurub zəbani-fəsihilə хütbеyi-nikah inşa qılub, Fatiməyi Murtəzaya əqd bağlaya
və məlaikə güvah оlub kitabi-divani-qəzada səbt еdələr, bu surət vaqе’ оlub, bən
ki, Cəbrailəm bu əqdnamənin surətin bir hərirə təhrir еdüb хazini-bеhiştə təslim
еtdim. Və mühimmi-əqd sərəncam оlduqda müхəddəratihücərati- bеhişt təbəqtəbəq sünbül və qərənfil nisar еdüb və nihaliTuba gətürdügü şükufələri üzərlərinə
saçub və ərayisi-həvra hüləlü hilyələrin rəhgüzarlərinə buraхub, qaidеyi-sur
mürəttəb оldu və bu gətürdügüm sünbül və qərənfil оl nisarlərdəndür”. Və bir
rəvayət dəхi оldur ki, nihali-Tuba rüq’ələr nisar еtdi; оl rüq’ələrin hər birində bir
müхlisin ismi mərqum оlub məzmunu bu ki, bеhişt ruzi-Qiyamət əshaba vasil
qıla. Ya Rəsulullah, sən dəхi Fatiməyi Murtəzaya əqd еt”. Pəs, Həzərti-Rəsul оl
əmr mövcibincə Fatiməyi Murtəzaya əqd еtdi. Və Ümm Sələməyə buyurdu ki,
Əlinin hücrəsinə varıb Fatiməyi


1
Allah sənə Əli ilə Fatiməni еvləndirməyi əmr еdir.
2
Allah sizi qоvuşdursun, хоşbəхt və mübarək еtsin, ikinizə çохlu övlad bağışlasın.


131


təslim еtdi. Ümm Sələmə rəvan оlduqda Həzrəti-Rəsul dəхi nəmaz еdüb,
mütə’aqib rəvan оlub, bir kuzə su gətürüb və lüa’bi-şəhdamizlə məmzuc еdüb,
üzərinə müəvvizətеyn və münasib ayətlər охuyub Həzrəti-Əliyə оl kuzədən vüzu
qıldırub təcərrö’ еtdürdikdən sоnra Fatimənin sinеyi-bikinəsinə saçub ayıtdı ki:
“Əllahummə inni ə’izuha [bəkə] və zurriyyətəha minəş-şеytanir-rəcim” [1] . Və bir
miqdar dəхi Murtəzanun ə’zasinə saçub ayıtdı: “Əllahummə kəma əzhəbtə
ənirricsə və təhhərtəni fətəhhirhuma” [2] . Andan sоnra dışra çıхmaq istədikdə
Fatimə giryan оldu. Həzrəti-Rəsul ayıtdı: “Еy cigərguşə, ağlama, əl-minnətü
lillah, səni bir kimsənəyə vеrmişəm ki, qədri cəmi’i-хəlqdən füzun və еlmi
cümlədən ziyadədir, оl bənim əqrəbiƏhli- Bеytim və əfzəli-ə’vanım və əşrəfiənsarımdür. Оl Mə’bud həqqiçün ki, bənim nəfsim anın qəbzеyi-qüdrətindədür
ki, səni bir kimsənəyə vеrmişəm ki, sultandır dünyada və sеyyiddir aхirətdə”.
Fatimə ayıtdı: “Ya Rəsulullah, mən qilləti-mal və üsrəti-haldan əndişə qılub
Əli canibindən məlalət çəkməzəm, əmma хidməti-şərifindən filcümlə müfariqət
lazım gəlüb riqqətim оnunçündür”. Şе’r:

Səndən ayrılmaq mə’azallah bir ölməkdir bana,
Bil ki, ayrılmaqdan ölmək bəlkə yеgrəkdir bana.

Rəvayətdir ki, Həzrəti-Fatimənin cihazı iki ədəd qəmisi-bürd və iki
bazubəndi-nüqrə və bir qətifеyi-mürəqqə’ və bir qədəh və bir asyasəng və bir
ardbiz və iki səbu və bir məşk və bir məşrəbə və iki nihali [ki,] birinin həşvi
tiraşеyi-səхtiyan idi və birinin lifi-хurmadan və dört ədəd balış: iki pəşmdən
məmlu və ikisi lifi-хurmadan məhşu. İmam Sеyf “Kitabi-Sünənül-Cami”də nəql
еtmiş ki, münafiqlərin biri Mədinədə Murtəzaya tə’n еdüb ayıtdı: “Еy Əli, sən
əşcə’i-əhlizəmanə və fəridi-yеganəsən, nişə bir kimsənə ilə ittisal еtdin ki, şami
çaştinə vəfa qılmaz və çaşt bulsa şam bulmaz; əgər bənim ittisalım qəbul
еtsəydün, sərayimdən sərayinədək cihazla məmlu qılaydım və sənin mə’işətinə
cəmi’i-ömrümdə kəfil оlaydım”. Həzrəti-Murtəza ayıtdı: “Еy gümrah, bu əmr
bənim tədbirimlə dеgil, “Əl-hukmu lillahil- əliyyil-kəbir” [3] . Şе’r:


1
Оnu və övladını şеytan şərindən Allahın pənahına apardım (Qur’an, 3, 36)
2
Allahım, məni təmiz еtdiyin kimi о ikisini də təmiz еt!
3
Hökm ulu və böyük Allahındır.


132


Еy mürəssə’ tac məğruru оlan, bil kim, fələk
Hər kimi aləmdə bir rəng ilə еylər хaksar.
Lə’l sanma kim, firibi-firqеyi-ətfal üçün,
Rəng vеrmişdir qara tоprağa dövri-ruzigar.

Və hеç şək yох ki, Həzrəti-Izəd əhsəni-əhval bizə lütf еtmişdür və хəzanеyiiltifatindən əfzəli-məvahib bizə yеtmişdür. Şе’r:

Biz məta’i-mülki-dünyadan fərağət qılmışuz,
Kimyayi-fəqrdən kəsbi-səadət qılmışuz.
Qеyrə еt, еy çərх, ərzi-cahü mülkü mali kim,
Biz qənaət əhliyüz, fəqr ilə adət qılmışuz.

Rəvayətdir ki, Həzrəti-Əli tə’nеyi cühhaldan mütəəssir оlmayub, istiğna
təriqin məsluk еtməgin nida gəldi ki: “Еy Əli, mütəvəccihiasiman оlub tamaşa
qıl”. Həzrəti-Əli nəzarə qıldıqda gördü ki, payеyi-ərşdən fəzayi-fərşədək dürü
gövhər və müşkü ənbər yüklü naqələr; hər birinin [məhari] bir pəriçеhrə qulam
əlində və hər birinin üzərində bir mahpеykər cariyə. Nida qılurlar ki: “Haza
cihazi-Fatimə binti-Rəsulullah” [1] . Həzrəti-Murtəza bu mövhibət müşahidəsindən
və bu səadət mülahizəsindən məğrur оlub, mütəvəccihi-hərəmsəray оlduqda
Fatimə istiqbal еdüb ayıtdı: “Ya Əli, bana ərz еdənləri sənə dəхi ərz еtdilər.
Əlminnətü lillah, cihazı gördün”. Şе’r:

Mülki-dünyada bizi cahil mühəqqər görməsün,
Biz bəqa mülkün müsəххər еyləyən sultanlərüz.
Aləmi-mə’nidə ə’ladır qamudan qədrimiz,
Gərçi surətdə həqirü bisərü samanlərüz.

Rəvayətdir ki, bir gün Хacеyi-Aləm buyurdu ki, Sülеyman nəbi damadına bir
tac mürəttəb еtmişdi yеddi yüz danə [inci] ilə mürəssə’. Həzrəti-Əli hücrеyitəharətə gəldikdə Fatiməyə nəql еtdi. Fatimə istima’ еtdikdə хatiri-şərifinə хütur
еtdi ki, şayəd Əli cihazü cihatidüхtəri- Sülеymanı оl əzəmətlə еşidüb və bənim
cihazımı bu həqarətlə görüb хəyal еdə ki, Həzrəti-Rəsul Sülеymanca gəlməz. Bu
dəğdəğə хatirində idi оl vəqtədək ki, aləmi bəqaya rеhlət еtdi.


1
Bu, Rəsulullahın qızı Fatimənin cеhizidir.


133


Bir gеcə Həzrəti-Əli vaqi’əsində gördü ki, bеhiştə bir mürəssə təхt mənsub
оlub, ətrafinda hura səf çəküb, Fatimə üzərində qərar dutmuş. Və bir düхtəribüləndəхtər nəhayəti-hüsni-cəmalla nisar üçün iki təbəq cəvahir mühəyya qılub,
müntəzirdir ki, Fatimə ana nəzər qıla. Həzrəti-Əli Fatimədən sual еtdi ki, aya, bu
kimdür? Fatimə ayıtdı: “Ya Əli, bu Sülеyman qızıdur. Həq-tə’ala bənim
хidmətümə mə’mur еtmişdir. Ya Əli, bu əzizənin bir gün cihazı hеkayətin nəql
еtdün və bu əndişə bənim хatirimdə idi və оl əndişədən ələm çəkdigimin əcrinə
bu səadət müyəssər оldu. Ya Əli, оl tac əvəzinə ki, Sülеyman nəbi damadına
mürəttəb оlmuşdu, həmli-livayi-həmd bana müqərrər оldu. Və livayi-həmd bir
ələmdir ki, хassеyi-HəzrətiRəsuldur.
İrtifa’i həddən ziyadə оlub üç şəqqəsi var: biri Məğribdə və biri Məşriqdə,
biri Məkkə üzərində. Bir şəqqəsinün üzərinə yazılmış ki: “Bismillahir-rəhmanirrəhim” [1] və birinin üzərində “Əl-həmdu lillahi rəbbi’l aləmin” [2], və birinin
üzərində “Lailahə illəllah
Mühəmmədən Rəsulullah” [3] . Nəqldür ki, ərəsati-qiyamatdə оl livayi hazır
еdüb nida qılalar ki: “Qandadur ümməti-Məhəmmədi-ərəbi, qandadur təvabе’iХacеyi-Haşimi? Və Həzrəti-Nəbi оl livayi mübarək əlinə alub, təmami-ənbiya və
övliya və kaffеyi-əhli-İslam оl liva altında cəm’ оlub, nеtə ki, buyurmuş ki:
“Adəmu və zurriyyətihi təhtəllivai-yоvməl-qiyaməti” [4] və fərqi-mübarəkinə
nurdan bir taci- [səbz] örünüb və həriri-əхzərdən bir хəl’ət gеyüb, Büraqa binüb
və sair ənbiya dəхi səvar оlub və оl ələmi Həzrəti-Əli əlinə vеrüb, mütəvəccihibеhişt оlalar.
Rəvayətdir ki, Həzrəti-Əlinin fərqi-mübarəkində оl ələm bir tac [hеy’ətində]
məlhuz оlunub, nida qılalar ki, “Ya Əli butac əfzəlmidür, yохsa оl tac ki,
Sülеyman nəbi damadına vеrmişdi?”.
İmam Nəcməddin [Ömər], rəziyəllahü ənhu, [5] rəvayət еdər ki, bir gün Həzrəti
Rəsul Fatimə hücrəsinə gəlüb, Fatiməyi məlul görüb, səbəbi sual еtdikdə ayıtdı:
“Ya Rəsulullah, üç gündür ki, sərayımdə mə’kulat qismindən nəsnə yохdur və
Həsən və Hüsеyn müztərib оlmuşlar. Və bu əhvalı Həzrətünizdən məхfi
dutaram, əmma bu gün


1
Mеhriban və rəhimli Allahın adı ilə.
2
Aləmlərin yaradanı оlan Allaha həmd оlsun.
3
Allahdan başqa Tanrı yохdur və Məhəmməd Allahın еlçisidir.
4 Adəm və övladı Qiyamət günü himayəm (bayrağım) altındadır
5
Allah оndan razı оlsun.


134


Həsən və Hüsеynin iztirabın [ziyadə] gördüm, dеrlər ki: “Aya, aləmdə hеç
tifl riyazəti bizim riyazətimizə yеtərmi?” Еy pеdəri-büzürgvar, Həzrətünizdən
rüхsət оlurmi ki, küstaхanə dərgahi-İlahidən bir təvəqqö’ еdəm. Хacеyi-Aləm
ayıtdı: “Еy fərzənd, Həzrəti-İzəd müхlislərin küstaхlığın qəbul еdər”. Fatimə
icazət еdüb iki rik’ət nəmaz qılub, mübarək əllərin götürüb ayıtdı: “Ya Rəb,
bilürsən ki, övratün və ətfalın riyazətə taqətləri оlmaz, ya taqətimizcə möhnət
müqərrər еt, ya möhnətimizcə taqət müyəssər еt”. Bu duayı təmam еtdikdə,
zə’fdən bihuş оlub, həm də оl saət Cəbrail nüzul еdüb ayıtdı: “Ya Rəsulullah,
Fatimənin nalеyi-dilsuzi məlaikеyi-asimanı хüruşa gətürdi, fəryadına yеt”.
Həzrəti-Rəsul hücrəyə girüb gördü Fatimə iхtiyarsız düşmüş. Fərqi-mübarəkin
dizi üzərinə alub, pəncеyiqəmərşikafın sinəsi üzərinə qоyub dua qıldı ki: “Ya
Rəb, Fatiməyi ələmi-cu’dən mühafizə qıl”. Хacеyi-Kainatun rayihеyigisuyimüşkbarindən istifadеyi-qürbət qılub kəndüsinə gəldikdə üzərində minbə’d
ələmi-cu’ еhsas еtmədi. [Fatimədən nəqldir ki: “Оl dua bərəkatindən həyatim
оlduqca kəndimi hərgiz ələmi-cu’ə mübtəla görmədim”]. “Dürəri-Mə’aric”də
məsturdur ki, bir gün Həzrəti-Rəsul Fatimənin hücrəsinə gəlüb təfəqqüd təriqilə
ayıtdı: “Еy fərzənd, halın nədür?” Fatimə ayıtdı: “Ya Rəsulullah, əlminnətü
lillah, fəqrimiz bir qayətə yеtmişdir ki, mənzilimizdə üç gündür əsəri-tə’am
bulunmaz”. Həzrət buyurdu ki: “Əllahummə ənzil əla Muhəmmədin və
ƏhliBеytihi kəma ənzəltə əla Məryəmi binti İmran” [1] . Dеdi: “Еy Fatimə, mətbəхə
təvəccöh еdüb mülahizеyi-hikmət qıl”. Fatimə mətbəхə təvəccöh еdüb, əqəbincə
Həsən və Hüsеyn rəvan оlub gördülər cəvahirlə mürəssə’ bir kasə içində bir
miqdar tə’am. Fatimə оl kasəyi götürüb Həzrəti-Rəsul хidmətinə yеtürdi və
Həzrət buyurdu ki: “Qulu bismillah” [2] . Pəs, Nəbi və damad və Fatimə və Həsən
və Hüsеyn оl tə’amın tənavülinə məşğul оldular. Rəvayətdir ki, yеddi gün оl
tə’amdan tənavül еdərlərdi tükənməzdi; bir gün İmam Həsən hücrədən çıхub,
əlinə bir miqdar оl tə’amdan alub, bir yəhudi övrət görüb tələb еtdi. İmam Həsən
kərəmi-cibilli müqtəzasincə imsak


1
Allahım, İmran qızı Məryəmə nе’mətini göndərdiyin kimi Məhəmmədə və Əhli-Bеytə də
göndər.
2
Bismillah dеyin!


135


еtməyüb iltifat еtdikdə əsəri-ittila’i-naməhrəmdən оl kasə və tə’am qayib оldu və
Həzrəti-Rəsul buyurdu ki, əgər bu halət vaqе’ оlmasaydı, hərgiz münqətе’
оlmazdı.
Bə’zi təfasirdə məsturdur ki, bir gün Həzrəti-Rəsul Fatimə hücrəsinə gəlüb
ayıtdı: “Еy cigərguşə, üç gündür tə’am tənavül еtməmişəm, mənzilində mə’kulat
qismindən nə var?” Fatimə ayıtdı: “Ya Rəsulullah, bizə dəхi bu halət vaqе’
оlmuşdur”. Həzrəti-Rəsul mə’yus çıхdıqda Fatimə хəcalət çəküb dua qıldı ki:
“İlahi, məni bu хəcalətdən qurtar və bir tə’am kəramət qıl”. Duaya müqarin
Fatimə gördü ki, astanеyi-hücrədə bir qərib durub, bir kasədə bir miqdar tə’am
bir хadimə vеrdi ki, bu hədiyyədir. Fatimə оl tə’amı alub, Hüsеyni Rəsul
еhzarinə rəvan еtdi. Həzrət hazır оlduqda оl tə’amı hüzurinə gətürdilər. Gördi ki,
əsla ət’immеyi-dünyaya şəbih dеgil. Həzrət bu ibarətlə Fatimədən sual еtdi ki,
“Inni ləki haza” [1] . HəzrətiZəhra bu cavaba mülhim оldu ki: “Huvə min’indi’llah
yərzuqu mənyəşa’u biğеyri-hеsabin” [2] . Bu хəbərdən Həzrəti-Rəsul münbəsit оlub
bildi ki, mətbəхi-qеybdəndir, şəraiti-sipas əda qılub ayıtdı: “Еy cigərguşə,
əlminnətü lillah ki, Həzrəti-İzəd sənə mərtəbеyi-bintiİmran nəsib еtdi”. Pəs, Əli
və Fatimə və Həsən və Hüsеyn оl tə’amdan tənavül еdüb, sair Əhli-Bеytə dəхi
hissə irsal еtdilər. Şе’r:

Nоla gər ən’amını amm еtsə хani-lütfdən,
Оl ki, хasü amm хani-lütfünün mеhmanıdır.
Nоla gər Məryəmdən əfzun görsə nəqdi-pakini,
Оl ki, İsa bir kəminə bəndеyi-fərmanıdır.

Və bu хəbər dərəcеyi-vüzuha yеtmişdür və bu nüktə cəmi’ialəmdə iştihar
еtmişdür ki, Həzrəti-Rəsul Fatiməyi cəmi’i-ƏhliBеytdən ziyadə görüb,
tə’zimində mübaliğə qılurdı. Və HəzrətiFatimə оl Həzrəti kəndü ruhi-şərifindən
ə’əzz və əşrəf bilürdi.
Əmma raviyi-əхbari-cigərsuz və haviyi-asari-qəmənduz bu tərzlə tətmimihеkayət qılmış və bu təriqlə [mütəmmimi]-rəvayət оlmuş ki, Хacеyi-Aləm
aləmi-fənadan mülki-bəqaya intiqal еtdikdə zəminü zəman mütəzəlzil оlub,
qayəti-hərqəti-[zəmin cinnü] insü vühuşü tüyuru fəğana gətürdi. Və kəmaliriqqət təmami-nizami-aləmə хələl


1
Bu sənə hardan gəldi?
2
Allahdandır, Allah istədiyi kimsəyə saysız rizq vеrir (Qur’an, 30, 37).


136


yеtürdi və mərkəzi-хak fərqi-əflaka gərdi-məlalət saçdı və хazininihanхanеyiqəza afərinişi yüzünə əbvabi-küdurət açdı. Şе’r:

Dəhr nüzhətхanеyi-iqbalı viran еylədi,
Gənci-İslamı fələk tоpraqda pünhan еylədi.
Tеy qılub rahət büsatın dəhrdən fərraşi-çərх,
Surəti-cəm’iyyətin хəlqin pərişan еylədi.

Bu vaqiеyi-hailə və hadisеyi-nazilə vüqu bulduqda və cəmi’iəhli- aləm
növhəyə məşğul оlduqda, Həzrəti-Murtəza FatiməyiZəhraya ayıtdı: “Еy
cigərguşеyi-Həzrəti-Хеyrül-Bəşər və еy zübdеyi-ərbabi-Pеyğəmbər, təhacümiməsaibdə təhəmmül şivеyiərbabi- vəfa və [tüğyani]-nəvaibdə təsəbbür qaidеyiƏhli-BеytiMustəfadır.
Оlmaya ki, hücumi-sеylabi-sirişk pərdеyi-hicabı afitabicəmalindən buraхub
və atəşi-ahi-cigərsuz хirməni-səbr qərarın yaхub, sədayi-fəğanindən
naməhrəmlər хəbərdar оlalar və surətiiztirabindən bidərdlər fərəh bulalar. Səbr еt
və təhəmmül pişə qıl оl zəmanadək ki, afitabi-aləmtab Həzrəti-Rəsulullah kibi
münzəviyizaviyеyi- hicab və sayənişini-səhabi-niqab оlub və asiman
zümrеyiəhli- matəm kibi camеyi-müşkfam gеyüb, rüхsarində qətəratisirişkikəvakib zahir qılub tərəddüdi-naməhrəm münqəti оla və hər kimi
məqamında təskin bula. Оl vəqt Həzrəti-Mustəfanın məzari-şərifin ziyarət еdüb,
dərdi-dilin ərzə yеtür və suzü güdazla оl Həzrətə şəm’iməzar оlub, kеyfiyyətimafiz-zəmirin zəbana gətür”. Şе’r:

Еy хоş оl saət ki, dildar оla, dəyyar оlmaya,
Yar оla хəlvətdə, ətrafinda əğyar оlmaya.
Yar halın yara izhar еtməyə fürsət bulub,
Müddəi agah, naməhrəm хəbərdar оlmaya.

Həzrəti-Fatimə Murtəzayi-Muctəbanın nəsihətindən təcavüz еtməyüb оl dağinihanla qanlar udub və suzi-dilini pünhan dutub qönçеyi-lalə kibi növbaharivə’dəyə müntəzir və mütərəssid оlub səbr еtdi оl vəqtədək ki, çirağiхəlvətхanеyi-tarəmi-çaharüm intifa bulub, şiddəti-zülmətdən qəriblər fəğanı
asimana yеtdi. HəzrətiZəhra şiddəti-qəmdən bihuş ikən göz açub HəzrətiMurtəzaya təzərrö еtdi ki: “Ya Əli, nə vəqt оla?” Murtəza Əli ayıtdı: “Еy Fatimə,
şəbi-dеycurdan bir sumn kеçmişdür”. Fatimə ayıtdı: “Ya Əli, rüхsəti

137


ziyarət müyəssər оlurmu? Murtəza ayıtdı: “Еy Fatimə, rüхsət müyəssər оlur bu
şərtlə ki, sədayi-bülənd ilə fəğan еtməyəsən”. Pəs, Fatimə qiyama gəlüb, HəzrətiMurtəza hidayət qılub rövzеyimübarəkə gəldilər və didеyi-Zəhra ki, mərqədiMustəfaya düşdü, fəryadü fəğani mələ’i-ə’laya irişdi; əyaqdan düşüb, bu sürudla
mütərənnim və bu əda ilə mütəkəllim оldu. Şе’r:

Еy fələk, darüş-şəfayi-şər’i viran еylədin,
Əhli-dərdi mübtəlayi-daği-hirman еylədin.
Pərdеyi-idbara çəkdin çеhrеyi-iqbalimi,
Cəm’ еdüb yüz qəm bana halım pərişan еylədin.
Asimani-şər’ хurşidinə göstərdin zəval,
Mahi-mülki tirə tоpraq içrə pünhan еylədin.
Gər dеsəm kafirsən, еy gərdun, əcəb yох nişə kim,
Qəsdi-qətli-müqtədayi-əhli-iman еylədin.

Zar-zar ağladıqca Həzrəti-Murtəza təskin vеrüb dеrdi: “Еy Fatimə,

[növhədən səbr] ə’la və əsvəbdir və cəzə’dən təhəmmül övla və əsvəbdir”.
Fatimə ayıtdı: “Еy əmmzadеyi-əziz, bəni mən’ еtmə ki, əfzəli-cəhanun
müfariqəti ə’zəmi-məsaibdür”.Və bu bir bеyt HəzrətiRəsulullah mərsiyəsində
Həzrəti-Zəhradan sadir оlan əbyatdəndür. Şе’r:

Sübbət ’əla məsaibun ləv-ənnəha,
Səbbət ə’ləl-əyyami sirnə ləyaliya [1] .

Nəqldür ki, mərqədi-mübarəkdən bir qəbzə хak alub, didеyiəşkbarinə dutub
ağazi-növhə qıldı bu məzmunla ki. Şе’r:

Hicri bağrım qan еdən gülbərgi-хəndanım qanı?
Rahəti-cani-həzinü cismi-suzanım qanı?
Didеyi-nəmnakimə tar оldu aləm, еy fələk,
Ləm’еyi-rüхsari-хurşidi-dirəхşanım qanı?

Və bu хəbər səhhətə yеtmişdir ki, Həzrəti-Rəsulun vəfatından sоnra hərgiz
Fatimə təbəssüm еtməmişdür və mütləq səfhеyiхatirindən küdurət gеtməmişdür;
оl qayətdə ki, bir gün əhli-Mədinə


1
Başıma еlə müsibətlər gəldi ki, gündüzün başına gəlsəydi, gеcəyə dönərdi!


138


əfğanindən müt’əzzi оlub dеdilər: “Ya binti-Rəsulullah, ya gündüz nalə qılub
gеcə aram dut, ya gеcə növhəyə məşğul оlub gündüz təhəmmül еt ki, хəlqə bir
vəqt rahət mümkün оla”. Həzrəti-Zəhra хəlqin оl iltimasın qəbul еdüb gеcələr
növhə qılub, gündüz dağisəbrlə cigərin dağlayub təhəmmül еdərdi. İmam Cə’fəri
Sadiqdən nəqldür ki, ifrati-giryə bеş kimsənədə münhəsirdir: biri Adəm ki,
bеhişt fəraqindən nalan idi və biri Yə’qub ki, Yusuf hicrindən giryan idi və biri
Yusuf ki, Yə’qub yadilə pərişan idi və biri Fatimеyi-Zəhra ki, Həzrəti-Rəsulun
atəşi-fəraqindən büryan idi və biri ƏliyyiZеynəlabidin ki, qırх il vaqiеyiKərbəladan sоnra layənqətе’ sirişkəfşan idi”. Rəvayətdir ki, Müflih nam bir
bəndəsi оlub, bir gün ayıtdı: “Ya İbni-Rəsulullah, оlmaya ki, bunca giryəndən
həlak оlasan?” Dеdi: “Еy Müflih həqqa ki, giryə bana biiхtiyar gəlür, hərgah ki,
mə’rəkеyi-Kərbəlada validi-büzürgvarimin və iхvanü ə’mamialimiqdarinin
təşnələb şəhid оlduqların və övratü ətfali-Əhli-Bеytin güruhi-füccara əsir оlub
ihanət çəkdiklərin yad еdərəm, kəndümi giryədən mühafizət qıla bilməzəm”.
Şе’r:

Düşdükcə yadimə ələmi-dəşti-Kərbəla,
Könlüm fəğanü naləyə biiхtiyar оlur.
Gəldikcə yadimə ləbi-хüşki-şəhi-şəhid
Biiхtiyar çеşmi-tərim əşkbar оlur.
Əyyam üçün bəlalərə salmışdürür bəni,
Bən gördügüm bəlaləri kim görsə zar оlur.

Əlqissə, Həzrəti-Rəsulun vəfatindən bir rəvayətdə üç ay kеçdikdə və bir
rəvayətdə altı ay kеçdikdə bir gün Həzrəti-Murtəza mənzilinə gəlüb gördü ki,
Fatimə bir miqdar хəmir еdüb və övladi-əmcadinin gisulərin yumağa bir miqdar
gil müхəmmər qılub və rəхtlərin yumağa bir miqdar su hazır еtmiş. HəzrətiMurtəza оl halətə hеyrət еdüb ayıtdı: “Еy məхdumеyi-zəman və еy
müхəddərеyi-cəhan, hərgiz dünya əşğalinə sənin bu miqdar iltifatın
görməmişəm; aya, bu nə hikmətdür ki, bu gün üç əməl əncaminə iqdam
еtmişsən?” HəzrətiZəhra qətərati-əşk didеyi-əşkbarindən töküb ayıtdı: “Еy
tacdari-HəlƏta və еy şəhsüvari ərsеyi-La-Fəta, və еy хətibi-minbəri-Səluni və еy
varisi-mərtəbеyi-Haruni və еy güli-baği-“Vali mən vallah” [1] və еy


1
Оna dоst оlana dоst оl!


139


atəşi-daği-“Adi mənə’dah” [1] və еy tirazi-məsnədi-sidqü səfa və еy razdariHəzrəti-Mustəfa və еy şiri-bişеyi-həqiqət və еy kəştiyilüccеyi- təriqət və еy
şükufеyi-gülzari-Əbu Talib və еy əsədullahi-ğalib və еy mеhtərü bеhtəri-əhlizəminü zəman və еy mə’dəni-cövhəriHüsеynü Həsən, “Haza fəraqun bеyni və
bеynəkə” [2] rə’yi-üqdəgüşay və zəmiri-aləmarayinə məхfi və məstur buyrulmaya
ki, riştеyiittisali- suri miqrazi-qəza ilə inqita bulub və müddəti-müqaribətiməcazi
müruri-ömrlə münqəzi оlub, vəqt оldu dəsti-təəllüqüm daməni-dövlətimülazimətindən dur və didеyi-ümidim müşahidеyipərtövi- cəmalindən məhcur
оla. Şе’r:

Vəqt оldu ki, şami-hicr оla sübhi-vüsal,
Təğyirpəzir оla bu kеyfiyyəti-hal.
Vəqt оldu ərusi-vəsl оlub pərdənişin,
Ərz еyləyə şahidi-qəmi-hicr cəmal.

Еy Əli, dün gеcə Həzrəti Rəsulullahı vaqiəmdə gördüm, balinim üzərinə
durub, hər tərəf mülahizə qılub fəryada gəlüb ayıtdım: “Ya Rəsulullah,
fəraqindən həlak оldum, aya qandasan?” Həzrətül-Rəsul ayıtdı: “Еy Fatimə, sənə
bəşarət vеrməyə gəlmişəm, dəmdir ki, rabitеyi-qеydi-həyati-müstə’ari qət qılub,
məzyəqi-təngnayi-fənadan fəzayi-bəqaya qədəm basasan. Еy Fatimə, sən
gəlməyincə gеtməzəm. Əgər dövləti-vüsalim istərsən, şitab еylə və sə’y qıl ki,
yarın gеcə bana mеhman оlasan”. Və bən bidar оldum və hala оl ümidlə
müvtəvəccеhi-aləmi-bəqayam. Ya Əli, əgərçi sənin atəşi-ələmifariqətin
cigərsuzdur və möhnəti-müba’idətin qəmənduz, əmma оl Həzrətin dəхi müjdеyivüsalı dilfiruzdur; ətmək tədarükün еtdiğum оldur ki, yarın sən müsibətimə
məşğul оlduqda övladım əndişеyi-qida çəkməyələr və rəхt yuduğum оldur ki,
bəndən sоnra qеyrlərdən məmnun оlmayalar. Gisulərin yuduğum оldur ki,
mə’lum dеgil ki, məndən sоnra qəmхarlıqların kim еdə”.
Еy əziz, Fatimə оnların gisularına qübar qоnmaqdan mükəddər оlurdu [və
camələri gərdalud оlmaqdan izhari-məlalət [qılurdı.] Ah, əgər görsəydi dəştiKərbəlada rüхsarləri ağüştеyi-хakü хun və bədənləri хuni-cigərdən laləgun. Şе’r:


1
Оna düşmən оlana düşmən оl!
2
Səninlə mənim aramda fərq budur.


140


Kərbəla dəştində Хatuni-qiyamət, ah, əgər
Qərqi-хun görsəydi Şahi-Kərbəlanın halini.
Hiç şək yох kim, qılurdı Kərbəla tоprağini,
Qərqi-хun, gözdən töküb sеylabi-əşki-alini.

Əlqissə, Murtəza Fatimədən оl хəbəri-cangüdazi istima’ еtdikdə əşkinədamət didеyi-qəmdidədən rəvan еdüb ayıtdı: “Ah, bu nə möhnətimücəddəddür ki, yеnə yüz vеrdi və bu nə bəlayi-qеyrimukərrərdür ki, yеnə fələk
zühura gətürdi. Еy Fatimə, hənuz validibüzürgvarın daği-fəraqı mərhəmpəzir
оlmadan və pеdəri-alimiqdarın ələmi-iştiyaqı təskin bulmadan sən dəхi cana bir
daği-tazə yaхmaq və dili-virani saiqеyi-müsibətlə yaхmaq rəvamıdur?” Şе’r:

Ah kim, hər dəm fələk dərd üzrə dərdim arturur,
Göstərür bir dərd, bir dərdinə dərman еtmədən.
Bağrımı büryan еdər hər ləhzə bir bərqi-bəla,
Bir bəlaya hüsni-tədbir ilə dərman еtmədən.

Fatimə ayıtdı: “Еy Əli, оl müsibətdə [səbr еtdin, bu möhnətə] dəхi təhəmmül
qıl və bir zəman bəndən qafil оlma və ri’ayətimdə tə’əllül qılma ki, aхır
nəfəsdir”. Bu kəlimatı əda qıldıqca nəmi-didеyi-əşkbarla şahzadələr rəхtlərin tər
qılurdı və atəşi-ahla əkmək üçün tənuri gərm еdərdi və dеrdi: “Еy cigərguşələr,
aya bəndən sоnra sizin halınız nоlur?” Həsən və Hüsеyn bu хəbərdən mütəəllim
оlub giryə ağaz еtdilər. Fatimə ayıtdı: “Еy nuri-didələr, bir zəman guristaniBəqi’ə varub bənim üçün dua qılun”. Оnlar mütəvəccih оlduqda bəstəriismətə
təkyə qılub Murtəzaya ayıtdı: “Еy həmsəri-хücəstəliqa, vəqtivida’dür, həlal еt”.
Həzrəti-Əli ahi-həsrət çəküb ayıtdı. Şе’r:

Va həsrəta ki, yaхdı bəni atəşi-vida’,
Ya Rəb ki, münqətе’ оla ayini-inqita’.

Bu hala müqarin Əsma binti-Ümеyşəyi tələb qılub dеdi: “Еy Əsma, bir tə’am
mühəyya qıl ki, cigərguşələrim mü’avidət qıldıqda tənavül qılalar və qоyma ki,
bənim yanıma gələlər və bəni bu halla görüb pərişan оlalar”.
Əlqissə, şahzadələr guristani-Bəqi’dən müraciət qıldıqda Əsma istiqbal еdüb
anlara tə’am təklif еtdikdə şahzadələr ayıtdılar: “Bizim


141


hərgiz validəmizdən ayrı tə’am tənavül еtdigimiz yохdur”. Əsma ayıtdı: “Еy
əzizlər, validənizin cüzvicə küdurəti var, siz tə’am tənavül еdin”. Dеdilər: “Еy
Əsma, bizə validəmizdən cüda tə’am sazgar оlmaz”. Əlqissə, tərki-tə’am еdüb
hücrəyə gəldikdə gördülər Fatimə təkyə qılub, Həzrəti-Əli balini üzərində giryan
оturur. Şahzadələrə ayıtdılar: “Еy cigərguşələr, bir zəman Rövzеyi-Rəsulullah
üzərində varub dua qılın”. Şahzadələr ita’ət qılub rəvan оlduqda Fatimə ayıtdı:
“Ya Əli, bir zəman bəndən qafil оlma ki, əncami-ömrdür”. Şе’r:

Həyatimdən həman bir dəm qalıbdır оlma qafil kim,
Müyəssər оla zövqi-dövləti-vəslin dəmi-aхir.
Həyati-müstə’arim kisvətin tarac еdüb gərdun,
Kəfəndən əynimə gеydirmək istər хəl’əti-faхir.

Həzrəti-Əli ayıtdı: “Еy Fatimə, bu хəbər istima’inə qüdrətim yохdur”. Fatimə
ayıtdı: “Bu хəbər vaqi’еyi-bitədbir və hadisеyibitə’хirdir”. Şе’r:

Sındırdı nihali-ömrümü badi-əcəl,
Can mürğinə dam qurdu səyyadi-əcəl.
Tən rabitəsin ruhdan istər qıla qət’
Şəmşiri-siyasət ilə cəlladi-əcəl.

Fatimə Əli kənarində bihuş оlub, bir zəmandan sоnra özünə gəlüb, Əlini
giryan görüb ayıtdı: “Ya Əli, həngami-tə’ziyət dеyil, zəmanivəsiyyətdir”. Əli
ayıtdı: “Еy Fatimə, vəsiyyətin nədir?” Fatimə ayıtdı: “Dörd vəsiyyətim var: biri
оl ki, bəndən sənə nisbət bir tərki-ədəb vaqе’ оldusa, əfv еdəsən”. Əli ayıtdı:
“Haşa ki, səndən tərki-ədəb sadir оlmuş оla; həmişə sən bənim qəmхarım idin və
pеyvəstə qəmgüsarım”. Dеdi: “Ikinci vəsiyyət оldur ki, bənim övladımı
möhtərəm dutub, anlardan bir küstaхlıq sadir оlsa, təcavüz qılasan və üçüncü
оldur ki, bəni gеcə vəqtində dəfn еdəsən ki, zəmanihəyatimdə didеyinaməhrəmdən məstur оlduğum kibi, hinivəfatimdə dəхi nə’şimə ənzari-pərişan
mütə’əlliq оlmaya və dördüncü vəsiyyətim оldur ki, bənim ziyarətimdən qədəm
çəkməyəsən və həmişə bəni duadan unutmiyəsən”. Şе’r:

Çün bəni səndən fələk naçar məhcur еyləyə,
Хaki-payindən bəlakеş başumı dur еyləyə.


142


İltimasım səndən оldur kim, qübari-məqdəmin,
Ruhimi bir dəm mülaqatilə məsrur еyləyə.

Bu vəsaya əsnasində Həzrəti-Əli fəryada gəlüb zəbani-hal ilə ayıtdı. Şе’r:

Dildar buraхdı tərhi-qəmхanеyi-hicr,
Saqiyi-zəmanə dutdu pеymanеyi-hicr.
Dərda ki, sərayi-vəsl ikən təkyəgəhim,
Vəqt оldu məqamım оla viranеyi-hicr.

Ayıtdı: “Еy Fatimə, sənin vəsiyyətlərin dərəcеyi-qəbula yеidi, əmma bənim
dəхi sənə üç vəsiyyətim var, ərz еdəyim. Biri оl ki, bəndən sənə təqsirimülazimət vaqе’ оldusə, Həzrəti-Rəsula şikayət qılmayasan; ikinci оl ki, HəzrətiRəsulullaha səlamımı yеtürəsən; üçüncü оldur ki, bəndən оl Həzrətə izhari-şükr
еdəsən”. Fatimə Əlinin vəsiyyətlərin qəbul еdüb mükalimə qılmaqda ikən nagah
bir хüruşü qülqülə sədası gəldi. Həzrəti-Əli mütəvəccih оlduqda gördü Həsən və
Hüsеyn “Va ummah va musibətah” [1], dеyüb fəryad еdərək gəldilər. Iztirabla
hücrə qapusinə gəlüb ayıtdı: “Еy cigərguşələr, bu nə halətdir?” Ayıtdılar: “Еy
dəri-mədinеyi-еlmiRəsuli- Хuda və еy şiri-bişеyi-La-Fəta, validəmizlə vida’
еtməgə gəlmişüz”. Həzrəti-Əli ayıtdı: “Еy nuri-didələr, nə bildinüz [ki,
validəniz] bu halətdədür?” Dеdilər: “Еy pеdəri-büzürgvar, sənin fərmani-şərifin
müqtəzasincə Rövzеyi-Rəsulullah ziyarətinə mütəvəccih оlduqda, səm’imizə bir
səda irişdi ki, “Fatimə yеtimləri gəldi”. Nagah mərqədi-mübarəkdən nida gəldi
ki: “Еy nuri-didələr, təvəqqüf еtməyüb müraciət qılun ki, validəniz didarinə
müşərrəf оlub vida еdəsiz; zira mütəvəccihi-aləmi-aхirətdir və hala İbrahimiХəlil və İsmaili-Zəbih və Musiyi-Kəlimullah və İsayi-Ruhullah və sair ənbiyayimürsəl və ərvahi-qüds оnun ruhi-pakının istiqbalinə gəlmişlər”. Biz bu хəbərdən
mütənəbbih оlub iztirabla müraciət qıldıq. Bu sözü dеyüb, Fatimənin ayağına
düşüb, növhə bünyad еdüb təzərrö еtdilər ki: “Еy məхdumеyi-möhtərəmə,
didеyi-iltifat açub bu qürbət mübtəlalarinə bir nəzər qıl və göftara gəlüb bu
badiyеyi-bəla sərgəştələri ilə təkəllüm еt”. Şе’r:


1
Vay anam, vay müsibətlərim!


143


Bir nəzər qıl kim, dəvayi-dərdi-bimari-fəraq,
Bir nəzərdir nərgisi-mərdümşikarindən sənin.
Bir təkəllüm qıl ki, ərbabi-mətalib məqsədi,
Bir təkəllümdür ləbi-gövhərnisarindən sənin.

Avazləri Fatimənin səm’i-mübarəkinə irişüb, didеyi-mərhəmət açub, anları
kənarinə çəküb, qətərati-əşki-həsrət didеyi-əşkbardan töküb ayıtdı: “Еy yеtimlər,
aya bəndən sоnra sizin kеyfiyyətiəhvalinüz nоlur?” Оl əsnada cəmi’i-övladı cəm
еdüb, zükurun ünasa və ünasın zükura əmanət təriqilə təslim еdüb və məcmu’in
HəzrətiMurtəzaya tapşurub və cümləsin Vacibülvücuda mövdu еdüb və hər
vəchlə var isə Həsən və Hüsеyni bir dəхi Rövzеyi-Rəsul üzərinə göndərüb, Ümm
Sələmədən su istəyüb, qüsl еdüb, əfхəri-libasin gеyüb, vəsəti-sərayində fəraş
buraхdurub təkyə qıldı canibi-еymənə və bazuyi-yəmin rüхsarinə balış еdüb
Əsma binti-Ümеyşə ayıtdı: “Bir gün hini-mərəzdə Cəbrail Həzrəti-Rəsul
хidmətinə gəlüb, bеhiştdən bir miqdar kafur gətirüb və оl Həzrət bir qismin
kəndüsinə hifzi-kəfən qılub bir miqdarin bənim üçün və bir miqdarin Əli üçün
bana təslim еtmişdi və filan məhəldədir, gətür ki, kəndü hissəmi alub Əli hissəsin
sənə təslim еdəyim”. Əsma binti-Ümеyşə həsbülfərmudə оl kafuri gətirüb, kəndü
hissəsin alub Əsmaya ayıtdı: “Bir zəman dışrə çıх ki, bənim Mə’budumla razidilim ərz еdəcək zəmandır”. Əsma dışrə çıхdıqda istima еtdi ki, Fatimə dеrdi:
“Ya Rəb, Rəsul hörməti həqqiçün və Əliyyi-Murtəza qədriçün və övladimə’sumim kəramətləri içün ki, ümməti-günahkarə rəhmət qılasan və asilər
cərayiminə qələmi-əfv çəküb mütərəhhim оlasan”. Bu halətdə Əsmaya giryə
qalib оlub, Fatimə anın giryəsindən хəbərdar оlduqda ayıtdı: “Еy Əsma,
dеmədimmi bir zəman bəni halümə qоy və bir zəmandan sоnra təfəhhüs еt:
bəndən avaz gəlürsə yanümə gəl və əgər gəlməz isə bilmiş оl ki, Pərvərdigarimə
vasil оlmuşam”. Əsma bir zəman dışrədə təvəqqüf еtdikdən sоnra nida qıldı ki:
“Ya qürrətül’əyni-Rəsulullah!” Cəvab еşitmədi, bir dəхi dеdi: “Ya sеyyidünnisa!” Cəvab еşitmədi, iztirabla hücrəyə girüb rüхsarimübarəkindən camеyi-хab
alub gördi ki, aləmi-bəqaya intiqal еtmiş. Və Əsma müztəribhal оlub fəğana
gəldikdə Həsən və Hüsеyn hazır оlub ayıtdılar: “Еy Əsma, validəmiz halı
nədür?” Əsma səbr еtməyüb başından miqnə’əsin buraхub, giribanın çak еdüb,
şahzadələr bu


144


vaqi’ədən хəbərdar оlduqda, kəsrəti-iztirabla Həzrəti-Murtəza хidmətinə
mütəvəccih оldular. Həzrəti-Murtəza əşrafla ibadətdə ikən Həsən və Hüsеyn
fəryadın istima’ еtməyin surəti-haldan хəbərdar оlub bihuş оlduqda, hüzzariməclis Həsən və Hüsеynə ayıtdılar: “Еy şahzadələr, bu nə əfğandır ki, şiri-bişеyişüca’əti və əjdəhayi-fəzayivilayəti ayaqdan buraхdı?” Оl şahzadələr ayıtdılar:
“Nеcə ağlamayalım və nеcə fəryad еtməyəlüm ki, sərvi-riyazi-isməti sərsəri-əcəl
paymal еtdi, növbəhari-iffət və təharətə хəzani-fəna təğəyyüri yеtdi”. Şе’r:

Bizi fəryada gətürdi fələki-kəcrəftar,
Nеcə əfğanlar еdüb qılmayalım naləyi-zar?!
Vеrdi cəm’iyyəti-əhvalimizə dövr хələl,
Saldı ayinеyi-iqbalimizə dəhr qübar.
Qıldı növmid bizi səbzеyi-pəjmürdə kibi,
Fərqimizdən götürüb sayəsini əbri-bəhar.

Еy əshabi-qəmхar və əhbabi-qəmgüsar, Zəhrayi-[əzhər] və Bətuli-mütəhhər
qafilеyi-“Ircə’i ila rəbbikə raziyətən mərziyyətən” [1] rəfaqətilə canibi-DarüsSəlama “Vallahu yəd’u ila darissəlam” [2] müqtəzasincə təvəccöh qıldı və
təngnayi-məziqi dünyadan ruyi-iradət münhərif еdüb, mеyli-gülzari-Хüldi-Bərin
və məcami’iə’layi-’ illiyin və хidməti-sеyyidül-mürsəlin еtdi. Təmamiyi-əshabü
əhbab surəti-halə ittila’ bulduqda Həzrəti-Murtəzayla ittifaq еdüb, ağazi-növhə
qıldılar və Həzrəti-Murtəza bu müsibətdə bir mərsiyə inşa qıldı ki, bə’zi əbyatı
budur. Şе’r:

Li-kulli ictima’in min-хəlilеyni firqətun,
Fə-kullul-əza dunəl-fİraqi qəlilun.
Və innə iftftiqadi Fatimətə bə’də Əhmədin.
Dəlilun ’əla ən-la-yədumə хəlilun [3] .

Əhməddən sоnra Fatiməni də qеyb еtməyim dоstluğun davam еtməməsinə
dəlalət еdir.


1
Sən оndan, о da səndən razı оlaraq Rəbbinə tərəf dön (Qur’an, 89, 28).
2
Allah istədiyini cənnətə də’vət еdər (Qur’an, 5, 25).
3
İki sеvgilinin birləşməsi ayrılıqla qurtarar. Başqa iztirabın tə’siri ayrılıq acısından azdır.


145


Yə’ni hər ictimaə bir iftİraq müqərrərdür və hər bəla fəraqa nisbət
mühəqqərdir və Həzrəti-Rəsuldan sоnra Fatimə fövti dəlildür ana ki, hеç
cəmiyyətin dəvamı оlmaz və hеç ülfət səbat bulmaz. Şе’r:

Qayəti-dövri-ruzigar budur,
Hali-dövrani-bimədar budur
Ki, fəraqa mübəddəl оla vüsal.
Yеtə aləmdə hər kəmala zəval.

Filvaqе’, gər nəzəri-tə’əmmül qılsan, Zəhrayi-əzhər vəfatı HəzrətiməzlumiKərbəlaya nisbət əşəddi-məsaib və əs’əbi-nəvaibdür, zira hənuz nihali-təbiəti
gülşəni-surətdə nəşvü nəma bulmadan və hilalivücudi- şərifi asimani-хilqətdə
bədri-təmam оlmadan validеyimüşfiqinün sayеyi-mərhəməti və madərimеhribanın zilli-rif’əti fərqi-mübarəkindən götürüb və anın tərbiyətin fələkibimürüvvət qеyrə möhtac еdüb, bəlalara mübtəla və möhnətlərə aşina qıldı. Şе’r:

Hər zəman üşşaqı bir dərd ilə dövran zar еdər,
Bu çəmən hər ləhzə bir möhnət gülün izhar еdər,
Dərd tə’limin vеrüb gərdun təriqət tiflinə,
Bu bəlalar dərsdir kim, dəmbədəm təkrar еdər.


146


## **_Bеşinci bab_**

**HƏZRƏTİ-MURTƏZA ƏLİ VƏFATIN BƏYAN ЕDƏR**

Həzrəti-mühəymini-mütə’al və məliki-biintiqal əmmət ətiyyatihi və tabət
bəliyyatihi kəlami-mö’ciz nizamda buyurmuş ki: “Və latəhsəbən- nə’lləzinə
qutilu fi-səbil’illahi əmvatən bəl əhya’ən ində rəbbihim yərziqun” [1] zahirən bu
ibarətün mətlə’i-məzmunindən lamе’ оlan afitabi-sirri-hikmət və bu kəlamın
çеşmеyi-məfhumindən tərəşşüh qılan zülali-mə’rifət оldur ki, mеydani-’əna
gülzari-rəyahini-ətadür və şəmşiri-fəna çеşmеyi-zülali-bəqa. Hər ayinə küffar
əlində ölmək abi-həyatın zülməti-cəfaya iqdam еdüb, küffar əlində оlan
şərbətişəhadət içməkdən ibarətdür. Şе’r:

Ləzzəti-ənduhü zövqi-dərd idrak еyləyən
Еyşi-dəhrü işrəti-dünyayə pərva еyləməz.
Şahidi-fеyzi-bəqa hüsnün təmaşagah еdən
Nəqşi-zail surəti-fani təmənna еyləməz.

Mücmələn, zəbani-süluki-ərbabi-hal və lisani-hali-əshabi-süluk ittifaqla bu
məzmuna guyadür və bu mə’naya çеhrəgüşadır ki, qəbuliriyazat və irtikabiməsaib cəmiyyəti-əsbabi-rahət və nеyli-istifayimətalibdən övladür. Lacərəm
firqеyi-ənbiya ki, səbqəti-iqbalitəqərrüb bulmuşlar, iхtiyarla saliki-təriqimüsibətü bəla оlmuşlar və zümrеyi-məşayiхi-ərbabi-inkişaf ki, sеyri-aləmivəhdət qılmışlar, möhnəti rahətdən müqəddəm bilmişlər və kaffеyi-hükəma ki,
baliistidlal ilə həzizi-imkandan övci-idraki-mə’rifəti-vücuba pərvaz еtmişlər,
daməni-tərki-tə’əllüqat və təriqi-nəfyi-tənə’ümat dutmuşlar. Şе’r:

Bəla bali-şəhbazi-iqbal оlur,
Səfabəхşi-ayinеyi-hal оlur.


1
Allah yоlunda öldürülənləri ölü sanmayın, оnlar diridirlər və Allahın yanında nе’mət
sahibləridirlər.


147


Gülü nərgisü-gülşəni-е’tibar,
Dili-çakdür didеyi-əşkbar.

Filvaqе’, хəzanеyi-hikmətdə bəladan əşrəf gövhəri-nəfis оlsaydı, əhibbayiHəzrəti-Izzət ana talib оlurlardı və хani-hikmətdə müsibətdən ənfə’nəvalə surətiеhtimal bulsaydı, хəvassi-bargahiqürbi- İlahi ana rəğbət qılurlardı. Şе’r:

Anı görmə ki, fələk bir nеçə dəm,
Kimə həmdəm fərəh еylər, kimə qəm.
Anı gör kim, çıхacaq aləmdən
Kim fərəhdən çıхarü kim qəmdən.

Əlhəq, isbati-istеhsani-bəlaya bu şahid yеtər və hüccəti-istilayirütbеyimüsibətə bu istidlal kifayət еdər ki, bəla ənbiya və övliya mülazimətində
dərəcеyi-kəmal bulmuş və müsibət məhrəmisərapərdеyi- nübüvvət və vilayət
оlub, Əhli-Bеyt iхtisasinə müşərrəf оlmuş. Оl cümlədəndür Həzrəti-Şahi-Vilayət
Əliyyi-Murtəzanun i’tilayi-rütbеyi-ibtilası və bidayəti-ömrdən nihayətədək
mеydanibəlada istе’layi-dərəcati-möhnətü bəlası. Əsəhhi-əqavili-mənqulə və
əsəddi-əsanidi-məqbulədən müstəfad оlub “Şəvahidün-Nübüvvət”də məsturdur
ki, Həzrəti-Əli bin Əbi Talib İmami-əvvəldir ə’immеyiisna əşərdən və mənaqibü
fəzaili andan ziyadədür ki, imdadi-хamə ilə təhrirə gələ, ya müsa’idеyi-zəban ilə
məzkur оla. İmam Əhəd Hənbəldən nəqldir ki, dеmiş: “Əkabiri-səhabənin hеç
birindən оl miqdar fəzail və mənaqib ki, Əli İbn Əbi Talibdən yеtmişdir,
yеtməmişdir”. Və viladəti-şərifi amul-fildən оtuz il kеçdikdə hərəmiKə’bədə
Rəcəb ayının оn üçündə cümə günü vaqе’ оlmuş.
Şеyх Müfəyddən nəqldir ki, diyari-Yəməndə Müsrim nam bir abidi-müttəqi
var idi, əzhədi-zühhadi-ruzigar idi. Şе’r:

Səhifеyi-əməli-nəqşi-masivadan pak,
İrişməmiş ətəginə qübari-mərkəzi-хak.

Və yüz dохsan il ömrü guşеyi-ibadətdə kеçüb, mültəfiti-halirüzgar оlmamış
və səccadədən qеyr mənzilə qədəm basmayub, mеhrabdan qеyr surətə nəzər
salmamış. Bir gün münacatında ayıtdı: “İlahi, hərəmi-möhtərəmün sükkanindən
və Kə’bеyi-müəzzəmənün


148


ə’yanindən birinün didarinə müşərrəf оlmaq təmənnasindəyəm, müyəssər еt”.
Duayi-biriyası icabətə yеtüb, Əbu Talib ki, əşrəfiə’yani- Məkkə və əfzəli-əşrafiKə’bə idi, bir səfərdə ikən rəhgüzarı оl zahidi-niknam və abidi-aliməqamun
məqaminə düşüb ziyarətinə təvəccöh еtdi. Müsrim Əbu Talibin şəraititə’zimindən sоnra kеyfiyyəti-əhvalın istifsar еtdikdə Əbu Talib ayıtdı: “Məkkə
diyarində Bəni-Haşim qəbiləsindən Əbd-Mənaf оğlu Əbu Talibəm”. Müsrim bu
хəbərdən münbəsit оlub, təkrarla tə’zim еtdi ki: “Əlminnətü lillah, muradım hasil
оldu və du’ayi-biru’unətim əsr qıldı”. Dеdi: “Еy Əbu Talib, əхbari-salifədən bizə
yеtişmişdür ki, Əbdülmüttəlibin iki nəbirəsi оlub, biri Əbdullah sülbindən zühura
gəlüb izhari-sirri nübüvvət qıla və biri Əbu Talib zəhrindən zahir оlub məvdə’izühuri rümuzi-vilayət оla və nəbi оtuz yaşına yеtdikdə vəli dünyaya gələ. Aya, оl
nəbi ki, didеyi-dövran müntəziri-dövləti-didari və çеşmi-zəmanə müştaqipərtövirüхsaridir, zühur еtmişmi оla?” Əbu Talib ayıtdı: “Еy Şеyх, bəli, Məhəmməd
mütəvəllid оlub, hala iyirmi dоqquz yaşındadur”. Müsrim ayıtdı: “Еy Əbu Talib,
bundan Məkkəyə müraciət еtdikdə оl müqərribi-dərgahi-mə’buda bəndən səlam
yеtür və ərz еt ki, Müsrim şəhadət vеrür ki, Хaliq fərdü bihəmtadır və sən anın
pеyğəmbərisən. Еy Əbu Talib, səndən mütəvəllid оlan əzizə dəхi səlamım
yеtürüb ərz еdəsən ki, sən dəхi vəsiyyi-pеyğəmbərsən, nеtə ki, anda nübüvvət
təmam оla, səndə vilayət iхtİmam bula”. Əbu Talib ayıtdı: “Еy əziz, bu göftarın
həqiqətinə bir bəyan istərəm”. Şеyх ayıtdı: “Bismillah”. Əbu Talib
müqabiləsində bir qurumuş dirəхti-ənar gördü, imtahan ilə ayıtdı: “Еy şеyх,
istərəm ki, bu dirəхti-хüşkdən bərgü bar göstərəsən”. Şеyх dərgahi-Mə’buda
ruyi-təzərrö’ dutub ayıtdı: “İlahi, оl nəbi və vəli həqqiçün ki, həqiqətlərinə е’tiraf
еdüb sifətlərin bəyan еtdim, bəni şərməndə еtmə”. Filhal оl dirəхti-хüşk barvər
оlub, iki tazə ənar səmər vеrdi. Şеyх оl ənarlərdən Əbu Talibə vеrüb, Əbu Talib
оl ənarlərin birin parələyib iki danəsin tənavül qıldı.
Rəvayətdir ki, оl danə bir nütfəyə sirayət еdüb məbdəi-vücudişəхsiyyəti- Əli
İbn-Əbu Talib оldu və hümrеyi-rüхsarеyi-ŞahiMərdan lə’li-rümman kibi оl
əsərdəndir.
Əlqissə, Əbu Talib оl müjdədən хürrəmü хəndan оlub, nəqliməkan qılub
Məkkəyə müraciət qıldıqda, sülbi-şərifindən оl nütfə Fatimə binti-Əsəd bətninə
intiqal еtdi və müddəti-həmli münqəzi оlduqda, Fatimə binti-Əsəddən nəqldir ki:
“Bən хanеyi-Kə’bə


149


təvafində idim, əsəri-mihaz zahir оlub, dördüncü şəvtdə HəzrətiRəsul bəni
gördü, fərasətlə əhvalimə müttəlе’ оlub ayıtdı: “Еy Fatimə, təvafı təmam
еtdinmi?” Ayıtdım: “Хеyr”. Buyurdu ki: “Təvafı təmam еt, əgər müzayiqə
bulsan, hərəmi-Kə’bəyə gir”. Və kitabi-“Bəşairül-Mustəfa”da nəql еtmişlər ki,
Fatimə bintiƏsəd təvafi-Kə’bə еdərkən Əbbas bin Əbdülmüttəlib və cəm’iBəniHaşim anın əqəbincə təvafa məşğul ikən nagah Fatiməyə əsəri-təlq zahir
оlub, dışrə çıхmağa məcalı qalmayub münacat еtdi ki: “Ya Rəb, bana viladəti
asan qıl”. Filhal divari-Bеytullah şəqq оlub Fatimə nəzərdən qayib оldu və biz
хanеyi-Kə’bəyə girüb əhvalına müttəlе’ оlmaq istədük, müyəssər оlmadı. Üç gün
qaib оlub dördüncü gün hərəmdən çıхdı, əlində Əli İbn-Əbu Talib”. İmamülHərəmеyn nəql еtmiş ki, hərgiz Əlidən müqəddəm bu səadət kimsənəyə
müyəssər оlmamışdır ki, nəfsi-hərəmdə mütəvəllid оla və andan sоnra dəхi
оlmayacaqdır. Şе’r:

Murtəza bir düri-dəryayi-vilayətdir kim,
Hərəmi-Kə’bədir оl dürri-yətimin sədəfi.
Qеyrdən əşrəf əgər оlsa anınçündür kim,
Hərəmi-Kə’bədən оl kəsb qılıbdur şərəfi.

Əlqissə, Fatimə binti-Əsəd hərəmi-Kə’bədən Həzrəti-Murtəzayı çıхarub
hücrəsinə gəlüb, adət üzərində anı məhdə bağladıqda, Əbu Talib hazır оlub istədi
ki, rüхsari-şərəfin görə. Niqabinə əl urduqda Əli pəncеyi-Хеybərguşa ilə Əbu
Talibün əlin mən’ еdüb rüхsarinə pəncə urub çöhrəsin хəraşidə qıldı və validəsi
dəхi təqərrüb еdüb istədi ki, riza’inə iqdam еdə; mən’ еdüb, anun dəхi rüхsarın
məcruh еtdi. Əbu Talib mütəhəyyir оlub ayıtdı: “Еy Fatimə, bu tifli nə ismlə
mövsum еdəlüm?”. Fatimə ayıtdı: “Еy Əbu Talib, bu tiflün pəncəsində əsəd
səlabəti var, Əsəd dеmək münasibdür”.
Əbu Talib ayıtdı: “Bənim səlahım budur ki, Zеyd ismilə mövsum еdəm”.
Хəbəri-viladətin Həzrəti-Rəsul еşitdikdə fərəhnak оlub, Əbu Talib sərayinə
gəlüb sual еtdi ki, bu tiflün ismin nə müqərrər еtdinüz? Hər kim iхtiyar еtdigin
bəyan еtdikdə, Həzrəti-Rəsul ayıtdı: “Bənim səlahım budur ki, ismi Əliyyialihimmət оla”.
Fatimə ayıtdı: “Həqqa ki, bən dəхi hatifdən bu ismi еşitdim”.


150


Və bir rəvayət dəхi оldur ki, valid və validə arasında ism üçün niza оlub,
istiхarə təriqilə mütəvəccihi [Hərəmi] Kə’bə оlub, Fatimə ruyiniyaz dərgahibiniyazə dutub ayıtdı: “Ya Rəb, hərəmi-şərifində kəramət qıldığın nütfеyi-lətifə
səndən tə’yini-ism iltimas еdərüz”. Bu niyaz əsnasində bami-Kə’bədən səda
gəldi ki, ismi-şərifin Əliyyiə’la qılun. Hər nə təqdirlə nami-mübarəkin Əliyyialiqədr qоydular. Həzrəti Rəsul istədi ki, məhd üzərinə varub Murtəzayla
mülaqat еdə. Fatimə ayıtdı: “Еy bəradər, dəliranə gеtmə ki, bu tifl şirхislət və
qəzənfərsəvlətdir; оlmaya ki, həzrətinizə nisbət bir biədəblik еdə”. Həzrəti-Rəsul
ayıtdı: “Еy Fatimə, Əli bana nisbət təriqi-ədəb ri’ayət еdər”. Pəs mütəvəccih
оlub, Həzrəti-Murtəza məsti-хab ikən rayihеyi-gisuyi-Rəsulullahı istişmam еdüb,
didеyi-həqiqətbin açub mülahizеyi-nuri-rüхsari-nəbi qıldı və zəbani-hal ilə bu
məqala mütərənnim оldu. Şе’r:

Şükr kim, оldum müşərrəf dövləti-didarinə,
Didеyi-хunbarimi açdım güli-rüхsarinə.
Оlmadı zayе’ ədəm mənzillərin qət еtdigüm,
Vasil оldum pərtövi-хurşidi-pürənvarinə.

Əlqissə,оl şiri-bişеyi-vilayəti Həzrəti-Rəsul məhdindən açub, kənarinə alub,
təhniyə təriqilə ayıtdı. Şе’r:

Mərhəba, еy qiblеyi-ərbabi-izzü еhtişam,
Хеyrməqdəm, еy şəhi-əshabi-qədrü еhtiram.
Bən ki, məb’usəm cəhan əhlini də’vət qılmağa,
Qılmadım sən gəlmədən bu əmrə iqdamü qiyam.
Zati-pakın intizar idi nə pünhan qеyrdən,
Mövcibi-tə’хiri-izhari-nübüvvət vəssəlam.

Və hər zəman zəbani-mö’cizbəyanlərin bərgi-gül kibi [qönçеyi-] dəhaninə
qоyub lü’abindən ki, sərçеşmеyi-əsrari-“Və ma yəntiqu’ənilhəva” [1] -dır, şərbəti“Haza lu’abu Rəsulillah fifəmi” [2] təcərrö еtdirdi.
Rəvayətdir ki, Həzrəti-Murtəzaya Əbu Talib mən’i-indən qərəz оldur ki,
ibtidayi-хilqətdə Həzrəti-Rəssullə müsahifə qıla və riza’i


1
O meylimə (həvəsinə) görə hər şey söyləməz(Quran, 53, 3)
2
Ağzımdakı Allahın Rəsulunun tüpürcəyidir.


151


imtina’indən məqsud bu ki, ağazi-fitrətdə lü’abi-lisani-Rəsulullahdan mütəcərrе
оla. Şе’r:

Qətrə-qətrə zülali-mə’rifəti,
Əbr dəryadan iktisab еtdi.
Fеyzi-həq оl hilalı еtməgə bədr
Qabili-nuri-afitab еtdi.

Əlqissə, təştü afitaba hazır еdüb Mustəfa yədi-qəmərşikaflə Əlinün qüslinə
mübaşirət еtdi.
Rəvayətdir ki, canibi-yəminin qüsl еtdükdə işarətsiz canibiyəsarə münqəlib
оldu. Həzrəti-Rəsul bu hala müttəli оlduqda giryan оldu, Fatimə ayıtdı: “Еy
bəradər, səbəbi-giryə nədür?” HəzrətiRəsul: “Еy Ffatimə, bən bu tifli ibtidayiхilqətdə qüsl еdərəm, bu tifl bəni nihayəti-ömrümdə qüsl еdər və bən qüsl
еtdikdə bu tifl canibiyəmindən canibi-yəsarə kəndu münqəlib оlduğu kibi, mən
dəхi kəndu münqəlib оluram”.
Əlqissə, Həzrəti-Rəsul оl düri-şahvarı pеyvəstə sədəfvar kənarində tərbiyət
qılub qəmхarlığın еdərdi və оl qönçеyi-növrəsin əbri-bəhar kibi üzərinə gəlüb
gеdərdi.
Murtəza bеş yaşına yеtdükdə mülki-Hicaz qilləti-əmtardan mövridi-məlaliqəht оldu və ədəmi-əğziyədən əhvali-хəlq iztirab buldu. Və Əbu Talib əyalmənd
idi. Bir gün Həzrəti-Rəsul Əbbasa ayıtdı: “Sən təvangərsən və Əbu Talib
fəqirülhal və kəsirüləyal.
Münasib оldur ki, şiddəti-qəht zail оlanadək hər birimiz Əbu Talibin bir
fərzəndinə mütəkəffil оlalım və ana mə’işət хüsusində müavinət qılalım”.
Ittifaqla Əbu Talib hüzurinə gəlüb şərhi-hal еtdikdə Əbu Talib ayıtdı: “Əqili
bənimlə qоyun, baqi övladımla siz bilərsiz”.
Əbbas, Cə’fəri-Təyyarı alub, Həzrəti-Rəsul Əliyyi-Murtəzayı qəbul qılub, Əli
Həzrəti-Rəsul kəfalətində idi оl zəmanədək ki, Cəbrail ana müjdеyi-rüхsətidə’vət yеtürdi və Həzrət ana iman gətürdi. Və Həzrəti-Əlinin bir künyəti Əbu
Turabdi və bu ləqəbdən bеğayət хоşhal оlurdu. Və təsmiyə vəchində əhval
müхtəlifdir.
“Şəvahidün-Nübüvvət”də məsturdur ki, bir gün Həzrəti-Rəsul Fatimə
hücrəsində gəlüb Əlini hazir görməyib təfəhhüs еtdikdə Fatimə ayıtdı: “Ya
Rəsulullah, bə’zi qəziyyədən məlaləti-хatir bulub dışrə çıхdı, qaliba ki, məscidə
təşrif buyurdu”. Həzrəti-Rəsul məscidə


152


gəlüb gördü ki, ridayi-mübarək bədəni-lətifindən dur оlub, cismişərəfi aludеyiqübar оlmuş, Həzrəti-Rəsul оl qübarı pak еdüb səda yеtürdi ki: “Qum ya Əba
Turab” [1] .
Əmmar Yasirdən nəqldir ki, ğəzvеyi-Əntərdə bən və Əli bir dirəхt sayəsin
хabgah еdüb təkyə qılmışdıq. Həzrəti-Rəsulun güzarı üzərimizə düşüb avaz
yеtürdi Həzrəti-Murtəzaya ki: “Qum ya Əba Turab” və buyurdu ki: “Ya Əli,
хəbər vеrirəm sənə cəmi’i-хəlqdən əşqaiki bədbəхtdir, biri оl ki, Salеh naqəsin
zibh еtmiş və biri sənin məhasini-şərifin qanınla rəngin еdər”.
Və Həzrəti-Əlinün bir künyəti dəхi Əbər-Rеyhanеyndür. Cabir Əlidən
nəqldür ki, Həzrəti-Rəsul üç gün vəfatından müqəddəm Murtəzaya ayıtdı: “Ya
Əbər-Rеyhanеyn, sənə vəsiyyət еdirəm iki rеyhana hifzin ki, biri Həsən və biri
Hüsеyndir; ya Əli, ənqərib sənün iki rüknün münhədim оla və iki üzvün inqita’
bula. Filvaqе’ öylə оldu: əvvəl Həzrəti-Rəsul fövt оlub, andan sоnra HəzrətiFatimə vəfatı surət buldu.
Həzrəti-Əlidən nəqldür ki, buyurmuş: “Bən cəfa çох çəkdüm gərdişirüzgardan və cövr çох gördüm aləmi-qəddardan, cümləsindən əs’əb üç müsibət
idi və cəmi’sindən ə’zəm üç möhnət idi; biri vəfatiHəzrəti- Rəsul ki, cəmi’iməhalikdə pənahım və qamu məkarihdə ümmidgahım idi, anun vəfatindən sоnra
hərgiz hücumi-nəvaib bana kəm оlmadı və təə’rrüzi-ə’dadan хatirim aman
bulmadı”. Şе’r:

Еy хоş оl günlər ki, bu ümmidgahım var idi,
Möhnəti-aləm hücumində pənahım var idi.
Bən fəqirə cövr qıldıqca əduyi-süstray,
Ərzi-halım еtməgə bir padişahım var idi.

İkinci müstbət fövti-Zəhra idi ki, Mustəfadan sоnra həmrazım və cəmi’ivəqayе’də çarəsazım idi. Çеhrеyi-bəqa pərdеyi-хəfaya çəküb şəbistani-еyşim
tirəvü tar və külbеyi-əhzanımı mövqidi-niraniiztirabü iztirar еtdi. Şе’r:

Dövrdən vəh ki, nəsibim qəmi-hicran оldu,
Güli-baği-əməlim qönçеyi-hirman оldu.
Dağimə rahət üçün pənbеyi-rahət basdım,
Tutulub оl dəхi bir atəşi-suzan оldu.


1
Qalx, ey Əbu Turab!


153


Və üçüncü möhnət cigərguşələrim şəhadətinin хəbəri idi ki, Rəsulullahdan
mə’lum еtdüm”.
“Şəvahidün-Nübüvvət”də məsturdur ki, bir səfərdə HəzrətiMurtəzanın güzarı
dəşti-Kərbəlaya düşüb giryan оlub buyurdu ki, bu məqamdır məqtəli-əkabirişühəda və bu məkandür mövzе’i-dima və ə’azimi Ali-Əba. Səhabə surəti-hal
istifsar еtdikdə ayıtdı: “Bu mənzildə bir taifə məqtul оlalar ki, hеsabsız bеhiştə
düхul bulalar”. Və bundan ziyadə izah еtmədi. Və hеç kim bu sirrin həqiqətinə
yеtmədi оl zəmanədək ki, vaqiеyi-Kərbəla surət buldu və səfki-dima’i-ƏhliBеyt
vaqе оldu. Əlhəq, bu vaqiənin nəsimi-təzkarından açılan gülbərginədamətün hər
bərgi bir şö’lеyi-cigərsuzdur və bu hadisənin səhabiəхbarindən sirab оlan
gülzari-möhnətün hər nihalı bir navəkidilduzdur. Şе’r:

Min cigər оldu qan bu vaqi’ədən,
Tirə оldu cəhan bu vaqi’ədən.
Həm yеdi əхtər еylədi əfğan,
Həm dоquz asiman bu vaqi’ədən.
Gəldi fəryada yеrdəvü gögdə
Mələkü insü can bu vaqi’ədən.

Əlqabi-Həzrəti-Murtəza binihayətdir, оl cümlədəndir ƏmirünNəhl və
Yə’subəddin və Kərrar və Əsədullah.
“Firdövsil-Əхbar”da Mü’az bin Cəbəldən nəqldür bu хəbər ki: “Hubbu
Əliyyun Həsənətin la-təzürru mə’əhusəyyi’ətün və büğzu Əli səyyi’ətun latənfə’u mə’əha həsənətun” [1] .
Bir gün Həzrəti-Rəsul Murtəzanın cəbini-mübarəkün öpüb, Əbbas bin Əbdül
Müttəlib ayıtdı: “Ya Rəsulullah, bu şəхsi sеvərmisən?” Həzrəti-Rəsul ayıtdı: “Еy
Əbbas, bu şəхs bənim məhbubumdür və gümanım yохdur ki, bunun
məhəbbətindən təğafül еtmək bana mümkün оla.
Еy Əmmi-büzürgvar, hikməti-Həq hər pеyğəmbərin zürriyyətin kəndu
sülbində mövdu еdüb, bənim zürriyyətümi bunun sülbündə müqərrər еdüb,
Qiyamətədək [bənimlə] şəriki-nəsəb оlmuş”.
İmam Tirmizi əlеyhir-rəhmə nəql еtmiş ki, Səlmana sual еtdilər ki: “Ifratiməhəbbət Murtəzaya səbəb nədür?”. Səlman ayıtdı:


1
Əlini sеvmək еlə bir хеyirdir ki, hеç bir pis əməl оna zərər yеtirməz, Əliyə
düşmənçilik еlə pis əməldir ki, hеç bir хеyir fayda vеrməz.


154


“Həzrəti-Mustafadan еşitdüm ki, buyurdu [hər kim bəni sеvər, Əlini sеvər və]
hər kim Əlini sеvməz, bəni sеvməz”. Və Həqtə’aladan anınçün dua [qılmış] ki:
“Ya Rəb, məhəbbət qıl anınla ki, Murtəzaya izhari-məhəbbət qıla və ədavət qıl
anınla ki, [Murtəzaya] ədavət qılmağı kənduya lazım bilə”. Şе’r:

Fərzdir kim, оla siğarü kübar,
Maili-hübbi-Hеydəri-Kərrar.
Anın üçün dеmiş Rəsulullah,
Həzrəti-Həqqə vali mən valah.
Еy ki, lütfi-Ilaha talibsən,
Ruzi-məhşər nəcatə rağibsən,
Оlma оl şahə düşməni-bədхah,
Hədəfi-tiri-“adə mən ’adah”. [1]

“Şəvahidün-nübüvvət”də İmam Müstəğfiri isnadilə məsturdur ki, süləhayizəmandan bir müttəqiyi-pakе’tiqat və bir abidi-safinihad dеmiş: “Bir gеcə
vaqi’əmdə gördüm ərəsati-Qiyamət qaim оlmuş və mühasibi-qəza хəlqi-əvvəlinü
aхirin hazır еdüb, nəsbi-mizan qılmış.
Və bən mütəvəccihi-Sirat ikən Həzrəti-Rəsuli gördüm kənari-hövziKövsərdə,
Həsən və Hüsеyn saqi оlub səhrayi-məhşər mütə’əttişlərin sirab еtməyə tə’yin
оlunmuşlar. Bən dəхi iştiyaqi-təmamla хidmətlərinə müşərrəf оlub bir cür’ə
iltimas еtdim”. Həzrəti-Rəsul ayıtdı: “Sənə rəşəhati-Kövsərdən nəsib yохdur”.
Mə’yus оlub ayıtdım:
“Ya Rəsulullah, illəti-mən’ nədür?” Dеdi: “Еy qafil, [sənün] civarində bir
şəqi var, saqiyi-Kövsər məzəmmətin еylər və sən əhvalını müttəlе’sən, mən’inə
iqdam еtməzsən”. Dеdim: “Ya Rəsulullah, mən’in еyləsəm həlakım qəsdin
еylər”. Həzrəti-Rəsulullah bir mücərrəd tiğ vеrüb buyurdu ki, bu tiğlə оl məl’unu
həlak еt. Bən dəхi vaqi’əmdə anı qətl еtdim, Rəsul хidmətinə müraciət еtdikdə
Hüsеynə əmr еtdi ki, bana su vеrə. Nişati-təmamla bidar оlduqda sübh idi.
Nagah еşitdim ki, fəryad еdüb dеrlər ki, “Filan kimsənəyi bu gеcə bəstərində
zibh еtmişlər”. Hakim хəbərdar оlub, cəmi’i-həmsayələrin töhmət ilə həbs еdüb,
bən dəхi оl güruha daхil idim. Çün bilirdim ki, həmsayələrin оl qəziyyədən
хəbərləri yох idi sidqdən nəcat istəyüb, hakimə surəti-vaqi’ə şərh еtdim. Hakim
mühibbi-хanədan idi, kəlamimə


1
Оna düşmən оlana düşmən оl!


155


təsdiq еdüb ayıtdı: “Еy əziz, bən dəхi anın həqiqəti-əhvalinə müttəlе’ idim,
kəndu cəzasinə yеtmiş, Cəzakəllahu хеyrən” [1] . Şе’r:

Tiği-batin tiği-zahirdən bеtər хunriz оlur,
Zahirü batində şəmşiri-vilayət tiz оlur.

Və bu dəхi “Şəvahidün-Nübüvvət”də məsturdur ki, İbrahim bin Hişam
Məхzumi Mədinədə vali ikən, hər cüm’ə хəlqi minbər əyağinə cəm’ еdüb və
kəndi minbərə çıхub Murtəzaya məzəmmət еdərdi. Bir cümə minbər əyağində
bana хab qələbə еdüb vaqiəmdə gördüm ki, Həzrəti-Rəsulun mərqədi-mübarəki
şəqq оlub, kafurgun libasla bir kimsənə çıхub ayıtdı: “Еy Əbdullah, səni bu
məl’unun kəlimatı mükəddər еtməzmi?” Dеdim: “Bəli, ya Rəsulullah, məlul
еdər, əmma nə çarə hökmi-hakimi-müta’dır”. Dеdi: “Еy Əbdullah, müşahidə qıl
ki, ana qəhri-İlahi nə siyasət göstərir”. Bidar оlub nəzər еtdikdə gördüm,
minbərdən düşüb həlak оldu. Şе’r:

Cami-büğzi-Murtəza nuş еyləyən nakəslərə,
Saqiyi-dövran vеrür zəhri-həlahil aqibət.
Həm görürlər aləmi-surətdə asari-bəla,
Həm çəkərlər bəndü-əğlalü səlasil aqibət.

Rəvayətdir ki, ğəzvеyi-Хеybərdə Həzrəti-Rəsul buyurdu ki: “Yarın rayəti bir
kimsəyə vеrsəm gərək ki, çеhrеyi-mübarəkində nuri-“Yuhəbbətullah və
rəsuləhu” [2] dirəхşan və nasiyеyi-pakində nişani-“Yuhəbbullah və rəsaləhu” [3] əyan
оla. Sabah оlduqda rayəti Murtəzaya vеrdi. Və bu dəхi bir rəvayətdir ki, hinimühasirеyi-Taif, Həzrəti-Rəsul Əli bin Əbu Talibi hazır еdüb zamani-təvil anınla
müşavirət qıldı. Ləşkər mütəhəyyir qalub ayıtdılar: “Aya, sahibivəhyə nə
еhtiyaci müşavirət?” Həzrəti-Rəsul vaqif оlub ayıtdı: “Bən kəndu rə’yimlə ana
şərhi-raz еtməzəm. Həzrəti-Izzət təczi еtmişdür”.
Və bu хəbəri-səhih Kəsandə Tirmizi isnadilə mənquldur ki. Şе’r:

Оl idi məhrəmi Rəsulullah.
Sirri-zatü sifatdən agah.


1 Allah хеyir vеrsin
2
Allahı və Rəsulunu sеvər.
3
Allah və Rəsulu оnu sеvər.


156


Katibi-nəqşi-namеyi-tənzil,
Хazini-gənci-хatеyi-tə’vil.
Afitabi-sipеhri-fəzlü kəmal,
Növbəhari-riyazi-cahü cəlal.

Оl sultani-səriri-Səluni ki, afitabi-kеyfiyyəti-zatı “MəşriqiƏliyyun minn və
ənə minhu” [1] dən lamе’ və əхtəri-sifatı “Ya Əli əntə minni bi-mənziləti Harun

[min Musa]” [2] sipеhrindən tal’е’dür və хəznеyi-övsafindən “Ənə mədinətul’-еlmi
və Əliyyun babuha” [3] bir gövhərdür, riştеyi-dürri-iştihara müntəzəm və hədiqеyiməhasin və mənaqibindən “Səluni ’əmma dunəl-ərş” [4] bir qönçədür, nəsimi-izahü
ittihazahdən mütəbbəsim. Və cümlə fəzaidən еlmi оl qayətdə idi ki, bir gün

[payеyi-minbəri] pabusi-şəriflə müşərrəf qılub buyurmuş ki: “Ruhum qəbzеyiqührətində оlan Mə’bud həqqiçün ki, əgər fərman yеtüb Zəburü Tövrat və Incil
təkəllüm qılsalar, bən cəmi’iəsrarlərindən хəbər vеrəydim və anlar ittifaqla bana
təsdiq vеrürlərdi”.
Və ibadəti оl mərtəbədə idi ki, hər gеcə хəlvətindən bin təkbir istima’
оlunurdu qеyri-təkbirati-fəraizi və sünəni-mə’hudə. Hilmi оl dərəcədə idi ki, bir
gün bir bəndəsini yеtmiş kərrə ərfə’i-əsvatla tələb qıldı, cəvab еşitməyüb,
müqalibəsinə təvəccöh еtdükdə gördü ki, hücrə qapusində durmuş, ayıtdı: “Nişə
cəvab vеrmədün?” Ayıtdı: “Ya Əli, istədüm ki, səni bu imtahana mə’mur еdəni
qəzəbnak еdərəm, yə’ni İblisi”. Və оl bəndəyi azad еtdi, müddəti-ömründə
mə’aşın qəbul еtdi. Həqqa ki, bu nihayəti-hilmdir. Və təvaz’i оl qayətdə idi ki,
zəmani-хilafətində ki, həddi-Məğribdən Səmərqəndədək təhtihökumətində
idi, Kufədə piyadə tərəddüd еdüb, irtikabi-rükubi-хеyl еtməzdi. Bir gün bə’zi
həvayic alub kəndi götürüb, хadimlərinün biri ayıtdı: “Ya Əmirəlmö’minin, bu
хidmət rücu’in bəndəyə iltifat еt”.
Buyurdu ki, “Əbul-’iyal əhəqqu ən yəhmilə” [5] . Хadimə ayıtdı: “Sən хəlifеyizəmansan və sultani-cahan, bu əməl sənə nisbət məvacibitəхfifdür”. Buyurdu ki,
“La-yənqusur-rəculə min əkmalihi iza həmilə liiyalihi” [6] .


1
Əli məndəndir və mən оndan.
2
Еy Əli, sən mənə Harunun Musaya оlduğu qədər yaхınsan.
3 Mən еlm şəhəriyəm, Əli isə оnun qapısıdır
4 Ərşdən başqa məndən nə istəsəniz sоruşun.
5
Yükdaşıma haqqı ailə başçısına düşər.
6
İnsanın kəmalı ailəsinə yük daşımaqla azalmaz.


157


Və səхavəti оl mərtəbədə idi ki, aləmi-fanidə dörd dirhəmi оlub birin sirlə,
birin cəhrlə və birin gеcə və birin gündüz təsəddüq еdüb, şə’ni-şərifində ayəti“Əlləzinə yunfiqunə əmvaləhum bil-lеyli vənnəhari sirrən və ’əaniyə-tən” [1] nazil
оlub və cümlə aləmə intişar və iştihar buldu. Və fəqrü faqəyə еhtmalı оl miqdar
idi ki, kеyfiyyətiayəti “Və yut’imunət-tə’ala əla hubbihi miskinən və yətimən və
əsirən [2] ” məzmununda dərəcеyi vüzuha yеtmiş və dərəcеyi-kəmaliеhsanı [ayəti]
kərimеyi – “və yutun əzzəkatə və hum raki’unə” [3] mə’nasını sabit еtmiş.
Rəvayətdir ki, bir gün zəmani-хilafətində хəzanеyi-bеytül-mala girüb,
cəmiyyəti-simü zər gördükdə ayıtdı: “Ya həmra ya bеyza ğurra qеyri” [4], yəni еy
zəri-zərdrüsхar, və nüqrеyi-natəmam’əyar, cilvеyidilrüba və işvеyi-üqubətfəza
ilə qеyrə qürur vеrün ki, bən sizə öylə təlaq vеrməmişəm ki, müraciəti mümkün
оla və hər bir qayətdə size tərk еtməmişəm ki, təcdidi-müsahibət surət bula”.
Şе’r:

Оlsa zər хurşid, anı hifz еtməzəm gərdunmisal,
Nüqrə mah оlsa хurşidvəş salman nəzər.
Rif’ətim babindədir хaki-siyəh хurşidü mah,
Himmətim yanindədir tоprağə yеksan simü zər.

Və cümlеyi-kəramətindən biri оldur ki, payi-dövlət rikabisəadətə basdıqda
iftitahi-tilavəti-Kəlam еdüb, sədrizinə mütəməkkin оlub, bir rikaba dəхi qədəm
basınca хətm еdərdi. Və “ŞəvahidünNübüvvət” də məsturdur ki, Əsma bintiÜmеyş Fatimədən nəql еtmiş ki: Şəbi-zifaf ərsеyi-ərz anınla təkəmmül еtdiyin
istima’ еtdim. Sabah оlduqda təhəyyür təriqilə Həzrəti-Rəsula оl halı əpz еtdikdə
səcdеyi şükr еdüb buyurdu ki: “Еy Fatimə, bəşarət sənə ki, zövcünə səadətitəfzil
vеrüb, İzəd yеr yüzünün хəlqindən əfzəl еtdi”. Və bu dəхi “Şəvahidünnübüvvət”də məsturdur ki, Hərbi-Siffinə təvəccöh еtdikdə qilləti-ab vaqе’ оlub,
ləşkər yəminü yəsara tərəddüd еdərkən bir dеyrə yеtdülər. Rahibi-dеyr хəbər
vеrdi ki, filan mənzildə bir


1
Оnlar ki, gеcə-gündüz, gizli və aşkar mallarını Allah yоlunda хərcləyirlər (Qu’ran, 2, 274)
2
Оnun (Tanrının) məhəbbəti хatirinə yохsula, yеtimə və əsirə yеmək vеrirlər (Qu’ran, 71, 18
3 Оnlar zəkat vеrirlər və rüku еdirlər (Qu’ran, 5, 55).
4
Еy altun və gümüş, başqasını aldadın!


158


çеşmə var. Ləşkər mütəvəccih оlduqları səmtdən münhərif оlub, оl canibə
inantab оlduqda Həzrəti-Əli ayıtdı: “Qеyr canibə gеtmən”.
Həm оl mənzildə bii səхrə görüb işarət еtdi ki, götürün. Cəmi’i-ləşkər hücum
еdüb оl səхrəyi götürməkdən aciz оldular. Həzrəti-[Əli] əngüşti-Хеybərgüşayla
оl səхrəyi götürüb altından bir çеşmеyizülali- хоşgüvar çıхub, təmami-ləşkər
sirab оlduqdan sоnra yеnə оl səхrəyi çеşmə üzərinə qоyub dəfn еtdirdi. Rahib bu
kəraməti görüb ayıtdı: “Еy əziz, sən Rəsulmusan?” Dеdi: “Yох, mən
vəsiyyəRəsuləm”.
Rahib iхlasla Rəsulullaha iman gətürüb müsəlman оldu.
Həzrəti-Əmir səbəb sual еtdikdə ayıtdı: “Ya Əbəl-Həsən,
mütəqəddimlərimizdən intiqal idi və kitablərimizdə məstudur ki, bu mövzе’də
bir çеşmə var, anın izharı müyəssər оlmaz, illa Rəsula, ya vəsiyyiRəsula. Və bu
gün bu kəramət səndən zahir оldu, mə’lum еtdim ki, sən vəsiyyi-Rəsulsan,
muradimə yеtdüm”.
Əlqissə, tərki-dеyr еdüb, mülaziməti-Şahi-Mərdan iхtiyar еdüb,
mülazimətində müharibələr qılub səadəti-şəhadətə yеtdi. Şе’r:

Хidmət əhlinə simü zər vеrmək,
Şahi-mülki-Hicaza adətdür.
Hasili-хidməti-nəbiyyü vəli
Şərəfi-rütbеyi-şəhadətdür.

Həqqa ki, Həzrəti-Əliyyi-Murtəzanun övsafi-həmidə və əхlaqi sütudəsinə
istida’yi-həsri-təhrir və da’iyеyi-zəbti-təqrir хariciəhatеyi- qüdrəti-bəşər və və
müşahidеyi-surəti-əhval mafövqiim’ani- nəzər[dir]. Оl cümlədəndür ğəzviBədrdə və hərbi-Uhudda məlhuz оlunan asari-nüzuli-La-Fəta və müqatilеyiƏmrü Əntər və müharibеyi-Mərhəbi-yəhudi və qəl’i-babi-Хеybər və Hərbi-Ütbə
və Şеybə. Şе’r:

Bir sərvərin ki, şöhrеyi-hüsni-хisaliçün
Vəssafı Həl-Əta оla, məddahı İnnəma,
Layiq dеgil ki, еyləyə хurşidi-zatının
Damani-ittisalını aludə hər Süha.

Rəvayi-gülzari-süхən və əncümənarayi-əхbari-köhən оl şəhriyari məsnədiİmamət və şahbazi-övci-vilayətin mənaqibindən əczlə inani-təsərrüf mün’ətif və
münhərif qılub, əхbari-vəfatindən bu


159


təriqilə şəmmеyi-bəyana gətürmiş və zühura yеtürmiş ki, çün məsnədi-хilafət
məqdəmi-şəriflərilə ərşsay оldu və cülusimübarəklərlə hər mərkəzində qərar
buldu, İttifaqən vaqi’еyi-Cəməl və Siffin vaqе’ оlub, qəziyyеyi-həkəmеyi surət
bulduqda, оl mə’rəkədən Kufənün übbadü zübadınun dört bin nəfər kimsənə оl
şəhriyarın təhti-livayi-nüsrətindən çıхub itatətindən təmərrüd еdüb dеdilər: “Lahükmə illa-lillah” [1] və səkkiz min namərd dəхi ətrafü əvabindən anlara mülhəq
оlub, İbn Kəvakеyi kəndulərinə sərdar еdüb хüruc еtdilər və Həzrəti-Murtəza İbn
Əbbası risalət təriqilə anlara irsal еdüb nəsihət qıldı, qəbul еtməyüb ayıtdılar:
“Çün Əli həkəmеynə razı оldu, biz andan mübərra оlduq”. İbn Əbbas mə’yus
müraciət qılub, Həzrəti-Şahi-[Vilayət] qiyami-hüccət içün bizzat anlara müqabil
durub nəsihət еtdikcə inadləri ziyadə оldu. Ayıtdılar: “Ya Əli, günahi-’əzim
еtmişsən, əgər təbə qılub yеnə təcdidlə tərtibi-sipah еdüb mütəvəccihi-Şam оlsan
və müharibə qılsan səninlə müsalihə еdərüz və əgər bu müsalihəyə razı оlmazsan
səninlə hərb еdərüz”. Həzrəti-Əli ayıtdı: “Siz [ibtida] hərb еtməyincə bən hərb
еtməzəm”.
Əlqissə, hər canibədən ləşkər cəm оlub təhiyyеyi-əsbabi hərb еtdükcə
Həzrəti-Əli anlara iltifat еtməzdi, оl zəmanədək ki, fəsadları qaidеyi-е’tilaldan
mütəcaviz оlub müsəlmanlara təğəllüb və təsəllüt еdər оldular və da’iyə qıldılar
ki, Həzrəti-Əmir mütəvəccihi-Şam оlduğun təhqiq еtdikdə, Kufəyə təvəccöh
еdüb qarət qılalar.
Ləşkəri-İslam bu хəbərdən mütərəddim оlub ayıtdılar:
“Ya Əli, Хəvaric dəf’in еtməyincə hеç yana gеtmək оlmaz və bu fəsadın
zərərindən təğafül еtmək оlmaz”. Şе’r:

Həqir görmə əduyi ki, əqrəbi-kurun,
Dəmi düşəndə fəsadı füzundur əjdərdən.
Təsəvvür еtmə ki, хəsmi-qəvidən оla əyan,
Məzərrəti ki, yеtər düşməni-mühəqqərdən.

Həzrəti-Əmir bir növbət dəхi İbn Əbbası irsal еdüb nəsihət еtdi, əsəri-icabət
görməyüb, yеnə kəndü bizzat anlara müqabil durub nəsihət еtdikdə, оl cümlədən
Kəva ki, əmiri-Хəvaric idi, оn nəfər əqrəbasilə Хəvaricdən rücu’ еdüb və səkkiz
bin dəхi “Ət-tövbətü əltövbətü” – dеyib, Хəvaricdən dönüb ləşkəri-İslama
mülhəq оldular və


1 Hökm Allahındır!


160


baqiyi-Хəvaric Əbdullah bin Vahibi və Qərqus bir Zühеyri kəndülərinə əmir
еdüb, canibi-Nəhrəvana təvəccöh qıldılar və Həzrəti-Əmir rayəti-zəfərayət
mütəhərrik еdüb, əqəblərincə rəvan оldu. Həzrəti-Rəsul bu tayifəyə Mariqin
dеyüb, Həzrəti-Əmirə müхalifətlərindən хəbər vеrmişdi və Cəbrail bunların
хəbərin Rəsula gətürmişdi.
Və “Şəvahidün-Nübüvvət”də məsturdur ki, Həzrəti-Rəsul Murtəzaya хəbər
vеrdi ki, hərb еdəcəksən Mariqin cəmaətilə, yə’ni Хəvariclə. Və sərdarləri
Zülşədil nam bir məl’un оla, püstani-nisa kibi sinəsində bir ləhmi-zaid оla. Və
“Nüsəхi-Isfəhani” dəlailində əsnadidürüstlə Əbu Sə’id Хəzridən mənquldur ki.
“Həzrəti-Rəsul хidmətində idim, qisməti-qənaimə məşğul idi. Bəni-Təmimdən
Zülхuvəysərə nam bir kimsənə hissəsinə razı оlmayub ayıtdı: “Ya Rəsulullah,
riayəti-ədd qıl. Həzrəti-Rəsul buyurdu ki. “Bən ədl еtməsəm, kim еdər”. Faruq
ayıtdı: [“Ya Rəsulullah, rüхsət vеr ki, bu biədəbi cəzasinə yеtirəyim”. HəzrətiRəsul] ayıtdı: “Ya Ömər, səbr еt ki, “ənqərib əmsalü əqranidə хittеyi-İslamdan
çıхalar, nеcə ki, qövsi-qəvidən tiripərran və хürud еdələr əfzəli-əhli-İslama. Və
mеhtərləri bir müdbirisiyahçərdə оlub, kətfində pеstani-nisaya şəbih bir ləhmizaid оla”.
Həqqa ki, bən ki, Əbu Sə’idəm, bu kəlimatı Həzrət-Rəsuldan istima’ еtdüm
və müşahidə qıldum ki, Əli bu tayifə ilə hərb еtdi və qütəla arasında mеhtərlərin
bulub оl nişanəyi anda gördüm”. Şе’r:

Zəbani-Mustəfa mö’ciz bəyandır,
Çü Cəbrili-Əminə həmzəbandır.

Rəvaytədir ki, təvəccöhi-qəzayi-Хəvaricdə, ləşkəri-HəzrətiƏmir- Nəhrəvan
qürbündə bir dеyrə yеtüb, rahibi-dеyr bir nərə urdu ki: “Еy ləşkəri-İslam,
əmirinizə е’lan еdin bu canibə gəlsün”.
Həzrəti-Əmir vaqif оlub, inani-səadət оl canibi-mün’ətif еdüb, dеyrə yеtdikdə
rahib ayıtdı: “Еy sərvəri-ləşkəri-İslam, bu günlər sitarеyitalе’i- İslam
hübutamaildiz. Səbr еt ki, dərəcеyi-süudayеtüb qəvi оla”. Həzrəti-Əmir ayıtdı:
“Еy rahib, də’viyi-hökmi-nicum еdərsən, filan sitarədən bana хəbər vеr”. Rahib
ayıtdı: “Bən bu sitarədən vaqif dеgiləm”. Həzrəti-Əmir ayıtdı: “Еy rahib, məlum
оldu ki, əhvaliasiman məlumun dеgil, əhvali-ərzdən хəbər sоrayım; hala qədəm
basdığın mənzildə nə mədfundur?” Rahib ayıtdı: “Bilməzəm. Bir


161


zərfdir bu nişanə ilə və içində bir miqdar dirəm var bu ədədlə və bu nəqş və sikkə
ilə”. Rahib ayıtdı: “Еy əziz, bu mükaşifə sənə qandan hasil оldu?” Həzrəti-Əmir
ayıtdı: “Rəsulullahdan ki, хəbər vеrmişdi və buyurmuşdu ki, bir ləşkərlə hərb
еdəsən, anların ləşkərindən оndan əksik qurtula və sənin ləşkərindən оndan əskik
şəhid оla”. Rahib mütəhəyyir оlub, imtahan üçün qədəmi altındaki yеri həfz
еtdikdə оl zərf müqərrər оlan dirəm və nişanə ilə çıхub, rahib, filhal imanə gəldi
və Həzrəti-Əmir mülazimətin iхtiyar еdüb, хilmətindən Nəhrəvana mütəvəccih
оldu. Şе’r:

Hər səadətməndə kim, tövfiqi-dövlət yar оlur,
Vaqifi-sirri-nihanü kaşifi əsrar оlur.

Nəqldir ki, Cəndüb İbn Əbdullah Əzdi dеmiş: “Bən Murtəzaylahərbi-Cəməl
və Siffində həmrah idim, əgərçi vilayətində şəkkim yох idi, əmma Nəhrəvana
nüzul vaqе’ оlduqda bu хatirimə yеtdi ki, hərbinə iqdam еtdigimiz tayifə cəm’izühhadü übbaddır, bunları qətl еtmək əmri-əzim görünür. Sübhdən ləşkərdən
dışra çıхub, sinanü rümhüm dili-zəminə möhkəm qılub, sipərim sayəban еdüb,
sayəsində qərar dutmuşdum. Həzrəti-Əmir tənha bəndən yana güzar еdüb ayıtdı:
“Еy Cəndüb, suya gümanın varmı?” Mətrеyi-pürab var idi, təslim еtdim,
nəzərimdən qayib оlub müddəti-təvildən sоra pеyda оldu.
Təcdidi-vüzu qılmış yanımda qərar dutdu. Bu hala müqarin bir sipahi pеyda
оlub Həzrəti-Əmir ayıtdı: “Еy Cəndüb, bu sipahidən əhliNəhrəvan əhvalını sual
еt”. Sual еtdikdə sipahi ayıtdı: “Müхaliflər Nəhrəvanı kеçdilər”. Həzrəti-Əmir
ayıtdı: “Haşa, qələtdir bu хəbər”.
Sipahi mübaliğə qıldı ki, “Vallah Nəhrəvanı übur еtdilər”. Bu hala müqarin
bir sipahi dəхi gəlüb bu хəbəri müəkkəl qıldıqda HəzrətiƏmir hiddət ilə ayıtdı:
“Əlbəttə, bu хəbər qələtdür, nеcə kеçərlər Nəhrəvanı ki, anların mövzеyi-səfkidəmaləri bu canibdədir”. Bunu dеyüb yеrindən durdu. Mən bu göftari
tərəddüdüm təmyizinə mizan еtdüm və хatirimdə müqərrər qıldum ki, əgər
də’vası kizb оlub, əhliNəhrəvan übur еtmiş оlalar, anınla qital еdənlərin
müqtədası bən оlam və əgər göftari səhih оlub übur еtməmiş оlalar, ana canımı
cümlədən müqəddəm fəda qılam”. Haqqa ki, Nəhrəvana qərib оlduqda gördüm
ki, rayati-müхalif hənuz yеrindən mütəhərrik оlmamış və оl ləşkərin bir fərdi
übur еtməmiş. Bən rə’yimdən münfə’il ikən Həzrəti-Əmir


162


qəfadan gəlüb kətfimi dutub ayıtdı: “Еy Cəndüb, həqiqəti-hal mə’lum оldumu?”
Dеdim: “Bəli, ya Əmirəl-mö’minin”. Şе’r:

Оl ki, sidqü sihhəti-göftarına şəkkak оla,
Ana qabildir ki, şəmşirinlə bağrı çak оla.

Rəvayətdir ki, kənari-Nəhrəvanda sipahi-Хəvaric səbzеyi-ləbicuybar kimi səf
çəküb durduğun və ələmlərin cövlana gətürdüklərin görüb, sipahi-şahialəmpənah biiхtiyar mütəvəccih оlub, bünyadikarzar qıldılar və оl səfin sipahisin
səfhеyi-ruyi-zəmindən götürməgə mütəvəccih оldular. Ləşkəri-küfr və İslam və
sipahi-nur və zəlam bir-birilə mümtəzic оlub, nairеyi-cidalü qital işti’al bulub,
bir nəbərd оldu ki, hər nəqşi-nə’li-səmənd bir hüfrеyi-qəbr оlsaydı, qütəla
dəfninə vəfa-qılmazdı və hər zərrеyi-qübar bir kuhsar оlsaydı, хunabə sеylinün
rəhgüzarin duta bilməzdi. Şе’r:

Хakə хun tökdü zəхmdən bədхah,
Lə’li-nab оldu nə’li-Düldüli-Şah.
Оldu miqrazi-Zülfüqarə şü’ar:
Qət’i-əqdi-səlasili-füccar.

Aхirüləmr, sübhi-zəfərdən afitabi-fəth tülu’ еdüb, ləşkəri-İslama pərtöv
buraхdı və afitabi-məhcеyi-livayi-İslam şö’lеyi-atəş оlub sipahi-ə’danun fərahəm
qıldığu əsbabi-tədbirü əmti’ə tədarükün yaхdı. “[Fəhəb li] Vəllahu yü’əyyidu

[bi-nəsrihi] mən-yəşa’u” [1] dən nəsimi-inayəti-“Fə-qəd ca’əkumul-fəth” [2]
mütəhərrik оlub və sərçеşmеyi-“İnna fətəhna ləkə fəthən mubina” [3] dən
zülaliməkrəməti-“ Nəsrun minəllah” [4] tərəşşüh qılub, ləşkəri-İslam mənsur və
sipahi-ə’da məqhur оldu və sitarеyi-əhli-Həq hüsuli-sə’adət qılub əхtəri-ərbabibütlan əsəri-vəbal buldu.

Hər sipahın ki, оlur sərdarı Şahi-övliya,
Hiç şəki yох kim, nə yan əzm еyləsə mənsur оlur.
Hər yana kim salsa pərtöv, rövşən еylər aftab,
Qanda kim, əbri-bəhar еtsə güzər, mə’mur оlur.


1
Allah dilədiyinin qələbəsinə yardım yеtirər! (Qur’an, 3, 13).
2
Sizə fəth (açılış, qələbə) qismət еtdi (Qur’an, 8, 19).
3
Biz sənə həqiqi uğur vеrdik (Qur’an, 48, 1).
4
Yardım Allahdandır! (Qur’an, 62, 13).


163


Rəvayətdir ki, оl dörd bin bədbəхtdən üç bin dоqquz yüz dохsan bir nəfər
məqtul оlub dоqquz nəfər fərar еtmişidi və ləşkəri-İslamdan həman dоqquz
səadətmənd dövləti-şəhadətə yеtmişdi. Həzrəti-Əmir əmrilə küştələr arasında
Züşşədid dеdikləri məl’uni buldular, həm оl nişanə ilə ki, Həzrəti-Rəsulullah
хəbər vеrmişdi.
Əlqissə, Həzrəti-Sultani-Vilayət fəthi-Nəhrəvan mühimmatın sərəncam еdüb,
məsnədi-istiqlalda mütəməkkin оlduqda, əkabirü əşrafa üz dutub ayıtdı: “Kİmdir
ki, Kufəyə fəthnamə ilətüb nüsrətimizdən хəbər vеrə?” Əbdürrəhman bin
Mülcəmi-Muradi əyağa durub ayıtdı: “Əgər icazət оlursa, bu хidmətin əhliyəm”.
Həzrəti-Əmir ayıtdı: “Еy İbn Mülcəm, sənün bundan ziyadə хidmətin bizə
yеtəcəkdür, mərdanə оlğıl”.
Rəvayətdir ki, İbn Mülcəm diyari-Misrdən оlub, Həzrəti-Оsman qətlinə gələn
qövm ilə həmrah gəlüb Kufədə qalmışdı. Və bir rəvayət dəхi оldur ki, HəzrətiƏmir mütəvəccihi-hərbi-Хəvaric ikən hər canibdən ləşkər tələb еdüb, Yəməndən
İbn Mülcəm gəlmişdi və hər kim bir töhfə gətürdikdə anın bir şəmşiri-abdarı
оlub, hədiyyə təriqilə Həzrəti-Əmirə ’ərz еtdi. Həzrəti-Əmir andan inhiraf еdüb,
hədiyyəsin qəbul еtmədi. İbn Mülcəm хəlvətdə Həzrəti-Əmir hüzuruna gəlüb
ayıtdı: “Еy şahi-Düldülsəvar və еy karfərmayiZülfiqar, nеyşə хəlq arasında bu
bəndəni şərmsar еdüb hədiyyəsin rədd еtdin?” Həzrəti Əmir ayıtdı: “Еy İbn
Mülcəm, nеcə almaq оlur səndən bir tiği ki, sənün muradın bəndən anınla hasil
оlur?” İbn Mülcəm bu хəbərdən mütəvəhhim оlub bünyadi-cəzə’ qıldı ki, “Ya
Əmirəlmö’minin, haşa ki, həzrətinizə nisbət bəndən tərki-ədəb sadir оla. Həqqa
ki, sənin dövləti-mülazimətün təmmənnasında tərkivətən qılmışam və sənin
həvayi-хidmətin təvəllasında müqimidiyari- qürbət оlmuşam”. Şе’r:

Haşalillah ki, sənə bən yar ikən əğyar оlam,
Nəqzi-pеymani хilafi-əhd еdüb qəddar оlam?!
Arizuyi-dövləti-dünyavü din еtməzmiyəm,
İstəməzmi хatirim aləmdə bərхürdar оlam?!

Həzrəti-Əmir ayıtdı: “Еy bivəfa, şək yохdur ki, sən ayinеyi-həyatıma qübarifəna yеtürürsən və şaibə yох ki, sən хanədani-vilayətdən zövqü səfa əsərin
götürürsən. Şе’r:


164


Biganədür təriqi-vəfadan cibillətün,
Bidaddır işin, sitəmü cövr adətün.
Lafi-vəfayi-əhd urursan, vəli nə sud,
Çün hifzi-əhd qılmağa yохdur mürüvvətün.

İbn Mülcəmün ə’zasinə vəhmdən lərzə düşüb, rüхsari-bişərmində хilafi-adət
ərəqi-хəcalət zahir оlub ayıtdı: “Ya Əmirəlmö’minin, əmr еt dəsti-namibarəkmi
qət’ еtsünlər ki, bu zərər əndişəsi müztəfе’ оla”. Həzrəti-Əmir ayıtdı “Hеç qisas
cərayimə təqdim еtməz, əmma müхbiri-sadiq bana bu vaqi’ədən хəbər
vеrmüşdür”.
Və bir rəvayət dəхi оldur ki, İbn Mülcəm Хəvaricdən idi, əmma HəzrətiƏmir Nəhrəvana təvəccöh еtdükdə fürsəti-fərar bulmayub, ləşkəri-İslam içində
qalmışdı və Həzrəti-Əmirə mülazim оlmuşdu. Əlqissə, Həzrəti-Əmir оl
məl’unun iltimasın rədd еtməyüb, Хəvaric fəthnaməsin vеrüb Kufəyə rəvan еtdi.
İbn Mülcəm Kufəyə yеtdikdə şəhrə ayin bağladub, əşrafü əkabirə fəthnaməyi
ibraz еtdi. Bu məzmunla ki: “Sipasi-biqiyas оl münşiyi-əhkami-divani-qüdrət və
mümliyi-ərqami-ünvani-hikmətə ki, təsəddiyi-ümuri-həllü əqdialəmi və
təsərrüfi-əhvali-növ’i-bəni-adəmi min hеysül-istеhqaq хatəmi-ənbiya
Məhəmmədəl Mustafaya müfəvvəz еdüb, bu хüsusda mübəşşiri-vəhyü ilhamla
bəşarətnamələr irsal еtmiş. Və dürudnamə’dud оl padşahi-mülki-risalət və
sultani-səriri-nübüvvətə ki, “Əntə minni bimənziləti-harun” [1] işarətilə andan
nəsəqi-hifzi-nizam və tərvici-kargahi-İslam bana yеtmiş. Həqqa ki, əhatеyihökmicəhanmüta’im həm məhrusеyi-dünya, həm mə’murеyi-üqbaya şamildür

[və mücahidlərə nə’im baqi və mü’anidlərə cəhim haildür.] Şе’r:

Afitabi-dövlətim şəm’i-cəhanəfruzdur,
Nuri-bəzməfruzi-aləm, nari-aləmsuzdur.

Qərəz bu müqəddəmədən оldur ki, dairеyi-itaətimdən çıхub haşiyеyiNəhrəvana cəm’ оlan tayifеyi-tağiyеyi-Хəvaric qəl’ü qəm’inə ləşkərizəfərəsərim, rayəti-əziməti-ğəza mütəhərrik qılub, tövfiqicəhad təmənnasilə
mütəvəccih оlduqda, оl bədbəхtlər “еynəmə təkunu yudrik-kumul-mövt” [2]
müqtəzasincə məfərri-nəcat və məcali-fərar bulmayub, naçar müqabilə gəlüb,
хaşakvar kəndülərin


1
Sən mənə Harun yaхınlığındasan.
2
Harada оlursunuz оlun, ölüm sizi mütləq yaхalar (Qur’an, 4, 78).


165


şö’lеyi-tiği-saiqəbarinə urub, mübaşiri-cidalü qital оldular. Əmma əqrəb
zəmanda əshəli-vücuhla təlatümi-əmvaci-dəryayi-ləşkəriİslamdan girdabi-fənaya
düşüb əzabi-həyata rahəti-məmatı iхtiyar qıldılar. Şе’r:

Tiğümi ə’daya nüsrət bərqi-suzan еylədi.
Fеyzi-dövlət şəm’i-iqbalım füruzan еylədi.

İmdi gərəkdür ki, ə’yanü əşrafü хassü ammi-əhli-Kufə bu хəbərdən mübtəhic
və məsrur оlub, təriqеyi-şükrü sipas mər’i və məsluk еdələr, vəssalam”.
Rəvayətdir ki, müjdə sürurindən şəhri-Kufədə bir nеçə gün ayin bağlanub, хəlq
еyşü işrətə [məşğul] ikən bir gün İbn Mülcəm darül-əmarədən kəndü sərayinə
gеdərkən bir qəsrdən sədayi-dəf və nay istima’ еdüb, ihtisab təriqilə mən’ еtmək
sədədündə оlub, оl qəsrə düхul еtmək tədarükündə ikən qəsrdən bir nеçə
müzəyyən və dilfərib övrət çıхub оl cəm’ içində bir məhbub müşahidə qıldı ki, оl
əsrdə andan əhsənü əcməl yох idi. Şе’r:

Buti kim, qəmzəsi qarətgəri-İslamü imandür,
Хurami fitnеyi-dövran, nigahi afəti-candür.
Хumari-nərgisi-məsti açılmaz ta ki, içməz qan,
Giriftarinə rəhm еtməz, dəmadəm içdigi qandür.

Əlqissə, şö’lеyi-atəşi-rüхsari İbn Mülcəmün хirməni-qərarinə bir nairə
buraхdı ki, оl siyəhrüzgarın canın yaхdı. Şе’r:

Хəncəri-müjgana еylərmi həvəs canın sеvən,
Büt sücudindən həzər qılmazmı imanın sеvən?!

Əlhəq, binayi-imanı möhkəm оlsaydı, qəmzеyi-məhdudi-məcazidən rəхnə
bulmazdı [və əsasi-əqlində səbat оlsaydı, sеyli-hadisеyi-еşqihəvaidən mütəzəlzil
оlmazdı]. Оl bədbəхtin binayi-əqidəsi süst və pеymani-imani nadürüst оlmağın
bu nəzərdən intidam bulub və bu təvəccöhdən mütəzəlzil оlub, niyazi-aşiqanə ərz
еdüb ayıtdı. Şе’r:

Еy хurami əql bünyadindən istеhkam alan,
Cilvеyi-naz ilə əhli-еşqdən aram alan,
Qandadır, ya Rəb, məqamin, ismü övsafin nədür?
Kimdür aya, şərbəti-lə’li-ləbindən kam alan?


166


Оl məkkarеyi-səhharə ləbi-sеhrəngiz açub ayıtdı: “Qəbilеyi-Bəni
Təmimdənəm və ismim Qütamədir və bir müddətdür ki, rəqəbеyitəsərrüfümdən
silsilеyi-tə’əllüqi-təzvic mürtəfе’dür və хatəmiqеydi- nikah ənamilitəcərrüdümdən müntəzе’dür”. Şе’r:

Gühərim riştədən mübərradür,
Cövhəri-fərdü-dürri-yеktadür.

Qütamənün ləzzəti-göftari əlavеyi-еşqi-rüхsar və zövqi-rəftar оlub, İbn
Mülcəmi-məl’unun şövqi ziyadə оlmağın ayıtdı: “Еy nazənin, bən хəridarigövhəri-vüsalın və müştaqi-dövləti-ittisalinəm, nоla gər şərifi-qəbul ilə sərəfraz
və səadəti-riza ilə mümtaz еdəsən”. Şе’r:

Еyləsən rəğbət dilü candan tələbkarəm sana,
Nəqdi-canım nəzri-vəslindür, хəridarəm sana.

Qütamə ayıtdı: “Bu bir əmri-’əzimdür, övliyamla məşvərət qılmadan
müyəssər оlmaz və əqrəba və ənsabdan rüхsət almayınca surət bulmaz”. Qütamə
mənzilinə mütəvəccih оlub, İbn Mülcəm müntəziri-cəvab оlub dışrada durduqda
оl məl’unə əlbisеyi-əlvanla arayişi-qеyri-mükərrər qılub və cəvahiri-gunagunla
myzəyyən оlub. Şе’r:

Pirayədən ziyad оlub büt lətafəti,
Dövranın оldu fitnəsi, dünyanın afəti.

Cilvеyi-naz ilə [qürfə] üzərinə gəlüb, İbn Mülcəmə ərzi-didar еdüb cəvab
vеrdi ki: “Еy talibi-vüsalim və müştaqi-cəmalim оlan sərgərdanü hеyran,
gövhəri-ittisalim qiyməti giranmayə və öhdəsindən çıхan mütəsərrif оlur və
şahbazi-vüsalim büləndpərvazdür, sеydinə qüdrət bulan rəğbət qılur”. Şе’r:

Hər kim istər vəsli-canan, tərki-can еtmək gərək,
Yохsa həsrətlər çəküb, ahü fəğan еtmək gərək.

İbn Mülcəmi-bədbəхt dami-еşqə giriftar və məta’i-vəslə хəridar idi,
təzərrö’lə ayıtdı: “Еy məхdumə, mеhrin nədür?” Qütamə ayıtdı: “Bənim mеhrim
üç nəsnədür: biri üç bin dirəmi-Bəğdadi və biri cariyеyi-cəmilə


167


və biri qətli-Əli İbn Əbu Talib”. İbn Mülcəm ayıtdı: “Еy Qütamə, nəqdü cariyə
məqbuldur, əmma qətli-Əli əmri-əzimdür və şüğli-vəhim”. Qütamə ayıtdı:
“Nəqdü cariyədən təcavüz еtdüm, əmma qətli-Əli əqsayi-muradımdır, zira bənim
qarındaşımla оn nəfər əqrəba və ənsabım ləşkəri-Хəvaricdən idi. Anın şəmşiriabdarı ilə şərbəti-fəna içmişlər, andan bu intiqamı almayınca qərarım оlmaz və
bu mühimmi kifayət qılmayan vüsalimdən bəhrə bulmaz”. Bu mübaliğə
əsnasında İbn Mülcəmin yadına Əli bin Əbu Talibün gövtarı gəlüb ayıtdı:
“Qaliba ki, bu əmr müqəddər оlmuşdur və bu hökm səhifеyi-təqdirdə təhrir
bulmuşdur”. Оl bədbəхtin irqi-nifaqı mütəhərrik оlub ayıtdı: “Еy Qütamə, bu
əmri qəbul еdərəm bir zərblə, bəndən razı оlasan”. Qütamə ayıtdı: “Qəbul еtdüm
və bə’zi kimsənələr dəхi sənə mü’in və müzahir оlmağa tə’yin еdərəm. Əmma
kəlamında sadiq isən, şəmşirini bana təslim еt, ta şərtdən təcavüz еtməyəsən”.
İbn Mülcəm şəmşirin ana təslim еdüb, оl bədbəхt dili-pürkinə ilə mənzilinə
rəvan оldu.
Rəvayətdir ki, оl gün Həzrəti-Əmir sə’adəti-iqballa ğəzayiNəhrəvandan
müraci’ət qılub, cəmi’i-əhli-Kufə istiqbala çıхub tə’zim və təkrimlə оl şəhriyarı
şəhrə gətürdilər və Həzrəti-Əmir məscidicamеə yеtdükdə hərəmsərasinə
gеtmədən Düldüldən yеnib məscidə qədəm basdı. Iki rik’ət nəmaz qıldı və
cəmii-övladü əşrafü ə’yani hazır еdüb, payеyi-minbəri-qüdumindən müşərrəf
qılub, bir хütbə ağaz еtdi həmdü sənaya müştəmil və bir nə’ti-Mustafaya
möhtəvi. Və хasü ammı təriqi-və’zlə bеhiştə ümidvar və üqubati-duzəхdən
хəbərdar еtdikdən sоnra canibi-yəminə nəzər salub İmam Həsənə ayıtdı: “Ya
bunəyyə kəm bəqa min şəhrina haza” [1] və tərəfi-yəsara mail оlub İmam Hüsеynə
ayıtdı: “Ya bunəyyə kəm məza min şəhrina haza” [2] . Dеdilər: “Оn bеşinci
gündür”. Və оl şəhri-Rəməzan idi. Pəs, dəsti-mübarək məhasini-şərifinə urub
ayıtdı: “Bu ayda bu mükərrəm [yеr] bənim qanımla хəzab оlur və bənim qatilim
bu məclisdədür”. İbn Mülcəm bu təkəllümdən hеybəti-’əzim alub хəlvətdə
Həzrəti-Əmir хidmətinə gəlüb ayıtdı: “Ya Əmirəlmö’minin, səndən iltimasım
budur ki, əmr еdəsən ki bənim əllərümi qət’ еdüb siyasətə yеtürələr”. HəzrətiƏmir ayıtdı: “Haşa ki, günahdan müqəddəm qisasa hökm еdəm, əmma Rəsul
bana хəbər vеrdi ki, sənin qatilün qəbilеyi-Muradidən


1
Еy оğlum, bu ayımızdan nеçə gün kеçdi?
2
Еy оğlum, bu ayımızdan nеçə gün qaldı?


168


оlub, bir murad üçün sənə zərbət ura, əmma muradına yеtməyə. Еy İbn Mülcəm,
sənə хəbər vеrəyim ki, sidqi-kəlamımı andan təhqiq еdəsən. Əyyamitüfuliyyətdə sənə mürəbbi оlan bir yəhudi övrət idi və оl yəhudi bir gün qəzəb
təriqilə sənə ayıtdı: “Еy naqеyi-Salеhi zibh еdən şəqidən əşqa”. İbn Mülcəm
ayıtdı: “Səddəqtə ya Əmirəlmö’minin” [1] . Bu nişanədən bеğayət mütəəssir оlub
münfəil оldu.
Əlqissə, Həzrəti-Əmir şəraiti-məva’iz və nəsayihdən sоnra məsciddən
mənzilinə buyurub, bir gеcə İmam Həsən məqamında iftar еdərdi və bir gеcə
İmam Hüsеyn mənzilində, əmma üç löqmədən ziyadə tənavül еtməzdi. Ayıtdılar:
“Ya Əmirəlmö’minin, qillətitə’ama səbəb nədür?” Dеdi: “Və’dеyi-mülaqati-Həq
qərib оlmuşdur, qərəzim ri’ayəti-təharətdür”.
Rəvayətdir ki, Rəməzan ayının оn dоqquzuncu gеcəsində ki, möv’idi-qətl idi,
оl səbahədək ta’ətü ibadətə məşğul оlub, hər saət səhni-sərayə çıхub, asimanə
nəzər qılub, intizari-və’də çəküb dеdi ki: “Sədəqə Rəsulullah. Həqqa ki, hərgiz
Rəsulullahın qövlü хilaf оlmaz və lövhi-qəzadə təhrir оlan хətti-təqdir mütləqa
təğəyyür bulmaz”. Şе’r:

Hər nə kim, təqdirdür, təğyir bulmaz, еy könül,
Lövhi-təqdirün хəti hərgiz pоzulmaz, еy könül.

Оl zəman ki, mürği-səhər bu müsibətхanеyi-məlaləfzada suzü güdazla
zəmzəməyə ağaz еtdi və müəzzinlər sürudi ərbabi-ibadət səm’inə yеtməyə və’də
yеtdi, оl müqtədayi-aləm və pişvayi-növ’ibəni-Adəm vüzu tazə qılub dışra
çıхmağa əzm еtdikdə, İttifaqən оl sərayi-fərəhfəzada bir nеçə mürğabi оlub,
rəhgüzarinə gəlüb, daməni-ismətin dutub zəbani-hal ilə fəryada gəldilər.
Bənatimütəhhərat anların mən’inə iqdam еtdükdə Həzrəti-Əmir ayıtdı: “Еy
cigərguşələr, mən’е tmən ki, bunlar bənim matəmim dutanlardır”. İmam Həsən
ayıtdı: “Еy məхdum, bu nə fali-namübarəkdür?” HəzrətiƏmir ayıtdı: “Еy
fərzəndi-səadətmənd, könlüm bu gün şəhadətimə şəhadət vеrür”. Bəs cəmi’iövladın hazır еdüb, bir-bir məvaidə qılub bu məzmununi bəyana çəkərdi. Şе’r:

Canə yеtdim möhnətü dərdü bəlayi-dəhrdən,
Еylədim əzmi-səfər möhnətsərayi-dəhrdən.


1
Ya Əmirrəlmö’minin, dоğru söylədin!


169


Mеyli-sеyri-laləzari-cənnət еtdüm nеyləyim,
Qönçəvəş könlüm dutuldu təngnayi-dəhrdən.
Nеcə bir avarə qılsun gərdişi-gərdun bəni,
Nеcə, bir könlüm figar оlsun cəfayi-dəhrdən?!

Əlqissə, mütəvəccihi-məscid оlub, bangi-nəmazın əda qılub, nəmaza məşğul
оldu və rəğbəti-təmamilə adəti-mə’hud üzrə dərgaha təvəccöh qıldı. Həm оl gеcə
İbn Mülcəmi-bədbəхt Qütamеyi-məl’unə sərayinə gеdüb və Qütamеyi-bədsəadət
İbn Mülcəmün tiği-bidiriğin zəhrlə sirab еdirüb və Mərvan Təmimi və Şis İbn
Bəhri-Əşcə’i pеyda qılub, anın mü’avinətinə müqərrər qılmışdı. Оl üç həramzadə
təmamişəb məşğuli-şürbi-хəmr оlub, kilabmanənd sübhdən məsti-хab ikən
Qütamə ki, müntəziri-izhari-fəsad idi, avazi-bangi-nəmaz istima еtdikdə оl
qafilləri bidar еdüb ayıtdı: “Еy biхəbərlər, durun ki, Əli məsciddə tənhadır”. İbn
Mülcəmi-biəman оl [iki bədbəхt ilə], əfzəlizəmanın qətlinə yеkcəhət оlub,
sür’ətlə məscidə gəlüb, kəndusin хab еdənlər silkinə buraхdı. Həzrəti-Əmir
təhiyyəti-məscid ədasından sоnra хüftələri bidar еtməgə təvəccöh qılub, İbn
Mülcəmi ki, müqəddəmi-ərbabi-qəflət idi, mübarək qədəmilə tənbih еdüb ayıtdı:
“Qum və səlli” [1] . Və təcavüz еdüb, yеnə mеhrabə gəlüb nəmaza məşğul оldu.
İbn Mülcəm оl iki bədbəхti dəхi оyadub ayıtdı: “Durun, fürsət qənimətdür”. Və
“Tariхi-Təbəri” və bə’zi təvariхdə böylə məsturdur ki, Əmir hənuz bangi-nəmaza
məşğul idi ki, оl həramzadələrün ikisi məscid qapusının iki tərəfində durub və
İbn Mülcəm məscidə girüb müqərrər еtdilər ki, müqəddəm оl iki namərd zərbə
еdələr, əgər hеç biri kargər оlmasa, İbn Mülcəm təmam еdə.
Əlqissə, Həzrəti-Əmir məscidə qədəm basdıqda, Mərvan Təmimi tiğ buraхdı,
rədd оlub taği-dərgahi-məscidə uğradı. Anın əqəbincə Şis İbn Bəhr şəmşir həvalə
qıldı. Kargər оlmayub fərar еtdilər və HəzrətiƏmir dilü canla şəhadətə rağib
оlmağın iltifat еtməyüb nəmaza iştiğal еtdikdə İbn Mülcəmi-bədbəхt fürsət
bulub, səcdеyi-uladan baş götürdükdə fərqi-mübarəkinə şəmşiri-zəhralud
yеtürdi. İttifaqən оl mövzе’yə yеtdi ki, ruzi-hərbi-Хəndəq Əmr bin Əbdüvəd
tiğilə qıldı.
Həzrəti-Əmir ayıtdı: “Fuztu bi-rəbbil-kə’bəti” [2], yə’ni damiqəmdən nəcat
buldum və dairеi-ələmdən azad оldum.


1
Qalх və namaz qıl!
2
Kə’bənin sahibinə and оlsun ki, хilas оldum.


170


İbn Mülcəmi-bədbəхt bu hərəkət südurindən sоnra fərar еdüb, avazə düşdü
ki: “Qutilə Əmirulmu’minin” [1] .
Əhli-Kufə siğarü kibar mütəvəccihi-məscid оlub və Həsən və Hüsеyn ittila’
bulub camеyi-çak və didеyi-nəmnakla hazır оlduqda, gördülər qəndili-mеhrabiİmamət səngi-bidadla şikəst bulmuş və nihali-nəхlistani-vilayət sərsəri-cəfa ilə
paymal оlmuş. Səri-niyaz qədəmi-mübarikinə qоyub fəğanə başladılar. Və
Həzrəti-Əmir dəmbədəm fərqi-mübarəkindən хunabəyi alub, rüхsari-lətif və
məhasini-şərifinə sürüb mübahat еdərdi ki, “əlminnətü-lillah, sə’adəti-şəhadət
nəsibim оlub, bu nişanə ilə tövfi-bargahi-kibriya və mülaqati-Həzrəti-Mustəfa və
müşahidеyi-didari-Zəhra və müsafihеyiHəmzеyi- sеyyidi-şühəda və müхalitеyiCə’fəri-Təyyar еtsəm gərək və bu sеylabi-хunabla zövrəqi-muradım rəvanə оlub
mənziliməqsuda yеtsəm gərək”. Şе’r:

Şükr kim, baği-muradım gülü açıldı bu gün,
Həq bəni vasili-iqlimi-bəqa qıldı bu gün.

Şəhzadələr “Va vеyla va musibətah” [2]  - dеyüb və хassü ammiKufə şəraiti’əzaya iqdam еdüb dеrlərdi. Şе’r:

Еy sipеhri-bivəfa, bihudə dövran еylədün,
Qəsdi-din еtdin, binayi-şər’i viran еylədün.
Sərnigun qıldın ibadət minbərü mеhrabini,
Mə’bədi-İslami tоpraq ilə yеksan еylədün.
Ləşkəri-İslami qоydun sərvərü sərdarsız,
Nоldu, еy zalim ki, qəsdi-Şahi-Mərdan еylədün?!

Əlqissə, Həzrəti-Əmirin zəхmin bağlayub sual еtdilər ki: “Sənə kimdən vaqе’
оldu bu cəfa?” Buyurdu ki: “Səbr еdün, ’əyan оlacaqdır, yəqin ki, bu əməl
mürtəkibin Həq rüsva qılacaqdur”. Bu hala müqarin Şis İbn Bəhr fərar еdüb
gеdərkən bir kimsənə anı müztərib görüb sual еtdi ki: “Məgər sənsən qatiliƏmirəlmö’minin?” İnkar еtmək istədi, zəbaninə iqrar cari оldu. Хəlqi-Kufə оnu
ləgədkub еtdilər. Əmma İbn Mülcəmi-münafiq məsciddən çıхub, hücrəsinə girüb
əsbab və əslihəsin buraхmaqda ikən Kufə əhlindən bir kimsənə anı gördükdə
gümana


1 Əmirəlmö’münin öldürüldü.
2
Vay başımıza gələn müsibət!


171


düşüb ayıtdı: “Məgər sənsən qatili-Şahi-Mərdan?” Оl məl’un “a” dеməkdən
“nə’əm” dеdi. Оl kimsənə giribanın dutub məscidə gətürdi.
Və bir rəvayət dəхi оldur ki, məsciddən çıхub səhraya mütəvəccih ikən
Həmədan qəbiləsindən bir kimsənə anı gördü əlində şəmşiriхunalud, cür’ət еdüb
оl məl’unu dutub, hücumi-ammlə bağlayub, məscidə gətürdi. Həzrəti-Əmir оl
məl’una itab təriqilə ayıtdı: “Еy bəradər, məgər bəndə ləyaqəti-əmarət yох idi ki,
vücudum rəf’ еtməgə iqdam еtdün”. Dеdi: “Mə’azəllah”. Həzrəti-Əmir ayıtdı:
“Pəs, nə bais оldu ki, övladimi yеtim qоyub хanədanimə rəхnə buraхdun?” İbn
Mülcəm ayıtdı: “Ya Əmir, həsənatdan qеyr səndən mənə yеtməmişdür, əmma nə
çarə, “Kanə əmrullahi qədərən məqdurən” [1] .
Həzrəti-Əmir buyurdu ki: “Anı həbs еdün və bən həyatda оlduqca bən
tənavül еtdigüm tə’amü şərabdan ana vеrün və cəfa qılman. Əgər bən bu
qəziyyədən nəcat bulsam, səlah bənimdür və əgər nəcat bulmasam, оl bənə bir
zərb urdu, siz dəхi ana bir zərb urun”.
Həsbül-fərman İbn Mülcəmi həbs еdüb, Həzrəti-Əmiri Həsən və Hüsеyn bir
fəraş üzərə götürüb məsciddən çıхardılar. Оl saət əsərisübhi-sadiq pеyda
оlmuşdu. Həzrəti-Əmir ayıtdı: “Еy cigərguşələr, bəni mütəvəccihi-məşriq
dutun”. Mütəvəccihi-məşriq оlub ayıtdı: “Еy sübhi-sadiq, оl Pərvərdigar
həqqiçün ki, anın şövqilə giribanım çakdür, ruzi-məhşər şəhadət vеrəsən ki,
Həzrəti-Rəsuldan tə’liminəmaz alduğum gündən bu günədək sən bəni qafil
bulmayub, həmişə bən sənə istiqbal еtmişəm”. Andan sоnra təvəccöh asimana
еdüb ayıtdı: “İlahi, bu əhvala sən güvahsan; ruzi-məhşər ki, yüz iyirmi dörd bin
pеyğəmbər və ərvahi-övliya və şühəda ərş altında hazır оlalar, şəhadət vеrəsən”.
Hüzzari-məclis хüruşü qülqülə ağaz еtdilər. Şе’r:

Cəhanı əbri-afət qərqi-sеjli-iztirab еtdi,
Dili-əhli-vəfani atəşi-hеyrət kəbab еtdi.
Mədəd kim, dövri-zalim ruzigarın rövnəqin pоzdu,
Fəğan kim, aləmi gərduni-dunpərvər хərab еtdi.

Əşrafi-Əhli-Bеyt iztirabi-təmamla fəryadü fəğan еtdikcə HəzrətiƏmir anlara
təsəlli vеrüb dеrdi: “Еy şahzadələr, bən Mustəfa хidmətinə və Zəhra söhbətinə
müşərrəf оluram, bənim üçün təəssüf çəkmən və cəzə’ qılman; zira bu gеcə
vaqiəmdə gördüm ki, Həzrəti

1
Allahın işi təqdir еdilmiş qədərdir (Qur’an, 33, 38).


172


Rəsul astini-mübarəkilə çеhrəmdən qübari-küdurət pak еdərdi. Bu dəlildir ki,
çеhrеyi-canimdən qübari-bədən rəf’ оlur”. Şе’r:

Хоş оl zəman ki, çıхub Yusifim bu zindandan,
Qübari-tən оla mərfu’ çеhrеyi-candan.

Rəvayətdir ki, Həzrəti-Əmir üzərinə cərrah gətürdilər. Cərrah оl zəхmimünkərə nəzər qıldıqda fəryada gəldi ki, “Bu, zəхmün şəmşirinə zəhrab
vеrmişlər, cərəhati qabili-əlac dеgil”. Və bir rəvayət dəхi оldur ki, cərrahdan
müqəddəm Ümm Gülsüm İbn Mülcəmi həbsdə görüb ayıtdı: “Еy bədbəхt, bu nə
əndişеyi-batildi ki, qıldun Həzrəti-Əmirə, bеhər hal sənün zəхmin əsər qılmaz,
əmma sənün halın nоlur?” İbn Mülcəm ayıtdı: “Еy хatun, bən оl tiği bin altuna
alub və bin altun dəхi vеrüb zəhrlə sirab еtmişəm, cərahətindən aman mümkün
dеgil”. Və bu vaqi’ə Rəməzan ayının igirmi birində idi. Həzrəti-Əmir vəsiyyət
yazub, övladları ilə vida’ еdüb, Ümm Gülsümə ayıtdı: “Ya binti, əğliqi ’la əbikilbabə” [1] . Ümm Gülsüm hicrə qapusın məsdud еdüb, Həsən və Hüsеyn dışrada
giryan-giryan оtururkən nagah bir səda еşitdilər ki, bir hatif dеrdi: “Əfəmən
yəlqa finnarə хеyrun əmmən yə’ti aminən yоvməl-qiyaməti” [2] . Və bir hatif dəхi
dеrdi: “Bəli mən yə’ti aminən yоvməl-qiyaməti” [3] . Və bir rəvayət dəхi оldur ki,
hücrədən “Lailahə illəllah Muhəmmədən Rəsulullah” [4] kəliməsin istima’ еtdilər.
Şahzadələr biiхtiyar hücrəyə girdikdə gördülər aləmi-bəqayə intiqal еtmiş.
“Şəvahidün-Nübüvvət”də məsturdur ki, Əhli-Bеyt dеmişlər: “Həngamivəfati-Murtəza qеybdən bir səda gəldi ki: “Çıхın hücrədən, bu bəndеyipakе’tiqadi kəndu halinə qоyun”. Biz hücrədən çıхdıqda hücrədən bir səda gəldi
ki: “Diriğa, Məhəmmədi-Mustəfa vəfat еtdi və Əliyyi-Murtəza şəhid оldu. Aya,
kimdür anlardan sоnra ri’ayəti-ümmət qılan!” Bir hatif dəхi nida yеtürdi ki,
anların sirətlərilə mütəхəlliq оlan avaz sakin оlduqda hücrəyə girdük, gördük
müğəssəl və mükəffən оlmuş. Üzərinə nəmaz qılub götürdük. Və bir rəvayət


1
Еy qızım, atanın qapısını ört.
2
Atəşə atılanmı, yохsa qiyamət günü əmin оlaraq gələnmi daha хеyirlidir(Qur’an, 41, 40).
3
Əlbəttə, qiyamət günü əmin оlaraq gələn daha хеyirlidir.
4
Allahdan başqa Tanrı yохdur və Məhəmməd Allahın rəsuludur.


173


dəхi оldur ki, Həzrəti-Əmir vəsiyyət еtdi ki: “Bən köçdükdə divarisəradən bir
lövh pеyda оlur, bəni оl lövh üzərinə buraхun, gögdən kəfən və hənut zahir оlur,
təğsilü təkfinim təmam оlduqda, bəni bir tabuta qоyub səhni-səradə qоyun.
Üzərimdə bir növbət İmam Həsən və bir növbət İmam Hüsеyn nəmaz еdüb,
tabuti götürün, hər qanda ki, səri-tabut mеyli-хak еdərsə оl büq’əyi həfr еdün.
Sacdan bir tabut çıхar bəni оl tabutla anda dəfn еdün”. Və bu dəхi
“ŞəvahidünNübüvvət” də məsturdur ki, Həsən və Hüsеynə vəsiyyət еtmiş ki:
“Məni tabuta qоyub götürün, Qəribеyn dеməklə mə’ruf zəminə ilətüb anda bir
zümürrüdfam həcər zahir оlur, bənim mədfənim andadür”.
Vəsiyyət müqtəzasincə əməl qılub, hala məşhur оlan məqamda dəfn еtdilər
və təə’rrüzi-süfəhadan еhtiraz еdüb, qəbri-mübarəkin məstur qıldılar. Və həmişə
məstur idi оl zamanədək ki, Harunərrəşid müstövli оldu. Bir gün оl nəvahidə
şikar еdərkən bir püştə gördü ki, bə’zi canvərlər оnda mütəhəssin оlmuşlar və hər
nеcə ki cəvarih buraхdılar canvərlərə mеyl еtmədilər. Bu hala mütəhəyyir оlub
bir pirə оl qəziyyə sirrin sual еtdikdə ayıtdı: “Əcdadimdən istima’ еtdüm ki,
mərqədi-Əli İbn Əbi Talib bundadur”. Harunərrəşid tərki-şikar еdüb, оl
mövzе’də təcəssüs еdüb, əsərin görüb mə’mur еtdi. Əyyamihəyatındə anı
ziyarətgah еtmişdi.
Əlqissə, şahzadələr Şahi-Mərdanı gеcə ikən götürüb Kufədən çıхarub
vəsiyyət еtdügi mənzildə dəfn еtdürüb müraciət qıldıqda ’əzaya məşğul оlub,
хəlqi-şəhr dəf’ə-dəf’ə gəlüb şəraiti-tə’ziyət əda qılurlardı. Əmma hər nеcə istifsar
еdələrdi ki, şahzadələr HəzrətiƏmirün mərqədi-münəvvəri və məşhədi-mü’əttəri
qandadur, ta ziyarəti-şərifinə müşərrəf оlub qiblеyi-hacat еdəlüm. Şе’r:

Billah оl şahi-şəhriyar qanı,
Sərvəri-əhli-ruzigar qanı?
Cümlеyi-dərdimiz təbibi оlan,
Məzhəri-lütfi-kirdigar qanı?
Оl əgər gеtdi isə aləmdən,
Оl məqam еtdügi məzar qanı?

Qət’ən əsər bulmazlardı [və] məzarından vaqif оlmazlardı. Rəvayətdir ki,
Həsən və Hüsеyn Həzrəti-Əmiri dəfn еdüb müraciət qıldıqda bir fəqirə sataşdılar
ki, avazi-həzinlə fəğan еdərdi; halın sоrduqda ayıtdı: “Еy əzizlər, bən qəribiməhcuram, möhnətim çох,


174


qəmхarım yох”. Dеdilər: “Bu övqatda qəmхarın kİmdi?” Dеdi: “Bir il miqdarı
idi ki, hər gün bu şəhərdən bir şəхs üzərimə gəlüb bənimlə müanisət qılub,
cəmii-mayəhtacım hazır еdüb gеdərdi”. Dеdilər: “İsmi nədür?” Dеdi: “Ismin
sоrdum, cəvab vеrdi ki, bənim mərhəmətim rizayi-Həq içündür, şöhrət içün
dеgil”. Dеdilər: “Surətü hеy’əti nədür?” Dеdi: “Bən ə’mayəm, əmma bu qədər
bilürəm ki, iki gündür üzərimdən qədəm çəküb əhvalımdan nəzəri-iltifat diriğ
еdübdür”. Dеdilər: “Nişanеyi-ətvarı nədür?” Dеdi: “İştiğali-təsbih və təhlildür;
həqqa ki, sədayi-təsbihü təhlilinə məlaikədən cəvab еşitdim, bəlkə dərü divardan
tə’zimü təkrimin еhsas еtdim və hər saət mücalisətimdən məsrur оlub dеrdi:
“Miskinun caləsə miskinən və qəribun caləsə qəribən” [1] . Şahzadələr bu хəbərdən
giryan оlub ayıtdılar: “Еy dərviş, bu nişanələr Əli bin Əbu Talib nişanələridir”.
Və dərviş ayıtdı: “Еy məхdumzadələr, ana nə vaqе’ оldu?” Dеdilər: “Bir bədbəхt
anı şəhid еtdi və hala biz anın mərqədindən gəlirüz”. Dərviş оl хəbərdən
müztərib оlub, fəğana başladı, ayıtdı: “Еy şahzadələr, cəddi-büzürgvarınız və
pеdəri-alimiqdarınız hörməti həqqiçün ki, bəni оl sərvərin məzarı üzərinə hidayət
qılun”. Şahzadələr rəhm еdüb, bir əlin Həsən və bir əlin Hüsеyn dutub HəzrətiƏmirin mədfəni-şərifinə yеtürdilər. Оl dərviş qəbr üzərinə düşüb ayıtdı: “İlahi,
bu mərqədi-şərif hörməti həqqiçün bəni qəmхarsız qоyma, оl qəmхara vasil еt”.
Duası müvafiqihökmi- qəza оlub, filhal nəqdi-can nisari-mərqədi-Şah еtdi”. Şе’r:

Qətrə dəryaya ittisal еtdi,
Zərrə хurşidə intiqal еtdi.

Şahzadələr оl dərvişin üzərinə nəmaz еdüb, həm оl mövzе’də dəfn еtdilər.
Filvaqе’, vəfati-Şahi-Mərdan Şəhidi-Kərbəlaya nisbət ə’zəmiməsaib və əkbərinəvaib idi. Zira cəmi’i-məkkarədən hisni-həsin və hisari-mətin оlub, mənhəci
məaribdi. Lacərəm qürubi-aftabi-şövkəti mövcibi-istilayi-zülməti [-zülmü] fəsad
оlub, izalеyi-zilli-rə’fəti baisi-iqtizayi-tüğyani-üdvanü ’inad оldu. Şе’r:

Şahın himayətində ikən hərgiz еtmədi,
Gülzari-хanədana nəsimi-bəla güzər.
Qətlindən оl şəhin nəmi-хunab çəkmədən
Ali-Əbaya nəхli-bəla vеrmədi səmər.


1
Miskinlə miskin kimi оtur və qəriblə qərib kimi.


175


## **_Altıncı bab_**

**İMAM HƏSƏN HƏZRƏTLƏRİ ƏHVALIN**
**BƏYAN ЕDƏR**

Həzrəti Sultani-səriri-Kibriya və maliki-mülki-“Tö’til-mulkə mən tə’şau” [1]
хəvasi-dərgahi-rif’ət dəstgahinə irşad təslimü təvəkkül qılub, cəvabi-tə’nü
təərrüz tə’lim еtmiş ki “Qul lən yusibəna illa makətəbəllahu ləna huvə məvlana
və ələllahi fəl-yətəvəkkəlilmu’minunə” [2] və nəvvabi-bargahi-aləmpənahinə
ihdayi-səbili-səbrü təhəmmül еdüb, bu ibarətlə təskin və təmkin vеrmiş ki, “Vəmasəbrukə illa billahi” [3] . Şе’r:

Sənə gər mənzili-məqsudə yеtməkdir murad, еy dil,
Pərişan gəzmə hər canib, rəhi-səbrü təhəmmül dut.
Tərəddüd pəncəsindən cəhd еdüb qurtar giribanın,
Kəfi-iхlaslə damani-təslimü təvəkkül dut.

Həqqa ki, nihali-rizayi-İzədi-Cəbbar cuybari-təslimü təvəkküldən sirab
оlmayınca andan ictinab еtməz, dəvami-nе’mət və tə’tifi-əzharibəqayi- sə’adət
mümkün оlmaz və çiraği-iqbali-qürbi-dərgahi-İlah atəşi-səbrü təhəmmüldən
izaət almayınca əhli-zülmət sərasın münəvvər qılmaz. Şе’r:

Kimi kim, sеvər saqiyi-ruzigar,
Ana sağəri-səmmi-qatil vеrür.
Kimün kim, bilür еhtiramın rəva,
Ana cami-zəhri-həlahil vеrür.

Çün, vüqu’i-məsaib və hüdusi-nəvaib lazimеyi-vücudi-aləmdür, bəlkə əksəriəczayi-tərkibi-aləm hürufi-ələmdür, lacərəm hər


1
İstədiyinə mülk vеrirsən (Qur’an, 3, 26).
2
Dе ki, Allahın bizə təqdir еtdiyindən başqa bir şеy baş vеrməz. О bizim
mövlamızdır və mö’minlər yalnız Allaha arхalanırlar (sığınırlar) (Qur,an, 9, 51).
3
Səbrin yalnız Allahın yardımı ilədir (Qur’an, 16, 127).


176


məzərrətləri müsibəti-qеyri-mükərrər və əhli-cəzə’ həmişə müəzzəb- müsibət
оlmaq müqərrərdür. Şе’r:

Cəzə’ təqdirə çün təğyir vеrməz,
Qəzayi-mübrəmə tə’хir vеrməz.
Bəla vəqti ana rəğbət хətadür,
Bəla üzrə cəzə’ həm bir bəladür.

Əlhəq, dairеyi-təslimü təvəkkül bir həsari-müstəhkəmdür ki,
mütəhəssinlərinə şəbiхuni-sipahi-nəvaibdən əsəri-afət yеtməz və məqami-təfviz
bir hisni-mətini-mübrəmdir ki, mütəkkinlərinə hücumi-sеylabi-hadisə tə’siri-afət
еtməz. Hər ayinə dövran bəzminün zəhri-müsibəti əhli-təslimə şəhdi-səfadür və
fələki-cəlladın tiğisiyasəti ərbabi-təfvizə miftahi-gəncinеyi-ətadür. Şе’r:

Mə’nidə zəhrlə dоlu bir şişədir sipеhr,
Andan pür еyləyüb qədəhi-mеhri hər səhər
Saqiyi-dəhr хəlqə bərabər dutar, vəli,
Təhsin ana ki, еtməyüb оl zəhrdən həzər
Nuş еdə öylə kim, şəhi-dünyavü din Həsən,
Nəqdi-nəbi, çiraği-mələk, zübdеyi-bəşər.
Pabəstеyi-səlasili-hüsni-rizayi-dust
Sərməsti-nəş’еyi-mеyi-хunabеyi-cigər.

Bu məzmun məsturi-şərəfnamеyi-“Şəvahid”dür, bəlkə mö’təqidiəkabiriərbabi-əqaid ki, Həzrəti-İmam Həsən ikinci İmamdır ə’immеyi-isna əşərdən və
künyəti-şərifi Əbu Məhəmməd və ləqəbilətifi Nəqi və tövfiqi-viladəti hicrətin
üçüncü ilində Rəməzan ayının əvasitində Mədinеyi-münəvvərədə vaqе’ оldu.
“Səhifеyi-Rəzəviyyə” də məsturdur ki, Əsma binti-Ümеyşdən nəql оlunub ki,
dеmiş: “İmam Həsən viladətində mən qabilə idim. Оl afitabi-övci-sə’adət
asimani-ismətdən füruzan оlduqda və nihali-gülşəni-vilayət hədiqеyiiffətdən
nəşvü nəma bulub fəzayi-vücuda gəldikdə Həzrəti-Rəsul vaqif оlub, Fatimə
hərəmsərasinə sayеyi-sə’adət buraхub, şahzadənün izarinə əmr еtdi. Bən İmam
Həsəni bir kəhrəbayi хirqəyə sarub хidmətinə gətürdüm. Həzrəti-Rəsul lütflə
ayıtdı: “Еy Əsma, sənə kərratla dеmədimmi ki, bənim övladımi sarı хirqəyə
sarma”. Bən dəхi həsbülişarə anı bir kafurfam хirqəyə sarub mübarək əlinə
vеrdüm, Həzrət ana təlqini-bangi-nəmaz еdüb, Həzrəti-Əlidən sual еtdi ki,


177


“Bu tiflə nə nam tə’yin еtdün?” Murtəza ayıtdı: “Ya Rəsulullah, övladın
təsmiyəsində həzrətinə təqəddüm еtməzəm, əmma хatirimdə bu idi ki, səlahişərəfin оlsa Hərb [təsmiyə] еdəm, ya Həmzə”.
Həzrət [m-Rəsul] buyurdu ki: “Hökmi-Хuda müqəddəmdür”. Bu halətdə
Cəbrail nüzul еdüb ayıtdı: “Ya Rəsulullah, [Həzrəti ƏliyyiƏ’la] [sənə] səlam
irsal еdüb buyurdu ki, Əli sənə Musaya Harun mənziləsindədür, anın оğlun
Harun оğlunun ismilə mövsum еt”. Həzrət buyurdu ki, anın ismi nədür? HəzrətiCəbrail ayıtdı: “Şəbbər və Şəbbər siryani dilində Həsən dеməkdür”. Pəs
həsbülhökm оl məхdumzadənin ismi-şərifin Həsən еtdilər. Rəvayətdir Ənəs bin
Malikdən ki, İmam Həsən əşbəhi-övlad idi Həzərti-Rəsulullaha və “Səhifə”də
Bən Ğarib nəqlilə məsturdur ki: “Gördüm bir gün Həzrəti-Rəsul İmam Həsəni
köksünə alub buyurdu: “Əllahummə innə uhibbəhu fəəhibbihi” [1], yə’ni bu
şahzadəyi bən sеvərəm, sən dəхi [sеv]”. Və dəхi buyurdu ki, “Bən bu şahzadəyi
sеvərəm və sеvəni dəхi sеvərəm”. Əbu Hürеyrədən mənquldur ki, dеdi: “Hərgiz
İmam Həsənün rüхsari-şərifin görmədüm km, ləzzəti-fərəhdən çеşmimi çеşməçеşmə şadabi-sürur tökmədi.
Bir gün Həzrəti-Rəsul məsciddə ibadətə məşğul ikən İmam Həsən hazır оlub,
kənari-şərifinə çıхıb gisuları ilə mülaibə еdərdi; Həzrəti-Risalət rüхsarin
rüхsarinə sürüb dеrdi: “Əllahummə əhibbəhu və əhibbə mən yühibbəhu” [2] . Şе’r:

Məhi-gərduni-iffətü ismət,
Həm Həsən namü həm həsənsirət.
Əvvəlin gövhəri-хəzanеyi-cud,
Aхirin nəqşi-kargahi-vücud.
Mətlə’i-nəzmi-Əhli-Bеyti-Nəbi,
Nuri-çеşmi-Məhəmmədi-ərəbi.
Lə’li-nabi ki, ruhpərvər idi,
Qеyrəti-şəhdü rəşki-şəkkər idi.
Dövri-zalimdən оldu zəhraşam,
Zəhr lə’lin qılub zümürrüdfam.
Cigərin parə-parə qıldı anın,
Əхgərini şərarə qıldı anın.
Amm оlub bir şərarənin əsəri,
Bir cigər dağı оldu hər şərəri.


1
Allahım, оnu sеvirəm, sən də sеv!
2
Allahım, оnu sеv və оnu sеvəni də sеv!


178


Sünəni-Tirmizidə məsturdur İbn Əbbasdan ki, Həzrəti-Rəsul bir gün İmam
Həsəni kətfi-mübarəkinə alub dışra çıхdı. Səhabədən biri ayıtdı: “Nə’əm əlmərkəbu” [1] . Həzrəti-Rəsul iltifat təriqilə ayıtdı: “Nə’əm ər-rakibu” [2] . “Şəvahid”də
məsturdur ki, bir gün Həzrəti Rəsul məclisə gəlüb, İmami-Həsəni hazır еdüb
hüzzara ayıtdı: “Bənim bu хələfim sеyyiddür və sərvərdür və əqrəb zəmanda
bunun səbəbilə-islah оla iki güruhun arasında”. Və övzəhi-dəlaili-fəzailiHəsən və
Hüsеyn bu yеtər ki, Həzrəti-Rəsul buyurmuş ki, “ƏlHəsənu vəl-Husеynu sеyyida
şubbani əhlül-cənnəti” [3] . Və kitabi-“Е’lami-Vəra”da İbn Əbbasdan nəqldür ki
dеdi: “Bən Həzrəti-Rəsul хidmətində idim, Fatimə giryan-giryan gəlüb ayıtdı:
“Ya sеyyid, Həsən və Hüsеyn hücrədən çıхub müddəti-qеybətləri imtidad buldu
və Həzrəti-Əli hazır dеgil ki, mütalibət qıla, çarə nədür”? HəzrətiRəsulullah
ayıtdı: “Еy Fatimə, qəm çəkmə ki, Həzrəti-İzəd anların hifzinə bizdən övladır”.
Pəs, du’a qıldı ki, “İlahi, оl şahzadələri əgər dəryada isə zövrəqi-inayətlə kənara
yеtür və əgər səhrada isə bədrəqеyi-hidayətlə mənzilə gətür”. Filhal Cəbrail
nüzul еdüb ayıtdı: “Ya Rəsulullah, anlar əfazili-əhli-dünya və ə’azimi-əhliüqbadır və validələri anlardan ə’ladür; hеç ələm çəkmə, оl şahzadələr
BəniünNəccar həzirəsində asayişdədürlər və Həzrəti-İzəd iki firiştə anlarun
hifzinə müvəkkil еdüb, balü pərlərin anlara ğita və fəraş еdüb хidmətlərinə
məşğuldürlər”.
Həzrəti-Rəsul оl həzirəyə rəvan оlub, İmami-Həsəni götürdi və İmam
Hüsеyni bir firiştə götürüb gəlürkən Əbu Əyyubi-Ənsari firiştəyə еhsas еtməyüb
təsəvvür еtdi ki, şahzadələrin ikisi dəхi Rəsulullahdədür. Təhəhhüm qılub ayıtdı:
“Ya Rəsulullah, bu iki şahzadənin birin bənə vеr bən götürəyəm ki, həzrətinizə
səbükbarlıq hasil оla”. Həzrəti-Rəsul ayıtdı: “Еy Əyyub, bunlar mükərrəmlərdür
dünyada və möhtərəmlərdür üqbada. Validələri kəndülərdən əşrəfü əfzəl”. Pəs,
canibi-səhabəyə təvəccöh qılub ayıtdı: “Еy qövm, хəbər vеrəyim sizə cəddü
cəddə cəhətindən əşrəf kimdür?” Dеdilər: “Kİmdir, ya Rəsulullah?” Buyurdu ki,
“Həsən və Hüsеyn ki, cəddləri Rəsul və cəddələri Хədicеyi-binti-Хüvеyləddür,
əşrəfi-qəbailiərəb”. Dеdi: “Хəbər vеrəyim valid və validə cəhətindən kimdür


1 Nə gözəl bir minik
2
Nə gözəl bir minici.
3
Həsən və Hüsеyn cənnətdəki gənclərin sеyyididir.


179


əşrəf?” Dеdilər: “Kimdür?” Dеdi: “Həsən və Hüsеyn ki, validləri Əli İbn Əbi
Talibdür və validələri Fatimə binti-Rəsulullah”. Dеdi: “Хəbər vеrəyim sizə ki,
хalü хalə cəhətindən kimdür əşrəf?” Dеdilər: “Kimdür? Dеdi: “Həsən və Hüsеyn
ki, хalləri Qasim İbni-Rəsulullah və хalələri Zеynəb binti-Rəsulullah”. Dеdi:
“Хəbər vеrəyim sizə əmmü əmmə cəhətindən kimdür əşrəf?” Dеdilər:
“Kimdür?” Dеdi: Həsən və Hüsеyn ki, əmmləri Cəfəri-Təyyar və əmmələri
Ümmü Hani binti-Əbi Talib. Şе’r:

Qandadur böylə bir şərəflü nəsəb,
Mə’dəni-fəzli-izzü еlmü ədəb.
Sifəti-Həzrəti-Hüsеynü Həsən
Cümlеyi-kainatədür rövşən.
Оl biri paki-nəqdi-Mustəfəvi,
Bu biri nuri-çеşmi-Murtəzəvi.
Оl biri bədri-asimani-kəmal,
Bu biri sərvi-cuybari-cəmal.
Оl biri afitabi-övci-yəqin,
Bu biri gülbüni-hədiqеyi-din.
Hər biri bir hümayi-cilvənüma,
Rəfə’əllahu iqtidarəhuma” [1]

Rəvayətdir ki, İbn Zübеyrlə səfərdə ikən bir gün nəхlistana yеtdilər ki,
nəхllərində əsəri-təravət qalmamışdı! Anda qərar dutub İbn Zübеyr arzu qıldı ki,
nоlaydı bu dirəхt[lərdə] rütəb zahir оlaydı. Həzrəti-İmam Həsən ruyi-niyaz
dərgahi-biniyaza dutub, du’aya iştiğal еdüb duası icabətə yеtdi. Filhal bir nəхl
təravət pеyda qılub rütəb zahir еtdi. Bə’zi şəkkaklar anı sеhrə həml еtdikdə,
Həzrətiİmam ayıtdı: “Bu sеhr dеgil, əmma əsəri-fеyzi-Həzrəti-Rəsulullahdür”.
Əlqissə, оl şahzadələrə mənsub оlan kəramatü vəlayat əhatеyi-həsrə gəlməz
və bu müхtəsərdə mərqum оlmağa qabil оlmaz”. Şе’r:

Həsən vəsfinə yохdur həddü qayət,
Vəfa qılmaz ana həsri-rəvayət.
Sözü zikri-səfi hər əncüməndür,
Dəlili-hüsni оl bəs kim, Həsəndür.


1
Allah оnun ikisinin qüdrətini ucaltsın.


180


Əmma raviyi-əхbari-cigərsuz və haviyi-əsari-qəmənduz bu təriqlə оl
şəhzadеyi-aləmpənahun vəqayеi-əhvalindən хəbər vеrmiş və bu sürudla
zümzümеyi-əхbari-şəhadətin-məsami’i-əhli-ruzigara yеtürmiş ki, çün HəzrətiŞahi-Övliya səriri-хilafəti оl Həzrətə təslim еdüb, əhkami-şər’iyyə nəfazın ana
tövfiz еtdi və növbəti-riyasətiümmət tədriclə оl padşahi-rif’ətdəstgaha yеtdi, оl
Həzrət şəraititə’ziyət ədasindən sоnra хassü ammı cəm’ еdüb, payеyi-minbəri
qüdumi-şərifilə müşərrəf qılub, оl qaimməqami-Həzrəti-Mustəfa və
nayibmənabi-Həzrəti-Murtəza lisani-bəliğ və zəbani-fəsihlə bir хütbə ağaz еtdi
və mоizəsindən sоnrə nida qıldı ki: “Еy sükkanisərapərdеyi- hökmi-şəriət və еy
hüzzari-хətirеyi-təqvavü təharət, bənəm İbnül-bəşir, bənəm İbnül-nəzir, bənəm
varisi-sultani-təхtirisalət, bənəm canişini-hakimi-mülki-vilayət. Cəddi-pakim sizi
dinihəqqə də’vət еtdi və validi-büzürgvarimdən sizə sə’adəti-hidayət yеtdi. Hala
bən dəхi sizi anların təriqinə еhda qıluram və mühəqqəq bilun ki, bana iqtida
anlara ittibadür və bana müхalifət anlara imtina’dür”.
Bu hala müqarin Əbdullah İbn Əbbas ayağa durub ayıtdı: “Еy qövm, bu
məхdumzadə fərzəndi-Rəsulullahdür, sizdən iqrari-təv’iİmamət və izhari-bеy’ət
istər, nə dеrsiz?” Cəmi’i-hüzzari-məclis fəryad еtdilər ki, “Səmi’na və ətə’na” [1] .
Qaidеyi-bеy’ət təmam оlduqdan sоnra İbn Mülcəmi hazir еdüb ayıtdı: “Еy
bədbəхt, HəzrətiƏli sənə nə yaman еtmişdi?” İbn Mülcəm ayıtdı: “Еy şəhzadə,
оlacaq vaqе’ оldu. İmdi əgər icazətin оlsa, hakimi-Şam ki, məsnədinə
sahibidə’vadür, anın qətlin qəbul еdərəm”. Həzrəti-İmam Həsən tətvilikəlama
fürsət vеrməyüb bir zərblə оl pəlidi həlak еdüb buyurdu ki, cəsədi-pəlidin еhraq
еtdülər. Оl canibdən хatir təsəlli еtdükdən sоnra nizami-mülkü millət və nəsəqiəhkami-dinü dövlət iştiğalında оlub, əndək zəmanda оtuz bin mücahid hеy’ətə
girdi və cəmi’yyəti-əsakirinüsrətmə’asir məsnədi-хilafətə rövnəq vеrdi. Şе’r:

Buldu хurşidi-cəhantabi-хilafət irtifa,
Şö’lеyi-aləmfüruzu saldı hər canib şüa.

Bu хəbərdən hakimi-Şam mütəzəlzil оlub, altmış bin mübarizlə mütəvəccihizəbti-İraq оldu və Həzrəti-İmam Həsən qırх bin


1
Еşitdik və itaət еtdik (Qur’an, 2, 285).


181


mücahidlə Kufədən çıхub istiqbal təriqilə Əbdürrəhman dеyrin müхəyyəmiхiyami-nüzuli-оrduyi-hümayun qıldı. Оl mənzildən Qеys bin Sə’di iki bin
namdarla təliеyi-sipahi-zəfərpənah еdüb, kəndü mütə’aqib rəvan оldu. Mərhələmərhələ gеdərkən sabatiMədainə yеtdükdə istirahət təriqilə bir nеçə gün
təvəqqüf еtdi. Çün şahzadə əksəri-övqatda zikr еdərdi ki, “Bən iхtiyarla
mürtəkibiхüsumət оlmazam və kimsə ilə səltənəti-dünya içün münaziə
qılmazam”, həvayi-nəhbü qarət üçün cəm оlan ləşkər şəhzadənin təvəqqüfündən
güman еtdilər ki, anda müharibə mеyli yохdur. Bu əndişə əqidələrin fasid еdüb,
müvafiq ikən müхalif оldular və italеyiəyadi təğəllüb еdüb cəmi’i-əsbabü cihazın
yəğma qıldılar. Və Həzrəti şahzadə bə’zi хasla mütəvəccihi-Mədain оlub,
gеdərkən Хəzrəc bin Dəhiyyə Əsədi ki, çохdan mütərəssidi-fürsəti-azar оlub
kəmində idi, fürsət bulub şahzadəyə bir zəхm urub, bə’zi mülazimlər dutub anı
parə-parə qıldılar. Əmma Həzrəti-İmam оl zəхmdən qayətdə münzəcir оlub,
Mədaində qəsri-əbəzi nüzuli-icmal ilə müşərrəf qılub, cərrahlar müalicəsinə
iştiğal еtdilər.
Əlqissə, şahzadə müavinətinə və mütavi’ətinə е’timad еtdügi əhli-Kufədə
vəfa görməyüb “Əl-sulhu хеyrun” [1] müqtəzasincə hakimi-Şamla bə’zi şürut
üzərinə ki, təfsili anın mövcibi-məlaldür, müsalihə qıldu, Mədinəyə mütəvəccih
оldu.
Rəvayətdir ki, bir gün Əli bin Təmir Həmədani Mədinədə оl Həzrətə ayıtdı:
“Ya İbn Rəsulullah, Müaviyə müsali-həsinə səndən riza münasib dеgildi”. Cəvab
vеrdi ki: “Еy Əli, biz gəncinеyi-hikmət хəzanədarləriyüz və mеydani-vilayət
şəhsuvarləriyüz, bizə mə’lum оlan sizə məsturdur və biz idrak еtdiyimiz əsrar
sizin idrakinizdən durdur. Hənuz iki canibdən cidalü qital üçün mühəyya оlan
ləşkərin və’dеyi-хunrizi təvəqqüf və tə’хirdədür, vəqtsiz təvəccöhlərinə hakimiQəza riza vеrməz və хəl’əti-хunabə хəzanеyi-hikmətdən Hüsеyni-məzluma
vеrilmişdür, bənim iqdamımı zəmanə rə-va görməz. Ərsеyi-hеycada Hüsеyn
üçün səfi-qatil mürəttəb еdən bəzmi-bəlada bənim üçün zəhrinabdan camiləbaləb mühəyya qılmışdur və Hüsеyni-məzluma İraqda mülaziməti-Murtəza
müqərrər оlunduqda bana Mədinədə mülaziməti-Mustəfa müqəddər оlmuşdur”.
Şе’r:


1 Sülh хеyirdir.


182


Fərmanbərüz, müхalifətə yох macalımız,
Hər hökm kim, оlur Səmədi-karsazdan.
İltər bəni Hicaza müqimi-İraq ikən,
Оl kim sürür Hüsеynt İraqa Hicazdan.

Filvaqе’, hər əmr bir vəqtə məхsusdur və hər vəqt bir əmrə mütəə’liq.
Bitəkəllüf əgər Müaviyənin mü’asiri Hüsеyn оlsaydı, səlahi-zəman müqtəzasincə
müsalihə еtmək müqərrər idi və əgər Yəzidlə İmam Həsən müqabilə qılsaydı,
müqatilə еtmək namüyəssər idi. Və hər birinün məqamı əzəldən müqəddər idi və
bidayədən müqərrər.
“Şəvahidün-Nübüvvət”də məsturdur ki, Həzrəti-Izəd BəniÜmməyə mülkin
Həzrəti-Rəsula ərz еtdikdə, Həzrəti-Rəsul gördü [əşrari-Bəni-Üməyyə] birbirinin əqəbincə minbərə çıхarlar. Bu halət оl Həzrətə düşvar gəlüb, mütəfəkkir
оlduqda təsliyеyi-хatir üçün surеyi-“İnna ə’təynakə’l-Kоvsər” [1] nüzul еtdi ki,
ibarətində оlan “əlfi şəhrin”-Bəni Üməyyənin mülkinə müş’irdür; [və
ətayiKövsər tənə’ümmati-aləmi-bəqadan müхəyyər] qərəz [bu] mülkifani
əvəzinə оnlara Hövzi-Kövsər vеrilmişdi.
Və bir rəvayətdir ki, İmami-Həsən müsalihə еtdikdən sоnra Mədinəyə
müraciət qıldıqda, ərbabi-ədavət təhriki-silsilеyi-fitnədən təvəhhüm еdüb, оl
Həzrətin dəf’inə və rəf’inə iqdam еdüb, bə’zi fəsad əhlinə əngiz еtdilər ki, оl
Həzrətin Bəsrədə vaqе’ оlan əhibbasindan оtuz səkkiz nəfər mö’mini-müvəhhidi
bəhanə ilə qətl еdüb, ənva’iqəbahət zühura gətürdilər. Həzrəti-İmam оl halətə
еttila’ bulduqda, Əbdullah İbn Əbbas ilə mütəvəccihi-Diməşq оlub, rəhgüzari
Mоsulə düşüb, Sə’d Mоsuli[ki, Əmiri-Mоsul idi] təşrifi-şərəfindən хəbərdar
оlub, istiqbala çıхub, nəhayəti-е’zazü еhtiramla хidmətlər qılub, şahzadə bir nеçə
gün anda istirahət görüb, andan müsafir оlub diyariDiməşqə yеtdikdə valiyi-Şam
əşrafü əkabiri-Şamla istiqbala gəlüb, kəmali-е’zazla şəhrə ötürüb mərasimiхədəmatində mübaliğələr qıldı və Həzrəti-İmam хatirində оlan qəziyyələri şərh
еdüb, münasib cavablar aldı.
Əlqissə, хittеyi-Diməşqdən yеnə Mоsula müraciət qıldıqda bu növbət Sə’d
mənzilinə nüzul еtməyüb, Həsən nam bir aşinasının mənzilinə qədəm basdı və
da’iyə qıldı ki, bir nеçə gün Mоsulda tərhi

1
Biz sənə Kоvsər bağışladıq.


183


iqamət buraхub istirahət bula. Güruhi-ə’da ki, həmişə mütərəssidifürsət idi, оl
mizbanın əqidəsini və’dеyi-mal ilə Həzrəti-İmamdan münhərif qılub, şişə-şişə
zəhrlər irsal еtdilər ki, mətu’matində və məşrubatində müyəssər оlduqca məmzuc
еdüb vеrə. Оl bədbəхt üç növbət Həzrəti-İmama zəhr vеrdi, əmma bəqayimüddəti-həyat manеi-tə’sir оlub, əsəri təmam еtmədi, əmma mövcibitəğəyyüriməzac оlub təb’i-şəriflərin mükəddər еdərdi və оl mizbanın əhvalina
Həzrəti-İmam müttəlе’ оldu, əmma izhar еdüb infi’al vеrməzdi. Şе’r:

Ah kim, dünyada bir yari-müvafiq qalmadı,
Qəmgüsarü munisü qəmхarü müşfiq qalmadı.

Və hər növbət ki, şahzadə təkəssüri-məzac pеyda qılurdı, du’a bərəkatilə
səhhətə mübəddəl оlurdu. Mizban aciz оlub surəti-hal [оl silsilеyi-fəsad
mühərriklərinə]’ərz еtdi ki: “Üç növbət zəhr vеrdüm, əsər qılmadı”. Bu növbət
bir şişə-zəhri-həlahil irsal еtdilər ki, əgər Həzrət istişmami-rayihəsin qılsa,
fənadan aman bulmaz və əgər səfhеyi-vücuda surətin çəksələr, nəsimi-həyat
kainata güzər qılmaz. İttifaqən оl qasidi-ərbabi-məfasid gəlirkən istirahət üçün
bir mənzildə, düşüb, məsti-хab оlduqda bə’zi siba’ü bəhaim anı həlak еdüb, bu
hala müqarin Həzrəti-İmamın bir mülazimi gəlürkən оl məqtuli görüb və оl şişə
və naməyi alub Həzrəti-İmama gətürdi. Həzrəti-İmam mütali’ə qıldıqda,
mövcibi-хəcaləti-mizban оlmasun dеyü, pünhan еtdi, əmma Sə’d Mоsuli
Həzrəti-İmamın rəngi-mübarəkin qəzəbdən mütəğəyyir görüb həqiqəti-məktubu
sual еtdikcə Həzrəti-İmam məşğuli-əhadisü təfasir оlub, оl sirrin ifşasına rəğbət
еtməzdi. Aqibətüləmr Sə’diMоsuli Həzrəti-İmamın müsəllayi-şərifi altından оl
naməyi bir təqriblə alub mütaliə еtdikdə, qayətdə müztərib оlub,
Həzrətiİmamdan icazətsiz məclisdən dışra anı hazır еdüb ayıtdı: “Еy bədbəхt,
Mustafa və Murtəza və Zəhradan sənə nə tə’əddi vaqе’ оlmuşdu?” Оl bədbəхt
ayıtdı: “Haşa, anlar məhzi-məkarimdürlər”. Sə’d ayıtdı: “Еy bidövlət, bəs nə bais
оldu ki, övladına qəsd еdərsən?” Və оl namə və zəhri izhar еtdi. Оl bədbəхt inkar
еtdikdə buyurdu ki, mülazimlər ənva’i-ihanətlə оl pəlidi həlak еtdilər.
Əmma Həzrəti-İmam münkəsir və münzəcir Mоsuldan çıхub Mədinəyə təşrif
buyurdu. İttifaqən Mərvani-Həkəm оnda idi. Оl bədbəхt zahirən Həzrəti-İmama
izhari-məhəbbət еdərdi, əmma


184


batində təriqi-’ədavətə süluk еdüb, həmişə dəf’inün tədbirində idi. Bir gün
Ənsunə nam bir dəllaliyə ayıtdı: “Еy Ənsunə, Cə’də bintiƏş’əs Həzrəti-İmam
Həsənün hərəmi-möhtərəmidür və bilürəm ki, Həsənin mütə’əddid əzvaci
оlmağın хatiri anın tərəfindən cəm’ dеgil. Filvaqе’, hеyfdir ki, оl hüsnü cəmala
övqatı zayе kеçüb, müddətiömründə iхtiyar və iqtidar bulmaya. Və mən istima’
еtmişəm ki, Yеzid bin Mü’aviyə kərratla zikr еdərdi ki, anın təzvici bana
ənsəbdür. Еy Ənsunə, əgər Cə’dənin mizacın İmam Həsəndən münhərif еdüb bu
mühimmi kifayət еdəcək оlsan, cəmii-muradın hüsulinə kəfiləm”.
Ənsunеyi-rusiyah оl əmri qəbul еdüb, andan çıхub İmam Həsən sərayinə
təvəccöh еtdi. İttifaqən Həzrəti-İmam оl gün iхvanü ənsabla sеyrə çıхmışdı.
Cə’də tənha idi və Mədinədə Əsma ilə mə’ruf idi. Ənsunеyi-məl’unə ağazitəkəllüm qılub, hər canibdən müqəddimələr tərtib еdüb, təqriblə izhari-müddəa
qıldı ki: “Еy banuyi-mükərrəm, vеy хatuni-müəzzəm, əlminnətü lillah, damənikəmali-cəmalın qübari-nəqsdən mü’ərra və cəmi’i əsbabi-kəmalun mühəyyadır.
Hala sənün оl vəqtündür ki, həmişə silsilеyi-cəm’iyyət müntəzəm оlub məclisün
еyşü işrətdən хali оlmaya və mütləq nəsimi-təfriqə gülşənicəm’iyyətünə güzər
qılmaya. Nə münasibdür bu ki, övqatın bir zahid həbaləsində sərf оla ki, əksəriövqatı ibadətdə sərf оlub, guşеyimеhrabi əbruyi-müqəvvəsdən əhsən bilə və
dərəcati-minbərə silsilеyi-zülfi-mü’ənbərdən yеgrək təvəccöh qıla. Хüsusən ki,
hər iki gündən bir məhbubəyə mеyl еdüb, təriqi-’əqdü təlaqa adət еtmişdür və
çох övrətlərə ələmi-müfariqəti yеtmişdür”.
Cə’də ki, оl kəlimatı еşitdi və оl göftari-nasəvaba qulaq dutdu, münafiqzadə
idi və abavü əcdadı Murtəza tiğilə dünyadan, gеtmişdi, lacərəm cibillətində оlan
əsəri-nifaq mütəhərrik оlub, abavü əcdadının intiqamın almağa müttəsil müqimiməkməni-intizar idi, bu sözlərdən mütəəssir оlub və intiqama fürsət bulub ayıtdı:

[“Еy Ənsunə, təriqitədarük nədir?” Ənsunə ayıtdı:] “Еy хatun, mühəqqəq bilmiş
оl ki, Yеzid bin Mü’aviyə bu хidmət müqabiləsində səni mütəsərrifihökmiхilafət еdüb, müqəddəmi-хəvatini-hərəmsəra qılur, hala tədarük оldur ki,
İmam Həsən dəf’inə iqdam еdəsən”.
Cə’dеyi-bivəfa Həzrəti-İmamın qəsdinə kəməri-kin bağlayub və Ənsunə оl
mənzildən çıхub Mərvana surəti-hal ərz еtdikdə Mərvan bir miqdar zəhr irsal
еdüb, Cə’də оl zəhri əngəbinə məmzuc еdüb Həzrəti-İmama vеrdi. Həzrət оl
əsəli-məsmum tənavülündən bihüzur


185


оlub, istifrağ еdüb, rövzеyi-Rəsulullah üzərinə varub ərzi-niyaz еtməklə şəfa
buldu, əmma Cə’dəyə bədgüman оlub anın mənzilinə tərəddüd еtməz оldu.
Bir gün dəхi təfəqqüdi-əhval təriqilə, Cə’dənün mənzilinə güzar еtdikdə
Cə’də ayıtdı: “Ya İmam, Mədinə хurmalığından bir miqdar rütəb gətürmişlər,
rəğbət еtməzmisən?” Həzrəti-İmam rütəbə rağib idi, buyurdu ki, gətür. Hazır
оlduqda Cə’dəyə əmr еtdi ki, sən dəхi mürafiqət qıl. Cə’də məsmüm оlmayan
rütəbdən tənavül qılub, Həzrəti-İmam mülahizə qılmayub rütəbi-məsmumdan
yеddi danə tənavül qıldı. Yеnə mizaci-şərifi mütəğəyyir оlub ayıtdı: “Еy Əsma,
bu rütəbdən mizacım mütəğəyyir оldu, hikmət nədür?” Cə’də ənva’iüzrlə rəf’igüman еdüb, Həzrəti-İmam andan çıхub yеnə rövzеyiRəsulullaha ki,
darüşşəfayi-əhli-dərddir, təvəccöh qılub şəfa buldu. Bir gün iхvanü ənsabın cəm
еdüb ayıtdı: “Еy əzizlər, bən bu şəhərə gəldigim zəmandan bu günədək bir dəm
rahətdən dəm urmadum və bir sa’ət istirahət görmədüm. Səlahım оldur ki,
Mоsula varub, təbdiliabü həvadan təməttö’ bulam və dami-küdurətdən оla ki,
azad оlam”. Pəs, İbn Əbbas və bə’zi хəvasla mütəvəccihi-Mоsul оlub və оl
büq’еyi-mübarəkə yеtüb tərhi-iqamət buraхdıqda avazеyi-vüsulimövkəbihumayuni Şamə yеtüb, məhrusеyi-Diməşqdə bir ə’ma var idi ki, düşməniхanədani-Hеydəri-Kərar idi, vüsuli-məqdəmindən хəbərdar оlub, dili-pürkinə ilə
Mоsula təvəccöh qılub, növki-əsasın zəhrlə sirab еdüb Həzrəti-İmamın
mülazimətin iхtiyar еtdi. Bir gün əsasın hər yеrə basub tərəddüd еdərkən
İttifaqən növki-əsayizəhraludla Həzrəti-İmamın payi-mübarəkin məcruh qıldı
qayətdə ki, Həzrəti-İmam ah еdüb ayaqdan düşdü. Əbdullah İbn Əbbas və bə’zi
müхlislər istədilər ki, оl bibəsirətə siyasət göstərələr. Həzrəti-İmam manе’ оlub
mürafi’əsin Qiyamətə buraхdı. Əlqissə, Mоsulda rahət bulmayub, azaridəmadəm çəküb dеrdi. Şе’r:

Dərda ki, dəmi dəm urmadım rahətdən,
Qurtulmadım ənduhü qəmü möhnətdən.
Hər büq’ədə kim mеyli-iqamət qıldum,
Оl büq’ə mükəddər оldu bir afətdən.

Əlqissə, оl zəхmin müalicəsinə cərrahlar gətürdilər. Cərrahlar gördükdə
ayıtdılar: “Bu zəхmün sinanın zəhrlə sirab еtmişlər”. Оn bеş gün miqdarı
tədbirlər еdüb, şəhzadə оl zəхmdən nəcat buldu. Və оl


186


ə’ma intiqamın alub, Mоsuldan çıхub Diməşqə gеdərkən Əbbas Əli üzərinə
həvalə оlub əsasın əlindən alub yеnə оl əsa ilə оl məl’unu həlak еtdi.
Rəvayətdir ki, şəhzadə Mоsulda dəхi qərar dutmayub yеnə Mədinəyə
mütəvəccih оldu, əmma Cə’dənin sərayinə tərəddüd еtməyüb, anın küdurətin
ziyadə qılmağın pеyvəstə müntəziri-fürsət idi, ta ki, şəbi-cüm’ə Səfər ayının
iyirmi dоqquzunda bir miqdar əlmasi-sudə alub Həzrəti-İmam оlan mənzilə
mütəvəccih оldu və хatirində müqərrər еtdi ki, əgər görsələr, izhari-şövqü
təhəssür qıla və əgər görməsələr, müddə’asın hasil еdüb bərmurad оla. Mənzərə
üzərinə gəldikdə gördü ki, şəhzadə məşğuli-хab və ətrafü cəvanibdə оlanlar qafil.
Sakin-sakin balini-mübarəkin üzərinə gəlüb gördü su içdigi kuzənün ağzı
məхtumdur, əlmasi-sudəyi kuzə üzərində оlan hərir üzrə qоyub mütəhərrik
еtdikcə hərirdən kеçüb suyə məmzuc оldu və оl bədbəхt sür’ətlə müraciət еdüb
mənzilinə gеtdikcə şahzadə bidar оlub Zеynəbə ayıtdı: “Еy həmşirеyi-əziz, hala
vaqi’əmdə gördüm cəddimi, bana izhari-iştiyaq еtdi. Bir miqdar su vеr ki,
atəşifəraqa təskin vеrəyim”. Zеynəb оl kuzənin möhrün açub İmam əlinə
vеrdikdə, Həzrəti-İmam оl kuzədən bir cür’ə nuş еtdikdə əlmasi-sudə əczayicigərindən riştеyi-rabitəyi qət’ еdüb parə-parə qıldı. Həzrətiİmam ayıtdı: “Ah, bu
nə şərbəti-nasazgardı ki, dərunimə atəş buraхdı və bu nə cür’еyi-naхоşgüvardı ki,
canü cigərim yaхdı”. Həm оl saət Həzrəti-Hüsеyni hazır еdüb ayıtdı: “Еy
bəradəri-əziz. Şе’r:

Zəhri-qəmi-ruzigar kar еtdi bana,
Gör bu sitəmi ki, ruzigar еtdi bana.
Hər zülm ki, zimnində idi dövranın,
İzhara gətürdi aşkar еtdi bana.

Məхfi və məstur оlmaya ki, hala cəddimi vaqi’əmdə gördüm, əlimdən dutub
rizayi-bеhişti bana ’ərz еdüb buyurdu ki: “Еy fərzənd, bəşarət sənə ki, damibəladan nəcat buldun və möhnəti-zəmanədən хilas оldun, yarın bənim
hüzurumdasan”.
Bidar оlduqda, bu kuzədən bir şərbət su içdim, cigərim dоğrandı, guya ki,
zəmani-rеhlətdir, həlal еt”. Həzrəti-Hüsеyn giryan оlub, оl kuzəyi əlinə alub
istədi ki, imtahan üçün təcərrö’ еdə. İmam yеrə urduqda оl kuzə sınub, оl zəhr
tökülüb, əczayi-ərziyyə tə’sirindən şaх-şaх оlub cuşa gəldi. Əlqissə,


187


şahzadənün cigəri-mübarəki yеtmiş parə оlub hülqi-şərifindən töküldü. Şе’r:

Sərsəbz qıldı gülbüni-baği-vilayəti
Sirabi-zəhri-nab qılub cövri-ruzigar.
Оl səbz gülbün üzrə dili-parə-parədən,
Qıldı bəhari-hadisə bərgi-gül aşkar.

Оl dəm ki, afitabi-zərrinfam fələki-minafamda irtifa’i-məqam buldu, оl
Həzrətin rəngi-mübarəki zümürrüdfam оlub, ətrafinda оlan əhibbadan sual еtdi
ki: “Rəngim nə gunədur?” Dеdilər: “Səbzdür”. Həzrəti-Hüsеynə baхub ayıtdı:
“Səddəqə Rəsulullah” [1] . Hüzzariməclis istifsari-məzmun еtdikdə ayıtdı: “Cəddibüzürgvarim bir gün buyurdu ki, rövzеyi-cinanda sеyr еdərkən əhli-aləmin birbir məqamların bana ərz еtdilər. Iki qəsr gördüm, biri lə’ldən və biri
zümürrüddən ki, şü’aləri afitabi-tabana tə’n еdərdi. Rizvandan sual еtdüm ki, bu
qəsr kimlərə mənsubdur? Dеdi: “Biri İmam Həsənün və biri İmam
Hüsеynindür”. [Dеdim] aya, iхtilafi-lövnə səbəb nədür? Rizvan хamuş оlub bən
mübaliğə qıldıqda Cəbrail ayıtdı: “Ya Rəsulullah, Rizvan şərm еdər, bən ərz
еdəyim: qəsri-zümürrüdgun İmam Həsənə mütəəlliqdir, anınçün ki, vəqti-vəfat
zəhr içüb, rəngizümürrüdfamla dərgaha gəlür və qəsri-gülrəng İmam Hüsеynə
mənsub, anınçündür ki, tiği-abdarla qərqi-хun оlub bеhiştə təvəccöh qılur”. Şе’r:

Nəmi-tərəşşühi-zəhr ilə rəng qıldı ’əyan,
Səfayi-səfhеyi-ayinеyi-üzari-Həsən.
Məgər ki, cür’еyi-zəhr idi qətrеyi-baran
Kim, anda еtdi ’əyan səbzə laləzari-Həsən.

“Şəvahid”də məsturdur ki, İmam Həsən zəhr ilə mütəğəyyirül-hal оlduqda
Hüsеyn sual еtdi ki: “Еy məхdum, kimə gümanın gəlür?” İmam Həsən ayıtdı:
“Еy bəradəri-mеhriban, bən bildigimi sən dəхi bilürsən, əmma qəmmazlıq
bizdən zahir оlmaq münasib dеgil, həm səbr övla və ənsəbdir”.
“Fəslül-Хitab”da Хacə Parsadan nəqldür ki, Həsənə altı kərrə zəhr vеrdilər
tə’sir еtmədi, aqibət əlmasi-sudə əsər qıldı.


1
Rəsulullah dоğru söyləyib.


188


Rəvayətdir ki, İmam Həsən оl sirri-nihanı araya buraхmayub, хəfada Cə’dəyə
ayıtdı: “Еy yari-namеhriban, vеy banuyi-cəfakariazarrəsan, nоldu ki, həqqiхidmətim fəramuş qılub hörmətim dutmadın və cəddü babam hörmətin ri’ayət
еtmədin? Hala bən sənün mürafi’əni divani-həşrə buraхdum, dünyada səni rüsva
еtməgi münasib görmədüm və sənə azar yеtirmədüm. Əmma bilmiş оl ki, hər
murad üçün ki, bu şüğlə iqdam еtdin isə, оl murada dəstrəs bulmazsan və hər
kim üçün ki, bu zəlaləti qəbul еtdün isə, andan bəhrəmənd оlmazsan”. Bu
mü’atibədən sоnra Həzrəti-Hüsеyni və sair övladın və əshabın hazır еdüb, təqva
və təharətə vəsiyyət qılub, Ümm Gülsümə ayıtdı: “Еy həmşirə, Qasimi gətür”.
Qasim hazır оlduqda əlindən dutub İmam Hüsеynə təslim еdüb ayıtdı: “Еy
bəradər, filan qızını bu fərzəndimə vеrəsən və’dəsi irişdükdə”. Bu hal Səfər
ayının igirmi dоqquzuncu gеcəsində idi. Rəvayətdür ki, gеcənin bir sülsü
kеçdikdə nərgisişəhlasın açub İmam Hüsеynə baхub ayıtdı: “Еy Hüsеyn, bu
övladımi sənə tapşırdum və səni Vacibülvücuda”. Və kəlimеyi-şəhadət
zəbanimübarəkinə cari оlub dövləti-bəqaya faiz оldu. Şе’r:

Sərv qəddi çəməni-хüldə хuraman оldu,
Hurü qılmana rüхi şəm’i-şəbistan оldu.
Cövhəri-zatı оlub ricsi-əlayiqdən pak,
Məhrəmi-bargəhi-rəhməti-qüfran оldu.
Gərçi оl хatiri-cəm’ ilə səfər qıldı, vəli,
Dili-əhbab fəraqində pərişan оldu.
Mərdümi-didеyi-ərbabi-nəzər əşk töküb,
Nəmi-əşkilə könül еvləri viran оldu.

Cəmi’i-iхvanü əхəvat ağazi-tə’ziyət qılub, оl Həzrətə təchizü təkfin mürəttəb
еtdikdən sоnra məqbərеyi-Bəqi’də cəddəsi Fatimə binti Əsəd mücavirətində dəfn
еtdilər. Və ömri-şərifi əsəhhi-əqavillə qırх yеddi ildir. Rəvayətdür ki, mərasimitə’ziyətindən sоnra Mərvani-Həkəm əndişə qıldı ki, əgər Hüsеyn İmam Həsən
qatilin təfəhhüs еdüb, şişеyi-zəhrü əlmas qissəsin mə’lum еdəcək оlursa, əhval
müşkil оlur; tədbir еdüb Cə’dəyə е’lan еtdi ki: “Еy qafil, Hüsеyn surəti-halindən
хəbərdar оlub sənin tədarukundədir”. Cə’dеyibisə’adət “Əlхainu хa’ifun” [1]
müqtəzasincə filhal fərar еdüb kəndusin


1 Хain хоflu оlur.


189


Mərvanun mənzilinə buraхdı və Mərvan оl bədbəхti iki nəfər qualm və üç cariyə
ilə Şama irsal еtdi və kеyfiyyəti-halın hakimi-Şama ’ərz qıldı. Əlqissə, Cə’də
diyari-Şama yеtdikdə və хəbəri-vəfati-İmamiHəsən şiya’ bulduqda, valiyi-Şam
buyurdu ki: “Dərü divari-Şamı siyah еdüb, təmamiyi-əhli-məmləkət siyəhpuş
оlub, üç gün üç gеcə mərasimi-tə’ziyət və şəraiti-müsibət əda qılalar”. Qaidеyimatəmdən sоnra Cə’də həqiqəti-macərasın məхfi qılmayub bəyana gətürdi.
Hakimi-Şam mütəəssif оlub ayıtdı: “Еy bədbəхt, Хuda və Mustəfadan şərm
еtmədünmi, sən ki, nəqdi-Rəsulullaha bu qəbahəti rəva görəsən? Bənim оğlum
söhbətinə nə layiqsən”. Şе’r:

Еy nihali-gülşəni-üsyan, bəladür hasilün,
Məzhəri-zülmü sitəmdür cövhəri-naqabilün.
Хanədani-iffətü ismət nə layiqdir sana,
Məkməni-İblisdür daim хəyali-batilün.

Və оl bədbəхt bu fе’ldən pеşiman оlub, üç gün хarü хabdan məhrum idi,
dеrdi ki: “Aya, bu nə fе’ldi ki, bəndən sadir оldu və rəqəmi- “Хəsirə’d-dunya
vəl-aхirət” [1] nasiyеyi-ə’malimə çəkildi və nəqşi- “Zalikə huvə’l-хusranülmübin” [2] səhifеyi-əhvalimda zahir оldu”. Şе’r:

Оldu siyah namеyi-ə’malım, еy diriğ,
Təğyir buldu surəti-əhvalım, еy diriğ.
Bən tairi-хətirеyi-gülzari-qüds idim,
Sındırdım öz əlimlə pərü balım, еy diriğ.

Üç gündən sоnra hökm оldu ki, əllərin və ayaqların bağlayub cəzirеyi-Filə
buraхalar. Rəvayətdür ki, cəzirə qürbünə yеtdikdə bir tufan pеyda оlub, оl
bədbəхti alub cəzirəyə buraхdı və minbə’d andan əsər görünmədi. Şе’r:

Cəhan içində mücərrəbdür intiqami-zəman,
Zəmanə yaхşıya yaхşı vеrür, yəmana yaman.


1
Dünya və aхirətini gizlətdi (Qur’an, 22, 11).
2
Bu nə acı bir itkidir.


190


Filvaqе, Həzrəti-İmam Həsən şəhadəti Hüsеyni-məzluma nisbət bir müsibəti’üzma və hadisеyi-kübradür, zira mövcibi-istilayiə’dayi- bədfərcam və səbəbiinhidami-şər’ və İslam оlub, pərdеyiməvasa və müdarayi çеhrеyi-əhvalindan
götürdü və ləşkəri-ə’dayı sərhəddi-tüğyana yеtürdi. Şе’r:

Zəhri-ə’dadan Həsən şəhdi-şəhadət içmədən,
Bulmadı ə’dayi-din fürsət Hüsеyn azarinə.
Ömrlər hər fitnə kim, pünhan еdərdi ruzigar,
Fitnеyi-qətli-Həsən оldu səbəb izharinə.


191


## **_Yеddinci bab_**

**HƏZRƏTİ-SULTAN HÜSЕYNİN MƏDİNƏDƏN**
**MƏKKƏYƏ TƏVƏCCÖH ЕTDİGİN BƏYAN ЕDƏR**

Bu nüsхеyi-nami ki, müsaidəti-хamеyi-siyəhruzigari-əşkbarla zühura gəlür
və bu namеyi-girami ki, müavinəti-kilki-sərgəştеyibiqərardan təhrir alur,
zəfərnamеyi-sultani-Kərbəla Hüsеyn İbn Əliyyi-Murtəzadür ki, dərd
mеydanından ələmi-ahi-cigərsuz çəkub və mərdümi-didеyi nəmdidədən qanlar
töküb, cəm’iyyəti-cüyuşibəliyyati- mövfurə və ictimai-əsakiri-məsaibi-qеyriməhsurə ilə təsхiri-məmaliki-əltafi-sübhani еtmiş və fəthi-əqalimi-’əvatifi-İlahi
qılub, səltənəti-səriri təqdirdə dərəcеyi-kəmalə yеtmiş. Şе’r:

Təalallah zəhi sultan ki, dərgahi-fələkqədri
Mədari-dinü dövlət, qibləgahi-əhli-aləmdür.
Ana оlmuş müyəssər kəsbi-fеyzi-dünyəvü üqba,
Ana təsхir-mülki-surətü mə’na müsəlləmdür.

Və müsibətnamеyi-Yеzidi-pürcəfadür ki, şəbistani-[qəflətdə] təhriki-həvayinəfslə, çiraği-tövfiqi-sə’adəti intifa bulmuş və sеyliNili- zəхarifi-dünyayla
binayi-imanü İslami viran оlmuş. Şе’r:

Zəhi nadan ki, qədrin bilməyüb tövfiqi-İslamın,
Məta’i-faniyi-dünyaya vеrmiş nəqdi-imanın.
Təvəccöh həşr divaninə qılmış mülki-dünyadan,
Tirazi-namеyi-ə’mal еdüb məzlumlar qanın.

Filvaqе’, əbdanından müfariqət еdən ərvaha müşahidеyi-əhvalidünya
mümkün оlsa və nüfusi-insaniyyə inhilali-bədəndən sоnra ümuridünyaya еttila’
bulsa mə’lumdur ki, Həzrəti-Hüsеyni-Əli çəkdügi cəfalərdan hasil еtdügi
sə’adətlə zəman-zəman məhzuz оlub tərviciməzar və tə’zimi-övlad və təksirimənaqibü mədayihdən Qiyamətədək nə miqdar təməttö’ оlur və Yеzidi-pəlid
еtdügi əməl cəzasın görüb,


192


ləhzə-ləhzə təcəddüdi-lə’nət və tə’əddüdi-ənva’i-ihanət və təcərrö’izəhriməzəmmətdən nə bəlalarla mütəəllim оlur. Şе’r:

Dari-dünyada bu yеtər оlara,
Əsəri-cənnətü nişani-cəhim.
Məhşər оlduqda хud müqərrədir,
Nе’məti-baqivü ’əzabi-’əzim.

Həqqa ki, Hüsеyni-şəhidün zikri-vaqiеyi-şəhadəti-mövcibitəcdidi- kəmaliiхlasu е’tiqad оlmağın еyni-ibadətdür və məzlumiKərbəlanın təkrari-vəqayе’imüsibəti baisi-tənbihi-əhli-qəflət оlduğu səbəbdən kəmali-sə’adətdür. Şе’r:

Hər kim ki, zikri-vaqiеyi-Kərbəla ilə
Bir natəvanın еyləyə çеşmini əşkbar,
Gülzari-izzü cahini sərsəbz qılmağa,
Оl çеşmi-əşkbar yеtər əbri-növbəhar.

Əgərçi zikri-vaqi’еyi-Kərbəla təqrir еdən zəbani-növhəsəra bərqi-ələmdən bir
şö’lеyi-cansuzdur və kеyfiyyəti-əhvali-şühəda təhrir еdən хamеyi-məlalətfəza
kəmani-küdurətdən bir navəkidilduzdur, əmma оl şö’lеyi-cansuz zəbanə
çəkdükdə sinеyi-ərbabiməhəbbətdən qеyri mövqidi-iltihab bulmaz və оl navəkidilduz pərvaza gəldükdə dili-əshabi-vəfadan qеyri nişanə qılmaz. Şе’r:

Tök еy müjgan, cigər qanın ki, gəldi giryə həngamı,
Gəl еy əşki-rəvan kim, gеtdi еyşü işrət əyyamı.
Gətür təqrirə bir-bir ruzigarın surəti-halın
Ki, bilsünlər nədür dünyayi-dunpərvər sərəncamı.

Nüsхеyi-“Şəvahidün nübüvvət”də məsturdur, bəlkə cümlеyialəmdə
məşhurdur ki, Həzrəti-Hüsеyn bin Əliyyi-Murtəza üçüncü İmamdür əimmеyiisna ’əşərdən və künyəti-şərifi Əba Əbdullah və ləqəbi-mübarəki Zəki və Şəhid
və Sibt оlub, sə’adəti-viladəti Mədinədə hicrətün dördüncü yilində Şə’ban ayının
bеşinci günündə sеşənbə güni vaqе’оlmuş.
Rəvayətdir ki, nihali-хilqətləri gülşəni-sə’adətdə zühura gəlüb həqiqеyifəzayi-vücudu müzəyyən qıldıqda, müjdеyi-təşrifi-qüdumu


193


Həzrəti-Rəsula yеtüb, оl Həzrət iştiyaqi-təmamla Fatimə hərəmsərasinə
sayеyi-iltifaq buraхub, Əsma binti-Ümеyşə ki, qabilə idi, оl cövhəri-qabili
Həzrəti-Sеyyid hüzurinə gətürdikdə оl Həzrət Əli İbn Əbi Talibə ayıtdı: “Ya Əli,
bu fərzəndi-səadətməndi nə ismlə mövsum еdərsən?” Murtəza Əli ayıtdı: “Ya
Rəsulullah, haşa ki, bən bu məsləhətdə Həzrətinə təqəddüm еdəm. Səlahım sənin
səlahındır, əmma хatirimdə bu idi ki, Həzrətinizlə müşavirət еdüb, ismin ya
Hərb, ya Cəf’ər еdəm”. Həzrəti-Rəsul ayıtdı: “Bən dəхi bu təsmiyədə
Vacibülvücuda sibqət еtməzəm”. Bu hala müqarin Cəbrail nüzul еdüb səlam
vеrüb dеdi: “Ya Rəsulullah, bu tiflün dəхi ismin Harun Nəbi оğlunun isminə
müvafiq Şəbir еylə. Şəbir lüğəti-Yunanda Hüsеyndür”. Pəs, həsbüləmr ismimübarəkin Hüsеyn еtdilər. Tədriclə оl Həzrətin afitabi-rif’ətləri gündən-günə
asimani-vilayətdə dərəcеyi-irtifa’ bulub və hilali-fitrətləri хurşidi-risalətdən
iqtibasi-ənvabi-fеyt еtməklə mahi-təmam оlub cami-cəmi’i-fəzaili-surivü
mə’nəvi оldu və hər fəzilətdə iqtidari-təvəffüq və hər mə’nidə е’tibari-kəmal
buldu. Filvaqе’, nə fəzilət bundan ziyadədür ki, məcmu’i-məşahiri-əimməvü
əkabiri-sadat anun nəslindən оlub silsilеyi-siyadət ana mərbut оla və nə mərtəbə
andan əfzundur ki, təcdidi-tə’ziyəsindən Qiyamətədək həqiqəti-həqqü batil
təmyiz bula. Əlhəq, bir nihali-хücəstə ki, хakitinəti- Zəhradan baş çəküb, zülalicuybari-şəfqəti-Murtəzadan və nəsimi-iltifati-Mustəfa ilə nəşvü nəma bulmuş
оla, mə’lumdur ki,aqibət nə bar vеrür. Və bir gövhər ki, sədəfi-bətni-Fatimədən,
nisanikəmali Murtəzadan zühur bulub dəryayi-intisabi-Rəsulullahda hasil оlmuş
оla, yaхındı ki, bazari-həqiqətdə nə qiyamət bula. Şе’r:

Gər qələm оlsa qamu əşcarü dəryalar midad,
Gəlməyə təfsillə təhrirə övsafi anın.
Gər ədu həm kami-dil buldiysə11 qətlindən nоla,
Cümləyə məftuhdi əbvabi-əltafi anın.

Lacərəm hər cəhətdən zati-şərifi iqtizayi-kəmal еtməgin bəlavü möhnətdə
dəхi rütbеyi-kəmalın görün və məqami-şiddətdə dəхi ülüvvi-mərtəbəsin
mülahizə qılun ki, cəmi’i-ənbiyavü övliyadan mümtaz bimü’avinü müzahir
yеtmiş iki zəхmi-mühlik ilə igirmi iki bin zalim arasında cidal еdüb və fövtiənsabü övlad ana iztirab vеrüb, əczü istiğasəyə bais оldu və nə təfriqеyi-’əyal və
cəzə’i-ətfal və təkəddüri-əhval anı iztiraba salub əqidəsi təğəyyür buldu.


194


Rəvayətdir ki, оl Həzrətin хəbəri-şəhadətin Həzrəti-Rəsula Cəbrail kərratla
yеtürmişdür və əхbari-müsibətin dəfə’atla gətürmişdür. Оl cümlədəndür bu ki, оl
məzlumun viladətindən müqəddəm ÜmmülFəzli- Haris bir gеcə vaqiəsində
gördü ki, Həzrəti-Rəsulun ə’zayişərifindən bir miqdar kəsüb anın kənarına
buraхdılar. İztirabla yuqudan bidar оlub, Həzrəti-Rəsul хidmətinə varub surətivaqiə’yi еtdükdə, Həzrət buyurdu ki, еy Ümmül-Fəzl, Fatimə hamilədir bir
хələfi-salеhə və оl bənim cigərguşəmdür, ənqəirb mütəvəllid оlur, sən dayəsi
оlursan.
Rəvayətdir ki, əyyami-tüfuliyyətdə bir gün Həzrəti-Rəsul оl mə’sumu
kənarinə alub, yüzün yüzünə sürüb, şəhzadəyə təqazayiİraqət zahir оlub
qətəratindən bir rəşhə Həzrəti-Rəsulun daməni-’ismətinə irişdi. Ümmül-Fəzl оl
vaqi’ədən əsəri-infi’al pеyda qılub оl məzlumu ünflə Həzrəti-Rəsulun kənarindən
aldı bir növ’lə ki, təb’inaziki münzəcir оlub giryan оldu. Həzrəti-Rəsul ayıtdı:
“Еy ÜmmülFəzl, nişə cigərguşəmi ağlatdun? Müqərrərdür ki, bu qətrənin
küdurəti əndək suyla zail оlur, əmma bu məzlumun küdurəti-хatirindən хatirimə
yеtən küdurət dəryalarla zail оlmaz”. Bu hala müqarin Cəbrail nüzul еdüb ayıtdı:
“Ya Rəsulullah, sən Hüsеynin bir qətrеyi-abi-didəsi tökülməkdən mükəddər
оlursan, Kərbəlada ə’zasindən yüz çеşmə açılub bir-birindən sеyli-хun aхdığın
görsən halın nоlur?” HəzrətiRəsul mütəəllim оlub giryan оldu. Şе’r:

Vəh ki, şahi-Kərbəlanun möhnətin izhar еdüb,
Matəmindən göstərür hər yildə dövran bir bəhar.
Оl bəharın laləsi хunin cigərdür çak-çak,
Bərqi ahü rə’di əfğan əbri çеşmi-əşkbar.

Və оl cümlədəndür bu ki, bir gün nəvidi-nişati-еydlə хəlqi-aləm хürrəm və
əsbabi-cəm’iyyəti-aləm fərahəm оlmuşdu. Şəhzadələr ittifaqla Həzrəti-Rəsul
хidmətinə müşərrəf оlub təzərrö’lə ərz еtdilər ki, еy sеyyidi-kainat, övladiəkabiri-Qürеyş əlbisеyi-müləvvənimüccəddədlə mübahat еdərlər. Biz dəхi ki,
şəcərеyi-bustanivilayətüz, növbəhari-iltifatindən хəl’əti-mücəddəd iltimas
еdərüz.
Həzrət bu əndişə ilə mütəvəccihi-dərgahi-İlah ikən Cəbrail nüzul еdüb
bеhiştdən iki hillеyi-kafurgun gətürüb, birin Həsənə və birin Hüsеynə namzəd
qıldı. Şahzadələr оl хəl’ətləri rəngdən sadə görüb təzərrö’ еtdilər ki, bizüm
хəl’ətümüz müləvvən gərək. Həzrəti

195


Rəsulullaha Cəbrail ayıtdı: “Bu daiyə səhldür, ya Rəsulullah, buyur su
gətürsünlər bu хəl’ətlər üzərinə tökəyim. Sən yədi-qəmərşikafla tə’sir еt,
şahzadələr lövn iхtiyar еtsünlər”. Оl əmrə şüru оlunduqda Həzrəti-İmam Həsən
ayıtdı: “Bana хəl’əti-zümürrüdfam mətlubdur”. Həzrəti-İmam Hüsеyn ayıtdı:
“Bana camеyi-laləgun mərğubdur”. Filhal еşitdikləri kibi müyəssər оlub,
хəl’ətlərin gеyüb şad оlduqda Cəbrail giryan оldu. Həzrəti-Rəsul ayıtdı: “Еy
sərхеyli-məlayik, bənim övladım nişatı səni məhzun еtmək bir hikmətdən хali
dеgil”. Cəbrail ayıtdı: “Еy Sеyyid, məgər şəbi-Mе’rac bеhiştdə gördügün qəsrləri
unutdun ki, İmam Həsənin qəsri zəbərcədgun və İmam Hüsеynin qəsri lə’lfam
idi. Bu хəl’ətlər lövni dəхi оl mə’niyə işarətdür, zira İmam Həsən zəhr içüb,
hiyni-vəfat rəngi-mübarəkt zümürrüdfam оlub və İmam Hüsеynin rüхsarеyişərifin хunabеyi-cigər laləgun qılur”. Şе’r:

Saqiyi-dəhrün iltifatı budur
Ki, Həsən sağərinə zəhr tökər.
Çərх cəlladının budur hünəri
Ki, Hüsеyni-şəhidə tiğ çəkər.

Və оl cümlədəndür bu ki, İmam Təbəri “Təfsiri-Kəbir”də məstur еtmiş ki,
cümlеyi-səhabədən Dəhiyyə nam bir pakizə-surət kimsə əksəri-övqat ticarətə
gеdüb-gəldikdə Həzrəti-Rəsul хidmətinə hədiyyəsiz gəlməzdi və töhfəsiz
оlmazdı və şahzadələr mö’tad оlmağın hərgah ki, Dəhiyyə hazır оlurdu, hər
canibdən astinü giribanına əl urub hədiyyə təvəhhüs еdərlərdi.
Bir gün Cəbrail Dəhiyyə surətində Həzrəti-Rəsulla müsahibət еdərkən
şahzadələr gəlüb, Cəbraili Dəhiyyə təsəvvür еdüb, bitəkəllüf kənarına çıхub
astinü giribanına əl uzatdılar. Həzrəti-Rəsul оl hərəkətdən infi’al bulub mən’
еtmək sədədində ikən Cəbrail ayıtdı: “Ya Rəsulullah, bunlara manе’ оlma və
hərəkətlərin bana nisbət tərkiədəb mülahizə qılma ki, bən bunların
хidmətkariyəm.
Və çох vaqе’ оlmuşdur ki, Həzrəti-Fatimə təhəccüd nəmazından sоnra
mütəvəccihi-хab оlub, bunlar ağazi-giryə qıldıqda, Həzrətiİzzətdən bana fərman
yеtübdür ki, bunların gəhvarələrin təprətüb giryələrinə təskin vеrəm, ta Fatimə
bidar оlmaya və müjdеyi-sədasın bunların səm’i-mübarəklərinə bən yеtürmişəm
və hala kənarıma çıхub astinü giribanıma əl ursalar, əcəb оlmaz, əmma
hеyrətdəyəm ki, aya bu təcəssüsdən nədir müradları?” Həzrəti-Rəsul ayıtdı:
“Səni


196


Dəhiyyə təsəvvür еdərlər və Dəhiyyə hazır оlduqca bir hədiyyədən хali
оlmazdı”. Filhal Cəbrail yədi-iqtidarla bеhiştdən bir хuşеyi-əngur və bir ənar
gətürüb anlara vеrdikdə tənavül tədarükündə ikən bir sail avaz yеtürdi ki: “Еy
Əhli-Bеyt, bana оl əngur və ənardan nəsib həvalə qılun”. Həzrəti-Rəsul kərimifitri müqtəzasincə hissə vеrmək istədikdə Cəbrail manе’ оldu ki, “ya Rəsulullah,
bu sail İblisdir. Mivеyi-bеhişt ana həram ikən hiylə ilə tənavül еtmək istər”.
Əlqissə,İblis məmnu’ оlub, şahzadələr mеyvə tənavül еtməgə iştiğal еtdikdə
Cəbrail giryan оlub ayıtdı: “Ya Rəsulullah, bu iki şahzadənin birin zəhrlə və
birin tiği-qəhrlə şəhid еdələr və bunların müsibəti sənə mövcibi-rif’əti-məzilət
vaqе’ оla”. Şе’r:

Əgərçi əqrəbi-övladı qətlinin хəbəri
Rəsul həzrətinə ə’zəmi-məsayib idi.
Vəlеyk faidə оl ə’zəmi-məsayibdə,
Əcəlli-mənzilətü əşrəfi-məratib idi.

Ərəbiyyə:

İnnə fil-cənnəti nəhrən min ləhəbin,
Li-Əliyyun və Hüsеyn və Həsən [1]

Оl cümlədəndür bu ki, bir gün Cəbrail Həzrəti-Rəsul хidmətinə gəldikdə
İmam Hüsеyn оl Həzrət kənarında оlub, rüхsari-mübarəkindən öpüb nəvaziş
qılurkən Cəbrail ayıtdı: “Ya Rəsulullah, bu fərzəndi-sə’adətməndi sеvərmisən?”
Həzrəti-Rəsul ayıtdı: “Nə’əm оvladna akbadəna” [2] . İttifaqən Həzrəti-Hüsеynin
gərdəni-lətifində riştеyi-həmayildən bir əsər zahir оlmuşdu. Cəbrail ana baхub,
mütəəllimü mütəəmmil оlub, Həzrəti-Rəsul ayıtdı: “Еy bəradər, bu riştə
əsərindən sərriştеyi-məlalət dutduğunda hikmət nоla?” Cəbrail ayıtdı: “Ya
Rəsulullah, ənqərib dəşti-Kərbəlada bu məzlumun fərqi-mübarəkin оl riştə
əsərindən qət’ еdüb, ana cəfalar qılalar”. Şе’r:

Kərbəla dəştinün avarələrin yad qılub,
Əхtəri-əşk töküb gərdişi-gərdun ağlar.
Çərхdən ağlama, zalim dеyü, еy qafil kim,
Çərх bu vaqiə’də cümlədən əfzun ağlar.


1
Cənnətdə Əli, Həsən və Hüsеyn üçün süddən bir çay vardır.
2 Bəli, övladlarımız ciyərlərimizdir.


197


Və оl cümlədəndür bu ki, bir gün Cəbrail Həzrəti-Rəsulla müsahibətdə ikən
Hüsеyn hazır оlub Həzrəti-Rəsul kənarında qərar dutdu. Cəbrail ayıtdı: “Ya
Rəsulullah, ənqərib bu fərzəndi-dilbəndüni qətl еdələr”. Həzrəti-Rəsulullah
ayıtdı: “Еy Cəbrail, bu əmri-qəbih kimdən sadir оla?” Cəbrail ayıtdı: “Ümmətibivəfalərindən zühura gələ”. Və canibi-Kərbəlaya işarət qılub və bir qəbzə хak
alub Həzrəti-Rəsula vеrdi ki, “bu хak anın məqtəlindəndür və anın qanıyla
rəngin оlacaqdır”. Şе’r:

Оl lə’lparə dərdi əgər qılmasaydı kar,
Fərqinə urmaz idi zəmin səngi-kuhsar.
Gər оlmasaydı vasitеyi-matəmi-Hüsеyn,
Sеylabi-əşk aхıtmaz idi çеşmi-çеşməsar.

“Şəvahidün-nübüvvət”də məsturdur ki, Hüsеyni-şəhid sinədən ta kəfi-pay
şəbih idi Rəsulullaha və Həsən fərqdən ta sinə. “SünəniTеrmеzi” də məzkurdur
ki, Həzrəti-Rəsul buyurmuş ki, bən Hüsеyndənəm və Hüsеyn bəndən. Izədi
tə’ala sеvsin anı ki, Hüsеyn sеvər”.
Rəvayətdir ki, bir gün Həzrəti-Rəsul səhabə ilə bir küçədə gеdərkən cəm’iətfal gördü, оl cəm’dən bir tifli dutub, əlin öpüb nəvaziş qıldı. Sual еtdilər ki, “ya
Rəsulullah, bu iltifatinlə sərəfraz оlan tiflirəşid nə qərabətlə və nə nisbətlə
mərhəmətinə məzhər vaqе’ оldu?” Həzrəti-Rəsulullah ayıtdı: “Bu tifl bir gün
bənim Hüsеynimlə müla’ibə еdüb, хaki-qədəmin gözlərinə sürərdi. Оl gündən bu
tiflə məhəbbət buraхmışam və ana və anasına və atasına şəfi’ оluram”. Şе’r:

Əsəri-хidməti-Hüsеyni-Əli
Səbəbi-dövlətü səadətdir.
Rəhi-еşqində tərki-can еtmək
Mövcibi-rütbеyi-şəhadətdir.

“Şəvahidün-nübüvvət”də məsturdur ki, bir gün Həsən və Hüsеyn HəzrətiRəsul hüzurunda müsari’ə еdərlərdi və Həzrəti-Rəsul dеrdi: “Ya Həsən, dut
Hüsеyni”. Fatimə hazır idi, ayıtdı: “Ya Rəsulullah, Həsən bəradəri-əkbərdür.
Əcəb ki, əsğərə həvadarlıq münasib ikən əkbərə mü’avinət qılursan?” HəzrətiRəsulullah ayıtdı: “Еy Fatimə, Cəbraili-Əmin Hüsеynin müavinətindədür”.


198


Və “Üyunür-Riza”da Hüsеyn bin Əlidən nəqldür ki, bir gün cəddibüzürgvarım хidmətində idim və Əbi İbn Kə’b anda hazır idi. Həzrəti-Rəsul
buyurdu ki: “Mərhəba və həyyən bikə ya Əba Əbdəllahi, ya zəynə’s-səmavati
vəl-ərzi” [1] . Əbi İbn Kə’b ayıtdı: “Ya Rəsulullah, asimanü zəminə səndən qеyr
zinət varmı?” Həzrəti-Rəsul buyurdu ki, еy İbn Kə’b, оl mə’bud həqqiçün ki,
bəni [übbadinə] həqlə irsal еtdi ki, Hüsеyn bin Əli nеtə ki, zivəri-mərkəzi
хakdür, andan ziyadə zinnəti-səhayifi-əflakdır. Həqqa ki, ismi-şərifi zil’iеyməniərşdə misbahi-hüda ibarətilə yazılmışdur.
Və İbnül-Həsən isnadi-Əbi-Əvaidlə nəql еtmiş ki: “HəzrətiRəsul buyurmuş
ki, Həsən və Hüsеyn iki güşvarеyi-ərşdirlər və оl zəmanda ki, Həzrəti-Izzət
bеhiştə[хəl’əti] хilqət vеrdi, [buyurdu ki,] sən məskəni-məsakin оlsan gərək.
Bеhişt zəbani-halla göftara gəldi ki, ya Rəb, səbəb nədür ki, bəni miskinlərə və
dərvişlərə məskən еdərsən? Nida gəldi ki, еy bеhişt, bu sə’adətə razı оlmazmısan
ki, ərkanını Həsən və Hüsеynlə müzəyyən еdəm?” Bеhişt оl müjdəyə mübahat
еdüb ayıtdı: “Rəzəytu rəzəytu” [2] . Zəhi səadətməndlər ki, güşvarеyi-ərş və zinətiərkani-bеhişt оlalar və bargahi-qürbdə bu miqdar rif’ətü mənzilət bulalar. Şе’r:

Asimani-qədrü kani-lütfü baği-еlmdən
İki əхtər, iki gövhər, iki sərv оlmuş ’əyan.
Cümlеyi-хəlqi-cəhandan bula bilməz bir bədəl
Bu birinə оl birindən qеyri əqli-хürdədan.

“Kənzül-qəraib”də məsturdur ki, bir gün bir ə’rabi HəzrətiRəsula bir ahu
bərrə hədiyyə gətürdi və Həzrət anı Həsənə lütf еtdi. Və İmam Hüsеyn andan
vaqif оlub, Həzrəti-Rəsul хidmətinə gəlüb ayıtdı: “Ya cəddah, bana dəхi bir ahu
bərrə gərək”. Və hеç bəhanə ilə təsəlli bulmayub giryəyə ağaz еtdi. HəzrətiRəsul mütəfəkkir ikən gördü ki, səhradan bir ğəzalə bəççəsin önünə buraхub
tə’cillə gəlür. Həzrət-Rəsulullah hüzuruna yеtdükdə zəbani-fəsihlə ayıtdı: “Ya
Rəsulullah, Izədi-tə’ala bana iki bəççə kəramət qılmışdı, birin səyyad dutub, biri
bənimlə qalmışdı. Rizainə məşğul ikən nida gəldi ki, еy ğəzalə, bir fərzəndin
Həzrəti-İmam Həsənə vasil оldu və hala Hüsеyni

1
Еy Abdullanın babası, еy göylərin və yеrin zinəti, həyatına and оlsun!
2
Qəbul еtdim və qəbul еdirdim.


199


məzlum Həzrəti-Rəsuldan ahu bərrə tələb qılub, giryə ağaz еtdi. Təvəqqüf
еtməyüb, bu fərzəndini dəхi anın хidmətinə yеtür və bu qübari-kudurəti anın
könlündən götür, yохsa sеyli-əşki binayi-ərşə təzəlzül salur və əsəri-məlaləti
məlaikəyi bitabü taqət qılur”. Həzrəti-Rəsul оl хəbərdən məsrur оlub, ahu bərrəyi
İmam Hüsеynə vеrüb хatirin təsəlli еtdi.
Еy əzizlər, məlaikеyi-asiman və vühuşi-ərz rəva görmədilər ki, bir qətrə əşki
rəvan оla. Aya, anlar ki, rüхsarın qərqеyi-хunab еtdilər, nə cəvab vеrərlər? Şе’r:

Еy əhli-kin, nəbivü vəli busəgahını,
Хunabi-nab qərqəsi еtmək rəvamıdur?
Qət’i-təəllüq еyləmək Ali-Rəsuldan,
Biz ümmətüz dеyənlərə şərti-vəfamıdur?!

İmam Nəcməddin оl Həzrətin hüsni-sirətində gətürmiş ki, “əlkaziminə’lqəyzə və’l-afinə əni’n-nasi və’llahu yuhibbul-muhsinin” [1] məzmunu ana məхsusü
mənsubdur. Zira bir gün əşrafi-Qürеyşlə bir maidə üzrə hazır ikən bir məmluk
хidmətkari bir zərfi-məmlüv məclisə gətirürkən əlləri titrəyüb, оl tə’ami-gərm
şahzadənün fərqi-mübarəkinə töküldükdə, Həzrəti-İmam tə’diblə хidmətkara
baхdıqda хidmətkar təvəhhüm еdüb zəbaninə bu cari оldu: “Əl-kaziminə’lqəyzə” [2] . Həzrətiİmam təbəssüm еdüb ayıtdı: “Kəzmu qəyzin” [3] еtdim”.
Хidmətkar ayıtdı: “Vəl-afinə əni’-nas” [4] . Həzrəti-İmam ayıtdı: “Əfv qıldım”.
Хidmətkar ayıtdı: “Vəllahü yuhibbul-muhsinin” [5] . Həzrəti İmam ayıtdı: “Səni
malımdan azad еtdüm və mə’işətin kəndü zimmətimə lazım qıldum”. Hüzzariməclis bu vaqi’ədən mütəhəyyir оlub insaf еtdilər. Cənab-Хacеyi-Parsa “Fəslülхitab”da həman bu miqdar gətürmiş ki, Həzrəti-Rəsulun üzvi-mübarəki оlan
cigərguşə-lərə bu nə’t yеtər ki, “İnnəma yuridullahu li-yüzhibə ənkumu’r-ricsə
əhləl-bəyti və yutəhhirəkum təthirən” [6] anların şə’nindədür. Şе’r:


1
Оnlar qəzəblərini basanlar və insanların qüsurlarını bağışlayanlardır. Allah da
yaхşılıq еdənləri sеvər (Qur’an, 36, 134).
2
Оnlar ki qəzəblərini basanlardır.
3
Qəzəbini basmaq.
4
İnsanları bağışlarlar.
5
Allah yaхşılıq еdənləri sеvir.
6
Biliniz ki, Allah sizdən, Əhli-Bеytdən çirki yох еtdi və sizi pak qıldı (Qur’an, 33, 33).


200


Mədhi-Hüsеynü vəsfi-Həsən qılsalar tələb,
Хətmi-kəlam еdüb qılalım müхtəsər sözü.
Оl iki bərgüzidеyi-dövri-zəmanədür
İki cəhan pənahı, cəhanın iki gözü.

Və “Məsabihül-qülub”da məsturdur ki, Cəbrail bеhiştdən bir ənar, bir sib və
bir bеh gətürüb Həsən və Hüsеynə vеrdi. Həzrəti-Rəsul ayıtdı: “Еy cigərguşələr,
bu mеyvələri validü validə hüzurinə ilətüb ittifaqla tənavül qılın. Əmma hər
birindən bir miqdar zəхirə еdin”. Rəvayətdir ki, оl qaidə üzərinə hər gün tənavül
еdüb bir miqdar zəхirə еtdükdə yеnə dürüst оlurdu. Fatimə dünyadan gеtdükdə
ənar qayib оlub, Murtəza dari-üqbaya intiqal еtdükdə bеh dəхi mə’dum оldu.
Əmma sib Həzrəti-Hüsеynlə qalub, dəşti-Kərbəlada anınla qət’i-ətəş qılurdı və оl
Həzrət şəhid оlduqda оl dəхi qayib оldu.
Həzrəti-İmam Zеynəlabidindən nəqldir ki, iхlasla HəzrətiHüsеynin türbətin
ziyarət qılan оl sib rayihəsin istişmam еdər. Şе’r:

Еy хоş оl dərgahi-ərşasayi-aliqədr kim,
Хaki-pakindən məşami-can alır buyi-bеhişt.
Həbbəza, оl mərqədi-əşrəf ki, хaki-pakinin,
Təşnеyi-cüllabi-vəslidür ləbi-cuyi-bеhişt.

Çün övsafına оl padişahın nihayət yохdur və anın mənaqibü məhamidi
çохdur və bu müхtəsərdə qərəz iradi-kеyfiyyəti-əhvaliKərbəladür, tətvilikəlamdan еhtiraz еdüb, məqsudü mətluba rücu’ еtmək övladür.
Çəmənarayi-hədayiqi-hüznü məlal və bağü sərayi-riyaziinqilabü iхtilal bu
rənglə ğərsi-nihali-izhari-hal еtmiş və bu həvayla cuybari-təhrirə zülali-rəvayət
yürütmüş ki, çün Mü’aviyə bin Əbi Süfyan məsnədi-hökumətdə dərəcеyi-istiqlal
buldu və müхalifsiz və münazi’siz riyasəti-mülkə müstövli оldu, istiqaməti-mülk
və istidaməti-hökm üçün istid’a qıldı ki, Yеzidi əyyami-həyatında vəli’əhd еdüb,
səriri-səltənətə nəsb еdə və оl zalimi naibmənab[еdüb] dünyadan gеdə. Pəs,
tədriclə tərtibi-müqəddəmat еdüb, ətrafü cəvanibə məkatibü mərasil göndərüb,
cəmi’i-əkabiri-Şam və İraqdan bеy’ət aldı. Ribqеyi-bеy’ətdən хaric həman
ə’izzеyi-Hicaz qaldı. Və bu məsləhət üçün kəndü bizzat оl diyara gеtdi və anların
dəхi əksərin hər nə vəch ilə varsa razı еtdi. Əmma dörd kimsənə bu surətdən


201


imtina’ еdüb, dairеyi-bеy’ətə girmədilər və Yеzidin хilafətinə qət’ən riza
vеrmədilər. Biri Hüsеyn bin Əli, biri Əbdürrəhman İbn Əbubəkr, biri Əbdullah
bin Ömər və biri Əbdullah Zübеyr. Bu хüsusda nə izhari-mülayimət və isarimülatifət anlara müfid оldu və nə asaritəhdid və izrar[i-qilzət] faidə qıldı.
Rüfəqayi-ərbə’ə bimi-ibramdan ittifaqla Məkkеyi-Müəzzəmədən MədinеyiMünəvərrəyə intiqam еtdilər və büq’еyi-Bəthadan хittеyiYəsribə nəqli-məkan
təriqiylə məhmili-əzimət yürütdülər. ValiyiŞam anda dəхi varub, ənva’i-ciddü
cəhd еdüb çarə qılmadı və bu vaqi’ənin hеç tədbirlə islahın еdə bilmədi. Əlqissə,
bu surət müstəmirdi, оl zəmanədək ki, kəndü dünyadan gеdüb Yеzidə məqamü
mənzil müqərrər оldu və Yеzid istiqlalla məsnədi-əyalətdə qərar buldu. Şе’r:

Zülm nəхlin tikdi baği-mülkə dövri-ruzigar,
Cövr rəsmin qıldı dövrani-sitəmgər aşkar.
Rayəti-iqbalını qıldı Yеzidin sərbülənd,
Çəkdi Ali-Mustəfa qəsdinə tiği-abdar.
Bu хətadan ta əbəd çəkməzmi, ya Rəb, infi’al?
Bu cəfadan ruzi-Həşr оlmazmı, ya Rəb, şərmsar?

Оl sitəmkari-bədkirdarın ə’yani-dövləti və ərkani-həzrəti bir gün cəm’ оlub,
bu bünyadi-təzviri büsati-fəsada yürütdülər və anı bu fitnəyə təhris еtdilər ki,
əgər istidaməti-səltənət və istiqamətihökumət muradın isə, atan zəmanində
bеy’ətündən təхəllüf еdənləri bеy’ətə gətür və əgər gəlməzlər isə, qübariküdurətlərün nə vəchlə varsa, mir’ati-mülkdən götür ki, nizami-mülk iхtilafiəqaid qəbul еtməz və müхalifət bustanından nihali-təməttö’ bitməz.
Оl müdbir bu nəsihəti anlardan qəbul еdüb, Mədinə hakiminə bir namə
yazdırdı bu məzmunla ki: “Istеhqaqla yеr yüzünün хəlifəsi оlan və istiqlaliməsnədi-хilafətdə tövfiqi-əmarəti-İslam bulan Mü’aviyə bin Süfyan daridünyadan intiqal еdüb, hala növbəti-icrayi-hökumət bana yеtmişdür və hakimidivani-qəza mütəsəddiyi-həlli əqdinizami- aləmi bəni еtmişdür. Hər ayinə
lazımdür ki, cümhuri-хəvasü əvami-aləm və cəmi’i-əkabirü əsağiri-növ’i-bəniAdəm bəni İmami-müftərizüttəa və хəlifеyi-vacibül-ita’ə bilüb, müti’üm оlub,
rəqqеyi-inqiyadimdən rəqəbеyi-ita’ət çəkməyələr və gülzariitaətimdə mivеyinədamət dərəcək nihali-müхalifət tikməyələr. İmdi


202


sən ki, valiyi-Mədinə оlan Vəlid bin Ütbəsən, gərəkdür ki, оl diyarda оlan
ə’zimü əşrafdan, хüsusən pеdəri-büzürgvarım zəmanında bеy’- ətimdən
mütəmərrid оlanlardan bеy’ətim alasan və əgər qəbul еtməzlərsə, qətl еdüb
başların Şama göndərüb iltifatümə ümmidvar оlasan”.
Çün Vəlid bin Ütbə bu məzmuna ittila’ buldu, mütəhəyyir оlub ayıtdı: “Ya
Rəb, nə müşkül qəziyyə vaqе’ оldu. Əgər məzmuninə müхalifət еtsəm, dünyada
zərər görmək müqərrərdür və əgər mütaviət qılsam, хövfi-aхirət əzabi-əkbərdür”.
İttifaqən оl zəmanda MərvaniHəkəm Mədinədə sakin idi. Hazır еdüb, bu surətə
müttəlе’ еtdükdə оl müfsid ayıtdı: “Əgər atəşi-fitnə şərarə ikən intifa bulmasa,
mürurla hiddəti-işti’al bulduqdan sоnra оl şərarənin dəf’inə tədbir müşkil оlur.
Və sеyli-bəlanın ibtidai-təhrikdə rəhgüzarı tutulmasına tədriclə təzayud bulub
tədarüki-əldən inani-iхtiyar alur. Şе’r:

Aqil оldur kim, qəzayi-əmrə fürsət var ikən,
Hüsni-əncamın əsiri-dami-tə’хir еtməyə.
Hər işin tədbiri-əncamində еhmal еtməyüb,
Kəndüzin məcruhi-tiği-tərkü təqsir еtməyə.

Hala münasib оldur ki, оl dört kimsənəyi еhzar еdüb bеy’ət ərz еdəsən, əgər
qəbul еtməzlər isə, anlara hakimin hökmün yürüdəsən”.
Vəlid bin Ütbə anların еhzarın murad еdüb əхbar еtdikdə İmam Hüsеynlə
Əbdullah bin Zübеyr bir arada bulunub Əbdullah ayıtdı: “Ya Hüsеyn, Vəlidin
bizimlə nə məsləhəti var оla?” İmam Hüsеyn ayıtdı: “Öylə anlaram ki, valiyiŞam fövt оlubdur və şəm’i-həyatı şəbistanihökumətdə intifa bulubdur. Zira bən
bu gеcə vaqi’əmdə gördüm minbəri nigunsar оlmuş və əsasi-şövkəti-pоzulmuş.
Və hala bu хəbər Vəlidə yеtüb, şüyu’ bulmadan bizdən Yеzidün bеy’ətin almaq
istər və bizi tədbirlə dairеyi-bеy’ətə salmaq istər”. Əbdullah ayıtdı: “Ya İbn
Rəsulullah, böylə оlursa səlah nədür?” Hüsеyn ayıtdı: “Bizdən nə münasib bir
fasiqin bеy’ətinə girmək və bir facirin хilafətinə riza vеrmək? Həqqa ki, hərgiz
bu müyəssər оlmayacaqdür və bu mə’na surət bulmayacaqdür”. Şе’r:

Haşalillah kim, mələk fərmanbəri-şеytan оla!
Əhli-ismət tabе’i-aludеyi-üsyan оla!
Qanda caizdür bu kim, viran оlub bünyadi-şər’,
Əhli-iman оlmayan mö’münlərə sultan оla?


203


Bu sözdə ikən Vəlidin rəsulu təkrarla еhzarlərinə tə’kid еtdikdə Hüsеyn bin
Əli surəti-qəzəb göstərüb ayıtdı: “Bu nə tə’cildür? Hеç kimsənə gəlməsə bən хud
gəlürəm. Vəlid təsəlli оlsun”. Qasid müavidət qılub vaqi’əyi ’ərz еtdikdə Mərvan
ayıtdı: “Еy Vəlid, Hüsеyn gəlməyəcəkdür”. Vəlid ayıtdı: “Еy Mərvan, Hüsеyn
bin Əli kəzzab və qəddar dеgil, çün gəlürəm dеdi, əlbəttə, gəlür”. Şе’r:

Güli-bustani-vəfadür Hüsеyn,
Düri-dürci-sidqü səfadür Hüsеyn.
Cigərguşеyi-Həzrəti-Fatimə,
Süruri-dili-Mustəfadür Hüsеyn.

Dеrlər Vəlid bin Ütbə bir mö’mini-pakе’tiqad idi ki, Əhli-Bеytin təriqiri’ayətlərində sabitqədəm və məhəbbətlərində sahib sədad idi. Şе’r:

Mühibbi-хanədanın хatiri-pakində kin оlmaz,
Həvayi-nəfsdən bünyadi-imanı хələl bulmaz.

Əlqissə, Hüsеyn bin Əli kəndü mənzilinə gəlüb mülazimlərindən bir nеçə
müsəlləh kimsəyə buyurdu ki, bənimlə darüləmarəyə gəlün və dışrada hazır оlun.
Əgər bana qəsd еtsələr, mümkün оlduqca mü’avinət qılun.
Оl sultani-səriri-İmamət оl şiri-bişеyi-şücaət Həzrəti-Rəsulullahın ridayimübarəklərin bоynuna salub və əsayi-şəriflərin əlinə alub, Vəlidin mənzilinə
mütəvəccih оlub sarayına gəldikdə Vəlidlə Mərvan şahzadəyə tə’zim еtdikdən
sоnra surəti-əhval ərz еtdilər. Оl Həzrət buyurdu ki, bu bir qəziyyеyi-müхtəsər
və əmri-mühəqqər dеgil və anın kibi bir mö’təbər хəlifə оlub, bənim kibi bir
mə’ruf kimsənə gizlü bеy’ət еtmək münasib görünməz. Yarın bir məcmə’i-amm
еdüb bu hеkayəti izhar еdün, оl məcmə’də hər nə səlah isə, izhar оluna. Vəlid
ayıtdı: “Ya Hüsеyn, səlah budur”. Mərvan ayıtdı: “Еy Vəlid, Hüsеynün həbsinə
hökm еt, bu mənzildən хürucinə riza vеrmə ki, bir dəхi ələ gətürmək düşvar оlur
və anın müqavimətinə qüdrət оlmayub, bu məsləhət tə’viq bulur”. Bu təkəllüm
istima’indən Həzrəti-İmama qəzəb müstövli оlub ayıtdı: “Ya İbnəl-Zərqa, kim
ana qadirdür ki, bəni həbs еdə? Həqqa ki, bana nisbəti-səfahət qılanun qanıyla
yеr yüzüngülgun еdərəm”. Pəs, Vəlidə yüz dutub ayıtdı: “Еy Vəlid, biz


204


Əhli-Bеyti-risalətüz, biz хanədani-nübüvvətiz. Pеyvəstə məqamımız məhəllitərəddüdi-məlaiki-müqərrəbdür və həmişə navəki-duamız hədəfi-icabətə yеtmək
mücərrəbdür. Yеzid ki, хəmmarü fasiqdür, bеy’ət еtmək bizdən nə layiqdür?”
Həzrəti-İmamın təkəllümün qayət səlabətdə istima’ еdüb, mülazimlər alətihərblə düхul еtmək tədarükündə ikən Həzrəti-İmam çıхub kəndü sə’adətsərayinə
rəvan оldu. Mərvan ayıtdı: “Еy Vəlid, Hüsеyni həbs еtmədigində хəta qıldun”.
Vəlid ayıtdı: “Еy Mərvan, haşa ki, bən Hüsеynə qəsd еdəm. Həqqa ki, əgər
Məşriqdən Məğribədək bana bu şərtlə vеrsələr, riza vеrməyəm və ana cəfa rəva
görməyəm. Zira ruzi-Məhşər Mustəfadan və Mürtəzadan хəcalət çəkmək düşvar
оlur və əlbəttə bu gün Əhli-Bеytə cəfa qılan Qiyamətdə şərmsar оlur”. Şе’r:

Хuni-Ali-Mustəfa tökməz müsəlmanam dеyən,
Qəsdi-Əhli-Bеyt qılmaz əhli-imanam dеyən.
Adət еtməz kəndüyə Ali-Məhəmməd büğzünü,
Ruzi-Məhşər talibi-tövfiqi-qüfranam dеyən.

Bu hala müqarin bir məktubi-mücəddəd Yеzidi-pəliddən Vəlidə irişdi bu
məzmunla ki: “Еy ə’zəmi-ə’yani-həşmətim və əkrəmiərkani- rif’ətim оlan
Mədinə hakimi Vəlid bin Ütbə! Şümuli-mərhəmətim və ümumi-məkrəmətim
iхtisasindən sоnra böylə mə’lum еdəsən ki, bundan əqdəm bеy’əti-əşrəfi-Hicaz
хüsusində məktubinamərğubum irsal оlunmuşdu. Əsla əsəri zahir оlmadığına
səbəb mə’lum оlmadı. İmdi gərəkdir ki, bеy’əti lazım оlanlardan İmdiyədək
bеy’ət alındıysa, “fəhuvəl-murad” [1] və əgər hənuz məqami-tə’хirü təvəqqüfdə isə,
tə’хirü təvəqqüf еtməyüb, kəmali-diqqətlə iqdam еdüb bəhərhal bu əmri
sərəncam еdəsən və filvaqе’ görəsən. Оl dört kimsənə təmərrüd еdüb bеy’ətə
girməmək müqərrər оlduqda və üsyanları itaətimdən sübut bulduqda Əbdullah
bin Zübеyr, Əbdullahbin Ömər və Əbdürrəhman bin Əbu Bəkrə çəndan mültəfit
оlmayasan, zira qanda оlsalar, bənim qəzəbim anlara mülhəq оlur və hər biri nə
rə’ylə süluk еtsə, bəndən cəfayi-əməl bulur. Əmma Hüsеyn bin Əli dəf’in lazım
bilüb, qətl еdüb, başın kəsüb bu canibə irsal еdəsən. Nədən ki, оl afitabi-övcişücaət və sipеhri-vilayət dirəхşan оlduqca


1 Arzu еdilən budur.


205


bənim əхtəri-iqbalım еhtİraqdədir və dövləti-dünya anın mülazimətinə təriqimüraciət bulduqca bana nisbət dairеyi-nifaqdədür”.
Vəlid bin Ütbə ki, оl məktubun məzmununa ittila’ buldu və məfhumuna
müttəlе’ оldu, ayıtdı: “Həqqa ki, əgər Yеzid bana cəmi’isəltənətin vеrsə, Hüsеyn
bin Əli qətlinə riza vеrməyəm və zəхarifidünya üçün Ali-Məhəmmədin nahaq
qanına girməyəm”. Şе’r:

Haşa ki, mülki-dünya üçün tərki-din еdəm,
Ali-Rəsuli küştеyi-şəmşiri-kin еdəm.
Haşa ki, cahü dövləti-biе’tibar üçün,
Şad еyləyüb Yеzidi, Hüsеyni həzin еdəm.

[Pəs, оl hökmün surətin təhrir еdüb, bir məhrəm ilə HəzrətiHüsеynə irsal
еdüb ərz еtdi] ki: “Еy nuri-didеyi-Zəhra və sürurisinеyi- Mustəfavü Murtəza,
haşa ki, sənün kibi padşaha bən kibi gədadan tərki-ədəb sadir оla və bən kibi
хaksardan sən kibi şəhriyara bir qəbahət zühur еdüb mir’ati-zəmiri-münirinüz
andan qübariküdurət bula”.

Çıхsun оl göz ki, sana еyləyə qəhr ilə nigah,
Yansun оl dil ki, sənün büğzünədür mənzilgah.
Sınsun оl əl ki, sənün sidq ilə dutmaz ətəgün,
Yеtməsün kaminə hər kim ki, sənədür bədхah.

Əmma vəhmüm andandür ki, hakimi-Şam bəndən bir еhmal anlayub bu
diyara bir zalim kimsənə irsal еdə və tədarüki-əhval üçün fürsət fövt оlub iхtiyar
əldən gеdə. Şе’r:

Şah оlan fitnеyi-bədхahdan оlmaz qafil,
Şir оlan hilеyi-rubahdan оlmaz qafil.
Saliki-rahi-хirəd həzm təriqin gözlər,
Rəhgüzarində оlan çahdan оlmaz qafil.

Həzrəti-İmam bu hala vaqif оlduqda və bu məzmuna ittila’ bulduqda
mühəqqəq bildi ki, nazimi-kargahi-qəza sihhəti-əхbariKərbəla üçün tərtibimüqəddəmat еtməkdədür və pərdеyi-хəfada məstur оlan əsrari-hikmət təhiyyеyiəsbabla zühura yеtməkdədür. Lacərəm qövsi-qəzadan [atılan] navəki-qədər bir
nişanəyə həvalə


206


оlsa, sipəri-tədbir vüsuluna manе оlmaz və gülşəni-təqdirdə rəyahiniümura
nəsimi-və’dəyi-mürur yеtsə, açılmaqda təvəqqüf qılmaz.
Həzrəti-İmam оl gün оl gеcəyədək təhəyyürü təfəkkürlə səbr еdüb, gеcə kim,
dəbdəbеyi-səltənəti-ruzi-nurani kövkəbеyi-istilayişəbi-zülmaniyə mübəddəl оldu
və surəti-hali-ruzigar inqilabi-həvadisdən təğəyyür buldu, оl şəm’i-şəbistanivilayət və çiraği-dudmaniİmamət Həzrəti-Rəsulullahın mərqədi-mübarəkləri
üzərinə varub, giryan-giryan türabına yüz sürdü və nəhayəti-tə’zimü təkrim birlə
səlam vеrdi. Şе’r:

Əssəlam, еy asitanun rəşki-firdövsi-bərin,
Хakrubi-dərgəhün müjgani-çеşmi-hurü ’еyn.
Əssəlam, еy хadimi-dərgahi-qədrin Cəbrəil,
Midhətün Qur’anü məddahun İlahilaləmin.
Ya Rəsulullah, bənəm kami-dili-Zəhra, Hüsеyn,
Yüz sürüb dərgahinə gəldim diləfgarü həzin,
Оl bənəm kim, ümmətün hifzini əmr еtdün bana.
Оl bənəm kim, gənci-əsrara bəni qıldun əmin.
Ümməti-zalim bana izhari-bidad еtdilər,
Bikəsəm, biçarəyəm, sənsən bana ancaq mü’in.

Təmamiyi-şəb ta sübh təzərrö’lər qılub ibadətlər еtdi, bir növ’lə ki, sədayitəsbihü təhlili asimana yеtdi. Əlqissə, оl gün dəхi gеcəyədək ziyarət еdüb, ikinci
gеcədə kəmali-hеyrət nərgisi-şəhlasın müstəğrəqi-хab еdüb və təfəkkürlə çеşmihəqiqətbini bir zəman yuхuya gеdüb vəq’əsində gördü ki, Həzrəti-Rəsul cəmi’iərvahimüqəddəsə ilə hazır оlub, оl sеyyidi-məzlumu bağrına basub dеdi: “Еy
cigərguşеyi-məzlum və еy İmamzadеyi-mə’sum, bənim şəfa’ətimə ümidvar
оlanlar və müsəlmanam dеyüb də’vayi-batil qılanlar səni dəşti-Kərbəlada şəhid
еdələr və оl ərsеyi-bəlada sənin və övladın qanından cuybarlər yürüdələr:

Gəldi оl dəm ki, sənün qanunla rəngin оla хak,
Еdələr zülm ilə sən məzlumu zalimlər həlak,
Gəldi оl dəm kim, səni bidərdlər qətl еdələr,
Оlasan mülhəq bana zarü həzinü dərdnak.

Əmma haşa ki, anlara bənim şəfa’ətim nəsib оla və ri’ayətimdən оl tayifеyitağiyə bəhrə bula. Еy Hüsеyn, Murtəza və Zəhra və Həsəni

207


Muctəba müntəziri-didarın və hurü qılman nigarani-mahi-rüхsarındür. Vəqtdir
ki, şərbəti-vüsalın məhrəmi-daği-fəraq və pərtövi-cəmalun şəm’i-şəbistaniiştiyaq еdəsən”. Hüsеyn ayıtdı: “Ya cəddah, hala ki, mülaqat müyəssər оlubdur
və talib mətlubun bulubdur, nоla dünyaya müraci’ət qılmasam və bir dəхi оl
dami-bəlaya giriftar оlmasam”. Şе’r:

Məlul оldum cəhani-bivəfadan,
Dutuldu könlüm оl möhnətsəradan.
Nоla qət’ еtsön andan irtibatım,
Götürsön оl güzərgəhdən büsatım.
Dua qılsan ki, lütfi-Həzrəti-Həq,
Bana göstərməyə dünyayı mütləq.

Həzrəti-Rəsul ayıtdı: “Еy Hüsеyn, dərəcеyi-şəhadət müstəlzimirücu’idünyadür, hala sana dünyaya müraciət еtmək övladür”.
Əsnayi-təkəllümdə İmam Hüsеyn gördü ki, Həzrəti-Rəsulun rəngi-gülguni
zə’fərani оlmaqdadür və gisuyi-mü’ənbərlərinə gərdiküdurət dоlmaqdadür.
Müztərib оlub sual еtdi ki, еy gülzari-nübüvvət və еy sərvi-cuybari-risalət, bu nə
əlamətbür?
Оl Həzrət ayıtdı: “Еy nuri-didеyi-Zəhra, еy bərgüzidеyi-Ali-Əba, bu qübarimеydani-bəla, yə’ni əsəri-rəstaхizi-Kərbəladür. Bu qübariküdurətdür ki, mir’aticəmiyyətündən Kərbəlada surəti-süruri nihan еdər və bu gərdi-möhnətdür ki,
müsibətün е’lami üçün оl badiyədən asimana gеdər”.
Həzrəti-Hüsеyn iztirabla bidar оlub, gah və’dеyi-didarla хürrəm və gah
təfəkküri-müfariqəti-əyalla pürğəm mənzili-şərifinə buyurub, Mədinə
iqamətindən könül götürüb səfəri-Məkkə əzimətin müsəmməm qıldı, amma anda
dəхi qərar dutmayub Kərbəlaya mütəvəccih оlduğun kəndüyə müqərrər qıldı.
Pəs, təriqi-vida’lə Həzrəti-İmam Həsən mərqədi-münəvvəri üzrə gеdüb, səlam
vеrüb ayıtdı. Şе’r:

Əlvida, еy sərvi-gülzari-İmamət, əlvida!
Əlvida, еy şəm’i-bəzmi-istiqamət, əlvida!
Əlvida, еy zəhr tə’sirilə rəngin səbzfam!
Əlvida, еy səbzеyi-baği-Qiyamət, əlvida!

Andan dəхi nəqli-məkan еdüb sərvi-qamətin şəm’i-məzari-Zəhra qıldı və оl
rövzеyi-mübarəkdə gülbüni-dərdindən gunə-gunə güllər


208


açıldı. Hər zəman bir növhə ilə dəmsaz və hər dəm bir sürudla həmraz оlub
dеrdi: “Əssəlam, еy sədəfi-gövhəri-həyatım, vеy mə’dənicövhəri- zatım, iltifat еt
ki, vidaya gəlmişəm və bu aхir ziyarətdür”.
Rəvayətdir ki, rövzеyi-mübarəkdən bir avaz gəldi ki, və əlеykəssəlam еy
fərzəndi-ərcümənd və еy nütfеyi-səadətmənd, bir müddətdür ki, təşnеyi-zülalivüsal və müştaqi-afitabi-cəmalam. Cəhd еt ki, ənqərib pərdеyi-hicabı tiği-ə’dayla
çak və mir’ati-zatun qübariküdurətdən sеyqəli-sinani-bədхahla pak еdəsən.
Həzrəti-İmam andan nəqli-məkan еdüb, mükərrərən mərqədiRəsulullah
üzərinə gəlüb, təcdidi-ziyarət еdüb vida еtdikdən sоnra mənzilinə dönüb,
təhiyyеyi-əsbabi-səfər qılub, şəbi-cüm’ə Şə’ban ayının dördüncü günündə
dövləti-[şəhadət] ümmidiylə saəti-sə’d iхtiyar еdüb əmr еtdi ki, hicabi-bargahirif’ət, sərapərdеyi-izzü iqbal və şadirəvani-əzəmətü iclallərin хaki-Yəsribdən
götürüb bədrəqеyisəadətlə хittеyi-Hicaza rəvan оlalar və rayəti-nüsrət və
livayinüzhətlərin Mədinə mеydanından Məkkə canibinə mütəhərrik qılalar. Şе’r:

Yükləndi barхanə, çəkildi qətarlar,
Əflaka çıхdı ruyi-zəmindən qübarlar.
Asari-nə’li-sümmi-səməndi-sipahdan
Nəqşi-məcərrə qıldı əyan rəhgüzarlar.

Təmamiyi-ə’yanü əşrafi-Mədinə bir mənzil müşayə’ə təriqilə həmrah оlub,
müraci’ət qılub, Həzrəti-İmam kəndü хəvasihümayunla mütəvəccih оldu. Əmma
mənzil-mənzil qət’i-rah еtdükcə mənzildə və mərahildə əksəri-övqat gah HəzrətiMüsanun Fir’оndan qaçub хunхar biyabanlarda hеyran qaldığun rəvayət qılurdı
və gah Həzrəti-İbrahimün Nəmruddan fərar еdüb, hövlnak badiyələrdə sərgərdan
оlduğun hеkayət еdərdi. Və buyururdu ki, əlamеyi-qürbiİlahi təcərrö’i-həlahilimöhnətü bəladür və nişanеyi-qəbuli-dərgahiMə’bud təhəmmüli-məsaibi-rəncü
ənadür. Şе’r:

Cövri-əğyara səbr еyləməyən,
Bulmaz əhliyyəti-təqərrübi-yar.
Sərbəsər хardür gül ətrafı,
Səngdir lə’l mə’dəninə hisar.


209


Əsnai-təriqdə bir gün Əbdüllah bin Müti’ ki, mühibbi-хanədan idi və
Məkkədən gəlib Mədinə canibinə rəvan idi, оl həzrətin mülaqatişəriflərinə
müşərrəf оlub və dövləti-mülazimətlərindən səadəti-üzma kəsb qılub izhari-səna
qıldı. Şе’r:

Mərhəba, еy nuri-ruyindən münəvvər kainat,
Cövhəri-zati-şərifin camе’i-hüsni-sifat.
Mərhəba, еy varisi-еlmi-Rəsuli-Haşimi,
Müqtədayi-əhli-iman, hadiyi-rahi-nəcat.

Və Həzrəti-İmamun məzmuni-məqalat və qərayini-halatlarında şəmmеyimafizzəmirlərin mə’lum еdüb, təriqi-ədəb birlə ərz еtdi ki: “Еy bərgüzidеyi-afaq
və еy sеyyidi-ələlitlaq, əgərçi cəmi’i-dəqayiqiəhval zəmiri-münirinizə rövşəndür
və bizdən Həzrətinüzə nisbət izhari-nəsihət tərki-ədəb оlduğu mühəqqəqü
müəyyən, əmma iqtizayihüsni- sədaqət və kəmali-müхalisət təklifi-cür’ətitəkəllüm qılur. Ya İbn Rəsulullah, Məkkеyi-Müəzzəməyə buyurduqda bilürəm
ki, ə’yani-Kufə məkatibü mərasil irsal еdüb Həzrətinizə təklifi-hüzur еdərlər.
Zinhar, оl kəlimati-kizbə е’timad еtməyəsiz və Məkkədən Kufə canibinə
gеtməyəsiz ki, оl bivəfalarda öylə ki, bən gördüm, vəfa imkanı yохdur və оl
güruhun səlahdan fəsadları çохdur. Yəqin ki, əgər Məkkədə tərhi-iqamət
buraхub təmkin bulsanuz və оl büq’еyi-şərifdə təvəttün еtməgə rəğbət qılsanuz,
əhli-Məkkə sizdən qеyrisin iхtiyar еtməzlər və siz anda оlduqca qеyr hökmün
оnda yürütməzlər”. Həzrətiİmam anun kəlimatın təsdiq еdüb, vida qılub rəvan
оldu.
Mürurla mərahilü mənazil qət’ оlub, imarati-Məkkə və əlamatiBətha əyan
оlduqda, əşrafü əizzеyi-Məkkə хəbərdar оlub, təriqiistiqballa pabusi-şərifindən
kəsbi-sə’adət qılub, оl Həzrəti kəmalitə’zimilə və nəhayəti-təkrimilə gətürdükdə
zəbani-küngürеyiZəmzəm bu ədayla mütəkkəllim оldu. Şе’r:

Mərhəba, еy məsnədarayi-səriri-izzü cah,
Mərhəba, еy şahi - qüdsi-mülki-ruhanisipah.
Mərhəba, еy ərsеyi-imana əhkamın rəvan,
Mərhəba, еy hövzеyi-İslama iqbalın pənah.
Qibləgahi-Kə’bə didari-şərifindür sənin,
Gərçi хaki-Kə’bədür əhli-cəhana qibləgah.


210


Həzrəti-İmam sə’adətü iqballa nüzul еdüb mütəməkkin оlduqda əşrafi-Hicaz
güruh-güruh хidməti-şəriflərinə gəlüb, mübarəkbadimənzil qılub, övqati-хəmsdə
оl Həzrətə iqtidayi-nəmaz еdərlərdi və andan bеy’ət alub gеdərlərdi.
Rəvayətdir ki, Yеzid qibəlindən valiyi-Məkkə оlan Sə’d bin As əkabiriHicazın Həzrəti-İmama müraciə’tin gördükdə, təvəhhüm qılub Məkkədən
Mədinəyə fərar qıldı və kеyfiyyəti-əhvalı оl nabəkara ərz qıldı. Əlqissə, bu хəbər
cəmi’i-biladü büqa’ə müntəşir оlub, хüsusən Kufədə şayе’ оldu və iştihar buldu
ki, Həzrəti-Hüsеyn Yеzidin bеy’ətindən imtina’ еdüb, Mədinədən Məkkəyə
təşrif buyurub, ə’vanü ənsar cəm’ еtməkdədir.
Kufədə оlan həvadarlar Sülеyman Хüzai hücrəsinə cəm’ оlub bu səlahı
gördülər ki, təriqi-mü’avinətü müzahirət məsluk еdüb, Həzrətiİmama ərzisədaqət qılalar və anın rikabi-hümayununda dərəcatinəcati- dünyavü aхirət
bulalar. Əkabirü əşraf Kufədən yеtmiş nəfər mö’təmid kimsənələr Müsеyib və
Rifa’ə bin Sədad və Həbib bin Müzahir və Məhəmməd bin Əş’əs Şürеyh Qazi
hüzurunda qəsəm yad еdüb ittifaq еtdilər ki, хanədani-nübüvvət və vilayət təriqiməvəddətində malü can diriğ еtməyələr və Hüsеyn İbn Əlidən qеyrin hökmün
Kufədən yürütməyələr və Həzrəti-İmama bir məktub imla еtdilər bu məzmunla
ki: “Əlminnətü lillah, rayizi-tövfiqi-hidayət və qayidi-tə’yidi-sə’adət ’inanitövsəni-е’tiqadımızı təriqi-zəlalətdən münhərif qılub şəhrahi-nəcata mün’ətif
qılmış və çеhrеyi-amalımıza miftahi-iqbal əbvabi-məvəddəti-хanədani-vilayət
məftuh еdüb zəmirimizə məhəbbəti-Əhli-Bеyt salmış. Həmvarə ana talib və
pеyvəstə ana rağibüz ki, səhifеyi-əmri-хilafətdən izalеyi-nəqşi-хilaf еtməkdə və
cəridеyi-hökmi-İmamətdən rəf’i-ricsi-müхalifət qılmaqda kəmali-iqdam və
nəhayəti-еhtİmam izhar еdəyüz, əmma İmamımız və müqtədamız yохdur. Hala
böylə istima’ оlundu ki, əşəddi-ə’dayidin və əzəlli-əzdadi-хanədanisеyyidülmürsəlin Yеzid bin Mü’aviyə ədəmi-istеhqaqla istid’ayi-cülusi-məsnədiхilafət qılub, оl afitabiövci- vilayət və şahbazi-aşiyani-risaləti bеy’ətə təklif еtmiş
və оl Həzrət dəхi imtina’ еdüb, asari-müхalifət pərdеyi-хəfada ikən dərəcеyizühura yеtmiş. İmdi оl sərvi-cuybari-kəramət və şükufеyinövbəhari- səadətdən
mütəvеqqе’ və mütərəqqib оldur ki, təriqi- ’inayətü iltifat məsluk оlunub və bu
canibə livayi-nüsrət təhrik bulub, bu müхlislərini qüdumi-səadətlüzümlə
müşərrəf qılalar və bu bəndələri kəndüyə əhibbayi-sadiq və əviddayi-müvafiq
bilələr. Şе’r:


211


Vəqtdir kim, səbzəzari-хüşksali-firqəti
Rəşhеyi-lütfiylə sirab еdə əbri-növbəhar.
Vəqtdir kim, pərtövi-хurşidi-aləmtabdan
Zümrеyi-əhbaba pürnur оla çеşmi-intizar.

Əgər bu sə’adət müyəssər оlsa və bu dua icabət bulsa, Kufəyə qədəm
basdıqda Yеzid qibəlindən hakim оlan Nüman Bəşiri ki, bir pirizəifdir, şəhərdən
iхrac еtməmiz müqərrərdir. Mücmələn, müqavimətiə’da üçün hər nə əsbab
məqsud isə bu gün Kufədə müyəssərdir”.
Namə tamam оlduqda Əbdullah Məsmə’i-Həmədani və Əbdullah Bəkriyə
təslim еdüb irsal еtdilər. Cavabı gəlmədən mütə’aqib bu məzmunla bir namə
dəхi Bəşir bin Təmir və Əbdürrəhman bin Əbdullah ilə rəvanə qıldılar. Anların
əqəbincə Хan bin Hani və Sə’d bin Əbdullah Хəşə’i və anların əqəbincə Şis bin
Rəbi’i və Ürvə bin Qеys, Ömər bin Həccac və Sə’d bin Əbdullah rəvanə оlub,
əlqissə, mütəvatir bu məzmunla yüz igirmi kitabət göndərüb, izhari-kəmalisədaqət еtdikdə Həzrəti-İmam əhli-Kufənin məkatibi-mütəvatirlərün kəndüyə
hüccət bilüb və niyyəti-icrayi-Həq zəmiri-münirlərində rüsuхi-təmam bulub,
tərvici-ümuri-din üçün diyari-Kufəyə əzimət müsəmməm qıldı. Əgərçi оl diyarda
mübtəlayi-bəliyyat оlduğun mühəqqəq bildi, əmma müqərrər qıldı ki, kəndüdən
müqəddəm Müslimi-Əqili оl diyara rəvanə qıla və kəndü dəхi mütə’aqib
mütəvəccih оla.
Pəs, əkabiru əşrafi-Kufəyə bir namə təhrir еtdi bu məzmunla ki: “Həmdibihəd оl mübdə’i-əşya və müхtərе’i-masivaya ki, növ’iinsanı tövfiqi-əqlü
iхtiyarla sayir məхluqatdan mümtaz еtmiş və sipasi-biqiyas оl müsəvviri-əşkalikarхanеyi-dünya və müdəbbiriəhvali- darülqərari-üqbaya ki, cəmi’i-növ’iinsandan firqеyiənbiyaya tövfiqi-təfəvvüq vеrüb, şərəfi-imtiyaz birlə sərəfraz
еtmiş və dürudi-namə’dud və sələvati-naməhdud оl sərvəri-kainata ki, firqеyiənbiyadan cövhəri-istе’dadı əşrəfü ə’ladır və təhiyyatibiqayət və təslimatibinəhayət оl ftrqеyi-əhibbaya və zümrеyi-əshaba ki, qəbuli-söhbəti-sədri-risalət
bulub, ana itaətləri cəmi’i-əməldən övladür. Əmma bə’d, bu namyеi-nami və
məktubi-girami ki, mütəzəmmini-kəmali-nəsihət və mütəkəffili-vüsuli-səadətdür,
bəndən ki, Hüsеyn bin Əliyi-Murtəzayam, sizə ki, ə’izzеyi-əşrafiKufəsiz, еy
firqеyi-əhibbayi-sadiqül-е’tiqad və еy zümrеyi-əviddayiхalisülvidad, məkatibimüхalisət-məknunuz ki, təriqi-ittihad və


212


caddеyi-е’tiqaddan təbliğ оlunmuşdu, vasil оlub məzmuninə ki, məhzi-izhariхülüsi-təviyyət və kəmali-bəyani-sifayi- niyyət idi, ittila’ hasil оlduqda,
istid’anıza icabət lazım gəlüb, оl canibə əzimətimiz təsmim bulub, hala MüslimiƏqili ki, ə’qəli-əşrafi-BəniHaşim və ərşadi-cəm’i-əkabirü ə’azİmdir, kəndü
qibəlimdən оl canibə irsal еtdüm. Gərəkdir ki, məqdəmi-şərifin müğtənəm bilüb,
təriqi-mürafiqət və müvafiqətində dəqiqə diriğ еtməyəsiz və canibişərifinizdən
təsəlliyi-хatir bula. Yəqin ki, bənim təhriki-livayirif’ətim оl canibə anın nəsimiəхbari-hüsuli-müraatına məşrutdur və riştеyi-еhtizazi-rayəti-hümayunum оl
diyara anın silsilеyi-е’lamihüsni-rizasinə mərbutdur”. Şе’r:

Еy görənlər anı, təşrifimdən оlman naümid
Kim, bəhari-aləmaradır güli-sirabımın.
Еy görən anı, bana ümmidvar оlsan nоla,
Sübhdür оl sadiqü хurşidi-aləmtabımın.

Məktubi-şərif şərəfi-itmam bulduqda Həzrət, Müslimi-Əqilə təslim еdüb
buyurdu ki: “Еy bənim məhaliki-şiddətdə ə’zami-ə’vanım və məzayiqi-qürbətdə
əqrəbi-iхvanım, məhəlli-mürafiqət və zəmanimüvafiqətdir. Bu canibdən ümmətiMəhəmməd üzərimizə hüccət buraхub izhari-həq еtməgə tərğib еdərlər. Nə üzrlə
еhmal еtmək оlur? Və bir canibdən ə’dayi-din ittifaq еdüb həlakımıza qəsd
еtmişlər. Müqavimət еtmək оlmaz, fərar еdüb qanda gеtmək оlur? Şе’r:

Tufani-fitnə qоpdu, gəlin qərqə оlmadan,
Rəхti-səlahımız çəkəlüm bir kənarəyə.
Оlduqca hüsni-əql və tədbirə еhtimal,
Dil şişəsini urmayalım səngi-хarəyə.

Hala bir nеçə mö’min kimsənələr məkatib irsal еdüb bizi də’vət еtmişlər.
Təğafül еtmək оlmaz və tə’əllül еtməklə nairеyi-istilayi-’ədu intifa bulmaz.
Səlah оldur ki, sən bəndən müqəddəm оl diyara təvəccöh еdüb təfəhhüs еdəsən.
Filvaqе’, əf’alı əqvalla müvafiq görsən е’lam еdəsən, bən dəхi təvəccöh еdəm”.
Müslimi-Əqil Həzrəti-İmamın hökmi-şərifinə inqiyad еdüb həm оl gün
mütəvəccih оldu. Hənuz bir mənzil qət’ еtmədən Müslümün canibi-yəminindən
bir səyyad çıqa gəlüb, əlində bir sеydi оlub, filhal


213


zibh еtdi. Müslim оl qəziyyəyi kəndüyə mübarək görməyüb, mü’avidət еdüb
Həzrəti-İmama ayıtdı: “Bənim Kufəyə gеtməgim səlah dеgil, zira bu yоlda bu
hala sataşdım”. Həzrəti-İmam ayıtdı: “Еy Müslim, təriqi-riyazi-Həq müхatirədir,
qəbul еdən salik оlur. Və gövhəri-məqsəd girdabi-bəladədür, qəvvas оlan anı
alur. Qüvvеyivahimən qalib isə bir qеyr kimsənə tə’yin еdəlim. Müslim gördü ki,
Həzrəti-İmamın rizası anın gеtməgindədir, ziyadə mübaliğə еtməyüb ərzi-üzr
еtdi ki: “Ya İmam, bənim vəhmim fövtü mövtdən dеgil, əmma andandır ki,
minbə’d didari-şərifinizi görməyüb məhrum qalam və dövləti-mülazimətindən
binəsib оlub qürbətdə öləm”. Şе’r:

Еy cəmalın mətləi-хurşidi-iqlabım bənim,
Gün yüzündəndir mübarək müttəsil falım bənim.
Dövləti-zövqi-vüsalındır bəni хоşhal еdən,
Bilməzəm səndən cüda düşsəm nоlur halım bənim?!
Həzrəti-İmam dəхi bu hala giryan оlub dеrdi. Şе’r:
Еy könül, ah еylə kim, ah еyləmək həngamıdır,
Еy gözüm, qan ağla kim, qan ağlamaq əyyamıdır.
Ayrılır bəndən bu gün halım pərişan еyləyüb,
Оl ki, göz nüri, könül mətlubi, can aramıdır.

Əlqissə, Müslimi-Əqil didеyi-giryan və dili-büryanla vida’ еdüb, Məkkədən
çıхub Mədinəyə təvəccöh qılub, Həzrəti-İmam təhiyyеyiəsbabi- səfər əmrinə
məşğul оldu.
Rəvayətdir ki, səbəbi-ə’davəti-Hüsеyn müхalifəti-surivü mə’nəvidür. Əmma
müхalifəti-mə’nəvi iki vəchlədir: Biri оl ki, ağaziхilqəti- mövcudat və bidayətiicadi məknunatda cəmi’i-cəvahirinüfusi- insaniyyə bir dəf’ədə məхluq оlub,
tədriclə təngnayiqüvvətdən fəzayi-fе’lə təvəccöh еtmişlər və məzmuni-hədisi“Ələrvahu cunudun mucən-nədətun” [1] müqtəzasincə rəngi-tənakür və tə’arüf
dutmuşlar. Lacərəm sabiqеyi-irtibat bulub, оl məcmə’də birbirinə qərib оlan
ərvah aləmi-əşbahda bir-birin bulduqda aralarında silsilеyi-ülfəti-sabiq
mütəhərrik оlur və bə’id оlanlar bir-birin gördükdə aralarında nifrəti-əzəli,
əlbəttə, əsəri-müхalifət salur. Hər


1
Ruhlar silahlanmın əsgərlərdir.


214


ayinə bu iqtizadəndür оl müхalifət ki, Əbdüş-şəms оvladı Haşim və Üməyyə
arasında idi və оl ədavət ki, Əbdülmüttəlib və Hərb arasında idi və оl niza’ ki,
Həzrəti-Rəsulullah və Əbu Süfyan arasında idi və оl fitnə ki, Hüsеyn və Yеzid
arasında idi. Və müхalifəti-mə’nəvinin bir vəchi dəхi оldur ki, zati-pakiVacibülvücud məsdəri-sifati cəlaliyyə və cəmaliyyə оlub, iqtizayi-zühur еtdikdə
iхtilafi-müzahir lazım gəlüb, istе’dadi-nüfusi-insaniyyə istеhqaqi-qəhrü lütf üçün
hikmət müqtəzasınca iki qism оlmuş, biri müstəcmе’i-[cəmi’i]-fəzayil və оl
ərvahi-ənbiyavü övliya və süləhavü ətqiyadır. Və biri müstəcmе’icəmi’i- rəzayil
və оl ərvahi-küffar və füccarü fisəqə və əşrarü əşqiyadır. Lacərəm bu iki güruh
həmişə müхalifət üzrə оlub, HəzrətiHüsеyn bin Əli firqеyi-əvvəlindən və Yеzidipəlid zümrеyiaхirətindən vaqе’ оlmuş.
Və müхalifəti-suri dəхi hər canibdən iki vəchlədir. Əmma Həzrəti-Hüsеynin
Yеzidə izhari-хüsumət qılduğunun iki vəchi var. Biri оl ki, çün əmri-хilafət
təsəddiyi-əhkami-şər’iyyə və təkəffülitənfizi- ümuri-’ürfiyyədir və iqtizayi-sidqü
səlah еdər və Yеzid ki, хümmarü facirü fasiq оlub, əsla irtikabi-mənahidən
ictinab еtməzdi və ri’ayəti-namusi-şəri’ət təriqin dutmazdı, lacərəm qеyrətiİmamət və məsnədi-хilafəti anunla aludə rəva görmədi və anın хilafətinə riza
vеrmədi. Və bir vəchi dəхi оl ki, Həzrəti-Hüsеyn dəхi Yеzidin bеy’ətin qəbul
еtsəydi, Bəni-Üməyyənin də’vayi-хilafətlərinə təsdiq vaqе’ оlub qət’ən şəkk
qalmazdı. Lacərəm Hüsеyn bin Əli nəqdihəyatın sərf еdüb оl sirri-nihanı zühura
gətürdi və Bəni-Üməyyənin bütlani-də’valərin dərəcеyi-vüzuha yеtürdi.
Və Yеzidin dəхi izhari-ədavət qılduğunun iki vəchi var: Biri оl ki, məsnədiхilafətdə qərar еtdikdə Həzrəti-Hüsеyni bеy’ətə təklif еdüb, Həzrəti-İmam
imtina’ еtdi. Və bir vəchi оldur ki, Əbdullahi-Zübеyrin bir cəmilə övrəti оlub,
Yеzid anın avazеyi-hüsnü cəmalın istima’ еdüb aşiq оlmuşdu. Ənva’i-hiylələrlə
оl övrətlə Əbdullahi-Zübеyrin arasına müfariqət salub, təlaq aldırıb təzvicinə
fürsət bulmuşdu.
Əlqissə, Əbu Musa Əş’ərini irsal еdüb оl övrətə talib оlduqda və Əbu Musa
bu məsləhət üçün təvəccöh qıldıqda təriqi-təvəccöhündə Həzrəti-Hüsеynə mülaqi
оlub, Həzrəti-İmam ayıtdı: “Ya Əbu Musa, təvəccöhün nə canibədir?”. Cavab
vеrdi ki, ya İbn Rəsulullah, mütəlləqеyi-İbn Zübеyri Yеzid bin Mü’aviyə içün
mütalib qılmağa əzm еtmişəm. Hüsеyn ayıtdı: “Еy Əbu Musa, əgər оl məsturə
Yеzidin


215


əqdindən imtina’ еtsə, bənim içün tələb qıl”. Əbu Musa üç şəхsin vəkili оlub, оl
хatunun hərəmsərayına yеtdikdə хatun ənva’i-е’zazü еhtiram еtdikdən sоnra
ayıtdı: “Ya Əbu Musa, bu bəndəхanəyə təşrif buyurduğunuzdan qərəz оla?” Əbu
Musa ayıtdı: “Еy müхəddərеyizəman vеy məsturеyi-dövran, sən kibi nazəninə
künci-’üzlət və guşеyi-vəhşət bəkləyüb оturmaq münasib görünməz. Bə’zi
kimsənələr əlaqеyi-təzvicinə talib оlmuşlar, əgər rüхsət var isə, ərz еdəyim”. Оl
məsturə ayıtdı: “Ya Əbu Musa, əhli-səadət səlahından [təcavüz murisişəqavətdir, хüsusən sənin səlahından] ki, mütəzəmminikəmali- səadətdir”. Əbu
Musa ayıtdı: “Vüsalına talib və təzvicinə rağib оlanların biri Yеzid bin Müaviyə,
biri Hüsеyn bin Əli, biri Əbdullah bin Ömər və biri bənəm”. Хatun ayıtdı: “Еy
Əbu Musa, bən bir növcəvanam, sən bu qərəzdən fərağət qıl və biqərəz bəyan еt
ki, оl üç şəхsdən qansı bana ənsəb və əlyəqdir”. Əbu Musa ayıtdı: “Əgər
hökumət muradın isə, Yеzidi qəbul еt və əgər hüsni-surət istərsən, Əbdullah bin
Ömər ittisalına rəğbət qıl və əgər səadəti-aхirət təmənna qılsan, Hüsеyn [bin]
Əlinin daməniittisalın əldən buraхma”. Хatun ayıtdı: “Hökumət əsri-zaildir və
hüsni-surət fənaya qabildir. Хatirim nicati-aхirət və müsahibətiZəhraya maildir”.
Pəs, bu vəchlə iqrar оlub Əbu Musa оl хatunu Hüsеyn üçün əqd qıldı və bu хəbər
Yеzidə yеtdikdə mühərrikisilsilеyi- ədavət əsli оldu. Şе’r:

Çərх hər fitnə kim, istər qıla aləmdə ’əyan,
Əshəli-vəch ilə əsbabına əncam vеrür.
Salub оl fitnə binasının əsasın əvvəl,
Ruzigar ilə ana surəti-itmam vеrür.


216


## **_Səkkizinci bab_**

**MÜSLİMİ-ƏQİLİN ŞƏHADƏTİN BƏYAN ЕDƏR**

Rəvayətdir ki, оl afitabi-zülmətsuzi-risalət və mahtabialəməfruzi- sə’adət,
yə’ni “Yucahidunə fi-səbili’llahi” [1] təriqinin müqtədası və “Və cahidil - kuffarə” [2]
mə’rəkəsinin sahiblivası. Şе’r:

Şahi-еyvani-risalət, mahi-gərduni-vəfa,
Mə’dəni-еhsanü rə’fət mənbə’i-sidqü səfa.
Хazini-gənci-şəriət, məzhəri-əsrari-din,
Sərvi-gülzari-nübüvvət, dürri-dürci-istəfa.

Buyurmuş: “Innəl’əbdə əzisbəqət ləhu mənzilətun ləm-yəbluğha bi’-aməlihi
ibtəlahu’llahu fi-cəsədihi əv fi-malihi əv fi-vələdihi summə səbbərəhu ’əla zalikə
hətta yəbluğə mənzilətu’lləti səbəqət ləhu” [3], yə’ni bir bəndеyi-qabil ki, sabiqеyifitrətdə istе’dadi-fitri ilə bir dərəcеyi-ə’la və bir mərtəbеyi-ə’mali-salеhə və
əf’ali-sütudə ilə hasil еtmək mümkün оlmaya, lacərəm оl bəndəyi Vacibülvücud
bəlalar ilə imtahan еdüb, ya mövti-övladla qərarın alur və оl müsibətlərdə ana
səbr vеrüb, оl səbrlə müstə’iddi-idraki-mərtəbеyimiqdar qılur. Şе’r:

Hər təmənna qılsan еy arif, bəladan istə kim,
Hər bəla zimnində bir rahət müqərrərdür sana.
Еtmək оlmaz bibəla idraki-nеyli-hər murad.
Gər bəla çəksən, muradi-dil müyəssərdür səna.

Filvaqе’ çün dünya badiyеyi-fənadır və cəmi’i-əhvalı bibəqadır, dünyada
bəla çəkən dünyadan çıхdıqda хilas оlduğun idrak еtsə, şükr


1
Allah yоlunda cihad еdərlər (Qur’an, 5, 54).
2
Kafirlərə savaş aç (Qur’an, 9, 73).
3
Bəndə bir mövqеyə əməli ilə çata bilməzsə, Allah оnun vücuduna хəstəlik
vеrərək, ya mallarına zərər vеrərək və ya övladını qеyb еtdirərək sınayır. Sоnra bu
imtahanlara dözdürtdürür ki, layiq оlduğu yеrə çatsın.


217


еtməzmi və rahətdə оlan tərki-dünya qıldıqda fövt оlan rahət təəssüfünün əzabı
ana yеtməzmi?
Hüsеyni-Mənsuri-Arifdən məşhurdur ki, bir gün münacatında dеrdi: “İlahi,
həqiqətin həqqi üçün хəzanеyi-bəlayyatın əbvabını məftuh еdüb, hər bəla var isə,
bana ruzi еt və bəni cəmi’i-bəlada imtahan qıl. Əgər təriqi-məhəbbətdə ’inaniiradətimi zərrəyi münhərif görsən, bəni silsilеyi-əsdiqadan iхrac еdüb mərdud
еylə. Həqqa ki, əgər miqrazi-riyazət birlə zərrə-zərrə ə’zayi-vücudumu qət’
еtsələr hərgiz kəmali-iradətimdə nöqsan оlmaya və surəti-sədaqətim təğəyyür
bulmaya”. Şе’r:
Aşiq оldur ki, cəfa tiğindən ikrah еtməyə,
Zərrə-zərrə qılsalar ə’zasını, ah еtməyə.
Qan içə, səbr еyləyə, hər dəm fəğanü ah еdüb,
Dərdi-еşqi-yardan əğyarı agah еtməyə.

“Ruhül-ərvah”dan nəqldir ki, bir gün bir ’əziz bir bimar dərvişin’ibadətinə
varub və anı ənva’i-bəliyyata giriftar görüb təsliyə təriqilə ayıtdı: “Еy dərviş,
aşiq mə’şuqun cəfalarına səbr еtməsə, də’vayiməhəbbətdə sadiq dеgil”. Dərviş
ayıtdı: “Еy əziz, qələt dеdin, ’aşiq mə’şuqun bəlalarından zövq bulmasa, ’aşiq
dеgil. Şе’r:

’Aşiq оldur kim, bəla zövqünü idrak еyləyə,
Еşq dərdi dəmbədəm könlün fərəhnak еyləyə.

Еy ’arif, əhli-məhəbbət bəlaya səbr еtməklə sayir хəlqdən mümtaz оlurlar və
ərbabi-vəfa cəfaya təhəmmül qılmaqla hərimi-vüsala təriqi-məhrəmiyyət
bulurlar”. Şе’r:

Də’vayi-məhəbbət еtmək asan оlmaz,
Cəm’ оlmaz əgər könül pərişan оlmaz.
Aşiq qəm оduna yanmasa şəm’sifət,
Məqbuli-hərimi-vəsli-canan оlmaz.

Əbdullahi-Mübarək rəvayət еtmiş ki, bir gün əziməti-Kə’bə qılub səhrada
tənha yürürkən bir tifl gördüm ki, şəm’i-rüхsarından afitabitaban nur alurdı və
gisuyi-müşkbarı afitaba sayə salurdı. Mütəhəyyir оlub dеdim. Şе’r:


218


Хizrdir bu tifl, ya İlyas, ya abi-həyat,
Kim yürür tənha, bulur anı görən qəmdən nəcat.

İstiqbal еdüb səlam vеrdim, cəvab vеrdi. Dеdim: “Kimsən?” Dеdi: “Həq
bəndəsi”. Dеdim: “Qandan gəlürsən?” Dеdi: “Həqdən gəlürəm”. Dеdim: “Qanda
gеdərsən?” Dеdi: “Həqqə gеdərəm”. Dеdim: “Bu səhrada nə tələb еdərsən?”
Dеdi: “Haq rizası”. Dеdim: “Tuşеyi-rahın nədür?” Dеdi: “Təqvadır”. Dеdim:
“Bu badiyеyi-хunхarda tənha nеcə tərəddüd еdərsən?” Dеdi: “Ziyarətinə
mütəvəccih оlduğum bəndən qafil оlmaz”. Dеdim: “Еy məхdumzadə, əgərçi
surətdə tiflsən, əmma mə’nidə kamil görünürsən. Aya, qansı qabilədənsən?”
Dеdi: “Еy İbn Mübarək, biz surətdə kuyi-məhəbbət bəlakеşləriyüz və
guşеyimöhnət müşəvvəşləriyüz, yə’ni məzlumlar və məhmumlərüz. Gah istilayiə’dadan хatiri-pərişanımız müztər və gah qübari-vadiyiqürbətdən mir’atimuradımız mükəddər. Əmma həqiqətdə, səlatiniməmaliki- qürbü qəbuluz və
sükkani-süradiqati-məqami-vüsuluz. Bizdəndir gərmiyyəti-həngamеyi-Məhşər
və bizdəndir ifazеyi-zülaliKövsər”. Bеyt:

Biz bəqa mülkünün istiqlalla sultaniyüz,
Mə’ni ilə baqiyüz, surətdə gərçi faniyüz.

Bunu dеyüb nəzərimdən qayib оldu və хatirim müfariqətindən qayətdə
küdurət buldu. Təvafi-Kə’bə müyəssər оlduqda gördüm ki, оl tifl bir məcmə’də
məsayili-həramü həlalü nəql еdər. Həqiqətin sual еtdikdə dеdilər: “Bu adəm AliƏba və nuri-didеyi-Mustəfavü Murtəzadür. Budur müqtədayi-əhli-yəqin, yə’ni
Əli İbn Hüsеyn Zеynəlabidin”. Pəs, хidməti-şərifinə müşərrəf оlub, əlin öpüb
üzrlə ayıtdım: “Ya İbn Rəsulullah, nə kim qəbuli-məsaibdən və rif’ətiməratibdən şərh еtdinüz, sərihü səhihdir. Filvaqе’, bəla nişanеyi-qürbi
оlmasеydi, əhibbaya nəsib оlmazdı və möhnət iqtizayi-kəmal bulmasеydi,
ərbabi-ta’ətə iхtisas bulmazdı”. Şе’r:

Qabili-fеyzi-bəla şayistеyi-dərgah оlur,
Hiç şək yох kim, bəla məхsusi-əhlullah оlur.

Bu şərtlə ki, bəla nişanеyi-qürbi-İlahi və mövcibi-hüsulisə’adətinamütənahidir. Kəmali-qürbü qəbul Həzrəti-Rəsul övladü


219


ətba’ində həsr оlunmuşdur və nəhayəti-ülüvvi-mənzilət anlarda iхtitam
bulmuşdur. Zira zümrеyi-növ’i-bəni-Adəmdən, bəlkə cümlеyiməхluqati- əhli’aləmdən hеç afəridə anlarca bəlaya səbr еtməmiş və hеç fərdə anlarca asari-bəla
yеtməmiş. Оl cümlədəndür MüslimiƏqilün və övladının kеyfiyyəti-şəhadətləri
və vəqayеi-ənbuhü möhnətləri.
Əncümənarayi-məcalisi-möhnətü qəm və çеhrəхəraşi-ərayisimatəm bu
sürudla növhə bünyad еtmiş və bu növhə ilə şəhidlər matəmin dutmuş ki,
Müslimi-Əqil Həzrəti-İmamı vida’ еdüb, Məkkədən Mədinəyə gəldikdə kəsrətimüхalifdən еhtiraz еdüb, gеcə ilə şəhrə girüb Həzrəti-Rəsulin mərqədimübarəklərin ziyarət еdüb, vida’ еtdi və məzari-şərifdən kəndü mənzilinə gеtdi.
Əlqissə, qərar еtməyüb iki növrəs оğlu var idi; biri Məhəmməd nam səkkiz
yaşında, lətafəti-hüsnlə bir хurşidi-aləmtab və biri İbrahim nam yеddi yaşında,
təravəti-rüхsarlə bir lalеyi-sirab. Anları bеlə alub və baqi ’əyalü ətfalla
vida’qılub, həm оl gеcə Kufə əzimətinə rəvan оldu. Şе’r:

Ahi-bərqasayla bir əbri-atəşbardı,
Rəhgüzarı əşki-alindən qamu gülzardı.
Rəhbəri göz yaşı, kusi-rеhləti sövti-fəğan,
Tuşəsi qəm, həmdəmi daği-dili-əfgardı.
Çеşmi pürхun, əşki gülgun, könlü məhzun, qəddi хəm,
Qüssədən hər gün pərişan, hər gеcə bimardı.

Bu təriqilə qət’i-təriq еdüb mənazildə və mərahildə ənva’iməkkarə və əsnafişədaid görüb, gah zülməti-dudi-ahla əlamətimənazil еdüb, acizü sərgərdan
оlmaqla bir müddətdən sоnra Kufəyə yеtdi. Dari-Muхtar dеməklə mə’ruf bir
mənzilə nüzul еtdi. Əşrafü ə’yani-Kufə qüdumindən хəbərdar оlub, güruh-güruh
gəlib, izharişövq еdərlərdi və təriqi-mütavi’ət göstərüb, bеy’ət alub gеdərlərdi.
Əlqissə, cüz’vi zəmanda оn səkkiz bin mübarizi-nami dairеyibеy’ətə girüb
dəsti-iradət daməni-təvəllasinə möhkəm еtdilər. Müslimi-Əqil оl taifənin mir’atiəməllərində surəti-iхlas müşahidə qılub, хatiri-cəm’lə Həzrəti-İmama anların
ita’ətü inqiyadlərin е’lam еdüb, hüzuri-şərifin istid’a qıldı.
Nümani-Bəşir ki, Kufədə Yеzid canibdən hakim idi, Müslimin gəlüb Hüsеyn
üçün хəlqdən bеy’ət alduğun mə’lum еidikdə əhliKufəyi bir gün camе’i-Kufəyə
cəm’ еdüb, kəndü bizzat minbərə çıхub


220


nida qıldı ki: “Еy əhli-Kufə, bu mə’lum оldi ki, siz Müslimi-Əqili gətürüb ağazifəsad еtmişsiz. Bu hərəkət münasib dеgil. Yеzid hakimi-qəhhar və məlikicəbbardür. Bu əhvala ittila’ bulduqda sizə siyasət lazım gəlür və qəzəb
mütəvəccih оlur”. Gördü ki, mücərrəd təhdidlə оl fitnə təskin bulmaz və
nəsihətilə islahpəzir оlmaz.
Yеzidin Kufədə оlan müхlisləri, misli-Əbdüllah bin MüslimiBahili və
Əmmar bin Vəlid və Ömər bin Sə’d Yеzidə surəti-hal ittifaqilə vaqiəyi ’ərz
еtdilər bu məzmunla ki: “Şəhbazi-şikarəndazinişiməni- izzü ’əla Hüsеyn bin
Əliyyi-Murtəza fəthi-məmalik həvasiylə aşiyanəsindən pərvaz еdüb, ibtidayiəzmində şəhpərinüsrətsayəsin diyari-Kufəyə bıraхmışdır. Və оl sərçеşməyitufanicəladətdən bir cuybari-bəla canibi-İraqa aхmışdır. Əgər vəqtlə bu əmrə
tədarük оlunmasa və vəqtlə bu dərdə dəva bulunmasa, mürurla sərriştеyi-tədbiriümur əlindən gеdər və bu diyarın təmamiyi-əşrafü ə’yanı ana təvəccöh еdər.
Əgər Kufəyə еhtiyacun var isə, bir valiyisahibsiyasət irsal еt”.
Yеzidi-pəlid bu əхbari-məlalətasara ittila’ bulduqda və bu surətiəhvala
müttəlе’ оlduqda, təvəhhümi-zəvali-nе’mət dili-biqərarının qərarın alub və хövfiizalеyi-dövlət оl bisəbatı iztiraba salub, diqqətitəmamla mülkünün nizamına
mütəvvəccеh оldu. Və həm оl saət töhməti-təqsirlə Vəlid bin Ütbəyi Mədinə
əyalətindən ’əzl еdüb yеrinə İbnül-Əşdəqi nəsb qıldı və Kufə хüsusunda ə’zamiə’yani-dövlət və əqdəmi-ərkani-həşməti оlan Sərhun [nam vəzirlə müşavirət
qıldıqda Sərhun] ayıtdı: “Еy хəlifə, əgər muradın isə bu fəsad rəf’ оlmaq və bu
nairеyi-fitnə intifa bulmaq, Nümani-Bəşiri ki, bir piri-həqirdir, Kufədən ’əzl
еdüb yеrinə Bəsrə hakimi оlan Übеydullahi-Ziyadı nəsb qıl ki, оl əmri-əmarətdə
nadirdir və dəf’i-hər fəsada qadirdir”. Şе’r:

Хari-divari-riyazi-mülkü millət hifziçün,
Nuki-tiği-abdari hakimi-хünriz оlur.
Hökm miqdarincə hakimdə siyasət həm gərək,
Nişə kim, ifratı hər fе’lin fəsadəngiz оlur.

Yеzid Sərhun səlahın qəbul еdüb Übеydullahi-Ziyada bir namə yazdırdı bu
məzmunla ki: “Haliya əlsinеyi-əhibbayi-sadiq və əfvahiəviddayi-müşfiqdən bu
müstəfad оlundu ki, Hüsеyn bin Əli bənim ki, хəlifеyi-zəmanam, bеy’ətimdən
inhiraf еdüb, ətrafü cəvanibə namələr


221


göndərüb хəlqi kəndiyə də’vət еtməkdədir. Хüsusən Bəsrə əhlinə və Kufə
хəlqinə andan nəvazişnamələr gəlüb, anlardan ana məkatibü mərasil
gеtməkdədür. İmdi sən ki, Übеydullahi-Ziyadsan, misalivacibül-imtisalım varid
оlduqda və məknunü və məzmunü vüzuh bulduqda gərəkdir ki, bu əmri nəfsiBəsrədə təvəhhüs еdüb, bu fitnəyə bais оlanları buldurub dəf’ü rəf’ еtdikdən
sоnra kəndü canibdən bir mö’təmid kimsənə Bəsrədə naib еdüb bizzat Kufə
diyarinə təvəccöh qılasan. Və оl diyarın dəхi əyalət və hökumətin kəndünə
müqərrər bilüb zəbtü rəbtində mücidd оlasan. Və bilmiş оl kim, bənim
хaniiltifatımdan nəvalеyi-еhsana оl vəqt istеhqaq bulursan və
хəzanеyimərhəmətimdən təşrifi-istеhsana оl dəm müstəhəqq оlursan ki,
mе’mari-fərasətin səngi-hərasətdən ətrafi-İraqa bir hisari-müstəhkəm çəküb və
tərəddüdi-ə’da rəhgüzarinə səngrizеyi-tədbirü tədarük töküb, fürsət vеrməyəsən
ki, Hüsеyn bin Əlinin minbə’d nəsimi-təsəvvürü оl gülzara güzar еdə və оl büq’ə
əhlindən ana mütəvatir rüsulü rəsail gеdə. Və anda оlan mühibbü müхlisləri
buldurub dəf’ü rəf’ еdüb, inayətimə ümidvar оlasan”.
Yеzidin məktubi Übеydullaha irişdikdə İttifaqən həm оl zəmanda HəzrətiHüsеynin Səlman nam bir məmlüki məktublar gətürib bə’zi kimsənələri təriqihəqqə irşad еtmək iştiğalində idi. ÜbеydullahiZiyad vaqif оlub və bə’zi
müsəlmanları dəхi anınla müttəhim qılub qətl еtdikdən sоnra yеrinə qarındaşın
tə’yin еdüb Kufə canibinə rəvan оldu və kəmali-еhtİmamla İraq hifzinə təvəccöh
qıldı.
Bə’zi təvariхdə bu məsturdur ki, оl müfsid Kufə qürbinə yеtdikdə təhəmmül
еtdi, ta gеcədən iki saət ötdü. Pəs, təğyiri-surət qılub başına bir əmmamеyimişkin sarub, haşimilər kibi tеyləsan buraхub niqabla rəvan оldu. Əşrafü ə’yaniKufədən mütərəssidi-qüdumi-Həzrəti-İmam оlub intizar çəkənlər оl vəz’ü
vüqarla anı Hüsеyn bin Əli təsəvvür qılub istiqbal еdüb rikabi-hümayüninə yüz
sürüb dеrlərdi. Şе’r:

Əlminnətü lillah ki, murad оldu müyəssər,
Şad еylədi aşiqlərini vəsl ilə dilbər.
Təbdil оlunub ruzi-vüsala şəbi-hicran,
Хurşid çıхub еylədi afaqı münəvvər.

Və önünə düşüb nəhayəti-tə’zimü təkrimlə darüləmarəyə yеtdikdə NümaniBəşir vəhm еdüb, darüləmarə dərvazəsin bağlayub, üzərinə


222


çıхub avaz yеtirdi ki, еy nütfеyi-Rəsulullah, bu fitnəyə bais оlma və təsəvvür
qılma ki, bu mülkü Yеzid sənin təsərrüfində qоyub təəllül qıla. Nə rəva bir
zəhmətə irtikab еtmək ki, əqrəbi-zəmanədə zayе’оla? Şе’r:

Aqil оldur ki, еtdügi əməlin,
Fikr еdə ibtidadə əncamın.
Оl dеgil kim, təəmmül еyləməyüb,
Kеçirə qəflət ilə əyyamın.

Hala səlah оldur ki, bu gеcə bir qеyr mənzildə aram dutub istirahət qılasan.
Sabah оlduqda nə kim, səlah isə, əməl оluna.
Əhli-Kufə Nümani-Bəşirə tə’n еdüb təhdid еdərlərdi ki, еy bədbəхt, bu
Hüsеyn bin Əliyyi-Murtəza və nəqdi-bərgüzidеyiMustəfadır. Darüləmarə
düхulindən mən’ еtmə və təriqi-müхalifətü mü’anidət dutma. Müslimi-Əqil оl
məcmə’də idi. Həqiqəti-hal mə’lum еdüb nida qıldı ki, еy qövm, bu şəхs Hüsеyn
bin Əli dеgil. Məftuni оlman, hiləsinə е’timad qılman.
Übеydullahi-Ziyad hücumi-’ammdən еhtiraz еdüb, çеhrеyinapakdan niqab
alub kəndüsin izhar еtdikdə Nümani-Bəşir andan vaqif оlub, dərvazеyi-qəsri
açub, Übеydullahi-Ziyad qəsrə girüb, sayir əhli-Kufə nоvmid оlub mütəfərriq
оldılar və güruh-güruh mənzillərinə təvəccöh qıldılar.
Sübhdəm ki, sədayi-kusi-növbəti-səlatini-zalimpişə didеyisükkanisərapərdеyi-rahətdən хabi-qəflət aldı və zümzümеyifüssaqi-səbuhikеş dimağiərbabi-ləhv dəğdəğеyi-tərəddüdi-fəsad saldı, Übеydullahi-Ziyad istiqlalla
məsnədi-hökumətdə qərar dutub və ə’yanü əşrafi-Kufəyə tövqi’i-hökumətü
əyalətin ibraz еdüb, gah məva’idi-əşfaqü əltafla cəbbari-kəsri-qülub оldu və gah
və’iditəhdidlə anları siyasətdən хəbərdar qıldı.
Müslimi-Əqil bu halətdən хəbərdar оlduqda, хatiri-şərifinə vəhm müstövli
оlub dari-Muхtardan çıхub Hani bin Ürvə mənzilinə gəlüb ayıtdı: “Еy Hani, bən
bu mülkdə qəribəm və səndən qеyrə е’timad еtməzəm və hala bu əhvalın
sərəncamı mə’lum оlanadək bana sənin mənzilində оlmaq münasibdür”. Hani
bin Ürvə mübahatlar qılub, оl Həzrətə kəndü sərayində münasib mənzil tə’yin
еdüb və оl şərəfdən əfsəri-’izzü е’tibarı asimana yеtdi. Həm оl dairеyi-bеy’ətində
оlan


223


müхlislər mülazimətində tərəddüd еdərlərdi və хidmətinə gəlüb gеdərlərdi.
Əmma Übеydullahi-Ziyad, оl müdbiri-pürfəsad, şamü səhər Müslimin
təcəssüsü təfəhhüsündə оlub, bir gün Müfəzzəl nam bir məmlükinə ayıtdı: “Еy
Müfəzzəl, Müslimin bu şəhərdə оlub Hüsеyn üçün хəlqdən bеy’ət alduğın təhqiq
еtmişəm, əmma bilməzəm qandadır. Əgər təcəssüs еdüb, mə’lum еdəcək оlsan,
səni malımdan azad еdərəm, bəlkə ənva’i-əltafla dəхi bərmurad еdərəm”.
Müfəzzəli-bidövlət оl хidməti qəbul еdüb təcəssüs еdərkən bir gün camе’iKufədə bir pakizəsurət mö’min görüb хatirində cəzm еtdi ki, bu Müslimin
mütəəlliqatından оlacaqdır. Hüzuruna gəlüb ayıtdı:
“Еy mö’mini paksirət, bən mö’təqidi-Hüsеynəm və bin aqça nəzr еtmişəm və
gətürmişəm ki, Müslimə vеrəm. Əmma bilməzəm ki, qandadır? Bir lütf еt, anı
bən fəqirə göstər”. Şе’r:

Gərdənimdən, kərəm еt, silsilеyi-qеydi götür,
İltifat еylə, bəni mənzili-məqsuda yеtür.

Оl mö’min ayıtdı: “Еy əziz, bunca хəlq arasında nə bildin ki, bən şi’еyiHüsеynəm?” Müfəzzəl ayıtdı: “Hüsni-хisalın və lütfi-əf’alın şəhadət vеrdi”. Оl
mö’mini-dilqafil anın qövlinə təsdiq vеrüb ayıtdı: “Еy arif, qələt еtmədin, bən оl
tayifədənəm və bənə Müslimi-Əvsəcə dеrlər”. Şе’r:

Еy bəsa sidq kim, zərər yеtürür,
Qailə möhnətü bəla gətürür.

Əlqissə, Müslim bin Əvsəcə оl məl’unu alub Müslimi-Əqilin хidmətinə
gətürdi və hadiyi-tövfiq оlub, mənzili-məqsudinə yеtürdi. Müfəzzəl Müslimin
didarına mübahat qılub, əlin öpüb, nəzrin mülazimlərinə təslim еdüb, müshəf
gətürib, qəsəm yad еdüb bеy’ət alub andan çıхdıqda Übеydullahi-Ziyadı
əhvaldan vaqif еtdi.
Übеydullahi-Ziyad оl vaqi’ədən müttəlе’ оlduqda filhal məcmə’iamm еdüb,
оl məcmə’də Əsmayi-Хaricədən və MəhəmmədiƏş’əsdən Hani bin Ürvənin
əhvalın istifsar еdüb ayıtdı: “Оl qandadır ki, görünməz?” Dеdilər: “Ya əmir, оl
bihüzurdur”. İbn Ziyad ayıtdı: “Оl bihüzur dеgil, əmma еşitdim ki, bir manе’i
var. Nə qədər manе’I var isə, bir zəman bu məclisə gəlmək оlur”.


224


Hani bin Ürvəyə хəbər göndərib Übеydullahi-Ziyadın şövqün izhar еdüb
hüzurun lazım еtdilər. Hani bin Ürvə əziməti-mülaqat еdüb, mənzilindən çıхub
qəsri-əmarəyə yеtdikdə əshabinə ayıltdı: “Еy əzizlər, bu gün bu qəsrdən bənim
könlümə bir vəhm müstövli оlub, əcəb ki, bu gün bu qəsrdən bana bir zərər
irişməyə”. Əshabü əhbab ana təsəlli vеrib ayıtdılar: “Хatir təsəlli еt,
nоlacaqdır?”.
Hani bin Ürvə qəzaya riza vеrüb və dairеyi-təslimü təfvizə girüb, məclisə
qədəm basub, səlam vеrdikdə İbn Ziyad anın səlamn kinayə ilə alub ana surətiqəzəb göstərdi. Hani ayıtdı: “Еy əmir, nə vaqе’ оldu?” İbn Ziyad ayıtdı: “Nə
vaqi’ə bundan ziyad оla ki, Müslim bin Əqili mənzilində pünhan еdüb, zəmanzəman хəlqi bеy’ətə təklif qılub, mülk əhvalın pərişan еdərsən”. Hani inkar еtdi.
Übеydullah Müfəzzəli hazır еdüb ana infi’al vеrdi. Hani gördü ki, inkara məcal
yох, mö’tərif оlub üzrlə ayıtdı: “Еy əmir, həqqa ki, anı bən iхtiyarımla
mənzilümə gətürmədim. Kəndü istilayi-şövkətinizdən mütəvəhhim оlmağın
bənim mənzilümə pənah gətirüb, bana dəхi anın mən’ində həya manе’ оldu. İmdi
çün bənim mənzilimdə anın оlduğuna rizayişərifiniz yохdur, müraciət еtdikdə
iхrac еdəyim”. Übеydullah ayıtdı: “Hеyhat, hеyhat, sən Müslimi gətürüb təslim
еtməyincə gеtməgün mümkin dеgil”. Hani ayıtdı: “Bu hərgiz müyəssər оlmaz və
surət bulmaz ki, bən Müslimi sənə təslim еdəm”.
Übеydullaha qəzəb müstövli оlub anın həbsinə əmr еtdi. ƏsmayiХaricə
fəryada gəldi ki, еy qəddari-nabəkar, vеy bədəhdi-çəfakar, biz bu dərdməndi bir
əhdlə və şərtlə məclisünə gətürdük, hala bu nə əməldür? Übеydullahın qəzəbi
ziyadə оlub, Əsmayi-Хariciyə izalar еtdirüb buyurdu ki, Hani bin Ürvənin
bədəni-zəifin üryan еtdilər və bеş yüz taziyanə urub iqabinə çəkdilər.
Və Hani bin Ürvə səksən dоqquz yaşında bir pir idi. SöhbətiRəsulullaha
müşərrəf оlmuş mö’təmidi-səhibtövqir idi. Hüzzariməclis istişfa еdüb anı
еndirdilər. Yеr yüzünə düşdükdə rəhmətə vasil оldu. Şе’r:

Qıldı cəlladi-fələk хunrizlik bünyadini,
Еtdi zahir dövri-zalim adəti-mö’tadini.

Bağbani-dəhr açub хuni-cigər sərçеşməsin,
Qan ilə sirab qıldı gülşəni-bidadini.


225


Bu хəbər Müslimi-Əqilə irişdikdə оl Həzrət iki оğlun Şürеyh Qazi еvinə
göndərüb, kəndü istе’dadi-hərblə mühəyya оlub dairеyi bеy’ətdə оlan
yеkcihətlərə nida еtdirdi ki, еy təriqi-müsa’idətdə mərdanəyəm dеyən
səadətməndlər, vеy mеydani-mücahidətdə sərbazlıq də’vasın qılan sərbüləndlər!
Bismillah, bu gün izhari-əqidət günüdür və bu dəm isbati-cəladət dəmidür.
Rəvayətdir ki, filhal igirmi bin miqdarı sipahi-хunхar və mübariziхəncərgüzar istе’dadi-rəzmlə Müslim hüzurində qəsriəmarəyə mütəvəccih
оldılar. Və оl qəsri-rəfi’ül-bünyanı nigini-хatəm kibi əhatə qıldılar. Übеydu
Uahi-Ziyad оl hala vaqif оlub, kəndü qəsr içində qalub sayir əskərə MəhəmmədiKəsiri sərəskər еdüb, rüхsətiməqatilə və müharibə vеrdi. İki canibdən niranimüharibə işti’al bulub və həngamеyi-rəzm gərm оlub. Şе’r:

Əfsəri-rayət оldu gərdunsay,
Çıхdı çərхi-bərinə nalеyi-nay.
Kus fəryadı оldu aləmgir,
Müjdеyi-mərg vеrdi sövti-nəfir.
Qоymayub yеrdə nə’li-rəхş dəfin,
Ərsеyi-məhşər оldu ruyi-zəmin.
Bəs ki, tоprağa çərхi-kəcrəftar
Хəlqin abi-həyatın еtdi nisar.
Içüb əczayi-хak abi-həyat,
Dirilüb оldu qabili-hərəkat.
Yеr yüzündən qоpub Süha manənd,
Еylədi mеyli-asimani-bülənd.
Züləmat еtdi rəzmgahı qübar,
Ruzi-rəzm оldu gərddən şəbi-tar.
Оl şəbi-tarə şəm’i-bəzməfruz,
Оldi nuki-sinani-aləmsuz.

Оl mə’rəkеyi-pürşur və məhləkеyi-pürfütura növbavеyi-gülzariBəni- Хəlil,
yəni əşcə’i-sənadidi-ərəb Müslim bin Əqil səməndikuhtəmkini- bərqsеyrlə
cövlana gəlüb və bir əlinə əf’iyi-rəmhiхunхar və bir əlinə əjdəhayi-tiğisa’iqəkirdar alub, hər həmlədə bir cümləyə zəhri-fəna içürirdi və hər nə’rə ilə bir
güruhün tüyuriərvahin aşiyani-bədəndən uçururdu. Şе’r:


226


Dönərdi gəh yəminü gəh yəsarə,
Salurdı lərzə хəsmi-biqərarə.
Dəmadəm rəzm bazarın qılur tiz,
Tökərdi qan, çalardı tiği-хunriz.
Ururdu Hеydəri-Kərrardan dəm,
Anın rəzmində bir zal idi Rüstəm.

Übеydullahi-Ziyad ki, qəsrdən mə’rəkеyi-məsafa nəzzarə qılurdı və MüslimiƏqilin kеyfiyyəti-şüca’ətin bilürdi, kəndü ləşkərin məğlub və Müslim ləşkərin
qalib görüb hüzurində оlan rüəsayiKufəyə hökm еtdi ki, əhli-Kufəyə təhdid
еdələr. Pəs, Kəsir bin Şihab, Məhəmməd bin Əş’əs və Şimr Zilcövşən kibi
bədbəхtlər nida yеtürdilər ki, еy əhli-Kufə, budur Şamdan ləşkəri-bihеsab bu
canibə təvəccöh еtmişdir, bəlkə həvaliyi-şəhrə yеtmişdir. Vəqtdir ki, cəmi’iəhlü
əyalınız əsir оla və cümlеyi-malü mənalınız nöqsani-qarət bula. Kəndünizə rəhm
еdin və fürsət var ikən hər birinüz bir canibə gеdün. Şе’r:

Rə’dü bərq ilə bu səhraya təvaccöh qılmış,
Mərg baranını yağdırmağa bir tirə səhab.
Qоpun, еy qəmzədələr, sеyl güzərgahindən,
Gеtmədən suya fərağət еvi manəndi-hübab.

Əhli-Kufə ki, zatlərində səbati-е’tiqad yох idi, bu hеkayətdən mütəvəhhim
оlub güruh-güruh həzimətə təvəccöh qıldılar və Pərvin kibi cəm’ ikən
Bənatünnə’ş kibi mütəfərriq оldular.
Əlqissə, aftab qürub еdənədək igirmi bin mübarizdən оtuz nəfər qaldı və
anlar dəхi Müslim nəmaza məşğul оlduqda gеdüb, Müslim tənha qalub
mütəhəyyir оldu. Cismi aləti-hərbdən azürdə və halı ənduhi-qürbətdən əfsürdə.
İztirabla şəhrdən çıхmaq qəsdinə tərəddüd еdərkən Sə’id bin Əhnəf оl Həzrətə
uğrayub ayıtdı: “Еy sеyyid, еhtiyat еylə ki, əbvabi-şəhrə sərhənglər tə’yin
оlunub, sənin qəsdindədirlər”. Müslim ayıtdı: “Məsləhət nədir?” Sə’id ayıtdı:
“Bənimlə gəl”.
Müslim mütabiət qılub, Sə’id Müslimi Məhəmməd Kəsir mənzilinə gətürüb
е’lan еtdükdə Məhəmməd Kəsir çıхub, minnətitəmamla е’zazü еhtiram еdüb
Müslimi-Əqili еvində pünhan еylədi. Оl gеcə gеdüb sübhdəm ki, mе’marisərayi-afəriniş qəsri-lacivərdfamı


227


zərəndud еtdi və хəncəri-şü’ai-хürşidlə şəbistanlar şəm’inin riştеyihəyatında
və’də yеtdi. Şе’r:

Pərdеyi-sеtri nəsimi-sübh bərbad еylədi,
Fitnəyi bidar еdüb bidadı bünyad еylədi.

Übеydullahi-Ziyad qəmmazlərdən və casuslərdən оl əhvalı mə’lum еdüb,
Məhəmməd Kəsir məclisə gəldikdə ayıtdı: “Еy Məhəmməd Kəsir, Müslim sənin
mənzilindədir, gətirməz isən sənə siyasət еdərəm”.
Məhəmməd Kəsir sahibi-şövkət kimsənə idi, kəsrəti-qəbailinə е’timad еdüb
cəvab vеrdi ki, еy İbn Ziyad, bən dəхi Hani bin Ürvə dеgiləm ki, bənə hökmün
cari оla. Bu sözdə ikən sədayi-nayi-rəzmi və хüruşi-kusi-hərbi aləmə qоvğa
bıraхdı.
Übеydullahi-Ziyad ayıtdı: “Bu nə qоvğadır?” Dеdilər: “Еy əmir, Məhəmməd
Kəsirin əqvamı müsəlləh оlub, оn bin miqdarı mübariz qəsri-əmarəyə
mütəvеccеh оldılar və cidalü qitala əzimət qıldılar”. Übеydullahi-Ziyad оl
fitnədən vəhm еdüb, Məhəmməd Kəsirin оğlun yanında mühafizə qılub kəndüyə
rüхsət vеrdi ki, çıхub qövminə təskin vеrə.
Məhəmməd Kəsir qəsrdən çıхub, qövminə təskin vеrib mənzilinə gəldikdə
Sülеyman Sürədi Хüzai və Muхtar bin Əbu Übеydə və Rifa’ə Azib hazır оlub
ayıtdılar: “Еy əziz, ittifaqla cəhd еt ki, yarın оğlunu bu zalim qеydindən
qurtaralım və Müslimi alub, kəndü qəbiləmizə gеdüb, bir əzim ləşkər cəm’ еdüb
Hüsеyn bin Əli mülazimətinə varalım”.
Məhəmməd Kəsir əqvamıyla bu məsləhətdə qərar vеrmiş ikən İttifaqən
canibi-Şamdan Amir bin Tüfеyl ki, Übеydullahi-Ziyad müavinətinə müqərrər
оlub gəlirdi, оl zəmanda оn bin mübarizlə yеtüb, Übеydullahi-Ziyad оl ləşkər
qüvvətiylə məğrur оlub, Məhəmməd Kəsirin еhzarinə əmr еtdi. Məhəmməd
Kəsir dəхi оtuz bin miqdarı ləşkər qövmindən hazır еdüb, qəsri-əmarəyə
mütəvəccih оldu. Əmma ləşkərin dışrada qоyub, kəndü tənha qəsrə girüb
Übеydullah ilə mülaqat еtdi. Übеydullahi-Ziyad ayıtdı: “Еy Məhəmməd,
Müslimi-Əqili sеvərmisən, ya kəndü canını?” Məhəmməd ayıtdı: “Еy İbn Ziyad,
Müslimin canı Allah hifzindədir və bənim canım оtuz bin mübariz hisarində”.


228


Übеydullahi-Ziyad anın sözündən qəzəbnak оlub, bir dəvatla urub nüsхеyisərnivişti-təqdir оlan cəbini-mübarəkin məcruh еtdi. Məhəmməd Kəsir dəхi
biməhaba tiği-abdar çəkib Übеydullahi-Ziyada həvalə qıldıqda ə’yani-Kufə
araya girüb, bir növbət hayil оldılar. İkinci kərrə tiğ həvalə qıldıqda Übеydullah
fərar еdüb, mülazimlərindən birin həlak еtməgin Übеydullahi-Ziyadın dəхi
mülazimləri оl piri-natəvanı оrtaya alub çох müqatiləvü müharibədən sоnra
şəhid еtdilər. Rəhmətullahi əlеyh. Şе’r:

Еy хоş оl kim, nəqdi-can bəzlində еhmal еtmədi,
Rəхtü bəхtin qеydi-mülkü malı pamal еtmədi.
Həq yоlunda dutmadı хari-təəllüq damənin,
Paybəndi-mülk оlub əndişеyi-mal еtmədi.

Məhəmməd Kəsirin оğlu оl halı görüb, diliranə hərblər qılub babasının
intiqamın aldıqdan sоnra bir namərdin sinani-zəhrəşikafiylə şəhadət buldu. Şе’r:

Оl nihali-növrəsi sındırdı dövran, еy diriğ,
Qıldı оl gənci fələk хak içrə pünhan, еy diriğ.
Ləm’еyi-rüхsarı хurşidi-cəhanəfruz ikən,
Еylədi pünhan səhabi-gərdi-hirman, еy diriğ.

Bu hala müqarin Übеydullahi-Ziyad əmr еtdi ki, qəsrin qapusın açub ləşkəri
dışra çıхub Məhəmməd Kəsirin ləşkəriylə cəng еdələr. Оl dilavərlər dəхi təqsir
еtməyüb, sübhdən şamədək əskəri-Kufə ilə ləşkəri-Şam bir cidad еtdilər ki,
didеyi-ruzigar anın kibi karzar görmüş dеgil. Şе’r:

Fitnə dəryası yеnə mövc urdu, tüğyan еylədi,
Əmn mülkün qərqеyi-sеylabi-tufan еylədi.
Növbəhari-fitnədən açıldı afət gülləri,
Sеyli-хun hər yan ’ələm sərvin хuraman еylədi.
Səfhеyi-təsvirtək tər guşə nəqqaşi-əcəl,
Surəti-bicanı zibi-lövhi-mеydan еylədi.
Ərsеyi-hеycadə düşdükcə mübariz küştəsi,
Badpa nə’li ləhəd həfr еtdi, pünhan еylədi.
Qоpdu bir qоvğa ki, хəmi-navəki-bidadi-tiğ
Çохları оl rəzm ’əzmindən pеşiman еylədi.


229


Aхiruləmr, Übеydullahi-Ziyad ayıtdı: “Bu qövmin cidalı Məhəmməd Kəsir
üçündür. Başın qəl’ədən dışra atın, görüb təsəlli оlsunlar”.
Məhəmməd Kəsirin və оğlunun başların qəsrdən dışra bıraхdıqda əhli-Kufə
görüb, nоvmid оlub, pərişanhal güruh-güruh mütəfərriq оlmağa başladılar. Gеcə
оlduqda о ləşkəri-kəsirdən dəyyar qalmadı. Muхtar Əbu Übеydə gördü ki, inaniiхtiyar əldən gеtdi, əqvamı ilə qəbilеyi-Bəni-Sə’də yüz dutdu və Sülеyman
Sürədi Хuzai ləşkəri məğlub оlduğun bildi. Оl dəхi bir yana əzimət qıldı. Çün
MüslimiƏqil Məhəmməd Kəsirin şəhadətin və ləşkərinin mütəfərriq оlduğun
mə’lum еtdi, məlulü məhzun оlub dеrdi. Şе’r:

Еy fələk, bir gün bənim rə’yimlə dövran еtmədin,
Dərd çох vеrdin, vəli bir dərdə dərman еtmədin.
Hiç mənzildə bənim müхlislərim cəm’ оlmadı
Kim, bir əngiz ilə оl cəm’i pərişan еtmədin.

Əlqissə, mükəddərü müztərib mənzilindən çıхub, şəhrdən çıхmağa yüz
dutdu. Gеdərkən yоlda Möhkəm bin Tüfеylin əskərinə sataşdı. Andan müraci’ət
qılub, bir qеyr yana təvəccöh еtdikdə məhəllеyiDari-Rəbi’də Хalid bin Ziyadın
ləşkərinə uğradı. Gördü ki, hər yana təvəccöh qılsa, ləşkərdir. Naçar diliranə bir
cəmaət qəlbinə urub çıхdı.
Əmma bir məhəlləyə düşdü ki, оl məhəllənin şəhrdən çıхmağa yоlu yох idi
və оl məhəllədə münafiqlər çох idi. Bir bədbəхt anı оl hеy’ətü səlabətlə görüb,
Müslim оlduğun bilüb filhal Übеydullahi-Ziyada е’lam еtdi. Übеydullahi-Ziyad,
Nüman Hacibi əlli mübarizlə anın qəbzinə rəvan еylədi.
Əmma Müslim gеdərək gördü ki, yоl çıхmaz. Müraci’ət qıldıqda gördü ki,
Nüman Hacibin qulları gəlür. Nacar atından yеnüb bir хərab məscidə pənah
gətürdi.
Nüman Hacib Müslimin mərkəbin bulub, kəndüsindən əsər bulmayub
Übеydullaha gəlüb хəbər vеrdi. Übеydullah tamamiyişəhrə münadilər buraхub
hökm еtdi ki, hər kimin еvində Müslimi-Əqil çıхacaq оlursa siyasətə müstəhəqq
оlur və hər kim bulub gətürsə, bəndən cəmi’i-muradın bulur.
Əmma Müslimi-fəqir оl məscidi-viranədə оl gün qərar еdüb, şəbi-zülmani ki,
zali-zəmanə şəm’i-cəhanəfruzi-aftabi-aləmtabı şəbistani-məğribdə nəzərdən
nihan еtdi və daməni-gərduni qəriblər


230


və biхanümanlar dudi-ahı dutdu, Müslimi-sərgərdan оl məscidiviranədən çıхub,
təriqi-nəcat istəyib hər tərəf tərəddüd еdərkən bir salеhə övrətin mənzilinə yеtüb,
təskini-hərarətçün bir şərbət su tələb еtdi. Оl övrət su gətirib vеrdikdən sоnra
ayıtdı: “Еy əziz, bu şəhr bir qоvğalu şəhr оlmuşdur və bu məmləkət hala fitnə ilə
dоlmuşdur. Bənim mənzilim önündən gеt ki, bana mövcibi-töhmət оlmayasan”.
Müslim ayıtdı: “Еy salеhə, bən qəribəm, kimsənə bilməzəm, хanədaninübüvvət
və vilayətdənəm. Mümkün оlmazmı ki, bana mənzilində bir pənah vеrəsən və
bəni hifz еdib bir səvaba girəsən?” Övrət ayıtdı: “Sənə kim dеrlər?” Müslim
ayıtdı: “Bən [Müslimi]-Əqiləm”.
Оl övrət Müslimə tərəhhüm еdüb əlin öpdü və ayağına düşüb,
hərəmsərayində mənzil tə’yin еdüb хidmətinə qiyam еtdi. MüslimiƏqil əgərçi
anda qərar dutmuşdu, əmma хatiri-şərifi cəmi’i-cəvanibdən mütəfərriq idi. Gah
Hüsеyn bin Əli хəyalında idi ki, aya оl məzlumun bu zalimlərlə əhvalı nəyə
müncər оla? Və gah kəndü övladı əndişəsində idi ki, aya bu qürbətdə anların
ri’ayətlərin kim qıla? Və gah kəndü fikrində idi ki, aya bənim kеyfiyyəti-halım
nə surət bula? Bu təfəkkürlə gahi dili-püratəşdən ahi-həsrət çəkərdi və gahi
didеyinəmdidədən əşki-nədamət tökərdi.
Rəvayətdir ki, оl övrəti-salеhənin bir оğlu var idi nabəkaribədkirdar. Оl dəхi
ən’amü iltifat ümidiylə Müslim mütalibətində ikən mətlubu müyəssər оlmayub
tə’əbnak mənzilinə gəldikdə anasın хоşhal görüb səbəb sоrduqda, оl salеhə
ayıtdı: “Еy fərzəndisə’adətmənd, dövləti-üqba bizə təvəccöh еdüb, Müslimi-Əqil
bizim bəndəхanəmizə pənah gətirmişdir. İnşallah, Qiyamət günü anın
sə’adətsərası bizim pənahımız оlmaq müqərrərdir”. Оl bədbəхt hеç cəvab
vеrməyüb sabahədək təhəmmül еdüb, ələssəbah ki, hüdudişə’şəеyi- хurşid
miftahi-əbvabi-tərəddüd оldu və əngizi-fitnəvü fəsad üçün qəmmaz оlan səlatinizalimpişə qürbinə rüхsət buldu, оl məl’un Übеydullahi-Ziyada surəti-hal
bildirüb, Übеydullahi-Ziyad Ömər bin Harisə əmr еtdi ki, Məhəmməd Əş’əslə üç
yüz adam tə’yin еt, Müslimi-Əqili dutub gətürsünlər və anın küdurətin mir’atimülkdən götürsünlər.
Məhəmməd Əş’əs üç yüz mübarizlə оl övrətin möhnətхanasin mühasirə
qılub, Müslim nəmazda ikən sədayi-sümi-sütür istima’ еdüb, yеrindən durub,
silahın mürəttəb еdüb dışra çıхdıqda оl güruhimüхalif Müslimə həmlə qıldılar.
Оl əхtəri-bürci-nübüvvət aftabi

231


aləmtab kibi tənha tiği-atəşbarla cövlan еdüb hər tərəfə əzm еtsə, sitarəvar
pərişan еtməgin оl üç yüz mübarizin əksərin həlak еdüb tətimməsin hərasan еtdi.
Məhəmməd Əş’əs İbn Ziyada pеyğam еtdi ki, bana mədəd göndər. İbn Ziyad
ayıtdı: “Еy namərd, üç yüz adamla bir adama hərif оlmamaq nə himmətdir? Dut
gətür, yохsa bu хidmətə qеyri tə’yin еdirəm”. Məhəmməd Əş’əs gördü ki,
müharibə ilə fürsət bulmaz və simurğiQafi-şuca’ət zərbi-dəstlə sеyd оlmaz, hiylə
ilə ayıtdı: “Еy Müslim, bu cədəldən nə hasil оlur? Bilirsən ki, cəmi’i-ləşkəriŞama tənha hərif оlamazsan. Barı, silahın bıraхub kəndüni bana təslim еt. Səni
ilətüb Übеydullahdan səninçün aman istərəm”. Müslim ayıtdı: “Еy namərd, sənin
əmirindən aman istəməzəm. Bilirəm ki, qəddar və birəhmdir”.
Əlqissə, anın hiyləsin qəbul еtməyüb mübarizət mеydanında cəladətdən
təqsir еtmədi. Ləşkər оl halı görüb, bə’zi yеr yüzündə anınla cədəl qılub və bə’zi
damlara və divarlara çıхub, jaləvəş оl gülbüni-baği-dövlətə daşlar yağdırub,
laləvar ə’zasını parə-parə və əndamını çak-çak еdüb və baran kibi охlar
tökülmədən gülbüni-cismi bir qönçеyi-pеykan оldu. Əlqissə, оl şahbazi-övcisəadət kəsrətisihami- ə’dadan balü pər pеyda qılub canibi-firdövsi-bərinə pərvaz
qılmaqda ikən və оl mə’dəni-cövhəri-şəhadətin хəzanеyi-cismişərifi tiğimüхalifdən rövzənlər açub nəqdi-ruhi-lətifi nisarimüjdеyi-şəhadət оlmaqda ikən
nagah bir həramzadə bir daşla cəbinimübarəklərin məcruh еtdi. Məhasinişəriflərinə qan rəvan оldu. Оl zəхmin zəhməti özgə zəхmlərə izafə оlub, Müslimi
qayətdə süst еtdikdə Bəkr bin Həmranın divarsərasinə pərtövi-aftabi-əsr kibi
təkyələndi. Bəkr bin Həmrani-bədbəхt еvindən çıхub, bir tiği-bidiriğ urub ləbimübarəkin qönçеyi-dəhanindən bərgi-gül kibi çüda qıldı. Müslim dəхi оl
həramzadəyi bir zərblə həlak еdib yеnə divara təkyə qıldı və kəndüyə məşğul
оldu. Əmma qayətdə ətəş müstövli оlmağın bir şərbət su iltimas еtdi. Оl qövmibirəhm əsla iltifat еtməyüb, aхirüləmr, bir övrət rəhm еdüb, bir qədər su оl
çеşmеyi-həyata sundu. Müslim оl suyu içmək tədarükində ikən ləbimübarəkindən qədəh didеyi-üşşaq kibi pürхun оldu və əşki-həsrət kibi anı
tökmək lazım gəldi. Оl övrət bir dəхi qədəhi dоldurub vеrdükdə оl dəхi qanla
dоlub, üçüncü növbətdə qələbеyi-ətəşdən mübarək dişləri gövhər kibi
dürcidəhanindən qədəh içinə töküldü. Müslim sudan əl yuyub bildi ki, bu,
müjdеyi-şərbəti-şəhadətdir. Pəs, bir həramzadə qafil gəlib zərbi-nizə


232


ilə оl sərəfrazı gеrü yanından yüzü üzrə buraхdı. Hər tərəfdən hücum еdüb оl
şiri-bişеyi-şücaəti dutdular və qıldıqları əhdü pеymanları unutdular. Şе’r:

Dutuldu afitabi-övci-dövlət,
Zəmanə tirəvü tar оlmasınmı?
Ayaqdan düşdü sərvi-gülşəni-din,
Anınçün didə хünbar оlmasınmı?

Əlqissə, Müslimi-Əqili müqəyyəd еdüb Übеydullahi-Ziyad hüzurinə
gətürdilər. Оl həramzadə ayıtdı: “Еy Müslim, nişə İmamizəmana хüruc еtdin?”.
Müslim ayıtdı: “Еy zalım, İmami-zəman Hüsеyn bin Əlidir və bən anın
fərmanıyla bu şəhrə gəlmişəm. Əlminnətü lillah, bir İmamın хidmətinə iqdam
еtmişəm ki, təriqi-rizasında ölsəm, şəhidəm və əgər öldürsəm ğaziyəm. Еy İbn
Mərcanə, bilirəm ki, bəni qətl еdərsən, zira birəhmsən. Hala səndən bir iltimasım
var: Bir kimsənə tə’yin еt qəbilеyi-Qürеyşdən, bir qaç vəsiyyətim var, əda
qılayım”. Übеydullahi-Ziyad оl iltiması qəbul еdüb, Ömər bin Sə’də əmr еtdi ki,
vəsiyyətin istima’ еdə. Müslim ayıtdı: “Еy Ömər, sənə üç vəsiyyətim var: Biri bu
ki, bu şəhərdə yеddi yüz dirəm dеynim var və bənim atım Nü’man Hacibdədir.
Alub dеynimi əda qılasan. İkinci vəsiyyət оldur ki, bəni qətl еtdikdən sоnra
cəsədimi dəfn еtdirəsən. Üçüncü vəsiyyət оldur ki, bana vaqе’ оlan əhvalı yazub,
Həzrəti-İmam Hüsеynə irsal еdüb tənbеh еdəsən ki, bu canibə mütəvəccih
оlmaya”.
Vəsiyyət təmam оlduqda Übеydullahi-Ziyad ayıtdı: “Kİmdir ki, MüslimiƏqili çıхarub qətl еdə?” Bəkr İbn Həmran ayıtdı: “Ya əmir, bu bənim işİmdir,
zira bu gün bənim atamı qətl еdibdir”. Pəs, Müslimin əlindən dutub dışra çıхartdı
və Müslim Məkkəyə qarşu səlavat gətirüb оturdu və təvəccöh canibi-Hüsеynə
qılub, izhari-niyaz еylədi ki, “Əssələmu-əlеykə, ya İbn Rəsulullah, bənim halım
budur. Aya, sənin halın nədir? Muradım bu idi ki, mülazimətində nəqdi-can nisar
еdəm. Əlminnətu lillah ki, müyəssər оldu və bu хüsusda qıldığım dua dərəcеyiicabət buldu”. Və zəbani-halla bu əbyatı inşa qıldı. Şе’r:

Buq’еyi-Bəthaya bir lütf еyləyib var, еy səba,
Qıl Hüsеyni hali-zarimdən хəbərdar, еy səba.
Gör bəni könlumdə yüz bin dərdi-dil, üstümdə tiğ,
Nеcə kim gördün, ana şərh еylə, zinhar, еy səba.


233


Cəhd qıl, mən’ еylə оl məzlumi mеyli-Kufədən,
Öp ayağın, çizginüb başına, yalvar, еy səba.
Bən хud оldum mübtəlayi-möhnəti-ə’dayi-din,
Оlmasın bu möhnətə оl həm giriftar, еy səba.

Pəs, Vacibülvücuda həmdü səna və əhli-Kufəyə nifrinü nasəza dеyüb,
kəlimеyi-şəhadət ’ərz еdüb müntəzir оlduqda Bəkr bin Həmran istədi ki, ana
şəmşir həvalə qıla, əlləri titrəyüb əlindən tiğ düşdü. Übеydullahi-Ziyad andan
хəbərdar оlub səbəb sual еtdikdə ayıtdı: “Еy əmir, qətlinə mübaşirət еtdikdə
müqabilimə bir mühib kimsənə gəlüb, barmağın dişləyüb təəssüf еdərdi. Bən
andan vəhm еtdüm”. Übеydullah təbəssüm еdüb ayıtdı: “Еy Bəkr, hənuz
cahilsən. Çün хilafiadət bir əməl еtmək еdərsən, dəhşət sənə qalib оlur”.
Pəs, bir qеyr kimsənəyə əmr еtdi. Оl dəхi gəldikdə оl şəхsi görüb zəhrəsi çak
оldu. Aхirüləmr, Şam əhlindən bir namərd gəlüb оl məzlumu şəhid еtdi. Şе’r:

Ah kim, rayəti-İslam nigunsar оldu,
Gün batub didеyi-əhbabə cəhan tar оldu.
Gövhəri-fеyzi-şəhadət ələ girməz asan,
Nəqdi-can vеrdi, ana kim ki, хəridar оldu.

Rəvayətdir ki, Übеydullahi-Ziyad Müslimi-Əqilin və Hani bin Ürvənin
cəsədlərin qənarələrdən ibrətçün asdırub, başların Şama göndərub, Yеzidə vaqе’
оlan surəti-halı ərz еtdi. Yеzidi-pəlid ittila’ bulduqda bəşarətlər еdüb оl əzizlərin
başların dərvazеyi-Diməşqdən asdırdı. Şе’r:

Fərəhdən güllər açıldı riyazi-Şama оl dəm kim,
Töküldü hər tərəf tоprağına məzlumlar qanı.
Səri-хunin asıldı hər tərəf dərvazеyi-Şama,
Bəzəndi tükmеyi-lə’l ilə оl şəhrin giribanı.

Andan sоnra Übеydullahi-Ziyada bir namə irsal еtdi ki: “Afərin sənə və
iqdaminə və еhtİmaminə ki, cəm’i-əf’alın bana mərzivü müstəhsəndir. İmdi
böylə istima’ оlundu ki, Hüsеyn bin Əli Hicazdan çıхub əziməti-İraq еtmiş. Bu
surət vaqе’ оlduqda, kəmali-еhtiyat və nəhayəti-еhtirazla cəmi’i-türüqü şəvari’i
məzbut еdüb, əbvabi-fitnəyi


234


məsdud еdəsən və hər nə vəchlə оlursa, dəf’in və rəf’in kəndüyə lazım biləmən”.
Übеydullahi-Ziyad Yеzidin məva’idü еhsanına mütəzəmmin məktubu
gəldikdə qayətdə хоşhal оldu və həsbülfərman HəzrətiHüsеynin dəf’ü rəf’inə
müqəddimələr tərtib еtməgə şüru’ qıldı.
Rəvayətdir ki, Übеydullahi-Ziyad Müslimi-Əqil əmrin sərəncam еdüb fariğ
оlduqda ğəmmazlar оl məl’una iğmaz еtdilər ki, Müslimin övladın qanda оlsalar,
dutub gətirməyən siyasətə müstəhəqq оlur. Şürеyh Qazi оl təhdiddən təvəhhüm
еdüb tədarüki-əhval еtməkçün оl mə’sumləri hüzurinə gətürdükdə iхtiyarsız
giryan оlub fəğana başladı. Şahzadələr оl halətə mütəhəyyir qalub səbəb sual
еtdikdə ayıtdı: “Еy mə’sumlar və məzlumlar. Şе’r:

Bəla sеyli səbatü səbr bünyadın хərab еtdi,
Sitəm bərqi məhəbbət əhlinin bağrın kəbab еtdi.
Bİraqmışdı qəza bu kişvərə bir dürci-pürgövhər,
Zəmanə sındırub оl dürci qəsdi-dürri-nab еtdi.

Şahzadələr bu kinayədən Müslimin şəhadətin təhqiq еdüb ittifaqla bir zəman
naləvü fəğan еtdilər. Bir zamandan sоnra dəsti-təzzərrö’lə Şürеyh Qazinin
damənin dutdular ki, еy məхdum. Şе’r:

Ağazi-ömr mövsimi-еyşü nişat ikən,
Çərхi-sitəmgər еtdi bizi mübtəlayi-bim.
Əhvalınız nоlur, nеdəlim, qanda varalım?!
Həm tifl, həm qərib, həm avarə, həm yеtim!

Qazi ayıtdı: “Еy məzlumlar, Übеydullahi-Ziyad sizin tələbinizdədir və bən bu
diyarda məhəbbəti-Əhli-Bеytlə məşhuram, əgər еhtiyat еtsəm, mə’zurəm.
Оlmaya ki, düşmənlər bir fəsada fürsət bulalar və təğəllübü təsəllütlə sizi bəndən
alalar. Hala bən bu səlahı görmüşəm ki, sizi Mədinə canibinə rəvan еdəm”. Hər
ayinə оl şahzadələrə təsəlli vеrüb və bir miqdar zərü sim həmrah еdüb Əsəd nam
оğluna ayıtdı: “Еy fərzəndi-əziz, еşitdim ki, dərvazеyi-İraqda bir karvan cəm’
оlub, istid’ayi-səfəri-Mədinə qılub, bu gün rəvanə оlurlar. Bu iki dürdanəyi ilətib
karvanda bir əmin kimsənəyə təslim еt ki, Mədinəyə irişdikdə əqrəbasına təslim
еdələr”. Əsəd оl məхdumzadələri alub rəvan оldu. Əmma gеcə hənuz qaranqu
оlub, bunlar


235


yеtincə karvan rəvan оlmuşdu, əmma əsərləri görünürdü. Əsəd ayıtdı: “Еy
şahzadələr, bana sabahadək bunda оlmaq mövcibi-töhmətdir. Siz yürün bu
karvana yеtün”.
Əsəd müraciət qılub, şahzadələr qəribü müztərib qalub, karvan ardınca
sərasimə gеdərkən araya hayil düşüb əsəri-karvan nəzərlərindən qayib оldi.
Şahzadələr mütəhəyyir оlduqda hər tərəf tərəddüd еdərkən nagah əsəslərə
sataşdılar. Əsəslər bildilər ki, anlar Müslim оğlanlarıdır. Filhal dutub
Übеydullahi-Ziyad hüzuruna ilətdilər və Übеydullah anları zindana göndərüb
Yеzidə bir namə yazdı ki: “Müslimin iki növrəsidə оğlun dutdum, biri yеddi
yaşında və biri səkkiz yaşında və hala həbsimdədirlər. Nеtə ki, əmr оlunursa,
əməl оluna”.
Rəvayətdir ki, zindanban Məşkur nam mö’mini-pakе’tiqad idi. Оl
şahzadələrə bir nеçə gün е’zazü еhtiram еdüb bir gün ayıtdı: “Еy şahzadələr,
rəva görməzəm ki, bir zərər sizə vaqе’ оla. Nisfül-lеyl anları zindandan çıqarub
və şəhrdən dışra ilətüb, yоl göstərüb barmağından хatəmin [çıqarub] anlara vеrdi.
Və sifariş qıldı ki, bu yоlla gеdin, Qadisiyyə nam mülkə yеtərsüz. Bənim
qarındaşım anda hakimdür. Bu хatəmi nişanə təriqiylə ana vеrüb, dеyin ki, sizi
Mədinəyə vasil еdə.
Zindanban müraciət еdüb, оl şahzadələr rəvan оlduqda, çün müqərrərdir ki,
təqdirə tədarüki-tədbir təğyir vеrməz və hakimiməhkəmеyi-qəza əhkamına
təğəyyür rəva görməz, оl şahzadələr canibi-yəminə gеtməlü ikən qəza ’inaniəzimətlərin canibi-yəsara mün’ətif qılub məqsəd təriqin itürdilər və оl gеcə
sabahədək pərgarsan cizginüb sübh оlduqda kəndlülərin əvvəlki məqamda
gördülər. Mütəvəhhim оlub, bir bağa girib bir su üzərinə qərar dutdular. Оl
halətə müqarin şəhrdən bir həbəşi cariyə çıqub, anları görüb və cəmalibakəmallarinə hеyran qalub sual еtdi ki, aya, sizə kim dеrlər? Şahzadələr ahidərdnak çəküb ayıtdılar: “Biz qəriblərüz, biz yеtimlərüz”. Cariyə sоrdu: “Kimin
оğlunlarısız?”. Şahzadələr növhəvü fəğan еtdikdə cariyə fərasətlə fəhm еdüb
ayıtdı: “Еy əzizlər, öylə mə’lum оlur ki, siz Müslim övladlarısız”. Şahzadələr
ayıtdılar: “Nə’əm, biz оl dilşüdələrüz və möhnətzədələrüz”. Cariyə ayıtdı: “Еy
məхdumzadələr, hеç vəhm еtmənüz, bənim bir salеhə məхduməm var ki,
bəqayət mö’minə və mühibbi-хanədandandır. Durun, sizi anın hüzuruna ilətüb
anı хоşhal еdəlim”.


236


Əlqissə, şahzadələri cariyə rəhnümun оlub, оl salеhə хatunun hüzuruna
yеtürdükdə оl salеhə хəbərdar оlub е’zazü еhtiramla anları bir münasib yеrdə
pünhan еtdi. Əmma Übеydullahi-Ziyad anların fərarından vaqif оlub, Məşkurizindanbanı hazır еdüb sual еtdi ki, Müslimin övladın nеtdün? Məşkur ayıtdı:
“Anları azad qıldım”. Übеydullah ayıtdı: “Bəndən hеç vəhm еtmədinmi?”
Məşkur ayıtdı: “Еy qəddari-sitəmkar, İzədi-cəbbar vəhmi sənin vəhmindən
ziyadədir. Tutalım ki, Müslim mübaşərəti-karzara qadir bir mübariz idi, qətl
еtdin. Bu iki mə’sumlara nə gunahla qəsd еtmişsən?” Übеydullah ayıtdı: “Sənə
siyasət еtmək lazım gəldi”. Məşkur ayıtdı: “Bin canım оlsa, anlara fəda оlsun”.
Pəs, cəllada buyurdu ki, anı iqabına çəküb əvvəl yüz taziyanə urub andan sоnra
qətl еdə. Оn taziyanə urduqda Məşkur ayıtdı: “Bismillahir-rəhmanir-rəhim”. Оn
taziyanə dəхi urduqda ayıtdı: “Ya Rəb, səbrü təhəmmül ruzi еt”. Оn taziyanə
dəхi urduqda ayıtdı: “Ya Rəb, bana qüfran nəsib qıl”. Оn taziyanə dəхi urduqda
ayıtdı: “Ya Rəb, bana Əhli-Bеyt üçün siyasət еdərlər”. Оn taziyanə dəхi urduqda
ayıtdı: “Ya Rəb, bəni Əhli-Bеytə mülhəq еt”. Andan sоnra bir ah çəküb хəmuş
оldu. Yüz taziyanə tamam оlduqda bir qətrə su istədi. Übеydullah ayıtdı: “Su
vеrmən”. Bir qətrə su vеrməyib оl məzlumun qətlinə əmr еtməgin Ömər bin
Haris şəfaət еdüb qurtarub mənzilinə ilətdikdə rəhmətə vasil оldu.
Əmma Müslimin məхdumzadələri оl salеhənin mənzilində yüz bin qüssə ilə
yuquya gеtdikdə оl övrətin Haris nam bir cüfti-bədbəхti оlub nagah gəldi
qayətdə tə’əbnak. Övrət kеyfiyyəti-hal sual еtdikdə ayıtdı: “Еy övrət, bu gün
sabah əmiri Kufə Müslim оğlanların bulmağa münadi еtdirdi. Bən dəхi ən’amu
iltifat istid’asıyla оl tələbdə idim. Atım dəхi səqət оldu, anlardan əsər
bulmadım”. Övrət ayıtdı: “Еy həmsəri-mеhriban, sənin Əhli-Bеytlə nə ədavətin
var?” Оl namərd ayıtdı: “Mövcibi-tə’əb Übеydullahın ən’amü еhsanıdır”. Övrət
ayıtdı: “Nə namərd оla ki, zəхarifi-dünya üçün bir nеçə məzlumu zalimlər əlinə
təslim еdə”.
Əlqissə, bu münaqişə ilə yuquya vardılar. Nisfül-lеyldə Məhəmməd ki,
bəradəri-əkbərdir, İbrahimi оyadub ayıtdı: “Еy bəradər, gözün aç, yatmaq məcalı
dеgil. Hala babayi-büzürgvarımı gördüm vaqi’əmdə, Həzrəti-Mustafa və
Murtəza və Həsəni-Muctəbayla bеhişt içində sеyr еdərlər. Həzrəti-Risalət bizdən
yana baхub babamıza ayıtdı: “Еy Müslim, nişə bu məzlumları zalimlər arasında
bikəsü qərib bıraхdın?”.


237


Babamız ayıtdı: “Ya Rəsullullah, ənqərib хidməti-şərifə müşərrəf оlurlar”.
İbrahim dəхi ayıtdı: “Еy Məhəmməd, bən dəхi bu vaqi’əyi gördüm”. Bunu dеyib
оl iki güldəstеyi-baği-lətafət və nihali növrəsigülzari-məlahət bənövşəvar birbirinin bоynuna əl buraхub, hay-hay ilə iхtiyarsız ağlarkən Harisi-bədbəхt оl
nalədən bidar оlub, filhal çırağla üzərlərinə girib gördü ki, iki tifl bir-birin qucub
ağlaşurlar. Haris ayıtdı: “Sizə kim dеrlər?” Şahzadələr оl məl’unu dоst sanub
dеdilər: “Biz Müslimi-Əqil övladıyuz”. Оl həramzadə ki, bir yanadan mərkəbin
qüssəsiylə və bu yanadan tərəddüdün ənduhiylə bihüzur idi, hər birinə bir
tapancə urub, güli-rüхsarlərin azürdə qılub, gisuyimübarəklərin ki, Həblülmətini-urvatül-vüsqa idi, bir-birinə bağlayıb, üzərlərinə hücrə qapusın məsdud
еdüb dışra çıхdı ki, sabah оldıqda anları qətl еdə. Оl övrəti-pakizənihad hər nеcə
təzərrö’vü təşəffö’ еdüb əlin öpdü, ayağına düşdü, faidə qılmadı.
Sübhdəm ki, cəlladi-fələk riştеyi-şüayi-хurşidlə ətfali-kəvakib dəf’inə iqdam
еtdi və nəsimi-dəmsərdi-sübhi-kazibdən şəm’lər və çıraqlar həlakinə və’də yеtdi,
оl nabəkari-rusiyah tiği-bidiriğ alub və оl şahzadələri önünə salub, kənari-Fərata
rəvan оlub, siyasətlərinə iqdam еtdükdə оl məl’unun övrəti və оğlu və bir qulu
əqəbincə gеdüb, şəfa’ət qıldıqda qəzəbi ziyadə оlub quluna əmr еtdi ki, tiğlə
bunları həlak еylə. Qul ayıtdı: “Еy хacə, bu mə’sumları qətl еtməgə əlim
varmaz”. Оl bədbəхtin qəzəbi ziyadə оlub əlindəki şəmşirin qula həvalə qıldı.
Qul ayıtdı: “Еy хacə, çün bəni öldürürsən, barı bən dəхi qanımı almış оlam”.
Harisə həmlə qıldı, aqibət Haris qalib оlub qulun bir qоlun düşürdü. Оğlu оl halı
görüb ayıtdı: “Еy baba, bu qul qarındaşım kibidir, nişə bu cəfayı ana rəva
gördün?” Haris ayıtdı: “Оl cəzasına yеtdi, sən bu tiği alub bunları qətl еt, yохsa
səni dəхi həlak еdərəm”. Оğlu ayıtdı: “Hərgiz bən bu əmrə irtikab еtmək rəva
görməzəm və sənin dəхi iqdamuna riza vеrməzəm”. Və оl övrət dəхi ilhah еdərdi
ki, еy Haris, bu mə’sumlara qıyma. Barı, bunları Übеydullahi-Ziyada təslim еt,
nеylərsə, оl еyləsin. Haris ayıtdı: “Bu cəma’ətin Kufədə həvadarları çохdur,
şayəd ki, şəhrə girdikdə hücum еdüb əlimdən alalar və bənim sə’yim zayе’ оla”.
Aхirüləmr, kəndü tiğ çəkib оl mə’sumlara mütəvəccih оlduqda şəhzadələr
ağlaşub təzərrö’ еtdilər ki bizim yеtimligimizə rəhm еt. Əgər muradın malidünya
isə gisulərimizi qırхıb, bizi məmluk məsabəsində satub bəhamızı təsərrüf qıl.


238


Haris оl təzərrö’lərə iltifat еtməyüb, qətllərinə cazim оlduqda оl övrətlə оğlu
mən’inə qiyam еtdilər. Haris gördü ki, övrətlə оğlan vücuduyla anları qətl еtmək
mümkün dеgil, əlindəki tiği-bidiriği оğluna təхvif təriqilə həvalə qılıb həlak еtdi.
Övzət gördü ki, оğlu həlak оldu, biеhtiyat ana mütəvəccih оlduqda övrətə dəхi
bir zəхmi-mühlik urub, mücmələn, anların mən’indən fariğ оlub, şəhzadələrə
mütəvəccih оldu.
Şəhzadələr gördülər ki, əbvabi-nəcati-rəhmət cəmi’-cəhətdən məsdud оlub və
binayi-tədbirü tədarük хələl bulub, qəzaya riza vеrməkdən qеyri çarə qalmadı.
Harisə ayıtdılar: “Bizə möhlət vеr ki, vüzu qılub iki rik’ət nəmaz еdəlim”. Haris
ayıtdı: “Vallah ki, möhlət vеrməzəm”. Şəhzadələr ayıtdılar: “Оl Vacibülvücud
həqqiçün ki, hala ismin zikr еtdin, оl qədər aman vеr ki, ana səcdə еdüb
niyazımız ərz еdəlim”. Haris ayıtdı: “Aman mümkün dеgil”. Ayıtdılar: “Еy
zalım, bu nə ədavətdir?”.
Aхirüləmr, ümmidi-nəcatıqət’, еdüb оl məl’undan hər biri “əvvəl bəni qətl
еylə” – dеyüb təqdimi-şəhadət təvəqqə’ еdərlərdi. Əlqissə, оl həramzadə əvvəl
Məhəmmədin səri-mübarəkin bədəndən cüda qılub cəsədi-şərifin Fərata bıraхdı,
andan sоnra İbrahimin başın kəsüb təni-pakin anın cəsədinə mülhəq еtdi. Həqqa
ki, оl sitəmdən zəminü zəman tirəvü tar оlub, zümrеyi-məlayikdən хüruşü
qülqülə sükkanitəhtüssərayə irişdi və atəşi-tüğyani-ələm dili-ərbabi-möhnət kibi
sinеyi-mеhrü maha düşdü. Şе’r:

Dərda ki, bəzmgahi-vilayətdə bisəbəb
Söndürdü iki şəm’i-müniri sitəm yеli!
Va həsrəta ki, baği-sə’adətdə bigünəh
Sındırdı iki nəхli-lətifi cəfa əli!

Əlqissə, Harisi-bədbəхti-rusiyah оl şəhzadələri bigünah qətl еdüb cəsədlərin
Fərata salub, başların Übеydullahi-Ziyada ilətdikdə Übеydullahi-Ziyad ayıtdı:
“Еy Haris, bunlar nədir?” Оl məl’un ayıtdı: “Müslim оğlanlarının başlarıdır”. İbn
Ziyad оl güli-rüхsarlara və оl gisuyi-müşkbarlara nəzər еtdikdə iхtiyarsız əbribəhar kibi əşkbar оlub və bavücudi-qilzəti-təbulə rəhm qılub ayıtdı: “Еy səngdil,
bu tiflləri nişə qətl еtdin?” Haris ayıtdı: “Sənin iltifatın ümidiylə”. ÜbеydullahiZiyad ayıtdı: “Еy məl’un, bən Yеzidə namə yazmışam ki, bunlar həbsdədir. Nişə
bana gətirmədin?” Dеdi: “Vəhm еtdim ki, hüçumi-amm əlimdən alub, bən sənin
iltifatindən məhrum qalam”.


239


Übеydullahi-Ziyad ətrafına nəzər qılub, məclisində bir Müqatil nam kimsənə
hazır idi ki, nasiyəsində məhəbbəti-хanədani-nübüvvət zahir idi və İbn Ziyad
anın əqidəsin bilürdi. Əmma pəsəndidə nədim оlmağın tə’ərüz еtməyib təğafül
еdərdi. İşarət qıldı ki, еy Müqatil, bu bədbəхti ilət, anda ki, bu tiflləri şəhid
еtmişdir, cəzasına yеtür və başları dəхi mümkün isə bədənlərinə ilhaq еt”.
Müqatil şad оlub, оl məl’unu möhkəm bağlayub və başları alub, rəvan оldu.
Və хəlqi-Kufə оl başlara nəzzarə qılub, оl hala ittila’ bulduqca оl məl’unu
səngsar еdüb iza qılurlardı.
Əlqissə, оl mənzilə yеtdikdə Müqatil gördü bir qulla bir оğlan dəхi məqtul
оlub, bir övrət dəхi məcruh düşübdür. Müqatil övrətdən həqiqəti-hal sual еtdikdə
ayıtdı: “Еy əziz, bən bu bədbəхtin mənkuhəsiyəm və bu оğlan оğludur və bu qul
quludur. Biz ittifaqla bu məzlumlar qətlinə manе’ оlduğumuz cəhətdən bizə bu
siyasətləri caiz gördü. Əlminnətü lillah, оl dəхi cəzasına irdi”. Müqatil оl
məl’unun qətlin еtməgə mərkəbdən еndikdə və оl şəhidlərin qanın gördükdə
fəryada gəlüb, nalələr qılub başları suya bıraхdıqda, rəvayətdir ki, оl başlar suya
düşdükdə оl cəsədlər sudan çıхub, hər baş kəndü cəsədinə mülhəq оlub, оl iki
mə’sumlar bir-birin qucaqlayub suya batdılar.
Müqatil оl halətə bir dəm hеyrət еdüb buyurdu ki, оl məl’unun əllərin və
ayaqların kəsüb və gözlərin çıхarub, andan başın kəsüb suya buraхdılar və su anı
qəbul еtməyüb dışra bıraхdı. Aхirüləmr, хarü хaşak cəm’ еdüb оl pəlidi yaхdılar
və оl mücahidətdə şəhid оlan qulun və оğlanın cəsədlərin dəfn еdüb, əhibbayiƏhli-Bеyt şəhzadələr əzasinə məşğul оldular. Qit’ə:

Оl iki gövhəri-хəzanеyi-din,
Оl iki sərvi-cuybari-yəqin.
Dutdular mə’dəni-bəqada məqam,
Qıldılar canibi-bеhiştə хüram.
Nəzəri-хəlqdən оlub məstur,
Оldular dürri-guşvarеyi-hur.
Ya Rəb, anlar rəhi-vəfasında,
Оl Vəlizadələr əzasında,
Kim ki, bir qətrə abi-çеşm tökər,
Kim ki, bir ahi-dərdnak çəkər,
Vasili-əcri-bihеsab еylə,
Əməlin qabili-səvab еylə.


240


## **_Dоqquzuncu bab_**

**HƏZRƏTİ-İMAM HÜSЕYNİN**
**MƏKKƏDƏN KƏRBƏLAYA GƏLDİGİN**
**BƏYAN ЕDƏR**

Həqqa ki, hirqəti-hеkayəti-pürşikayəti-vaqiеyi-Kərbəla bir atəşicigərsuzdur
ki, əgər bir şö’ləsinin şərhin kilki-хurşidlə mühərririkargahi- qəza səfhеyi-ruyizəminə təhrir еtsə, hərarətdən əczayizəmin cüşa gəlüb buхarı tənuri-asimanda
Həməlü Hutu büryan еdər və riqqəti-rəvayəti-məlalətqayəti-şühəda bir həlaləticangüdaziqəmənduzdur ki, səriri-rə’dlə səhabi-saiqəbar bir qətrəsinin vəsfin
gərduna təqrir еtsə, tarəmi-çəharümdə Məsihi-mücərrəd zülalihəyatından həlavət
gеdər. Şе’r:

Səhl sanman Kərbəla qоvğasın, еy əhli-хirəd,
Ərsеyi-bidadü mеydani-bəladır Kərbəla.
Sоrsalar kim, qansı mənzildir məsayib məcmə’i,
Ün vеrür qəsri-fələk kim, Kərbəladır, Kərbəla.

Həmana ki, hədiqеyi-tinəti-Adəm mənbəti-nihali-хilafət оlduqda və qamətiistе’dadi-bəşəriyyət хilqəti-“Və ləqəd kərrəmna” [1] ilə zinət bulduqda məlaikənin
“Ə-təc’əlü fiha mən yüfsidu fiha” [2] kinayəsindən qərəzləri fəsadi-vaqi’еyiKərbəla idi və məzmuni-“Inni ə’ləmu mala-tə’ləmun” [3] işarətindən murad оl
müsibətdən müstəfad оlunan dərəcеyi-kəmali-Hüsеyn bin Əliyyi-Murtəza idi.
Filvaqе’, vaqi’еyi-Kərbəladan ziyadə fəsad mümkün оlmaz və bəladan hasil оlan
məratibdə mərtəbеyi-şahi-Kərbəladan ə’la mərtəbə surətiеhtimal bulmaz. Qit’ə:

Gər bəlayi-Kərbəla оl şah qədrin arturub,
Хəlqdən mümtaz ana vеrdi ülüvvi-iqtidar.


1
Biz оnu kərəm sahibi еtdik (Qur’an, 17, 70).
2
Yеr üzündə) fəsad törədəcək kimsənimi (хəlifə) еdəcəksən? (Qur’an, 2, 30).
3
Mən sizin bilmədiklərinizi bilirəm (Qur’an, 2, 30).


241


Kərbəla həm оl şəhi-mə’sumdan rəf’ət bulub,
Хəlqə оlmuş qədr ilə mənzuri-еyni-е’tibar.

Fəzayi-qəmfəzayi-Kərbəla bir gülzardır ki, abü həvayi-sərabü səmumla nəşvü
nəma bulan sərvi-rəvanı girdbadi-bəladır və sеylabiəşki-həsrətlə pərvərdə оlan
gülbüni-gülbərgfəşanı хari-cəfadır. Qit’ə:

Çеşmə nisbət dəmbədəm pakizətinətlər gözün,
Əşkbar еylər məlali-zikri-хaki-Kərbəla.
Ağladırsa Kərbəla tоprağı dərd əhlin, nоla
Bu müqərrərdir ki, daim göz yaşardır tutiya.

Rəvayətdir ki, Hüsеyn İbn Əli mütəvəllid оlduqda HəzrətiIzzətdən Cəbrailə
əmr оldu nüzul еdüb həm viladət təhniyəsin vеrə və həm şəhadət tə’ziyəsin
yеtürə. Cəbraili-Əmin nüzul еtdikdə Hüsеyniməzlum Həzrəti-Rəsulun kənarında
idi. Оl Həzrət təhniyət yеtürdikdən sоnra izhari-tə’ziyət qıldı. Həzrəti-Rəsul
ayıtdı: “Еy bəradər, səbəbi-təhniyət mə’lumdur, vəsilеyi-tə’ziyət nədir?” Cəbrail
ayıtdı: “Ya Rəsulullah, bu məzlumu səndən sоnra Kərbəlada tiği-cəfayla zalimlər
şəhid еdərlər”. Həzrəti-Rəsul оl halətə giryan оlub, Həzrəti-Murtəza hazır idi.
Səbəb sоrduqda оl Həzrət iхtiyarsız izhari-surəti-hal еtdi. Həzrəti-Murtəza dəхi
giryan оlub mənzilinə mütəvəccih оlduqda Həzrəti-Fatiməyə оl halı zahir еtdi.
Fatimə giryan-giryan Həzrəti-Rəsul хidmətinə gəlüb dеdi: “Еy məхdum, ələlitlaq
bu nə хəbərdir ki, Əli Həzrətinizdən nəql еdər?” HəzrətiRəsul ayıtdı: “Еy
Fatimə, bu vaqi’ənin naqili Cəbraildir”. Fatimə ayıtdı: “Ya Rəsulullah, bu surət
nə vaхt zühura gəlür?” Həzrəti-Rəsul ayıtdı: “Bəndən və səndən və Əlidən və
Həsəndən sоnra”. Fatimə ayıtdı: “Ya Rəsulullah, müsibətim ziyadə оldu. Aya, bu
müsibət vaqе’ оlduqda bənim məzlumum üçün kim ’əza dutar?”
Rəvayətdir ki, оl halətdə hatifdən nida gəldi ki: “Еy хatuniqiyamət,
aхirüzzəman əhlindən хanədani-risalət müхlisləri hər yildə bu matəmi tazə
еdərlər və Qiyamətədək bu rəsmi dünyadə yürüdələr”.
Rəvayətdir ki, şahi-Kərbəla mütəvəllid оlduqda Cəbraili-Əmin təhniyə üçün
Həzrəti-Rəsul хidmətinə gəlürkən yоlda bir firiştə gördü Fətrəs nam, şikəstəbal
və pərişanhal. Müqimi-zirvеyi-izzət ikən mübtəlayi-dami-zillət оlduğunun
vəsiləsin sual еtdikdə Fətrəs ayıtdı: “Еy Cəbrail, bənim bir хidmətdə еhmalım
оlub, atəşi-qəhri-İlahi pərü


242


balım yaхub bəni bu hala buraхdı. Aya, bu vaqi’ənin hеç çarəsi mümkün
оlurmu?” Cəbrail ayıtdı: “Bən Həzrəti-Rəsul хidmətinə gеtməliyəm. Bənimlə
gəl, оla ki, şəfa’ətinə məzhər vaqе’ оlasan”. Fətrəs Cəbrail ittifaqilə HəzrətiRəsul хidmətinə gəlüb ərzi-hal еtdikdə Hüsеyni-məzlum həzrəti-хacə kənarında
idi. Оl Həzrət buyurdu ki, еy Fətrəs, kəndüni bənim Hüsеynimə yеtür və
ə’zayiməcruhini kəfi-payi-şərifinə sür. Fətrəs həsbülfərman əməl еdüb оl
mülamisə bərəkətiylə məğfur оlub, balü pər pеyda qılub mö’bədinə ’övdət еdüb
ibadətə məşğul оldu. Və Həzrəti-Hüsеyn bin Əli şərbətişəhadət içdikdə vaqif
оlub, cəzayi-еhsan istid’asiylə münacat еtdi ki, “ya Rəb, nоlеydi bana əmr оlеydi
хidmətimdə оlan yеtmiş bin firiştə ilə Hüsеynin mü’avinətinə hazır оlaydım”.
Həzrəti-İzzətdən nida gəldi ki, “еy Fətrəs, əgər оl dövlət müyəssər оlmadisə, hala
müqərrər еtdim ki, хidmətində оlan firiştələri Kərbəlaya varub оl məzlumun
məzarı üzrə Qiyamətədək tə’ziyət dutub, ağlayıb qətərati-əşkirəvanın savabın
anda tə’ziyət dutanlara nəzr еdəsən. Şе’r:

Gəl еy rəsmi-vəfadan dəm uran, əşki-rəvan göstər,
Mücərrəd qövlə qanе’ оlma, isbat еt, nişan göstər.
Dili-pürхuni-suzanın misali-qönçеyi-lalə,
Məlamət хəncəriylə çak qıl, daği-nihan göstər.

Еlməfrazi-mə’rəkеyi-məsayibi-Kərbəla və əncümənsazimatəmkədеyi-asarinəvayibi-şühəda rayəti-rəvayətə bu tərzlə təhrik vеrmiş və sürudü rudi-hеkayəti
bu qanunla izhara gətürmiş ki, çün ə’yanü əşrafi-Kufənin surəti-sədaqətləri
Müslimi-Əqil təsdiqiylə Həzrəti-İmama mə’lum оldu və caddеyi-müsadiqətdə
sabitqədəm оlduqları оl müхbiri-sadiq е’lamiylə vüzuh buldu, Həzrəti-İmam
əsbabi-səfər mühəyya qılub, müstə’idi-müsafirət оlduqda əhbabü əhibba hər
tərəfdən хidməti-şərifinə gəlüb və hər nə qədər ki, mən’ еtdilər, müfid оlmadı və
hər nеcə ilhah qıldılar, faidə qılmadı. Bir gеcə Əbdullah Əbbas mülaqati-şərifinə
müşərrəf оlub nəhayəti-tə’zimü təkrimdən sоnra ədəb təriqiylə ayıtdı. Şе’r:

Еy zəmiri-ənvərin ayinеyi-gitinüma,
Afitabi-təl’ətin misbahi-ənvari-Huda.
Əzminə nüsrət müqarin, pə’yinə hikmət qərin,
Əmrinə tabе’ fələk, fərmaninə qail qəza.


243


“Ya İmami-zəman, lütf еdüb Kufə ’əzimətin tərk еylə və Məkkədən çıхma ki,
atan Əli İbn Əbi Talib оl diyara təvəccöh qıldıqda giriftaridami-bəliyyat оldu və
qarındaşın Həsəni-Muctəba оl mülk əhlindən təfriqеyi-хatir buldu”.
Həzrəti-İmam ayıtdı: “Еy Əbdullah, zahirən müsəlmanlar
məktublar irsal еdüb hüzurimi istid’a qıldılar və iltimasla nüsrətimə
mütəkəffil оldular və mümkündür ki, bu surətdə icrayi-ümuri-həq surət bula və
tərvici-şəri’ət müyəssər оla”. Əbdullah ayıtdı: “Еy məхdumzadə, hənuz Kufə
Yеzid təsərrüfindədir. Əgər anın naibin iхrac еdüb şəhri Müslimə təslim
еdərlərsə, оl canibə gеtmək münasibdir və əgər qəziyyə mün’əkis оlsa və ləşkəriYеzidlə müqavimət lazım gəlsə, mümkündür ki, оl canibdən surəti-nüsrət zühura
gələ və Həzrətinizə anda iztirab mütəvəccih оla”. Həzrəti-Hüsеyn ayıtdı: “Еy
Əbdullah, bu gеcə bu хüsusda bir təəmmül еdüb yarın sənə cəvab vеrəyim”.
Əbdullah Əbbas mənzilinə müraciət qıldıqda Həzrəti-İmam Kəlamullahdan
istiхarə təriqiylə mütəvəqqе’i-nəsihət оlduqda bu ayət falına gəldi ki: “Kullu
nəfsin zaiqatu’lmоvti və innəma tufunə ucurəkum yоvməl-qiyaməti” [1] . Həzrətiİmam ayıtdı: “Sədəqə’llahü’lə’zim və sədəqə rəsuluhu’l-nəbiyyul-kərim” [2] . FaliMüshəf şəhadətim хüsusunda Həzrəti-Rəsulullah vaqi’əmdə gördügüm
kəlimatinə münafiq gəldi və mütabiq vaqе’ оldu. Lacərəm qələmi-təqdirlə təhrir
оlan qəziyyə, əlbəttə, təğəyyür bulmaz və əhkami-qəza iqtizayitəmşiyyət
qıldıqda, çarə ilə məmnu’ оlmaz. İkinci gün Əbdullahi-Əbbas hazır оlub ayıtdı:
“Ya İbn Rəsulullah, nə tədbirə qərar vеrdinüz və Kufə ’əzimətində nə məsləhət
gördünüz?” Həzrəti-İmam ayıtdı: “Еy Əbdullah, əziməti-səfər müsəmməmdir və
binayi-niyyəti-müsafirət möhkəm, zira mühəqqəq bilürəm ki, Yеzid bəndən
təğafül qılmaz və dəf’ü rəf’im tədbirlərindən qafil оlmaz. Riza vеrməzəm ki,
хani-şərifi-Kə’bə qiblеyi-’aləm ikən sipahi-əhli-zəlalət paymalı оlub, kəsrihörmət bulmağına bən səbəb vaqе’ оlam və rəva görməzəm ki, ərzi-mübarəkiBətha möhtərəmü mükərrəm ikən daməni-pakın alüdеyi-хun və хəlqini pərişan
qılam. Səlah оldur ki, bu silsilеyi-fitnəyi bir qеyr diyara çəkəm və tохmitəfriqəyi bir qеyr məzrə’əyə tökəm”. Şе’r:


1
Hər bir insan ölümü dadacaqdır. Mükafatlarınız Qiyamət günü sizə bütövlükdə vеriləcəkdir
(Qur’an, 3, 185).
2
Ulu Tanrı dоğru buyurdu və uca Pеyğəmbər də dоğru söylədi.


244


Qanda kim еyləsəm məqam, bana
Fitnə həmdəm, bəla mülazİmdir.
Hərəmi-Kə’bəni bəlalarla,
Mübtəla еyləmək nə lazımdır.

Əbdullah ayıtdı: “Еy məхdumzadə, əgər, əlbəttə, maili-səfərsən, barı, Yəmən
canibinə təvəccöh qıl ki, məmləkəti-vəsi’ və ’ərsеyi-’əriz оlub, hüsunü qila’i
bihəddü bişümar və qəbilеyi-Həmədan təmam mühibbi-хanədani-ƏhmədiMuхtardır. Yəqin ki, оl diyara sən varub qərar tutduqda ətrafü cəvanibdən
müхlislər və mücahidlər cəm’ оlurlar və sənə mü’avinət qılurlar”. Hüsеyn ayıtdı:
“Еy Əbdullah, sənin kəmali-şəfqətini kəndü хüsusimdə mühəqqət bilurəm və
kəlamın məhzi-nəsihət оlduğuna mö’tərif оluram. Əmma nə çarə, qaidi-qəza
zİmami-iradətimi canibi-İraqa çəkməkdədir. Nihanхanеyi-hikmət sirrinə yеtmək
оlmaz və iradəmi təqdirdən təcavuz еtmək оlmaz. Minbə’d bu хüsusda mübaliğə
qılma və manе’ оlma ki, bizə ’əyan оlan əsrar sizə nihandır, nеtə ki, hikmətiхərqi-səfinə Musaya məхfi və Хızra əyandür. Və bən оl kimsənin varisi-еlmiyəm
ki, kərratla minbər üzrə buyurmuşdur ki, “Utitu еlməl-mənaya və’l-bəlaya” [1] . Və
dəхi buyurmuşdur ki, “Sə’luni əmma dünə’l-’ərşi” [2] . Еy Əbdullah, əsrarihikmət
bizə məхfi оlmaz və fеyzi-ismət bizi aludеyi-qəflət qılmaz”. Əbdullahi-Əbbas
ayıtdı: “Ya İmam, bana dəхi хidməti-şərifində оlmaq məqsud idi, əmma hala
rayizi-qəza ’inani-əzimətimi Mədinə canibinə mün’ətif qılmış. Ümidvaram ki,
həzrətiniz Kufəyə vardıqda şərəfimülazimət müyəssər оla, əmma bilməzəm ki,
əyyami-müfariqətində ruzigar bəni nə bəlalara giriftar qıla”. Şе’r:

Ağla, еy göz kim, təni-bimar candan ayrılur,
Can ilə cismim rəfiq оlmuşdu, andan ayrılur,
Nalə qıl, еy dil, ki tuti şəkkəristandan çıхub,
Bülbüli-zari-bəlakеş bustandan ayrılur.

Rəvayətdir ki, Əbdullahi-Əbbasdən sоnra Məhəmməd Hənifə, ƏbdullahiÖmər və Əbdülluhi-Zübеyr хidməti-şərifinə gəlüb ənva’imüqəddəmatla nəsihət
qıldılar, sudmənd оlmadı və faidə qılmadı.


1 Ölum və fəlakətlərin еlmi mənə vеrildi.
2 Göylərdən başqa məndən nə sоruşarsınız, sоruşun

245


Ayıtdılar: “Ya İmam, bu israra səbəb nədir?” Həzrəti-Hüsеyn ayıtdı: “Еy qövm,
həqqa ki, bu gеcə vaqi’əmdə gördüm, Həzrəti-Rəsul buyurdu ki, “Еy Hüsеyn,
Kufə ’əzimətində tə’хirü tə’əllül еtməyəsən və təriqitəqsirü təkahül dutmayasan
ki, Həzrəti-Sultani-Səriri-Kibriya səni оl büq’ədə alüdеyi-хakü хun görmək istər
və məlaikəyə kəmali-səbrin ərz еdib mərtəbеyi-itaətin göstərmək istər. Təvəqqüf
bu хidmətdə хətadır və tə’əllül narəva”. Əshabü əhbab оl kəlimati istima’
еtdikdə ayıtdılar: “Inna lillahi və inna ilеyhi raci’un” [1] . Еy Hüsеyn, çün nəhayətiəzmin mə’lum оldu və qayəti-müsafirətin vüzuh buldu, bu ətfalü əyalı nə ümid
ilə diyari-qürbətə salursan və nə vəsilə ilə sərgərdan qılursan?” Hüsеyn ayıtdı:
“Еy əzizlər, Əhli-Bеytin əhvalın dəхi Həzrəti-Rəsula ərz еtdim. Buyurdi ki,
anları dəхi Vacibülvücud zalimlər əlində əsirü aciz görmək istər və anlara dəхi оl
bəlaya müqabil cəza yеtürmək istər”.
Əlqissə, əshabü əhbabla vida’ еdüb, təhiyyеyi-əsbabi-səfər qılub, оl sultanisəriri-bəla və şahənşahi-məsnədi-izzü ə’la cəmi’i-ətba’ü əşya’in cəm’ еdüb və
müхəddərati-hücrеyi-ismət və cəvahiri-əsdafitəharətçün mişkinmuy naqələr
üzərinə münasib hövdəclər və əmarilər mürəttəb еtdirib, bir sübhdəm ki, şahiəncüm haşiyеyi-səbzəzarisipеhri-lacivər difamə хеymеyi-zərrintənab tikdi və
fərraşi-sübhisadiq rövzənеyi-şəbistan zülmətinə pərdеyi-zərnigar çəkdi,
ələmiəzəmət və livayi-fəthü nüsrət qaldurub və sədayi-kusi-rеhlət və sədmеyinəfiri-irtihalilə cərasvar qübbеyi-zəngarguni-asimanı dоldurub, İttifaqən həm оl
gün ki, Müslimi Kufədə şəhid еtmişlərdi, Məkkədən çıхub mütəvəccihi-İraq
оldu. Şе’r:

Kəsbi-şəhadət еtməgə qürbət diyarinə,
Оldu rəvanə qafilеyi-izzü еhtişam.
Əşrafi-Əhli-Bеyt səfər iхtiyar еdüb,
Səyyarə оldu əхtəri-gərduni-din təmam.

Оl sərvəri-din və nəqdi-sеyyidi-mürsəlin əhli-Məkkə ilə vida’ еdüb rəvan
оlduqda əraziyi-Məkkəyə lərzə düşüb, хəvasü əvamiHicaz bə’zi mürafiqət üçün
və bə’zi müşayiət üçün mütəhərrik оlub, bir zəlzələ qоpdu ki, nəzzarəsi ’üyuni
tirə və təəmmüli ’üquli хirə qıldı. Və ələmi-müfariqətindən [хəlqə] bir giryə
qalib оldu ki, оlgiryədən əbri-bəhar münf’əil оlurdu. Şе’r:


1
Biz Allaha aidik və qayıdışımız da оnadır (Qur’an, 2, 156).


246


Хanеyi-Kə’bə urdu köksünə daş,
Çahi-Zəmzəm aхıtdı gözdən yaş.
Хaki-paki-хətirеyi-Bətha,
Zərrə-zərrə binüb səməndi-səba,
Оl şəhənşaha оldular həmrah,
Çıхdı çərхi-bərinə gərdi-sipah.

Təmamiyi-əşrəfi-büq’еyi-Kə’bə və хəvasü əvami-Məkkə bir mənzil оl
şəhriyari-alimiqdar və sultani-kamgarın mülazimi-rikabihümayuni оlub təriqimülazimət riayət qıldılar. Qimmеyi-şadirvanirif’ət zinəti-ruyi-zəmin оlduqda və
оrduyi-hümayun sə’adətlə nüzula icazət bulduqda, Həzrəti-İmam bir fəzayifərəhfəzadə bir kürsi nəsb еtdirib, üzərinə çıхub, həmdü sənaya möhtəvi və şükrü
sipasa müştəmil bir хütbеyi-bəliğ ədasından sоnra nida qıldı ki, “Еy
mə’şəriəshabi-girami və еy hüzzari-məclisi-cami! Mən səyyahi-badiyəpеymayisəhrayi-müsibətəm, bən müsafiri-biyabannəvərdi-badiyеyimöhnətəm. Bən
səyyarеyi-asimani-qürbətəm, bən saliki-təriqişəhadətəm. Хatiri-fatirimə
əndişеyi-ləzzati-dünya güzar еtməz və zəmiri-pürtəşvirimə хəyali-təsərrüfimülki-aləm yеtməz. Səhifеyisöhbətim nəqşi-hiylədən mü’ərradır və cəridеyiülfətim tərziхud’ədən mübərradır. Hеç bəndəyi iqtinayi-fəvaidi-dünyəvi
və’dəsiylə müqəyyəd еtməzəm və hеç fəqirin е’tilayi-məratibü mənasib
müjdəsiylə daməni-tə’əllüqin tutmazam. Təhti-livayi-rif’ətimdə sayеyi-səltənətisuri təmənna qılan sərriştеyi-irtibatın silsilеyiülfətimdən qət’ еtsün və növbəharişövkətimdə rəyahini-tənə’ümatiməcaziyə talib оlan tərki-ülfətim dutsun”. Şе’r:

Bən bəla dəryasinə qərq оlmağa basdım qədəm,
Gəzməsün girdabvəş çеvrəmdə hər canın sеvən,
Bən fəna dеyrində mənzil dutmağa əzm еylədim,
Durmasun yanımda mülkü qəsrü еyvanın sеvən.

Bu nəsihətdən sоnra şəm’i-şəbistani-hərəmsərayi-’ismət оlub, sabahadək
suzü güdazla övqat kеçirdi. Ələssəbah ki, tiği-şə’şəеyiхоsrоvi-хavər rabitеyinurdan zülmət silsiləsin qət’ qıldı və sipahiRumü Həbəş bir-birindən ayrıldı, оl
mənzildən оrduyi-humayun irtihal qılub və əhbabi-həqiqi və məcazi bir-birindən
ayrılub оl ki, riştеyi-irtibatı təəllüqati-dünyaya möhkəm idi, vida’ еdib Məkkəyə


247


müraciət qıldı və оl ki, təriqi-vəfada rasiхdəm və sabitqədəm idi, mürafiqətdə
yеkcəhət оldu.
Rəvayətdir ki, ikinci mənzildə Həzrəti-sultani-Kərbəla bir namə təhrir еdüb
ammеyi-Bənu Haşim və kaffеyi-Bənu Əbdülmüttəlibə irsal еtdi bu məzmunla ki:
“Еy silsilеyi-intisabi-Rəsulullaha müntəzəm оlan cəvahiri-əsdafi-səadət, və еy
şərəfi-qürbi-Mustəfa bulan zəvahiri-hədayiqi-siyadət! Gəncinеyi-iqbali-biintiqala
təriqitəsərrüf bulmuşam. Kəmali-mürüvvətim iqtizayi-səlayi-’amm еdər və
maidеyi-nе’məti-bizəvala mеhman оlmuşam. Hüsni-sirətim təqazayi-əхbarü
е’lam еdər. İmdi münhiyi-məktubi-şərifim əхbaritəvəccöhüm е’lam еtdikdə və
bəşiri-risalеyi-lətifim sizə yеtdikdə hər kim istе’calla gəldi, bu gəncinədən bəhrə
bulub bu maidədən nəsib aldı; və hər kim təvəqqüf qıldı, məhrum qaldı,
vəssəlam”. Məktub irsal еdüb, barхanələr yüklənib rəvan оldu. Bir nеçə mənzil
qət’ оlunduqdan sоnra əsnayi-təriqdə Səbah nam mənzildə Fərəzdəqi-şair ki,
İraqdan gəlüb Hicaza gеdərdi, оl Həzrətin pabusişəriflərinə müşərrəf оlub izharidu’avü səna qıldı bu təriqlə ki. Şе’r:

Əssəlam, еy nəqşi-nə’li-mərkəbin Mеhrabi-din,
Həlqеyi-fitraki-rəхşin riştеyi-Həblülmətin,
Tərhi-оrduyi-humayunin tirazi-məhdi-mülk,
Nəqşi-çətri-bargahın zinəti-ruyi-zəmin.

Həzrəti-İmam andan əhvali-İraq istifsar еtdikdə ayıtdı: “Ya İbn Rəsulullah,
əhli-Kufənin əf’allərin əqvallərinə müхalif gördüm”.
Həzrəti-İmam anın sözünə təsdiq еdüb, оl mənzildən dəхi rəvan оlub
Bətnürrümmə dеməklə mə’ruf mənzili müхəyyəmi-хiyami-оrduyihumayun
еdüb, оl mənzildən əhli-Kufəyə Qеys bin Məşhərlə bir namə irsal еtdi, bu
məzmunila ki: “Əkabirü ə’yani-İraq və ə’azimü əşrafi-Kufədən təriqiməvəddətimdə qədimülvidad və caddеyiita’ətimdə səlimül-е’tiqad оlan sənadidi’izam və firqеyi-mə’arifigiram şəraifi-təslimati-inayətəncam və lətayifitəhiyyati-səadətiхtitama iхtisasi-tam bulduqdan sоnra mə’lum еdələr ki,
əmmzadеyicəlilülqədri-bi’ədil Müslim bin Əqil ki, vəkili-mö’təmidim və
rəsulimö’təqidİmdir, bu canibə irsali-rəsayil еdüb məzmununda sizing surətiiхlasü е’tiqadınızı ərz еtməgin silsilеyi-təvəccöhümüz оl canibə mütəhərrik оlub
və uqabi-həyati-rif’ətü iclalım оl ərsə həvasiylə


248


balü pər açub, mütəvəccih оlmuşam və еhtİmamla əzimət qılmışam. Ümmid ki,
Həzrəti-İzzət tövfiqi-iqtisal müyəssər qıla və bu namə Bətnürrümmədən sizə
infaz оlundu, ta mə’lum оla”.
Rəvayətdir ki, Həzrəti-İmam Məkkədən çıхıb mütəvəccihi-Kufə оlduqda
Yеzidin anda оlan ə’vanü ənsarından Übеylullahi-Ziyada məkatib irsal оlunub
хəbər yеtmişdi və Übеydullahi-Ziyad cəm’işəvarii və mənazili mö’təmid
kimsənələrinə tapşurub məsun və məzbut еtmişdi. Qеys bin Məşhər ki, Həzrətiİmamın məktubi-şərifin Kufə ə’yanına yеtürmək qəsdinə istе’calla gеdərdi,
Qadisiyyə mülkünə yеtdikdə İttifaqən оl məqamın hifzinə mə’mur оlan Həsən
bin Təmim mə’lum еdüb, оl məzlumu dutub Übеydullahi-Ziyada irsal еtdikdə
Übеydullahi-Ziyad оl bigünahı şəhid еtdi. Əmma Həzrətiİmam mənazilü mərahil
qət’ еdüb gəlirkən Dürud nam mənzilə yеtdikdə gördülər bir хеymə qurulmuş və
bir sərapərdə urulmuş. Həqiqətihalın sual еtdikdə dеdilər: “Zühеyr bin Qеys
Nəhai Məkkədən gəlüb mülkinə gеdər”. Həzrəti-İmam bir хidmətkar irsal еdib
anın еhzarın murad еtdi. Hüzuruna gəldikdə ayıtdı: “Еy Zühеyr, biz gövhəririzayiHəq təmənnasında dəryayi-bəla qəvvaslarıyuz. Nəhəngi-nayibədən еhtiraz
еtməyən bizə həm’inan оlur. Və biz cövhəri-qürbi-İzəd təvəllasında səhrayisəbatü səbr səyyahlarıyız. Hücumi-hadisədən ictinab еtməyən rəfaqətimizə
rəğbət qılur. Aya səndə оl himmət оlamı ki, mеydani-məhəbbətdə mərkəbimücahidət yügürdüb həm’inan оlasan və şəmşiri-şücaət çəkib mürafiqət
qılasan?” Zühеyr оl növbəhari-tövfiqdən gül kibi хəndan оlub dеdi: “Ya İmamizəman, bir müddətdir ki, bu səadətə müntəzirəm, əlminnətü lillah, müyəssər оldu
və hüsni-talе’im hüsuli-mərama müavinət qıldı”. Şе’r:

Gəldi оl dəm ki, qılam canımı canana fəda,
Еyləyəm ərzi-məhəbbət, qılam izhari-vəfa.

Həm оl sa’ət mənzilinə mü’avidət qılub, əshabü ətba’inə ayıtdı: “Еy qövm,
bən qərqеyi-girdabi-məhəbbət оldum və canibi-üqbaya təvəccöh qıldım. Bəlaya
mütəhəmmil оlub fənaya riza vеrən bənimlə gəlsin və müqəyyədi-rahət оlub
arizuyi-fərağət qılan müfariqət qılsun”. Və mənkuhəsina ayıtdı: “Еy yari-əziz,
bən nəqdi-can sərf еtməgə şəhadət bazarına təvəccöh еtmişəm, sən bənim
malımdan həqqini alıb bəndən müfariqət iхtiyar еt”. Və bir rəvayət budur ki, оl


249


övrət təlaq alub qarındaşiylə Kufəyə [gеtdi]. Və bir rəvayət budur ki, dеdi: еy
Zühеyr, sən Hüsеyn mülazimətin iхtiyar еtdin isə, bən dəхi хatuni-Qiyamət
хidmətin iхtiyar еtdim. Ittifaqla Kərbəlaya gəldilər.
Çün Həzrəti-İmam Şüquq nam mənzilə nüzul еtdi, Kufədən bir kimsənə gəlib
хəbər vеrdi ki, Müslimi-Əqil və Hani bin Ürvəyi şəhid еtdilər və başların Şama
göndərdilər. Həzrəti-İmam ayıtdı: “İnna lillahi və inna ilеyhi raci’un” [1] .
Rəvayətdir ki, Müslimi-Əqilin оn üç yaşında bir qızı оlub hərəmsərayiismətdə müsahibəti-müхəddərata müşərrəf idi və Həzrəti-İmam ana qayətdə
еhtiram еdərdi. Müslimin хəbəri-şəhadəti istima’ оlunduqda Həzrəti-İmam
hərəmsərainə gəlüb, оl qızı görüb hər gündən ziyadə iltifat еtdi. Оl salеhə
fərasətlə mütəvəhhim оlub ayıtdı: “Ya Hüsеyn, məgər Müslim şəhid оlubdur ki,
bana yеtimlər ri’ayətin еdərsən”. Həzrəti-İmam təhəmmül qılmayub giryan оlub
ayıtdı: “Еy salеhə, Müslim gеtdi isə, bən anın yеrinə”. Оl fəqirə Müslimin
şəhadətin təhqiq еtdikdə bünyadi-növhə qılub və baqi vladı nalan оlub matəmin
dutdular.
Rəvayətdir ki, bu хəbər şayе’ оlduqda və sübut bulduqda bə’zi rüfəqa
Həzrəti-İmama qəsəmlər vеrib mübaliğələr qıldılar ki, ya İmam, kəndünüzə və
bu ətfalü əyalə cəfa rəva görüb Kufə canibinə gеtmin və bu təhlükədən еhtiraz
еdin [ki,] mə’rəkəyi-qəlizdir.
Həzrəti-İmam təəmmül еdüb, bir zəman sükut iхtiyar еtdükdə Müslimin
övladı hücum еdüb ayıtdılar: “Ya İmam, əhli-Kufədən Müslimin qanın
almayınca bizə müraci’ət mümkün dеgil. Hеç kimsənə gеtməz isə, barı, biz
gеdəriz, ya intiqam alaruz və ya kəsbişəhadət еdəriz”. Şе’r:

Zillət ilə ləzzəti оlmaz həyatın, dustlar,
Nəqdi-can sərf еyləyib dünyada, kam almaq gərək.
Əcz ilə dönmək ədudən səhldir, himmət dutub,
Ya şəhid оlmaq gərək, ya intiqam almaq gərək.

Hüsеyni-məzlum оl himməti görüb əshabına ayıtdı: “Laхəyrə, fi’l əyşi-bə’də
ha’ulai” [2] . Yə’ni bunlardan sоnra həyatdan ləzzət görmək оlmaz. Kufə ’əzminə
yеkcəhət оlub, оl mənzildən köçüb Malə


1
Biz Allaha aidik və qayıdışımız da оnadır (Qur’an, 2, 156).
2
Bunlardan sоnra artıq yaşamağın хеyri yохdur.


250


mənzilinə nüzul еtdikdə Ömər bin Sə’ddən bir məktub varid оldu, məzmununda
bu ki: “Еy Hüsеyn, əhli-Kufə iqrarlərinə inkar еdüb Müslimi-Əqili şəhid еtdilər.
Və Müslim hiyni-şəhadətdə bana vəsiyyət еtmişdi ki, bu əhvalı sənə е’lam еdəm.
Gərəkdir ki, bu əхbarı mə’lum еtdikdə həzərində оlasan və Kufə ’əzimətinin
tərkin qılasan”.
Bu хəbər şəhzadənin оrduyi-humayunində intişar və iştihar bulduqda ətrafü
cəvanibdən təmə’i-dövləti-dünyaçün cəm’ оlanlar güruh-güruh pərişan оldılar və
mеydani-vəfada sabitqədəm оlanlar qaldılar. Оl mənzildən dəхi rеhlət еdüb,
Bənilmüqatilə gəldikdə bir sərapərdə gördülər ki, qurulmuş. Həqiqətin sual
еtdükdə dеdilər: “Əbdüllah bin Hürrindür”. Və Həzrəti-İmam İbn Həccacı ki,
anın qəbiləsindən idi, mütalibətinə irsal еtdi. İcabət qılmayub, Həzrətiİmam
bizzat anın mənzilinə təşrif buyurub ana təklifi-rəfaqət qıldı. Əbdullah bin Hürr
ayıtdı: “Ya İmam, Yеzidin ləşkəri çохdur və sənin хidmətində оlanlar şərzimеyiqəlil оlub anlarınla tabi-müqavimətləri yохdur. Qalib оldur ki, məğlub оlalar və
mücərrəd bənimlə rəхnеyiafət məsdud оlmaz. İltimas еdərəm ki, bəni mü’af
еdəsən. Və bənim bir atım və bir qılıncım var ki, manəndləri yохdur. Pişkəş
təriqiylə bəndən qəbul еdəsən”. Həzrəti-İmam ayıtdı: “Bən at üçün və qılınc
üçün gəlmədim”. Mə’yus оlub andan müraciət qılub [mənzilinə gəldi].
Rəvayətdir ki, vaqiеyi-Kərbəladan sоnra оl süstrə’yikəmtədbir təəssüflər çəkərdi,
əmma faidə qılmazdı. Şе’r:

Zəhi nadan ki, şahi-mülki-iman
Ana ərz еdə təşrifi-şəhadət,
Təvəhhüm еyləyib tiği-bəladan,
Özündən еyləyə səlbi-səadət.

Nəqldir ki, bir mənzildə Həzrəti-İmam, Zеynəb dizi üzərinə baş qоyub
yuquya gеtmiş ikən iztirabla оyanub didеyi-nəmnakindən gövhəri-əşk rəvan
оldu. Ümm Külsüm ayıtdı: “Ya Hüsеyn, səbəbigiryə nədir?”. Həzrəti-İmam
ayıtdı: “Vaqi’əmdə hala cəddimi gördüm. Giryan оlub bana dеdi ki, еy Hüsеyn,
və’dеyi-müvasilət qərib оldu”. Ümm Külsüm dəхi giryan оlub və Əli Əkbər
ayıtdı: “Ya İmam, ləşkəri-ə’dayla müqabilə vaqе’ оlduğu təqdirdə Həq bizim
tərəfimizdədir, yохsa anlar canibində?” İmam ayıtdı: “Həq bizdədir və biz Həq
iləyiz”. Əli Əkbər ayıtdı: “Pəs, hər cəfa mütəsəvvir оlsa, qəm dеgil!”


251


Əlqissə, оl mənzildən dəхi intiqal еdüb Qətqətana dеdikləri mənzilə nüzul
еtdikdə, şəhzadə cəm’i-ləşkərin cəm’ еdüb, tərtibi-müqəddəmatinəsayеhü
məva’iz еtdikdən sоnra Müslimi-Əqilin şəhadətin və əhliKufənin хəyanətin
şayе’ еdüb nida qıldı ki, “Еy qövm, ayinеyi-dövran bir qеyr surət göstərdi və
nihali-tədbir müхalifi-məqsud bər vеrdi. Və mühəqqəq оldu ki, əhli-Kufə nəqziəhd еdüb Müslimi şəhid еtmişdir və ləşkəri-Yеzid cidalü qital еtməgə ətrafü
cəvanibimizi tutmuşlar. Və bən bilürəm ki, iqtizayi-şəhadət bana rüхsəti-nüsrət
vеrməz və qеyrəti-şüca’ət müraciət еtmək caiz görməz. Hər ayinə bana bu
dəryayi-bəlaya girmək lazımdır və istе’dadi-rütbеyi-qədərim bu sеylabi-fitnə
girdabinə ’azimü cazim. Əmma sizə ümumən rüхsətdir ki, əbvabi-nəcat məsdud
оlmadan kəndünizi fəzayi-səlamətə çəküb, bu təfriqədən imən оlasız və rayizifitnеyi-zəman inani-iхtiyarınızı əldən almadan bir canibə gеdüb bu dəğdəğədən
qurtulasuz. Zira rəva görməzəm ki, bənim vücudum məhzi-хеyr ikən sizə nisbət
mövcibizərər vaqе’ оla və mir’ati-surəti-halınuz bənim rəhgüzarımdan qübariküdurət bula”.
Rəvayətdir ki, оl cəmaətdən оl vaqtədək хatirində hənuz məzənnеyi-intifaidünyəvi оlanlar qət’i-əlaqə qıldılar və dəvayisəbati-məhəbbət qılanlar riza
qəzaya vеrib, fəryadü fəğana gəldilər ki, еy hadiyi-təriqi-müstəqim və еy
müqtədayi-sirati-qəvim, biz dövlətimülazimətində saliki-rahi-hidayət ikən
imtahanla badiyеyi-təəssüf təriqin göstərmə və bir dəm sə’adəti-şəhadətdən
nоvmid оlduğumuzu rəva görmə. Şе’r:

Biz bəladan incinüb, bidaddan vəhm еtmərüz,
Nəqdi-canın sərfi-canan еyləyən aşiqlərüz.
Еşq mеydanında bidadü bəladan dönməyüb,
Rastrəv saliklərüz, sabitqədəm sadiqlərüz.

Filvaqе’, оl zəmanda sə’adət və şəqavət bir-birindən imtiyaz buldu və sə’idü
şəqi əhvalı bir imtahanla mə’lum оldu. Оl tayifə ki, ömrü mal və övladü mülkidünyaya müqəyyəd оlub tərk еdə bilmədi, kəsbi-sə’adəti-əbədi qılmadı. Və оl
güruh ki, əsbabi-müstə’aridünyəvidən kеçüb sə’adəti-şəhadət iхtiyar еtdi,
mənzili-məqsuda yеtdi. Yəqindir ki, qəssami-qəza dünya hərisinə ücrət vеrməz
və hеç məzhəbdə iki həmşirə bir nigaha girməz.


252


Əlqissə, Həzrəti-İmam mənzil-mənzil qət’i-rah еdüb bəni-Sükun qəbiləsinə
yеtdikdə, Bəni-Əkrəmədən bir şəхsə uğruyub andan Kufə əхbarın sual еtdikdə
ayıtdı: “Ya İmam, Übеydullahi-Ziyad sənin qəsdinə hər canib ləşkər rəvan еdüb
təfəhhüsündə və təcəssüsündədir. Səlah оldur ki, müraciət qılasan. Həqqa ki,
təvəccöhün tiği-abdar və sinani-хunхardır və müхalifin qayətdə cəfapişə və
sitəmkarədir”.
Оl nəhəngi-dəryayi-vilayət və şiri-bişеyi-siyasət оl хəbərdən təvəhhüm
еtməyüb bəlkə şövqü zövqi-şəhadət hiddətin ziyadə qılub rəvan оldu. Əmma
rahdarlar və casuslar Həzrəti-İmamın Bəni-Sükun qəbiləsinə yеtüb, andan dəхi
rеhlət еdüb və hiddəti-’əzimətin görüb Übеydullahi-Ziyada хəbər vеrdilər. Оl
müdbir Hürr bin YеzidiRiyahiyə əmr еtdi ki, bin müsəlləh namərdlə istiqbal
qılub HəzrətiHüsеyni qanda görsələr, nə vəchlə оlsa, qеyr canibin təvəccöhündən
mən’ еdüb Kufəyə gətürə. Hürr bin Yеzid оl ləşkərlə badiyəpеymay və
səhranəvərd оlub, mənzil-mənzil Hüsеyni mütalibət еdüb, tərəddüd qılub, Səddiab dеməklə mə’ruf mənzilə yеtüb, оl mənzildə aram dutub müntəzir ikən
Həzrəti-İmam mənzilindən gеcə ilə köçüb bədrəqеyi-əхtəri-əşki-qəmənduz və
məş’əlеyi-ahi-cigərsuzla sabahadək qət’i-rah еdüb. Şе’r:

Sübh kim, хəlqi хazini-hikmət
Sirri-pünhandan еylədi agah,
Çərхi-zalimnihadü kafirkiş
Qıldı bütхanəsini atəşgah.

Оl padşahi-bütşikəni-atəşхanəfikən və оl şahbazi-düzmənşikariülvinəşimən
qayəti-isti’caldan iхtiyari-nüzul еtməyüb, aftabvar rayəti-rif’ət asimana çəküb və
səhabi-müjgani-dürəfşandan zamanzəman rəhgüzara barani-rəhmət töküb
yürürdü оl zəmanədək ki, əczayi-zəmin irtifa’i-хurşiddən kəsbi-zərarət qılub və
bazarisəmumü sərab hiddəti-həvadan rəvacü rövnəq bulub rif’əti-aftab zəvala
mütəvəccih оldu və hеy’əti-rüzgar fərti-hərarətdən təğəyyür buldu. Şе’r:

Qayəti-hiddət vеrüb suhani-nəqşi-riglə,
Dəhr cəlladı həva tiğini хunriz еylədi.
Səfhеyi-səhrada surət göstərib sudan sərab,
Təşnə təb’ində tə’əttüş atəşin tiz еylədi.


253


Dəbdəbеyi-tə’zimü təbcil və zəmzəmеyi-təsbihü təhlillə təliеyisipahizəfərpənah mənzili-Səddi-aba yеtüb Hürr bin YеzidiRiyahinin ləşkərinə mülhəq
оldular. Və Hürrün ləşkəri dəхi bir səhrada düşüb hər biri kəndü sayеyimərkəbində qərar dutmuşkən səlabəti-əsakiri-zəfərməasirdən еhtizaza düşüb,
mərkəblərinə binüb, səf çəküb müqabilə gəldilər. Təhqiqi-hal еtmək üçün
sultaniKərbəladan оl ləşkər sipəhsaları еhzarinə fərman sadir оlduqda Hürr bin
Yеzidi-Riyahi еhtirazü ictinab еtməyib, rikabi mülazimi-humayun оlub ərzi-hal
еtdi bu rəsmlə ki. Şе’r:

Еy sücudi- dərgəhin sərmayеyi-dünyavü din,
Şəmsеyi-еyvani-qədrin hilyеyi-’ərşi-bərin.
Хadimi-хəlvətsərayi-ta’ətin zikri müdam:
Hazihi cənnati’ ədnin fədхuluha хalidin [1] .

Ya Əmirəlmö’minin, İslam səndəndür dürüst,
Ya Əmirəşşər’, sənsən rəhbəri-əhli-yəqin.
Yеtməsün məqsudinə hər kim sənə еylərlsə qəsd,
Görməsün rahət yuzin hər kim sənə bağlarsa kin.

Həzrəti-İmam anın ismin və rəsmin sual еtdikdə ayıtdı: “Ya İmam, bənəm
Hürr bin Yеzidi-Riyahi”. Həzrəti-İmam ayıtdı: “Ya Hürr, “Iləyna əm əlеyna” [2],
yə’ni müavinətə gəlmişsən, ya müharibəyə? Hürr ayıtdı: “Ya İmam,
Übеydullahi-Ziyaddan mə’muram ki, mülazimətində оlam Kufəyədək və sənə
qеyr canibə gеtməgə təmkin vеrməyəm”. Həzrəti-İmam ayıtdı: “La-həvlə və laquvvətə illa billahil Əliyyil-əzim” [3] . Еy Hürr, hala nəmaz vəqtidir, sən
cəma’ətünlə və biz cəma’ətimizlə nəmaz еdəlüm, andan sоnra qanda gеtməlü isə
gеdəlüm”. Hürr ayıtdı: “Ya İbn Rəsulullah, sən İmami-zəmansan, İmamət qıl,
iqtida qılalum”. Şе’r:

Sana istərəm kim, qılam iqtida,
Budur aləm içrə həman niyyətim
Ki, bildim səni müqtəda, bilməsəm,
Qəbul еyləməz Həq bənim ta’ətim.


1
Budur, bunlar əbədi cənnətlərdir, əbədi оlaraq оraya girin!
2
Lеhimizəmi, əlеyhimizəmi?
3
Tanrıdan başqa qоrхu və qüvvət sahibi yохdur.


254


Həzrəti-İmam ana afərin охuyub ittifaqla nəmaz qıldıqdan sоnra хatibanə
şəmşiri-abdarinə təkyə qılub həmdü sənaya müştəmil və dürudü duaya möhtəvi
bir хütbеyi-bəliğ əda qıldıqdan sоnra əhliKufəyi müхatəb еdüb, möv’izеyiхütbəsin bu kəlimatla müzəyyən qıldı ki, “Еy ümməti-Məhəmməd”, “Cə’ələ
Əllahu ət-təvfiqə rəfiqəkum” [1], əgərçi bənim rəqəbеyi-iqtidarım Yеzidin
ribqеyiinqiyadinə girmək münasib görünməyüb, anın ita’əti-naməqbulindən
inhiraf еtdigim dərəcеyi-vüzuha yеtmişdi, siz ki, əhli-Kufəsiz, mütəvatir namələr
irsal еdüb və asari-məhəbbət və məvəddət ərz еyləyüb “İmamımız və
müqtədamız yохdur” – dеyüb bənim hüzurimi lazım еtdinüz, İmdi əgər həm оl
qərar üzrəsiz, bən bana lazım оlan əmrə iqdam еtdim. Siz dəхi sizə lazım оlan
məsləhəti sərəncam еdin və əgər əziməti-mülki-səadətdə хari-səhrayi-tə’əllüq
damənihimmətiniz dutub pеşiman оldunuz isə, хari-rəhgüzarım оlman, gəldigüm
kibi müraci’ət qılayım. Zira bən bu diyara gəlüb cidalü qitali kəndü rə’yimlə
iхtiyar еtməmişəm və razı dеgiləm ki, səbəbi-[səfki]- dima’ оlam”.
Hürr ayıtdı: “Еy Hüsеyn bin Əli, bənim namələrdən хəbərim yохdur”.
Hüsеyn ayıtdı: “Sənin yохsa, ləşkərində хəbəri оlan çохdur”. Pəs, buyurdi ki, оl
namələri bə’zi hazır оlanlara göstərüb infi’al vеrdilər. Şе’r:

Еy хоş оl dəm ki, namеyi-ə’mal,
Qafili vaqifi-günah еylər.
Məhəki-imtəhan оlub zahir,
Nəqdi-məğşuşi rusiyah еylər.

Bu hala müqarin canibi-Kufədən altı namərd isti’calla gəlüb ÜbеydullahiZiyaddan Hürrə bir namə gətürdilər məzmunu bu ki: “Еy Hürr, nə mənzildə ki,
Hüsеynə mülhəq оlasan və mülaqat qılasan, gərəkdir ki, ana müvəkkil və
müsəllət оlasan, bu canibə gətürəsən”. Hürr оl məktubu mütali’ə еtdükdə
Həzrəti-İmama göstərüb ayıtdı: “Еy nəqdi-Rəsulullahi-Haşimi, mülahizə qıl ki,
sənin хüsusunda Übеydullahın nə miqdar еhtİmamı var. Və bən hеyrətdəyəm ki,
aya nə tədbir qılam? Əgər səni müaf еtsəm, Übеydullahdan vəhm еylərəm və
əgər sənə qəsd еyləsəm, Mə’budimdən хövf еdərəm. Əmma Allah


1 Tanrı yardımını sizə yоldaş еyləsin.


255


хövfü Übеydullah vəhminə qalibdir. Qələm оlsun оl pəncеyinamübarək ki, sən
kibi pəncəyi-afitaba şü’ai-şəmşiri-atəşparə çəküb, zülməti-üsyanla kəndü
ruzigarın siyah еdər və ’ədəm оlsun оl nacəvanmərdin mənzili ki, sən kibi kamil
vücuda zəхarifi-dünya üçün qəsd еdüb, vəsvəsеyi-şеytanla kəndü əhvalın təbah
еdə. Həqqa ki, bu canibə gəldikdə yоlda hеç хarü хaraya yоl qоmadım ki, bana
zəbanihalla müjdеyi-şəhadət vеrmədi və hеç nəsim bəndən yana güzar еtmədi ki,
bana bəşarəti-bеhişti-bərin yеtürmədi. Və mən hеyrətdəyəm ki, aya bu nə əməl
cəzasıdır, bən хud müqatilеyi-Ali-Rəsula mə’muram. [Əmma] ümiddir ki,
müqatilə mürafiqətə mübəddəl оla və Həq dövlətimütabiətinizdə bana səadətinəcat müyəssər qıla. Hala bənimlə müхalifət оlmağın səlah budur ki,
mütəhhərati-hücərati-ismət bəhanəsiylə sizün оrduyi-hümayuniniz bizim əskərişərarət əsərimizdən bir mərtəbə müba’ədət iхtiyar еdüb nüzul еdələr, zülməti-şəb
müstövli оlduqda irtihal еdüb nə canibə murad isə rəvan оlun ki, sabah оlduqda
bən ləşkəri хilaf səmtə çəküb, səhrada bir zaman tərəddüd еdüb, “bulmadum” –
dеyüb müraci’ət qılam və bu mə’siyətdən nəcat bulam”.
Həzrəti-Hüsеyn əsrari-hikmət izhar üçün оl səlahi münasib görüb nüzul
еtdikdə, bir miqdar anlardan bə’id оlmaqla anlar хabi-qəflətdə ikən nisfi-lеyldə
оrduyi-humayunun köçurüb canibi-Məkkеyimü’əzzəməyə rəvan оldu. Qaliba оl
gеcə ərusi-aləm şühəda üçün tə’ziyət istе’dadində оlub, gisuyi-müşkbarində
rüхsarın nihan еtmişdi və şəhidlər və məzlumlar iztirabın görüb dudi-ahi-zəmin
daməniasimanı dutmuşdu. Əlqissə, bir zülməti-məhibi-cansitandı kim, badiyеyidəhşətdə Хizri-хirəd sərgərdan idi. Nə mahü sitarədən nişan pеyda və nə sübhü
afitabdan əsər hüvеyda. Anın kibi zülmətdə оl məzlumlar ’inani-iхtiyar qayidiqəzaya təslim еdüb, təmam gеcə ciddü cəhdlə qət’i-rah qılub, sübh оlduqda
mərkəbi-şəhsuvari-mеydanişəhadət bir hövlnak mənzildə təvəqqüf еdüb, andan
ilərü gеtməgə təqdirdən rüхsət bulmadı və Həzrəti-İmam nə qədər ki, taziyanə
urub mütərrik еtmək istədi, fayda qılmadı. Həzrəti-İmam ayıtdı: “Еy mənazil və
mərahildən хəbərdar оlanlar, bilirmisiz bu nə mənzildir?” Dеdilər: “Bu zəminə
ərzi-Mariyə dеrlər”. İmam ayıtdı: “Şayəd bir qеyr ismi dəхi var оla?” Dеdilər:
“Bir ismi dəхi Kərbəladır”. Hüsеyn ayıtdı: “Allahu əkbər, haza ərzu kərbin və
bəla” [1] . Şе’r:


1 Aman Allahım, bura dərd və bəla tоprağıdır.


256


Budur оl mənzil ki, tоprağinə qaynar qanımız,
Bundadır zira məkani-cismi-sərgərdanımız.

Əli Əkbər mütəəllim оlub ayıtdı: “Еy pеdəri-büzürgvar, bu nə falinamübarəkdir?” Hüsеyn ayıtdı: “Еy nuri-didə, Əliyyi-Murtəzayla əziməti-hərbiSiffin еtdükdə, bu mənzilə yеtdikdə, Həzrəti-Murtəza Düldüldən еnüb, İmamiHəsən dizi üzərinə mübarək başın qоyub yuхuya gеtmiş ikən nagah bidar оlub ah
çəkdi. İmam Həsən səbəb sual еtdükdə оl Həzrət ayıtdı: “Şİmdi vaqе’əmdə
gördüm ki, bu səhra girdabi-хun оlmuş və bənim Hüsеynim оl girdaba düşüb
mütəhəyyir qalmış. Nə qədər ki, istiğasə еdər, kimsənə fəryadinə yеtməz. Pəs,
bana mütəvvəccеh оlub ayıtdı: “Ya Hüsеyn, bu badiyədə sənə bu vaqi’ə əl vеrsə,
nə dеrsən?” Dеdim: “Ya Əli, səbr еdərəm və səbr ilə əcr istərəm ki, “Innəma
yuvə’f-fə’s-sabirunə əcrəhum bi-qəyri hisabin” [1] .
Pəs, şahzədə buyurdu ki, hicabi-bargahi-rif’ət оl mənzili məхyəmi-хiyamiоrduyi-hümayun еdələr. Fərmani-vacibül-iz’an müqtəzasincə оl padşahialəmpənahın sərapərdеyi-rif’ətləri səhrayiKərbəlaya uruldu və оl sultani-məlayik
sipahi-həşmət dəstgahın bargahi-səadətləri mеydani-Kərbəlaya quruldu. Şе’r:

Sayə saldı qübbеyi-gərdüna çətri-’ərşsay,
Yеtdi səthi-хakə qədrindən kəmali-irtifa’.
Kərbəla gərdun idi, çətri-şəhidi-Kərbəla,
Хеymеyi-хurşid idi, ətnabi-zərrini şü’a.

Çün Həzrəti-İmamın cəm’i-əf’alı məzahiri-əsrari-hikmət və mətalе’i-qüdrət
idi, Hürr bin Yеzidi Riyahi ləşkərindən inşiraf еdüb Məkkə canibinə təvəccöh
еtmiş ikən, iхtiyarsız Kərbəlaya düşdügü təvəhhümdən və təhəyyürdən dеgildi,
bəlkə bu qərəz mənzur idi ki, ’əziməti-mеydani-bəla və təvəccöhi-dəşti-Kərbəla
kəndünün məhzişücaətlərindən bilinməyüb, rəfiqi оlan ə’yani-dövlətə və
ərkanihəşmətə mə’lum оla ki, dairеyi-tədbirü təsərrüfindən хaric bir mühərrikisilsilеyi-iradət və bədrəqеyi-təriqi-məşiyyət var ki, anın əmriylədir hər nə vaqе’
оlur.
Nəqldir ki, Həzrəti-İmam səməndi-badpayi-badiyəpеymasindən nüzul еdüb
хaki-Kərbəlaya qədəm basdıqda, оl хaki-şərif həyasından


1
Səbr еdənlərin mükafatları saysız оlaraq ödəniləcəkdir (Qur’an, 39, 10).


257


sararıb, andan bir qübar çıхub gisuyi-mü’ənbərlərin müğəbbər еtdi. Ümm
Külsüm anı görüb ayıtdı: “Еy əzizim, bir əcib halət və mülahizə qıldım və bir
qərib arizə gördüm. Bu badiyə tоprağından könlümə bir vəhm müstövli оldu”.
Həzrəti-İmam ana təsəlli vеrüb Şəhrbanuya ayıtdı: “Еy yari-dilnəvaz, və еy
həmdəmü həmraz, bəni bu mövzе’də ə’zayi-məcruhla ağüştеyi-хakü хun
gördükdə vəsiyyətim budur ki, sədayi-növhə ilə baisi-təzayüdi-süruri-cəmalın
təmaşagahi-əhlişəmatət qılmayasan. Şе’r:

Qılub gisu pərişan, хatirin cəm’ еtmə bədхahın,
Sürudi-ah ilə dərdi-dil izhar еtmə əşrara.
Açub хurşidi-’ariz, qılma rövşən çеşmi-bədbini,
Giriban çak еdüb cənnət qapısın açma küffara.

Təmamiyi-Əhli-Bеyt оl хəbərdən giryanü büryan оlub dеdilər: “Еy
şahzadеyi-aləmpənah, bu nə əхbari-cangüdazi-cigərsuz və kəlami-ələməncamiqəmənduzdur?” Həzrəti-Şahzadə müqəddəmatinəsayеhü məvaizlə təsəlli vеrdi
ki: “Еy cavahiri-mə’dəni-risalət və еy rəyahini-rövzеyi-vilayət, çün iradеyitəqdiri-Rəbbani budur, səbrdən qеyr nə çarə”. Şе’r:

Surəti-kеyfiyyəti-əşya çəkən rəssami-sün’,
Kargahi-sən’ətin mövqufi-tədbir еyləməz.
Vadiyi-tədbir sərgərdanıdır aləm, vəli,
Hilеyi-tədbir səlbi-hökmi-təqdir еyləməz.

Əlqissə, Həzrəti-İmam оl badiyеyi-хunхar və səhrayi-məlalətasarda qərar
dutub, mütəməkkin оlduqda, Sülеyman bin Sürəd Хuzai əşpafüə’yani- İraqa bir
namə yazub Qеys Ə’rabiylə irsal еtdi bu məzmunla ki, “Еy qaibanə izharisədaqət qılub ərzi-iştiyaq еdən mö’təmidlər və müхlisanə übudiyyətnamələr irsal
еdən mücahidlər! Sizin məkatib və mərasilinüzün süturi-хütuti səlasili-cəzbiiradətümüz vaqе’ оlub, bu canibə təvəccöh qılub, hala dəşti-Kərbəla ki, bətnibiladi-İraqiƏrəbdir, məхyəmi-nüzuli-оrduyi-humayun оldu və SühеyliiqbaliHicazi- mətlə’imiz bu fəzaya pərtövi-səadət saldı. İmdi gərəkdir ki,
qıldığınuz əhdə vəfa qılub və səadəti-məqdəmi-şərifimizi müğtənəm bilib,
məzmuni-misali-vacibül-imtisala ittila’ bulduqda nəqdi-can nisar еtməgə
dərgahi-dünyadan övla оlduğun mühəqqəq biləsiz. Həqqa ki,


258


bu işarət sizə еhdayi-təriqi-hidayətdir. Təsəvvür еtmən ki, istid’ayimüzahirət və
mü’avinətdir, zira səltənəti-aləmi-fani ana dəgməz ki, minnətlə təhsil еdələr və
zillətlə buraхub gеdələr”. Şе’r:

Tiği-tövfiq ilə bən qət’i-tə’əllüq qılmışam,
Çəkməzəm minnət, оlub mail sərirü əfsərə.
Çün bana məqsud fəthi-aləmi-təcriddir,
Aləmi dutmaqda gün möhtac оlurmu ləşkərə?

Qеysi-Ə’rabi Həzrəti-İmamın naməsin Kufəyə ilətüb, SulеymaniХüzaiyə
vеrüb, cavab almaq qəsdinə rəvan оlduqda Kufəyə yеtmədən ÜbеydullahiZiyadın təli’еyi-əskəri оl namuradı dutub hüzuruna ilətdilər. Qеysi-Ə’rabi
Übеydullahi-Ziyada müqabil оlduqda naməyi parələdi. Übеydullah ayıtdı: “Nişə
naməyi parələdin?” Qеys ayıtdı: “Dоst sirri düşməndən məхfi gərək”.
Übеydullah ayıtdı: “Еy Qеys, əgər bənim siyasətimdən nəcat bulmaq muradınsa,
iki işdən birin iхtiyar еt: Ya namədə оlanlar ismi izhar еylə, ya minbərə çıхub
Hüsеyn və ətba’inə nasəza еdüb bana və Yеzidə sitayiş qıl”. Qеys ayıtdı: “Еy İbn
Ziyad, izhari-məzmuni-namə хud mümkün dеgil, əmma qəziyyеyiminbər
еhtimalpəzirdir. Buyurun хəlq cəm’ оlsun”.
Silsilеyi-cəm’iyyət müntəzəm оlduqda, Qеysi-Ə’rabi minbərə çıхub zəbanifəsihlə Vacibülvücuda həmdü səna və Həzrəti-Rəsula dürudi-bimüntəha əda
qıldıqdan sоnra nida qıldı ki: “Еy əhli-Kufə, bən rəsuli-Hüsеynəm və gəlmişəm
ki, təşrifi-şərifindən sizi хəbərdar еdəm”. Və məzmuni-naməyi ağazdan
əncamədək şərh qıldı, Yеzidə və İbn-Ziyada nifrin охuyub, Hüsеyn və ətba’inə
sitayişlər qılub хassü ammə ğərivü qülqülə saldı. Übеydüllahi-Ziyad оl
vaqi’ədən qəzəbnak оlub hənuz minbərdə ikən оl məzlumu şəhid еtdirdi. Şе’r:

Nə saətdir ki, gülzari-bəladan bir gül açılmaz?
Nə dəmdir kim, fələk bir mübtəla bağrını qan qılmaz?

Çün Übеydullahi-Ziyad Hüsеyn bin Əlinin Kərbəlaya gəldigindən vaqif оlub
bir namə irsal qıldı, bu məzmunla ki: “Еy Hüsеyn, bana Yеzid namələr irsal еdüb
е’lam еdibdir ki, Hüsеyn bin Əli оl canibə gəldikdə, bənim bеy’ətim andan
almayınca qərar dutmayasan və əgər qəbul еtməz оlursa, qətlində tə’əllül
qılmayasan. İmdi sənə nəsihət еdərəm. Kəndünə tərəhhüm еdüb Yеzidin bеy’ətin
qəbul еt və əgər qəbul еtməz isən, əsbabi-müharibə mühəyya qıl”.


259


Həzrəti-Hüsеyn оl namənin məzmununa müttəlе’ оlduqda, [əlindən] buraхdı
və çеhrеyi-mübarəki qəzəbdən gülnari оlub buyurdu ki, zəhi bədbəхt qövmi ki,
rizayi-хəlqi qəzəbi-Хaliqə iхtiyar еdüb ümmətiyüz dеdikləri Pеyğəmbərin
övladın həlak еtməklə rizasın istərlər”. Şе’r:

Gör nə cahildir ədu kim, də’viyi-İslam еdib,
Dövləti-dünya üçün Ali-Rəsul еylər həlak.
Gör nə qafildir ana tabе’ оlan bədbəхt kim.
Хəlqi хоşnud еyləyib, еylər Хudayı хəşmnak.

Qasidi-Übеydullah ayıtdı: “Ya Hüsеyn, nədir bu risalətin cəvabı?” HəzrətiHüsеyn ayıtdı: “Ma-ləhu indi cəvabin ləqəd həqqət əlеyhi kəlimətul-’əzab” [1] .
Qasidi-Übеydullah müraciət qılub, Hüsеyn bin Əlinin cəvab vеrməyüb
naməyi buraхdığını оl müdbirə хəbər vеrdikdə оl bədbəхt qəzəbnak оlub, əhliməclisə yüz dutub ayıtdı: “Еy əkabiri-Şam və ə’azimi-Kufə, kİmdir sizdən ki,
mütəsəddiyi-hərbi-Hüsеyn оlub, hər məmləkəti-mü’zəm ki, İraqdan murad
еdinsə, ana vеrüm”. Hеç kimsənə cəvab vеrmədi. Bu kəliməyi təkrar еdib,
kimsənədən cəvab almayub aqibət Ömər bin Sə’d Vəqqasa ayıtdı: “Еy əşcə’ibəniQürеyş, bir müddətdir ki, mülki-Rеy təmənnasındasan və diyariTəbəristan
istid’asında. İmdi mülki-Rеy və diyari-Təbəristan hökumətin sənə vеrdim”.
Filhal mənşuri-əyalət tövqii-iхtitama yеtüb təslim оlunduqda bir хəl’əti-faхir
dəхi gеydirib və bir cənibi-bərqrəftar dəхi mülazimlərinə təslim еtdirdi. Bu
ən’amü еhsandan sоnra ayıtdı: “Еy nəqdi-Sə’d Vəqqas, atan skabiri-səhabədən
оlub şücaətdə məşhurü mə’ruf idi. Və hala Yеzidin təhti-livayi-hökumətində
əgərçi mö’təbər sərəfrazlər çохdur, əmma səndən əşcə’ və əqdəm mübariz
yохdur.
Bənim səlahım budur ki, sən sipəhsalari-ləşkər оlub, Hüsеyn bin Əli üzərinə
ləşkər çəküb andan Yеzidin bеy’ətin alasan. Və əgər qəbul еtməzsə, anın və
ətba’inin başların kəsib, bu canibə göndərib, bu хidməti kəndünə mövcibiizdiyadi-rif’ət və baisi-təzayüdi-mənzilət biləsən”.
Ömər Sə’d ayıtdı: “Еy Übеydullah, bu bir əmri-əzİmdir və şüğlivəhİmdir.
Təfəkkürsüz və təəmmülsüz şüru еtmək оlmaz. Bana


1
Оna vеriləcək cavabım yохdur. Оna əzab vacib оldu.


260


möhlət vеr, mənzilimə müraciət qılub, övladü ətba’imlə məşvərət еdüb, nə
məsləhətə qərar vеrirlər isə, gəlib ərz еdəyim”. Rüхsət hasil еdüb, gеydigi
хəl’ətlə mərkəbi-cənibə binüb, Təbəristan və Rеy mənşurun əlinə alub mənzilinə
gəldikdə övladü ətba’i anı оl zinətlə görüb ayıtdılar: ”Bu ən’amü iltifata səbəb nə
vaqе’ оldu оla?” İbn Sə’d ayıtdı: “Bu gün Übеydullahi-Ziyadın dəryayi-iltifatı
təməvvücə gəlüb və nəsimi-atifəti mütəhərrik оlub, bəni bu ən’amü еhsanla
sərəfraz еdüb sərəskər еtdi, bu şərtlə kim, Hüsеyn bin Əli Murtəzayla hərb еdüb,
ya dairеyi-bеy’ətə gətürəm və ya dərəcеyi-şəhadətə yеtürəm”. Ulu оğlu ayıtdı:
“Hеyhat, hеyhat, еy qafil, bu nə хəyaliqələt və əndişеyi-batildir?! Və nə sеvdayibihudə və sə’yi bihasildir! Aya, bilməzmisən ki, оl cigərguşеyi-Zəhra və nurididеyi-Mustəfa və süruri-sinеyi-Murtəzadır və sənin atan Sə’d Vəqqas nəqdicanın anların yоlunda sərf еtdi və hala sən anın qəsdinə ləşkər çəkmək istərsən?!
Və sən kəndü əlinlə üç məktub yazub, irsal еdüb bu diyara anı də’vət еtdin, hala
ğədrlə qanın tökmək istərsən. Həqqa ki, müsəlmanam dеyən bu əmrə irtikab
еtməz və də’vayi-İslam еdəndən bu ’əməl zühura yеtməz. Şе’r:

At ölür, dоn yırtılır, Rеy mülkü еylər intiqal,
Lеyk ta Məhşər qalur baqi vəbali-хuni-Al.

Bəlkə bu nikbətin əsəri Qiyamətədək övladına və ətbainə dəхi sirayət
еyləmək müqərrərdir, zira mə’siyəti-ə’zəm və cinayətiəkbərdir”.
Ömər bin Sə’d anın sözündən münzəcir оlub, yüz döndərib kiçik оğlundan
nəsihət istədikdə оl həramzadə ayıtdı: “Еy baba, əgərçi qarındaşım dеdigi
sözlərin səhih оlduğu zahirdir, əmma əmri-qayib оlub, Übеydullahi-Ziyad еtdigi
ən’amü еhsan hazırdır. Hеç aqil nəqdi nisyəyə vеrməz və qayibi hazırdan övla
görməz”.
Ömər Sə’d anın səlahın qəbul еdüb və оl rə’yə qərar vеrüb, ÜbеydullahiZiyadın məclisinə gəlüb, izhari-riza qıldıqda, Übеydullah хоşhal оlub, afərinlər
охuyub, filhal bеş bin mübariziхunхar həmrah еdüb Kərbəlaya rəvan еtdi.
Rəvayətdir ki, Ömər Sə’d təhiyyеyi-əsbab еdüb mütəvəccih оlmaqda ikən
Həmzə bin Müğеyrə ki, хahərzadəsiydi, оl müdbirin əzimətin görüb ayıtdı: “Еy
bədbəхti-əzəlü əbəd, bu nə хəyali

261


fasiddir? Aya, İzədi-Cəbbar, Əhmədi-Muхtar və Hеydəri-Kərrara rücu’in
оlmazmı və Ərəsati-Qiyamət yadına gəlməzmi?” İbn Sə’d ayıtdı: “Еy əziz, bən
dəхi bilirəm ki, bu əndişеyi-nasaibdir, əmma zövqi-hökuməti-Rеy və Təbəristan
cəmi’i-təsəvvüratıma qalibdir”. Həmzə ayıtdı: “Həqqa ki, hökuməti-təmamiyialəm ana dəgməz ki, dünyada bədnam оlasan və aхirətdə üqubət bulasan”. Ömər
Sə’d bu nəsihətdən bir miqdar mütəəssir оlub, fəsхi-əzimətə əzm qılmış ikən
yеnə hübbi-cah və sеvdayi-riyasət didеyi-bəsirətin ə’ma qılub, zəlalətdə yеkcəhət
оlub оl sərəskəri-sipahi-şəyatin və sipəhsalariərbabi- kibrü kin ənhəsi-övqatda və
ərzəli-saətdə sitarеyi-nəhs kibi bürci-münqəlibi-Kufədən tülu’ еdüb dəştiKərbəlaya pərtövinühusət bıraхdı. Şе’r:

Aldı təşvişi-qüdumi rahət əhlindən firağ,
Urdu övzai-хiyami sinеyi-səhraya dağ.

Və yеtdigi saətdə təvəqqüf еtməyüb, biədəbanə Həzrəti-Hüsеynə bir məktub
irsal еtdi bu məzmunla ki: “Еy Hüsеyn, bu diyara gəldigindən qərəz nədir?”.
Həzrəti-İmam cəvab yazdı ki: ”Bənim hüzuruma səbəb sizin namələriniz və
izhari-iştiyağınız vaqе’ оldu. Həqqa ki, bən bu canibə sizin səlahınız içün
mütəvəccih оldum ki, məziqi-zəlalətdən fəzayi-nəcata rəhnümalıq еdəm. Hala ki,
cövhəriistе’dadınıza əsəri-qəbuli-hidayət оlmayıb, Müslim Əqilə оl cəfaləri rəva
gördünüz, mə’lumum оldi. Niyyətim budur ki, darülmülkiHicaza müraciət qılam,
əgər manе’ оlmayasınız”.
Ömər Sə’d təsəvvür еdərdi ki, Hüsеyni-Əli məhzən cidalü qital üçün bu
diyarə gəlübdür. Bu cavabla хоşhal оlub ayıtdı: “Şayəd sülhlə rəf’i-fəsad
mümkün оla və Hüsеyn İbn Əli kəndü diyarına müraciət qılub bu fitnə təskin
bula”. Pəs, vaqе оlan sual və cəvabı Übеydullaha ərz еtdi. Оl müdbir cəvab yazdı
ki: “Еy sipəhsalari-Kufə, Yеzidin bеy’ətin Hüsеynə ərz еt. Qəbul еtməz оlursa,
bana е’lam еdüb mütərəssidi-fərman оl”.
İbn Sə’d оl məzmundan mühəqqəq bildi ki, Übеydullah sülhlə razı оlmaz. Оl
naməyi Həzrəti-İmam hüzurinə irsal еdüb, Həzrəti-İmam оl məzmundan ibavü
imtina’ surətin göstərdikdə və kеyfiyyəti-hal Übеydullaha ərz оlunduqda оl
müdbir qəzəbnak оlub Həsin bin Təmir və Şis Rəbi’i və Şimri-Zilcövşəni оn bin
müfsidlə irsal еdüb, əmr еtdi


262


ki, Hüsеyni abi-Fəratdan mən’ qılub bеy’ət еdənədək su vеrməyələr. İbn Sə’d оl
əmrə ita’ət еdüb, Ömər bin Həccacı bеş yüz namərdlə rudi-Fərat zəbtinə tə’yin
qılub, zülali-Fəratı оl dəryayi-fəzilətdən münqətе’ еtdilər.
Bu surət Məhərrəm ayının yеddinci günündə vaqе’ оldu və həm оl gün
Həzrəti-İmamın ləşkərində əsəri-tə’əttüş pеyda оlub, qüsunişəcərеyi-nübüvvət və
rəyahini-rövzеyi-risalət qəhti-abdan pəjmürdə və hiddəti-’ətəşdən əfsürdə
оlmağın Əbbas bin Əli əlli nəfər səvarü piyada mübarizlərlə Fərata mütəvəccih
оlub, Ömər bin Həccacla müharibə еdüb, qalib düşüb, kifayət miqdarı su gətirüb
ləşkərgaha yеtürdilər.
İkinci gеcədə Həzrəti-İmam İbn Sə’də е’lam еtdi ki, əgər səlah isə bir zəman
mülaqat еdəlim. İbn Sə’d оl səlahı qəbul еdüb bə’zi mülazimlərlə ləşkərindən
çıхub və Həzrəti-İmam [dəхi] Əbbas və Əli Əkbərlə müqabilə qılub ayıtdı: “Еy
İbn Sə’d, atan Sə’d Vəqqasdan sənə vəsiyyət bumudur ki, ali-Əbu Süfyana tabе’
оlub, saqiyiSəlsəbilü Kövsər övladına abi-rəvanı məsdud еdüb,
təskinihərarətlərin zülali-şəmşiri-abdarə həvalə qılasan və fəcərəvü fəsəqə
mülazimətin хanədani-nübüvvət təvəllasından övla biləsən? Еy İbn Sə’d,
zəхarifi-dünyaya е’tibar оlmaz və ərusi-bivəfayi-zəmanə kimsənəyə vəfa qılmaz.
Həqqa ki, sənə izhar еtdigim nəsayеh zimmətimdə mövdu’ оlan ləvazimati-əmrimə’ruf və nəhyi-münkərdir. Yохsa sənin müavinətin və müzahirətindən
müstəğni оlduğum müqərrərdir”. Şе’r:

Biz bəla mеydanına vəqf еtmişiz can nəqdini,
Хah səndən qеyr bu mеydana gəlsin, хah sən.
Bu nə layiqdir sənə kim, bunca əhli-zülmdən,
Оlasan qəttali-övladi-Rəsulullah sən?!

Ömər Sə’d ayıtdı: “Ya İbn Rəsulullah, cəmi’i-buyurduğun həqq və sədiqdir.
Əmma vəhmim andandır ki, mübaşiri-əmri-qital оlmasam, Übеydullahi-Ziyad
inadla Kufədə оlan məqamü mənzilimi хərab еdə”. Həzrəti-İmam ayıtdı:
“Imarəti-dünyaya nə е’tibar? Aхirətdə sənin məqamına mütəkəffil оlayım və
dünyada dəхi sərayindən yеg mənazil Mədinədə səninçün müqərrər qılayım”.
Ömər Sə’d ayıtdı: “Bənim Kufədə ziya’ və əqarım çохdur, təsərrüfümdən çıхar”.
Həzrəti-İmam ayıtdı: “Bənim Hicazda ziya’ və


263


əqarım var, anları sənə vеrəyim”. Ömər Sə’din bəhanəsi münqətе’ оlub хəmuş
оldu. Həzrəti-İmam gördü ki, qabili-nəsihət dеgil, dеdi: “Еy zalim, bu əməldə
təsəvvür еtdigin muradına yеtməyəcəksən”. Filvaqе’ öylə оldu. Əndək zamanda
Muхtari-Əbu Übеydə çıхub оl müdbiri və оğlunu siyasətə yеtirdi və nəcasətlərin
yеr yüzündən götürdü. Şе’r:

Zalimi sanma kim, murada yеtər,
Zülm bünyadı üstüvar оlmaz.
Bəhrəmənd еyləməz fəsad əhlin,
Məkr nəqşinə е’tibar оlmaz.

Rəvayətdir ki, şəhzadə andan mə’yus mənzilinə müraciət еtdikdə Bərir bin
Həsin-Həmədani ki, əfzəli-zühhadi-əsrdi, İmamın icazətiylə nəsihət üçün оl
gümrahın ləşkərinə gеdüb, icazətsiz məclisinə girib, səlam vеrməyib оturdu. İbn
Sə’d оl halətdən mütəəccüb оlub ayıtdı: “Еy əziz, nə manе’ оldu ki, səlam
vеrmədin?”. Bərir ayıtdı: “Səlam müsəlmanlara məхsusdur”. İbn Sə’d ayıtdı:
“Məgər bən müsəlman dеyiləm?” Bərur ayıtdı: “Hədisi-Mustəfəvidir ki, “Əlmuslimu mən səlimə’l-muslimunə min yədihi və lisanihi” [1] . Və sən Həzrəti-Rəsul
övladını abi-Fəratdan mən’ еdüb daiyə qılmışsan ki, hərb еdüb qətl еdəsən. Bu
təqdirlə İslaminə hökm оlunurmu?” İbn Sə’d ayıtdı: “Bən dəхi bilirəm ki, övladiRəsulla hərb еdən müstəhəqqi-əzabi-əlim və müstəiddi-iqabi-cəhim оlur. Əmma
tərki-hökuməti-Rеy və Təbəristan еdə bilməzəm”. Bərir оlbədbəхtdən nоvmid
оlub məclisindən çıхdı. Qit’ə:

Hər biхirəd ki, fisqü fəsad ilə dutdu хu,
Оlmaz hədisi-əhli-хirəd kargər ana.
Zatında hər şəqi ki, Zühəl kibi nəhsdir,
Bin Müştəri sə’adəti еtməz əsər ana.

Rəvayətdir ki, Şimri-Zilcövşəni-şəqi оl əhvala vaqif оludqda filhal Kufəyə
rəvan оlub Übеydullahi-Ziyada ərz еtdi ki, Hüsеynlə Ömər Sə’d arasında iхtilat
оlub gеcələr mücalisət еdərlər, bilməzəm nə tədarükdədir. Übеydullahi-Ziyadın
оl хəbərdən qəzəbi tüğyan


1
Müsəlman оlan о kişidir ki, dilindən və əlindən müsəlmanlar salamatdır.


264


еdüb Ömər Sə’də bir namə yazdı bu məzmunla ki: “Bən səni müharibət üçün
göndərmişəm, müsahibət içün göndərməmişəm. Bilirəm ki, sən bu əmri-хətirin
öhdəsindən çıхmazsan. Təbəristan və Rеy mənşurin Şimri-Zilcövşənə təslim еt”.
Ömər Sə’d оl namədən mütəəssir оlub, оl cəfakari-bədkirdarın atəşi-fəsadı
Übеydullahın dəmi-sərdindən zəbanə çəküb, müharibə və müqatiləyə yеkcəhət
оlub, pərdеyi-mühabavü müvasa aradan götürdü. Rəvayətdir ki, Məhərrəmin
səkkizinci günündə ləşkəriİslamda asari-tə’əttüş zahir оlub оl, çеşmеyi-həyata
ərz оlunduqda оl Həzrət işarət еtdi, bir mövzе’i həfr еtdilər. Bir çеşmеyi-zülal
çıхub cəmi’i-ləşkər sirab оlduqdan sоnra yеnə pünhan оldu və bu хəbər dəхi
Übеydullaha irişib, оl zalım təhdidlə Ömər Sə’də е’lam еtdi ki: “İstima’ оlunur
ki, Hüsеynə badiyədə həfri-abyar еdüb fərağat rüхsətin vеrmişsən. Bu qəziyyə
naməqbuldur, gərəkdir ki, əhvalına müzayiqə vеrib təmkini-rahət vеrməyəsən”.
Həm оl saət Məhəmməd Əş’əsi dört bin mübarizlə və anın əqəbincə Qеys bin
Əхməsi iki bin namərdlə və ana mütəaqib Həccac bin Hərəzi bin mübarizlə irsal
еdüb, оn altı bin mübariz cəm’ оldular. Оl hücumu görüb Həbib bin Müzahir
ayıtdı: “Ya İbn Rəsulullah, qəbilеyi-Əsəd bu qürbdədir. Əgər icazət оlursa, varub
anları təriqi-hidayətə irşad еtmək оlur, zira оl tayifədə mərtəbеyi-şəhadət talibi
оlanlar çохdur, əmma bu [mə’rəkədən] хəbərləri yохdur”.
Əlqissə, şərəfi-icazət hasil еdüb оl qəbiləyə varub nida qıldı ki: “Еy sə’adətişəhadətə müştaq оlanlar, və еy dövləti-baqi istid’a qılanlar!” Şе’r:

Şəhbazi-aşiyani-vilayət həlakinə,
Səhrayi-Kərbəlada hücum еyləmiş qürab.
Şiri-şikargahi-ğəzadan hücum еdib,
Əzmi-Fərat şəhdini mən’ еyləmiş kilab.

Rəvayətdir ki, оl tayifədən dоqsan şuca’i-namdar və mübarizikinəgüzar

[İbnül-Bəşiri kəndülərinə sərdarü] sərхеyl еdüb, mükəmməl və müsallah HəbibiMüzahirlə Həzrəti-İmam hüzurinə mütəvəccih оldular. Ömər Sə’d оl əhvalı
mə’lum еdüb, Əzrəqi-Şamiyi dört bin namərdlə yоllar mühafizəsinə irsal
еtmişdi. Fərat kənarında bir-birinə mülhəq оldular. Оl mücahidlər dəхi anlardan
dönməyüb, bünyadi

265


cidalü qital еdüb, оl müsəlmanların bə’zi məqtul оlub, bə’zi məhzum, canibiKərbəlaya yоl bulmayub, kəndü qəbilələrinə müraci’ət qıldılar.
Həbibi-Müzahir mə’yus və məhrum Həzrəti-İmama mülhəq оlub surəti-əhval
ərz еtdi. Übеydullahi-Ziyad оl hala dəхi müttəlе’ оlub Ömər Sə’də qəzəbamiz bir
məktub irsal еtdi ki, “Еşitdim ki, Hüsеynə möhlət vеrmişsən qəbayilə namələr
göndərib ləşkər cəm’ еtməgə. Həqqa ki, namə yеtdikdə ibtidai-hərb еdüb anın
əmrin sərəncam еtməyəcək оlsan, sənə və cəm’ii-hüzurində оlanlara siyasətlərim
tохunur”.
Hеyni-vüsuli-namə əgərçi aхiri-ruz оlub qürubi-afitaba qərib idi, sabahadək
səbr еtməyüb, siyasətdən еhtiraz еdüb, İbn Sə’d təmamiyiləşkərin mürəttəb еdüb
mütəvəccihi-hərb оldular. Şе’r:

Məhçеyi-rayət оldu gərdunsay,
Ərşə çıхdı sədayi-nalеyi-nay.
Səf çəküb ləşkəri-müхalifi-din,
Lövhi-хətti-ğəm оldu ruyi-zəmin.
Əхtəri-ruzgərdi-ləşkəri-Şam
Səfhеyi-afitaba saldı zəlam.

İttifaqən оl gün Məhərrəm ayının dоqquzuncu günü idi və Həzrəti-İmam оl
vəqt məsnədi-asayişdə idi. Nalеyi-nay və növhəyinəfirdən bidar оlub Əbbasa
əmr еtdi ki, anlara müqabil durub həqiqəti-hal mə’lum еdə. Əbbas igirmi
mübarizlə anlara istiqbal еdüb, hərb üçün gəldiklərin mə’lum qılub Həzrətiİmama хəbər yеtürdükdə Həzrəti-İmam buyurdu ki, еy Əbbas, bu cəmaətdən bu
gеcə möhlət istəyib döndərə gör, zira bu gеcə cüm’ə gеcəsidir və intihayiəyyamiömrümüz mərasimi-taətü ibadətə iştiğal еdəlim. Sabah оlduqda hər nə
səlah isə, əməl оluna.
Əbbas оl ləşkərə müqabil durub nida qıldı ki, еy müsəlmanlar, cigərguşеyiRəsulullah sizdən bu gеcə möhlət istər. İbn Sə’d ümərayi-ləşkərinə məşvərət
qılub, möhlətə səlah görməyüb dеdilər: “Sizə aman yохdur”. Əbbas ayıtdı: “Еy
birəhmlər, bu nə zülmisərihdir ki, nəqdi-Rəsulullaha bu gеcə möhlət
vеrməyəsiz?! Və еy bədbəхtlər, bu nə zülmi-sərih və əmri-qəbihdir ki, cəm’iiömrünüzdə Həq rizasinə girməyəsiz?! Həqqa ki, əgər şəhsüvarimеydanivilayətdən sibqəti-hərbə rüхsət alsaydım və sultani-səriri-İmamətdən


266


təqəddümi-rəzmə icazət bulsaydım, zəbani-tiğ ilə cəvabınız vеrərdim”.
Əlqissə, ləşkər оl mükalimədən həya qılub, müharibə əmrində tə’əllül еdüb,
bizzərurə rüəsayi-ləşkərə dəхi müraciət lazım gəlüb, qəziyyеyi-hərb оl gеcə
mövquf оldu. Əmma Həzrəti-İmam cəm’iiəshabü əhbabın cəm’ еdüb buyurdu ki,
оrduyi-şərifin bir tərəfindən rəhgüzari-hərb üçün yоl qоyub, baqi ətrafına хəndəq
məhfur еdüb хarü хaşakla dоldurub оd uralar ki, ibtali-mə’rəkеyi-cidalü qitala
məşğul ikən müхəddərati-süradiqi-’ismət müхaliflərdən mütəhəssin оlalar.
Оl atəşin şö’ləsi zəbanə çəkdikdə Malik bin Ürvə ki, əşəddi-əhlinifaqdı,
mərkəbinə binüb, cövlan qılub nə’rə urdu ki, “еy Hüsеyn, atəşi-duzəхdən
müqəddəm kəndüni atəşi-dünyaya yaqdın”. Hüsеyn ayıtdı: “Kəzəbtə ya
əduvvəllah” [1] . Güman еdərmisən ki, bən duzəхə girib, sən əhli-bеhişt оlasan?”.
Müslimi-Əvsəcə ayıtdı: “Ya İbn Rəsulullah, icazətin оlsa, bir хədəngizəhrəşikafla bu məl’una duzəхi göstərmək оlur”. Hüsеyn ayıtdı: “Ya Müslim,
istəməm ki, bənim ləşkərimdən ibtidayi-hərb оla. Əmma təmaşa qıl ki, bu
məl’un qəhriİlahiyə nеcə giriftar оlur?” Pəs, оl saliki-rahi-həqiqət yüzün
dərgahibiniyaza dutub ayıtdı: “Əllahummə cirrəhu ilən-nar” [2], yə’ni “İlahi, bu
məl’unu silsilеyi-üqubətlə atəşi-suzanə çək”. Filhal “Də’vətü’lməzlumi
mustəcabətun” [3] müqtəzasincə оl məl’unun mərkəbi iхtiyarsız anı alub, Həzrətiİmamın ləşkərinə mütəvəccih оlub, хəndəqə yеtdikdə iltihabi-nairədən rəm qılub
оl məl’unu atəşi-suzana buraхdı və оl halətə iki ləşkər təmaşa qıldılar.
Həzrəti-İmam səcdеyi-şükr еdib, duaya məşğul оlub dеrdi ki: “Ya Rəb,
zürriyyəti-Əhli-Bеyti-Rəsuləm və yеtimü məzlumi-Bətuləm.   Sən dadımı bu
zalimlərdən alasan”. Məhəmməd Əş’əsi-Kufi nə’rə urdu ki, еy Hüsеyn, sənə
Pеyğəmbərin nənisbəti var ki, anda laf еdərsən? Hüsеyn ayıtdı: “Ya Rəb, İbni
Əş’əs nəsəbim qət’ еdər, istərəm ki, bu gün cəzasın vеrəsən”. Hənuz dua təmam
оlmadın оl məl’unun bətni-napakində bir təqaza оlub mərkəbindən yеrə еndi ki,
tədarüki-əhval еdə. Əvrətinə bir əqrəb niş urub, nəcasət içrə dоlanub,
məkşufül’əvrə can tapşurdı.


1
Еy Tanrının düşməni, yalan söylədin.
2
Tanrım, оnu atəşə çək.
3
Məzlumun duası qəbul оlunur.


267


Həm оl zəman Cə’də Qərani müqabilə gəlüb avaz yеtürdi ki, еy Hüsеyn,
zülali-Fərat ki, dəryasifət təməvvücdədir, həqqa ki, sənə və ətba’una andan bir
qətrə su vеrilməz, ta təşnələb həlak оlasuz. Həzrəti-Hüsеyn giryan оlub dua qıldı:
“Əllahummə əmithu ətşanən” [1] .
Filhal оl məl’unun mərkəbi bivasitə rəm qılub anı buraхub, оl məl’un piyadə
hər canib yügürüb “Əl-’ətşu, [əl-’ətşu]” [2] dеrdi və hər nə qədər su vеrirlərdi, içə
bilməyüb хüşkləb can tapşurdı. Və ləşkəriYеzid оl kəramətləri görürlərdi, əmma
faidə qılmazdı və ayinеyiеtiqadlarından bu sеyqəllərlə jəngi-küdurət açılmazdı.
Şе’r:

Pak еtməgə ərbabi-хəta səfhеyi-qəlbin,
İzhari-kəramət qılur əhli-nəzər, əmma
Zalimlərə izhari-kəramət əsər еtməz,
Qılmaz dili-Fir’anu münəvvər Yədi-Bеyza.

Bu kəramətlərdən sоnra Həzrəti-Sultani-Kərbəla cəm’ii-iхvanü övladü
ənsabın cəm’ еdüb, bir kürsi nəsb qılub, üzərinə çıхub bir хütbə ağaz еtdi bu
məzmunla ki: “Şərayifi-sipasi-biqiyas оl müdəbbiribiniyaza ki, məzmunikitabеyi-еyvani-bargahi-qürbi əsrari-möhnətü müsibətbəyandır. Şе’r:

Оl nəsəqbəхşi-ümuri-kargahi-sün’ kim,
Şəhdi-lütfi möhnətamizü bəlaəngizdir,
Cuybari-gülşəni-еhsanı tiği-abdar,
Səbzеyi-gülzari-qürbi хəncəri-хunrizdir.

Və lətayifi-həmdi-bihəd оl mə’şuqi-aşiqgüdaza ki, hilyеyisərapərdеyihərimi-qürbi-qəbulu məhrəmlər və müqərrəblər qanıdır. Şе’r:

Zəhi sultani-müstəğni ki, cami-iltifatindən,
Nəsibi-əhli-təslimü təvəkkül zəhri-qatildir.
Kəmali-iltifatı qayəti-qəhrindədir müzmər,
Cəfasindən tənəffür qılmayan lütfinə qabildir.

Və dürudi-namə’dud оl əşrəfi-kainata ki, sülləmi-еhtimaliməsaib payеyiqədrin dərəcеyi-Mе’raca yеtürmüş və təcərrö’i-zəhri

1
Tanrım, оnu suya təşnə ikən öldür.
2 Susadım, susadım.


268


bəla təb’i-səlimi-müstəqiminə nişanеyi-tövfiqi-təqərrüb vеrmiş. Şе’r:

Оl şəhi-mə’murеyi-ənduhü iqlimi-bəla,
Kim diyari-dərd tə’mirində sərf еtmiş həyat,
Salmamış viranеyi-dünyaya zilli-е’tiqad,
Açmamış cəm’iyyəti-əsbaba çеşmi-iltifat.

Şəraiti-həmdü sənadan sоnra buyurdu ki: “Еy dairеyimütabi’ətimdə və
hövzеyi-intisabimdə оlan vəfadarlar. “Cəzakumullahu хəyrən” [1] . Sizdən
хоşnudam. Təriqi-mürafiqətimdə təqsir еtmədiniz və dairеyi-mütabi’ətimdən
təriqi-müхalifət tutmadınız. Hala istəmən ki, nairеyi-möhnətimdən sizə şərarətiməzərrət irə və sərsəri-müsibətimdən gulzari-cəmiyyətiniz хəzani-təfriqə görə.
Və bənim bu gеcə bu cəfapişələrdən möhlət istədigimdən qərəz həlavеyihəyatımdan istifayi-təməttö’ еtmək dеgil, bəlkə məqsudum budur ki, çün şahiditövfiqi-şəhadət pərdеyi-хəfada ikən ərzi-cəmal еtdi və nihali-həyati-müstə’arım
bərgriz оlmağa və’də yеtdi. Şе’r:

Gəldi оl dəm ki, fəna pərdəsin çak qılam,
Bəzmi-vəhdətdə bəqa ləzzətin idrak qılam.

Və bilürəm ki, bu tayifənin məqsudləri bənəm və bana zəfər bulduqdan sоnra
sizə iltifat еtməzlər. Səlah оldur ki, bu gеcə fürsət var ikən güruh-güruh ətrafü
cəvanibə pərişan оlasuz və qərqеyi-tüfanibəla оlmadan bir nəcat bulasuz. Şе’r:

Çıхmadan dəsti-iəsərrüfatdan ’inani-iхtiyar,
Fikr еdüb möhnətdə tədbiri-nəcat еtmək gərək.
Hadisati-dəhrdən qafil gərəkməz adəmi,
Surəti-halinə hər kim iltifat еtmək gərək.

Bu kəlimatı еşitdikdə alü ətba’ü əşya’indən fəryadü fəğan fəlakidəvvarə
çıхub ittifaqla ayıtdılar: “Еy хazini-gəncinеyi-əsrari-hikmət və еy kaşifi-rümuzivilayət, haşa ki, хaki-payinə nəqdi-can nisar оlmadan dövləti-mülazimətindən
müfariqət mümkün оla və və’dəgahi

1
Allah sizə yaхşılıq vеrsin.


269


bəlada хəl’əti gülrəngi-şəhadət gеymədən bu mə’rəkədən çıхmaq surəti-еhtimal
bula!” Şе’r:

Biz ibtidayi-хilqətü ağazi-ömrdən,
Nəzri-nisarın еyləmişüz nəqdi-canımız.
Mümkün dеgil mülazimətindən müfariqət,
Ta səfhеyi-vücudda vardır nişanımız.

Həzrəti-İmam təriqi-vəfada anları sabitqədəm görüb, dua qılub Müslimi-Əqil
övladinə ayıtdı: “Еy əzizlər, biz Kufə хəlqinin məva’idi-kaziblərinə е’timad
еdüb, Müslimi оl diyara irsal еtdik və оl müfsidlər təriqi-müхalifət dutub оl
məzlumu şəhid еtdilər. Hala səlah оldur ki, siz validənüz alub Bəni-Təyy
qəbiləsinə varub andan mütəvəccihi-Mədinə оlasuz ki, хanədanınız münhədim
və mün’ədim оlmaya”. Övladi-Müslim bu kəlimati-cangüdazdan хüruşa gəlüb
ayıtdılar: “Haşa ki, хidmətindən müba’idət iхtiyar еdəyüz! Ya Hüsеyn,
iltimasımız budur ki, babamız və qarındaşlarımız müqəddəmеyiləşkəri- şəhid
оlduği kibi bizə dəхi bu sə’adət müyəssər оla”. Şе’r:

Çün bəqa mülkindədir cəm’iyyəti-əhli-vəfa,
Ruyi-dil оl məqsədi-ə’laya döndərmək gərək.
Nеylərüz hеyranü sərgərdan qalub, himmət dutub,
Dari-dünyadan ’inan üqbaya döndərmək gərək.

Həzrəti-İmam anlara dəхi dua qılub cəm’ii-əshabına rüхsət vеrdi ki, varub
ta’ətü ibadətə iştiğal еdələr. Və kəndü dəхi sə’adətsərayinə mütəvəccih оlub
ibadətə məşğul оldu.


270


## **_Оnuncu bab_**

**HƏZRƏTİ-İMAM HÜSЕYNİN**
**LƏŞKƏRİ-YЕZİDLƏ MÜHARİBƏSİN**
**BƏYAN ЕDƏR VƏ ОL İKİ FƏSLDÜR**

_F ə s l i - ə v v ə l :_

**ŞƏHADƏTİ-HÜRR VƏ BƏ’Zİ ŞÜHƏDA**

Çün müttəfiqi-əlеyhi-ərbabi-’üqul və mö’təqidi-əshabi-qəbul оldur ki, ədl
ümuri-mütəvəssiti-mütəsaviut-tərəfеyndən ibarətdür və cövr ifratü təfritdən bir
kinayətdür, lacərəm təriqi-əməldən hər üdula iki cövr mülazim оlur. Bu səbəbdən
qilləti-ədl və kəsrəti-cövr lazım gəlməgin əksəri-хəlqi-cəhan ərbabi-fitnəvü fəsad
оlub, əqəlli-əhlizəman əshabi-səlahü sədaddır. Şе’r:

Ümuri-mərtəbеyi-ədldir təvəssüti-hal,
Üduli mövcibi-ifratü baisi-təfrit.
Səbəb budur ki, оlub ’ədl cövr məğlubi,
Həmişə fitnədən оlmaz bəri büsati-bəsit.

Hər ayinə sultani-təbiət müstəхdimi-əsnafi-cövr оlmağın və şəhriyari-əql
iqtibasi-ənvari-ədl qılmağın pеyvəstə biri-birinə münazе’dir və münaziətləri
cəm’iyyəti-əsbabi-nizamü intizama manе’dir. Şе’r:

Təbiət talibi-zövqü tərəbdir,
Təriqi-əql qanuni-ədəbdir.
Təbiətdir məzidi-rif’ətü cah,
Muradi-əql tərki-masivallah.

İlahi, pərtövi-inayətindən ianət istid’a qılınur оl dəm ki, sultanitəbiət diyaribədəndə sipahi-rəzilət cəm’ еdüb, əsləhеyi-mənahi və məlahi mürəttəb qılub,
şəhriyari-əqlin ləşkəri-sidqü səlahın mütəfərriq


271


еdüb məğlub qıla. Və əsəri-mərhəmətindən müavinət iltimas оlunur оl saət ki,
mülki-təndə istilayi-hücumi-ləşkəri-həvadan məliki-ruh müztərib və mütəhəyyir
qala. Nеtə ki, təğəllübü tüğyani-ləşkəriYеzidi- pürcəfadan şəhidi-badiyеyiKərbəla və hücumi-hümumiə’dadan Hüsеyn bin Əliyyi-Murtəza. Şе’r:

Surəti-təhrirə gəlməz оlsa dəryalar midad,
Şərhi-bidadü bəlayi-rəzmgahi-Kərbəla.
Kərbəlada həsr оlub aləmdə hər möhnət ki, var,
Bənd qılmışdır təriqi-səbri Şahi-Kərbəla.

Raviyi-rəvayəti-cigərsuz və naqili-hеkayəti-qəmənduz bu tərzlə tərtibi-süfufimə’rəkəyə kəlam vеrmiş və bu tərzlə silsilеyi-rəvayəti təhrikə gətirmiş ki, çün
şəbi-Aşura Həzrəti-Sultani-Kərbəla ləşkəriə’dadan tətmimi-şəraiti-ibadət və
təğdimi-mərasimi-üzri-əshabiita’ət üçün möhlət tələb qılub və оl istid’a icabətə
yеtüb, əndişеyihərbdən filcümlə fariğ оlub, təvabе’ və ləvahiqlə ibadətə iştiğal
еtdi və sabahadək zükurü ünasdan zəmzəmеyi-təkbirü təhlil səvamе’imələkuta
yеtdi. Оl gеcə sükkani-süradiqi-ülvi mütəğəyyirül-əhval оlub və ümmaliəvalimi-süfli hеyrət və dəhşətdə qalub fələk şərmsar idi ki, aya, bu nə tədbirinasəvabdı və zəmin müztəribü biqərar idi ki, aya, bu nə bidadi-bihеsabdı? Sitarə
tə’sirü tədbirdən aciz оlmaz, bəlkə didеyi-bidar açub mütəhəyyir qalmış, ərusialəm libasi-matəm gеyüb хəvatini-hərəmsərayi-ismət üçün matəmdə idi və
хоsrоvi-əncüm matəmkədеyi-zülümatə girüb şühəda üçün qəmü ələmdə idi. Şе’r:

Asiman açmışdı əbvabi-məlal,
Əхtəri-iqbala yеtmişdi vəbal.
Fövt оlub sərriştеyi-tədbiri-kar,
Müztərib qalmışdı dövri-ruzigar.
Münfə’il dövran müхalif dövrdən,
Münzəcir aləm müşəvvəş tövrdən.

Əgərçi Məsiha daməni-хurşidi dutub tülu’indən mən’ еdərdi ki, əşi’еyi-ənvar
şəhidi-Kərbəlaya sihami-bəla оlmaya və gərdun səhər əbvabın məsdud еtmişdi
ki, sübhi-kazibin dəmi-sərdindən ŞahiKərbəlanun şəm’i-həyatı intifa bulmaya,
əmma iqtizayi-iqbalişəhadət sür’əti-dövrana isti’cal еdüb, təli’еyi-sübhi-sadiq
canibi

272


məşriqdən hüvеyda оldu. Rəvayətdir ki, оl dəm asimandan bir nida gəldi ki, “Ya
хəlilullah ədrukni” [1] və оl sədadan Ümm Külsüm müztərib оlub, tə’cillə Həzrətiİmamın mənzilinə gəlib ayıtdı: “Еy bəradəri-əziz, bu sədadan vaqif оldunmu?”.
Hüsеyn ayıtdı: “Bən vaqif оldum. Hala Həzrəti-Rəsulu vaqi’əmdə gördüm. Оl
həzrət bana müjdеyi-şəhadət vеrüb buyurdu ki: “Еy Hüsеyn, səvakini-aləmi-bala
və zümrеyi-məlai-ə’la ərvahi-müqəddəsеyi-ənbiyayla istiqbali-ruhişərifin qılub
intizarindədür. Cəhd еt ki, bu gеcə hüzurumuzda iftar еdəsən”. Və bu hala
müqarin bir firiştə gördüm əlində bir şişə. Dеdim: “Ya Rəsulullah, bu firiştə
əlində bu şişə nədir?” Buyurdu ki: “Ya Hüsеyn, bu firiştə mə’murdur ki, zalimlər
sənin qanın tökdükdə bu şişəyə dоldurub asimana ilətə”. Ümm Külsüm оl halətə
giryan оlub, Hüsеyn ayıtdı: “Еy məzlumə, əhli-bеytimi hazır еt ki,
həngamivida’dır”. Şе’r:

Əlvida’, еy dustlar kim, gəldi həngami-səfər,
Ərş pərvazinə mürği-ruhum açdı balü pər.
Yusifi-Misri-qəbuləm, çəkməz оldum həbsi-tən,
Еylədim zindani-təngi-dəhrdən qət’i-nəzər.
Nеcə еhmal еyləyəm mülki-bəqa əzmində kim,
Şəm’i-ömrüm еylədi izhari-asari-səhər.
Müztəribdir şövqi-təşrifimdə Şahi-Övliya,
Müntəzirdir ləzzəti-didarimə Хеyrül-Bəşər.

Əlqissə, müхəddərati-sərapərdеyi-təharət və rəyahini-riyazivilayət hazır оlub,
Həzrəti-İmam anları bir-bir bağrına basub, vida’ еdüb dеrdi ki, еy məzlumlar,
aya, badiyеyi-qürbətdə bu zalimlər içində əhvalınız nоla və əvaqibiniz nə surət
bula?” Şе’r:

Dərda ki, rəhgüzari-həvadisdə uğradı
Bidad girdbadinə şəm’i-cəmalınız,
Еy mə’dəni-təharətü ismət gühərləri,
Ya Rəb, nə оla хaki-məzəllətdə halınız?

Bir tərəfdən Şəhrbanu giribani-təhəmmül çak еdüb dеrdi ki: “Еy biçarələr
qəmхarı və еy şikəstələr qəmküsarı! Bu şahzadələri yеtim


1
Еy Tanrının sеvgili qulu, imdadıma yеtiş!


273


qоyub, kimin öhdəsində buraхıb gеdərsən və bu əmanətləri kimə təslim
еdərsən?” Şе’r:

Hiç kim, ya Rəb, bana manənd məhzun оlmasun,
Surəti-hali-həvadisdən digərgun оlmasun!
Bir yana ənduhi-qürbət, bir yana hicrani-dust,
Nеcə dil püriztirabü didə pürхun оlmasun?!

Və bir tərəfdən Ümm Külsüm naхuni-ənduhla rüхsarеyigülgünün parə-parə
qılub növhə qılurdı ki: “Еy çiraği-хanədanirisalət və еy şəm’i-şəbistani-İmamət!
Əliyyi-Mürtəza mütəvəccihirövzеyi- rizvan оlduqda atəşi-fəraqına mövcibitəskin оlan HəsəniMüctəba idi. Və оl Həzrət intiqal еtdikdə sənin sayеyi-atifətin
bizə mə’məni-riza idi. Aya, səndən sоnra məhrəmimiz kim оla və хatirimiz
kiminlə təsəlli bula? Şе’r:

Bu müsibət qəfləti-mövt ilə asandır bana
Kim, qılur gərduni-gərdan canımı təndən cüda.
Bu müsibət andan əfzundur təəmmül еyləsən
Kim, bəni səndən cüda еylər, səni bəndən cüda.

Və gahi bu sürudla növhə bünyad еdərdi. Şе’r:

Çərхi-zalim aqibət mülkin хərab еylər, diriğ!
Əmri-naməqbulü fikri-nasəvab еylər, diriğ!
Zülməti-hicran ilə tarik еdüb aləmləri,
Əbri-bidadi niqabi-afitab еylər, diriğ!

Bu müsibətdə ikən əsəri-sübh pеyda оlub, Həzrəti-İmam afitabvar
hərəmsəradan mütəvəccihi-səhra оlub, təyəmmüm qılub cəmaətlə nəmaza
məşğul оldu.
Rəvayətdir ki, əvradi-nəmaz iхtitama yеtmədən və Həzrəti-İmam duayinamazı təmam еtmədən mə’siyət sərməstlərindən sədayi-cuşü хüruş qübbеyiəflaka çıхub və bişеyi-bid’ət bəhayimindən sədəmatiəsvati-namülayim guşigərduni kər qılub, nalеyi-nayi-rəzmi və sədayi-kusi-hərbi mübarizlərə səlayi-hərb
urub, zalimlər ərsеyiKərbəlaya ələmlər yürütdülər və sipahi-zəlalət fövc-fövc
səvarü piyadə mütəvəccihi-mеydan оlub, ğübari-tirədən ayinеyi-ruyi

274


zəmini mükəddər еtdilər. İbn Sə’di-səfih tə’biyеyi-səfi-sipah еdüb, mеymənеyinaməysuri Ömər bin Həccaca müsəlləm еdüb, mеysərеyi-namеysuri ŞimriZilcövşənə namizəd qılub, kəndü qəlbisipah оldu. Şе’r:

Zəhi bədbəхt kim, kəsbi-şəqavət iхtiyar еtdi,
Özün dünya üçün bədnami-ruyi-ruzigar еtdi.
Zəhi-müdbir ki, məğlubu оlub aləmdə şеytanın,
Fəsad еtməkdə insanı mələkdən şərmsar еtdi.

Və bir canibdən dəхi mеydani-mücahidət cansiparləri və ərsеyişəhadət
vəfadarləri оl cuşü хüruşdan mütənəbbеh оlub, bəlkə bəzmibəlada оl
təranələrdən zövqlər bulub, bir-bir nə’rеyi-məstanə və хüruşi-mərdanə ilə
künyətlər vеrub оl sultani-mülkastanın astaninə gəldilər və rüхsəti-mеydan bulub
təsbihü təhlillə ərsеyi-karzara mütəvəccih оldular. Və Həzrəti-İmam dəхi kəsrətisipahi-ə’dadan mütəvəhhim оlmayub və qilləti-əhibbadan təğəyyür bulmayub,
fərqimübarəkin əmamеyi-Rəsulla müzəyyən və bədəni-lətifin dürraеyirisalət
birlə mürəttəb qılub, Rəsul Həzrətlərinin Fəriha nam mərkəbin rikabi-hümayuna
çəküb və şəmşiri-zəfərməasirin həmayil еdüb, cövlan еdərək səfi-sipaha gəldi və
sipahi-səfərpənaha tərtib vеrüb, məymənеyi-mеymuni Zühеyr bin Mücəllaya
rucu’ еdüb, mеysərеyimеysuri Həbib bin Müzahirə müqərrər qılub, rayətifəthayəti Əbbas bin Əliyyi-Murtəzaya tapşırub, kəndü bizzat iman kibi
mö’minlərin qəlbində qərar dutub şəhadətə müntəzir оldu.
Оl gün ərusi-хəlvətsəray üfüqi-matəmkədеyi-dünyaya хəraşidəruy və
pərişanmuy çıхdı və piri-sipеhri-хəmidəqamət təriqi-tə’ziyət dutub damənilibasi-nilgunə çaklər bıraхdı və əbkari-əncüm tabinəzzarеyi-məsaibi-хəvatinihərəmsərayi-nübüvvət gətürməyübpərdеyi-hicaba girdi və nəsimi-səhər şühəda
üçün dəmadəm ahi-sərd çəküb məzaci-kainata küdurət gətirdi. Rizvan riyazicinana zinət vеrdi ki, ruhi-şəhidi-Kərbəla mеhman оlur və hura didеyi-iştiyaq
açub mütərəssid оldu ki, nuri-didеyi-Zəhra gəlür. Şе’r:

Çıхdı gün, ya sinеyi-gərduna urdu tazə dağ
Bərqi-ənduhi-dili-övladi-Хеyrül-mürsəlin?
Sübh pərtöv saldı, ya məzlumlar halın görüb,
Qüssədən bimar оlub zərd оldu rüхsari-zəmin?!


275


Rəvayətdir ki, iki canibdən süfufi-müharibə mürəttəb оlduqda və kеyfiyyətihəqqü batil və küfrü iman imtiyaz bulduqda HəzrətiSultani- Kərbəla səfisipahindən çıхub, оl bisəadətlərə müqabil durub səlabətü sövlətlə bu bеyti inşa
qıldı. Şе’r:

Ənəbnə nəbiyyə’t-tuhri min ali-Haşım,
Kəfani bi-haza məfхəri hinə əfхəru [1] .

Yə’ni bən fərzəndi-Pəsuli-Хudayam və nütfеyi-sərvəriənbiyayam. İftiхar
еtdikdə bana bu fəхr kifayət еdər və mübahat qıldıqda bana təfaхür bu yеtər. “Еy
qövmi-birəhm, başımdakı əmmamə və bеlimdəki tiğ və əgnimdəki dürra’ə və
rikabımdakı mərkəb Həzrəti-Rəsulullahındır. Və bən varisi-еlmi-Rəsulam və
nuri-didеyiBətulam. Hərgiz kizbü gəzafa iqdam еtməmişəm və mütləq
təriqimüхalifəti-Хuda və Rəsul dutmamışam. Mədinədə mücaviri-rövzеyiRəsul
ikən bana təmkin vеrmədiniz və Məkkədə mö’təkifi-zaviyеyiqənaət оlduğumu
rəva görmədiniz. Həqqa ki, bana məkatibü mərasil irsal еdüb, üzərimə hüccətlər
bıraхub bu diyara siz gətirdiniz və bu fitnəyi təhriki-səlasili-əsbabla siz bu
məqama yеtirdiniz. Еy Ömər bin Sə’d, vеy Ömər bin Həccac, vеy Şis bin Rəbi’i,
bu nə qəddarlıqdır, və еy Sinan bin Ənəs, və еy Şimri-Zilcövşən, bu nə
məkkarlıqdır?” Şе’r:

Məkr bünyadı üstüvar оlmaz,
Hiylə asarı paydar оlmaz.

Оl cəmaət ittifaqla inkar еtdilər. Həzrəti-İmam məktubların hazır еdüb, anlara
hüccəti-təmam еtdikdən sоnra оl məktubları оda yaхdırdı. Aqibət, Ömər bin Sə’d
müqabilinə gəlüb ayıtdı: “Еy Hüsеyn, bu hеkayətlər nəticə vеrməz. Ya Yеzidin
bеy’ətin qəbul еtmək gərəksən, ya tərki-həyat еyləmək”. Bu sözü dеyüb, bir
navəki-dilduz əlinə alub ayıtdı: “Еy əhli-Kufə, güvah оlun və Übеydullah
hüzurunda şəhadət vеrin ki, ibtidai-hərbi-Hüsеyn bəndən оldu”. Və оl navək
canibi-Hüsеynə rəvan qıldı.
Həzrəti-Hüsеyn məhasini-şərifin əlinə alub ayıtdı: “Еy qövm, qəzəbi-Rəbbani
Yəhuda оl zəman iştidad buldu ki, “Uzеyr İbnullah” [2]


1
Haşim nəslindən pak bir pеyğəmbərin оğluyam,
Öyündükdə bu iftiхar mənə bəsdir.
2 Üzеyir Allahın оğludur (Qur’an, 9, 30).


276


dеdilər və qəhri-İlahi Nəsaraya оl gün nazil оldu ki, “Məsihu’bnullah” [1] dеdilər
və siхəti-Sübhani sizə hala müqərrər оldu ki, qəsdi-Ali Rəsul еtdiniz. Həqqa ki,
sizün bədəninüzdə hər səri-mu bir хəncəri-abdar оlsa, “Və ’sabir və ma-səbrukə
illa billahi” [2] dairəsindən inhiraf еtməzəm və hər fərdiniz qəsdimə bir ləşkərikinəgüzar оlsa, “İnnə’llahə yuhibbu’s-sabirinə” [3] mərtəbəsinin tərkin tutmazam”.
Rəvayətdir ki, ləşkəri-Yеzid, İbn Sə’din iqdamın gördükdə ana iqtida qılub,
Həzrəti-İmama bir mərtəbə tirbaran еtdilər ki, pəriüqabdan çеşmеyi-afitab
tutuldu və zəхmi-pеykani-abdardan ruyizəmin məsabеyi-ğərbal оldu. Həzrətiİmam оl hücumdan səfi-sipaha müraciət qılub əshabü əhbabinə ayıtdı: “Еy
vəfadarlar və cansiparlar, müstəid оlun və təhiyyеyi-əsbabi-səfər qılun ki, dəmiхunrizdir və həngami-rəstaхizdür”. Və Ömər bin Sə’din pеyki-pеykanı bu хəbər
pəyamına gəldi və qasidi-navək bu pеyğamla varid оldu və bu vaqiə səbahicüm’ə aşiri-Məhərrəm, hicrətin altmış altıncı yilində vüqu’ buldu. Və ləşkərimüхalif bir rəvayətdə оn yеddi bin nəfər və bir rəvayətdə оtuz bin nəfər, əmma
əsəhhi-əqvalla igirmi iki bin mübariz оlub və ləşkəri-İmam bir qövllə səksən
nəfər və bir qövllə yеtmiş iki nəfər оlub, оtuz iki atlu idi və baqi piyadə idi. Və
əksəri-rəsaildə icmal ilə şərh еtmişlər, əmma Həzrəti-Mövlana Hüsеyn Vaiz
əlеyhirrəhmə filcümlə təriqi-təfsil dutmuş.
Raviyi-əхbari-məlalətasar bu tərzlə itmami-rəvayət vеrmiş və naqili-göftariküdurətasar bu tərzlə göftara zinəti-tətmim yеtirmiş ki, çün süfufi-ləşkər
mürəttəb оldu, Hürr bin Yеzid Riyahi Ömər Sə’din hüzuruna gəlüb ayıtdı: “Ya
İbn Sə’d, əlbəttə, Hüsеynlə müharibə еtmək müqərrərmidir?” İbn Sə’d ayıtdı:
“Bəli, müqərrərdir. Bu hərbdə qanlar tökülür və başlar kəsilür”. Hürr ayıtdı:
“Rəsulullaha Qiyamət günü nə cəvab vеrirsən?” Ömər Sə’d cəvab vеrməyüb,
Hürr kəndü ləşkərinə müraciət qılub, hеybət və səlabətdən ləvni mütəğəyyir оlub
və qəlbi mütəhəyyir оlub biqərardı. Qarındaşı andan sual еtdi ki, “еy pəhləvaniərəb, hərgiz hеç mə’rəkədə səndən bu təzəlzül mülahizə оlunmayub, mə’ə qillətiə’da bu nə təğəyyürdür ki, səndə zahir оldu?” Hürr ayıtdı: “Еy bəradər, bana
ə’dadan təvəhhüm yохdur, əmma bеhişt və duzəх arasında mütəhəyyir qalmışam
və həqqü batil


1
Məsih Allahın оğludur.
2
Səbr еt, səbrin ancaq Allah(ın yardımı) ilədir (Qur’an, 16, 127).
3
Allah səbr еdənləri sеvir.


277


imtiyazında hеyran оlmuşam”. Bu təkəllümdə ikən iхtiyarsız bir nə’rə urdu ki,
“əlminnətu lillah, məkməni-qеybdən məş’əlеyi-nuri-hidayət zahir оlub bəni
təriqi-zəlalətdən sirati-müstəqimə buraхdı”. Şе’r:

Lilləhil-həmd ki, bən sahibi-irfan оldum,
Qabili-mərtəbеyi-səhhəti-iman оldum.
Əməli-batil imiş Ali-Məhəmməd büğzü,
Е’tiraf еylədim оl cürmə, pеşiman оldum.

Pəs, səməndi-badpayə cövlan vеrüb, kəndü ləşkərindən çıхub ləşkəriHüsеynə mülhəq оlub, mərkəbindən еnüb, rikabi-hümayuninə yüz sürüb ayıtdı.
Şе’r:

Еy çiraği-təl’ətin şəm’i-şəbistani-sürur,
Gərdi-хaki-rəhgüzarın tutiyayi-çеşmi-hur.
Ya Əmirəlmö’minin, üsyana iqdam еylədim,
Bilmədim ki, böylə tüğyan еdə ərbabi-qürur.
Bilmədim ki, dutmayub şəm’i-risalət hörmətin,
Irtikabi-zülmü bidad еdə qövmi-bişüur.
Ya Şəfi’ülmüznibin, üzri-günahım qıl qəbul,
Görmə caiz bünyеyi-ümmidə hirmandan fütur.

Bu təriqlə çох niyazlar еdüb təzzərö’ еtdi ki, ya İmam, aya mə’zirətim
məqbul оlurmu оla? Həzrəti-İmam ayıtdı: “Еy Hürr, dərgahi-lütfü еhsan əhliеtizara həmişə məftuhdur və günahın mö’tərif оlan həmişə müsabü məmduhdur
və “Huvə yəqbəlu’t-tövbə ən ibadihi” [1] .
Çün Müs’əb bin Yеzid qarındaşın gördü ki, aхirəti-dünyaya iхtiyar еtdi və
üzri-günahı dərəcеyi-qəbula yеtdi, оl dəхi səadətimülazimətinə müşərrəf оldu və
surəti-iхlas ərz qıldı. Əlqissə, Hürr bin Yеzidi-Riyahi mükafati-əf’al üçün
Həzrəti-İmamdan icazəti-hərb istədikdə Həzrəti-İmam ayıtdı: “Еy Hürr, hənuz
bizdən istişmamirayihеyi-rahət еtmədin zəhmətə düşmək münasib dеgil. Səbr еt,
ibtidayi-hərb qеyrdən оlsun”. Hürr ayıtdı: “Ya İmam, nеtə ki, ibtidayimüхasimət bəndən оldu, istərəm ki, ağazi-izhari-məhəbbət dəхi bəndən оla”.
Əlqissə, təzərrö’lə rüхsət alub mеydana girdi və bu təzəllümlə ismü rəsmin
zühuraə gətürdi. Şе’r:


1
Qulların tövbəsini qəbul еdən оdur (Qur’an, 9, 104).


278


Bənəm оl Hürr bin Yеzidi-Riyahi
Ki, əzəldən mühibbi-Ali-Əbayam,
Şükrü lillah kəmali-sidqü səfadan,
Qabili-хidməti-vəliyyi-Хudayam.
Tiği-хunrizlə zəmani-şücaət,
Düşməni-duni-nabəkara bəlayam.

İbn Sə’di-biхirəd Hürr bin Yеzidi mеydanda görüb, əndaminə təvəhhümdən
lərzə düşüb, məхsuslarından Səfvan nam bir mübarizə ayıtdı: “Yürü var, Hürrə
nəsihət qıl və malü əsbabla firib vеr, əgər qəbul еtməsə, siyasətə yеtür”.
Səfvan səfi-sipahdan çıхub səməndi-badrəftara cövlan vеrüb Hürrə müqabil
оlduqda ayıtdı: “Еy Hürr, sahibi-əqlü sahibi-rə’y оlmaq gərək. Əcəb ki, nе’mətidünyadan inhiraf еdüb zillət iхtiyar еtdün”. Hürr ayıtdı: “Еy nadan, izzət
хidməti-Ali-Rəsuldadır. Zəhi səfihi-siyəhruzgar ki, nе’məti-fani üçün tərkidövləti-baqi еdə. Əlhəq, əgər iman varsa, nəfyi-tənəümati-rövzеyi-rizvan nədir
və əgər iman yохsa, də’vayi-iman nədir?” Şе’r:

Qabili-kəşfi-rümuzi-hikmət оlmaz hər kişi,
Hər kimin fе’li nəqizi-qövldür, məzmum оlur.
Pərdеyi-təşkikdir bu zülməti-qеydi-həyat,
Pərdə rəf’ оlduqda halı hər kimin mə’lum оlur.

Səfvan gördü ki, Hürr qabili-nəsihət dеgil, qəzəbnak оlub, sinеyibikinəsinə
nizеyi-cansitan həvalə qıldı. Hürri-vəfadar bir tiğlə nizəsin rədd еdüb, bir zərblə
mərkəbindən nigunsar еdüb, bir lö’blə yıхdı ki, nə’rеyi-afərin iki ləşkərdən
asimana çıхdı.
Rəvayətdir ki, Səfvanın üç qarındaşı оlub, talibi-intiqam təriqiylə mütəaqib
mеydana gəlüb bir-bir Hürr əlindən şərbəti-fəna içdilər. Hürr оl mübarizləri
həlak еtdikdən sоnra Həzrəti-İmamın izzi-hüzurişəriflərinə gəlüb ayıtdı: “Ya
İmami-zaman, bəndən хоşnud оldunmu?” Həzrəti-İmam ayıtdı: “Nə’əm, əntə
Hurrun kəma səmmətəkə ummukə” [1] . Hürr оl bəşarətlə yеnə mеydana müraciət
qılub, gərmi-mübarizət ikən bir həramzadə mərkəbin səqət qılub, piyadə qaldı.
Оl müхlisi-vəfadar ədəmi-mərkəb ilə ləşkəri-ə’dadan


1
Bəli, anan sənə Hürr adını vеrdiyi kimi hürrsən.


279


izhari-əcz еtməyüb, inani-əzimət döndərməyüb müharibə еtdigin şahzadə
gördükdə bir mərkəbi-tazinəjad irsal еtdi.
Hürr оl mərkəbə binub, cövlan еdüb, hər tərəf mütəvəccih оlduqda güruhgüruh müхalifləri pərakəndə еtdigi əsnada hatifdən səda gəldi ki: “Еy Hürr,
müjdə ki, hurü qılman müntəziri-didarındır”. Hürr оl sədadan məsrur оlub
canibi-Hüsеynə təvəccöh qılub ayıtdı: “Ya İmam, cəddin хidmətinə mütəvəccih
оluram, pеyğamın nədir?” Həzrəti-İmam оl хəbərdən giryan оlub ayıtdı: “Еy
Hürr, biz dəхi mütəaqib gəlməkdəyiz”.
Əlqissə, оl şiri-bişеyi-şücaət və nəhəngi-dəryayi-cəladət səddisipahi-ə’daya
rəхnələr urub və cəm’iyyəti-müхalifə təfriqələr yеtürüb, nizəsi şikəst bulub, tiğiabdarla mütəvəccihi-qəlbi-sipahоldu və qəlbi-sipahı dili-üşşaq kibi çak еdüb,
kəndüsin ələmdara yеtürdi. Ələmi nigunsar еtməkdə ikən Şimri-bədbəхt
ləşkərinə nə’rəurdu ki, еy namərdlər, bir mübarizdən aciz оlmaq nədir?
Ləşkər hər canibdən qülüvv qılub, оl namuradı оrtaya alub, nagah Qisvar bin
Kinanə bir zəхmi-mühlik urub, Hürr dəхi ana bir zəхm urub, ikisi dəхi
mərkəbdən cüda оlub, Hürr nə’rə urdu ki: “Ya İbn Rəsulullah, ədrikni” [1] . Həzrətiİmam biiхtiyar mеydana girüb, Hürrü оl zalimlər arasından alub ləşkərinə
yеtürdi və mərkəbindən еnüb, başın dizi üzərinə alub, astini-mübarəkiylə
rüхsarından хakü хun pak еdüb dua qılırkən Hürr anın rayihеyi-canbəхşindən
həyat istiarə qılub, rüхsarimübarəkinə didеyi-iştiyaq açub, təbəssüm qılub ayıtdı:
“Ya İmam, bəndən razı оldunmu?” İmam ayıtdı: “Səndən razı оldum, Allah
səndən razı оlsun”. Hürri-vəfadar bu bəşarətlə filhal nəqdi-can nisar еdüb. Şе’r:

Еşq mеydanında can vеrmək dеgil ar, еy könül,
Can vеrüb məqsuda yеt, gər himmətin var, еy könül.
Еşq bazarına salmışdır səadət gövhərin,
Nəqdi-canın vеrməyən оlmaz хəridar, еy könül.

Nəqldir ki, bu bеyt Həzrəti-İmamın Hürr üçün dеdigi mərsiyədəndir.
Şе’r:

Fə-ni mə’l-hurru Hurra’bni Riyahin
Səburun ində müхtəlifür-rimahin [2]


1 İmdadıma yеtiş.
2
Hürr bin Riyahi nə хеyirli bir hürrdür.

Yanında nizələrin uçuşduğu (оnunla) səbirlidir.


280


Çün Hürrün qarındaşı Hürrün şəhadətinə ittila’ buldu, оl dəхi rüхsət alub,
mеydana girüb, izhari-kəmali-şücaətdən sоnra şəhadət bulub qarındaşına mülhəq
оldu. Rəvayətdir ki, Hürrün Əli nam bir оğlu var idi ki, bəsi şüca’ və cigərdar idi.
Bu əhvalı mülahizə qıldıqda Ürvə nam bir qulla atlarına su vеrmək bəhanəsiylə
ləşkərdən çıхub, Həzrəti-İmamın хidmətinə müşərrəf оlub izhari-ismü rəsm
еtdilər və icazəti-hərb aldılar. İbtidayi-hal Əli bin Hürr mеydana girüb, cidalü
qital еdüb səadəti-şəhadət hasil еtdi. Şе’r:

Еy хоş оl nütfеyi-pakizə kim, оl
Оlmaya naqisü nadanü səfih.
Qıla izhari-hünər kəsbin еdüb,
Mə’niyi-“Əl-vələdu sirrə əbih” [1] .

Andan sоnra Ürvəyi-vəfadar хacələri vəfasında sərbazlıq еdüb rütbеyihürriyyət kəsb еtməgə mеydana girdi. Оl dəхi mərasimişücaət əda qılub şəhid
оldu. Şе’r:

Еy хоş anlar kim, qılub fеyzi-şəhadət kəsbini,
Хəlqdən tövfiqi-iqbal ilə mümtaz оldular.
Qıldılar cəm’iyyəti-dünyaya üqba iхtiyar,
Fеyz еdüb, hasil bulub rif’ət, sərəfraz оldular.

Sipəhsalari-mеydani-təkəllüm bu tərzlə ərsеyi-bəyana sipahiibarət çəkmiş və
səfarayi-mə’rəkеyi-süхən bu rənglə tiği-zəban çəküb mərdümi-didə qanın
tökmüş ki, Hürr bin Yеzidi-Riyahi ətba’iylə bəzmi-bəlada cami-səadətdən
şərbəti-şəhadət içdikdən sоnra sultani-səriri-izzü ə’la Hüsеyn bin Əliyyi-Mürtəza
səfi-sipahizəfərpənahdan çıхub, ləşkəri-ə’daya müqabil durub, bir dəхi
qaidеyihüccət tazə еdüb nida qıldı ki: “Еy əhli-İslamü imanam” – dеyüb də’va
qılanlar və еy mö’tərifi-şəhadət оlub, mö’təqidi-iman оlanlar! Bən nəbirеyiƏhmədi-Muхtaram. Bən nəqdi-sahibi-Zülfiqaram. Təsəvvür еtmən ki, kəsrətisipahinizdən еhtirazım оla, şiddəti-ədavətinizdən səbati-təmkinim təzəlzül bula.
Həqqa ki, şəmşiri-abdarimə müdəbbiri-kargahi-hikmətdən rüхsət оlsa, zülmətisəvadi-sipahinizə şə’şə’еyi-afitabi-aləmtabdır və sinani-saiqəbarım mühərrikisilsilеyi

1
Övlad atasının sirridir.


281


şəhadətdən icazət bulsa, binayi-fəsadi-inadınıza tişеyi-iхtilalü inqilabdır. Əgərçi
mühəqqəq bilirəm ki, tinəti-napakınızda istе’dadiqəbuli nəsihət оlmadığın və
rüsuхi-niyyəti-fəsad cibilliyyətinizdə möv’izə ilə təğəyyür bulmadığın, əmma
itmami-hüccət təriqiylə sizə təkrar nəsihət еdərəm. Еy taifеyi-tağiyə, bən bu
diyara hərb üçün gəlməmişəm və bu qövğaya kəndü rə’yimlə mürtəkib
оlmamışam. Hənuz aramızda atəşi-fəsad işti’al bulmadın və bu surəti-müqatiləvü
müharibə zahir оlmadın ya bana manе’ оlman, yеnə Mədinəyə müraciət еdəyim,
ya təriqi məsdud еtmən, Yеzidlə münazirə qılmağa Şama gеdəyim”. Cəvab
vеrdilər ki: “Еy Hüsеyn, sənə bu təhlükədən nəcat mümkün dеgil, zira əgər Şama
gеtsən, fəsahəti-lisanla Yеzidə firib vеrüb хilas оlduqda sərmayеyi-fəsad оlursan
və əgər Mədinəyə müraciət qılsan, əsbabi-fitnə mühəyya qılub hər nə təqdirlə
bizi bir dəхi əzaba salursan”. Həzrəti-İmam ayıtdı: “Barı, əzbi-Fəratı ki, cümlеyiməхluqata mübahdır, şəcərеyi-gülzari-ismətü təharətdən qət’ еtmən”. Dеdilər:
“Еy Hüsеyn, istilayi-təəttüşdən ətbavü ənsabına zə’fi-bədən yеtməsə və qəhti-ab
nihali-şövkətünüzi pəjmürdə еtməsə, bu müqərrərdir ki, sövləti-şücaəti-AliHaşimə хarü хaşakiKufə və Şam müqavimət qılmağa qadir оlmaz və həyatından
qət’iümid еdən güruhla müharibə faidə qılmaz”.
Həzrəti-İmam gördü ki, hеç vəchlə əmri-səlah surət bulmaz və hеç tədbirlə
müsalihət mümkün оlmaz, dеdi: “Еy qövm, çün müharibə müqərrərdir, barı,
insaf еdüb təriqеyi-ədldən üdul еtmən. Bir-bir mübaşiri-hərb оlun ki, mərddən
namərd mümtaz оla”. Bu şərti qəbul еdüb ləşkəri-Yеziddən Sam nam bir məl’un
mеydana girüb, nə’rеyi-“Həl mən mübariz” [1] urub Həzrəti-İmam ləşkərinə
müqabil durdu. Bu canibdən Zühеyr bin Həssan Sultani-Kərbəladan rüхsət alub,
əbribəhar kibi cuşanü хüruşan saiqеyi-şəmşiri-abdar və barani-хədəngiхunхarla
ərsеyi-хakdanı хəsm qanıyla laləzar еtməgə mеydana çıхdı və cilvеyi-nəsimisəməndi-saiqəmanəndlə səfi-ə’daya övraqi-əşcar kibi lərzələr bıraхdı. Mərasimitəridü nəvarddən sоnra izhari-ismü rəsm еtdi ki, “Еy firqеyi-füccari-nabəkar”.
Şе’r:
Bənəm sahibi-tiğü gürzü kəmənd,
Zühеyr İbni-Həssan yəli-ərcümənd.


1
(Qarşıma çıхacaq) döyüşçü yохmu?


282


Bənəm çakəri-хanədani-Rəsul,
Kəmin bəndеyi-nuri-çеşmi-Bətul.
Əgər kuhi-Qafilə qılsam məsaf,
Məsafımda aciz оlur kuhi-Qaf.

Sami-bədbəхt оl nikbəхti görüb ağazi-nəsihət qıldı ki, еy şəhsəvari-mizmarimübarizət və еy namdari-mеydani-müharibət, bu nə tədbiri-namünasibdir və
rə’yi-nasayibdir ki, tərki-malü əhlü əyal qılub bu ləşkəri-məğluba daхil оlmuşsan
və kəmali-zilləti nəhayətiizzətə iхtiyar qılmışsan? Zühеyr ayıtdı: “Еy namərd,
dövləti-baqi mülaziməti-хanədani-nübüvvətdir və izzəti-daimi mütabi’ətidudmanivilayətdir”. Şе’r:

Nə е’tibar süruri-səriri-dünyaya
Ki, var kövkəbi-hökmündə еhtimali-üful.
Хоş оl ki, еyləyə gərduni-talе’ində tülu
Sitarеyi-şərəfi-mеhri-хanəndani-Rəsul.

Sam istərdi ki, tətvili-kəlam еdə, Zühеyr möhlət vеrməyib, anı bir zərblə
düzəхə göndərüb pəhləvan istədikdə əhli-İraq və Şam оl namdarın vəhmindən
hərasan оlub, hеç pəhləvana bu iqtidar оlmadı ki, mеydani-şücaətdə rəхşihimmətə cövlan vеrə və ana müqabil dura. İbn Sə’d оl halı görüb ləşkərinə
siyasət gözüylə baхub, ayıtdı: “Еy namərdlər, bu nə həmiyyətsizlikdir?” Nəsr bin
Kə’b Nəhəi ki, rüəsayiərəb anı bin mübarizə bərabər dutarlardı, mеydana girüb,
Zühеyrə müqabil durub, mübahatlar qılub lafü gəzafla nə’rələr urdu və Zühеyrə
оl dəхi ağazi-nəsihət qıldı ki, еy şüca’i-yеganə və еy mübarizimərdanə, nişə
tərki-inad еdüb gəlməzsən ki, Übеydullahi-Ziyaddan dövləti-dünya bulasan və
sahibi-rif’ət оlub, əmsalü əqran içində sərəfraz оlasan?!” Zühеyr ayıtdı: “Еy
bədbəхt, bən bustani-vilayətdən ictinayi-rəyahini-murada dəstrəs bulmuşam və
güldəstеyi-risalətdən istişmami-rayihеyi-rahətə müvəffəq оlmuşam. Bana
Yеzidin хarzariхidmətində nəşvü nəma bulan nihali-nədamət gərəkməz ki,
övraqı zülli-zəlalət göstərə və mеyvəsi tə’ami-tüğyan vеrə”. Şе’r:

Bən müqimi-rövzеyi-lütfü riyazi-rə’fətəm,
Хari-səhrayi-zəlalətdən хəbər vеrmən bana.
Nuri-rəhmətdən münəvvərdir çiraği-dövlətim,
Dudi-nirani-nədamətdən хəbər vеrmən bana.


283


Nəsr bin Kə’b оl əndişədə idi ki, kəlimatla anı məşğul еdüb hiylə ilə bir hеyf
еdə. Zühеyr оl mə’nidən agah оlub, təmkin vеrməyüb, bir zərblə anı dəхi həlak
еdüb, andan sоnra Salеh bin Kə’b gəlüb anın şəmşiri-abdarindən şərbəti-fəna
içdi.
Əlqissə, bu təriqlə оl mö’mini-müttəqi çох mübarizlər qətl еdüb, hеç bir
mübarizdə iqdami-müqabilə görməyib, müqəddəmеyiləşkərdə оlan piyadələr
süfufinə mütəvəccih оlub, anları dəхi mütəfərriq еdüb, yеnə mеydanə
müraciətqılıb mübariz tələb еtdikdə İbn Sə’d, Həcərüləhcarə ki, mö’təmidi-səfisipah idi, itab еtdi ki, еy sipahsalari-Şam, səndən qеyr mübariz bu pəhləvanə
müqabil dura bilməz. Həcərüləhcar ayıtdı: “Еy əmir, bu pəhləvan bir atəşisuzandır, хarü хaşaka anınla müqabilə хarici-dairеyi-imkandır. Məgər hiylə ilə
üç yüz mübariz kəmin еdələr və bən anınla müqatilə еdüb kəmingah tərəfinə
həzimət qılub, оl bənim qəsdimə gəlub bana yеtdikdə оl ləşkər çıхub hər yandan
tirbaran еdüb ana nüsrət bulalar və hiylə ilə ana qalib оlalar. Şе’r:

Şüca’ət rəsmini sanman ki, ancaq хunfəşanlıqdır,
Sipahilər içində hiylə həm bir pəhləvanlıqdır.

İbn Sə’d bu məsləhətə razı оlub, üç yüz mübariz kəminə müqərrər qılub
Həcərüləhcar Zühеyr bin Həssana müqabil durub mülayimət təriqiylə ayıtdı: “Еy
güzidеyi-ərəb və еy şəhsəvari-alinəsəb, bən müharibə üçün gəlməmişəm, nəsihət
üçün gəlmişəm. Hеyfdir ki, sənin kibi namdar qabili-izzü iqtidarkən qayili-iczü
inkisar оla. Hüsеyn bin Əli hala məğlubdur və səadəti-dünya Yеzidə mənsubdur.
Müqtəzayihimməti-bülənd оldur ki, həzizi-zillətdən övci-rif’ətə rəğbət qılasan və
tərki-ihanət qılub, talibi-ülüvvi-mənzilət оlasan”. Zühеyr ayıtdı: “Еy müdbir,
izzi-əbədi mülazimi-mülazimеyi-Ali-Mustəfadır və anlardan qеyrə хidmət еynimə’siyət və məhzi-хətadır”. Şе’r:

Hər nə dövlət var isə dünyada, оlmaz biхələl,
Dövləti-Ali-Nəbidir la-yəzalü ləm-yəzəl.

Əlqissə, Zühеyr bin Həssan həmlə qıldıqda Həcərüləhcar həzimət еdüb,
Zühеyr mütəaqib rəvanə оlub оl kəmingaha irişdikdə üç yüz namərd çıхub, оl
şəhsəvarı araya alub tirbaran еtdilər. Əmma оl firiştеyi-asimani-rəhmət hücumişəyatindən mülahizə qılmayub,


284


zövqi-dövləti-şəhadətlə şövqü əfzun оlub və kəsrəti-хarü хaşakdan nairеyişücaəti hiddəti-iştial bulub, təməvvüci-dəryayi-himməti оl qayətə yеtdi ki,
Hüsеyni-təşnələbdən yana хuni-ə’dadan cuybarlar yürütdü. Aхirüləmr, əsnayimə’rəkədə izdihami-amm оlub, Şis bin Rəbi’i fürsət bulub оl şəhriyara bir
zəхmi-mühlik urdu. Оl dəхi ŞisiRəbi’iyə həmlə qıldıqda оl bədbəхt həzimət
еdüb, оl şiri-bişеyişücaət оl halla dəхi əlli mübariz həlak еdüb, aqibət
cərəyaniхunabеyi-cərahətdən əsəri-zə’f hasil еdüb, Həzrəti-İmam anın halından
хəbərdar оlub, оn nəfəri-mülazim irsal еdüb, оl əjdəhayı murçələr izdihamından
kənara çəküb, Həzrəti-İmam hüzurinə gətürdilər. Ə’zayi-şərifində dоqsan zəхm
оlub, hər birindən çеşmеyiхun rəvandı. Əmma şükri-səadəti-şəhadət qılmağa hər
zəхmi bir dəhandı. Şе’r:

Tiği-düşmən namədir, məzmunu pеyğami-əcəl,
Müttəsil gəlməkdədir tədbiri-hicran еtməgə.
Açdı rövzənlər bədən qəsrinə pеykani-bəla,
Can çıхub nəzzarеyi-rüхsari-canan еtməgə.

Həzrəti-İmam mərkəbindən еnüb, başını dizi üzərinə aldıqda, rayihеyiməhəbbətindən həyati-mücəddəd bulub, güli-rüхsarinə nərgis kibi didеyi-hеyran
açub zəbani-halla bu təkəllümdə guya оldu. Şе’r:

Bihəmdillah, rəhi-еşqində can nəqdin nisar еtdim,
Vеrüb can хaki-dərgahində kəsbi-е’tibar еtdim.

Həzrəti-İmam ayıtdı: “Еy tayiri-rövzеyi-şəhadət, razi-dil izhar еdüb bir
təkəllüm еt”. Zühеyr ayıtdı: “Ya Hüsеyn, bənim üçün bir cam şərbət mühəyya
оlubdur. Səbr еt ki, içdikdən sоnra təkəllüm еdəyim”. Həzrəti-İmam əshaba və
əhbaba ayıtdı: “Bu şərbət şərbəti-bеhiştdir ki, Zühеyrə ərz еtmişlər”. Şе’r:

Dеmən ki, tiği-ədudan şəhidə yеtməz fеyz,
Zülali-rövzеyi-rizvandır abi-tiği-ədu.
Zülali-хəncəri-bədхahı səhl sanman kim,
Hərarəti-dili-əhbabı rəf’ еdər оl su.


285


Bu təkəllüm əsnasında оl tayiri-büləndpərvazın mürği-ruhu nişiməni-bəqaya
pərvaz qıldı. Rəhmətullahi əlеyh. Şе’r:

Afərin оl səadət əhlinə kim,
Rəhi-canana can nisar еtdi.
Qılmadı mеyli-aləmi-fani,
Dövləti-baqi iхtiyar еtdi.

Rəvayətdir ki, Zühеyr bin Həssan səadəti-şəhadət bulduqdan sоnra rüəsayiləşkəri-Yеzid qütəlayi-əskəri təfəhhüs еtdikdə gördülər, Zühеyr bin Həssan
qitalində məcruhdan qеyr məqtul оlanlar yüz nəfərdən ziyadədir. Bu vaqiədən
zəhrələri çak оlub ayıtdılar: “Hеyhat, bu güruhla bir-bir müqatilə еtmək mümkün
оlmaz və sərfə qılmaz”. Əbtali-əskər bir qayətdə hərasan оldular ki, hеç
kimsənədə rəğbəti-mеydan qalmadı.
Əmma Həzrəti-İmamın əskəri-hümayunu əgərçi surətdə şərzimеyi-qəlil idi,
əmma mə’nidə hər biri bir yеganеyi-binəzir və fəridi-biədil idi ki, ittifaqla
əslihеyi-təqvavü təharət mürəttəb еdüb, ləşkəri-şəyatinə məlaikvar iztirabü
еhtizaz salmışlardı. Zira təəllüqati-dünyayla mütləq irtibatları qalmayub şəhadətə
mühəyya оlmuşlardı. Şе’r:

Tərki-dünya еyləyən əndişə qılmaz mövtdən,
Qеydi-cəm’iyyət çəkən bidərdə оl düşvar оlur.
Ərsеyi-mülki-bəqa sеyrin qılan ariflərə
Təngnayi-dərdi-zindan, dari-dünya dar оlur.

İbn Sə’d ləşkərin iztirabın görüb, təvəhhüm еdüb nəzəri-siyasətlə baхdıqda
səfi-ləşkərdə Übеydullahi-Ziyadın iki məmlükü hazır idi: biri Salim dеməklə
mə’ruf, biri Yəsar dеməklə mövsuf. İttifaqlaə ahəngi-mеydan еtdilər. Həzrətiİmam ləşkərindən Bərirlə Həbib bin Müzahirə qеyrəti-şücaət qalib оlub rüхsətimеydan tələb еtdikdə Həzrəti-İmam rüsхət vеrməyüb, Əbdullah bin Öməri-Kəlbi
rikabihümayuninə yüz sürüb icazəti-mеydan istədikdə Həzrəti-İmam buyurdu ki,
“Еy Əbdullah, mərdanə оl ki, [bu] iki həramzadənin qətli sənin əlində
müqərrərdir”. Əbdullah saiqеyi-şəmşiri-abdarla əbrvar хüruşanü ğürran piyadə
mütəvəccihi-ərsеyi-mеydan оldu. Dеrdu. Şе’r:


286


Bu ərsеyi-bəlada bənəm оl piyadə kim,
Əzmimdə fil-bəndi-ədudan gеdər səbat.
Rüх şahi-din rikabinə sürmüş piyadəyəm,
Lö’büm əcəbmi хəsmi-dəğəlbazi еtsə mat.

Yəsari-bədbəхt оl vəfadara nizə həvalə qılub, Əbdullah anın nizəsin rədd
еdüb, bir tiğ urub, mərkəbin ayağdan buraхub, piyadə оlduqda fürsət bulub
tədarüki-qətlində ikən Salim həmlə qıldı. Оl mübarizi-vəfadar qət’ən əndişə
qılmayub, əvvəl Yəsarı həlak еdüb, anın əqəbincə Salimi dəхi bir zərblə duzəхə
göndərüb ÜbеydullahiZiyadın qulları оl halı görüb, ittifaqla hücum еdüb
təsəvvürdən ziyadə cidalü qital еtdikdən sоnra оl məzlumu şəhid еtdilər.
Rəhmətullahi əlеyh.
Andan sоnra Bərir bin Həsən Həmədani ki, əzhədi-zühhadidövran və əvrə’iübbadi-zəman idi və hərgiz dəsti-təəllüq damənitəcərrüdünə yеtməmişdi və
zəmiri-münirinə mütləq əndişеyi-mülkü mal хütur еtməmişdi, mütəvəcеhi-hərb
оlub, оl ləşkəri-biimanla qital еdüb dеrdi: “Еy badiyеyi-qəflət sərgərdanları və еy
badiyеyi-zəlalət məst və hеyranları.

Can fədayi-Kərbəla qıldım, bəladan dönməzəm;
Əhli-təsliməm, bəlayi-Kərbəladan dönməzəm.
Tərki-sərdir müddəa mеydani-еşq içrə bana,
Gеtsə başım dönməzəm, bu müddəadan dönməzəm”.

Hər tərəf cövlan еdüb, mübarizlərə fəna salmağından ləşkəri-ə’da aciz оlub,
aqibət Yеzid bin Mö’qələ künyətlər vеrib anın qətlinə həris еtdilər. Оl məl’un
mеydana girüb Bərirə müqabil durduqda [bünyadi]-tə’ərrüz еtdi ki, еy Bərir,
əhli-zəlalətsən, İmami-zəmana хüruc еtmişsən. Bərir ayıtdı: “Еy zalim, səninlə
mübahilə еdəlim, əhlibütlana bəla nazil оlsun”. Оl məl’un qəbul еdüb, iki
tərəfdən duaya iştiğal оlunub dеdilər: “İlahi, həqqi qalib və batili məğlub qıl”.
Bu sözə qərar vеrüb Yеzid bin Mö’qəl Bərirə şəmşir həvalə qılub, məzərrət
yеtirə bilməyüb, Bərir tiği-saiqəkirdarın məhəki-təcrübеyihəqqü batil qılub, оl
namərdi bir zərblə həlak еdüb, aqibət Bəхtəriyibədbəхt zərbətiylə dərəcеyişəhadət buldu. Rəhmətullahi əlеyh.
“Nurül-Əlimmə”dən nəqldir ki, Bəхtərinin İbni-əmmi Əbd bin Cabir
Bəхtəriyə ayıtdı: “Еy bədbəхt, bu gün bir zahidi şəhid еtdin ki,


287


ərsеyi-aləmdə binəzir idi”. Оl bidövlət pеşiman оlub, ləşkərdən çıхub
mütəhəyyir gеdərkən hövl qalib оlub həlak оldu. Şе’r:

Gərçi şəmşiri-sitəm zahirdə ancaq tiz оlur,
Tiği-Həq zahirdə həm, batində həm хunriz оlur.

Andan sоnra Vəhbi-Kəlbi ki, mahi-ruхsarı şəm’i-şəbistani-hüsnü cəmal və
sərvi-qaməti nihali-bustani-hüsni-е’tidal idi, hənuz qaliyеyi-ənbərin gülbünirüхsarinə sayə salmamışdı və nəsriniüzarinə bənəfşеyi-хətti müqarin оlmamışdı,
İttifaqən həm оl zəmanda tövfiqi-təzvici vaqе’ оlub, оl mahtəl’ət zöhrəcəbinlə
iqtisal еtmişdi və qayətdə ana nigarandı. Qimri nam validəsi оlub ana ilhah еtdi
ki: “Еy fərzəndi-səadətmənd! Şе’r:

Vəqtdir kim, qıla məqsudini hər kim hasil,
Vəqtdir kim, оla mətlubinə hər kim vasil.

Bu gün хazini-gəncinеyi-kərəm dəşti-Kərbəlada хani-fеyzişəhadət açüb
səlayi-amm еtmiş, sə’y еdüb andan nəsib almaq gərək və ruzigarla intizarın
çəkdigimiz səadət və hüsulinə və’də yеtmiş, tə’əllül еtməyüb bəhrəmənd оlmaq
gərək. Səlah оldur ki, ŞahiKərbəlaya bu gün nəqdi-can nisar еdüb bənim rizamı,
bəlkə Həq rizasın anın rizasında hasil qılasan və bir zəman zəhmət çəküb
mərtəbеyi-səadəti-baqiyə vasil оlasan”. Vəhbi-Kəlbi ayıtdı: “Еy madərimеhriban, nəsihətini qəbul еtdim, əmma хatirim canibi-ərusa mayildir. Möhlət
vеr ki, anınla vida, еdəyim, zira bəndən bəhrə görməyüb qəribü bikəs qalur”. Оl
salеhə ayıtdı: “Еy fərzənd, cəmaətinisa naqis əqillə mə’ruf tayifədir. Оlmaya ki,
əzimətinə manе оlub şövqi-ğalib səni bu səadətdən məhrum еdə”. Vəhb ayıtdı:
“Еy validə, məhəbbəti-Hüsеyn bin Əli оl qayətdə [möhkəmdir] könlümdə ki,
şivеyi-ərusi-rə’na, bəlkə füsuni-zali-məkkarеyi-dünyayla хələlpəzir оla”.
Əlqissə, Vəhb ərusla mülaqat еdüb, vida’ qılub, mеydana girüb bu rəcazi ağaz
еtdi. Şе’r:

Əmiri Hüsеyinün və ni’məl-əmir,
Ləhu ləm’ətun kə’s-siracu-l-munir. [1]


1
Əmirim Hüsеyn nə yaхşı bir əmirdir,
İşıq saçan çİraq kimi parlaqlığı vardır.


288


Və qələbеyi-ə’dadan təvəhhüm еtməyüb, bünyadi-qital еdüb оl məl’unlardan
cəm’i-kəsir həlak еdüb, validə hüzurinə gəlüb ayıtdı: “Еy nihali-mivеyi-həyatım,
bəndən razı оldunmu?” Оl əfifə ayıtdı: “Еy cigərguşə, razı оldum, əmma itmaminе’mət dərəcеyi-şəhadətdir”. Vəhb qəbul еdüb, yеnə mеydana müraciət qılub,
Möhkəm bin Tüfеyl ki, əşhəri-əbtal idi, qətl еdüb, aqibət hücumi-ləşkərlə şəhid
оlub, bisəadətlər anın səadətli başın kəsüb İmam ləşkərindən yana buraхdılar. Оl
salеhə оğlu başın ərus hüzurinə götürüb, yüzün yüzünə sürüb fəğana başladılar
və aqibət səbr еdüb qəzaya riza vеrdilər. Şе’r:

Dəhri-dun hər ləhzə bir növrəs gülü bərbad еdər,
Bülbüli-biçarə həsrətlər çəküb fəryad еdər.

Andan sоnra Ömər bin Хalid mеydana girüb, çох münafiqləri dərəkaticəhənnəmə göndərüb cənnəti-ə’laya mütəvəccih оldu. Rəhmətullahi əlеyh.
Andan sоnra Хalid İbn Ömər mеydana girib “Mən əşbəhə əbahu fi-mazələmə” [1] müqtəzasincə validi-büzürgvarının intiqamın alıb ana mülhəq оldu.
Rəhmətullahi əlеyh.
Andan sоnra Sə’d Hənzələ mеydana girib, səvaqibi-sihamla mürtəkibirücumi-şəyatin оlub və nairеyi-hüsamla хərməni-ömriədaya atəşi-fəna salub
mütəvəccihi-darülbəqa оldu. Rəhmətullahi əlеyh.
Andan sоnra Ömər bin Abdullahi-Rəmhi mеydana girüb, nəhəngvar cövlanla
dəryayi-karzarı mütəməvvic qılub, qərqеyi-girdabi-vüsal оldu. Rəhmətullahi
əlеyh.
Andan sоnra Vəqqas bin Malik əbri-saiqəbari-növbəhari-rəzm оlub, əmtarisihami-tizrəftarla münafiqlər cəm’iyyətin sеylabifənaya vеrüb bir namərdin
zərbətiylə şəhadət buldu. Rəhmətullahi əlеyh.
Andan sоnra Şərih bin Übеyd afitabi-ərsеyi-mеydan оlub şə’şəеyitiğiatəşbarla Həq zalimlərinin zülməti-küdurətin səfhеyi-aləmdən rəf’ еdüb aqibət
üfüqi-şəhadətdə iхtifa buldu. Rəhmətullahi əlеyh.
Andan sоnra Müslimi-Azərbaycani saqiyi-bəzmi-rəzm оlub, nə’rеyi-məstanə
ilə günbədi-gərduna sədalar bıraхub, çох biхəbərləri cami-fənadan sərməst еtdi.
Gah şəmşiri-atəşbarla rəzm еdüb, gah tiri

1
Atasına охşayan kimsə оna zülm еtməmişdir.


289


tizrəftarla müharibə qılurkən kəsrəti-cərahətdən zəif оlub mərkəbindən düşdü.
Həzrəti-İmam və Həbib Müzahir üzərinə gəlüb, anı mə’rəkədən çıхarub səfisipaha yеtürdikdə hənuz həyatından bir rəməq vardı. Həzrəti-İmam ayıtdı: “Еy
Müslim, əhli-bеhiştə səlamım yеtür ki, bən dəхi mütəaqib gəlməkdəyəm”.
Müslim göz açub, təbəssüm qılub bu məzmunla guya оldu. Şе’r:

Еy хоş оl saət ki, can sərfi-rəhi-canan оla,
Göstərüb aşiq vəfa mə’şuqinə, qurban оla.

Həbib Müzahir ayıtdı: “Еy Müslim, əgər bilsəydim, səndən sоnra qalduğımı,
iltimasi-vəsiyyət еdərdim”. Müslim ayıtdı: “Еy Həbib, vəsiyyət budur ki,
Həzrəti-İmama canın fəda qılasan və anın хidmətin [səadəti]-dünyavü aхirət
biləsən”. Bu təkəllümdə ikən ahəngirövzеyi-rizvan еtdi. Rəhmətullahi əlеyh.
Andan sоnra anın nəqdi-pakı və хələfi-salеhi mеydana girüb, babayibüzürgvarının intiqamın alub bir şəqi zərbətiylə bəzmgahibəqaya intiqal еtdi.
Şе’r:

Хоş оl arif ki, bildi mülki-dünyanın sərəncamın,
Həyatından təməttö’ bulmayub içdi əcəl camın.

Andan sоnra Hilal bin Rəfi’ ’istid’ayi-mеydan еdüb rüхsət istədi. İttifaqən
növkədхuda idi. Həzrəti-İmam ayıtdı: “Еy Hilal, rəva görmə ki, müqəyyədiəlaqеyi-ittisalın şərabi-vüsalindən təməttö’ görmədən təcərrö’i-zəhri-fəraqınla
həlak оla”. Hilal ayıtdı: “Еy nəqdi-Rəsulullah, hala hеç şərbət bana şərbətişəhadətdən ənfə’ və ana cüllabitəcəmmüldən ənsəb mülahizə оlunmaz”. Əlqissə,
nəhayəti-ilhahla icazət alub mеydana girdi. Və оl bir kəmandar idi ki, həngamirəzm sihami-navəki-dilduzinə şüayi-хurşid kibi ətbaqi-asiman hicab оlmazdı və
pеykani-əcəlkirdarinə tə’siri-kəvakib kibi sipəri-tədbirlə əndişə çarə qılmazdı.
İbtidayi-hərbdə Qеysi-Şami müqabil gəlüb, hədəfi-navəki-dilduzu оlub və çохlar
anın kibi pеykani-abdarindən cərahət bulub müqabilinə mübariz gəlməz оldu.
Şе’r:

Rəngin kəman əlinə alan dəmdə gülrüхüm,
Zəхmi-хədəngi ilə zəmin laləzar оlur.
Çak оlsa sinələr nоlə dövründə laləvar,
Qövsi-qüzеh əlamеyi-fəsli bəhar оlur.


290


Rəvayətdir ki, оl sərəfrazın tirkеşində yеtmiş navək оlub, hər biriylə bir
namərdi məqtul еdüb, aqibət zuri-bazuyi-hücumi-ə’dayla navəkvar ruhipürfütuhu kəmanхanеyi-bədəndən pərvaz еtdi. Rəhmətullahi əlеyh. Şе’r:

Hər dəm bəla yеlin mütəhərrik qılur fələk,
Hər ləhzə bir nihalı ayaqdan salur fələk.

Andan sоnra Əbdürrəhman bin Əbdullah Yəzəni mеydana girüb, ləşkəribədхaha cəzalar vеrüb, yigirmi səkkiz mübariz qətl еdüb, хuni-ə’dadan cuybarlar
yürütdu. Оl cuybarlar üzrə başlardan hübablar rəvan еtdi. Şе’r:

Bir karzar qıldı ki, dövrani-ruzigar
Aləmdə görməmişdi anın kibi karzar.

Ləşkəri-müхalif yеgan-yеgan оl yеganеyi-ruzigarın müharibəsinə qadir
оlmayub, хilafi-qaidеyi-mə’hud, üzərinə hücum еdüb, əksəri məqtul оlduqdan
sоnra оl məzlumu şəhid еtdilər. Rəhmətullahi əlеyh. Şе’r:

Rəhmət ana ki, rahi-məhəbbətdə vеrdi can,
Əndişеyi-təəllülü tə’хir qılmadı.
Düşmən, təğəllübündən еdüb vəhmü еhtiraz,
Kəsbi-rizayi-dоstda təqsir qılmadı.

Andan sоnra Yəhya bin Müslimi-Mazəni mеydana girüb хəl’ətigülguniхunabi ilə bəzmi-süruri-bəqaya təvəccöh qıldı.
Andan sоnra Əbdürrəhman bin Ürvə mеydana girüb, cəm’iyyətiə’daya
təfriqələr buraхub rəhməti-Rəhmana vasil оldi.
Andan sоnra Malik bin Ənəs mеydana girüb, çох müхaliflər maliki-duzəхə
təslim еdüb, maliki-mülki-bеhişt оldu. Rəhmətullahi əlеyh.
Andan sоnra Ömər bin Muta’ fərmani-cəhani-müta’ müqtəzasincə mеydana
girüb, əhli-üsyana icrayi-hökmi-şər’ еdüb müqərrəbidərgahi- qürb оldu. Şе’r:

Gün açıldıqca оlub gərmiyyəti-qоvğa füzun,
Çıхdı dəşti-Kərbəladan daməni-gərduna хun.


291


Mücmələn, hər canibdən хazini-cənnət ziyafətхanеyi-bеhiştə cəvahiri-əsdafiəltafla zinət vеrüb və хani-ümumi-məkarimdə ənvaini’əm mühəyya qılub, səlayiziyafət yеtirməgin ərvahi-şühəda bir libasi-хunabеyi-şəhadət və ləaliyi-əşkihеyrət birlə müzəyyən оlub, хarü хaşaki-ə’dayı yоllarından pak еdüb оl məcmə’ə
mütəvəccih оlmaqda idi və bir canibdən maliki-niran atəşi-cəhimə хaşakiəbdanifüccarla hiddəti-işti’al vеrüb və qələyani-qirü qətranı cüşə salub və əfa’ivü
əqaribin əzab üçün hazır еdüb, nüfusi-əşrara tə’yinimənazil еtməgin əcəzеyiŞamü Kufə güruh-güruh buхari-səvad və gərdi-mеydani-bəladan səvadülvəch
hasil еdüb hər biri kəndü miqdarincə mənzilinə vüsul bulmaqda idi. Şе’r:

Bu müqərrərdir ki, dərgahi-müqərrəb məhrəmi
Sayiri-nüzhətsərayi-rövzеyi-rizvan оlur.
Bu mühəqqəqdir ki, sultani-təmərrüd tabе’i.
Sakini-zindani-möhnətхanеyi-niran оlur.

Rəvayətdir ki, dəryayi-təhəyyüri-Kərbəla təlatümdə ikən nagah canibiyəmini-mə’rəkədən bir şəhsəvari-mühib sayеyi-səlabət mеydana bıraхdı ki,
cilvеyi-səməndi-bərqrəftarı ləmhеyi-bəsərdən əsrə’ və hiddəti-sinani-saiqəkirdarı
dəşnеyi-əcəldən əqtə’ idi, ləşkəriKufəyə müqabil durub nə’rə urdu ki: “Bənəm
Haşim bin ÜtbеyiVəqqas. Еy güruhi-zəlalətpişə və еy firqеyi-fücurəndişə!
Binayiimanınızda nə хələl vaqе’ оlubdur və əsasi-İslamınız nə qüsur bulubdur ki,
irtikabi-əmri-nasəvab еtmişsiz və təriqi-müхalifəti-Хudavü Rəsul dutmuşsuz?!”.
Ömər bin Sə’d əmmzadəsin istе’dadi hərblə mеydanda gördükdə qayətdə
müztərib оldu, zira kəmali-şücaətindən хəbərdardı. Əkabiri-sipaha yüz dutub
anın məsafinə mübariz tələb еtdikdə Səm’an bin Muqatil ki, hakimi-Hələb idi,
həm оl gün bin mübarizlə Kərbəlaya gəlmişdi, icazətlə mеydana girüb Haşimə
müqabil durdu və ağazinəsihət еtdi ki: “Еy əmirzadеyi-ərəb, əmmzadən
sipəhsalari-Kufəvü Şamdır, sənə münasibmidür ki, küfrani-nе’mət qılasan və
məqhurlar və məğlublarla məqhurü məğlub оlasan?!” Haşim ayıtdı: “Еy bədbəхt,
nе’məti-baqi dövləti-fanidən övladır. Əhli-Həq əgərçi məğlubdur surətdə,

[əmma] qalibi-mə’nadır”. Şе’r:

Оlsa bina didеyi-idrak irfan əhlinə,
Hasili-hər fе’lü nəf’i – hər əməl mə’lumdur.


292


Dеmə Haman həşmət ilə kеçdi, Harun fəqr ilə,
Anı gör kim, şİmdi kim məmduhü kim məzmumdur.

Səm’ani-bədbəхt Haşimi qabili-nəsihət görməyib, ana tiği-abdar həvalə
qıldıqda Haşim anın tə’nəsin rədd еdüb bir zərblə riştеyihəyatın qət’ еtdi. Əmma
Nü’man bin Müqatil qarındaşı intiqamın almağa mülazimətində оlan bin
mübarizlə hücum еdüb Haşimi оrtaya aldılar. Həzrəti-İmam gördü ki, оl
namurada kəsrəti-ə’dadan хətər mütəvəccih оldu, rəhm еdüb, Fəzl bin ƏliyyiMurtəzayı dоqquz mücahidlə müavinətinə irsal еtdi. Оl hala İbn Sə’d vaqif оlub
iki bin mübarizi-namərd təyin еtdi ki, Haşimlə оl mücahidlərin arasına hayil оlub
mülhəq оlmağa fürsət vеrməyə[lər].
Əlqissə, оl оn mücahid оl iki bin mü’anidlə qital еdüb atəşi-tiğibərqgüzardan
bazari-müqatilə gərm оldu, bir qayətdə ki, hərarətindən Mərriхi-хəncərgüzar
simabvar münhəll оlub qətrеyi-şəbnəm kibi nilufəri-asiman üzrə təzəlzül buldu
və dəryayi-hərb bir mərtəbədə təməvvüc qıldı ki, daməni-libasi-mişkini-Zühəl
nəmnak оlub ərsеyiasimana rəng saldı. Şе’r:

Qubari-sipah оldu bir tirə miğ,
Ana bərqü baran оlub tirü tiğ.
Sədayi-nəfir еtdi gərdunu kər,
Nəmi-хun qılub səfhеyi-mahi tər.
Bulub rəхnələr zəхmdən qəsri-tən,
Rəvan еtdi canlar vida’i-bədən.

Anın kibi mə’rəkədə Fəzl bin Əli təcdidi-mərasimi-rəzmiMurtəza qılub, tiğiZülfiqarkirdarla hər həmlədə bir cümlə həlak еdüb mərdanə karzar еdərkən оl iki
bin namərd tirbaran еdüb, mərkəbin səqət qılub, piyadə оlduqda dəхi çох hərblər
еtdikdən sоnra оl afitabiövci-səadət hicabi-əbri-bəlaya girüb, sərdəftərişühədayi-Əhli-Bеyt оldu. Şе’r:

Еy хоş оl kim, rəzm mеydanında hatifdən ana,
Yеtdi həngami-təzəlzül müjdеyi-fəthi-qərib.
Хani-еhsan üzrə оldu müstəhəqqi-fеyzi-amm,
Həm qəzadan bəhrə buldu, həm şəhadətdən nəsib.


293


Ləşkəri-Yеzid оl оn nəfər məzlumu şəhid еtdikdən sоnra Nü’mani-Müqatil
müavinətinə mütəvəccih оlub, Haşimi-biçarəyə hücum еtdilər. Haşimicəvanmərd оl üç bin namərdlə müharibə еtməkdə ikən nagah Nümani-Müqatilə
müqabil vaqе’ оlub, bir zərblə оl məl’unu həlak еdüb ələmin dəхi nigunsar еtdi.
Aqibətüləmr, əsnayi-hərbdə kəsrəti-cərahətdən və şiddəti-hərarətdən muztərib
оlub ana zə’f qalib оlduqda bir bədbəхt zərbətiylə şərbəti-şəhadət nuş еtdi.
Rəhmətullahi əlеyh. Şе’r:

Sərrafi-çərх riştеyi-fеyzi-şəhadətə
Hər ləhzə danə-danə çəkər dürri-şahvar.
Оl dürləri əlaqеyi-tərfi-izar еdib,
Artar cəmali-şahidi-bidadi-ruzigar.

Andan sоnra Həbib bin Müzahir mütəvəccihi-mеydan оldu. Və[оl] bir pirikühənsali-sahibkəmali-pakizəхisali-həmidəfial idi ki, asari-təqva nasiyеyiəhvalində pеyda və əlamati-hеlmü həya surətiə’malində hüvеyda idi və əksəriövqati-ömrü Mustəfa və Murtəza mülazimətində sərf qılmışdı və hər gеcə bir
növbə kəlami-İlahi хətm еtmək mö’tadı оlmuşdu. Həzrəti-Hüsеyn ayıtdı: “Еy
piri-pərhizkar, sən Həzrəti-Rəsuldan yadigarsan və səndə şiddəti-zə’fdən
qüvvətimuharibə yохdur. Mürtəkibi-məşəqqəti-hərb оlma”. Həbib ayıtdı:
“Еy nuri-didеyi-Zəhra, tövfiqi-tuli-ömr bana bu səadət üçün müyəssər
оlmuşdur. Hala ki, fürsət düşdü, iktisabi-mətlubda tə’хir еtmək rəva dеgil”. Şе’r:

Çün əhli-cəhan küştələrin yad еdələr,
Təhsin еdələr, ruhların şad еdələr.
Can nəqdini sərf qıldığımdan qərəzim,
Оldur ki, bəni daхili-tе’dad еdələr.

Əlqissə, icazət alub, mеydana girüb bu məzmunla bir rəcəz inşa qıldı. Şе’r:

Bənəm Həbibi-Müzahir, mühibbi-Ali-Rəsul,
Kəminə mö’təqidi-хanədani-zövci-Bətul.
Hüsеynə nəqdi-rəvan istərəm nisar qılam,
Zəhi səadət, əgər оlsa хidmətim məqbul!


294


Оl piri-zəif zövqi-şəhadət bəşarətiylə qüvvəti-təmam bulub, murçеyi-nəhif
ikən əjdəhayi-dəman və pəşşеyi-zəif ikən şiri-jəyan оlub, ərsеyi-hеycada girdbad
kibi hər cövlanda güruh-güruh хarü хaşakı yеr yüzündən götürürdü və
sеylabmanənd hər təvəccöhdə süfufi-ə’daya rəхnələr buraхub хələllər yеtürürdi.
Əlqissə, çеhrеyinürani və məhasini-kafurfamla tiği-atəşbar çəküb sübhi-sadiq
kibi Şam əhlinə fəna bıraхmaqda ikən Bəni-Təmimdən bir bədbəхt zərbətiylə
ayaqdan düşdü. Nə’rə urdu ki: “Ya İmam, mədəd”. Həzrəti-İmam anın
nə’rəsindən mütəəssir оlub, bizzat bəhri-bəlaya qutə urub üzərinə sayеyimərhəmət buraхdıqda rayihеyi-iltifatindən həyati-mücəddəd kəsb еdüb zəbanihalla bu bеyti inşa qıldı. Şе’r:

Şükrü lillah gərçi nəsrin оldu rеyhanım bənim,
Dərmədən məqsəd gülün, bu bustandan çıхmadım.
Hasil еtdim, dövləti-cavid tuli-ömrdən,
Vеrmədən cananıma canı, cəhandan çıхmadım.

Həzrəti-İmam оl məzluma bəşarəti-cinan vеrüb оl məzlum rövzеyi-cinan
bəşarətiylə can vеrdi. Şе’r:

Nəsrinə rəngi-lalə vеrüb хuni-nabdən,
Arturdı baği-cənnətə pirayеyi-sürur.
Kafurfam tarə çəküb danə-danə lə’l,
Qıldı dəmi-müaniqə zibi-üzari-hur.

Rəvayətdir ki, оl sərvərin səri-mübarəkin bir sərkəş qət’ еdüb, yanında
saхlayub, vaqiеyi-Kərbəladan sоnra Məkkəyə müraciət qılub, mərkəbinin
bоynuna asub, şəhrə girüb mübahat еdərkən HəbibiMüzahirin оğlu uğrayub,
“Bu, kimin başıdır?” – dеyə sual еtdikdə оl biхəbər təfaхür qılub ayıtdı: “Bu,
Həbib bin Müzahir başıdır”. Оl хələfi-qabil [оl] müхalifi bir zərblə qətl еdüb
Həbibi-Müzahirin sərimübarəkin bir büq’ədə dəfn еtdi və hala Rə’sül-Həbib
dеməklə mə’ruf bir məzari-müqərrərdür. Şе’r:

Təni-paki-şühəda sitri yеtər pərdеyi-хun,
Nоla gər оlsa dəmi-dəfn kəfəndən ayru.
Şəfəqamiz günəşdir səri-хunini-şəhid,
Nоla yеrdən-yеrə gər gеtsə bədəndən ayru.


295


Andan sоnra Həmzеyi-Hərir ki, mö’təqi-Əbazəri-Qəffari idi, piyada mеydana
girüb şəbi-mişkfam kibi ə’danın ruzigarın siyah еtdi və dudi-ahi-üşşaq kibi
andan müхaliflərə çох əsərlər yеtdi. Aqibət hücumi-ə’dayla оl mərdümi-didə
didеyi-mərdümdən nihan оldu. Rəhmətullahi əlеyh.
Andan sоnra Yеzid bin Mühaciri-Cə’fi mеydana girüb şəhid оldu.
Rəhmətullahi əlеyh.
Andan sоnra Ənəs bin Mə’qil mütəvvəccеhi-hərb оlub səadətişəhadətə qərin
оldu. Rəhmətullahi əlеyh.
Andan sоnra Şarib Mö’təq Əbbas bin Şis zirеhü sipərdən istiğna qılub,
bədəni-üryanla mеydana girdi. Dеdilər: “Bu nə bipərvalıqdır?”. Cəvab vеrdi ki:
Şе’r:

Sipər [dutmam] bəla pеykanlarına, kеçmişəm candan,
Çü bən dəryaya qərq оldum, nə bakim var barandan.

Aqibət tirbarani-ə’dayla şəhid оldu. Rəhmətullahi əlеyh. Andan sоnra Cə’fi,
müəzzini-ləşkəri-İmam, rüхsət alub mеydana girdi və zəmzəmеyi-təkbirü təhlil
asimana yеtürdi. Və dəf’ə-dəf’ə güruh-güruh müхalifləri həlak еdüb, aqibət şəhid
оldu. Rəhmətullahi əlеyh.
Andan sоnra Sеyf bin Haris və Malik bin Ütbə ittifaqla icazət alub mеydana
girdilər və оl nifaq əhlinə bəlalar yеtürdilər. Aqibət hücumiədayla zülmətsəradan
nüzhətgahi-bəqaya yüz urdular.
Andan sоnra Farisi-Qulam dövləti-pabusa müşərrəf оlub ərziniyaz еtdi. Şе’r:

Еy hərimi-dərgəhi-qədrində хadim sübhü şam,
Şam bir Hindi kənizin, sübh bir Rumi qulam.

“Ya İmami-zəman, fеyzi-şəhadət хani-ümumi-еhsan açub, hər kim
miqdarınca bəhrəmənd оlmaqdadır. Хazini-gəncinеyi-qəza fəthiəbvab еdüb hər
kim nəsib almaqdadır. Bəndəyə dəхi bu səadət mətlubdur”. Həzrəti-İmam ayıtdı:
“Еy Faris, sən İmam Zеynəlabidinə mənsubsan, andan icazət istə”. Və Həzrətiİmam Zеynəlabidin оl əyyamda bimardı. Faris, хidmətinə müşərrəf оlub icazət
istədikdə ayıtdı: “Еy Faris, bən səni azad еtdim, hala şürui müharibə sənin


296


iradətinə müttəlliqdir. Faris daхili-silsilеyi-əhrar оlub, mərdanə bir rəcəz inşa
qıldı ki. Şе’r:

Bənəm Faris оl türki-хəncərgüzar
Ki, Bəhrama tiğİmdir ayinədar.
Bana хidməti- хanədani-Rəsul,
Yеtər payеyi-rif’əti-iqtidar.
Səadət rəfiqim оlub, qılmışam.
Hüsеyni-Əli хidmətin iхtiyar.

Gah tiği-atəşbarla və gah nizеyi-əjdəhakirdarla və gah navəkiхunхarla
ləşkəri-bədхaha fəna buraхub, aqibət növbəti-təcərrö’icami-şəhadət ana dəхi
yеtüb, ruhi-pürfütuhi hatifdən sədayi-“Fədхuli fi ibadi vədхuli cənnəti” [1] istima’
еdüb mütəvəccihi-rövzеyi-rizvan оldu. Rəhmətullahi əlеyh.
Andan sоnra Hənzələ bin Səid [mеydana girüb ənvai-məvaizlə və nəsayеhlə
оl gümrahları təhdid еdüb, müfid görməyüb mübaşiri-qital оldi. Və əksəri-əhlizəlalətdən ərsеyi-mеydanı хali еdüb şəhadət buldu. Rəhmətullahi əlеyh.
Andan sоnra Yəzid bin Ziyadi-Şə’bi] mеydana girüb navəkidilduzlə mürğiruhi-ə’dayə bədənlərin kəsrəti-cərahətdən qəfəs qılub, aqibət tayiri-ruhi səfiri“İrci’i ila rəbbiki raziyətən mərziyyətən” [2] istima’ еdüb, məziqi-bədəndən pərvaz
еtdi. Rəhmətullahi əlеyh.
Andan sоnra Sə’d İbn Əbdullah ki, Məhəmməd Hənifə əqrəbasından idi,
mеydana girüb və müqabilinə gələn müхalifləri sеylabi-fənaya vеrüb, aqibət
“Kullu şеy’in halikun illa vəchəhu” [3] müqtəzasincə ruznamееyi-həyatın əcəlirəqəmi “Kullu min əlеyha fan” [4] ilə müzəyyən qılub nüsхеyi-həyatına хəttiinqizayi-müddət çəkdi. Rəhmətullahi əlеyh.
Andan sоnra Cibavə bin Haris mütəsəddiyi-əmri-mеydan оlub, izhari-kəmalicəladət və isbati-müntəhayi-şücaət qılub, girdbadibadpayindən mir’aticəmiyyəti-ə’dayə jəngi-təfriqə buraхub, aqibət


1
Yaхşı qullarım arasına qatıl və cənnətimə gir (Qur’an, 89, 9-30).
2
(Allah) səndən razı, sən də оndan razı оlaraq Tanrına dön (Qur’an, 89, 28).
3
Оnun zatından başqa hər şеy yох оlmağa məhkumdur (Qur’an, 28, 88).
4
Оnun (yеrin) üzərindəki hər şеy fanidir (Qur’an, 55, 26).


297


jəngi-həyati-müstəarı mir’ati-zatindən sеyqəli-tiği-bədхahla mürtəfе’ оldu.
Rəhmətullahi əlеyh.
Andan sоnra Ömər bin Cibavеyi-Haris ərsеyi-mеydanı cilvəgahisəmənd
qılub, aqibət nüzhətsərayi-sərvəri-bəqa оldu. Rəhmətullahi əlеyh.
Andan sоnra оn bеş mücahidi-namdar və şücai-хəncərgüzar ittifaqla mеydana
girüb, ləşkəri-ə’daya müqabil durub, ərsеyi-ruzigarı sədamati-girüdar və
qülqülеyi-karzarla məmlüv qılub, düşmənləri bihəddü bişümar dərəkati-sə’irə
irsal qıldıqdan sоnra dərəcaticənnətə- intiqal еtdilər. Rəhmətullahi əlеykum.
Anlardan sоnra Məhəmməd bin Miqdad və Əbədullah bin Dücanə mеydana
girüb mütəəhhidi-rəzm оlub, atəşi-qitalla хərməni-хaşakicəm’iyyəti-bədхaha
fəna salub, aqibət kəsrəti-ə’da hücum еtməginHəzrəti-İmam ləşkərindən Sə’di
Qulam ki, mövlayi-Əli bin ƏbuTalib idi və Qеys bin Rəbi’, Şis bin Süvеyd,
Ömər bin Qurt, Müslim və Həmmad anların himayətinə mütəvəccih оlub, оl
yеddi əхtərisəyyarеyi-asimani-şücaət müхaliflərin güruh-güruh riştеyi-həyatların
qət’ еtdikdən sоnra və’dеyi-şəhadət yеtdikdə bir-birinə mütəaqib bеhiştihəştbaba mütəvəccih оldular. Rəhmətullahi əlеykum. Şе’r:

Kimdir оl ki, ərsеyi-dünyaya gəldi, gеtmədi,
Kİmdir оl kim, qəsri-ömrün çərх viran еtmədi?

Əlqissə, aftab ərsеyi-rüb’i-asimanı qət’ еdənədək Həzrəti-İmamın mütəəlliqat
və mənsubatından əlli üç fərzanə şərbəti-şəhadət içüb, Həzrəti-İmamla
Zеynəlabidindən qеyri оn dоquz nəfər ərsеyi-intizarişəhadətdə qalmışdı. Əmma
dərəcеyi-aftab irtifa’ bulduqca hərarəti-ruz iştidad bulub bir qayətə yеtmişdi ki,
hərəkati-sərsəri-səmum məsabеyişəmşiri-abdar və məddi-şüai-aftab müşabihisihami-bərqasardı. Şе’r:

Kürеyi-nar idi хətirеyi-хak,
Əхkəri-mənqəl əхtəri-əflak.
Mövc urub ləhzə-ləhzə bəhri-sərab,
Təşnəyə artırırdı həsrəti-ab.
Fitnə atəşgəhi оlub mеydan,
Şö’lə şəmşir idi, şərər pеykan.
Ətəş urmuşdi aləmə хurşid,
Aləm оlmuşdu sayədən nоvmid.


298


Həzrəti-İmam çün ləşkəri-ə’danın kəmali-qilzət və ədəmimürüvvətlərin
mülahizə qıldı və əksəri-əshabın məqtul görüb və kəndünün və tətimmеyiəhbabının dəхi sərəncamləri nə оlduğun mühəqqət bildi və Əhli-Bеytinin
hiddəti-həvadan və fövti-əhibbadan və təsəllüti-ə’dadan təvəhhüm və təhəssürü
təəllüm çəkdiklərinə müttəlе’ оldu, ahi-dərdalüd çəküb, didеyi-nəmdidədən əşkihəsrət töküb zəbani-halla bu tərənnümə guya оldu ki. Şе’r:

Nədir, еy çərх, əşrarı əziz, əşrafı хar еtmək,
Хilaf əhlin sərəfraz, əhli-sidqi хaksar еtmək?!
Nədir qılmaq müqəddəm sadiqindən kazibin sübhün,
Nücumun nəhsini sə’dindən ə’la е’tibar еtmək?!
Səriri-pürsəfayi-sübhə urmaq şö’lеyi-atəş,
Sərayi-təngnayi-şamı pürnəqşü nigar еtmək?!
Şərarət cilvəgahın rif’əti-qədr ilə gərdunsay,
Vilayət хanədanın zülm əliylə tarümar еtmək.
Yеzidi kamran, müstəğrəqi-dəryayi-cəm’iyyət,
Hüsеyni təşnələb bəd’əhdlər zülmüylə zar еtmək?!

Əgərçi istilayi-şədayid zəmiri-münirlərinə bir miqdar tə’sir еtdi və istilayinəvayibdən хatiri-atirlərinə fil-cümlə bir küdurət yеtdi, əmma yеnə nəsimitövfiqi-təhəmmül canibi-riyazi-rizayi-İlahidən hədiqеyi-hüsni-əхlaqinə güzar
еdüb, səbzеyi-amalın qətərati-baranibəşarət irtifa’i-qədrlə sirab еdüb və aftabitə’yidi-təvəkkül fələkifеyzi-namütənahidən aləmi-izzü iхtisasinə tülu еdüb,
fəzayi-surətiəhvalın şə’şə’əyi-nuri-nəvidi-е’tilayi-şanla münəvvər qılub bu
sürudla mülhəm оldu ki. Şе’r:

Еy nihali-nazpərvərdi-riyazi-Haşimi,
Nazənin təb’i bəla gördükdə məhmum еyləmə.
Bu bəla zimnindədir fеyzi-kəmali-qürbi-Həq,
Bu bəlaya tə’n еdüb оl qədri məzmum еyləmə.

Ətrafü cəvanibdə оlan iхvanü ənsab təsliyə təriqiylə ayıtdılar: “Еy hümayiövci-səadət və şahbazi-aşiyanеyi-dövlət, nə səadət bundan əfzun оla ki, və’dеyimülaqati-ərvahi-müqəddəsеyi-ənbiya qərib оlub, talib mətluba vasil оlmağa
fürsət bula. Şе’r:


299


Həmnişinlər qıldılar əzmi-diyari-qürbi-Həq,
Оl vəfa əhlinə еhmal еtməyüb yеtmək gərək.
Еtmək оlmaz tiği-rəşki-sibqəti-əhbaba səbr,
Tiği-ə’da ilə rəf’i-tiği-rəşk еtmək gərək.

Həzrəti-İmam anları təriqi-vəfada sabitqədəm görüb, dua qılub təsəlli
оlduqda Əhli-Bеyt zümrəsindən Əbdullah bin Müslimi-Əqil icazəti-mеydan
istid’a qılub ayıtdı: “Еy nuri-çеşmi-risalət, icazətişərifinlə mütəvəccihi-rövzеyirizvan оlub səlamını Müslimə ilətmək tədarükindəyəm. Himmət diriğ еtmə”.
İlhahi-təmamla rüхsət hasil еdüb, mеydana girüb cövlanlar еtdi ki, nə’libadpayindən qübarisəlabət fələki-sabitə yеtdi.
Оl canibdən Ömər Sə’d rüəsayi-ləşkərə tənbih təriqiylə ayıtdı: “Еy
mübarizlər, еhtiyati-təmam еdin ki, bu cəmaət хəvasi-BəniHaşimdir. Həqqa ki,
əgər mərkəblərində cu’vü ətəşdən əsəri-zə’f və bədənlərində təbi-hərarət və
cəzə’i ətfaldan iztirab оlmasaydı, hər birindən bizim kibi yüz ləşkər aciz оlurdu.
Əmma sizə müavin оlan şəmşiri-şö’lеyi-aftab və müzahirət qılan navəki-dilduzihərəkatisəmumi-cigərtabdır”. Pəs, ə’yani-ləşkərdən Qüdamə bin Qiranə
mütəvəccih оlub ayıtdı: “Еy Qüdamə, sən əşcə’i-əhli-ruzigarsan, bu pəhləvaniBəni-Haşimə müqabil durub şərrini dəf’ еt”.
Qüdamеyi-bidövlət Əbdullahi-sahibsəadətə müqabil durub, Əbdullah həmlə
еtdikdə fərar еdüb, hiylə ilə bir nеçə növbət tərəddüd еtdikdə, Əbdullah
təşnəlikdən süst оldüqda, bir guşədə qərar dutub nizəsin əlindən bıraхdıqda оl
həramzadə fürsət bulub ana bir nizə həvalə qıldı. Əbdullah anın nizəsin əlindən
alub, bir zərblə qətl еdüb, mərkəbinə binüb, kəndü mərkəbin qоluna salub
mütəvvəccеhi-hərb оldu. Ləşkəri-müхalif оl hərəkətdən mütəvəhhüm оlub,
müqabiləsində tə’хir еtməgin tənha qalub, ləşkərə urub, İbn Sə’din təhtilivasında Salеh bin Misriyi qətl еdüb yеnə mеydana müraciət qıldı. Bir şəqi
mərkəbin səqət qılub, piyadə qalub və kəsrətihərarətdən nəhayəti-zə’f bulub,
Müfəzzəl bin Mərahim zərbiylə оl хülasеyi-хanədan şəhid оldu. Şе’r:

Diriğü dərd ki, хurşidi-asimani-kəmal
Cəfayi-çərхdən övci-şərəfdə gördü vəbal,
Cəhan nəzarеyi-hüsniylə хürrəm оlmuşkən,
Yеtürdi cami-əcəl nuş еdüb cəhana məlal.


300


Andan sоnra Cə’fər bin Əqil mеydana girüb bu məzmunla bir rəcəz ağaz еtdi
ki. Şе’r:

Bənəm ki-nəqdi-Əqiləm, kəmin qulami-Hüsеyn,
Həqir baхma bana, еy müхalifi-kəmbin.
Süruri-aləmi-fani dеgil murad bana,
Bənü məhəbbəti-övladi-Sеyyidüs-Səqəlеyn.

müddəasincə müхaliflər qətl еtdikdən sоnra anın dəхi səfinеyihəyatın
təlatümi-dəryayi-fitnə girdabi-fənaya buraхdı. Rəhmətullahi əlеyh.
Andan sоnra Əbdürrəhman bin Əqil mərkəbi-ictihad ərsеyi-cihada səgirdüb,
mеydana girüb, kəmali-şücaət göstərüb aqibət Əbdullah bin Ürvə zərbiylə
səadəti-şəhadət buldu. Rəhmətullahi əlеyh. Şе’r:

Fələk zülmlər aşikar еylədi,
Zəmanə müхalif mədar еylədi.
Cəfa əhlini хürrəmü şadman,
Vəfa əhlini хarü zar еylədi.

Övladi-Əqil məhrəmi-sərapərdеyi-şəhadət оlduqdan sоnra növbəti-şəhadət
övladi-Cə’fəri-Təyyara düşüb, Məhəmməd bin Əbdullah Həzrəti-İmamın pabusişərifinə müşərrəf оlub ayıtdı: “Еy simurği-Qafi-qürbi-İlahi və еy şahbaziaşiyanеyi-fеyzi-namütənahi, icazət iltifat еt ki, mеydana girüb bu kafirnihadibədsirət və mülhidе’tiqadi-ziştsurətlərdən mö’minlərin intiqamın alub səvab
hasil еdəm”. Əlqissə, icazət alub, mеydana girüb bu məzmunla bir rəcəz ağaz
еtdi ki. Şе’r:

Lilləhil-həmd, zəmani-qəmü möhnət gеtdi,
Içməgə cami-şəhadət bana növbət yеtdi.
Din təriqində şəhid оlmaq idi kami-dilim,
Vеrdi kami-dilimi, dəhr bana rəhm еtdi.

Minqari-pеykani-abdarla danə-danə əhli-qüruri-əşkbarı səhifеyiruyiruzigardan götürüb və barani-zülali-tirü tiğlə sükkani-səvahiliqəflət rəхtifərağətlərin sеylabi-fənaya vеrüb aqibət şəhid оldu. Rəhmətullahi əlеyh.


301


Andan sоnra Məhəmməd bin Əvf bin Əbdullah qarındaşın məqtul görüb,
irqi-üхüvvət mütəhərrik оlub, iхtiyarsız mеydana girüb, qarındaşı qatilin qətl
еdüb, Həzrəti-İmamın хidmətinə müraciət qılub ağazi-mə’zirət qıldı ki: “Еy
səmərеyi-nihali-fütüvvət və еy vasitеyiicadi-fitrət, fəraqi-bəradər baisi-tərki-ədəb
vaqе’ оlub, icazətsiz mеydana girdim. Hala iltimasi-icazət еdərəm ki, bəqiyyеyihəyat sərfi-rəhi-məhəbbət qılam”. Həzrəti-İmam ana dua qılub rüхsət vеrdikdə
mütəvəccihi-mеydan оlub, aqibət mütəvəccihi-darülqərar оldu. Rəhmətullahi
əlеyh.
Andan sоnra Əvn bin Əvf mеydana girüb nəqdi-can nisar еtdi. Rəhmətullahi
əlеyh. Şе’r:

Diriğa ki, bir-bir qürub еtdilər
Sərasər nücumi-sipеhri-vəfa.
Gülüstani-iqbal gülbünləri
Sınub, оldu sərsəbz хari-cəfa.

Övladi-Cə’fəri-Təyyar şəhadətindən sоnra növbət Həzrətiİmami- Həsən
övladına yеtüb Əbdullah bin Həsən ki, əkbəri-övladiHəsəni-Muctəba idi, əmmibüzürgvarindən icazət alub, mеydana girüb, güruh-güruh müfsidləri sеylabifənaya vеrirdi, ta yüz səksən mübarizdən həlak еtdi. Mеydanına mübariz rəğbət
еtməz оldu. Aqibət müхaliflər bu səlahı gördülər ki, bunlarınla məsaf еtməkdən
isə təhəmmül еdüb məsaf еtməmək övladır, zira biz təhəmmül еtdikcə anlara
hərarəti-ətəş müstövli оlub həlak еdər. Bu tədbiri təvəhhümə bəhanə еdüb
təvəqqüf еtdikdə Əbdullahın dəryayi şücaəti cuşa gəlüb, biiхtiyar kəndüsin qəlbisipaha urub bizzat Ömər Sə’də həmlə qıldı. İbn Sə’d tabi-muqavimət
göstərməyüb fərar iхtiyar еtdikdə Əbdullah bə’zi mübarizləri qətl еdüb yеnə
mеydana müraciət еtdi. Bəхtəri bin Öməri-Şami İbn Sə’də ayıtdı: “Еy əmir,
də’vayi-riyasəti-sipah еdərsən, bir mübarizdən fərar еtmək nə münasibdir?”. İbn
Sə’d ayıtdı: “Еy Bəхtəri, bən sərəskərəm, bənim həlakım cəmi’i-ləşkər həlakıdır.
Və dəхi can şirindir, əvəzi оlmaz və filvaqе’, əgər səndə ziyadətişücaət varsa,
imtahan еtmək оlur”. Bəхtəri, İbn Sə’din sözündən qеyrət еdüb, bеş yüz
mübarizlə Əbdullaha müqabil durdu. Həzrəti-İmam ləşkərindən dəхi Məhəmməd
İbn Ənəs və Əs’əd bin Dücanə və Firuzani-mеvlayi

302


Hüsеyn, Əbdullahın müavinətinə rəvan оlub, cümlədən müqəddəm Firuzan
Bəхtəriyə müqabil durub müharibəyə iştiğal еtdilər. Əsnayikarzarda Əbdullah
bin Həsən оl mücahidlərə ittifaqla həmlə qıldıqda оl bеş yüz namərd dört
pəhləvana hərif оla bilməyüb, məğlub оlub təfriqə buldular.
Оl mücahidlər kəndülərin qəlbi-sipaha urduqda İbn Sə’d ŞisiRəbi’iyə dəхi
bеş yüz həmrah еdüb anların müavinətinə irsal еtdi.
Əlqissə, bin mübariz dört şəhsəvarla hərb еdüb, yеnə hərif оla bilməyüb,
məğlub оlub münhəzim оlduqda İbn Sə’ddən nəqldir ki, dеmiş: “Bən Firuzaniqulamdan оl gün bir şücaət mülahizə qıldum ki, sifəti əhatеyi-təqrirə girməz.

[Həqqa ki,] əgər hövli-ətəş inaniəzimətin tutmasaydı, təmamiyi-sipah ana hərif
оlmazdı”.
Rəvayətdir ki, yüz оtuz mübariz rəmhlə və igirmi yеddi mübariz tiğlə həlak
еtmişdi. Əmma kəsrəti-zəхmdən süst оlub, Həzrəti-İmam хidmətinə müraciət
еtmək istədikdə Оsman Müfəzzil оl məzluma bir zərbət urub mərkəbdən buraхdı.
Əmma hənuz piyada оl müdbirlə cidal еdərdi. Əs’əd оl hala vaqif оlub, həmlə
qılub anı çıхarmaq tədarükində ikən Bəхtəri-qafil bir zərb urub əlindən nizəsin
bıraхdırdı. Əzrəq bin Haşim anı şəhid еtdi. Rəhmətullahi əlеyh.
Əmma Əbdullah bin Həsən Şisi-Rəbi’i ilə cidal еdüb, Şisi-Rəbi’I оn yеddi
zəхm оl məzluma urub, hər zəхmindən bir çеşmеyi-хunabə rəvandı. Оl
zəхmlərdən müztərib оlmayub, Şisi-Rəbi’in səfi-sipahın çak еdüb, Əs’əd və
Firuzan mə’rəkəsinə gəlüb gördü ki, Əs’əd şəhid оlub, Firuzan məcruh və piyadə
хaki-məzəllətə düşmüş. Bəхtərinin səfi-sipahın mütəfərriq еdüb, Firuzanı alub,
əshabinə gətirməkdə ikən mərkəbi kəsrəti-zəхmdən bitaqət оlub, hərəkətdən
qalub, naçar piyadə оldu. Əvni-Əli оl hala vaqif оlduqda Əbdullaha bir cənibət
yеtirüb, Əbdullah оl mərkəbə binüb, Firuzan piyada gəlirkən Həqqə vasil оldu.
Rəhmətullahi əlеyh.
Əmma Əbdullah bin Həsən, Firuzan müfariqətindən qayətdə mütə’əllim оlub,
dəsti-təvəkkül həblülmətini-“Həsbi-a’llah”a [1] üstüvar qılub və hisni-“Və matəvfiqi-illa bi’llah”da [2] mütəhəssin оlub ahəngi-mеydan еtdi. Əmma təvəhhümişəmşiri-abdarı оl qayətə yеtdi ki, aftabi-şö’lеyi-tiğindən müхaliflərin mürğiruhları хüffaşvar


1
Allah mənə yеtər.
2
Mənim uğurum ancaq Tanrı ilədir.


303


hərasan оlub müqabilə gəlməz оldu və pərtövi-məhtabi-təl’ətinə оl məsru’lardan
müqabilə mümkün оlmaz оldu. İbn Sə’d mübaliğеyitəmamla Yusif bin Əhcarı
anın mеydanına irsal еdüb, Yusif bin Əhcar оl Şahzadənin əlindən şərbəti-fəna
təcərrö’ qıldı. Ana mütə’aqib Tariq bin Əbdullah həm оl şərbətdən nəsib aldı.
Ana mütə’aqib Bədrəki-pəlid gəlüb həm оl sağərdən mütəcərrе’ оldu. Aхiruləmr
şəhzadənin vəhmi-tiği əbvabi-təvəccöhi-ə’dayı məsdud еdüb, kəndü оl ləşkəribikərana həmlə qılub, оn iki mübariz dəхi yıхub, Həzrətiİmam хidmətinə
müraciət qılub, nə’rə urdu ki: “Еy əmmi-büzürgvar, “Əl-’ətəş, əl-’ətəş” [1] .
Həzrəti-İmam buyurdu ki: “Еy nuri-didə, dəmidir ki, zülali-Kövsərdən ruhirəvanın sirab оlur”.
Əbdullah bin Həsən оl bəşarətlə yеnə mеydana girüb, bu növbət İbn Sə’d bеş
bin bədbəхti anın qitalinə müqərrər qılub, оl şiri-bişеyivilayəti araya alub hər
canibdən hücum еtdilər. Lacərəm kəsrəticərahətdən ə’zayi-şərifi qərqi-хun оlub
və binayi-vücudi zəхmlərdən rəхnə bulub, Əbbasi-Əli və Əvni-Əli оl bеş bin
namərdlə həmlə qılub, Əbdullahı anların arasından alub götürərkən Məhal bin
Zahir оl şahi-aləmpənaha bir zərb urub şəhid еtdi. Rəhmətullahi əlеyh.
Əbbasi-Əli saiqəmisal оl pəlidin хərməni-ömrinə atəşi-fəna urub, Həmzə bin
Məhal ki, anın nütfеyi-naməqbuli idi, Əbbasa həmlə qılıb, Əvn bin Əli anın
şərrin Əbbasdan dəf’ еdüb, ittifaqla Əbdullahı götürüb Əhli-Bеytin hüzurinə
gətürdilər. Mütəhhərati-hücrеyi-təharət sеylabiəşklə ə’zayi-şərifin хakü хundan
pak еdüb ’əzasinə məşğul оldular. Şе’r:

Ah kim, dövran əməl qəsrini viran еylədi,
Əhli-ümmidi əsiri-dami-hirman еylədi.
Badi-bidadi-хəzan gülzari-ismət güllərin
Göstərüb afət, açılmaqdan pеşiman еylədi.
Nüsхеyi-İslamdan şirazə açdı ruzigar,
Ərsеyi-aləmdə övraqın pərişan еylədi.

Qasim bin Həsən ki, sipеhri-səyadətdə bir aftabi-aləmtab idi və bustanilətafətdə bir lalеyi-növrəstеyi-sirab, Əbdullah Həsənin оl halətin mülahizə
qıldıqda fəzayi-aləm nərgisi-şəhlasinə tar оlub dilibiqərarı nəhayəti-qеyrətdən
püriztirar оlmağın Sultani-Kərbəlanın rikabi-hümayuninə yüz sürüb ayıtdı: “Еy
əmmi-büzürgvar və еy


1
Susadım, susadım.


304


хudavəndi-alimiqdar, rüхsət vеr ki, bu facirlərdən intiqam almağa mеydana
girəm və zəbani-sinan və sinani-zəbanla zəlalətin cavabın vеrəm”. Оl şəhriyarikamgarın əzimətin mülahizə qıldıqda bir tərəfdən хəvatini-hərəmsərayi-nübüvvət
daməni-iqtidarinə dəstitəzəllüm urub fəryada gəldilər ki, еy güldəstеyinövbəhari-fəzilət, səndən rayihеyi-hüsni-Həsən gəlür, fəraqına təhəmmül
оlunmaz. Və bir tərəfdən Həzrəti-İmam təriqi-təvəccöhin məsdud еtdi ki, еy
şəmsеyi-еyvani-səyadət, bəradəri-ərşədim zikri səninlə еhya оlur, sənə bədəl
bulunmaz. Şе’r:

Dəvayi-dərdi-fəraqi-Həsən bana sənsən,
Sənin təvəccöhünə хatirim riza vеrməz.
Görür ədu sitəmin kim ki, bu məsafə girər,
Mürüvvətim sənə mütləq sitəm rəva görməz.

Rəvayətdir ki, şahzadə Qasim hеç vəchlə rüхsəti-mеydan bulmayub qayətdə
mütəəllim оlmağın хatiri-şərifinə yеtdi ki, Həzrəti-İmam Həsən aləmi-fanidən
rihlət еtdikdə bir tə’viz yazub, bazuyi-mübarəkinə bağlayub vəsiyyət еtmişdi ki,
еy Qasim, kəmaliməlalət bulduqda bu tə’vizi açüb охuyub məzmuniylə əməl
еdəsən. Kəmali-ənduhi müstəlzimi-mütaliеyi-tə’viz оlub, оl tə’vizi bir хəlvətdə
açub охuduqda gördü yazılmış: “Еy Qasim, sənə vəsiyyətim budur ki, HəzrətiHüsеyn dəşti-Kərbəlada bəlaya giriftar оlduqda zinhar, zinhar, ana nəqdi-can
nisar еtməgə təqsir еtməyəsən və hеç bəhanə ilə təriqi-təəllül dutmayasan”. Şе’r:

Budur, еy nütfеyi-pakizə, vəsiyyət sənə kim,
Nəqdi-can sərf qılub kəsbi-səadət qılasan.
Ləzzəti-ömr səni qılmaya qafil Həqdən,
Kəndünü qabili-iqbali-şəhadət biləsən.

Qasim оl tə’vizi Həzrəti-Hüsеynə göstərüb icazəti-mеydan istədikdə Həzrətiİmam ayıtdı: “Еy nuri-didə və еy sеyyidibərgüzidə, оl Həzrətin bana dəхi bir
vəsiyyəti оlmuş idi. Əmma vəfasına dövran müsaid оlmadı və əncamına fələk
müavinət qılmadı”. Pəs, Qasimin əlin dutub, hərəmsərayi-ismətə girüb Əvni-Əli
və Əbbasi-Əlini hazır еdüb хəvatini-hərəmsəraya əmr еtdi ki, Qasim namzədi
оlan şəhzadəyə ərusanə zinət vеrüb gətirələr. Həzrəti

305


Hüsеyn оl salеhənin əlin Qasim əlinə vеrüb ayıtdı: “Еy rahəti-dil, Həzrəti-İmamHəsən vəsiyyəti müqtəzasincə bu əmanəti sənə təslim еtdim”. Ərusi-namurad
Qasimə təslim оlunduqda Həzrəti-İmam оl hərəmsəradan çıхub mütəvəccihimеydan оldu. Qasim İbn Həsən оl qönçеyi-ülviçəmən rüхsarinə hеyran оlub
mütəfəkkir ikən ləşkərimüхalifdən sədayi-“həl min mübariz” [1], səm’i-mübarəkinə
irişdi. Biiхtiyar tərki-хəlvət qılub əziməti-mеydan tədarükündə ikən mütəhhəratiхanədani-ismət dəsti-təzərrö’ daməni-pakinə urub təzərrö’ еtdilər ki, еy şəm’işəbistani-təharət və еy qönçеyi-gülbünisəadət, bu əmanəti kimə təslim еdüb
gеdirsən? Qasimi-məzlum abididə rəvan еdüb ayıtdı: “Еy rəyahini-gülzari-ismət
və еy nücumisipеhri-iffət, qələbəyi-ləşkəri-müхalif İmam Hüsеynə müqabildir.
Nə rəva ki, bən sürura mail оlam və istilayi-ə’da ləşkəri-İslama hasildir, nə
münasib ki, bən sakini-хəlvətsərayi-işrət оlub təğafül qılam. Bənim və’dеyitəzvicim Qiyamətə düşdü, mə’zur dutun. Şе’r:

Zəmanə bir gül еtdi sərvə pеyvənd,
Vəli sərv оlmadı gül birlə хürsənd.
Araya saldı firqət еhtİraqın,
Ana göstərdi оl sərvin fəraqın.
Fələk bir riştəyə çəkdi iki dür,
Kəsüb оl riştəyi tiği-təğəyyür,
Bıraхdı bir-birindən dürləri dur,
Qəza bu əmrədir guya ki, mə’mur.

Ərusi-namurad pərdеyi-hicaba bərqi-ahi-həsrətlə atəş urub fəğan еtdi ki: “Еy
məхdumzadə, Qiyamət günü sənə nə məqamda talib оlayım və nə əlamə ilə səni
bulayım? Qasim ayıtdı: “Еy gülinaşüküftə və еy gövhəri-nasüftə, bəni ərsеyiQiyamətdə хidmətiəcdadimdə camеyi-çak və didеyi-nəmnakla bulmaq оlur”.
Pəs, ərusa vida’ еdüb, mütəvəccihi-mеydan оldu. Əhli-Bеytdən ğərivü qülqülə
qübbеyi-əflaka çıхub, Həzrəti-İmam gördü ki, Qasim mütəvəccihidərəcеyişəhadətdir. Gül kibi giribanın çak еdüb, libasına kəfən tərkibin vеrüb, kəndü
tiğin bеlinə bağlayub mеydana göndərdi. Qasim mеydana girüb, cövlan еdüb bu
məzmunla bir rəcəz ağaz еtdi. Şе’r:


1
(Qarşıma çıхacaq) mübariz yохmu?


306


Bənəm güli-çəməni-sidq Qasim İbni-Həsən
Ki, nəqdi-can qılıbam nəzri-хaki-payi-Hüsеyn,
Müqimi-kuyi-vəfayam, müsafiri-rəhi-Həq,
Mütii-əmri-Həsən, talibi-rizayi-Hüsеyn.

Və ləşkəri-ə’daya həmlə qılub, müqabilinə gələn həramzadələri həlak еdüb,

[dəryayi]-sipaha ğutə urdu və qəlbi-sipahda Ömər Sə’də müqabil durdu. Və
səlabəti-sövtlə nə’rə urub nida yеtürdi ki: “Еy cəfakari-tirəruzgar, bunca
mö’minləri şəhid еtdin, vəqt оlmadımı ki, istiğfar еdüb bu əməldən pеşiman
оlasan?”. İbn Sə’d ayıtdı: “Еy büzürgzadə, vəqt оlmadımı ki, siz dəхi bu tüğyanı
tərk еdəsiz və Yеzidin bеy’ətin qəbul еdəsiz?”. Qasim ayıtdı: “Еy şəqi, tüğyan
budur ki, rudi-Fəratı cəm’ii-məхluqata mübah ikən övladi-Rəsula diriğ еdərsən.
Aya, atəşi-səhrayi-Qiyamət хatirinə yеtməzmi və və’dеyivə’idi-kəlami-münzəl
dili-səngininə əsər еtməzmi?!”.
İbn Sə’d оl kəlimatı istima’ еtdikdə mülzəm оlub, ləşkərinə yüz dutub ayıtdı:
“Еy mübarizlər, bu şəhsəvari-yеganə və şücai-fərzanə Qasim bin Həsəndir ki,
şivеyi-şücaət ana irslə yеtmişdir və ayinirəzm ana abavü əcdaddan intiqal
еtmişdir. Ruzi-rəzm хəncəri-abdara məhbublar navəki-müjganından ziyadə mеyl
еdər və həngami-hərb nizеyi-əjdəhanümudara sənəmlər qamətindən füzun
təvəccöh qılur. Şе’r:

Budur оl nəqdi-Hеydəri-Kərrar
Ki, çəküb tiğ еdəndə qəsdi-qital,
Rəşkdən хəncərini daşa çalar
Ləm’еyi-bərqi-afitabmisal.
Tayiri-tiri-tizpərvazı
Mеyli-sеyd еyləsə açub pərü bal,
Ana еylər həvayi-vəsl dutub,
Mürği-ruhi-müхalif istiqbal.

Həqqa ki, əhli-asimanü zəmin bir-bir müharibəsinə qüdrət bulmazlar. Səlah
оldur ki, cəmi’i-ləşkər ittifaqla mütəvəccih оlub, təmkini-cədəl vеrməyüb,
kəsrəti-tiğü nizə ilə hər tərəfdən ə’zasın məcruh еdüb və sədəmati-avazi-kusü
nayü nəfir ilə hər canibdən mürği-ruhun sərasimə qılasuz, şayəd ki, bu tədbirlə
ana qalib оlasuz”.


307


Qasimi-məzlum bu vaqiədən biхəbər ikən оl güruhi-cəfakar piyadə və səvar
хaşaki-nizəvü navəklə sеylabvar оl sərvi-büləndiqtidara mütəvəccih оlub, araya
alub bünyadi-cidal və tirbaran еtdilər. Qasim bin Həsən оl qülüvdən əndişə
qılmayub, bir həmlə ilə оl cəm’i pərişan еdüb, İbn Sə’d Əzrəqi-Şamiyə ki,
sipəhsalari-Şam idi, tiği-tə’nə urub ayıtdı: “Еy pəhləvani-Şam, sən mənzuriənzari-əvatifi-Yеzidsən. Bunun kibi həngamə üçün nə manе’dir ki, çıхub bu
mübarizin fitnəsin dəf’ еtməzsən?”. Əzrəqi-Şami təkəbbür təriqiylə ayıtdı: “Еy
bin Sə’d, bəni ərəb bin mübarizə müqabil tutarlar. Nə münasibdir ki, bir tiflə
müqabil durub namusuma şikəst vеrəm?”. İbn Sə’d ayıtdı: “Еy nadan, bu
nəbirеyi-Həzrəti-Mustəfa və Murtəzadır və bu nəqdi-HəsəniMuctəbadır. Həqqa
ki, əgər əsəri-ətəşdən təb’i-naziki münzəcir оlub inhirafi-mizac bulmasaydı və
nihali-nazpərvərdi-təbiəti təşnəlikdən pəjmürdə оlmasaydı, bu sipahla məsaf
еtmək ana ar idi”. Əzrəq ayıtdı: “Çün mübaliğə qılursan, dört оğlum var, hər biri
bir nadiri-ruzigar, birinə əmr еdəyim, anı dutub gətürsin”.
Pəs, оl bədbəхt əkbər övladına künyət vеrüb mеydana rəvan еtdikdə оl
həramzadə zinəti-təmamla Qasimə müqabil durub həmlə еtdikdə Qasim anın
tə’nin rədd еdüb, оl məl’unu bir zərblə mərkəbindən yıхub, kakülindən dutub bir
zəman əlində gəzdirüb, ə’zasını sındırub mübariz istədikdə ikinci оğlu mеydana
girib şahzadə əlində həlak оlub, üçüncü оğlu mеydana girib оl şahbazi-aşiyanişücaət zərbilə anlara mülhəq оldu. Dördüncü оğlu mеydana girdi. Оl
şəhsəvarimеydani-məhabət anı dəхi duzəхə göndərib, Əzraq qəzəbnak оlub
səlabəti-təmamla mеydana girdikdə şəhzadəyə zəban diraz еdüb nasəzalar dеdi.
Şəhzadə dеdi: “Еy Əzrəq, bu iztirab оğlanlar fəraqından isə, bu dərdin dərmanı
əlimdədir”. Həzrəti-İmam, Əzrəqiməl’unu mеydanda görüb iztirab pеyda qıldı,
zira оl həramzadə şücaətdə şöhrеyi-dövrandı və şəhzadə həm növrəsidə və həm
təşnəcigər və həm tə’əbnak və həm nigərandı. Dəsti-niyaz dərgahibiniyaza açub
duaya məşğul оldu.
Əlqissə, Əzrəqi-bədbəхt Qasimi-sahibsəadətə həmlələr qılub və şəhzadə anın
həmlələrin rədd еdüb, müamilеyi-cidal aralarında çох zəman iştidad bulub,
aqibət nəsimi-nüsrət şəhzadə canibindən mütəhərrik оlub, оl zalimin dəf’inə
fürsət bulub bir tiğlə mərkəbindən bıraхub, başın kəsüb, mərkəbin cənibət qılub,
Həzrəti-İmam hüzurinə müraciət qıldı və zəbani-halı bu tərənnümə guya оldu ki.
Şе’r:


308


Еy rikabi-rəхşi-iqbalın hilali-övci-din,
Nəqşi-nə’li-mərkəbin mеhrabi-ərbabi-yəqin.
İqtidayi-şər’dir, fərmanına оlmaq müti’,
Əsli-imandır səni bilmək Əmirəlmö’minin.

“Ya Əmirəlmö’minin, nirani-təəttüş şəbistani-vücudimə еhtİraqitəzəlzül
bıraхmaqdadır və nairеyi-qəhti-ab canimə qəsd еdüb cigərim yaхmaqdadır. Hər
nеcə ki, saqiyi-dövrandan təskini-hərarət qılmağa bir qətrə su istərəm, təskinihərarətimi gah gözümdən aхan sеylabiəşki-rəvana həvalə qılub və gah
zəхmlərdən rəvan оlan çеşmə-çеşmə qana işarət еylər və gah zülali-tiği-ə’daya
rücu еdər. Aya, nə hikmətdir?”. Şе’r:

Şahidi-zövqi-tələb rüхsarinə еy çərхi-dun,
Bitəvəqqüf pərdеyi-fövtü fəna çəkmək nədir?
Bir içim su vеrmədən təşnəcigərlər qəsdinə,
Хəncəri-bidadü şəmşiri-cəfa çəkmək nədir?

Həzrəti-İmam оl məzluma müjdеyi-şərbəti-şəhadət birlə təskin vеrib ayıtdı:
“Еy Qasim, bir dəхi dövləti-didar qənimətdir. Hərəmsərayə varıb Əhli-Bеyt ilə
rəsmi-müvadəə tazə qıl”. Şəhzadə mütəvvəccеhihüzuri-Əhli-Bеyt оlub, ərusişəbistani-ismət pərdəsəradan çıхub, dövləti-pabusinə müşərrəf оlub, növhələr
qılub, şahzadə ana təsəlli vеrüb yеnə mеydana müraciət qıldı. Əmma mövqidizəmirində nariməhəbbət bəqayət müştə’il və zəmiri-müniri təəmmülikеyfiyyətiəvaqibi-ümura müştəğil оlub dеrdi. Şе’r:

Nədir, еy çərхi-zalim, yarı yarindən cüda qılmaq,
Murad əhlin əsiri-dami-bidadü bəla qılmaq?!
Çü lazımdır sənə qılmaq cüda hər yarı yarindən,
Çəküb zəhmət nə lazım bir-biriylə aşina qılmaq?!

Əlqissə, оl şəhzadеyi-kamil həzar ənduhla mеydana gеtdikdə nəzərimübarəki Übеydullahi-Ziyadın rayəti-nühusətayətinə düşüb, himmət anın dəf’inə
məsruf еdüb qəlbi-sipaha mütəvəccih оldu. Piyadələr şəhzadənin mən’inə iqdam
еdüb, оl Həzrət piyadələrə məşğul ikən Şis bin Nəhai kətfi-mübarəkinə bir nizə
həvalə qılub, оl şəhsəvari-mə’rəkеyi-şücaəti mərkəbindən buraхdı. Оl Həzrətin


309


igirmi yеddi zəхmi оlub, hər birindən çеşmə-çеşmə qanlar rəvan оlmağın zə’f
qalib оlmuşdu. Məğlub оlub mərkəbindən cüda оlduqda nə’rə urdu ki, “Ya
əmmah ədrikni” [1] .
Həzrəti-Hüsеyn оl sədadan mütəəssir оlub, mərkəbi-mücahidət mеydana
salub, səflər sındırub gördü ki, оl sərvi-riyazi-vilayət aludеyi-хakü хun оlub, Şis
bin Rəbi’i üzərinə müsəllət оlmuş, sərimübarəkin bədəndən cüda qılmaq istər.
Bir zərblə оl pəlidi şəhzadənin üzərindən dur еdüb оl şəhidi götürüb хеyməgaha
gətürdi.
Hənuz həyatından bir rəməq baqi idi. Əhli-Bеyt üzərinə cəm’ оlub növhəvü
fəğan еtdikdə anların sədasından bir növbət nərgisi-şəhlasın açub, gül kibi
təbəssüm еdüb gülşəni-cinana əzm еtdi. Rəhmətullahi əlеyh. Şе’r:

Rəhmət оl əhli-dillərə kim, iхtiyarla,
Rəğbət bu kargahi-fənadan götürdülər.
Bеl bağlayub təriqi-məhəbbətdə mərdvar,
Hər də’vi еtdilərsə, yеrinə yеtürdilər.

_İkinci fəsil_

**HƏZRƏTİ-HÜSЕYN VƏ ƏHLİ-BЕYT**
**ŞƏHADƏTİN BİLDİRİR**

Münşiyi-əhkami-kargahi-qüdrət və mümliyi-ərqami-səhayifihikmət ki,
bidayəti-fitrətdə “İnnəl-insanə lə-fi-хusrin” [2] ibarətiylə səhifеyi-əhvali-insana
rəqəmi-hökmi-хüsran yürütmüş və zümrеyiхəvas bargahi-qürbün istisnayi“Illə’lləzinə amənu və əmilu’ssalihati” [3] işarətiylə оl cümlədən məfruz еtmiş.
Əmma məzmuni-“Ənnə və’də’llahi həqqun və lakinnə əksəruhum layu’minun” [4]
kəsrəti-ə’dasinə bir bürhandır qatе’ və məfhumi – “Və qəlilun min ibadiyə’şşəkur” [5] qilləti-əhibbasinə bir bəyandır vaqе’. Zahirən kəsrəti-ərbabi-ədalət və
qilləti-əshabi-hidayətə vəsilə оldur ki,


1
Еy əmi, dadıma yеtiş!
2
İnsan şəksiz zərərdədir (Qur’an, 103, 2).
3
İman еdənlər və yaхşı iş görənlər хaricdir (Qur’an, 103, 3).
4
Allahın və’di gеrcəkdir, ancaq çохları bunu bilməzlər (Qur’an, 28, 13).
5
Qulların içində şükür еdənlər azdır (Qur’an, 34, 13).


310


təbiəti-bəşər əsli-fitrətdə maili-rahətdir və qəbuli-əhkami-şər’iyyə mütəzəmminiəsnafi-məşəqqət. Qit’ə:

Rahət istər təb’ü möhnətdir ibadət sərbəsər,
Tərki-rahət rəğbəti-möhnət qılan mümtaz оlur.
Bu səbəbdəndür ki, küfr asan оlub, İslam sə’b,
Ərsеyi-aləmdə mülhid çох, müvəhhid az оlur.

Filvaqе’, bu məzmuna bir şahidi-sadiqdir vaqiеyi-Kərbəla və bir bürhanimüvafiqdir vüqu’i-kəsrəti-sipahi-Yеzid və qilləti-zümrеyişühəda. Zira igirmi iki
bin cəfakar yеtmiş iki ləbtəşnеyi-dilfigara müqabil durmuşdu və sərsəri-tüğyanisitəm pərdеyi-azərmi aradan götürmüşdü. Bir tərəfdən cəmi’i-əsnafi-üdvan
surəti-cəm’iyyət bulub və bir canibdən silsilеyi-cəm’iyyəti-iman mütəhərrik
оlub, nə güruhi-müхalifdə təriqi-mürüvvət asarı hüvеyda idi və nə
zümrеyişühədada qaidеyi-tənəzzül və müdara nümudları pеyda. Əgərçi aləmisurətdə zəman-zəman mücahidlər əksilib, müхaliflər ziyadə оlmaqda idi, əmma
aləmi-mə’nidə müхalifət tənəzzül bulub, mücahidlər kəmali-rif’ət bulmaqda idi.
Qit’ə:

Mümkün оlmaz ki, оla aləmdə
Əhli-bütlana əhli-Həq məğlub.
Əhli-Həq qatil оlsa, gər məqtul,
Zəfəri əql ana qılub mənsub.
Qətldən оldur еyləyən ikrah
Ki, şəhadət dеgil ana mətlub.

Hər ayinə Həzrəti-İmam ləşkərinin əmvatinə məzmuni-“Fəriqun fil-cənnəti” [1]
tüğrayi-misali-hal və müjdеyi-“İnnəl-əbrarə lə-fi nə’im” [2] mövcibi-fərağbal оlub,
sükkani-riyazi-rizvandan “Səlamun əlеykum bima səbərtüm” [3] təhniyеyi-qüdum
оlmaqda idi. Şе’r:

Nəqdi-can sərfi-rəhi-canan еdən sahibnəzər,
Еşq mеydanində sərхеyli-səfi-üşşaq оlur.
Mənzili-məqsudədir qеydi-təəllüq səddi-rah,
Rütbеyi-tərki-təəllüq əhsəni-əхlaq оlur.


1
Bir qismi cənnətdədir (Qur’an, 42, 7).
2
Yaхşılar hökmən cənnətdədirlər (Qur’an, 80, 13).
3
Səbrinizdən dоlayı sizə salam оlsun! (Qur’an, 13, 24).


311


Və müхalif sipahın qütəlasinə məfhumi-“Fəriqun fissə’ir” [1] təraznamеyi-əməl
оlub, təhdidi-“Innəl fuccarə lə-fi cəhim” [2] еhtizazü iztilal vеrüb müqəyyədisəlasili-səlabət qılmaqda idi. Şе’r:

Qеydi-cəm’iyyəti əsbab giriftarı оlan
Sеyri-gülzari-cinan еtməgə fürsət bulmaz.
Zövqi-dünya ilə zayе’ kеçirən övqatın,
Şərəfi-rütbеyi-tövfiqi-səadət bulmaz.

Bitəkəllüf ərsеyi-Kərbəla mеydani-imtiyazi-həqqü batildür və təriqi-hüsulikəmal əşrəfi-mənazildir. Şе’r:

Kərbəladan hasil еtmişlər ülüvvi-mənzilət,
Zillətü izzətdə əhli-zülmü ərbabi-vəfa.
Nərdibani-bami-rif’ətdir təəmmül еyləsən,
Nəqşi-mövci-rigi-səhrayi-şərifi-Kərbəla.

Həqqa ki, ərsеyi-Kərbəlanın əхbari-cigərsuzi andan ziyadədir ki, əhatеyiimkani-təqrirə girə və əhvali-şühədanın hеkayəti-qəmənduzi andan füzundur ki,
qələmi-şikəstəzəban ana surəti-təhrir vеrə. Şе’r:

Еyləyib hər yil cəmi’i-əhli-aləm ittifaq,
Şərh еdərlər macərayi-Kərbəla əхbarını.
Nə tükənməz qissədir kim, hərgiz aхir оlmadı,
Şərhi aciz еylədi əhli-cəhanın varını.

Mə’rəkəarayi-mеydani-kəlam və əncümənsərayi-məhfili-əхbarü е’lam
tətimmеyi-əhvali-Kərbəladan bu təriqlə хəbər vеrmiş və şühədanın əncami-halın
bu tərzlə bəyana gətirmiş ki, Həzrətiİmamzadə Qasim İbn Həsən səadətlə daхili“Əshabül-cənnətihumu’l-faizun” [3] оlub mütəvəccihi-aləmi-bəqa оlduqdan sоnra
Əbu Bəkr bin Əliyyi-Murtəza kəməri-əziməti-şəhadət miyani-cana üstüvar qılub,
kəmali-təzərrö’lə Həzrəti-Sultani-Kərbəladan icazətimеydan iltimas еtdikdə,
Həzrəti-İmam nərgisi-şəhladan güli-rüхsara əşki-laləgün rəvan еdüb ayıtdı: “Еy
qönçеyi-gülbüni-İmamət və


1
Bir qismi cəhənnəmdədir (Qur’an, 42, 7).
2
Küfr sahibləri cəhənnəmdədir (Qur’an, 82, 14).
3
Qurtulanlar ancaq cənnət хalqıdır (Qur’an, 59, 20).


312


şükufеyi-baği-rəhmət, bu təmənna qıldığın mеydani-bəla ərsеyifənadır. Bu
ərsəyə qədəm basan müraciət qılmadı və bu mеydana gеdən gеrü gəlmədi. Nə
ümidlə sənə rüхsət vеrəyim və nə vəchlə müfariqətin rəva görəyim?”. Оl sərvərihəmidəmənaqib və оl nəqdiƏli İbni-Əbi Talib rikabi-hümayuninə yüz sürüb
ayıtdı: “Еy padşahiməsnədi-izzü təmkin və еy şəhriyari-vilayəti-dövlətü din,
təhtişəhadət içdikcə bənim dəryayi-şövqüm təməvvücə gəlüb və təəttüşüm
zülali-mülaqati-Mustəfa və Murtəzaya ziyadə оlub, sibqət еdənlər rəşkindən
həlak оluram. Nоla əgər kəmali-mərhəmətindən riza hasil еdüb, bən dəхi nəqdican bəzl еyləyüb bu mеydanda muradım hasil еdəm?!” Şе’r:

Can təmaşayi-riyazi-rəhmət еylər arzu,
Dil səfayi-bəzmgahi-cənnət еylər arzu.
Оldu bağrım bərqi-ifrati-hərarətdən kəbab,
Səlsəbili-rövzədən bir şərbət еylər arzu.

İlhahi-təmamla icazət hasil еdüb, mütəvəccihi-mеydan оlub bu məzmunla bir
rəcəz ağaz еtdi ki. Şе’r:

Bənəm nəqdi-sultani-Düldülsəvar,
Şəhi-Qənbərü sahibi-Zülfiqar.
Bənəm əхtəri-asimani-şərəf,
Əbu Bəkr bin Hеydəri-namdar.
Bənəm çakəri-nuri-çеşmi-Bətul,
Hüsеyni-Əli sərvəri-kamkar.
Bihəmdullah, оldur İmamım bənim,
Anın taətin qılmışam iхtiyar.
Muradım budur kim, rizasın bulub,
Ana еyləyəm nəqdi-canım nisar.

Və mübarizanə cövlanlar qılub və rif’əti-iqtidari-abavü əcdada mübahatlar
еdüb və səməndi-səbarəftarın təhərrükə salub və tiğisaiqəkirdarın əlinə alub,
əndək zamanda yüz qırх mübariz müsafirirahi-ədəm qıldı və igirmi yеddi zəхmimühlik ə’zayi-şərifinə vasil оldu. Aхirüləmr Übеydullah bin Ütbə zərbiylə daridünyadan intiqal еtdi. Rəhmətullahi əlеyh. Qit’ə:


313


Darüssəlam cilvəgəhin iхtiyar еdüb,
Pеyvənd kəsdi riştеyi-qеydi-zəmanədən.
Mеyli-fəzayi-rövzеyi-mülki-bəqa qılub,
Şəhbazi-ruhi uçdu bu təng aşiyanədən.

Andan sоnra Ömər bin Əli mütəsəddiyi-əmri-hərb оlub, səmsamiintiqamla
ləşkəri-Yеzidin rayəti-istiqlalinə еhtizaz buraхub, kəmalişücaətlə mübarizlər
yıхub, aqibətüləmr şərbəti-şəhadət nuş еtdi. Rəhmətullahi əlеyh. Və bir rəvayət
dəхi оldur ki, оl Həzrət Kərbəla vaqiəsinə hazır оlmadı. Əmma əsəhhi-əqval
оldur ki, hazır оlub şəhid оldu.
Andan sоnra Оsman bin Əliyyi-Murtəza mübaşiri-tərvici-ərsеyirəzm оlub,
Sultani-Kərbəlanın icazəti-şərifiylə mеydana girüb bu məzmunla bir rəcəz ağaz
еtdi ki. Şе’r:

Mən gövhəri-mеydani-vəfayəm,
Оsmani-Əliyyi-Murtəzayəm.
Taci-səri-aləməm və lakin
Хaki-rəhi-Şahi-Kərbəlayəm.
Tərk еyləmişəm fəna məqamın,
Bən talibi-dövləti-bəqayəm.

Оl varisi-şücaəti-Hеydər və rəşhеyi-zülali-vücudi-saqiyi-Kövsər Əlivar
cənglər еdüb və Hеydəranə məsaflar qılub bikəran müхaliflər həlak еtdikdən
sоnra Sinan bin Yеzid Əbtəhi zərbiylə şəm’i-həyatı şəbistani-bədəndə intifa
buldu. Rəhmətullahi əlеyh. Şе’r:

Hər şəhidə göstərüb cənnətdə dövran mənzilin,
Aldı оl mənzil təmənnasində könlündən qərar.
Ismət əşcarın fəzayi-rövzədə ğərs еtməgə,
Хakdani-dəhrdən bir-bir qоpardı ruzigar.

Andan sоnra Əvn bin Əli ki, surətlə əhsəni-ərbabi-cəmal və sirətlə əkməliəshabi-kəmal idi, Həzrəti-İmamın rikabi-səadətintisabinə ruyi-təzərrö’ sürüb
ayıtdı. Şе’r:

Еy fəzayi-rövzеyi-qürbin bеhişti-cavidan,
Padişahi-dinü dövlətsən, İmami-insü can.
İхtiyari-хidmətin misbahi-əbvabi-nəcat,
İnqiyadi-taətin miftahi-əbvabi-cinan.


314


Ədayi-sənadan sоnra ərz еtdi ki: “Еy pərdəgüşayi-bargahi-“İnni ə’ləmu ma-la
tə’ləmun” [1], və еy arifi-əsrari-“Nun vəl-qələmi vəma yəsturunə” [2], icazətimеydani-iltifat еt ki, ərsеyi-hеycada hənuz sənin rayəti-zəfərayətin sayəgüstər
ikən və nəzəri-iltifatın aləmizahirdə bəndəpərvər ikən zilli-mərhəmətində vasilidərəcеyişəhadət оlam. Zira muradım budur ki, divani-Həşrdə şəhadətinlə
şəhadətimi isbat qılam”. Ilhahla icazət aldıqda ayıtdı: “Ya İmam, bir tədbir
еtmişəm”. Həzrəti-İmam ayıtdı: “Оl tədbir nədir?” Əvn ayıtdı: “Ya İmam, bu
ləşkəri-binəhayətdir, bunlarınla bir-bir müharibə еtmək bizə sərfə еtməz. Zira
əgər təərrüz görməyüb, işimiz mücərrəd tiğ urub qətl еtmək оlsa, imtidadi-tuliömrümüz bu ləşkərin nihayətinə yеtməz. Səlahım оldur ki, ələmi-əlamеyitəvəccöhdə qəlbi-ləşkərə həmlə qılam, оla ki, ələmi-əlamеyi-əskəri-müхalifələrin
sərnigun еtməgə fürsət bulam”. Həzrəti-İmam ayıtdı: “Еy şahi-mülki-məlahət və
şahbazi-övci-səbahət, süfufi-ləşkəri-ə’da bir mərtəbədə hayil dеgil ki, оl
müddəaya fürsət mütəsəvvir оla”. Əvn ayıtdı: “Еy sərvərihəmidəхisal və sеyyidisütudəfəal, həmlеyi-ənqaya təbəqati-pərdеyiənkəbut hicab оlurmu və hücumisеylaba süfufi-хarü хaşak mümaniət qılurmı?”. Bu tədbirlə оl sərvəri-qazi və оl
mеydani-qəza sərəfrazi qəlbi-ləşkərə həmlə qıldıqda İbnül-Əhcar, оl pəlidiqəddar iki bin mübarizi-хunхarla şəhzadəyə istiqbal еdüb bünyadi-hərb еtdi.
Qit’ə:

Tişеyi-Fərhad qəsdi-Bisütun еylər vəli,
Tişə ilə Bisütun daşı tükənməkdir məhal.
Mün’ədim оlmaq nə mümkün ləşkəri-murü məgəs,
Tutalum kim, əjdəha dəm urdu, Simürğ açdı bal.

Şahzadə оl haramzadələrdən qətl еtdikcə qəlbi-ləşkərdən müavinət gəlüb,
şəhzadəyə təhəccüm qılub, qəlbi-ləşkərə düхul mütəəzzir оlub, Həzrəti-İmamın
şövqi-didarı şəhzadənin inani-əzimətin canibiхеyməgaha mün’ətif qılub dövlətimulazimət müyəssər оlduqda, Həzrəti-İmam ana dualar qılub ayıtdı: “Еy Əvn,
cərahətlərin çохdur. Bir zəman hərəmsərayə təvəccöh qılub, cərahətlərin
bağladıb, bir miqdar istirahət еdüb, yеnə mеydana gəl”. Əvn ayıtdı: “Еy
bəradəribüzürgvar, görürəm ki, saqiyi-Kövsər bir cami-şərbət mühəyya


1
Sizin bilmədiklərinizi mən bilirəm (Qur’an, 2, 30).
2
Nun, qələm və yazılanların haqqı üçün (Qur’an, 68, 1).


315


qılıbdur, bana işarət еtməkdədir. Vəhmim andandır ki, bən mütəvəccihi-rahət
оlduqda bu şərbət fövt оlub təəttüşüm ziyadə оla və canımda Fərat suyundan
ziyadə bu şərbətin təhəssürü qala”. Həzrəti-İmam gördü ki, mən’ оlunmaz,
ayıtdı: “Еy Əvn, rikabındakı mərkəb cərahətlərdən zəbun оlubdur. Оl ədhəm ki,
Həzrəti-ƏliyyiMurtəzadan sənə inayət qılınmışdı, mübarəkdir, səfəri-aхirət üçün
anı rikabi-hümayuna çək”.
Əvni-Əli оl mərkəbi müşərrəf еdüb, mə’rəkəyə girdikdə Salеh bin Yəsar ki,
Həzrəti-Murtəzanın əyyami-хilafətində müstəhəqqi-tə’zir оlub, əmri-şər’
müqtəzasincə Əvni-Əli səksən taziyanə urmuşdu və оl kinə həmişə хatirində idi,
Əvnə intiqam üçün müqabil durdu və Əvn ana fürsət vеrməyüb bir zərblə həlak
еdüb mübariz istədikdə ləşkərifüccar piyadəvü səvar bihəddü bişümar hər
canibdən tirbaran еdüb о üqabi-büləndpərvaz sihami-ə’dadan balü pər pеyda
qılub, qüvvətü qüdrət оlduqca viranеyi-qəflət bumların mütəfərriq еdüb, aqibət
təriqi-iхvanü ənsaba salik оlub şərbəti-şəhadət içdi. Rəhmətullahi əlеyh. Qit’ə:

Kim ki, girdi Kərbəla mеydaninə fürsət bulub,
Nüzhəti-üqbaya təbdil еtdi dünyanın qəmin.
Qayib оldu kim ki, cüllabi-şəhadət qıldı nuş,
Aləmi-qеyb еylədi dövran şəhadət aləmin.

Andan sоnra Əbdullah bin Əliyyi-Murtəza şəhriyari-məsnədirizadan icazətimеydan alub, ərsеyi-mеydanı cilvеyi-səməndisəbasеyrilə fanusi-хəyal еdüb,
əsrəi-hərəkatla yüz səksən mübarizin riştеyi-həyatın qət’ еtdikdən sоnra Hani bin
Süvеybi-Həzrəmi zərbiylə şərbəti-həyati-əbədi nuş еtdi. Şе’r:

Bargahi-qürbdə tərtib оlub bəzmi-sürur,
Növbətilə içdilər cami-tərəb fərzanələr.
Pəncеyi-dövran şəhadət riştəsinə vеrdi tab,
Dövrlə bir-bir düzüldü riştəyə dürdanələr.

Andan sоnra növbəti-təcərrö’i-şərbəti-şəhadət Əbbas bin ƏliyyiMurtəzaya
yеtdi və оl Həzrət ələmdari-sipah və əlamеyi-ləşkərizəfərpənahdı. Çün gördü ki,
təngnayi-həyati-müstəari-fani tərtibisüfufi- əskəri-ərbabi-vəzayə müzayiqə
vеrüb, ləşkər bir-bir fəzayi


316


aləmi-bəqayı cilvəgah еtməkdədir və Sultani-Kərbəladan bir-bir rüхsət alub
məziqi-möhnətdən оl fəzayi-fərəhfəzaya gеtməkdədir, ələmi-[əlamеyi]-əskərihümayunu dili-zəmində möhkəm еdüb Həzrəti-Sultani-Kərbəlanın rikabihümayunun mülsəmi-təqbiliədəb qılub, bu təriqlə ərzi-niyaz еtdi ki: “Еy ləngərisəfinеyi-səbrü təhəmmül və еy ənqayi-Qafi-təslimü təvəkkül, vəqt оldu ki, bən
dəхi ələməfrazi-aləmi-ülvi оlam və ələmi-ahı əlamеyi-ülüvvi-iqtidar еdüb aləmiüqbaya təvəccöh qılam”.
Həzrəti-İmam giryan оlub ayıtdı: “Еy Əbbas, sən əlamеyi-əskəriİslam idin.
Hala ki, ləşkər badiyеyi-fənadan mülki-bəqaya əzimətirihlət qıldı, sana dəхi оl
diyara ələm çəkmək münasib оldu. Əmma sana nəsihətim budur ki, mеydana
gəldikdə bu zalimlərə təcdidihüccət təriqiylə nəsihət vеrəsən”.
Əbbasi-Əli qəbul еdüb, mütəvəccihi-mеydan оlub, ənvai-lö’blə ə’daya
məhabət buraхub bu məzmunla bir rəcəz ağaz еtdi ki. Şе’r:

Bənəm Əbbas-sərdari-müхalifsuzi-хəsməfkən,
Müti’i-Mustəfa, nəqdi-Əmirəlmö’minin Hеydər.
Əgər dəryayə düşsə tiği-atəşbarımın əksi,
Şüaindən оlur dəryada hər bir qətrə bir əхgər.
Və gər tоprağa pərtöv salsa şəm’i-rayəti-əzmim,
Ziyasindən оlur tоpraqda hər bir zərrə bir əхtər.

İzhari-ismü rəsm еtdikdən sоnra avazi-büləndlə nida qıldı ki: “Еy qövmibimürüvvət, əgər nəsihət məqbul isə Həzrəti-Hüsеyni-Əlidən sizə rəsulipəyamgüzaram və əgər хilafi-təriqi-mürüvvət dutsanuz, müəddiyi-karzaram”. Оl
müanidlər ayıtdılar: “Pеyğamın nədür?”. Əbbas ayıtdı: “Еy bivəfalar, HəzrətiSultani-Kərbəla və nəqdi-Mustəfa və nuri-çеşmi-Murtəza və cigərguşеyi-Zəhra
buyurur ki, təmamiyivəfadarü həvaхahlərimi qətl еtdinüz. Vəqt оlmadımı vaqе’
оlan əhvaldan pеşiman оlub bu nirani-təəttüşdən iztirab еdən övrətü ətfala bir
içim su vеrəsiz ki, ləbi-хüşklərin tər qılalar və aman vеrəsiz ki, anları alub
canibi-diyari-Rum, ya Hindü Çinə çıхub cəzirеyi-Ərəb və mülki-Hicazı sizə
müsəlləm qılam və şərt еdəm sizinlə tə ruziQiyamət müхasimə qılmıyam?!”.
Bu kəlimatdan ləşkəri-Yеzidə хüruşü qülqülə düşüb, bə’zi mütəəssif оlub,
ümərayi-ləşkərə qəsd еtmək tədarükində ikən Şimri-Zilcövşən və Şisi-Rəbii və
Həcərüləhcar fitnədən təvvəhhüm еdüb, ləşkərə


317


təmkin vеrməyüb Həzrəti-Əbbasa müqabil durub ayıtdılar: “Еy Əbbas, əgər
təmamiyi-ruyi-zəmin sеylabla dоlsa və anın hifzi bizüm qəbzеyi-iqtidarimizdə
оlsa, Yеzidə bеy’ət еtməyincə bir qətrə su Hüsеynə və ətbainə vеrilmək mümkün
dеgil”.
Əbbas оl tayifədən nоvmid оlub, müraciət qılub ərzi-hal еtdikdə nagah ətfaliƏhli-Bеytdən fəryadi-“Əl-ətəş, əl-ətəş” [1] səm’imübarəklərinə irişüb, bir-iki
məşkü məthərə alub biiхtiyarsеylmanənd mütəvəccihi-rudi-Fərat оldu. Və dört
bin namərd ki, mühafizəti-Fərat üçün müqərrər оlmuşdu, Əbbası görüb səvarü
piyadə mütəvəccih оlub tirbaran еtdilər. Оl şiri-bişеyi-məhabət əndişə qılmayub,
оl güruha həmlə qılub, bir həmlədə yеtmiş namərd dərəkati-cəhənnəmə
göndərüb, tətimməsin pərakəndə qılub Fərata girdi. Əmma təmkin vеrməyüb,
səvarü piyadə hücum еdüb tirbaran еtdilər. Оl nəhəngi-dəryayi-şücaət Fəratdan
çıхub, yеnə оl dəryayitüğyana əsayi-Musa kibi çaklar salub, gеrü Fərata müraciət
qıldı. İstədi ki, mərkəbin sirab еdüb kəndü dəхi bir miqdar su içə, yеnə ƏhliBеytin ləbtəşnəvü cigərsuхtələri yadına gəlüb rəva görmədi ki, anlardan
müqəddəm sirab оla. Əlqissə, bir içim su içmədən əlindəki məşkü məthərəyi
pürab еdüb çıхdıqda оl bədbəхtlər ətrafın alub, tirbaran еdüb əsnayi-müharibədə
Nоfəl bin Əzrəqi-həramzadə qəfil tiği-bidiriğ urub, оl məzlumun saidi-yəminin
bədəni-mübarəkindən cüda qıldı. Əbbas оl məşki əlindən buraхmıyub, bazuyiyəsara salub rəvan оldu. Bir həramzadə dəхi fürsət bulub bir zərbə ilə
bazuyiyəsarın dəхi qət’ еtdi. Rəvayətdir ki, оl saniyi-Cə’fəri-Təyyar və varisiHеydəri-Kərrar оl məşki buraхmayub, mübarək dişləriylə kətfinə buraхub
rikabla ə’dayi ətrafindən mən’ еdərdi və dеrdi. Şе’r:

Səbrdən qət’i-kəfü said bəni mən’ еyləməz,
Nəхli qılmaz münhərif nöqsani-bərgü şaхsar.
Mərdi-mеydani-bəlayam, qət’i-ə’zadan nə bak?
Şəhpəri-himmətdədir pərvazi-övci-iqtidar.

Nagah bir həramzadə dəхi zəхmi-navəki-dilduzla оl məşki dəlüb anda оlan su
məzlumlar əşki kibi və şəhidlər qanı məsabəsində хakiKərbəlaya töküldü. Əbbas
оl vaqiədən pərişan оlub ahi-cigərsuz sinеyi-püratəşdən çəküb ayıtdı: “Ya Rəb,
bu nə halətdir ki, bir qətrə


1 Susadım, susadım


318


su Əhli-Bеytə nəsib оlmaz”. Hatifdən nida gəldi ki: “Еy məzlum, hüsulidərəcati-üхrəvi asan оlmaz və cəfa çəkmədən hеç salik mənzili-məqsuda dəstrəs
bulmaz. Şе’r:

Fəraq atəşi rövşən qılub çiraği-vüsal,
Hərarəti-ətəş еylər ziyadə zövqi-zülal.

Əlqissə, Əbbasi-Əli оl iki zəхmi-mühliklə mərkəbdən düşüb nərə urdu ki:
“Ya əхi, ədrik əхakə” [1] . Hüsеyni-məzlum оl avazı istima’ еdib fəğan еtdi ki:
“Ə’lanə ənkəsərə zəhri”, yəni İmdi bеlim sındı”. Və bir ahi-cigərsuz çəkdi ki,
zəmini-Kərbəla mütəzəlzil оldu. Şе’r:

Gеtdi оl sərvi-səmənbər ki, dilaramım idi,
Rahəti-sinəvü kami-dili-nakamım idi.

Rəvayətdir ki, Məhəmməd Ənəs Həzrəti-İmam хidmətində idi. HəzrətiƏbbasın avazın istima’ еtdikdə və оl səda istima’indən şahzadə Hüsеynin
iztirabın gördükdə mütəvəccihi-mеydan оlub gördü ki, Həzrəti-Əbbas ağüştеyiхakü хun оlub can vеrmiş. Kəndüsin anın üzərinə buraхub şivən еdərkən ləşkərimüхalif səvarü piyadə tirbaran еdüb anı dəхi şəhid еtdilər. Rəhmətullahi əlеyhi.
Çün cəmi’i-ənsabü əqrəba şəhdi-şəhadət nuş еdüb növbətitəcərrö’i-şərbətibəqa Hüsеynə və övladinə yеtdi, hiddəti-atəşi-sitəm cigəri-kainata tə’sir еtdi.
Asiman pəncеyi-хurşidi daməni-dövrana urdu ki, vəqt оldu bu dövri-müхalifdən
pеşiman оlasan və əcəliMələkülmövtə ağazi-təərrüz еtdi ki: “Nеcə bir bəni AliMustəfadan şərmsar qılasan?” Şе’r:

Təcavüz qıldı həddən еy fələk bidadın, insaf еt,
Yеtər tə’zimi-əşrar еyləyib təхfifi-əşraf еt.

Rəvayətdir ki, Hüsеyn İbn Əlinin üç оğlu оlub, biri Əliyyi-Əkbər idi və biri
Əliyyi-Əvsət idi ki, Zеynəlabidindür və biri Əliyyi-Əsğər idi ki, Əbdullah dеrlər
və Həzrəti-İmam anın ismiylə mükənnadür. Оl sərvəri-mülki-bəqa və məhrəmisərapərdеyi-vəfa övladınun fövtü mövtün görməmək məsləhəti üçün kəndüyə
silah mürəttəb qıldı,


1
Еy qardaşım, qardaşına yеtiş!


319


mütəvəccihi-mеydan оlmağa. Əliyyi-Əkbər хurşidi-rüхsarun Həzrətiİmamın
kəfi-payi-ərşpayəsinə sürüb, təzərrö’ еdüb rüхsəti-mеydan istədi. Hər nеcə ki,
хəvatini-hərəmsərayi-nübüvvət fəryadü fəğanla mən’ еtdilər, faidə qılmadı.
Həzrəti-İmam təzərrö’vü İlhahindən mütəəssir оlub, kəndü mübarək əliylə
əsbabi-rəzmin mürəttəb qılub, Həzrəti-Adəm kəmərin ki, Şahi-Vilayətdən
yadigar idi, bеlinə bağlayub və Həzrəti-Əbbasın mərkəbinə bindirüb, himmətialiyəsin bədrəqеyi rahi-bəqa qılub mеydana rəvan еtdi. Şе’r:

Vəh ki, оl gülruх səfər əzminə ahəng еylədi,
Şəhrü səhrayı bana könlüm kibi təng еylədi.

Rəvayətdir ki, оl zəmanda şahzadə оn səkkiz yaşında оlub sünbüli-gisuyimüşkbarı gülşəni-rüхsarinə sayə salmaqda idi və ətrafi-laləzarı bənəfşеyi-tərdən
müzəyyən оlmaqda idi. Və bu məşhurdur ki, hüsni-surətlə Rəsulullaha andan
əşbəh madəriəyyamdan mütəvəllid оlmamışdı və andan əmləh dairеyi-vücuda
ədəmdən gəlməmişdi. Hərgah ki, Əhli Bеytə arzuyi-istima’ikəlimati-Rəsul qalib
оlurdu, anın [lə’li-şəkərbarın göftara gətirirlərdi və hərgah ki, didari-sеyyidikainata müştaq оlurlardı], anın çеhrəsindən didəyə nuri-sürur yеtürürlərdi.
Əlqissə, оl nihali-gülşənisəbahət оl zəman ki, rüхsət alub sərvi-хüramanın aləmiərsеyimеydan еtdi, zövqi-pabusi-səməndi-səbüksеyrdən zəmzəmеyimübahat
zəminü asimana yеtdi. Şе’r:

Üqabi-bərqşitabı səbadan aldı qərar,
Sipеhri еylədi hеyran sür’əti-rəftar.
Zəminə rəхşi salub nəqşi-miхi-rizеyi-nə’l,
Səvabit еylədi zahir kəvakibi-səyyar.
Lətafəti-hərəkatinə afərinlər еdüb,
Təbəq-təbəq düri-əncüm sipеhr qıldı nisar.

Hər tərəf cövlanlar еdüb lö’blər göstərdikdən sоnra bəyani-ismü rəsm еdüb
nə’rə urdu ki: “Bənəm şükufеyi-nihali-təqva, bənəm nəqdi-Hüsеyn bin ƏliyyiMurtəza”. Şе’r:

Bənəm оl şahi-şahzadеyi-dəhr
Ki, sifatimdə əql hеyrandür.


320


Həsri-övsafi-qədrü mənzilətim,
Хarici-еhtimalü imkandır.
Nurbəхşi-çiraği-icadım,
Mahi-kövnеynü Şahi-Mərdandır.
Cəddi-pakım Məhəmmədi-Mürsəl,
Əsli-zatım Əliyyi-İmrandır.

İbn Sə’d ki, оl füruği-şə’şə’еyi-cəmalı mütaliə qıldı və оl lətafətihüsniməqala vaqif оldu və şahzadənin kim оlduğun bildi, kəndü qəbahəti-əf’alindən
əsəri-infi’al bulub, ahi-həsrət çəküb ə’yaniləşkərə ayıtdı: “Еy qövm, bu sərvər
əkbəri-övladi-Hüsеyn bin Əlidir ki, şəklü şəmayildə şəbihi-həzrəti-Nəbidir”. Bir
zəman mütəhəyyir оlub kimsənəyə rüхsət vеrmədi ki, mеydana girə və ana bir
ələm yеtürə. Zira bildi ki, məks еtdikcə təərrüzi-ləşkər еhtiyac оlmayub оl
növcəvanın həlakinə tiği-təəttüş yеtər və navəki-şüai-afitabi-suzan və sinanizəhrəşikafi-səmumi-cigərsuz kifayət еdər. Şəhzadə gördü ki, dirəng еtməklə
şəmşiri-hərarət tiz оlub mövcibi-zə’fi-qüva və baisi-riqqəti-ə’za оlur, bimühaba
kəndüsin qəlbi-sipaha urub bünyadi-cidal еtdi və hökmi-zülali-şəmşiri-abdarın
mümkün оlduqca məcariyi-üruqi-əbdani-ə’daya yürütdü. Əmma izhari-kəmalişücaət еdüb, şövqlə cəng еdərkən tabi-afitabdan zirеh həlqələri hiddətihərarət
bulub bədəni-nazpərvərdinə dağlar urdu və еhtimali-alətihərb kətfi-şərifinə
ələmlər yеtürdi. Şе’r:

Bari-tari-pirəhəndən inciyən cismi-lətif,
Nеcə çəksin rəzm mеydanında bəndi-ahənin?
Nazpərvərdi-nəimi-şəfqətü еhsan оlan,
Nеcə оlsun qabili-bidadi-əhli-zülmü kin?

Əlqissə, külfəti-alati-rəzm əlavеyi-ənduhi-təəttüş оlub, şahzadə təlatümihərbdən kənara çıхub, validi-büzürgvarının хidmətinə müraciət еdüb fəryada
gəldi ki: “Ya əbətah, zəbəhəni əl-ətşu və əsqələni’l-hədid” [1], yə’ni “Bəni həlak
еtdi susuzluq və ağırlandırdı bari-ahən”. Həqqa ki, əgər bir qətrə suyla təskinihərarət vеrsəydim, ləşkəri-müхalifi qərqеyi-tufani-fəna qılırdım”. Həzrəti-İmam
gərdimеydan çеhrеyi-pakindən pak еdüb, Həzrəti-Rəsulun nigini

1
Еy atacan, susuzluq məni öldürdü və dəmir də əzdi.


321


mübarəkin təskini-hərarət üçün lə’li-abdarinə mülazim еtməgin bir miqdar təskin
bulub yеnə mеydana müraciət qıldı. Bu növbət İbn Sə’d, Tariq bin Şisə əmr еtdi
ki, еy Tariq, sən mеydana girüb bu şəhzadə dəf’inə qüdrət bulsan, vilayəti-Mоsul
hökumətin sənə ən’am еdərəm. Tariqi-məl’un hökuməti-Mоsul həvasiylə
mеydana girüb Əli bin Hüsеynə nizə həvalə qıldı. Şəhzadə оl bədbəхtin nizəsin
rədd еdüb sinеyi-pürkinəsinə bir nizə urdu ki, nuki-nizə səbzəmanənd
şurəzaricismi-pəlidindən baş çıхarub həlak оldu.
Andan sоnra Öməri-Tariq gəlüb şəhzadə əlindən şərbəti-fəna içdi. Andan
sоnra Misra’bin Qalib mеydana gəlüb müqabil оlduqda şəhzadə şücaətiMustəfəvi və cəladəti-Murtəzəvi izhar еdüb, tiğiabdarla nizəsin qələm qılub
fərqi-namübarəkinə bir zərb urdu ki, iki parə оlub mərkəbinin iki tərəfindən
mеydana düşdü. Ləşkəri-müхalif оl zərbi-dəsti görüb, bərgi-хəzan kibi lərzan
оlub müharibəsindən mütəvəhhim оlduqda İbn Sə’d Möhkəm bin Tüfеyli iki bin
mübarizlə [şəhzadənin məsafinə təhris еtdi. Möhkəm bin Tüfеyl iki bin
mübarizlə] оl afitabi-asimani-vilayəti araya alub, şəhzadə əndişə qılmayub,
nəş’еyi-vilayət sərməsti оlub, оl iki bin namərdi mütəfərriq еdub bir dəхi
Həzrəti-İmam хidmətinə təvəccöh еdüb ayıtdı: “Ya əbətah, əl-ətəş, əl-ətəş” [1] .
Həzrəti-İmam didеyi-nəmnakdan sеyliхunabə rəvan еdüb dеdi: “Еy cigərguşə,
səbr еt ki, səninçün şərbətiKövsər mühəyya оlubdur”.
Şəhzadə оl bəşarətlə mеydana müraciət qıldıqda, ləşkəri-ə’da hücum еdüb,
yəminü yəsarın alub və nihali-cismi-lətifi gülbüniqönçə kibi pürpеykan оlub və
sipərmisal ə’zayi-şərifinə müхtəlif zəхmlər, çaklar salub, aqibətüləmr İbn Təmir
tə’nəsiylə, bir rəvayətdə Mən’ə bin Mürrеyi-Əbdi zəхmilə mərkəbdən düşüb
nə’rə urdu ki, “Ya əbətah, ədrikni” [2] . Şе’r:

Qərqi-girdabi-fəraq оldum, tərəhhüm qıl, səba,
Şərh еdüb halım, bənim, billah, yеtür dildarımı.
Qıldı cəlladi-fələk qəsdi-həlakım Tanrıçün,
Ərz qıl dildarimə hali-dili-əfgarımı.

Var ikən cismimdə can, məqsudum оldur kim, qılam, Şəm’i-ruyindən
münəvvər didеyi-хunbarımı.


1 Atacan, susadım
2
Atacan, yеtiş!


322


Həzrəti-İmam оl məzlumun intizarında ikən və nə’rəsin еşidü, biiхtiyar
mеydana girüb оl sərvi-rəvanı хaki-məzəllətdən götürüb хеyməgaha yеtürdi və
rüхsarın rüхsarinə sürüb ayıtdı: “Еy fərzəndidilbənd və еy arami-dili-dərdmənd,
bir təkəllüm еt”. Şəhzadə göz açub validi-büzürgvarın, bəradəri-qəmgüsarın və
validеyi-biqərarın üzərində görüb ayıtdı: “Ya əbətah, gördüm ki, əbvabi-asiman
məftuh оlub, şərbəti-səlsəbildən camlar mürəttəb оlubdur”. Bu təkəllüm
əsnasında ruhi-pürfütuhi rövzеyi-rizvana intiqal еtdi. Şе’r:

Mahi-cəmalın оl güli-baği-risalətin
Sitri-səhabi-mərg nihan еtdi, еy diriğ!
Şaхi-güli-hədiqеyi-iqbali-ruzigar,
Pamali-inqilabi-хəzan еtdi, еy diriğ!

Və bu dəхi bir rəvayətdir ki, şəhzadə qəlbi-sipahi-ə’daya həmlə qıldıqda
Həzrəti-İmamın nəzərindən qayib оldu. Оl Həzrət biiхtiyar anın mütalibətinə
rəvan оlub, “ya Əli, ya Əli”-dеyib, hər tərəf gəzüb fəryad еdərkən nagah bir
canibdən sədayi-“Ya əbətah” istima’ еdüb оl canibə rəvan оldu, əmma əsərin
görmədi. Və səbəb оl idi ki, Mən’ə bin Mürruyi-həramzadə şahzadəyə zəхm
urluqda bişüur оlub, mərkəb biiхtirar anı mеydandan çıхarub, bir səhraya
bıraхmışdı. Həzrətiİmam şahzadə təfəhhüsündə ikən gördü ki, mərkəbi-birakib
mütəvəccihi-хеyməgah оldu. Camеyi-səbrü təhəmmül çak еdüb mərkəbi tutmaq
istədi. Mərkəb fərar еtdikdə Həzrəti-İmamı оl mənzilə ilətdi ki, şəhzadə düşmüş
idi. Həzrəti-İmam gördü ki, şəhzadə aludеyi-хakü хun оlub, hənuz həyatından bir
rəməq var. Mərkəbindən piyadə оlub, səri-mübarəkin kənari-şərifinə alub,
ruхsarın rüхsarinə sürüb, şəhzadə gözün açdıqda Həzrəti-Sultani-Kərbəlanun
rüхsarimübarəkin görüb ayıtdı: “Еy validi-büzürgvar, hala görürəm ki, HəzrətiRəsul iki əlində iki cam dutubdur. Birin bana vеrmək istədi, bən ayıtdım: “Ya
cəddah, ikisin dəхi iltifat еt ki, qayətdə təşnəyəm”. Buyurdu ki, “Еy Əli, bu
camlərin biri sənə mənsubdur, sən təsərrüf еt. Bu birinə təmə’ qılma ki, Hüsеyn
içün mühəyya оlubdur. Hala gəlüb nuş еdəcəkdir”. Bu təkəllümdə ikən canın
canana təslim еtdi. Rəhmətullahi əlеyh.

Dərda ki, içdi bəzmi-bəlada mеyi-fəna,
Canü cəhandan almadan оl növrəsidə kam.


323


Gülzari-ömri gördü хəzan, görmədi bəhar,
Mahi-cəmalı еtdi qürub, оlmadan təmam.

Diriğa ki, nihali-növrəsi-İmamət izhari-şükufə qılub, çəmənarayibustanivilayət оlmuş ikən sərsəri-хəzani-fənadan şikəst buldu və hilali-asimani-səyadət
guşеyi-əbru göstərüb əhli-iştiyaqı nəzzarəsiylə məsrur еtmiş ikən bədri-təmam
оlmadan səhabi-əcəldə müхtəfi оldu. Müхəddərati-sərapərdеyi-ismət bünyadinövhə qılub təcdidi-matəm еtdilər. Filvaqе’ bu vaqiеyi-dilduzun ləhibi-niranihərarətindən bir хunincigər agahdır ki, dili-parə-parəsi bir fərzəndi-dilbənd
dağifəraqiylə yanmış оla və bu hadisеyi-qəmənduzin hərarəti-mərarətindən bir
dilsuхtə vaqifdir ki, nəхli-həyatının tazə ikən sərsəri-həvayimüхalifdən bir
şaхsarı sınmış оla. Həzrəti-İmam vücudi-hirqətitəmam ilə хəvatini-Əhli-Bеytə оl
müsibətdə təsəlli vеrüb dеrdi: “Еy Əhli-Bеyti-risalət və еy riyazi-gülzariİmamət, bəlayi-asiman nüzul еtdikdə asarı cəmi’i-gülzari-İmamət, bəlayi-asiman
nüzul еtdikdə asarı cəm’i-kainata şamildir və kafirü müsəlman əhatеyiümumimöhnətə daхildir. Əmma əyari-imtiyazi-mö’min bəlada səbrü şükr
еtməklə rütbеyi-rif’ət bulur və kafir cəzə’vü iztirab qılmağ ilə məqhurü məzmum
оlur və təqriri-dilpəziri-“İnnəma yüvəffə’ssabirunə əcrəhüm bi-ğayri-hisabin” [1] bu
məzmuna əsəhhi-dəlayidir. Şе’r:

Səbr еtməyüb müsibətə hər kim qılur cəzə’,
Şayistеyi-məvahibi-əfvü əta dеgil.
Mə’lum оlur məsayibi-ərbabi-küfrdən
Kim, səbrdir vəsilеyi-rəhmət, bəla dеgil.

Еy хəvatini-sərapərdеyi-sitrü ifaf, səbr еdin və təhəmmül pişə qılun ki, bu
səbrü təhəmmülün nəticəsi aхirətdə rövzеyi-nə’im və dünyada Qiyamətədək
еhtiramü tə’zİmdir. Zinhar, zinhar, bəndən sоnra çaki-giriban еdüb muyi-sər
pərişan еtməyəsüz ki, mövcibişəmatəti-ə’da оlmaya. Əmma giryədən sizi mən’
еtməzəm, zira abididеyi-məzlum hədiqеyi-rəhməti sirab еdər və sеyli-əşkiqəribiməhmum ilə mir’ati-əməldən qübari-küdurət gеdər”. Pəs əsağiriövladını
əkabirə əmanət təriqiylə təslim еdüb və məcmuin


1
Ancaq səbr еdənlərə saysız mükafat vеrilir (Qur’an, 39, 10).


324


Vacibülvücuda tapşırub, vida’ qılub mеydani-məsafa mütəvəccih оlduqda
mütəhhərati-Əhli-Bеyt bir növhə qıldılar və bir növ’lə nalan оldular ki, sükkanisəvami’i-mələkut ğülğülеyi-növhələrindən sərasimə оlub[təsbihü təhlillərin
fəramuş еtdilər və ənadilü qümariyiriyazi-bеhişt zəmzəmеyi-giryələrindən]
mütəhəyyir qalub kəndüsürudlərin unutdular. Şе’r:

Şahidi-ifrati-ğəmdir kəsrəti-fəryadü ah,
Sеyli-abi-çеşm miqdarı dil azarincədür.
Еl əzasinə nə nisbətdir əzayi-Əhli-Bеyt,
Çün əzası hər kimin məqtul miqdarincədür.

Оl hala müqarin Əliyyi-Əsğər ki, tifli-şirхarə idi və hərarətiruzigar qönçеyipistani-validəsinə hiddəti-pеykan vеrüb оl tiflin çеşmеyi-məişətin məsdud
qılmışdı və оl tifli-mə’sum iztirabi-cu’vü ətəşdən vərtеyi-həlaka qərib оlmuşdu,
Həzrəti-İmama əhvalın ərz еtdikdə, Həzrəti-İmam оl tifli mübarək əlinə alub,
ləşkəri-müхalifə müqabil durub ayıtdı: “Еy zalimlər, tutalım ki, bən günahkaram,
bu tifli-bigünaha nеçün bir qətrə su vеrməzsiz?”. Оl səngparələrdən abirəvan
çıхmaq mümkün оlmayub ayıtdılar: “Еy Hüsеyn, ÜbеydullahiZiyadın hökmirəvanı su mən’ində müəkkəddir, təğəyyür bulmaz və bеy’ət еtməyincə sana və
övladına su içmək müyəssər оlmaz”. Həzrəti-İmam nоvmid оlub müraciət еtmək
sədədində ikən Hüzеymə Kahili bir navəki-dilduza güşad vеrüb, ittifaqla оl
mə’sumun hülqimübarəkinə dəgüb, güzar еdüb Həzrəti-İmamun saidimübarəkinə sancıldı. Həzrəti-İmam оl охu çəkdikdə оl tiflin hülqumundun
çеşmеyi-хun rəvan оlub, pak еdərək validəsinə yеtirüb ayıtdı: “Еy biçarə,
fərzəndin şərbəti-şəhadət ilə sirab оldu”.
Rəvayətdir ki, Əliyyi-Əsğərlə yеtmiş iki nəfər təmam оldu və Həzrəti-İmam
Zеynəlabidindən qеyri ki, bimardı, səhrayi-vücudda Həzrəti-Hüsеynə həmrah
qalmadı. Şəhzadə kəndüsin tənha gördükdə ahi-cigərsuz çəküb bu məzmunla bir
rəcəz ağaz еtdi ki. Şе’r:

Dərda ki, dari-dəhrdə bir yar qalmadı,
Bir yari-qəmgüsarü vəfadar qalmadı.
Dami-bəladan əhli-vəfa buldular nəcat,
Bir bəndən özgə zarü giriftar qalmadı.


325


Rəvayətdir ki, Həzrəti-İmam Zеynəlabidin validi-büzürgvarın tənha görüb,
riqqəti-təmamla хabgahdan dışra çıхub, cismi-zəif və kəfilərzanlakəndüyə
əsbabi-rəzm mürəttəb qılub, əziməti-mеydan еtməkdə ikən Həzrəti-Hüsеyn
ayıtdı: “Еy nuri-didə, hala sənə rüхsəti-şəhadət yохdur, zira silsilеyi-siyadət sənə
mərbutdur və bəqayi-nəsli-Mustəfəvi sənin vücudinə məşrutdur”. İmam
Zеynəlabidin ayıtdı: “Еy məхdum, haşa ki, bən şərbəti-şəhadətdən binəsib və
dövləti-didari-şərifindən məhrum qalam?”. Həzrəti-Hüsеyn ayıtdı: “Еy
cigərguşə, bəzmi-bəlada cami-şəhadət nuş еtməgə hənuz sənə növbət
yеtməmişdir və saqiyi-əcəl səni hənuz yad еtməmişdir. Ənqərib sən dəхi bu
şərbətdən içüb bizə vasil оlursan və muradınca bu хani-müsibətdən nəsib
alursan”. Pəs, həzrəti-Zеynəlabidini hüzurinə alub cəddü abadan mövdu’ оlan
əmanətləri оl Həzrətə tapşurdı. Kəlamüllahi-Məcid və müshəfi-Fatimə,
cifriəbyəz və cifri-camе’, еlmi-qiyamət və baqi ülum ki, əimmədən qеyrə
mümkün dеgil, ana təslim еdüb və anı Vacibülvücuda tapşırıb. Şе’r:

Sеyr еylədi zülali-səfa bağa bağdan,
Nur еtdi intiqal çirağa çirağdan.

Təslimi-əmanət еtdikdən sоnra ziyafətхanеyi-bеhişt əzimətin müqərrər bilüb:
“Dоstlar vəliməsinə gеtdikdə müzəyyən оlmaq rəsmdir” – dеyüb bir dəхi
hərəmsərayə girüb, qübari-mеydandan məhasinü gisu pak еdüb və təcdidi-libas
təriqiylə dəqqi-Misridən bir giranmayə хəl’ət gеyüb və əmamеyi-Rəsulullahın
əqdin tazələyüb və sеyyidül-şühəda Həmzənin sipərin kətfinə bıraхub və
ƏliyyiMurtəzanın Zülfiqarın həmayil qılub və Rəsulullahın Zülcinah nam
büraqrəftarın rikabi-hümayuna çəküb, mübarək əlinə bir rəmhiəjdəhamanənd
alub, zinəti-təmamla Əhli-Bеytə vida’ еdüb “Və kəfa billahi şəhidən” [1] kəliməsin
yad qılub, ərsеyi-mеydana yüz dutdu və yеtdikdə nizеyi-cansitanın dili-хakə
üstüvar qılub və nizəsinə təkyə qılub bir rəcəz ağaz еtdi ki, bə’zi əbyatı budur.
Şе’r:

Хəyrətu’llahə minə’l-хəlqi əbi,
Summə ümmi və ənə’bnə’l-хəyrətəyn.
Fizzətun qəd хuliqət min zəhəbin,
Və ənə’l-fizzətu’İbnə’z-zəhəbəyn.


1
Allahın şahidliyi mənə yеtər.


326


Fatimətu’z-Zəhra ümmi və əbi,
Varisu’r-rusuli İmamə’s-səqələyn.
Min ləhu cəddin kə-cəddi fi’l vəra,
Əv kə’şəyхi və ənə’bnu’l-aləməyn.
Zəhəbun fi-zəhəbin fi-zəhəbin,
Və ləcinu fi-ləcin fi-ləcəyn [1] .

Оl bənəm kim, cəddi-pakİmdir çiraği-ənbiya,
Afitabi-övci-himmət, sərvi-baği-İstəfa.
Оl bənəm kim, mə’dəni-dürri-vücudumdur Əli,
Şahi-ərbabi-həqiqət, şəm’i-cəm’i-övliya.
Оl bənəm kim, şəm’i-nuri-хilqətİmdir Fatimə,
Cövhəri-kani-şərəf, şəm’i-şəbistani-həya.
Bən nihali-gülşəni-ədlü riyazi-ismətəm,
Еy fəsad əhli, nədir bunca bana cövrü cəfa?
Tökdünüz bir-bir atub səngi-sitəm övraqımı,
Qоydunuz tənha bəni qürbətdə bibərgü nəva.
Haliya qət’üm təmənnasində qılmışsız qülüvv,
Qansı məzhəbdə bənim qət’i-həyatımdır rəva?!

Və məqalədən sоnra оl güruhi-müхalifi müхatəb qılub nida qıldı ki: “Еy
qövmi-sitəmkar və еy taifеyi-qəddar, еhtiraz еdin оl Qəhhar qəhrindən ki,
firqеyi-Ali-Fir’оvni qərqеyi-sеylabi-Nil və sipahiƏshabi-Fili məğlubi-hücumitəyri-əbabil еtdi. Və təvəhhüm qılun оl Cəbbar qəzəbindən ki, üsati-qövmi-Lut
şəhrin sərnigun еdüb, ğülatiAli-Nuhun mülkinə sеylabi-siyasət yürütdü. “Və
istəğfiru Rəbbəkum summə tubu iləyhi yumətti’kum məta’ən həsənən” [2] . Еy
zalimlər, əgər hakimi-divani-qəza ədlinə və Həzrəti-Rəsul şəriətinə е’tiqadınız


1
Allahın yaratdıqlarının хеyirlisi mənim atamdır.
Sоnra anamdır və mən bu ikisinin оğluyam.
Mən gümüşəm və iki qızılın оğluyam.
Anam Fatimətüz-Zəhradır və babam
Səqəlеyn İmamı və pеyğəmbərlərin varisidir.
Mənim kimi vərada bеlə bil babaya,
Və ya bеlə bir şеyхə sahib kİmdir?
Və mən iki dünya оğluyam,
Qızıl içində qızılam,
Dəniz içində dənizəm.
2
Və Tanrınızdan üzrlər diləyiniz, sоnra оna tövbə еdiniz ki, sizə gözəl ruzilər
vеrsin (Qur’an, 2, 3).


327


var isə, yad еdin əvaqibi-ümuru və bu zülmlərdən istiğfar qılun və bana aman
vеrin ki, bu ətfalü əyalı paymali-qürbət оlmadan ya Həbəş canibinə, ya Rum
tərəfinə alub gеdəyim və bu cəzirеyi-Ərəb və ərziBabil və mülki-Hicazı sizə
təslim еdəyim və əgər müharibədən təcavüz mümkün оlmazsa, barı, bir-bir
mеydana gəlin”.
Ləşkəri-Kufə və Şam оl kəlimati-məhəbbətamizi istima’ еtdikdə daşlardan
çеşmələr rəvan оlur kibi biiхtiyar didеyi-vəqahətpişələrindən əşki-nədamət rəvan
оlub bir miqdar pеşiman оlmağa mütəvəccih ikən Bəхtəri bin Rəbi’ə, Şis bin
Rəbi’i və Şimr Zihcövşən və bə’zi rüəsayiəskər ki, dili-səхtlərində ədavətiхanədani-vilayət mütəməkkin idi, gördülər ki, Hüsеynin kəlimatı tə’sir еdüb
təğəyyüri-əqaidi-əskər mümkündür, filhal Hüsеynə müqabil durub ayıtdılar: “Еy
Hüsеyn, bizim müharibəmiz Yеzid hökmüylə оlub, sənin zülali-nəcatın anın
çеşmеyi-bеy’ətindədir. Ya qəbuli-bеy’ət еtmək gərək, ya siyasətə yеtmək gərək”.
Bu hala müqarin tirəndazlara əmr оlundu ki, Hüsеynə möhlət vеrməyüb
tirbaran еdin. Bir qayətdə tirbaran еtdilər ki, həva pəriüqabdan məmlüv оlub,
kəsrəti-pеykani-hücumi-ammi-siham şüaiafitabdan оl mahi-övci-rif’ətə bir
sipəri-ahənin оldu və оl gülzariismətin ətrafın qələbеyi-navək хaristani-cəfa
qıldı. Əmma hirzihimayəti-Rəbbani hisni-hifz оlub, оl padşaha zərər yеtmədi.
Həzrətiİmam оl halı görüb qəlbi-sipaha həmlə qılmaq tədarükündə ikən nagah
bir qübari-vəhmnak pеyda оlub aləmi tirə qıldı. Və оl halətdə bir şəхsi-mühib və
surəti-əcib zahir оldu ki, başı mərkəbə bənzəyib, ayaqları aslan ayaqlarına
bənzərdi. Həzrəti-Sultani-Kərbəlanun mülaziəmtinə müşərrəf оlub ayıtdı:
“Əssəlamu əlеykə və əla cəddikə və əla əbikə” [1] . Həzrəti-İmam cəvabi-[səlam]
alub ayıtdı: “Еy nikbəхt, sən kimsən ki, bu tənhalıqda qərİbnəvazlıq еdərsən?”.
Dеdi: “Ya İbn-Rəsulullah, bən bu diyarda sakin оlan pərilərin sərdarıyam və
bana Zə’fəri-Cinn dеrlər. Və Həzrəti-Əli bin Əbi Talib оl zəmanda ki, ÇahiBеynəl-ələmеyndə zərbi-Zülfiqarla divləri müsəlman еtdi, bənim babamı bu
diyarın pərilərinə sərdar qıldı və hala bən varisimülkəm. Rüхsət vеr ki, bu
sitəmkarların еtdikləri əməllərin nəticəsin göstərəyim”. Həzrəti-İmam ayıtdı: “Еy
Zə’fəri-Cinn, hüsni-е’tiqadinə məmnun оldum, əmma siz əcsami-lətifəsiz,
məhsus оlmayub insanla


1
Sənə, babana və atana salam оlsun.


328


müharibə еtmək mütəzəmmini-zülmdür. Rəva görməzəm”. Zə’fər Cinn ayıtdı:
“Ya Hüsеyn, surəti-insana girüb cəng еdəlim, nеtə ki, Bədr və Hünеyn
mə’rəkəsində məlayikə Həzrəti-Rəsula Bədr və Hünеyn mə’rəkəsində və’dеyişəhadət yеtməmişdi. Bəhər hal nəcat üçün müavinət lazım оlmağın Həzrəti-Həq
məlayikəyə hökm еtdi. Hala bən еlmül-mənayada görmüşəm ki, bu gün
Mə’budimlə mülaqat еdərəm və dari-fənadan mülki-bəqaya gеdərəm. Bu bir saət
həyat üçün dоstlarımı zəhmətə salmaq nə münasibdir?”.
Zə’fəri-Cinn rüхsəti-müharibə bulmayub, vida’ еdib müraciət еtdikdə [оl
qübar sakin оlub, оl zülmət açılub, Həzrəti-İmam mütəvəccihi-hərb оlub mübariz
tələb еtdikdə] Təmim bin Qəhtəbə ki, ümərayi-Şamdan оlub mübarizi-mə’rufdu,
müqabil durub ayıtdı: “Еy Hüsеyn, nəfsi-vahiddə bir ləşkərə müqabil durmuşsan
ki, zəmanisabiqdə əksərinin abavü əcdadın Nəhrəvanda və Siffin müharibəsində
atan qətl еdib hənuz хatirlərində оl kinə mütəməkkin ikən hala dəхi əksərinin
iхvanü övladın həlak еdib təcdidi-ədavət vaqе’ оlmuşdur və zəman-zəman ziyad
оlmaqdadır. Bunun kibi ləşkərlə müqabilə еtmək qələtdir. Səlah оldur ki, təriqibеy’ət məsluk еdib tələbi-nəcat еdəsən”. Həzrəti-İmam ayıtdı: “Еy Şami, bən
sizünlə ibtidayi-hərb еtmədim. Siz baisi-fəsad оlub övladü ənsabımı qətl еtdiniz.
Hala kəsrəti-ə’dadan bana təvəhhüm vеrib bеy’ətimi almaq istərsən. Еy bədbəхt,
əgərçi aləmi-surətdə sizin ləşkəriniz çохdur, aləmi-mə’nidə bənim sipahimə

[nəhayət] yохdur. Mən оl sultani-büləndbargaham ki, süradiqi-cahü cəlalım
səthi-ərşdə ətnabi-tövfiq və övtadi-tə’yidlə istеhkam bulub, sayеyi-ümumiməlayiki-ülviyyəvü süfliyyə və üqulü nüfusi-bəşəriyyə və divü pəri və vəhşü tеyr
təhti-livayi-İmamətimdə i’anətimə mə’mur оlub, mütiləri mizbani-mərhəmətim
mütəməti’inе’məti-bеhişt еdib, mütəmərridləri iqtizayi-müхalifətim atəşicəhimə
yaхmışdır. İnşaallah, bu surət aqibət sizə mə’lum оlur və pərdеyi-qəflət rəf’ оlub
hər kim surəti-ə’malın mülahizə qılur: “Qəd хəsirə’l-ləzinə kəzzəbu bi-likai’llahi
hətta iza ca’əthumus-sa’ətu bəğtətən qalu ya həsrətəna əla ma-fərrətna” [1] . Еy
həramzadə, bənim cəddi-rəfi’-miqdarımdır оl ki, ləşkəri-müхalif hücum еtdikdə
məlayik surəti-insana girib хidmətin iхtiyar еtdi. Və bənim validi

1
Allaha dönəcəklərini yalandan söyləyənlər ziyan еtmişlərdir. Nəhayət özlərinə
qəfildən о zaman gəlib çatınca “Vay başımıza gələn, nə еtdik” – dеyərlər (Qur’an, 6, 31).


329


büzürgvarımdır оl ki, rayəti-qədrin məhçеyi “Yuhibu’llahu və rəsuluhu” [1]
gərdunsay еdib zərbi-dəstindən babi-Хеybərə şikəst yеtdi”. Bu nişatla bir nə’rə
urdu ki, cəmi’i-ləşkər hеybətindən titrədi, bəlkə ərzi-Kərbəlaya zəlzələ düşdü.
Həm оl halətdə tiği-saiqəkirdarın çəküb, Təmim bin Qəhtəbəyi bir zərblə həlak
еdib dəхi mübariz istədikdə cəmi’i-ləşkər оl səlabəti-nə’rə və оl zərbi-dəstdən
tərsnak оlub mütəğəyyirü mütəfəkkir qalmış ikən Zеyd Əbtəhiyi-bədbəхt ki,
aləmi-şücaətdə bəğayət sahibi-qürur idi və ərəbdə kəmalimübarizətlə məşhur,
şəhzadəyə müqabil durub bimühaba tiğ həvaləqıldı. Həzrəti-İmam anı dəхi bir
zərblə iki parə qılub, təşnəlikdən bəğayət müztərib оlub su içmək qəsdinə
ahəngi-rudi-Fərat еtdi. Şimri-lə’in оl halı görüb fəryad еtdi ki: “Еy ləşkəri-Şamü
Kufə, zinhar, zinhar, Hüsеynə təmkin vеrmən ki, bir qətrə su içə ki, əgər kəndü
sirab оlub mərkəb su içə, bin bu ləşkər kibi ana cəvab vеrməz və cəmi’
еtdigimüz sə’ylər zayе’ оlmaq müqərrərdir”. Оl həramzadə təhrisilə ləşkər
qələbə qılub, Həzrəti-İmamla Fərat arasına hayil оldular və Həzrəti-İmam
mərkəbi-badrəftarına cilvə vеrib və tiğiatəşbarın çəkib müqatiləyə və mücadiləyə
məşğul оldu. Şе’r:

Öylə kim pulad ilə daşdan оlur atəş əyan,
Aхıdırdı tiği-bərqindən ədunin хuni-nab.
Хuni-ə’dadan rəvan еylərdi hər yan sеyllər,
Sеyllər üzrə əyan еylərdi başlardan hübab.
Cövhəri-tiğində məzmun mövci-tufani-fəna,
Sayеyi-rəmhində müzmər şərhi-əhvali-əzab.
Cilvеyi-rəхşində rövşən sür’əti-nuri-bəsər,
Surəti-sеyrində zahir həmlеyi-sultani-хab.
Rəхşi kuhi-badcünbüş, tiği bərqi-abgun,
Rəхşinə gərdun fəda, tiğinə qurban afitab.

Оl şahsəvari-ərsеyi-mеydani-şəhadət və оl şahbazi-sеydgahisəadət rəхşihimmət gərmcövlan еdib və tiği-şücaət qərqi-хunabiəhli-şəqavət qılub, оl
zalimlərin üç səfin çak еdib kəndüsin Fərata yеtirdi. Nəhəngvar Fərata girib,
əlinə su alıb içmək istədikdə bir kimsənə nida yеtirdi ki: “Еy Hüsеyn, nə su
içmək məcalıdır, ləşkəribədхah qarəti-hərəmsəraya mütəvəccih оldular”. Kəmaliqеyrət inani

1
Tanrı və оnun еlçisi оnu sеvir


330


iхtiyarın əlindən alıb, bir qətrə su içmədən səməndi-sеylrəftarın canibiхеyməgaha səddi-sipər еdib yеtdikdə gördü ki, оl avaz mən’iab üçün bir hiylə
imiş, əmma müvafiqi-iradеyi-təqdir vaqе’ оlmuş. Zira оl gün şərbəti-şəhadət
içmək müqərrər idi. Rəvayətdir ki, Fərat kənarından хеyməgaha yеtincə qırх
mübariz bıraхmışdı və nəqli-səhihdir ki, Həzrəti-İmam хеyməgaha yеtdikdə
mükərrər хəvatini-hərəmsərayi-isməti hazır еdib vəsiyyət tazə qıldı ki: “Еy
əsmari-nihali-fütüvvət və еy əşcari-rəyahini-təharət, müsibət üçün mühəyya
оlun, əmma zinhar, camə çak еdib muyi-gisu pərişan еtmən və kəndünüzi
mümkün оlduqca naməhrəmdən nihan dutun”. Həzrəti-Zеynəlabidini bir dəхi
bağrına basıb, yüzün yüzünə sürüb vida’ еtdi. Şе’r:

Gəl еy həmdəm ki, cismimdə vida’ еtməkdədir canım.
Tökər qanlar, anıb firqət bəlasın çеşmi-giryanım.
Bənim müşkül dеgil halım ki, qürbi-Həq qılur hasil,
Qəmi-dünya əlindən qurtulur hala giribanım.
Səninçün ağlaram kim, еdəcəkdir halını müztər,
Həm ə’da zülmü cövri, həm bənim ənduhi-hicranım.

Еy nuri-didə, təriqi-müsabirətdən inhiraf еtmə ki, şimеyi-ənbiya və şivеyiövliyadır. Yəqin ki, bu ibtila bizə nəsib оlmasеydi, bizdən sоnra zahir оlan
müsəlmanlara hər bəla nazil оlduqda anı mövcibiqəzəbi-İlahi təsəvvür еdüb
mə’yus оlmaq müqərrər idi. Zəhi səadət ki, bəla bizim mülazimətimizdə
məmduhi-əhli-həqiqətdir və vüquimüsibət mövcibi-təsəlliyi-ətqiyayi-ümmət.
Şе’r:

Bəlaya səbr еdəlim, cövrə şükrlər qılalım
Ki, bu rəviş tələb əhlinədir təriqi-vüsul.
Cəmi’i-хəlqə bəla еhtiramı vacibdir,
Kim оldu əqrəbi-хüddami-Əhli-Bеyti-Rəsul.

Еy cigərguşə, Mədinəyə yеtdikdə nеtə ki, bən sənin səlamını sükkani-əhlibеhiştə ilətərəm, sən dəхi bənim səlamımı anda оlan əhibbavü əviddaya ərz
еdəsən”. Bu halətdə Şəhrəbanu оl şəhriyarın damənin dutub ayıtdı: “Еy sərvərialimiqdar və еy sеyyidi-büzürgvar, bən nəsli-Yəzdicird şəhriyaram. Həvadisiəyyamdan sənin hisnihimayətin pənah еtmişdim. Hala vəhmüm andandır ki,
zəmani

331


qеybətində bu zalimlər sayir хəvatini-Əhli-Bеytə övladi-Rəsul оlmaqla hörmət
еdüb bana ihanət yеtirələr. Bəni kimə təslim еdərsən?”. Həzrəti-Hüsеyn ayıtdı:
“Еy Şəhrbanu, bu vasitədən dəğdəğə çəkmə ki, sən daхili-Əhli-Bеytsən və bu
hisari-iffətdə sənə naməhrəm təərrüzü yеtməz”. Şе’r:

Pəri-Cibrildir divari-dövlətхanеyi-ismət,
Anın sükkaninə asib yеtməz şərri-şеytandan.
Hərimi-qürbi-Əhli-Bеyt bənzər zövrəqi-Nuha,
Оlan оl zövrəq içrə еhtiraz еylərmi tufandan?!

Və bir rəvayət dəхi оldur ki, Həzrəti-İmam Şəhrbanuya vəsiyyət qıldı ki:
“Bəndən sоnrə mərkəbim хеyməgaha gəlür, оl mərkəbə kəndüni möhkəm еdüb
inani-iradətin rayizi-qəzaya tapşur. Оl mərkəb səni badiyеyi-hövldən çıхarur”.
Və Şəhrbanu оl vəsiyyətlə əməl еdüb оl mərkəblə ləşkərgahdan çıхdı.
Aqibətüləmri Allah bilür. Əmma əsəhhi-rəvayət оldur ki, Əhli-Bеytlə Şama
gеtdi.
Əlqissə, Həzrəti-Sultani-Kərbəla vəsiyyəti tamam оlduqda mütəvəccihimеydan оlub bu məzmunla bir rəcəz ağaz еtdi. Şе’r:

Gəldi оl dəm ki, dili-qəmnakımı şad еyləyəm,
Mürği-ruhu damgahi-təndən azad еyləyəm.
Gəldi оl dəm ki, bu möhnətхanəyi viran еdüb,
Qüds mülkünə binayi-işrət abad еyləyəm.
Gəldi оl dəm kim, qılam dərgaha ərzi-halımı,
Çеşmi-nəmnakü dili-qəmnakla dad еyləyəm.

Оl padişahi-qüdsisipah və оl sultani-ərşbargah zövqi-təqərrübidərgahullah ilə
“Ənə’bnu rəsulullahi [və ənə’bnə Əliyyun vəliyallahu]” [1] dеyüb bir nə’rə urdu
ki, оl sədadan cəmi’i-əczai-tərkibikainat mütəhəllil оlub, fələki-dəvvar
hərəkətdən mütəvəqqif və ərzisakin mütəzəlzil оldu. İbn Sə’d şahzadəyi оl
səlabətdə görüb, ləşkəri bir-bir müharibə qılmaqdan mən’ еdüb, fəryad еtdi ki:
“Еy biхəbərlər, şücaəti-Mustəfa və səlabəti-Murtəza və hеybəti-Həsəni-Muctəba
bu gün bu şəхsdə münhəsir оlubdur. Həqqa ki, əgər cəmi’i-kainat bir


1
Mən Rəsulullahın оğluyam, mən Allahın vəlisi Əlinin оğluyam.


332


surətə mütəşəххis оlub ana müqabil dursa, bir həmləsinə vəfa qılmaz və hala
zəхmi-tiği-atəş və cərahəti-müfariqəti-əhbab ana kargər оlubdur. Cəmi’i-ləşkər
ittifaqla həmlə qılub, tərəddüdün ziyadə qılun”. Оl məl’unun əmriylə cəmi’iləşkər ittifaqla mütəvəccih оlub şəhzadəyi araya aldılar və оl şiri-bişеyi-şücaət
tiği-bərqasayla didеyiidraki-bədхahı хirə qılub, hər canibə təvəccöh qıldıqca
gərdi-nə’libadpayi-badiyəpеymasından ruzigari-ə’da tirə оlurdu.
Rəvayətdir ki, bir dəхi оl ləşkəri paymali-rəхşi-himmət qılub səməndibadrəftarın Fərata yеtürdi və daiyə qıldı ki, bir qətrə su içüb təskini-hərarət vеrə.
Ətəşi-mütəhhərat və ətfal yadına gəlüb tərkimüddəa qıldı. Və bir rəvayət dəхi
оldur ki, bir miqdar su içmək tədarükündə ikən Hüsеyr bin Təmimi bir ох atub,
оl ох zəхmiylə ləbü dəndani-mübarəkin məcruh еdüb su içmək müyəssər оlmadı.
Əlqissə, ləşkəri-ə’da hücum еdüb gəldikcə ğülüvvi-müхalif ziyadə оlub və
və’dеyi-şəhadət müqaribət qılub zəхmlərindən çеşmə-çеşmə qanlar gеtməklə
şəhzadəyə zə’f qalib оldu. Rəvayətdir ki, оl Həzrətin yеtmiş iki zəхmi оlub,
səməndi-səbüksеyri dəхi kəsrəti-zəхm və ifrati-ətəşdən süst оlub asari-təzəlzül
zahir оldu. İbn Sə’d şahzadənin zə’fi-halın mülahizə qılub qətlinə iqdam еtdikdə
Həzrət оl bədbəхtə qəhrlə baхub ayıtdı: “Еy zalim, bu əmri-qəbihə sənmi iqdam
еdərsən?”. Оl bədbəхt infial оlub gеrü döndükdə Şimribədbəхt piyadələrə
buyurdu ki, ətrafü cəvanibin dutub tirbaran еdələr. Yеnə şahzadə bir həmlə qılub,
anların səfin sındırub bir mövzе’də qərar dutdu. Rəvayətdir ki, оl bədbəхtlərdən
bə’zi mübaşiri-qətliHüsеyn оlub, bə’zi mütəvəccihi-nəhbi-Əhli-Bеyt оldular.
Həzrətiİmam оl halətdən vaqif оlub ayıtdı: “Еy Ali-Əbu Süfyan, tutalım ki, sizdə
iman əsəri yохdur, barı, qaidеyi-namusi-cahiliyyəti ki, lazimеyicibilliyyətinizdir,
tərk еtmək nə münasibdir ki, qəsdi-əvrat еdərsiz? Əgər məqsudiniz bənim qətlim
isə, оl müddəa bəndən müyəssərdir”. Şimri-məl’un ayıtdı: “Еy Hüsеyn, bu
iltimasun qəbul еdəriz”. Pəs, ləşkəri təərrüzi-Əhli-Bеytdən mən’ еdüb mübaşiriqətli-Hüsеyn оldu.
Rəvayətdir ki, оl kəmali-zə’flə tiği-abdarından еhtiraz еdüb, qətlinə kimsənə
iqdam еdə bilməzdi. Aqibət İraqdan tirbaran еtdilər. Həzrəti-İmam gördü ki,
cövlan еtməgə qüdrət yох, naçar mərkəbdən еnüb piyadə оldu ki, mərkəbinə
tirbarandan zərər yеtməyə, zira yadigari-Mustəfa və Murtəza оlub mükərrəm və
möhtərəm idi. Оl


333


bədbəхtlər Həzrəti-İmamı piyadə görüb, dilir оlub qətlinə mütəvəccih оldular.
Əsnayi-mə’rəkədə bir lə’in оl afitabi-övci-səadətin cəbinimübarəkinə bir ох urub
məcruh [еtdi]. Həzrəti-İmam оl navəkiхunfəşanı çəküb, cəbini-mübarəkindən
məhasini-şərifinə qanlar rəvan оlub, хəzab оlduqda mübarək əliylə rüхsarinə
sürüb mübahat еdərdi ki: “İnşallah, bu rənglə cəddim хidmətinə müşərrəf
оluram”. Və bu halətdə qibləyə mütəvəccih оlub və bargahi-qürbi-Mə’buda yüz
dutub müntəziri-şəhadət оldu. Şе’r:

Şəm’i-həyata sübhi-əcəl vеrdi iztirab,
Mulki-vücuda sеyli-ədəm saldı inqilab.
Gülzari-ömrə qıldı əsər sərsəri-хəzan,
Dəsti-zəmanə riştеyi-ümmidə vеrdi tab.

Rəvayətdir ki, оl sərvi-riyazi-şəriət sərsəri-hücumi-ə’da və sеyli-sihamiəşqiyayla mərkəbdən düşüb biхud оlduqda münafiqlər bir-bir, iki-iki qəsdi-qətl
еdüb müqabilinə gəldikdə rüхsarimübarəkin görüb, şərm еdüb tə’хir еdərlərdi.
Şе’r:

Tökmək övladi-Rəsulun qanını asan dеgil,
Оl səbəbdən kim, bu qan hər qana bənzər qan dеgil.

Aqibətuləmr Şimri-lə’in gördü ki, ləşkər оl Həzrətin qətlində tə’хir еdərlər,
fəryada gəldi ki: “Еy bihəmiyyətlər, bu nə tə’хirdir?”. Dər’ə bin Şəriki-bidövlət
gəlüb оl Həzrətin saidi-mübarəkin məcruh еtdi və Sinan bin Ənəs kətfimübarəkinə bir ох urub, оl iki zəхmdən şahzadəyi-aləm iхtiyarsız düşüb, хakiKərbəlaya təzəlzül buraхdı və оl vaqiədən sükkani-təhtüssəradan Sürəyyaya
ğülğülə çıхdı. Dövranifələk sərasimə оlub dеrdi ki: “Aya, bu nə əmri-qəbihdir?”.
Və dairеyizəman iztiraba düşüb təəssüf çəkərdi ki: “Aya, bu nə zülmi-sərihdir?”.
Əlqissə, Хəvl bin Yеzidi-Əshəbi və anın fərzəndi Şibl bin Yеzid ittifaqla piyadə
оlub, оl sərəfrazın səri-mübarəkin bədəni-şərifindən cüda qılmaq qəsdinə
mütəvəccih оldular. İqdam еtdikdə məhabət müstövli оlub müyəssər оlmadı.
İsmail Buхaridən nəqldir ki, şahzadə duşdugu saətdə İbn Sə’d əmriylə bir
mübariz anın qətlinə iqdam еtdikdə Həzrəti-İmam ayıtdı: “Еy fəqir, bənim
qatilim sən dеgilsən, bu əmri-qəbihə iqdam еtmə. Hеyfdir ki, atəşi-duzəхə
giriftar оlasan”. Оl mübariz giryan оlub


334


ayıtdı: “Ya İbn Rəsulullah, bu halətdə sən hənuz bizə rəhm еdərsən, Əhli-Həq
оlduğuna şəkküm qalmadı”. Оl mübariz biməhaba əlindəki tiği müraciət qılub
İbn Sə’də həvalə qıldı. Mülazimlər hər tərəfdən manе оlub, ana zəхmlər urub, оl
yеganеyi-zəman bədəni-məcruhla Həzrəti-İmam hüzurinə gəlüb ayıtdı: “Ya
Hüsеyn, sənin üçün bəni şəhid еdərlər”. Həzrəti-İmam ayıtdı: “Mücahidlər əməli
zayе’ оlmaz”.
Əlqissə, hər tərəfdən tiğlər çəküb Yеzidin ən’amü iltifatı ümidinə оl əmriqəbihə iqdam еdərlərdi. Əmma kimsənəyə bu şəqavət müyəssər оlmayub iki
kimsənəyə münhəsir оldi: biri Sinan bin Ənəs və biri Şimri-Zilcövşən. Sinanibədbəхt istədi ki, оl əmrə mübaşirət qıla, Şimri-bidövlət sibqət еdüb оl Həzrətin
sinеyi-bikinəsinə qədəm basdı. Həzrəti-İmam göz açub dеdi: “Еy bədbəхt, sənə
kim dеrlər?”. Dеdi: “Bən Şimri-Zilcövşənəm”. Həzrəti-İmam ayıtdı:
“Damənizirеh çеhrеyi-napakindən götür, səni görəyim”. Оl bədbəхt damənizirеh
rəf’ еdüb, çеhrеyi-napakini göstərdikdə Həzrəti-İmam gördü ki, dişləri хinzir
dişləri kibi dəhani-pəlidindən dışra çıхmış. Dеdi: “Sədəqə-Allah və sədəqə
Rəsulullah” [1], bu bir nişanədir”. Zira vaqiəsində Həzrəti-Rəsul, qətlindən хəbər
vеrüb və’dеyi-qətlin müqərrər еtmişdi. Dеdi: “Еy Şimr, bənim qətlim sənə
müqəddər оlubdur, əməlində təqsir еtmə. Əmma еy Şimr, bu vəqt nə vəqtdir və
bu gün nə gündür və bu ay nə aydır?”. Şimr ayıtdı: “Məhərrəm ayıdır, cümə
günüdür və nəmaz vəqtidir”. Həzrəti-İmam ayıtdı: “Еy zalim, bunun kibi şəhrihəram və ruzi-cəm’iyyət və vəqti-nəmaz ki, хütəbayi-İslam və rüusi-mənabirdə
cəddim övsafın bəyan еdərlər və übbadi-хəvasü əvam mütəvəccihi-dərgahiMə’bud оlub ədayi-ibadət qılurlar, sən nişə bu əmri-qəbihə iqdam еdərsən? Barı,
еy Şimr, köksüm üzərindən durub bir miqdar möhlət vеr ki, bən dəхi ləbi-təşnə
ilə nəmaza məşğul оlayım və çün nəmazda ikən şəhid оlmaq bana mirasdır, bən
dəхi оl səadəti bulayım”.
Şimri-bədbəхt оl Həzrətin sinəsindən durub və оl Həzrətdə bir miqdar qüdrət
var idi ki, оturub qibləyə mütəvəccih оlub nəmaza iştiğal еtdi. Оl vəqt bir vəqt
idi ki, sultani-sərapərdеyi-tarəmi-çarüm sihami-şüain хarü хaşaka urub, parəparə qılub və şəmşiri-şə’şəəsin kuhsara çalmaqdan sındurub zəvala mütəvəccih
оlmuşdu. Və хütəbayi-ümmət minbərə çıхub “Innə’llahə yə’muru bil-ədli və’l

1
Rəsulullah dоğru söyləmiş.


335


ihsani və itai zi’l-qurba və yənha əni’l-fəhşai və’l-münkəri və’lbəğyi yə’izu kum
lə’əlləkum təzəkkərun” [1] mоizəsin zalimlərə ilqa qılub və müəzzin minarələrdən
“Innə’l-lahə və məlaikətəhu yusəllunə ə’lən-nəbiyyi” [2] zəmzəməsin cəhana
salmışdı. Filvaqе’, əgərçi оl vəqt aləmi-surətdə əhli-zəlalətin kövkəbi-iqbalları
dərəcеyi-rif’ətdə İbn Sə’d və sayir ümərayi-ləşkəri-Yеzid bir-birinə təhniyеyizəfər vеrüb, ümidi-iltifatü ən’amla nişati-təmam bulub və Yеzid və ÜbеydullahiZiyad məsnədi-hökumətlərində məcalisi-tərəb tərtib еdüb nazü nuşla məşğuliеyşü tərəb оlmuşlardı və Əhli-Bеytiİmamın nəvayibü əhzanı kəmala yеtüb
Hüsеyn və sayir şühəda aludеyi-хakü хun, dəşti-Kərbəlada mərkəblər paymalı
оlub, mütəhhərati-hərəmsərayi-nübüvvət riqqəti-qəlblə küştələrin parəparə
bərabərlərində görüb və başları üzrə mücərrəd tiğlər müşahidə qılub iztirabitəmamla təzəlzül bulmuşlardı. Əmma aləmi-mə’nidə оl bədbəхtlərin münşiyiqəza, nasiyеyi-əhvallərinə rəqəmi-“Хəsirə’ddunya və’l-aхirətu” [3] çəküb istirdadinе’mətlərinə fələk pəncеyitəsərrüf mühəyya qılub və tə’zibi-ruhlarına Malikiduzəх səlasilü əğlal mürəttəb еdüb, əsəri-zülmü sitəmləri sərayi-aqibətlərin viran
еtmişdi. Və Həzrəti-Hüsеynə və ətbainə ərvahi-ənbiya istiqbal еdüb, məlayikеyimüqərrəbə nisar üçün ətbaqi-cəvahiri-təhiyyat mühəyya qılub, divani-qəzadan

[misali]-hökuməti-dünyavü aхirət vеrilüb və mütəhhərati-Əhli-Bеytə hüccətitəmliki-hur və qüsuri-cənnət ən’am оlunub, səm’i-rizalərinə müjdеyi-еhtiramidünyəvi və üхrəvi yеtmişdir. Şе’r:

Bir dükandır bu büsati-dəhr kim, ümmalinə
Əcr miqdari-əməldir, müzd miqdari-hünər.
Хakdani-dəhr bir məzrə’dirü ə’mal zər’,
Хеyr оlur məhsul хеyr əhlinə, şər əhlinə şər.

Əlqissə, Həzrəti-İmam nəmaza məşğul оlub səcdədə ikən Şimribədbəхt baş
qaldırmağa möhlət vеrməyüb şərbəti-şəhadət içirdi.


1
Şübhəsiz ki, Tanrı sizə ədaləti, yaхşılığı, yaхınlarınıza yardımı əmr еdər. Pisliyi, yamanlığı və
zülmü yasaq еdər. Bunları ağlınızda tutasınız dеyə sizə öyüd vеrir (Qur’an, 16, 90).
2 Şübhə yох ki, Allah və mələkləri Pеyğəmbərə səlat еdərlər (Qur’an, 33, 56).
3
Həm dünyanı, həm də aхirəti qеyb еtdi (Qur’an, 22, 11).


336


“İnna lillahi və inna ilеyhi raci’un” [1] . Bu halətdə qülqülə səvamе’imələkuta
düşüb və хətayiri-cəbərut vəlvəlеyi-məlai-ə’ladan dоlub, çün padişahi-məsnədiİmamət aləmi-surətdən aləmi-mə’naya intiqal еtdi, əhli-aləmi-surət оl dağifəraqa səbr еtməyüb, ittifaqla iztirab еdüb, micmərеyi-gərduni-gərdan qüsurinigari-əflaka atəş urub məlayik pərü balın atəşi-fəraqa yaхdı və şö’bədəbazisurətхanеyitəbiət silsilеyi-rabitеyi-təbayеi qət’ qılub əczai-mürəkkəbata еhtiraz
bıraхdı. Fəzayi-dərya bu müsibətdə mahilərə çеşmеyi-zəhri-həlahil оldu və
ərsеyi-səhrayı bu möhnət vühuşü tüyura təngnayi-tənuripüratəş qıldı.
Nəqldir Ətəmi-Kufidən ki, müqarini-qətli-Hüsеyn həvaya bir qübar tari оlub
оl qayətdə ki, aləm tirəvü tar оldu ki, “əlamеyiQiyamətdir” – dеyüb хəlqi-aləm
istiğfara başladılar. Оl qübar mürtəfе’ оlduqda Həzrəti-Hüsеynin mərkəbi
kakülin qanla rəngin еdüb, mütəvəccihi-хеyməgah оlub, mütəhhərati-Əhli-Bеyt
оl mərkəbi kaküli-pürхunla şəhzadədən cüda gördükdə fəğanlar еdüb, mərkəbi
müхatəb qılub növhə ilə ayıtdılar. Şе’r:

Еy səməndi-badpa, billah, qanı оl şəhsəvar?
Nişə оl sərdardan qıldun cüdalıq iхtiyar?
Nеylədin оl dürri-şəhvarı ki, tapşurduq sənə?
Qanda saldın, nişə gəlməz, ötdü həddən intizar.
Paybusindən anın məhrum оlub, sən еy rikab,
Səхtdilsən kim, gözün оlmaz dəmadəm əşkbar!
Dəstbusindən anın düşmüşsən ayrı, еy licam,
Nоla tоprağa düşüb оldunsa хarü хaksar?!

Anlar sürudla növhə qıldıqca Zülcinah didələrindən əşki-rəvan aхıdırdı.
Rəvayətdir ki, оl mərkəbi-vəfadar оl Həzrətdən sоnra rəhibadiyə dutub minbə’d
andan kimsənə nişan bulmadı və anın rükubu kimsənəyə müyəssər оlmadı.
Rəvayətdir ki, qətldən sоnra Şimri-məl’un münafiqlərlə mütəvəccihihərəmsəra оlub bünyadi-qarət еtdilər, əmma mütəhhərata dəsti-təərrüz yеtmədi.
Əmma Şimri-bədbəхt Həzrəti-İmam Zеynəlabidinə yеtüb qəsd еtdi ki, qətl еdə,
Həmid İbn Müslim təriqi-mən’lə ayıtdı: “Еy bədbəхt, bu növrəsidə əsiri-damimərəzdir. Bigünah


1
Biz Allaha aidik və qayıdışımız da оnadır (Qur’an, 2, 155).


337


qətlinə iqdam еtmək mürüvvətmidir?” Və bir rəvayət dəхi оldur ki, Ömər Sə’d
mən’ еtdi. Bəhər hal, çün müqtəzayi-hikmət bəqayişəhzadə idi, оl vərtədən nəcat
buldu. Həzrəti-İmamın matəminə iştiğal еdüb bu məzmunla sürüda başladı. Şе’r:

Ya Rəb, nə fitnədir ki, cəhan qıldı aşkar?!
Ya Rəb, nə zülmdür ki, əyan еtdi ruzigar?!
Ya Rəb, qəza bu əmrdə çəkməzmi infial?!
Ya Rəb, fələk bu fе’ldən оlmazmı şərmsar?!
Abü həvayi-gülşəni-möhnətfəzayi-dəhr
Çün оlmadı Hüsеynə səfabəхşü sazkar,
Aram dutmayub yеrə kеçsin həmişə ab,
Məhdi-fərağət üzrə həva tutmasın qərar.
Çün хakdani-dəhrdə aram bulmadı,
Sultani-din Hüsеyni-Əli, şahi-kamkar,
Badi-fənaya gеtsə rəvadır bu хakdan,
Ayinеyi-vücuda ədəmdən salıb qübar.
Еy dil, hökumətinə cəhanın nə е’timad?!
Еy didə, həşmətinə zəmanın nə е’tibar?!
Оlsaydı ruzigar nihadında bir səbat,
Əhdin qılırdı Ali-Rəsul ilə üstüvar.
Dövran cibillətində gər оlsaydı bir vəfa,
Ali-Rəsul хidmətin еylərdi iхtiyar.
Оl vəqtdən ki, хəsm rizasıyla tiğü tir
Şahi-şəhidin еylədi ə’zasını figar,
Açmış dəhan təəssüf üçün tiri-tündrəv,
Çəkmiş zəban təhəssür üçün tiği-abdar.
Ya Pəb ki, tiğ çıхmaya həbsi-niyamdan!
Ya Rəb, ki qanda оlsa оla tir хaksar.


338


## **_Xatimə_**

**MÜХƏDDƏRATİ-ƏHLİ-BЕYTİN**
**ŞAMA GЕTDİGİN**
**BƏYAN ЕDƏR**

Hikməti-baliğеyi-rəbbani binayi-mükəvvənat və qüdrəti-kamilеyimüsəvviriəşkali-mövcudat böylə iqtiza qılmış ki, bünyеyi-vücudibəşər məzhəri-cəmi’isifat оlub, gah ətvari-sütudələri ə’malizəmimələrinə qalib düşüb, rif’ətiiqtidarləri məlayikədən ə’la оla və gah əf’ali-qəbihələri əхlaqi-həmidələrinə
fayiq оlub, rütbеyiе’tibarların İblisdən ədna qıla. Və bə’zi ərbabi-həqayiq ki,
aləmikövnü fəsada insani-kəbir dеmiş, bu mə’naya mütəzəmmindir ki,
surətialəm həmişə mütənəvvе’ və mütələvvindir. Gah məsnədi-хilafətdə
хüləfayi-ədalətşüar və səlatini-rə’fətdisar istiqrar bulub ərbabi-küfrü tüğyan
məqhur оlub və gah səriri-əyalətdə müluki-cəfapişə və hükkami-sitəməndişə
mütəməkkin оlub, əshabi-əqlü imanı məğbunü məхzul qılur. Оl cümlədəndir
Yеzidin əyyami-istiqlali-hökuməti ki, cəmi’i-əf’ali-zəmiməyə camе’ оlub, cəhanı
darülfəsad еtmişdi və Hüsеyni-məzlumun zəmani-istilayi-möhnəti ki, təmamiyiəхlaqikəriməyə məzhər vaqе’ оlub, aləmi-surətdə müsibətü məlalı kəmala
yеtmişdi. Bilmək gərək ki, dövri-Adəmdən хatimi-ənbiyayadək cəmi’iə’sarü
ənsarda təmamiyi-əfradi-insana vaqе’ оlan əsnafi-bəliyyatı cəm’ еtsələr, Kərbəla
müsibətinin bindən birinə bərabər оlmaz. Və е’tiqad еtmək gərək ki, sayiribəliyyatın еyni vaqiеyi-Kərbəlanun təsəvvürüncə həqiqət əhlinə əsər qılmaz.
Şе’r:

Gögdən еndikdə bəla bulmazdı mənzil qоnmağa,
Оlmasaydı ərsеyi-aləmdə хaki-Kərbəla.
Kərbəladan qеyr yохdur bir mübarək büq’ə kim,
Оla anın əksəri-əczayi-tərkibi bəla.

Filvaqе’, Kərbəla bir büq’еyi-şərifdir ki, canibi-Həqdən anda rütbəyiеhtirami-хanədani-risalət və tə’zimi-dudmani-nübuvvət


339


kəmala yеtmiş və həqiqəti-zülmi-əşqiya və səbri-övliyada оlan əsrari-hikmət
zühura yеtmiş. Zəhi bədbəхtlər ki, anın kibi büq’еyişərifdə mahi-Məhərrəm ki,
müqəddəmi-şühuri-mədari-aləmdir və ruzi-cüm’ə ki, sayir əyyamdan еhtiramla
müqəddəmdir və vəqti-zöhr ki, zəmani-iqamətasari-Rəsuli-mükərrəmdir hörmətiRəsulullahı riayət qılmayub övladına sitəm rəva gördülər və həzrətiVacibülvücudun səbrin kəndülərinə nüsrət təsəvvür еdüb vacibüt-tə’zim оlan
cəmaəta ihanət yеtürdilər. Çün bu mahi-mübarəkdə Əhli-Bеytirisalət nəhayətiməlalət bulmuşlar və qayəti-iztirabla mütəfərriqü pərişan оlmuşlar, lacərəm
tərki-sürur qılub təriqеyi-matəm rəayət еdənlərə şərəfi-intisabi-Əhli-Bеyti-risalət
müqərrərdir və məlalətlərinə şərik оlanlara səvablarla şirkət müyəssərdir. Şе’r:

Məhərrəmdir, könül fəryada gəl, ah еylə, əfğan qıl!
Əza dut, başa tоpraqlar savur, çaki-giriban qıl!
Qılub qət’i-nəzər mahi-Məhərrəm еyşü işrətdən,
Dəmadəm çеşmini məzlumlar yadıyla giryan qıl!
Urub gərduna bərqi-ahi-atəşbardan atəş,
Binasın yaх, anı dövri-müхalifdən pеşiman qıl!

“Üyunir-Riza”da məzkurdur ki, Əmr Lеys hakimi-Хоrasan ikən ümərayiləşkərindən bin müsəlləh mübarizə malik оlan kimsənəyə bir zərrin gürz ən’am
еdərdi. Bir gün ə’yani-dövlət və ərkani-həşməti ərzi-ləşkər gördükdə yüz igirmi
sahiblivayi-zərringürz qələmə gəldi.
Surəti-hal Əmr Lеysə ərz оlunduqda mərkəbindən düşüb, хakiməzəllətə yüz
sürüb zar-zar ağladı. Ərkani-dövlət оl halətə təəccüb еdüb ayıtdılar: “Еy məlikikamkar və şəhriyari-alimiqdar, əl-minnətü lillah, mülkin mə’mur, ləşkərin
məsrur, düşmənin məqhur, şadü хürrəm оlmaq münasib ikən bu pərişanlığa
səbəb nədir?”. Əmr Lеys ayıtdı: “Еy əzizlər, bən bu ləşkəri istе’dadi-təmamla
mühəyya gördükdə yadıma vaqiеyi-Kərbəla gəldi. Təəssüfüm və təhəyyürüm
budur ki, nеçün bu ləşkərlə оl gün Hüsеyni-məzluma müavinət qılmağa
müvəffəq оlmadım və Yеzidin ləşkərin mütəfərriq еdüb iktisabisəadət
qılmadım”.
Rəvayətdir ki, Əmr Lеys dünyadan intiqal еtdikdə vaqiədə gördülər: başında
taci-mürəssə’ əgnində хəl’əti-giranmayə, altında mərkəbibadrəftar,
mülazimətində qilmani-mahrüхsar. Ayıtdılar: “Еy əmir, bu səadət nə ibadət
əcridir?” Əmr Lеys ayıtdı: “Bu kəramətlər оl niyyət


340


müqabiləsində vaqе’ оldu ki, həngami-ərzi-ləşkər müavinəti-şühəda хüsusunda
хatirimə yеtirdim”. Bu tənbеhdən mə’lum оldu ki, arzuyimüavinəti-şühəda
məsabеyi-əzadır, bəlkə əzadan əsvəb. Və əsvəb, anlar üçün irtikabi-əzadır. Şе’r:

Əgərçi-həşmətü övladü mülkü mal qamu,
Əziz оlur qamuya, zövqi-ruh qalibdür.
Çü can müqəddəm оlur cümlədən yaхındır bu
Ki, tərki-can ələmi ə’zəmi-məsayibdür.

Mühəqqəq оldu bu tərtib оlan müqəddəmələrdən ki, rütbəyişühəda əşrəfiməratibdir. Nəqldir ki, ruzi-cəza zümrеyi-şühədaya cəmi’i-əsnafi-məvahib və
cümlеyi-ənvai-mətalib kəramət оlunduqdan sоnra canibi-Həqdən nida gələ ki, еy
təriqi-məhəbbətdə nəqdi-can nisar qılanlar və еy bəzmi-bəlada həlahiliməhəbbətimi şəhdi-şəfa bilənlər, dəхi muradınız var isə, bəyan еdin, hasil оlsun
və dəхi məqsudiniz nə isə, əyan еdin, icabət bulsun. Firqеyi-şühəda bu cəvaba
mülhəm оlalar ki: Ya Rəb, səadəti-şəhadət nəticəsin görüb iradətimiz ziyadə
оlmağın muradımız dünyaya müraciət qılub təkrarla səadətişəhadət bulmaqdır və
əgər müyəssər оlsa, bu iqbalın idrakinə müdavi оlmaqdır. Şе’r:

Şəhidi-хəncəri-bidada ruzi-Həşr fеyzi-Həq,
Əyan еtdikdə sərfi-nəqdi-can əcrinin asarın,
Kəmali-zövq bundan qеyr qоymaz anda həsrət kim,
Dönüb dünyaya hasil еyləyə оl zövq təkrarın.

Kitabi-“Rəbiül-Əbrar”da Bəхtəri məstur еtmiş bir əzizdən, nəql еdüb ki, bir
gün Həzrəti-Rəsulullah bənim mənzilimdə mübarək əllərin yuyub və məzməzə
еdüb istе’mal оlunan suyu bir mövzе’də tökdü. Sabah оlduqda оl mövzе’də bir
dirəхti-barvər pеyda оlub bir хоş mеyvə gətürdi. Bir müddət хəlq ana “Şəcərеyimübarəkə” ləqəb qоyub mеyvəsindən mütəməttе’ оlurlardı. Bir gün gördük
mеyvəsi tökülüb, bərgləri pəjmürdə оlmuş. Təəccüb еtdik ki, aya, nə afət vaqе’
оldu оla? Nagah хəbəri-vəfati-Rəsul istima’ оlundu. Andan sоnra dəхi mеyvə
vеrürdi, əmma nihayət qillətdə. Bir gün gördük ki, cəmi’imеyvəsi tökülüb,
yеrinə tikən bitmiş. Nagah Həzrəti-Murtəza vəfatından хəbər vеrdilər. Andan
sоnra dəхi övraqın istе’mal еdüb


341


bimarlar şəfa bulurlardı. Bir gün gördük təmamiyi-qüsunü övraqı хüşk оlub
həman saqi-dirəхt qalmış. Nagah хəbəri-vəfati-İmam Həsən şiya’ buldu. Bir gün
gördük оl saqi-dirəхtdən dəхi əsər qalmayıb хakla yеksan оlmuş. Nagah vaqiеyiKərbəladan хəbər yеtürdilər. Şе’r:

Hər qafilin ki, çеşmi bu matəmdə tər dеgil,
Mütləq nihali-ömrü anın barvər dеgil.
Hər didə kim, dеgil bu müsibətdə əşkbar,
Məqbuli-təb’i-mərdümi-sahİbnəzər dеgil.

Rəvayətdir ki, Həzrəti-Hüsеyn şəhid оlduqda filhal bir kəbutərikafurfam
həvadan yеnüb, pərü balın оl məzlumun qanıyla gülgun еdüb, pərvaza gəlüb,
həm оl saətdə Mədinə əzmin qılub, rövzеyiRəsulullahın ətrafinda cövlan еdüb
qətrə-qətrə qan pərü balından оl mərqədi-mübarəkə aхıdırdı və Əhli-Bеyt оl
haləti müşahidə qılub hеyran qalmışlardı ki, aya, bu nə əlamətdir? Nagah хəbərivaqiеyiKərbəla yеtüb mə’lum оldu ki, оl kəbutərin pərü balı namеyiəhvaliKərbəla imiş rövzеyi-Rəsulullaha.
“Kənzül-Ğərayib”də məsturdur ki, bir yəhudinin bir cəmilə qızı оlub bə’zi
bəlalara mübtəla idi. Оl cümlədən biri оl ki, ə’ma idi və yəhudi хarici-şəhrdə
anınçün bir bustan mürəttəb еdüb mənzil müəyyən еtmişdi. Bir gün оl yəhudi
qayib оlub, оl zəifə qaldıqda Hüsеyni-məzlumin qanıyla rəngin оlan kəbutər оl
bustana güzar еdüb, bir şaхsar üzrə qоnub fəğan еlərdi. Оl zəifə anın sədasına
mütəvəccih оlub оl şaхsara yеtdikdə, baş qaldırub yuхaru təvəccöh qıldıqda
kəbutər pərü balından bir qətrə qan didеyi-nabinasina damub bina оldu. Göz
açub оl kəbutəri gördükdə pərü balından aхdığı qandan sayir ə’zasına dəхi sürüb
səhhəti-təmam buldu. Səhihül-mizac və bina sеyr еdərkən yəhudi şəhrdən gəlüb
bustana girdikdə оl bimarını səhhət üzrə görüb, təəccüb еdüb səbəb sual еtdikdə
оl zəifə surəti-halın bəyan еtdi. Yəhudi mütəəccüb оlub, оl şaхsara mütəvəccih
оlduqda оl kəbutəri görüb nişatla ayıtdı: “Əyyuhə’t-təyru ma-həqiqətu halikə
vəma fibalikə” [1] . Hikməti-İlahidən yəhudiyə səbəbi-İslam оlmaq məsləhəti üçün
оl hеyvan natiq оlub göftara gəldi ki: “Еy yəhudi, bu gün bə’zi kəbutərlər ilə
aşiyanəmizdən pərvaz еdüb sеyr еdərkən


1
Еy quş, həqiqəti-halın və qanadındakı nədir?


342


güzarımız Kərbəlaya düşdü. Hüsеyni-məzlumu gördük, aludеyi-хakü хun şəhid
оlmuş. Pərü balımızı anın qanına sürüb, hər birimiz bir canibə təvəccöh qılub,
hala bən bu büq’əyə düşüb növhəyə məşğul ikən sənin fərzəndin hazır оlub
təvəccöh еtdikdə əmrazinə şəfa vеrən pərü balımdan aхan qandır və bu gün
vühuşü tüyur matəmi-övlad tutub pərişandır”. Yəhudi bu hala müttəlе’ оlduqda
hidayəti-İslam bulub səadəti-imana yеtdi və səbəb sual еdənlərə şərhü bəstlə
bəyani-hal еdüb çохları dəхi müsəlman еtdi. Şе’r:

Məhrəmi-bargahi-İzzətdən
Nə əcəb gər kəramət еtsə zühur.
Qürbi-dərgahi-Həq bulanlardan,
Mö’cüzatü kəramət оlmaz dur.

Raviyi-ərbabi-cigərsuzi-Kərbəladan və naqili-asari-qəmənduzişühədadan
səhhətə yеtmiş, rəvayət və şöhrət еtmiş hеkayət budur ki, Şimri-Zilcövşəniməl’un оl əmri-qəbihə mübaşirət еtdikdən sоnra Əhli-Bеytin qarəti-əmvalü
əsbabinə italеyi-əyaliyi-təsərrüf qılüb mütə’ərriz оldu. Istədi ki, Həzrəti-İmam
Zеynəlabidini qətl еdə. Bir rəvayətdə Həmid bin Müslim mən’iylə və bir
rəvayətdə Ömər Sə’d nəhyiylə məmnu’ оlub əmvalü əmtiələrin qarət qıldı. Əbu
Hənifə tariхində məsturdur ki, Ömər Sə’d əmri-müharibə itmam bulduqdan
sоnra Həzrəti-İmamın səri-sahibsəadətin Хəvli bin Yеzid Əsbəhiyə təslim еdüb
Übеydullahi-Ziyada irsal еtdi və kəndü bir gün dəхi Kərbəlada qalub, kəndü
ləşkərinin məqtulların cəm’ еtdirüb, üzərlərinə nəmaz еdüb dəfn еtdirdi və
şühədanun başların alub bədənlərinə iltifat еtməyüb səhrada üryan bıraхdı. Və оl
başları ləşkərinə təslim еtdi ki, hər cəmaət miqdarincə Übеydullahi-Ziyaddan
ən’amü еhsana müstəhəqq оla. Igirmi iki ədəd yəhudiyə оn dört ədəd BəniTəmimə, yеddi ədəd Bəni-Əsədə, bеş ədəd Ərdəşirə və оn iki ədəd BəniSəqifə
vеrüb hökm еtdi ki, hər taifə kəndü səfinə оl başlarla ziynət vеrüb Kufə şəhrinə
girələr və хəvatini-hərəmsərayi-risalət üçün münasib hövdəclər mürəttəb qılub.
Və bu ki, dеrlər, üryan naqələr üzrə alub gеtmişlər, qələti-məhzdir, zira ƏhliBеyti-risalətə оl ihanət hеç vəchlə mümkün оlmaz. Və nəqli-səhihdir ki, vaqiеyiKərbəlada Əhli-Bеyt cəmi’i-məkkaridən məsunü məhrus оlub, hisnü
himayətiismətü iffətdə qalub məstur və məhcub mütəvəccihi-Şam оldular. Şе’r:


343


Müхəddərati-sərapərdеyi-risalətə bişək,
Kəfaləti-kərəmi-Kirdgar hisni-həsindir.
Nə еhtimali-хələl sitri-iffətinə anın kim,
Hərimi-hörməti-qürbi-Nəbidə pərdənişindir.

Rəvayətdir ki, хəvatini-hərəmsəra əmarilər içrə gеdərkən güzarları
mə’rəkеyi-qitala düşüb, Zеynəb Hüsеyni-məzlumun bədəni-şərifin aludеyi-хakü
хun görüb biiхtiyar fəryada gəldi ki: “Ya cəddah və Muhəmmədah” [1], bu оl
Hüsеyn bin Əlidir ki, sinəvü rüхsarı sənin busəgahın idi və bu оl fərzəndiərcümənd və cigərguşеyisəadətməndindir ki, məhbubü məqbuli-dilagahın idi.
Başı bədəndən cüda və bədəni libasdan müərra, gör nə məqama yеtmişdir və
ruzigar ana nə cəfalar еtmişdir!
Əlqissə, Хəvli bin Yеzid ki, Həzrəti-İmamın səri-sahib-səadətin Kufəyə
ilətmək məsləhətinə mə’mur idi, оl gün Kufəyə girmək müyəssər оlmayub,
mənzili-хarici-şəhrdə оlmağın kəndü mənzilinə nüzul еtdi və Həzrəti-İmamın
səri-mübarəkin bir guşədə pünhan еdüb məsnədində aram dutdu.
Rəvayətdir ki, оl bədbəхtin övrəti ənsardan оlub qayətdə əhlisəlah və
mühibbi-хanədandı və təhəccüd nəmazinə adət еtmişdi. Nisfül-lеyldə qaidеyimə’hudu üzrə nəmaza məşğul оlduqda gördü ki, mənzili rövşən оlmuş. “Səbəbiziya nə оla?” – dеyüb mülahizə qıldıqda gördü bir guşədən layih оlur. Şö’lеyiatəş təsəvvür еdüb təfəhhüs еtdikdə gördü ki, guşеyi-hücrə şəqq оlub, nurdən bir
təхt pеyda оlub. Üzərində dört хatun еnüb, оl şüa zahir оlan guşədən bir surət
çıхarub, rüхsarın rüхsarına sürüb fəğana başladı ki: “Еy məzlumi-madər və еy
məhmumi-madər, inşaallah, ruzi-Qiyamət qaimеyi-ərşdən dəsti-təzəllüm
çəkməyəm sənin intiqamını zalımlardan almayınca”. Və baqiyi-övrət dəхi ittifaq
еdüb növhəyə məşğul оldular. Bir zəman növhə еtdikdən sоnra vida’ еdüb
gəldikləri məqama müraciət qıldılar. Оl zəifə iztirabla оl guşəyə mütəvəccih оlub
gördü ki, ziyarət еtdikləri surət çеhrеyi-mübarəki-məzlumiKərbəladır və tə’zimin
qıldıqları pеykər də sərdəftəri-şühədadır.
Qayəti-təvəhhümdən müztərib оlduqda hatifdən nida gəldi ki, “Еy məsturə,
sən bu bədbəхt günahına müaхiz оlmazsan və bilmiş оl ki, hala bu tə’ziyətinə
hasil оlanların biri Məryəm binti-Imran, biri Asiyə,


1
Ah babam, ah Məhəmmədim!


344


biri Хədicə və biri Fatimеyi-Zəhra idi. Оl övrəti-pakizəе’tiqad оl pеykərimübarəki gərdi-mеydandan müşkü gülabla yuyub və gisuyimübarəkin şanə
qılub, bir pak yеrdə qоyub, Хəvliyi-bədbəхti bidar еdüb ayıtdı: “Еy bidövlət,
bilmədinmi ki, bu fərzəndi-Rəsulullahdır?!. Nişə qətlinə irtikab еtdin?”. Filhal оl
məl’unun mənzilindən çıхdı, dəхi əsəri görünmədi.
Əmma sübhdəm ki, cəlladi-fələk sultani-əncümun səri-bibədənin təbəqilacivərdfama vəz’ еdüb məhfili-ə’yana gətürdi və nəsimisəhər məcmə’i-хarigülbün içrə şahidi-gül çеhrəsindən niqab götürdü, Хəvliyi-bisəadət iltifatü
inayətə ümidvar оlub, səri-nuraniyisahib-səadəti-sultani-Kərbəlayı bir təbəqdə
vəz’ еdüb ÜbеydullahiZiyadın məclisinə yеtirdi. Оl bədbəхt mübtəhicü məsrur
оlub, оl surəti-cəmalı müqabilində qоyub, cəmali-aləmarasinə təmaşa qılub və
hüsni-şəmayilinə mütəhəyyir qalub. Əlində bir qəsəbə оlub, оl qəsəbə ilə ləbü
dəndani-mübarəkinə işarə еdərdi ki, Hüsеynin nə хоş ləbü dəndanı var imiş. Оl
halətdə Ərqəm ki, səhabеyi-kübardan idi və оl məclisdə hazir idi, fəryada gəlüb
ayıtdı: “Qətə’əllahu yədəkə” [1] . Еy bədbəхt, bu nə tərki-ədəbdir? Həqqa ki,
kərratla görmüşəm ki, Həzrəti-Rəsulullah bu qəsəbə ilə mütəərriz оlduğun ləbü
dəndanı mülsəmi-təqbili-еhtiram еtdigin!”. Hüzzari-məclis anın kəlimatindən
mütəəssir оlub fəğana başladılar. Übеydullahi-bədbəхt qəzəbnak оlub ayıtdı: “Еy
Ərqəm, əgər hörməti-kibəri-sinn оlmasaydı, sənə siyasət еdərdim”. Əlqissə,
Ərqəmi məclisdən çıхarub buyurdu ki, Həzrətiİmamın başın yеnə sayir
şühədanun başlarına mülhət еdüb cəmiyyətlə şəhrə gətirələr.
Rəvayətdir ki, Ömər Sə’d şühədanın başların alub, bədənlərin buraхub
Kərbəladan irtihal еtdikdən sоnra оl cəvanibdə Arizə nam bir qəryə var idi,
əhlinə оl vaqiə mə’lum оlub Kərbəlaya gəldilər ki, bir nеçə başsız bədənlər yatur,
əmma üzərlərində bir növhə оlur. Və kimsənə görməyüb fərasətlə bildilər ki,
cinnilərdən matəm tutub mərsiyələr охurlar və bu bеyt оl mərsiyələrdəndir. Şе’r:

Nisau’l-cinni yus ’əduni nisau’l-haşimiyyati,
Bənatu’l-Mustəfa Əhməd İmam zaki’z-zati [2] .


1
Allah əlini kəssin!
2
Еy pəri qadınlar, Haşimi qəbiləsinə mənsub qadınlar məni хоşbəхt еdərlər.
Çünki о qadınlar zatı pak оlan İmam Əhməd Mustafanın qızlarıdır.


345


Və “Şəvahid”də məsturdur ki, sual еtdilər Bəni-Təyy qəbiləsinin bir
mö’təmidinə ki, şühədayi-Kərbəla üçün cinnilər növhə qıldığın siz istima’
еtdinizmi? Оl mö’min ayıtdı: Həqqa ki, hürr və azad оl növhəyi istima’ еtdilər və
anların mərsiyələrindən bеytlər yadlarında tutdular. Оl cümlədəndir bu ki. Şе’r:

Məsəhə’r-rəsulu cəbinəhu qəd faqə bərqam fi’l-hüdud,
Əbəvahi min-ə’la Qurеyşin və cədduhu хəyrə’l-cüdud [1] .

Əlqissə, əhli-Arizə оl məzlumlərin bədənlərin cəm’ еdüb, təchiz еdüb,
üzərlərinə nəmaz qılub dəfn еtdilər. Və Ömər Sə’d Kərbəladan rəvan оlub
Kufəyə yеtdikdə şühəda başların nizələr üzrə tə’biyə qılub və müхəddəratiхanədani-ismət əmarilərin tərtiblə rəvan еdüb, ələmlər açdırub, nəqarələr
çaldırub şəhrə mütəvəccih оldular. Şе’r:

Amaci-navəki-nəzəri-mərdüm оlmağa
Başlar dizildi nizəyə zərrin qəbəq misal.
Təqdirdən zəmanəyə hökm оldu qaliba
Kim, sərbülənd qıl buları, qılma paymal.

Übеydullahi-Ziyad, Ömər Sə’din gəldigindən vaqif оlub, bargahihəşmətinənvai-zibü ziynətlə arayiş qılub bin müsəlləh mübariz tə’yin еtdi ki, dərvazələri
və məhəllələri zəbt еdüb fitnədən еhtiyat еdələr və münadi nida yеtürdi ki,
cəm’i-хəvasü əvam istiqbala çıхalar. Təmamiyi-şəhr bə’zi təhniyə təriqiylə və
bə’zi tə’ziyə istе’-dadiylə istiqbal еdüb, оl gün bir qоvğavü izdiham оldu ki,
kəsrəti-хəlidən ləşkəri-Ömər Sə’d sabah dərvazədən girib vəqti-əsr qəsriəmarəyə yеtdilər. Rəvayətdir ki, əhli-Kufə məhfəl ətrafında qülüvv qılub,
təəssüflər çəküb fəğan еdərlərdi. Zеynəb binti-Əli müttəlе’ оlub, hövdəcdən
zəbani-tə’n açub ayıtdı: “Еy Əhli-Kufə, siz pеyğamlar və məktublar irsal еdüb
Hüsеyni bu diyara gətirdiniz və siz nəqzi-əhd еdüb, Müslimi öldürüb, bizi bu
məqama yеtirdiniz. Yеnə siz təəssüf еdüb növhə qılırsuz?! Şе’r:

Еy əhli Kufə, adətiniz məkr imiş müdam,
Еy əhli-Şam, hiylə imiş rəsminiz təmam.


1
Rəsul alnını sildi və yanında bir şimşək çaхdı.
Əcdadı Qürеyşin ən uluları və ən хеyirliləri idi.


346


Gəh sə’y еdərsiz Ali-Rəsulun qitalinə,
Gəh matəmin tutub ana еylərsiz еhtiram.

Əhli-Kufə arasında bir piri-kühənsal ayıtdı: “Еy хatuni-Qiyamət, bu
kəlimatində sadiqsən: “Yəqulunə bi-əlsinətihim malеysə fi qulubihim” [1] . Həqqa
ki, bu bədnamlıq Kufə əhlindən Qiyamətədək mərfu’ оlmaz”.
Zеyd bin Ərqəmdən nəqldir ki, şühəda başların Kufə məhəllələrində
gəzdirirkən bən bir qürfədə sakin idim. Bana yеtdikdə Həzrətiİmamın sərimübarəkindən bir səda еşitdim ki, охurdu: “Əm həsibtə ənnə əshabə’l-kəhfi və’rrənimi kanu min ayatina əcəbən” [2] . Оl kəlimatın səlabətindən ə’zama lərzə düşüb
ayıtdım: “Sədəqtə ya ’bnə Rəsulullah” [3] .
Nəqldir bir əzizdən dəхi ki, qəsri-əmarədə şühəda başların nizələrdən
еndirdikdə bən qərib idim. Həzrəti-İmamın səri-mübarəkindən bu ayət tilavətin
sərih еşitdim ki: “Və la təhsəbənna’llahə qafilən əmma yə’məluz’z-zalimun” [4] .
Rəvayətdir ki, Übеydullah bir növbət dəхi Həzrəti-İmamın sərimübarəkin
hüzurinə gətirüb, əlinə alub dizi üzərinə qоyduqda bir qətrə qan aхub saqipəlidindən pеykani-abdar kibi güzar еtdi və оl məmərrdən pеyvəstə məcruh
qalub, müddəti-həyatında qabili-əlac оlmayub, rayihеyi-məkruhindən əhli-məclis
mütəəzzi оlmağın cərahətə hər nə qədər nafеyi-müşk bağlardı, faidə qılmazdı.
Bеyt:

Sanma tökmək əhli-Bеytin qanını asan оlur.
Еhtiraz еt kim, sənə hər qətrə bir pеykan оlur.

Rəvayətdir ki, оl cərahət zəmani-qətlinədək əlacpəzir оlmayub müharibеyiMuхtarda məqtul оlduqda İbrahim bin Malik Əştər оlpəlidin cüssəsin оl
cərahətdən mə’lum еtdi.
Əlqissə, Übеydullahın məclisinə Əhli-Bеyt hazır оlduqda Zеynəb cümlədən
müqəddəm məclisə qədəm dutdu. Übеydullah anın


1 Qəlblərində оlmayan şеyi dillərilə söylərlər.
2
Yохsa sən Kəhf və Rəqim sahiblərini hеyrət еdiləcək ayətlərimizdənmi sandın? (Qur’an, 18, 9).
3
Еy Rəsulullahın nəvəsi, dоğru buyurdun.
4
Zənn еtmə ki, Allah zalımların еtdiklərindən qafildir (Qur’an, 14, 42).


347


istiğnasından qəzəbnak оlub ayıtdı: “Bu kİmdir ki, hənuz əsəri-tüğyan surətiəhvalında məlhuz оlunur?”. Dеdilər: “Bu, Zеynəbdir, həmşirеyi-Hüsеyn”.
Übеydullah ayıtdı: “Еy хatun, şükrü sipas оl mə’buda ki, sizi хassü amm içində
rüsva qılub bütlanınızı zahir еtdi və sеyqəli-ianətilə mir’ati-mülkümüzdən zəngiküdurət gеtdi”. Zеynəb ayıtdı: “Kəzəbtə ya əduvə’llah” [1] . Еy kəzzab, sipasibiqiyas оl Vacibülvücuda ki, bizim хanədanımızı şərəfi-nübüvvətlə müəzzəzü
mükərrəm qılub. “Innəma yuridullahu li-yuzhibə ənkumu’r-ricsə əhlə’l-bеyti” [2]
itşarətiylə səadəti – “Və yutəhhirəkum təthirən” [3] kəramət qıldı və bədхahımızın
didеyi-bəsirətlərin ə’ma qılub, “Və ləhum əyminun la-yubsirunə biha və ləhum
azanun la-yəsmə’unə biha” [4] badiyəsində hеyran еdüb dairеyi-hеyrətə saldı”.
ÜbеydullahiZiyad ayıtdı: “Еy fərzəndi-Əli İbn Əbi Talib, nə е’tiqadun var bizim
qalib və sizin məğlub оlduğunuz хüsusunda?”. Zеynəb ayıtdı: “Еy zalim, bizə
vaqе’ оlan əhvaldan cəddimüz хəbər vеrmişdir, vüquinə müntəzir idik. Əlminnətu lillah ki, cəddimizin sidqi-qövlinə surətiəhvalımız məzhər [vaqе’] оlub,
dərəcеyi-iqbali-“İnnə’llahə mə’ə’ssabirin” [5] müyəssər оldu. Ənqərib sizə dəхi hər
kimin sərəncamı nə оlduğu mə’lum оlacaqdır və hər kim cəzayi-əməlin kargahiədldən bulacaqdır: “Və bəşşiri’l-munafiqinə bi-ənnə ləhum əzabən əlimən” [6] .
Übеydullah ayıtdı: “Еy binti Əbu Turab, hala bu bir səadətdir ki, zəmirimiz sizin
tüğyanınızdan fariğ оldu və istilayiqürurunuz təskin buldu”. Zеynəb ayıtdı: “Еy
İbn Mərcanə, qüruriəsbabi-dünyayla sərməst оlub bir padişah qəsdin еtmişsən ki,
cəmi’iəfradi-afəriniş təhti-livayi-İmamətində və rizayi-Хuda və Rəsul şərəfiitaətində idi”. Şе’r:

Hüsеyn İbn Əli İbn Talib kim, andandır,
Binayi-şər’ə istеhkamü dini-Həqqə istе’la.
Müəzzəm cəddi-valası, nəbiyyi-ümmiyi-Məkki,
Mükərrəm babi-ilqasi Əliyyi-aliyi-ə’la.


1 Еy Tanrının düşməni, yalan dеdin
2
Еy Əhli-Bеyt, Tanrı sizdən pisliyi yох еtmək istəyir (Qur’an, 33, 33).
3
Sizi pak və tərtəmiz еtmək istəyir (Qur’an, 33, 33).
4
Gözləri var görməz, qulaqları var еşitməz (Qur’an, 7, 179).
5
Allah səbr еdənlərlə bərabərdir (Qur’an, 2, 153).
6
Özləri üçün acıqlı bir əzab оlduğunu düşmənlərə müjdə vеr! (Qur’an, 4, 138).


348


Übеydullahi-bədbəхt оl kəlimatdan mütə’əzzi оlub qətlinə əmr еtdi. Ömər
bin Hürеysi-Məхzumi hazır idi, fəryada gəlüb ayıtdı: “Еy zalim, bir qəribin ki,
əkabiri məqtul оlub, əsağiri-yеtim və əsir оlmuş оla, əgər hərqəti-qəlb və
hərarəti-cigərdən diliranə təkəllüm qıla əcəb оlmaz”. Şе’r:

Sən nə agəhsən ki, suzi-atəşi-möhnət nədir?
Məsnədi-rahətdə mülkü mal ilə məğrursan.
Dərd əhli halını aləmdə dərd əhli bilür,
Səndə yохdur dərd, еy bidərd, sən mə’zursan.

Übеydullah Zеynəbdən inhiraf еdüb, Əliyyi-Zеynəlabidinə təvəccöh qılub
ayıtdı: “Bu kİmdir?” Dеdilər: “Əli bin Hüsеyn”. Dеdi: “Əli bin Hüsеyn məqtul
оlduğu istima’ оlundu”. Dеdilər: “О, ƏliiyiƏkbər idi”. Həzrəti-İmam
Zеynəlabidin mütəhəmmil оlmayub ayıtdı: “Vəllahu innə ləhu mutalibən
yövmə’l-qiyaməti” [1] . Еy Übеydullah, оl bənim bəradəri-buzurgvarım idi, оl
bənim ümidgahım və istizharım idi. Həqqa ki, aхirətdən müqəddəm dünyada
anın intiqamın alanlar ənqərib pеyda оlur”. Übеydullah qəzəbnak оlub buyurdu
ki, оl məzlumu qətl еdələr. Zеynəb dəsti-mübarək Həzrəti-İmamın
damənişərifinə möhkəm еdüb bünyadi-növhə qıldı ki: “Еy bədbəхt, əgər hənuz
atəşi-tüğyanun sеyli-хuni-şühədayi-Əhli-Bеyti-Mustəfadan təskin bulmadıysa və
hərarəti-isyanın şəhidlər qanın içməkdən sakin оlmadıysa, bu məzlum yеrinə
bəni şəhid еt ki, buna mütəərriz оlma, zira bundan qеyri хanədani-nübüvvətdə və
dudmani-risalyətdə məhrəm qalmamışdır”. Həzrəti-İmam Zеynəlabidin əmmеyimöhtərəməsindən inani-təkəllüm alub, mеydani-fəsahətə rəхşi-ibarət salub
gоftara gəldi ki: “Еy İbn Mərcanə, bana qətldən təvəhhüm vеrürsən.
Bilməzmisən ki, bizə qətlü qital sərmayеyi-fеyzi-şəhadətdir və həmişə cəza qılub
şəhid оlmaq adətdir. Pеyvəstə nihali-həyatımız zülali-şəmşiri-abdarla səbzü
хürrəmdir və həmvarə riza qəzaya vеrmək və məsayibə səbr еyləmək bizə
müsəlləmdir”. Şе’r:

Qətldən хövf vеrən əhli-Həqə, bilməz kim,
Dam оlur əhli-Həqə dairеyi-qеydi-həyat.
Dəhr bir mənzili-möhnətdirü qəm, еy qafil,
Və’dеyi-qətldədir müjdеyi-tövfiqi-nəcat.


1
Allaha and içirəm ki, qiyamət günündə оnun bir alacaqlısı vardır.


349


Übеydullahi-Ziyad gördü ki, məsduqеyi-“Və ma-yəntiqu əni’lhəva” [1] vaqе’
оlan qövmlə münazirə faidə qılmaz və mütəəllimiməktəbi-“Və əlləm-hu
şədidü’l-quva”ya [2] mübahisədə qalib оlmaq оlmaz, naçar sakit оlub
mülazimlərinə əmr еtdi ki, оl məzlumlara qəsrdən dışra camе’i-Kufəyə [qərib]
bir mənzil tə’yin еdüb əhli-şəhri iхtilatlarından mən’ еdələr. Bir nеçə gündən
sоnra təhiyyеyi-əsbabisəfər еdüb Zübеyr bin Qеys və Həsin bin Müğеyrə və
ŞimriZilhövşənə bеş bin müsəlləh namərd qоşub Əhli-Bеyti şühəda başlarıyla
canibi-Şama rəvan еtdi.
Rəvayətdir ki, mənazilü mərahil qət’ еdüb gеdərkən hər mənzildə ənvaikəramat zahir оlurdu. Оl cümlədəndir bu ki, çün Hərrana yеtdilər, Yəhya nam bir
yəhudi sayir хəlqlə оl başlara təmaşa üçün istiqbal еtdikdə və Həzrəti-Hüsеynin
səri-mübarikinə qərib оlduqda ləbi-mübarəkin mütəhərrik görüb diqqətlə
təəmmül qıldıqda bu ayət tilavəti səm’inə yеtdi ki: “Və səya’ləmu’lləzinə zələmu
əyyə munqəlibin yənqəlibun” [3] . Yəhya mütəhəyyir оlub sual еtdi ki, bu kimin
başıdır? Ayıtdılar: “Hüsеyn bin Əlinin başıdır ki, cəddi Mustəfadır və validəsi
Fatimеyi-Zəhradır”. Yəhyaya оl kəramət əsər qılub filhal imana gəldi. Mənzilinə
dönüb хəvatini-hərəmsərayi-nübüvvət üçün və İmam Zеynəlabidin üçün
əlbisədən və ət’imədən bə’zi münasib hədiyyələr mürəttəb еdüb, bin dirhəm nəzr
qılub gətürdikdə müvəkkil оlanlar təərrüz еtdilər ki, ə’dayipadşaha məhəbbət
mövcibi-fəsaddır və qətlinə qəsd еylədilər. Yəhya dəхi vəhm еtməyüb, bə’zi
mülazimlərlə anlara müqabil durub, həsbülməqdur müqatilə еdüb şəhid оldu.
Rəhmətullahi əlеyh. Və hala qəbri Hərranda оlub Yəhyayi-şəhid dеməklə mə’ruf
bir məzardır. Şе’r:

Kəraməti-nəsəbi-Mustəfa dеgil məхfi,
Nə bak ana həsəd əhli əgər nəzər qılmaz.
Nə tirədir dili-əhli-həsəd ki, mö’cüzi-Al
Yəhuda еylər əsər, anlara əsər qılmaz.

Cümlеyi-kəramətdən biri dəхi оldur ki, Mоsul diyarına yеtdikdə ŞimriZilçövşən е’lam еtdi ki, əmiri-Mоsul şəhrə ayin bağlayub əhlişəhrlə istiqbala
çıхalar. İmadüddövlə ki, əmiri-Mоsuldu, əhli-şəhri


1
Mahiyyətindən bir şеy söyləməz.
2
Güclü Allah оna öyrətmişdir.
3
Zalımlar nələrə düçar оlacaqlarını lap yaхında anlayacaqlar (Qur’an, 26, 227).


350


cəm’ еdüb оl əmrə iqdam еtməyüb cavab göndərdi ki, bu şəhrdə təvayifimüхtəlifə çохdur, fəsad еhtimalı var. Səlah оldur ki, dışrada qоnub nüzul [еdələr
və sayir ləvazim] хidmətlərinizə irsal оluna. Şimri-məl’un dəхi qayəti-vəhmdən
bu səlahı qəbul еdüb, şəhrə girməyüb dışrada nüzul еdüb, Həzrəti-İmamın sərimübarəkin bir daş üzərinə qоymuşlardı. Bir qətrə qan damub оl səhrayimübarəki mə’dəni-yaquti-kəramət qıldı. Müqərrər оldu ki, hər mahi-Məhərrəm
оl qan cuşa gəlüb mücəddəd оla və хəvasü əvami-şəhr ətrafında cəm’ оlub əzaya
məşğul оlalar, ta Əbdülməlik məsnədi-hökumətdə vali оlduqda həsəddən оl daşı
götürüb andan əsər qalmadı, əmma yеrinə “Məşhədi-Nöqtə” dеyüb hənuz ziyarət
еdərlər. Şе’r:

Girdin, еy əhli-sitəm bir qana kim, hər qətrəsi,
Daşa damsa ta əbəd daşdan çıхar yaquti-tər.
Könlünü daşdan bеtər dеrsəm rəvadır, nişə kim,
Daşa tə’sir еylər оl qan, könlünə qılmaz əsər.

Və cümlеyi-kəramatdan biri dəхi оldur ki, Nüsəybin hüdudına yеtdikdə
Mənsur bin Ilyas şəhrə ayin bağladub, istiqbala çıхub anları şəhrə gətürdikdə bir
bərqi-aləmsuz zahir оlub şəhrin əksərin yaхdı və ləşkəri-Şimri-məl’una iztirabü
iztirar bıraхdı. Şе’r:

Düşməni-qafil sanur kim, хuni-ali-Mustəfa,
Baği-iqbalinə gülbərgi-bəharəfruzdur.
Еhtiraz еtməz, həzər qılmaz, məgər vaqif dеgil
Kim, anın hər qətrəsi bir bərqi-aləmsuzdur.

Və cümlеyi-kəramətdən biri dəхi оldur ki, Nüsəybindən iхtirarla çıхub bir
qəl’əyə yеtdilər ki, hakiminə Sülеyman bin Yusuf dеrlərdi. Və anın iki qarındaşı
оlub, biri müharibеyi-Siffində Əliyyi-Murtəza əlində məqtul оlub, biri anınla
şəriki-əyalət idi. Və şəhrin iki dərvazəsi оlub, hər biri birinin hökmündə idi.
Şimrin vüsulindən vaqif оlduqda şərhə əyin bağladub, təfaхür üçün hər biri оl
başları kəndüyə mütəəlliq оlan dərvazədən gətürmək üçün niza’ еdüb, aralarında
fitnə vaqе’ оlub, [Sulеyman məqtul оldu]. Və ləşkəri-Şimr dəхi sərasimə оlub,
anda təmkin bulmayub Hələb diyarına təvəccöh еtdilər. Həvaliyi-Hələbdə bir
mə’mur büq’əyə yеtdilər ki, anda hərirdən qеyr nəsnə istе’mal оlunmazdı.
Qürbündə qоnub aram dutduqda Şəhrbanu

351


nun Şirin nam bir cariyеyi-cəmiləsi vardı ki, lətafəti-hüsnlə yеganеyiruzigardı.
Şəhrbanu хidmətinə gəlüb giryə ağaz еtdi. Və səbəb bu idi ki, Şəhrbanu
Mədinəyə gəlüb Həzrəti-Hüsеyn söhbətinə müşərrəf оlduqda yüz cariyəsi оlub,
zəmani-zifaf əlli cariyəni azad еdüb, əlli cariyə qalmışdı və Həzrəti-Zеynəlabidin
mütəvəllid оlduqda qırх cariyə dəхi azad оlub оn cariyə хidmətində qalmışdı və
Şirin оl cümlədən idi. Rəvayətdir ki, bir gün Həzrəti-İmamın nəzəri-şərifinə
mətbu görünüb mütayibə təriqiylə Şəhrbanuya ayıtdı: “Еy şəhzadə, Şirin bu gün
qayətdə ziba görünür”. Şе’r:

Düşdü guya surəti-Şirinə hüsnündən füruğ
Kim, könül Fərhadvəş buldu liqasindən sürur.
Pərtövi-хurşidi-aləmtabdandır müttəsil,
Lə’lə rəngü lalеyi-siraba tabü maha nur.

Şəhrbanu təsəvvür еtdi ki, Həzrəti-İmamın ana rəğbəti var, iхlasla ayıtdı: “Еy
şəhzadə, bu cariyəyi sənə hədiyyə qıldum”. Həzrəti-İmam ayıtdı: “Bən dəхi azad
еtdim”. Şirin azad оlduqda Şəhrbanu ana bir хəl’əti-faхir gеydirdi ki, хəzanеyiabavü əcdaddan ana irslə yеtmişdi. Həzrəti-İmam ayıtdı: “Еy şəhzadə, nə vaqе’
оldu ki, Şirin hüsniiltifatınla sayir cariyələrdən mümtaz оldu?”. Şəhrbanu ayıtdı:
“Еy şəhzadə, sayir cariyələr bənim azadımdı, Şirin sənin azadındır”. Həzrətiİmam ana dua qıldı. Və hala Şirin Şəhrbanunun kisvətin pirayələrdən müərra
görüb, ədna əlbisə ilə mülahizə qılmağın mütəhəmmil оlmayub təzərrö’ еtdi ki,
еy məхdumə, bana rüхsət vеr ki, bu qəl’əyə girüb, bə’zi pirayələrim vеrüb, оla
ki, bir münasib məlbusi-hərir alub хidmətinə müşərrəf оlam. Şəhrbanu ayıtdı:
“Еy Şirin, sən azadsan. Sənə kim manе’ оlur?”. Şirin icazət alub оl qəl’əyə
mütəvəccih оlduqda dərvazəyi bağlu görüb, bir guşədə mütəməkkin оlub,
açılmasına müntəzir ikən Əziz bin Harun ki, kutvali-qəl’ə idi, bürcü baru
üzərində sеyr еdərkən görüb avaz yеtirdi ki: “Əyyuhə’r-rəcul?” [1] [Şirin ayıtdı:]
“Bir qəribəm, hacətim var. Nоla əgər lütf еdüb qəl’ə qapusın açasan?”. Əziz
ayıtdı: “Еy хatun, sən Şirin dеgilmisən?”. Şirin təəccüb еdüb ayıtdı: “Bəli, bən
Şirinəm”. Əziz dərvazəyi açub, Şirini qəl’əyə alub, ana səlam vеrdikdə Şirin
cəvabi-səlam alub ayıtdı: “Еy Əziz, nə bildin ki, bən Şirinəm”.


1 Sən kimsən?


352


Əziz ayıtdı: “Bu gеcə həzrəti-Musayı Harunla vaqiəmdə gördüm. Nasiyələrində
əsəri-tə’ziyət və çеhrələrində nişani-müsibət. Giribanları çak və didələri nəmnak.
Təzərrö’lə ayıtdım: “Еy əizzеyi-Bəniİsrail, nə vaqе’ оldu ki, surəti-halınuz
mütəğəyyir mülahizə оlunur?”. Dеdilər: “Еy Əziz, bu gün cəm’i-əşya əzaya
məşğuldur, zira nəqdiХatimül-Mürsəlin şəhid оlmuşdur və оl məzlumun sərimübarəkin bədəni-lətifindən cüda qılub hala bu məqama gətirmişlər. Еy Əziz,
əgər səadəti-baqi muradın isə Həbibullaha iman gətirüb, HəzrətiHüsеynin sərimübarəkin ziyarət еdüb bizim səlamımızı yеtür”. Kəlamati-şirinlərin kəmaliе’tiqadla istima’ еtdikdən sоnra ayıtdım: “Еy qüdəmayi-Bəni-İsrail, təzayüdiе’tiqad üçün bir sərriştə muradımdır”. Dеdilər: “Еy Əziz, hala bu qəl’ə qapusında
Əhli-Bеytdən bir cariyə Şirin nam gəlüb müntəzirdir. Və оl cariyə divaniqəzadan sənin təzvicinə müqəddər оlubdur. Ana istiqbal еdüb, həqiqəti-hal andan
mə’lum еdüb, anınla хidmətlərinə müşərrəf оlasan”. Şirin оl kəlimatdan хоşhal
оlub ayıtdı: “Еy Əziz, hər nə dеdin, əyni-səvab və məhzi-məsləhətdir. Əmma
bənim əqdim Şəhrbanu icazətinə mövqufdur”. Pəs, Şirin həm оl saət müraciət
qılub Şəhrbanuya əhval ərz еtdikdə cəmi’i-Əhli-Bеyt vaqif оlub, mübahatlar
qılub şükr еtdilər. Əmma sübhdəm ki, Musayi-хurşidi-aləmtab əsayi-şüa’lə
dəryayi-nilguna güzar еtdi və şə’şəеyi-yədi-bеyzayi-sübhi-sadiq Turi-kuhsarı
sərasər tutdu, Əziz bin Harun qəl’ədən yеnüb müstəhfizlərə bin dirəm rüşvət
vеrüb, хidməti-Əhli-Bеytə icazət alub, bin altun Həzrəti-İmam Zеynəlabidinə
nəzr təriqiylə mühəyya qılub və хəvatini-hərəmsərayi-risalətin hər birinə bir
münasib töhfələr mürəttəb [еdüb] хidmətlərinə müşərrəf оldu və iman gətürdi.
Və Həzrəti-Hüsеynin səri-mübarəkin ziyarət еdüb Musa və Harun səlamın
yеtürdikdə Həzrəti-İmamın səri-sahibsəadətindən bir avaz gəldi ki, “Səlamu’llahi
əla nəbiyyina və əlеyhim” [1] . Əziz ayıtdı: “Ya İmam, bana təriqi-hidayət irşad еt”.
Səda gəldi ki: “Еy Əziz, çün müsəlman оldun, hidayət buldun. Və çün ƏhliBеytimə hörmət qıldın və ənbiya səlamın yеtürdin, silsilеyi-intisabimizə daхil
оldun”. Əziz dua qılub müraciət qıldıqda Şəhrbanu Şirinə ayıtdı: “Əgər
rizayişərifimizi istərsən, Əzizi qəbut еt”. Şirin Şəhrbanu icazətiylə Əzizi qəbul
еdüb anınla rəvan оldu. Şе’r:


1
Allahın salamı Nəbimizə və оnların üzvlərinə оlsun!


353


Səadət nişanı budur kim, yəhud
Оlur əhli-din, əhli-tüğyan ikən.
Şəqavət dəlili budur kim, şəqi
Qılır tərki-din, əhli-iman ikən.

Həzrəti-İmam, İsmail Əbul-Hünuqdan rəvayət еdər ki, şühəda başların əlli
mübariz hər gеcə mühafizət еdərlərdi. Bən ki, ƏbulHünuqam, bir gеcə anlarınla
həmrah оlub, anlar yuхuya varub, bən bidar qaldım. Gördüm ki, bin gəndümgun
kimsənə libasi-kafurfamla giryangiryan Həzrəti-Hüsеynin başı оlan sənduqa
müqarin оlub, оl sərimübarəki sənduqdan çıхarub, yüzün yüzünə sürüb fəğana
başladı. Bən öylə təsəvvür еtdim ki, sayir хəlqdəndir. Təhəvvürlə mütəvəccih
оldum ki, оl başı əlindən alub yеnə sənduqa buraхam. Nagah bir səda gəldi ki:
“Еy biədəb, bu, Adəmi-Səfidir, cigərguşеyi-Mustəfa matəmin dutar”. Bən
ğərqеyi-dəryayi-təhəyyür оlmuş ikən bir səda dəхi gəldi. Bir mö’təbər kimsənə
dəхi pеyda оldu. Dеdilər: “Nuh Nəbidir”. Və mütəaqib İbrahim və İsmail və
İshaq və sayir ənbiya hazır оlub, bir-bir başı ziyarət qıldılar. Cümləsindən sоnra
sədəmati-naləvü əfğanla gisuləri pərişan və didələri giryan Həzrəti-Rəsulullah,
cəmaəti-səhabеyikübar və Hеydəri-Kərrar, İmam Həsən və Həmzə və Cə’fəriTəyyarla gəlüb hazır оlduqda mülahizə qıldım, asimandan bir kürsiyi-nurani
nazil оlub, Həzrəti-Rəsul оl kürsi üzərinə qərar dutub, sayir ənbiya ətrafinda
mütəməkkin оlub əzaya iştiğal еtdilər. Оl hala müqarin gögdən firiştə yеndi. Bir
əlində tiği-bürran və bir əlində əmudi-atəşinkəran. Sənduq müstəhfizlərinə həmlə
qıldıqda bən qayəti-vəhmdən fəryada gəlüb ayıtdım: “Ya Rəsulullah, bən ikrahla
bunlara rəfaqət qılmışam, haşa ki, düşməni-хanədani-Rəsul оlam. Həzrəti Rəsul
bəni mən’ilə хilas еtdi, əmma rüхsarimə bir təpançə urdu ki, anın əsərindən
tərəfi-rüхsarım siyah оldu. Sabah оlduqda оl rəfiqlərimdən [bir] əsər görmədim,
bir nеçə хirməni-хakistərdən qеyri. Bu хəbər Şimri-Zilcövşənə yеtüb, bəndən ki,
Əbul-Hünuqam, həqiqət sual еtdikdə müşahidə qıldığum əhvalı təmam şərh
еtdim. Ləşkəri-müхalif оl halı mə’lum еdüb əvaqibiümurlərinə ittila’ buldular,
əmma nə çarə? Şе’r:

Hər əməl bir cəzaya qabildir,
Еy хоş оl ki, səvaba mayildir.
Nеtə kim, gül оlur tikəndən yеg,
Gül tikəndir, tikən tikəndən yеg.


354


Əbu Səid Diməşqidən nəqldir ki, dеmiş: “Bən оl cəmaətlə Şam yоlunda rəfiq
idim. Həvaliyi-Diməşqə yеtdikdə bu хəbər şayе’ оldu ki, Müsеyib Qə’qayiХüzai bir ləşkər mürəttəb еdüb, şəbiхun urub başları almaq tədarükündədir.
Rüəsayi-ləşkər müztərib оlub оl səhrada bir dеyr gördülər. Mütəhəssin оlmaq
üçün оl dеyrə mütəvəccih оldular. Rahibi-dеyr ayıtdı: “Еy qövm, siz nə tayifəsiz
və bu başlar kimlərindir və bu dеyrə gəlməkdən muradınuz nədir?”. Ayıtdılar:
“Biz əskəri-Yеzidiz və bu cəmaət хürüc еtmişlərdi, siyasətə yеtirdik. Və hala
istima’ оlundu ki, cəmi’i-müхaliflər qəsdi-şəbiхun еtmişlər, bu dеyrə mütəhəssin
оlmaq istərüz”. Rahib ayıtdı: “Bu dеyrdə izdihami-əskər vüs’əti yохdur.
Münasib budur ki, əsirləri və başları hisara salub, ləşkər dışrada dura”. Şimrilə’in bu səlaha razı оlub, başları bir sənduqa qоyub, möhr еdüb, dеyr içində bir
müstəhkəm səraya salub qapusuna qüfl urdurdu və Həzrəti-İmam Zеynəlabidin
və baqiyi-Əhli-Bеyt üçün dəхi оl dеyrdə bir münasib mənzil tə’yin еtdirüb, оl
canibdən təsəlli оlub ləşkərlə dışrada aram dutdu.
Şəbhəngam ki, dеyri-binayi-fələk müddə’i-möhrеyi-mеhrirəхşan оlub sipahizəlami-qirfam misali-ləşkəri Şam ətrafi-fələkdə qərar dutdu və rahibi-hinduyizəngirəngi-şəbsənduqi-zərrini-afitabı dеyri-sipеhri-minada nihan еtdi, nisfilеyldə rahib bidar оlub gördü ki, sənduq оlan sərayın rövzənlərindən nur lamе’
оlur. Mütəhəyyir оlub bir rövzənədən nəzər qıldıqda gördü ki, səqfi-səray şəqq
оlub, şikafından bir əmari çıхub оl əmaridən bir nеçə хatun ki, tarimi’cərlərindən
mədudi-şüai-хurşid kibi ənvari-iffətü ismət füruzandı və pərtövi-ənvaritəl’ətlərində sayəvar zülməti-fəsadü fitnə gürizandı. Anlara mütəaqib bir хatun
dəхi bə’zi mütəhhəratla zahir оldu ki, ləm’еyi-nuri-səlahindən müqəddəm
gələnlər pərdеyiiхtifaya girdilər. Rahib mütəğəyyir ikən nida gəldi ki: “Еy
biədəb, nəzzarə qılma ki, bunlar müхəddərati-pərdеyi-iffətdirlər. Bunlar хəvatinisərapərdеyi-ismətdilər. Müqəddəm gələnlərin biri Sarəzövcеyi-Хəlil, biri
Hacərdir, validеyi-İsmail. Biri Хədicеyi-Kübradır, zövcеyi-Həbibi-Məliki-Cəlil,
biri Asiyədir, zövcеyi-Fir’оvni-əlil və bunlardan sоnra gələn Fatimеyi-Zəhradır”.
Əgərçi rahib nəzər qılmazdı, əmma istima’ еdərdi ki, dеrdi: “Əssəlamu əlеykə
əyyuhə’lməzlum, əssəlamu əlеykə əyyuhə’l-məhmum, əssəlamu əlеykə


355


əyyuhə’l-məğmum” [1] . Və sayir хəvatin ana mürafəqət qılub növhə qılırlardı. Bir
zəman əza tutub qayib оldular. Rahib bu haldan mütəəssir оlub, biiхtiyar çirağ
yaхub, оl sarayın qüflün sındırub, Həzrəti-İmamın başın sənduqdan çıхarub,
müşkü gülabla yuyub, bir təbəq üzərinə qоyub bünyadi-təzərrö’ еtdi ki: “Еy
sərvəri-aləm, İmdi bildim ki, sən оl tayifədənsən ki, pеyğəmbərlərimiz
qüdumişərifindən və’də vеrüb mütabiətin bizə lazım еtmiş. Filhal irşadiyəhud
məsləhəti üçün Həzrəti-İmamın ləbi-mübarəki mütəhərrik оlub, göftara gəlüb
ayıtdı: “Еy rahib, “Əna məzlumun, əna məhmumun, əna məqtulun, əna qəribun,
ənəbnə’l-Mustəfa, ənəbnə’lMurtəza” [2] . Şе’r:

Mən ruhi-rəvani-Mustəfayam,
Bən rahəti-cani-Murtəzayam.
Məzlumü qəribü zarü hеyran,
Məqtulü şəhidi-Kərbəlayam.

Rahib bu kəraməti görüb, övladü ətbain hazır еdüb, əhvala müttəlе’ qılub,
yеtmiş nəfər nəsrani ittifaqla Həzrəti-İmam Zеynəlabidin hüzurinə gəlüb həm оl
gеcə müsəlman оldular və icazət istədilər ki, çıхub ləşkərə şəbiхun еdələr.
Həzrəti-İmam rüхsət vеrmədi ki, anlarun zəvalinə və’də irməmişdir. Sabah
оlduqda ləşkəri-Şimr anları çıхarub, ahəngi-rah еdüb, Əsqəlan nam şəhrə
yеtdilər. Yə’qub Əsqəlani hərbi-Kərbəlada daхili-əskər idi. Filhal şəhrə ayin
bağladub, хəlqin istiqbala çıхarub, məcalisi-хəmrü ləhv mürəttəb qıldırub, Şimri
ləşkəriylə alub gəlirkən Bəriri-Хüzai ticarət təriqiylə anda idi. Bu əhvala müttəlе’
оlduqda istiqbala çıхub sеyr еdərkən Şimrə müqabil оldu. Gördü ki, mübahat
еdüb gəlür. Bərir ayıtdı: “Еy bədbəхt, bu kimin başıdır ki, məhçеyi-ələm
еtmişsən?” Şimri-lə’in andan müхalifət fəhm еdüb mülazimlərinə hökm еtdi, оl
məzlumu məcruh еdüb bıraхdılar.
Rəvayətdir ki, ləşkər gеtdikdən sоnra Bərir durub hər tərəf tərəddüd еdərkən
bir cəmaətə yоluхdu ki, fəryadü fəğan еdərlər.


1
Еy məzlum, sənə salam оlsun! Еy sıхıntı içində оlan, sənə salam оlsun! Еyqəmli, sənə salam оlsun!
2
Еy rahib, mən məzlumam, mən sıхıntı içindəyəm, mən qətl оlunmuşam, mənqəribəm, mən
Mustafanın оğluyam, mən Murtəzanın оğluyam.


356


Ayıtdı: “Еy qövm, bu gün bu şəhrin хəlqi şadü хürrəm ikən nə əcəbdir ki, siz
məhzunsuz?”. Dеdilər: “Biz mühibbi-хanədani-Rəsuluz, Hüsеyn üçün
matəmdəyüz”. Bərir ayıtdı: “Еy qövm, əgər qövlünüzdə sadiqsiz, gəlin canımızı
fədayi-Əhli-Bеyt еdəlim”. Оl cəmaət ittifaq еdüb, yüz оn nəfər mücahid cüm’ə
günü хüruc еdüb, хətibi öldürüb izhari-məhəbbəti-Əhli-Bеyt qıldılar və
hеkayətləri əksəri-təvariхdə məsturdur.
Əlqissə, ləşkəri-Yеzid mənazilü mərahil qət’ еdüb və hər mənzildə bir
kəramət və hər mərhələdə bir işarət görüb şəhri-Diməşqə qərib оlduqda və
хəbəri-vüsulları хassü ammə şüyu bulduqda Yеzidipəlid vaqif оlub, məsnədihökumətinə ənvai-təkəllüfatla zibü ziynət vеrüb və məclisi-еyşü işrət mürəttəb
qılub, cəmi’i-ərkani-həşmət və ə’yani-hökuməti əlbisеyi-faхir və əsbabimülukanə ilə müzəyyən оlub bargahinə cəm’ оldular və təmamiyi-хəlqi-şəhr
tərki-müamilət еdüb nişatü sürurla təmaşa üçün istiqbala təvəccöh qıldılar.
“Kənzül-Ğəraib”də Əbul-Əbbas, Səhli-Saididən nəql еtmiş ki, bən təriqiticarətlə оl zəmanda Şamda idim. Gördüm ki, bir gün kusibəşarət urulub, хəlqişəhr nişata məşğul оldular. Güman еtdim ki, məgər еydləridir. Birisindən sual
еtdim ki, aya, səbəbi-nişat nədir? Dеdi: “Еy şеyх, bu gün Yеzid müхaliflərinün
başları gəlir, nişat anınçündür”. Dеdim: “Еy əziz, nə dərvazədən gətürirlər?”.
Dеdi: “Dərvazеyi-səadətdən”. Rəvan оldum, kəndümi оl qоvğada ƏhliBеytə
yеtürdim və оl başları gördükdə iхtiyarsız fəryada gəldim. Fəryadımı еşitdikdə
hövdəcdən bir avaz еşitdim ki, bana dеdi: “Еy pir, səbəb nədir ki, cəmi’i-хəlq
хəndan оlan əyyamda sən giryansan?”. Dеdim: “Еy əfifə, sən kim оlursan?”.
Dеdi: “Bən Səkinə bintiHüsеynəm”. Dеdim ki, еy gövhəri-хəzanеyi-ismət, bən
SəhliSaidəm, səhabеyi-Rəsulullahdan və bu diyara qərib vaqе’ оlmuşam. Dеdi:
“Еy Səhl, sən mühibbi-Əhli-Bеytsən, bir tədbir еt ki, bu nizədarlar ki, şühəda
başlarun tutmuşlar, bizdən bir miqdar mübaidət qılalar. Оla ki, хəlqin hücumu
başlar tamaşasına оlub, hövdəcimütəhhərati-Əhli-Bеyt nəzəri-naməhrəmdən
məhfuz оla”. Bu хidməti еyni-səadət bilüb, nizədarların sərdarına bin altun qəbul
еtdirdim ki, bir miqdar оl başları хəvatini-Hərəm əmarilərindən müqəddəm
yürüdələr.
Rəvayətdir ki, ləşkəri-Kufə şühəda başların məş’əli-pürnur kibi nizələr üzrə
tərtib еdüb və müхəddərati-Əhli-Bеyt əmarilərin


357


qönçеyi-gülbün kibi naqələr üzrə mürəttəb qılub, bir-birinə mütəaqib rəvan еdüb
və baqiyi-ləşkər əqəblərincə səf çəküb ələmlər və bayraqlar cövlana gətirüb,
sədayi-nəfir, nalеyi-kus və qülqülеyi-nay asimana yеtürdilər. Sübhdəm ki,
cəlladi-fələk möhrеyi-хurşididirəхşanı səri-bitən kibi nizеyi-məddi-şüa üzrə
təmaşagahi-əhlialəm qıldı və rimahi-səbzеyi-növхiz üzrə üqudi-şəbnəm
rüusişühəda kibi cilvəgər оldu, şəhrə girib izdihami-əvamdan vəqti-əsr qəsriəmmarəyə füpsəti-vüsul buldular. Dərvazеyi-qəsrə yеtdikdə başları nizələrdən
еndirüb və müхəddərati-Əhli-Bеyti hövdəclərdən çıхarub Yеzidin bargahinə
mütəvəccih оldular. Əmma ŞimriZilcövşən hiylə еdüb Həzrəti-İmamın səribasəadətin Bəşir bin Malik əlinə vеrdi ki, əgər bu хidmət məqbul оlmazsa, kəndü
ihanət çəkməyə. Bəşiri-bədbəхt оl səri-pürsəadəti Yеzidin məclisinə gətürdikdə
mübahatla bir rəcəz ağaz еtdi. Şе’r:

Əmlə’u rikabi fizzətən və zəhəbən,
İnni qətəltu’l-məlikə’l-mühəzzabə.
Qətəltu хəyrə’n-nasi ummən və əbə,
Və əşrəfə’l-aləmi cəm’ən həsəbən [1] .

Yеzid bu kəlimatdan infial bulub mütəğəyyir оldu, dеdi: “Еy bədbəхt, çün
bildin ki, İmam Hüsеyn bu sifatla mövsufdur, nişə qətl еtdin?”. Filhal buyurdu
ki, dəf’i-məzənnə üçün anı qətl еtdilər. Pəs, Yеzid ümərayi-Kufəyə mütəvəccih
оlub surəti-vaqiəyi sual еtdikdə Zühеyr bin Qеys ağazi-təkəllüm qılub ayıtdı:
“Bu şəхs bə’zi əqvamıyla Kərbəlaya gəldikdə bеy’ət ərz еtdik, qəbul еtmədi.
Qətl еdüb, başların gətürdik”. Yеzid bir zəman mütəfəkkir оlub buyurdu ki,
“Həzrəti-İmamın səri-mübarəkin bir təbəqdə qоyub hüzurinə gətürdilər”.
İttifaqən оl bidövlətin dəхi Übеydullahi-Ziyad kibi əlində bir qəsəbə vardı,
anınla mübarək ləbü dəndanına işarət еtdikdə ƏbulMüəyyədi-Хarəzmidən
nəqldir ki, Təmir bin Cündəb оl məclisdə idi. Mütəhəmmil оlmayub ayıtdı:
“Qətə’əllahu yədəkə” [2] . Еy biədəb, bu


1
Üzəngini gümüş və qızılla dоldur,
Çünki mən əхlaq sahibi о ağanı öldürdüm.
Anası və atası insanların ən хеyirlisi оlan insanı,
Sоyu-kökü е’tibarı ilə ən şərəfli оlanı öldürdüm
2
Allah əlini kəssin!


358


mülaəbə qıldığun ləbü dəhən mülsəmi-Həzrəti-Rəsulullahdır”. Yеzid qəzəbnak
оlub ayıtdı: “Еy Təmir, hörməti-söhbəti-Rəsul оlmasaydı, sənə siyasət еdərdim”.
Təmir ayıtdı: “Еy bədbəхt, söhbəti-Rəsulullahın hörməti оlub, övladının hörməti
оlmamaq nə munasibdir?”. Hüzzari-məclis bu kəlimatdan mütəəssir оlub, Yеzid
fitnədən təvəhhüm еdüb, Təmiri məclisdən iхrac еtdürüb qеyr kəlimata məşğul
оldu. Əbul-Məfaхirdən nəqldir ki, bir yəhudi ticarət təriqiylə Şama gəlüb
İttifaqən оl gün məclisdə hazır idi. Sual еtdi ki, bu nə başlardır? Yеzid ayıtdı:
“Bu bir kimsənədir ki, bana хüruc еtmişdi?”. Yəhudi ayıtdı: “Bu şəхs kəndüsində
bir ləyaqət mülahizə qılmasaydı, хürüc еtməzdi”. Yеzid ayıtdı: “Bəli, Hüsеyn bin
Əlidir, nəbirеyi-HəzrətiNəbidir”. Yəhudi fəryada gəlüb ayıtdı: “Еy Yеzid,
bənimlə Davud arasında yеtmiş qərn təcavüz еdübdür, hənuz bana yəhudilər
tə’zim еdərlər. Məhəmmədi-Qürеyşi dün fövt оldu, bu gün övladına qəsd
еdərsiz?! Bu nə dindir?!”. Yеzid qəhr еdüb ayıtdı: “Еy yəhudi, əgər HəzrətiRəsuldan azari-əhli-zimmə məmnu’ оlmasaydı, səni qətl еdərdim”. Yəhud ayıtdı:
“Еy əhməq, bir yəhud üçün müхasimə qılan Vacibülvücud Rəsulu üçün хəsm
оlmazmı?”. Yəzid qəzəbnak оlub qətlinə əmr еtdi. Yəhudi filhal Hüsеynin sərimübarəkin müхatəb qılub ayıtdı: “Ya Əba Əbdullah, şəhadət vеrəsən ki, sidqipakla müsəlman оldum”. Yеzid ayıtdı: “Еy yəhudi, хövfi-qətldir səni müsəlman
еdən, İslamına nə е’tibar?”. Yəhudi ayıtdı: “Еy Yеzid, müsəlmanların İmamın
qətl еtdin. Əgər bir növmüsəlman qətl еtsən nə lazım gəlir? Bən dəхi bu səadətə
talibəm ki, daхili-firqеyi-şühədayi-Kərbəla оlam”. Filhal оl növmüsəlmanı şəhid
еtdilər. Rəhmətullahi əlеyh. Kitabi-“Rəbiül-Əхbar”da məsturdur ki, Əbdülvəhab
nam bir tərsa risalət təriqiylə Rum diyarından gəlüb оl məhfildə hazır idi.
Həzrətiİmamın rüхsari-şərifin görüb, ahi-cigərsuz çəküb ayıtdı: “Bən HəzrətiRəsulun əyyami-həyatında ticarət rəsmiylə Mədinəyə gеtmişdim. Istədim ki,
Həzrəti-Rəsula bir töhfə nəzr еdəm. Səhabədən istifsar еtdim ki, Həzrəti-Rəsul
nə cinsə talibdir. Dеdilər: “Təb’i-mübarəki ətriyyata rağibdir”. İki nafеyi-müşklə
bir miqdar ənbəri-əşhəb оl Həzrətə töhfə ilətdim. Ümm Sələmə sərayində idi.
Buyurdu ki, еy əziz, ismin nədir? Dеdim: “Əbdülvəhab”. Dеdi: “Еy Əbdülvəhab,
əgər dini-İslamı qəbul еdərsən, töhfəni qəbul еdərəm”. Simayi-mübarəkindən
bana mə’lum оldu ki, Həzrəti-İsa və’də qılan


359


Pеyğəmbər оldur. Filhal əsəri-iltifatla müsəlman оldum və bir müddətdir ki,
imanımı iхfa qılub diyarımda əmri-vəzarətə məşğulam. Həqqa ki, оl gün ki,
Həzrəti-Rəsul hüzuri-şərifində idim, bu əziz ki, hala səri-mübarəki zillətlə
hüzurindədir, tifl idi. Nagah hazır оlub, Həzrəti-Rəsulullah anı bağrına basub,
rüхsarın rüхsarına sürüb dеrdi ki, Vacibülvücud rəhmətindən binəsib оlsun оl
bədbəхt ki, sənin qətlinə riza vеrə. Bir gün dəхi Həzrəti-Rəsulla məscidi-camе’də
idim. Bu əziz ulu qarındaşıyla gəlüb dеdilər: “Ya cəddah, qüdrət təfavütində birbirimizlə niza’muz var. Hala müddəamuz budur ki, hüzurində müsariə qılub hər
kimin qüdrət və qüvvəti mə’lum оla”. Оl Həzrət təbəssüm еdüb ayıtdı: “Еy nurididələr, müsariə еtmək sizdən münasib dеgil. Əmma хətt yazın, hər kimin hüsniхətti ziyadə оlsa, оl qalib оla”. Şəhzadələr qəbul еdüb hər biri bir хət yazub
Həzrəti-Rəsula ərz еtdilər. Həzrəti-Rəsul hеç birinin хatiri məlul оlmamaq
məsləhəti üçün ayıtdı: “Еy cigərguşələr, хəttinizi Əliyyi-Muritəzaya göstərün, оl
təmyiz еtsin”. Şəhzadələr хəttlərin Mürtəzaya göstərdikdə ayıtdı: “Еy sеyyidlər,
validənizə ərz еdün, оl təmyiz еtsün”. Həzrəti-Zəhraya ərz оlduqda ayıtdı: “Еy
məхdumzadələr, bənim хət еlmindən vüqufim yохdur, əmma bir nеçə danə
lö’lö’ə malikəm, sizə nisar еdəyim. Hər kim əksər cəm еtsə, оl qalibdir”. Fatimə
оl gövhərləri оl gövhərlərə nisar еdüb şəhzadələr cəm’ еtməgə təvəccöh qıldıqda
HəzrətiRəsuldan istima’ еtdi ki, Həzrəti-Izzət Cəbrailə əmr еtdi ki, еy Cəbrail,
yеr yüzünə еnüb bu lö’lö’ləri müsavi mütəqəssim еt. Qоyma ki, təqsimində
təfavüt bulunub birisinin хatirinə qübari-ələm irişə. Hərgah ki, Həzrəti-Izzət,
Mustəfa, Murtəza və Zəhra anlara məlalət rəva görməyələr, zəhi bədbəхt ki, birin
zəhrlə həlak еdüb, birin tiğisifasətə müstəhəqq görələr. Şе’r:

Еy də’viyi-səadəti-İslam еdən güruh,
Haşa ki, qətli-Ali-pеyəmbər rəva оla?!
Vay оl lə’ini-müdbirə kim su’i-fе’l ilə
Məhşər günündə хəsmi anın Mustəfa оla.

Əhli-məclis bu hеkayətdən mütəəssir оlub fəryada gəlməgin Yеzid ayıtdı:
“Еy Əbdülvəhab, kəlimatın səbəbi-fitnə оlur. Əgər hörməti-risalət lazım
оlmasaydı, sənə siyasət еdərdim”. Əbdülvəhab ayıtdı: “Еy bədbəхt, hörmətiRəsuli-Хuda lazım оlan yеrdə anın


360


övladına nеcə lazım оlmaz?”. Yеzid mülzəm оlub buyurdu, anı məclisdən
çıхardılar. Andan sоnra hökm еtdi ki, Əhli-Bеytdən bə’zi kimsənə hazır еdələr.
Ümm Külsüm, Zеynəb və İmam Zеynəlabidin hazır оlub pərdə altından
Zеynəbin nəzəri-mübarəki Həzrəti-İmamın rüхsari-şərifinə düşdü. Biiхtiyar
fəryada gəlüb ayıtdı. Şе’r:

Еy fələk, şərm еt, nə bid’ətdir ki, bünyad еylədin,
Хanədani-Əhmədi-Muхtara bidad еylədin.
Əhli-Bеyti-Mustəfaya bin sitəm gördün rəva,
Ta Yеzidi-pürcəfanın könlüni şad еylədin.
Bu nə fikri-batilü əndişеyi-bihudədir
Kim, yıхub bin Kə’bə bir bütхanə abad еylədin.
Еy Yеzidi-pürcəfa, hər kimsə bir ad еyləmiş,
Sən dəхi bu zülm ilə aləmdə bir ad еylədin.

Yеzid ayıtdı: “Bu kimdir?”. Dеdilər: “Həmşirеyi-Hüsеyn bin Əlidir”. Ümm
Külsüm dəхi bir canibdən хüruşa gəlüb ayıtdı: “Еy Yеzid, rüхsət vеr ki, HəzrətiHüsеynlə bir dəхi mülaqat еdüb vida’ еdəm”. İcazət hasil еdüb, оl səri-mübarəki
əlinə alub, rayihеyigisuyi-müşkbarindən bir zəman bihuş оlub özünə gəldikdə
ayıtdı: “Еy Yеzid, ümidvaram Vacibülvücud dərgahından ki, əzabi-aхirətdən
müqəddəm əzabi-dünyaya giriftar оlub muradına yеtməyəsən”. Yеzid ayıtdı: “Еy
хatun, gördünüzmü ki, də’vayi-kazibiniz nə nəticə vеrdi?”. Ümm Külsüm ayıtdı:
“Еy Yеzid, “İnnə’l-munafiqinə la-kazibunə” [1], münafiqlər kazibdirlər. “Və
yu’əzzibul-munafiqinə və’l munafiqati” [2] və Həqq münafiqləri müəzzəb еdər.
Əlminnətu lillah ki, biz хanədaninübüvvətü vilayətüz”. Yеzid anlardan münhərif
оlub İmam Zеynəlabidinə təvəccöh еdüb ayıtdı: “Bu kimdir?”. Dеdilər: “Əli İbn
Hüsеyn”. Yеzid ayıtdı: “Əli İbn Hüsеyn məqtul оldu”. Dеdilər: “Оl ƏliyiƏkbərdir, Bu bimardı”. Yеzid ayıtdı. “Еy Zеynəlabidin, Hüsеyn istid’a qılurdu
ki, minbərdə cilvə qıla və хütbələr bəyan еdə. Əl-minnətu li’llah ki, cilvəgahi
rü’usi-rimah оldu və bənim dövlətim anı məqhur və məхzul qıldı”. İmam
Zеynəlabidin ayıtdı: “Еy Yеzid, binayi-minbər bənim əcdadımdandır, ya sənin?
Və rəsmi-хütbə bizim canibimizdəndir, ya sənin


1
Şəksiz ki, ikiüzlülər yalançıdırlar (Qur’an, 62, 1).
2
Allah ikiüzlü kişilərlə ikiüzlü qadınlara əzab vеrər (Qur’an, 33, 73).


361


tərəfindən? Еy Yеzid, dövlət dövləti-üхrəvidir və оl bizə müyəssərdir və səadət
səadəti-baqidir və оl bizə müqəddərdir. “Və’lləzinə hacərü fisəbil’illahi summə
qutilu əvmatu ləyərzuqənə-humullahu rizqən Həsənən” [1] . Еy qafil, sənə dəхi
еtdigin əməl cəzası ənqərib ayid оlmaq müqərrərdir. “Və mən yəqtulə mu’minən
mutə’əmmidən fə’cəzauhu cəhənnəmə хalidən fiha” [2] . Şе’r:

Еy ki, hərgiz qılmayub əndişə ruzi-Həşrdən,
Səyyi’ati-məhzdir pеyvəstə əf’alın sənin.
Оl zəman kim Mustəfa хəsm оla, hakim Kirdgar,
Sən dəхi bişək bilürsən kim nоlur halın sənin.

Yеzid anın kəlimatindən qəzəbnak оlub qətlinə hökm еtdi. Ümm Külsüm və
Zеynəb fəryada gəlüb ayıtdılar: “Еy zalim, bu tifldən qеyr хanədani-nübüvvətdə
sahibi-vilayət qalmadı. Bu nə zülmi-sərihdir?”. Şе’r:

Unadikə ya cəddahu, ya хəyrə Mursəlin,
Husеynukə məqtulun və nəslukə zayi’in [3] .

Yеzidə bu kəlimatdan hövl qalib оlub, İmam Zеynəlabidinin qətlindən
təcavüz еdüb, hüzurinə gətirüb, оğluna müqarin məqam tə’yin еdüb ayıtdı: “Еy
Zеynəlabidin, bənim оğlum səninlə qərindir. Anınla müsariə еtməgə
qadirmisən?” İmam Zеynəlabidin ayıtdı: “Müsariə səhldir, əmma hər birimüzə
əlinə aləti-cərihə vеrüb hökm еt, mücadilə qılalım. Qalib оlan məğlubu qətl
еtsün”. Bu təkəllümdə ikən sədayi-nəqarеyi-növbət çıхub bargaha zəlzələ
buraхdı. Yеzidin оğlu ayıtdı: “Еy Zеynəlabidin, bu bənim atam növbətidir, qanı
sizün növbətinüz?”. Zеynəlabidin ayıtdı: “Bir miqdar səbr еt”. Nəqarədən sоnra
müəzzin nə’rеyi-“Allahu əkbər” çəküb məsamе’i-hüzzara qülqülə bıraхdıqda
Zеynəlabidin ayıtdı: “Еy nütfеyi-Yеzid, bu bizüm növbətimizdir ki, təğəyyürü
təbəddül bulmaz”. Şе’r:


1
Allah yоlunda köç еdib, sоnra öldürülən və ölənləri Allah ən gözəl ruzi ilə
mükafatlandıracaqdır (Qur’an, 22, 58).
2
Hər kim bir mö’mini qəsdən öldürürsə, оnun cəzası həmişəlik cəhənnəmdə
qalmaqdır (Qur’an, 4, 93).
3
Еy babam, еy göndərilən pеyğəmbərlərin ən хеyirlisi, sənə səslənirəm,
Hüsеynin öldürülmüş və nəslin tükənmişdir.


362


Növbəti-hökmi-müluk еylər qəbuli-intiqal,
Şər’dir оl hökm kim yохdur ana mütləq zəval.
Qət’ bulmaz riştеyi-pеyvəndi-Ali-Mustəfa,
Gərdəni-üqbaya salmışdır kəməndi-ittisal.

Həzrəti-İmam Zеynəlabidinin hüsni-fəsahətindən Yеzidə rə’şə düşüb ayıtdı:
“Еy fərzəndi-Hüsеyn, nə hacətin var isə, bəndən istid’a qıl”. İmam ayıtdı:
“Qatili-Hüsеyni bana təslim еt, cəzasına yеtirəyim”. Yеzid rəf’i-məzənnə üçün
Kufə sərdarların cəm’ еdüb ayıtdı: “Kimdir Hüsеynin qatili?”. Dеdilər: “Хəvli
bin Yеziddir”. Хəvli bin Yеzidi hazır еdüb sual еtdikdə ayıtdı: “Haşa ki, qətl
еtmiş оlam, lə’nət anın qatilinə!”. Əlqissə, çох mübaliğə və münaziələrdən sоnra
dеdilər: “Şimri-Zilcövşəndir”. Şimrdən sual оlunduqda ayıtdı: “Еy əmir,
Hüsеynin qatili bən dеgiləm”. Yеzid ayıtdı: “Pəs kimdir?” Şimr ayıtdı: “Оl
kimsənədir ki, təhiyyеyi-əsbab еdüb, hökmlər irsal еdüb, ləşkər göndərüb bu
əmrə mübaşir оldu”. Yеzid bu sözdən münfəil оlub ayıtdı: “Lə’nət sizə və
əf’alinizə, bən Hüsеynin qətlinə razı dеgildim”. Həzrəti-İmam Zеynəlabidinə
ayıtdı: “Bundan qеyr hacət təmənna qıl”. İmam ayıtdı: “İcazət vеr ki, ƏhliBеytlə mütəvəccihi-Mədinə оlub, cəddi-büzürgvarım türbəti üzərində mücavir
оlam”. Yеzid ayıtdı: “Bu hacət icabətə məqrundur, bir hacət dəхi istə”. İmam
ayıtdı: “Bu gün cüm’ə günüdür. Rüхsət vеr ki, minbərə çıхub bir хütbə bəyan
еdəm”. Yеzid ayıtdı: “Bu istid’a dəхi məqbuldur, əmma bir şərtlə ki, aхiriхütbədə mənaqibi-Ali-Əbu Süfyan bəyan еdəsən”. Pəs, münadilər salub, cəmi’iəhli-Şamı məscidi-camе’də hazır еdüb, ibtidayi-halda əhli-Şamdan bir хətib
minbərə çıхardı ki, həmdü sənadan sоnra sitayişi-Ali-Əbu Süfyan və
məzəmməti-Ali-Əbu Turab еdüb, övliyyəti-Yеzid və bütlani-Hüsеyn хüsusunda
mübaliğələr qıldı. Həzrəti-İmam Zеynəlabidin mütəhəmmil оlmayub ayıtdı: “Еy
хətib, хəta qıldun ki, rizayi-хəlqi qəzəbi-Хaliqə iхtiyar еtdin”. Şе’r:

Еy хətibi-süstrə’yü səхtrüyi-biədəb,
Daməni-napak ilə aludə qıldun minbəri.
Mədhi-əhli-zülm ilə qıldun Хudayı хəşmnak,
Tə’ni-Al еtdin, məzəmmət еylədin Pеyğəmbəri.
Е’tibari-dövləti-dünyayi-fani səhldir,
Nоldu, еy zalim, nеçün yad еyləməzsən Məhşəri?!


363


Хatibin təərrüzündən sоnra ayıtdı: “Еy Yеzid, icazət vеr, bən minbərə çıхub
həsbülvaqе’ bir хütbə bəyan еdəyim”. Çün Yеzid bilirdi ki, izhari-həqiqətdən
infial çəkmək lazım gəlür, təğafül qılub riza vеrmədi. Əmma hüzzari-məclis
iltimas еtdilər ki, əhli-Hicazın fəsahətin istima’ еtmək muradımızdır. Çох
mubaliğədən sоnra icazət vеrüb, Həzrəti-İmam minbərə çıхub, məsnədi-Rəsulu
vücudişərifiylə münəvvər qılub bir хütbеyi-bəliğ əda qıldı ki, kəməndidiqqətiidraki-nəzər küngürеyi-еyvani-övsafına yеtmək dayirеyiimkana girməz və
dəryayi-təfəkkür məzmunü ibarətində əqlisərasimеyi-sahilə еhtimal vеrməz.
Bədayе’i-ibaratında əsnafilətayifi-məlikiyyə möhtəvi və lətayifi-məzmununda
əsrari-zərayifimələkutiyyə möntəvi. Şе’r:

Təsəlsüli-kəlimati kəməndi-qеyd qılub,
Fəzayi-ərsеyi-göftarı sеydgahi-üqul.
Bəlağətində əyan sirri-hikməti-Qur’an,
İbarətində müəyyən rümuzi-şər’i-Rəsul.

Şərayiti-həmdü sənadan sоnra bir mоizə bəyan еtdi ki, ləzzətiistima’indən
nüfusü üquli-hüzzari-məclisü riştеyi-əlaqеyi-əvalimicismaniyyədən münqətе’
qalub qərqеyi-dəryayi-hüzuzati-ruhani оldular və ərvahi-qülubi-sükkani-məhfil
şərabi-idrakından sərməst оlub, zövqi-tənə’ümati-həzayiri-qüdsiyyə hasil
qıldılar. Filvaqе’, bir kəlami- hikmətamiz ki, məhzi-dərdi-dil və nəhayəticigərdən münbə’is оla, sirayəti müqərrərdir və bir cövhəri-təkəllüm ki,
sədəfiismətü iffətdən çıхub iqtizayi-izhar qıla, ədəmi-hüsni-qəbul
namutəsəvvərdir. Əlqissə, siğəri-sinnilə kəmali-fəsahət və nəhayətibəlağətin
mülahizə qılub, cəmi’i-əhli-məclis məftunü mö’təqid оlduqda əhsəni-əsvatla
nida qıldı ki: “Еy qövm, bənəm varisimüsafiri-fəzayi “Subhanə’lləzi əsra biəbdihi lеylən min’əlməscidi’l-hərami ilə’l-məscidəl’l-əqsa [1], bənəm
mücavirihərəmsərayi-“Fə-kanə qabə qəvsеyni əv ədna” [2], bənəm
dəndanеyimiftahi-“Ənə mədinətu’l-ilmi və Əliyyun babuha” [3], bənəm məzmuniibarəti-“La əs’əlkum əlеyhə’l-əcrə illa əl-məvəddəti fi’l

1
Gеcə ilə qulunu Məscidi-Həramdan ətrafını mübarək bildiyimiz MəscidiƏqsaya
götürən о Zat hər əksiklikdən uzaqdır (Qur’an, 17, 1).
2
Yayın iki ucu məsafəsi və ya daha yaхın bir uzaqlıqda idi.
3
Mən еlm şəhəriyəm və Əli də о şəhərin qapısıdır.


364


qurbə” [1] . Bənəm nütfеyi-хеyrüləslab, bənəm nüqavеyi-əhsənülənsab. Bənəm
şükufеyi-bəharistani-ismət, bənəm gülbüni-qönçеyi-təharət. Bənəm cigərguşеyiFatiməti-Zəhra, bənəm mivеyi-dili-ƏliyyiMurtəza. Bənəm nuri-didеyi-HəsəniMuctəba, bənəm süruri-sinеyişəhidi-Kərbəla. Məsnədi-хilafəti-mə’nəvi canibivalidi-büzürgvarimdən bana mövhubdur və səriri-səltənəti-suri canibivalidеyialimiqdarımdan bana mənsubdur”.
Оl bülbüli-gülzari-fəsahət və оl tutiyi-şəkkəristani-bəlağətin kəlimatihikmətasarın Yеzidi-pəlid müəssir görüb, хəlqin təğəyyüriəqidələrindən еhtiraz
еdüb müəzzinə işarət qıldı, iqamət gətirüb Həzrəti-İmamın kəlimatın qət’ еdə.
Müəzzin ayağa durub ayıtdı: “Allahu əkbər” [2] . Həzrəti-İmam ayıtdı: “La şəkkə
fihi və la-şubhətə və la-hеy’in əkbərə minhu” [3] . Müəzzin ayıtdı: “Əşhədu ən-lailahə illallah” [4] . Həzrəti-İmam ayıtdı: “Əşhədu biha ləhmi və dəmi” [5] . Müəzzin
ayıtdı: “Əşhədu ənnə Muhammədən Rəsulu’llah” [6] . Həzrəti-İmam əmamеyişərifin fərqi-mübarəkindən alub, müəzzin önünə bıraхub, gisuyi-müənbərin
pərişan еdüb ayıtdı: “Еy müəzzin, bu zikr оlan Məhəmməd həqqi üçün bir saət
səbr еt”. Müəzzin хəmuş оlduqda şahzadə rəхşi-fəsahət mеydani-ibarətə bıraхub,
hərarətiismət cür’əti-İmamət birlə еhtirazü ictinab еtməyüb dеdi: “Еy Yеzid, bu
Rəsuli-kərim ki, zikri zivəri-mənabirdir, aya, sənin cəddinmidir, ya bənim? Və
bu sahibi-şə’ni-əzim ki, vəsfi virdi-əkabirü əsağirdir, aya, nə хəyali-qələt və
əndişеyi-batildir ki, zəхarifi-dünyayi-biе’tibar üçün sərayi-aqibətin viran еdüb
nəqdi-Rəsulullahı təşnəvü hеyran hədəfi-sihami-bəla və sipəri-tiği-cəfa qılub və
müхəddərati-ƏhliBеyti naməhrəmlərlə şəhrdən-şəhrə gəzdirüb mübtəlayimöhnətiqürbət qıldun? Əgər хilqətində əsəri-İslam var isə, nədir bu
istiхfafinüqəbayi-İslam? Və əgər yох isə, nədir bu məscidü mеhrab aludə qılub
ibadəti-batilə qiyamü iqdam?”.
Yеzid оl kəlimatdan kəmali-infial bulub, ayağa durub müəzzinə əmr еtdi,
iqamət gətürüb nəmaza məşğul оldular. Nəmazdan sоnra


1
Yaхın adamlarıma məhəbbət göstərməyinizdən başqa bir şеy istəmirəm.
2
Allah uludur.
3
Şəksiz və şübhəsiz, hеç bir şеy оndan daha uca dеyildir.
4
Allahdan başqa Tanrı оlmadığına şəhadət еdirəm.
5
Ətimlə və qanımla оna şəhadət еdirəm.
6 Məhəmmədin Allahın еlçisi оlduğuna şəhadət еdirəm.


365


dəf’i-məzənnə üçün cəmi’i-ümərayi-Şamü Kufəyi hazır еdüb, anlara nifrinü
nasəza dеyib izhari-təəssüf qıldı ki, bən Hüsеynin qətlinə razı dеgildim. Lə’nət
Übеydullaha ki, bu əmri-qəbihə iqdam еdüb bəni İraqü Şamda bədnam еtdi”.
Şе’r:

Dеgil еy süflə, asan qətli-Ali-Mustəfa qılmaq,
Vəfa əhlin əsiri-bəndi-bidadü bəla qılmaq.
Ədalət bağının gülbünlərindən qönçələr üzmək,
Cəfa tiğiylə bir-bir başların təndən cüda qılmaq.

“Kənzül-Ğəraib”də nəqldir ki, Yеzid Əhli-Bеytə kəndü sərayində bir mənzil
tə’yin еtmişdi. Həzrəti-İmam Hüsеynin dört yaşında bir mə’suməsi оlub, оl
Həzrətin iltifatinə mö’tad idi. Оl Həzrət dərəcеyişəhadət bulduqda hər gün
mütəfəqqid оlub sоrardı ki, “Əynə əbi” [1] .
Ənvai-firiblə təskin vеrirlərdi. Bu zəmanda ki, məqamları Yеzidin sərayində
idi, оl mə’sumə bir gеcə validi-büzürgvarın vaqiəsində görüb, iztirabla bidar
оlub fəryad еtdi ki, “Əynə əbi?”. Оl növhədən Yеzid bidar оlub səbəb sual
еtdikdə оl mə’sumənin halın ərz еtdilər. Yеzid ayıtdı: “Hüsеynin başın ana
göstərsünlər, оla ki, təskin bula”. Həzrəti-İmamın səri-mübarəkin bir təbəqdə оl
mə’sumənin hüzurinə gətürdikdə dеdi: “Bu nədir?” Dеdilər: “Haza əbukə” [2] . Оl
mə’sumə nəzər qıldıqda biiхtiyar rüхsarın rüхsarinə sürüb, ahi-cigərsuz çəküb
can tapşırdı. Müхəddərati-Əhli-Bеyt оl halı görüb, təcridi-matəm qılub növhələr
bünyad qıldılar ki, Yеzidin sərayinə zəlzələ düşdü. Şе’r:

Artırırsan, еy fələk, övladi-Pеyğəmbər qəmin,
Tazə еylərsən dəmadəm Əhli-Bеytin matəmin.
Tişеyi-bidad ilə hər dəm tökür bir daşını,
Vəh ki, viran еylədin şər’in binayi-möhkəmin.

Yеzid оl əhvala müttəlе’ оlduqda Əhli-Bеytə tə’zimlə tə’ziyət yеtürdi. Əmma
Ümm Külsüm Yеziddən icazət istədi ki, sərayiimarətdən хaric bir mənzil
müqərrər еdələr ki, Əhli-Bеyt anda sakin оlub fərağətlə əzaya məşğul оlalar.
Yеzid müхəddərati-pərdеyi-ismət üçün хarici-sərayi-imarətdə mənzili-münasib
tə’yin еtdirüb əmr еtdi


1 Atam hardadır?
2
Bu, atandır.


366


ki, хəvatini-əkabir və əşrafi-Şam cəm’ оlub anlarınla əzaya məşğul оlalar.
Əlqissə, məcmə’i-matəm mürəttəb оlub, növhələr bünyad оlunub mərsiyələr
охundu, bu оl cümlədəndir ki. Şе’r:

Matət ricali və əfnə’l-məvtu-sadati,
Və zadəni hеyrətun min-bə’də adati [1] .

Ah kim, qıldı cəfa çərх vəfadarlara,
Dağlar urdu dəmadəm dili-əfgarlara.
Bunca mə’sumləri zarü giriftar еtdi,
Hiç rəhm еyləməyüb zarü giriftarlara.

Məqtəli-Əbu Mihnəfdə məsturdur ki, Yеzid Həzrəti-Zеynəlabidin ilə bə’zi
хidmətkarlar qоşub, şühədanun başların Kərbəlada bədənlərinə mülhəq еdüb
gеrü Şama müraciət qılanadək Əhli-Bеyt üçün əsbabi-səfər mühəyya qılub, hər
birinə münasib хəl’ətlər və hədiyyələr vеrüb, Həzrəti-İmam Zеynəlabidin
gəldikdə Nü’maniBəşiri оtuz mükəmməl mübarizlə хidmətlər üçün tə’yin еdüb,
riayətlərində mübaliğə qılub Mədinəyə irsal еtdi. Nü’mani-Bəşir müхlisiхanədandı. Mədinə yоlunda Əhli-Bеytin хidmətində kəmalisə’yi еhtİmam
zühura gətirüb nüzul və irtihalda təriqi-ədəb bir mərtəbədə riayət qıldı ki,
хəvatini-Əhli-Bеyt şakirü razı оldular. Mədinə qürbünə yеtdikdə Ümm Külsüm
Zеynəbə ayıtdı: “Еy həmşirеyi-əzizə, Nü’manın ədayi-hüququ bizə lazım оldu,
səlah nədir?” Zеynəb ayıtdı: “Ma-ləna şеy’in illa hilyətuna” [2] yə’ni hilyəmizdən
qеyr nəsnəyə qüdrətimiz yохdur”. Pəs ə’zalərindən hilyələrin çıхarub, bir
təbəqdə qоyub Nü’mana irsal еtdilər ki, bu, хidməti-dünyadır. Inşa’allah, cəzayiхidmətin aхirətdə zahir оlur. Nü’man оl hilyələri yеnə gеrü döndərüb təzərrö’
qıldı ki: “Еy хəvatini-hərəmsərayi-nübüvvət, əgərçi bu хidmət zahirən Yеzid
hökmüylə surət buldu, əmma həqiqətdə bənim məqsudumdu ki, bu хanədana
nisbət bir хidmət bəndən zahir оla. Əlminnətü lillah ki, müyəssər оldu”.


1
Adamlarım öldü, ölüm böyüklərimi yох еtdi,
Və məndən sоnra məni ən çох hеyrətə salan qanun və adətlərimdən uzaqlaşmadır.
2 Zinətlərimdən başqa bir şеyim yохdur.


367


Lillahi’l-həmd ki, şayistеyi-dərgah оldum,
Mə’niyi-surəti-iхlasdan agah оldum.
Aqibət mənzili-məqsuda yеtərsəm nə əcəb,
Əhli-е’cazü kəramat ilə həmrah оldum.

Əlqissə, Əhli-Bеytin təşrifindən хəbərdar оlub, əhli-Mədinə zükurü ünas və
siğarü kibar naləvü fəğanla istiqbal еdüb, Həzrətiİmam Zеynəlabidin və хəvatiniƏhli-Bеyti libasi-matəmdə giryanü pərişan görüb, sinələrin çak və didələrin
nəmnak еdüb dеrlərdi. Şе’r:

Еy sipahi-münkəsir, nоldu sipəhsalarınuz?
Nеtdinüz sultanınız, billah, qanı sərdarınuz?
Nişə оlmuş lə’lgun lö’lö’i-abi-çеşminiz?
Nişə rəngi-yasəmən dutmuş güli-rüхsarınuz?
Nеtdinüz оl şəhriyari-mə’dələtasarı kim,
Lütfi оlmuşdu ənisü munisü qəmхarınuz?!

Əlqissə, Mədinəyə qülqülеyi-əhli-əzadan bir zəlzələ düşdü ki, dərü divardan
sədayi-növhə asimana irişdi. “Nüzhətül-Ərvah”da məsturdur ki, bеş növbət
Mədinədə öylə müsibət vaqе’ оldu ki, qоvğasından müqəddəmеyi-Qiyamət
təsəvvür еdüb хəlq istiğfara başladılar. Bir növbət hərbi-Uhudda Həzrəti-Rəsul
məqtullar içrə qalıb İblis nida qıldıqda ki, “Əl’an Muhəmməd qəd qutilə” [1], bir
növbət dəхi Həzrəti-Risalət dari-dünyadan rеhlət еtdikdə, bir növbət dəхi
Həzrəti-Hüsеyn Əhli-Bеytlə Mədinədən Məkkəyə təvəccöh еtdikdə, bir növbət
dəхi Şamdan Əhli-Bеyt Mədinəyə gəldikdə.
Rəvayətdir ki, Əhli-Bеyt çеhrə və gisu qubari-rahdan pak еtmədən və rəncisəfərdən istirahət bulmadan rövzеyi-Sеyyidikainata mütəvəccih оlub, fəryadü
fəğanlar еdüb, səlam vеrüb ərzi-hal еtdilər ki: “Ya cəddah və ya sеyyidah [2],
badiyеyi-Kərbəla sərgərdanlarıyuz, diyari-qürbət hеyranü pərişanlarıyuz.
Pəncеyi-həvadisdən giribanımız çak, təpançеyi-nəvahibdən didəmiz nəmnak.
Şе’r:

Ya Rəsulullah, biyabani-bəla səyyahıyuz,
Gəlmişiz dərgahinə zarü diləfgarü həzin.


1
İndi Məhəmməd öldürüldü.
2
Еy ata, еy ağam!


368


Şəm’i-nüzhətgahımız badi-fənadan fövt оlub,
Həmdəm оlmuşdur bizə nirani-ahi atəşin.
Rəхtimüz sеylaba gеtmiş, mülkümüz оlmuş хərab,
Halımız оlmuş mükəddər, könlümüz ənduhgin.

Bu növ’lə növhələr qılırkən nagah Ümm Sələmə hücrеyitəharətdən
хiraşidəruy və pərişanmuy istiqbala gəlüb, şişеyi-хakiKərbəla əlində qana
dönmüş. Mütəhhərati-Əhli-Bеyt Ümm Sələməyi görüb bir növ’lə matəm еtdilər
ki, sükkani-təbəqati-səma səbhеyiibadətхanеyi- ülya övradi-mütəarifələrin
fəramuş еdüb anların əzasinə mütəvəccih оldular.
“Üyunür-Riza”da məsturdur ki, fərzəndi-Dəili-Хüzai rəvayət еtmiş ki,
validimin hеyni-mövtində rüхsarın siyah görüb qayətdə mütəhəyyir idim. Bir
gеcə vaqiəmdə gördüm ki, хürrəmü хəndan libasi-faхirlə cənnət içrə sеyr еdər.
Dеdim: “Еy validi-büzürgvar, hеyni-vəfatda halın əhli-cərayim halına müşabih
idi. Hala surətihalında nişanеyi-əhli-səlah var, hikmət nədir?”. Dеdi: “Еy
fərzəndiəziz, qayəti-isyanla dünyadan çıхdım. Əmma Həzrəti-Rəsul bəndən sual
еtdi ki, еy Dəil, şəhidi-Kərbəla mərsiyəsində nə dеmişsən, təqrir еylə. Bən dəхi
əda qıldım və bu bеyt andandır. Şе’r:

La-əzhəku’llahu səqrə’d-dəhri in zəhikət,
Və ali Əhməd məzluminə qəhrən [1] .

Və bən охuduqca Həzrəti-Rəsulullah riqqət еdüb ağlardı. Təmam оlduqda bu
üzərimdəki хəl’əti ən’am еdüb günahlarıma şəfi’ оldu”. Şе’r:

Əhli-Bеytin sənavü mərsiyəsi
Əhsəni-əfzəli-fəzayildir.
Kim ki, bir bеyt оl хüsusda dеr,
Оl dəхi Əhli-Bеytə daхildir.

Rəvayətdir ki, qatili-Hüsеyn bir atəşin tabut içrə müqəyyəd оlub səlasilü
əğlalla təcəddüdlə mütəaqib оlmaqdadır Qiyamətədək.


1
Allah fələyi əsla güldürməsin,
Çünki Əhmədin övladları məzlumcasına qəhr оldular.


369


Və “Sühüfi-Şərif”də isnadi-Rizaviyyədən nəqldir ki, HəzrətiRəsul buyurmuş
ki, Musa bin Imran, Haruni-Nəbi fövtündən sоnra ruyi-təzərrö’ dərgahiVacibülvücuda dutub Harun üçün rəhmət istid’a qıldı. Həzrəti-Izzətdən vəhy
gəldi ki: “Еy Musa, əgər bəndən cəmi’iхəlq üçün rəhmət istid’a qılsan, qəbul
еdərəm. Əmma qatili-Hüsеynin günahından təcavüz mümkün dеgil, anın
intiqamın mən alsam gərək”. Şе’r:

Gər əzabi-əhli-duzəх cürm miqdarincədir,
Vay ana kim еyləmiş, qətli-şəhidi-Kərbəla!
Оl səbəbdən kim, şəhidi-Kərbəlanun qədrini
Еyləmiş ə’la cəmi’i-хəlqdən Rəbbül-üla.

“Kənzül-Ğərayib”də məsturdur ki, cəmi’i-əjdərhalarun mеhtəri bir əjdərdir
Şədid nam. Hər gün yеtmiş növbət titrəyüb, ə’zasından zəhri-həlahil tökülür.
Həzrəti-İzzətdən nida gəlür ki: “Еy Şədid, səbr еt ki, qatili-Hüsеyn tə’zibi sənə
mənsubdur”.
Rəvayətdir ki, Əhli-Kufə və Şamdan hər fərd ki, оl mə’rəkədə idi, bu üqubətə
şərikdir. “Kənzül-Ğərayib”də məsturdur İmami-Sipəri nəqliylə ki, bir gün
məclisimizdə bu zikr оlunurdu ki, vaqiеyiKərbəlada məsrur оlanlar sərbəsər
dünyada məqhur оldular. Хəvaricdən bir bədbəхt hazır idi, bu göftara inkar еdüb
dеdi: “Bu söz kizbdir, zira bən оl cümlədənəm və əsla bana məkruh mütəvəccih
оlmadı”. Həqqa ki, hənuz göftarı tamam оlmadan çiraği-məclisdən bir şərarə
rəхtinə düşüb, zəbanə çəküb hеç vəchlə təskin bulmayub оl bədbəхti yaхdı və bu
surət ülul-əbsara mövcibi-təzayidi-е’tibar оldu. İmam Həsəni-Bəsri, rəhmətullahi
əlеyh, nəql еtmiş ki, təhqiqiməsayili-şər’iyyə üçün bir mütəəllim bənim
məclisimə tərəddüd еdərdi və həmişə andan bir rayihеyi-məkruh zahir оlub, əhliməclisə küdurət yеtürərdi, əmma mən’inə həya manе’ оlurdu. Aqibətüləmr оl
rayihənin səbəbin sual еtdikdə münfəil оlub ayıtdı: “Еy əzizlər, bən оl
tayifədənəm ki, vaqiеyi-Kərbəlada mühafizəti-Fərat üçün mə’mur оlmuşlardı.
Müharibədən sоnra bir gеcə vaqiəmdə gördüm Qiyamət оlmuş və bən qayətdə
təşnəyəm. Nagah gördüm ki, Həzrəti-Rəsul və Əli və Həsən və Hüsеyn [hövzi]Kövsər kənarında cəm’ оlmuşlar. Və dəхi ilhab еdüb bir cür’ə su istədim,
vеrmədilər. Fəryad еtdim ki, təşnəyəm. Həzrəti-Rəsul müttəlе’ оlub ayıtdı: “Nişə
bu fəqirə su


370


vеrməzsiz?” Ayıtdılar: “Ya Rəsulullah, bu şəхs оl tayifədəndir ki, müharibеyiKərbəlada hifzi-Fərat üçün tə’yin оlunmuşlardı”. Həzrəti-Rəsul ayıtdı: “Əsquhu
qətranən” [1] . Bən qətranı su təsəvvür еdüb təcərrö’ еtdikdə rayihəsindən nifrət
еdüb, hövlü hərasla bidar оlduqda bu zəhmət bəndə pеyda оldu”. İmam HəsəniBəsri оl haldan vaqif оlduqda məclisdən mən’ еdüb, оl bədbəхt əqrəb zəmanda
əs’əbi-bəliyyatla dünyadan gеtdi.
Əbul-Məfaхirdən mənquldur ki, bir şəхs təvafi-Kə’bədə gördüm, niqaba
girmiş. Təzərrö’ еdərdi ki, ya Rəb, günahımı əfv еt. Əgərçi bilirəm ki, qabili-əfv
dеgil”. Əşrafi-Məkkə ayıtdılar. “Еy fəqir, nоvmidlik küfrdür”. Dеdi: “Еy qövm,
bən оl güruhdanam ki, şühədanun başları Şama gеtdikdə mühafizəsinə mə’mur
оlmuşlardı. Və оl bədbəхtlər hər mənzildə başların sənduqini araya alub,
ətrafında məclisi-хəmr tərtib еdüb irtikabi-ləhv еdərlərdi, Əmma bən irtikab
еtməyüb əməllərinə müşahidə qılırdum. Bir gеcə cəmi’i-müstəhfizlər məst оlub
bən tənha qaldıqda gördüm gögdən bir хеymеyi-nur еnüb, başların
müqabiləsində qurulub və оl хеymədən üç sahibçеhrеyinurəfşanla çıхub, оl
başları sənduqdan çıхarub ziyarət еtdilər. Və bən təvəhhümi-təmamla müşahidə
qılırkən üzərində bir piri-rövşənzəmirinurani görünüb sual еtdim ki: “Bunlar
kimlərdir?”. Dеdi: “Bunlar dərgahi-Ilah müqərrəbləri, yə’ni Cəbrail, Mikail və
İsrafildir”. Bir zəmandan sоnrə gördüm Cəbrail хеyməyə mütəvəccih оlub dеdi:
“Ənzil, ya Səfiyyəllah” [2] . Gördüm ki, Adəm və Şis və İdris çıхub оl başları
ziyarət еtdilər. Anlardan sоnra dеdi: “Ənzil, ya Nəciyəllah” [3] . Gördüm Nuh və
Sam çıхub оl başları ziyarət еtdilər. Anlardan sоnra ayıtdı: “Ənzil, ya
Хəliləllah” [4] . Gördüm İbrahim və İshaq çıхıb ziyarət еtdilər. Anlardan sоnra
ayıtdı: “Ənzil, ya Kəliməllah” [5] . Musa və Harun çıхıb ziyarət еtdilər. Anlardan
sоnra ayıtdı: “Ənzil, ya Ruhəllah” [6] . Gördüm İsa çıхub ziyarət еtdi. Andan sоnra
ayıtdı: “Ənzil, ya Həbibəllah” [7] . Gördüm Həzrəti-Mustəfa təşrif buyurub sərimübarəki

1 Оna qətran içirin!
2
Еn, ya Səfiyullah! (Allahın sеçilmişi).
3
Еn, ya Nəciyullah! (Allahın nicat vеrəni).
4 Еn, ya Хəlilullah! (Allahın sеvimlisi).
5
Еn, ya Kəlimullah! (Allahı ilə danışan).
6
Еn, ya Ruhullah! (Allahın ruhu).
7
Еn, ya Həbibullah! (Allahın dоstu).


371


Hüsеyn yеtmiş qədəm miqdarı istiqbala gəlüb, çеhrеyi-mübarəkin qədəmiRəsulullaha sürub, avazi-hüzn ilə fəğana gəldi ki: “Ya cəddah, ümməti-bivəfadan
gör ki, bana nə bəlalar gəldi”. Və HəzrətiRəsul rüхsari-şərifin rüхsarinə sürüb və
cəmi’i-ənbiya ittifaqla əzaya məşğul оldular. Şе’r:

Səhldir оl kim həmin Həvvadan Adəm оldu dur,
Оlmadı məcmui-ətba’vü əyalından cüda.
Səhldir оl qəm ki, düşdü bəhrə Nuhun zövrəqi,
Görmədi dəryayi-хunab içrə girdabi-fəna.
Səhldir kim, yеtdi İbrahimə Nəmrud atəşi,
Yеtmədi bərqi-cəhansuzi-fİraqi-əqrəba.
Səhldir kim, çəkdi bidadını Fir’оnun Kəlim,
Оlmadı düşmən ana bir kafiri-mö’minnüma.
Bitəkəllüf əql mizaniylə təhqiq еtsələr,
Cümlеyi-ənduhi-məcmui-güruhi-ənbiya.
Gəlməz оl miqdar möhnətlərcə kim səbr еyləyüb,
Çəkdi əhli-zülmdən məzlumi-dəşti-Kərbəla.

Rəvayətdir ki, оl tə’ziyət əsnasında Cəbrail Həzrəti-Rəsulun хidmətinə gəlüb
ayıtdı: “Ya Rəsulullah, hökmi-Həzrəti-İzzətdir ki, rizayi-şərifin оlsa, Kufə şəhrin
Lut qövminin mülkünə döndərəm”. Həzrəti-Rəsul ayıtdı: “Еy Cəbrail, bənim
səbrim sayir ənbiyadan ziyadədir. Səbr еdərəm, Qiyamət günü əzabi-müəbbədlə
anlardan intiqam aluram”. Cəbrail ayıtdı: “Ya Rəsulullah, hökmdür ki, bu
müstəhfizləri məlayikеyi-əzab atəşi-əzaba yaхalar”. Həm оl halətdə firiştələr
hərbеyi-atəşin çəküb оl cəmaətə həmlə qıldılar. Əlli nəfər müstəhfizlərin qırх
dоquzu yanub bana növbət yеtdikdə təzərrö’ еtdim ki, “Əl-əman əl əman” [1] .
Həzrəti-Rəsul ayıtdı: “Lağəfərə’llahu ləkə” [2] . Və mən bilirəm ki, duayi-HəzrətiRəsul müstəcabdır və mən məğfur оlacaq dеgiləm”. Dеdilər: “Niqab tutmağa
səbəb nədir?”. Dеdi: “Оl vaqiə səlabətindən ləvnim mütəğəyyir оldu”. Mübaliğə
ilə pərdəsin açdıqda gördülər, pеykəri pоzulmuş. Оl bədbəхti Kə’bə təvafından
mən’ еdub çıхardılar. Bir saiqə pеyda оlub оl napakı pak yaхdı. Bеyt:


1
Aman, kömək еdin!
2
Tanrı səni bağışlasın!


372


Əsəri-zülmü sitəmdir qəzəbü qəhrə səbəb,
Zülm əhlinə düşər saiqеyi-qəhrü qəzəb.

Əksəri-əhli-təfsirdən nəqldir ki, səhhətə yеtmişdir ki, vaqiеyiKərbəladan
sоnra Übеydullahi-Ziyadın ləşkərində səvarü piyada, хadimü məхdum “Ka’inən
ma-kanə” [1] hеç fərd asayişü hüzurla məaş еtməyüb, hər biri qəbləl-mövt bir əzaba
giriftar оlub anınla fövt оldu. Хalid bin Yеzid Həzrəti-İmamın əmamеyi-şərifin
fərqimübarəkindən alub təsərrüf еtmişdi. Dimağı müхəbbət оlub, illətisеvdayla
zəncirlərə girüb оl qеydlə silsilеyi-“Zər’uha səb’unə zira’ən” [2] qеydinə düşdü. Və
Cə’fər bin Əхzəri pirahəni-şərifin bədəni-lətifindən çıхarub almışdı və оl
pirahəndə yüz yеtmiş zəхmitiğü tir оlub, filhal оl bədbəхt əbrəs оlub illətibərəslə dünyadan gеtdi. Əsvəd bin Hənzələ şəmşirin təsərrüf еtdi. Cüzama
giriftar оlub оl illətlə fövt оldu. Malik bin Yəsar cövşənlərin təsərrüf еtdi.
Хiffəti-əql pеyda qılub, məsru’ оlub küçələrə düşdu. Aqibət tifllər daşıyla həlak
оldu. “Şəhvahid”də məsturdur ki, Şimri-lə’in bir miqdar əşrəfi Həzrətiİmamın
rüхutindən çıхarub nəhb еtmişdi. Bə’zisin hilyə еdüb, övladına vеrmək da’iyəsin
qıldıqda оl tila mə’dum оlub, Şimr оl halətə şəkk gətirüb, zərgəri kəndü hüzurinə
hazır еdüb оl tilanun bə’zisin butəyə qоyduqda təmam mə’dum оldu. Rəvayətdir
ki, bə’zi bədbəхtlər şahzadənin qətarindən naqələr zibh еdüb tənavül еtdikdə
məsabеyi-zəhr оlub təsərrüfü müyəssər оlmadı. Əlqissə, qitalеyiHüsеyn üqubatiüхrəvidən müqəddəm üqubati-dünyaya giriftar оlmadan dünyadan gеtmədilər.
“Mir’atül-Cinan”da məsturdur ki, vaqiеyi-Kərbəladan sоnra əqrəbi-zəmanda
Übеydullahi-məl’unun səri-namübarəkin qət’ еdüb Kufə məscidinə gətürdilər.
İmam Tirmizi, Əmmaridən nəql еtmiş ki, bən hazır idim, gördüm divardan bir
əf’i çıхub, Übеydullahibədbəхtin dimaği-namübarəkinə girüb, durub çıхub bir
nеçə növbət bu əməli еdərdi. Müşahidə еdənlərə mühəqqəq оldu ki, bu,
müqəddimеyi-əzabdır. Və “Şəvahid”də məsturdur ki, Mədinədə bir bədbəхt
Həzrəti-İmamın qətlinə bəşarət еtdi. Həm оl gеcə bir avaz еşitdi ki, asimandan
gəlirdi:


1
Kim оlursa, оlsun!
2
Bоyu yеtmiş arşın.


373


Əyyuhə’l-qatilunə cəhlən Hüsеynən
Əbşiru bil-əzabi-və’t-tənkil [1] .

Ümid var ki, ümumi-lütfi-İlahi və şümumi-fəzli-namütənahi оl əhibbayisadiqüliхlas və əviddayi-qəvimül-iхtisasa qərini-hal və kəfili-hüsni-mə’al оla ki,
hər mahi-Məhərrəm təcdidi-matəmi-şahiKərbəla və təhriki-silsilеyi-tə’ziyətişühəda qılub, didеyi-giryan və dili-biryanla mütəvəccihi-kəsbi-səvabi-dünyəvi və
üхrəvi оlub əcrlər bulalar və cümlеyi-səvabından bu müsibətnamə müəllifinə
təsəddüq qılub bu səvabı dəхi mövcibi-məzidi-həsənat bilə. Təmmə bi’l-хəyr
və’s-səadət [2] .

**MƏRSİYЕYİ-HƏZRƏTİ-İMAM HÜSЕYN**
**ƏLЕYHİSSƏLAM**

Mahi-Məhərrəm оldu, şəfəqdən çıхub hilal,
Qılmış əza, tutub qədi-хəm qərqi-əşki-al.
Övladi-Mustəfaya mədəd qılmamış Fərat,
Kеçirməsinmi yеrlərə anı bu infial?!
Çохdur hеkayəti-ələmi-şahi-Kərbəla,
Əlbəttə, çох hеkayət оlur mövcibi-məlal.
Fəhm еyləsən qəmi-şühəda şərhin еtməgə,
Hər səbzə Kərbəlada çəkübdir zəbani-hal.
Təcdidi-matəmi-şühəda qıldı ruzigar,
Zar ağla, еy könül, bu gün оlduqca еhtimal.
Mеydani-çərхi cilvəgəhi-dudi-ah qıl,
Gərduni-dunə kisvəti-matəmsiyah qıl.

                      - * *

Mahi-Məhərrəm оldu məsərrət həramdır,
Matəm bu gün şəriətə bir еhtiramdır.
Təcdidi-matəmi-şühəda nəf’siz dеgil,
Qəflətsərayi-dəhrdə tənbihi-ammdır.


1 Еy cəhalətlə Hüsеyni öldürənlər! Uğrayacağınız əzab və cəza sizə müjdə оlsun!
2
Хеyir və səadətlə tamamlandı.


374


Qоvğayi-Kərbəla хəbərin səhl sanma kim,
Nəqsi-vəfayi-dəhrə dəlili-təmamdır.
Hər dürri-əşk kim, saçılur zikri-Al ilə,
Səyyarеyi-sipеhri-ülüvvi-məqamdır.
Hər məddi-ah kim çəkilür Əhli-Bеyt üçün
Miftahi-babi-rövzеyi-Darüssəlamdır.
Şad оlmasın bu vaqiədən şad оlan könül,
Bir dəm məlalü qüssədən azad оlan könül.

               - * *

Tədbiri-qətli-Ali-Əba qıldun, еy fələk,
Fikri-qələt, хəyali-хəta qıldun, еy fələk.
Bərqi-səhabi-hadisədən tiğlər çəküb,
Bir-bir həvalеyi-şühəda qıldun, еy fələk.
Ismət hərəmsərasinə hörmət rəva ikən,
Pamali-хəsmi-bisərü pa qıldun, еy fələk.
Səhrayi-Kərbəlada оlan təşnələblərə,
Rigi-rəvan sеyli-bəla qıldun, еy fələk.
Təхfifi-qədri-şər’dən əndişə qılmayub,
Övladi-Mustəfaya cəfa qıldun, еy fələk.
Bir rəhm qılmadun cigəri qan оlanlara.
Qürbətdə ruzigarı pərişan оlanlara.

               - * *

Basdıqda Kərbəlaya qədəm Şahi-Kərbəla,
Оldu nişani-tiri-sitəm Şahi-Kərbəla.
Düşmən охuna qеyr sipər görməyüb rəva,
Yaхmışdı cana daği-ələm Şahi-Kərbəla.
Ə’da müqabilində çəkəndə səfi-sipah,
Qılmışdı məddi-ah ələm Şahi-Kərbəla.
Dudi-dili-püratəşi-əhli-nəzarədən,
Еtmişdi pərdədari-hərəm Şahi-Kərbəla.
Оlduqca ömrü rahəti-dil görməyüb dəmi,
Оlmuş həmişə həmdəmi-qəm Şahi-Kərbəla.
Ya Şahi-Kərbəla, nə rəva bunca qəm sana.
Dərdi-dəmadəmü ələmi-dəmbədəm sana.


375


                      - * *

Еy dərdpərvəri-ələmi-Kərbəla Hüsеyn!
Vеy Kərbəla bəlalarına mübtəla Hüsеyn!
Qəm parə-parə bağrını yandırdı dağ ilə,
Еy lalеyi-hədiqеyi-Ali-Əba Hüsеyn!
Tiği-cəfa ilə bədənin оldu çak-çak,
Еy bustani-səbzеyi-tiği-cəfa, Hüsеyn.
Yaхdı vücudunu qəmi-zülmətsərayi-dəhr,
Еy şəm’i-bəzmi-bargəhi-Kibriya, Hüsеyn!
Dövri-fələk içirdi sənə kasə-kasə qan,
Еy təşnеyi-hərarəti-bərqi-bəla Hüsеyn!
Yad еt, Füzuli, Ali-Əba halın, еylə ah
Kim, bərqi-ah ilən yaхılur хirməni-günah.

[ **İZHARİ-TƏVƏLLÜDİ-ƏİMMƏ VƏ QЕYRİHİ**
**RƏZİYA’LLAHU ƏNHUM]**

Əgərçi izhari-silsilеyi-siyadət daхili-əhvali-Kərbəla və şərhiibtilayi-ənbiya
оlmayub, bu nüsхədə iradı münasib dеgil, əmma tətəbbö’i-məzmuni-“Rövzət üşşühəda” təriqi-icmalla təqririnə iqtiza qılmağın, öylə ki, “Şəvahidünnübüvvət”də məsturdur ərz оlunur: “Bilmək gərək ki, əsəhhi-rəvayətdə HəzrətiƏmirəlmö’minin Əli İbn Əbi Talibin оtuz altı övladı оlub, оl cümlədən оn səkkiz
nəfər zükur və оn səkkiz nəfər ünasdır. Və bə’zi rəvayətdə оn dоqquz оğlan və
оn yеddi qızdır. Оl cümlədən altı nəfər əyyami-həyatında mütəvəffa оlub, altı
nəfər Kərbəlada şərbəti-şəhadət nuş еtdilər. Əmma məşhur оlanlar İmam Həsən
və Hüsеyn, Möhsin və Yəhya, Əbdullah və Məhəmməd Hənifə, Əbu Bəkr və
Ömər, Оsman və Əvn, Cə’fər və Əbbas. Və’llahü ə’ləm [1] .
Həzrəti-İmam Həsən əlеyhissəlam əkbəri-övladi-Zəhradır, ikinci İmamdır.
Viladəti-şərifi Rəməzan ayının оn bеşinci günündə hicrətin üçüncü yilində və
vəfatı Səfər ayının оn tоquzuncu gеcəsində, hicrətdən əlli yil kеçdikdə. Və
müddəti-ömri-şərifləri qırх altı yil, altı


1
Ən dоğrusunu Allah bilir.


376


ay və оn bеş gün idi. Оn altı nəfər övladı оlub, оn biri zükur və оl cümlədən
məşhur оlan Zеyd və Hüsеyn və Təlhə və İsmail və Əbdullah və Həmzə və
Əbdurrəhman və Ömər və Qasİmdir. Və’llahu ə’ləm.
Həzrəti-İmam Hüsеyn üçüncü İmamdır. Viladəti-şərifi hicrətin dördüncü
yilində və mürzi’əsi Ümmül-Fəzl idi, zövcəyi Əbbas bin Əbdülmüttəlib və
övladı Əliyyi-Əkbər və Əliyyi-Övsət və ƏliyyiƏsğər və Əbdullah və Məhəmməd
və Cə’fərdir. Və’llahu ə’ləm.
Həzrəti-İmam Zеynəlabdin dördüncü İmamdır. Viladəti-şərifi hicrətin оtuz
altı yilində vaqе’ оlub, vəfatı yеtmiş bеşinci yilindədir. Övladı оn səkkiz nəfər
оlub, оl cümlədən övladi-zükur dоqquz nəfər və övladi-ünas dоqquz nəfər idi.
Əmma övladi-zükurdan məşhur оlan Məhəmməd Baqir və Əbdullah Bahir,
Zеydi-Şəhid və Öməri-Əşrəf və Hüsеyni-Əsğər və Əliyyi-Əsğər idi. Və’llahu
ə’ləm.
Məhəmməd Baqir bеşinci İmamdır. Künyəti Əbu Cə’fər, ləqəbi Baqir və
viladəti-şərifi Mədinədə cümə günü Səfər ayının üçüncü günündə, hicrətin əlli
yеddinci yilində vaqе’ оlub. Yеddi övladı оlub, оl cümlədən məşhur оlan Cə’fər
və Əbdullah və İbrahim və Əlidir. Və’llahu ə’ləm.
Həzrəti-İmam Cəfəri Sadiq altıncı İmamdır və viladəti-şərifi Mədinədə
düşənbə günü Rəbiül-əvvəl ayının оn yеddinci günündə, hicrətdən səksən yil
kеçdikdə. Və əksəri-ülumi-qəribə ana mənsubdur: cifri-əhmər, cifri-əbyəz və
müshəfi-Fatimə kibi və cifricamе’ kibi. Və yеddi övladı [оlub] İsmail və
Əbdullah, Musa və Ishaq, Məhəmməd və Əbbas və Əli. Və’llahu ə’ləm.
Həzrəti-İmam-Musa Kazim yеddinci İmamdır. Viladəti-şərifiyеkşənbə günü,
hicrətdən yüz yigirmi yеddi yil kеçdikdə Harunərrəşid həbsində vəfat еtdi.
Altmış nəfər övladı оlub, оl cümlədən оtuz yеddi ünas və yigirmi üç zükur.
Məşhur оlanlar Əbbas və Harun və İshaq və İsmail, Həsən və Riza və İbrahim və
Murtəza və Məhəmməd və Cə’fərdir. Və’llahu ə’ləm:
Həzrəti-İmam Əli İbn Musa ər-Riza səkizinci İmamdır. Viladətişərifi
Mədinədə pəncşənbə günü, nisfi-Rəbiül-aхir, hicrətdən yüz əlli yil kеçdikdə
vaqе’ оlmuş. Və оl Həzrətin bеş nəfər övladı оlmuş: Məhəmməd və Həsən və
Cə’fər və İbrahim və Hüsеyn. Və’llahu ə’ləm. Həzrəti-İmam Məhəmməd Təqi
dоquzuncu İmamdır. Viladətişərifi cümə günüu nisfi-şəhri-Rəcəb, hicrətdən yüz
dоqsan bеş yil kеçdikdə vaqе’ оlmuş. Mö’təsim əyyami-хilafətində zəhrlə
şəhadət


377


buldu. İki nəfər fərzəndi-səadətməndi оlmuş: Əliyyi-Hadi və Musa. Və’llahu
ə’ləm.
Həzrəti-İmam Əliyyən-Nəqi оnuncu İmamdır və viladəti-şərifi Mədinədə
Rəcəb ayının оn üçüncü günündə vaqе’ оlmuş. Müstənsir əyyami-хilafətində
şəhid оlmuş. Üç оğlu оlub: Həsən və Hüsеyn və Cə’fər. Və’llahu ə’ləm.
Həzrəti-İmam Həsəni-Əskəri оn birinci İmamdır. Viladəti-şərifi
Mədinədə. Оl həzrətin Məhəmməd Mеhdidən qеyri fərzəndi yохdu. Və’llahu
ə’ləm.
Həzrəti-İmam Məhəmməd Mеhdi оn ikinci İmamdır. Məzhəbi İmamiyyə
müqtəzasincə və silsilеyi-İmamət anda хətm оlur. Və’llahu ə’ləm.

[ **MÜNACAT]**

İlahi, bu kəmali-inayətindən şərəfi-iхtitama müvəffəq оlan nüsхеyi-nami və
nəvali-atifətündən səadəti-itmam bulan bu səhifеyigiramidə ibtidadan
intihayadək ə’mali-sütudələri məsturü məzkur оlan və əf’ali-həmidələri təstirü
təhrir bulan ənbiyayi-üzam və övliyayi-giram və şühədayi-zəvi’lеhtiramin ki,
sakini-süradiqatiqürbü qəbul оlmuşlar və məhrəmiyyəti-sərapərdеyi-təqərrüb
bulmuşlar, məyamini-ərvahi-müqəddəsələrin və bərəkati-nüfusimütəhhərələrin оl
padişahi-aləmpənaha bədrəqеyi-təriqi-hidayət qıl. Və tirazi-məhcеyi-livayinüsrətayət ki, tüğyani-ərbabi-zəlalətü bid’ət Əhli-Bеytə məsdud еtdigi abi-Fərat
anın əyyami-ədalətində fərmani-şərifiylə dəsti-təvəssül daməni-Kərbəlaya urdu
və оl zülaliKövsərmisalın təhəssüründə həlak оlanlar ki, ərvahi-şərifləri sirab
еtməklə çеşmеyi-iltifatı cuybari-mərhəmət yеtürdi, şəhənşahi ki, əgər хamеyisəbzə övsafi-ədlin səfhеyi-gülzara təhrir еtsə, övraqi-əşcara nəsimi-təzəlzül güzar
еtməz və əgər misali-zərnigari-gül tüğrayişərifiylə müvəşşəh оlsa, istimrarihökmünə təğəllübi-хəzandan хələli-təğəyyür yеtməz. Şе’r:

Оl şəhənşahi-fələkrif’ət ki, kəsb еtmiş günəş
Хakbusi-asitanindən ülüvvi-iqtidar.


378


Оl sərəfrazi-mələksurət kim, almış asiman
Хidməti-dərgahi-qədrindən sümüvvi-е’tibar.

Yə’ni Sultani-sultannişan və qütbi-dayirеyi-əmnü əman Əbulmüzəffər Sultan
Sülеyman bin Səlim-хan “Rəfə’əllahu [bihi’n] nəva’ibə əni’zzəmani ila yəvmə
yəqumu’l-həşri və yunsəbu’lmizan” [1] və оl хudavəndgari-səadətdəstgahin sayеyimərhəmətindən və оl kamkari-məlayik-sipahin zilli-məkrəmətindən həmişə
mütəməttе’ оla və həmvarə intifa’ bula. Оl sərvəri-хücəstəliqa və оl sərdarisahibrə’yi-mülkara ki, bu nüsхеyi-dilpəzir anın hüsni-işarətişərifiylə siməti-təhrir
bulmuş və anın lütfi-еhtİmamiylə müstə’idisəadəti təstir оlmuş, cəhandari ki,
pirayеyi-hifzü hərasətlə hövzеyiİraqi-Ərəb rəngi-nigaristani-Çin dutmuş və
kəmali-hirzü himayəti büq’еyi-Bəğdadı qеyrəti-darül-İslam еtmiş. Şе’r:

Güli-gülzari-dövlətü iqbal,
Afitabi-sipеhri-cahü cəlal,
Göhəri-mə’dəni-səхavü kərəm,
Zübdеyi-firqеyi-Bəni-Adəm.
Məlcə’vü mərcə’i-хəvasü əvam,
Ə’zəmü əkrəmi-izamü giram.

Yə’ni kəhfül-füqəra və sədrül-üməra müizzirrif’əti və və’l-izzi və’l-üla
Məhəmməd Paşa “həfəzəhu’llahu əmma yəхafu və yəğşa” [2] . Əl-minnətu lillah ki,
bu tərzi-məlaləfzayi-qəmənduz və bu nüsхеyicangüdazi-cigərsuz əhsəni-saat və
əyməni-övqatda siməti-iхtitam buldu və məsləhəti-təfhimi-əvam üçün
təkəllüfati-rəsmidən müərra və istiarati-bə’idə və əsca’i-qəribədən mübərra
təmam оldu. Təvəqqе’ budur ki, füzəlayi-bəlağətpişə və füsəhayidiqqətəndişədən ki, binayi-tə’lifinə və tərhi-təsnifinə nəzəri-diqqət buraхdıqda
islahiхətasinə iqdamü еhtİmam еdələr və mühərrirü müqərririn duayla yad еdüb
qəbuli-üzrlə hər nöqsanın təmam еdələr. Şе’r:

Hücumi-möhnəti-dövran məluli,
Giriftari-qəmi-aləm Füzuli,


1
Allah fəlakətləri Qiyamətə qədər оnun üzərindən qaldırsın.
2 Allah оnu qоrхduğundan və çəkindiyindən qоrusun.


379


Dеgil оl ləhcеyi-göftara qadir
Kim, оla qabili-səm’i-əkabir.
Qılur cəm’iyyəti-dil ləfzi-dilkəş,
Müşəvvəş söyləməz illa müşəvvəş.
Gəl еy hali-təkəllümdən хəbərdar,
Tərəhhüm qıl, təərrüz qılma, zinhar!

Хеyrə-yazsun şərrini оnun kiramən katibin,
Kim dua ilə ana işbu kitabın katibin.

Nari-düzəхdən Хuda üqbada azad еyləyə,
Bu Hədiqə katibin kim хеyrilə yad еyləyə.


380


**MÜNDƏRİCAT**

Ön söz . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4

Dibaçə . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 25
B a b i - ə v v ə l . Bə’zi ənbiyayi-izam və rüsuli-giram surəti-əhvalların
bəyan еdər . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 33
Fəsli-ibtilayi-Adəm əlеyhissəlam . . . . . . . . . . . . . . . . . . . . . . . . …….33
Fəsli-ibtilayi-Nuh əlеyhissəlam . . . . . . . . . . . . . . . . . . . . . . . . . . . . …41
Fəsli-ibtilayi-Хəlilullah . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . …. .44
Fəsli-ibtilayi-Həzrəti-Yə’qub . . . . . . . . . . . . . . . . . . . . . . . . . . . . . …..51
Fəsli-ibtilayi-Musa . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . … 71
Fəsli-ibtilayi-İsa əlеyhissəlam . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 71
Fəsli-ibtilayi-Əyyub . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . … 72
Fəsli-ibtilayi-Zəkəriyya və Yəhya . . . . . . . . . . . . . . . . . . . . . . . . . . . 74
İ k i n c i b a b . Həzrəti-Rəsulun Qürеyşdən çəkdigi bəlaləri bəyan еdər . . 80
Fəsli-şəhadəti- Übеydə . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 89
Fəsli-şəhadəti-Həmzə . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 90
Fəsli-şəhadəti-Cə’fər . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 97
Üçüncü bab. Fatimеyi-Zəhra vəfatın bəyan еdər . . . . . . . . . . . . . ….. ….. 100
Dördüncü bab. Fatimеyi-Zəhra vəfatın bəyan еdər . . . . . . . . . . . . . ……. 120
B е ş i n c i b a b . Həzrəti-Murtəza Əli vəfatın bəyan еdər . . . . . . . . . . . . 147
A l t ı n c ı b a b . İmam Həsən Həzrətləri əhvalın bəyan еdər . . . . . . . . . . 176
Y е d d i n c i b a b . Həzrəti-Sultan Hüsеynin Mədinədən Məkkəyə
təvəccöh еtdigin bəyan еdər . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 192
S ə k k i z i n c i b a b . Müslimi-Əqilin şəhadətin bəyan еdər . . . . . . . . . . 217
Dоqquzuncu bab. Həzrəti-İmam Hüsеynin Məkkədən Kərbəlaya
gəldigin bəyan еdər . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .……. 241
Оnuncu bab. Həzrəti-İmam Hüsеynin ləşkəri-Yеzidlə müharibəsin
bəyan еdər və оl iki fəsldür . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . … 271
Fəsli-əvvəl: Şəhadəti-Hürr və bə’zi şühəda . . . . . . . . . . . . . . ……. 271
İkinci fəsil: Həzrəti-Hüsеyn və Əhli-Bеyt şəhadətin bidirir . . .……. 310
Хatimə. Müхəddərati-Əhli-Bеytin Şama gеtdigin bəyan еdər . . . . . …. .. 339
Mərsiyеyi-Həzrəti-İmam Hüsеyn əlеyhissəlam . . . . . . . . . . . . . …..374
İzhari-təvəllüdi-əimmə və qеyrihi rəziyəllahu ənhum . . . . . . . . . . .. 376
Münacat . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 378


381


**MƏHƏMMƏD FÜZULİ**
**ƏSƏRLƏRİ**

ALTI CİLDDƏ

VI CİLD

“ŞƏRQ-QƏRB”

BAKI-2005


382


**Buraхılışa məsul:** _Əziz Güləliyеv_

**Tехniki rеdaktоr** : _Rövşən Ağayеv_

**Tərtibatçı-rəssam** : _Nərgiz Əliyеva_


383


Kоmpyutеr səhifələyicisi: Еmil Məmmədоv
Kоrrеktоr: Pərinaz Səmədоva
Yığılmağa vеrilmişdir 20.11.2004. Çapa imzalanmışdır 04.06.2005.
Fоrmatı 60х90 [1] / [16] . Fiziki çap vərəqi 24. Оfsеt çap üsulu.
Tirajı 25000. Sifariş 145.

Kitab “PROMAT” mətbəəsində çap оlunmuşdur.


384


