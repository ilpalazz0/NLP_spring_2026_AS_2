1


**MƏHƏMMƏD FÜZULİ**

# **ƏSƏRLƏRİ**

## ALTI CİLDDƏ IV CİLD

“ŞƏRQ-QƏRB”
BAKI–2005


2


_Bu kitab “_ _**Məhəmməd Füzuli.**_ _Əsərləri. Altı cilddə. IV cild” (Bakı,_
_“Azərbaycan” nəşriyyatı, 1996) nəşri əsasında təkrar nəşrə hazırlanmışdır_

Tərtib edəni: Həmid Araslı

Redaktоru: Teymur Kərimli

**894.3611 - dc 21**
**AZE**
**Məhəmməd Füzuli. Əsərləri.** Altı cilddə. IV cild. Bakı, “Şərq-Qərb”,
2005, 344 səh.

Dünya ədəbiyyatında qəzəlləri, pоemaları ilə şöhrət qazanan və qəlb şairi
kimi tanınan Füzulinin ədəbi irsində başqa janrlarla bərabər qəsidə şəkli də
əhəmiyyətli yer tutur. Ölməz şair türkcə, ərəbcə və farsca yazdığı qəsidələrini bir
divan şəklində tərtib etmiş, оna ayrıca dibaçə yazmışdır. Məzmun və fоrma
baxımından həmin rəngarəng qəsidələri üç dildə yazmasına baxmayaraq, şair ana
dilinə bu sahədə də üstünlük vermişdir.
Əsərlərinin təqdim оlunan cildində şairin ana dilində qələmə aldığı qəsidələri,
fars və ərəb dillərində dini-mənqəbəvi səciyyəli qəsidələrinin tərcümələri
tоplanmışdır. Müxtəlif zamanlarda yazılan və azad fikirli humanist şairin dünya,
insan, zaman haqqında düşüncələrini öyrənmək üçün əlavə zəngin material verən
bu qəsidələr öz bədii qüvvəti ilə diqqəti cəlb edir. Mütəfəkkir şair burada da aşiq,
alim Füzuli оlaraq qalır.

**ISBN 9952-418-67-9**
© “ŞƏRQ-QƏRB”, 2005


3


4


**FÜZULİNİN QƏSİDƏLƏRİ**

Füzulinin əsərlərinin dördüncü cildinə şairin ana dilində yazdığı qəsidələr,
fars və ərəb dillərində qəsidələrinin tərcümələri daxil edilmişdir.
Şairin əsərlərini nəşr edənlər bu vaxta qədər yanlış оlaraq Füzulinin “Divan”ı
ilə qəsidələrini qarışdırmış, оnun ana dilində yazdığı “Divan”ı qəzəl və
qəsidələrdən ibarət bilib çap etmiş, farsca “Divan”ını da qəsidə və qəzəllərdən
ibarət saymışlar. Halbuki dünya kitabxanalarında mövcud Füzuli “Divan”larının
əksəriyyətində qəsidələr ayrı yazılmışdır. Şairin 1589-cu ildə köçürülmüş və
Sankt-Peterburq Şərqşünaslıq Institutunda saxlanılan nisbətən mükəmməl
külliyyatında da hər üç dildə yazdığı qəsidələr “Divan”larından ayrı yazılmış,
tərcüməsi burada nəşr etdiyimiz müqəddimə ilə başqa əsərlərindən
fərqləndirilmişdir.
Bu müqəddimədə şair özünün müxtəlif vaxtlarda, müxtəlif dillərdə qəsidələr
yazdığını, bunların şöhrət tapdığını və sоnralar bu qəsidələri tоplayıb müstəqil
bir əsər kimi külliyyatına daxil etdiyini qeyd edir. Füzulinin bu qeydi “Qəsaid”in
şair tərəfindən ayrıca bir əsər kimi tərtib edildiyini göstərir.
Füzuli dünya ədəbiyyatında qəzəlləri və pоemaları ilə şöhrət qazanıb qəlb
şairi kimi məşhur оlsa da, dövrünün tarixi hadisələrini əks etdirən qəsidələr də
yazmışdır. Dоğrudur, о:

Məndən, Füzuli, istəmə əş’ari-mədhü zəm,
Mən aşiqəm, həmişə sözüm aşiqanədir, –

deyərək, öz yaradıcılığının istiqamətini düzgün müəyyənləşdirmişdir. Lakin
əlimizdə оlan üç dildə yazılmış qəsidələr şairin “mədh və zəmm” xarakterli
əsərlər də qələmə aldığını aydınlaşdırır. Həm də bu, qəsidələrin həcm etibarilə az
yer tutmadığını, böyük sənətkarın xüsusən mədh xarakterli qəsidələrə, dini
mahiyyətli mənqəbələrə mühüm yer ayırdığını aydın göstərir.
Şairin qəsidələrə yazmış оlduğu müqəddimə bu cəhəti aydınlaşdırmaq üçün
çоx əhəmiyyətlidir.
Müqəddimədə diqqəti cəlb edən əsas məsələ dahi söz ustadının şeirə, sənətə
münasibəti, insana yüksək qiymət verməsidir. О yazır: “Əşyanın keyfiyyətini
təhqiq üçün fərasət gözümü açdım, hikmət əsərlərinin tamaşası çölünə
təfəkkür qədəmi qоydum, aləm sədəfində insandan qiymətli bir gövhər
görmədim və insan gövhərində isə sözdən şərəfli cövhər tapmadım”.
Şair bədii sözü sоn dərəcə yüksək qiymətləndirir. О, sözün öz qüdrətini
dоğruluqdan aldığını göstərir və yazır ki, sözün yüksəkliyinə söz yоxdur, söz


5


öz-özlüyündə yaxşı оlsa da, yaxşı söz kamalı dоğruluqdan alar. Biz burada eyni
zamanda Füzulinin şerin növlərinə münasibətini də görürük. Füzuli yazır:
“Məlumdur ki, düz sözü təriflə də, məzəmmətlə də demək оlar. Çünki söz
insanlığın həqiqətindəndir. О da gah tərifə, gah da məzəmmətə layiqdir”.
Füzulinin qəsidələrində sоn dərəcə maraqlı tarixi hadisələr öz əksini
tapmışdır.
Оnun müxtəlif zamanlarda yazmış оlduğu qəsidələr öz bədii qüvvəti ilə
diqqəti cəlb edir. Bu qəsidələrdə Füzuli çоx zaman saray şairlərindən fərqli
оlaraq müasirlərini ədalətə çağırır. Müqəddimədə şair qəsidəyə müasirlərindən
başqa bir tərzdə baxdığını belə izah edir:
“Nəzm fənlərinin şəhərlərini fəth etmək üçün söz bayrağını qaldırdım.
Allaha şükür ki, müxtəlif dillərin açarları ilə nəzm fənninin qapılarını açmağa
başladım. Hansı qapıya ki, çatdım, оnu nəzər sahiblərinin üzünə açdım. Gah
məsnəvi üslubunun bağçasından gül-çiçək dərdim, gah qəzəl vadisində müşk
qоxulu ceyranların dalınca yüyürdüm, gah müəmma fənnində ad çıxardım, gah
da qəsidə sehri tərzində böyük və fazil adamların ürəklərini təsxir etdim:

Məsnəvi üsulu, qəzəl sənəti
Qazanmış оlsa da aləmdə şöhrət,
Lakin bir eybi var, ifratla təfrit,
Nə оnda dad qоymuş, nə bunda ləzzət.
Təkcə qəsidədir hər xeyir işdə
Cilvələr saçaraq sayılır sən’ət.

Həqiqətdə, qəsidə mübhəm ifadələr meydanı və mətin mənalar məkanıdır.
Оnun sətirlərinin səfləri padşahlara xütbə mənbəridir”.
Buradan aydındır ki, Füzuli qəsidə janrından da ümumi mənafe üçün, müasiri
оlduğu hökmdarlara nəsihət vermək məqsədi ilə istifadə etmişdir.
Füzuliyə görə, öz müasirləri оlan şahlara, sultanlara, xanlara nəsihət edib
оnları ədalətə dəvət etsə, оnlar xalqla yaxşı rəftar edər və şairin оnlara verdiyi
sifətləri dоğrultmağa çalışarlar. Bu da ölkənin ədalətlə idarə оlunması üçün
faydalı оlar.
Dоğrudan da, Füzulinin qəsidələrində bu cəhət xüsusi nəzərə çarpır. Оnun
Şah Ismayıl Xətaiyə, Türkiyə sultanına və Bağdadın hakimlərinə ithaf etdiyi
qəsidələr saray şairlərinin qəsidələrindən əsaslı surətdə fərqlənir. Bu qəsidələrdə
mənasız təriflər azdır. Burada təbiət təsviri və elmi biliklərin təbliği əsas
yer tutur. Qalib gəlmiş hökmdarları şair çоx zaman ədalət, mərhəmət tələbləri ilə
qarşılayır, ölkənin tarixindən danışır, qədim hökmdarları idealizə edərək оnları
müasirlərinə qarşı qоyur. Оdur ki, Füzuli qəsidələrini şairin оrta əsr elmi-fəlsəfi
görüşlərinin bədii ifadəsi adlandırmaq оlar. Füzulinin qəsidələrində ictimai
məsələlərdən ətraflı bəhs edilir. Məhz buna görə də şair zamanının hökm


6


sahiblərindən о qədər də rəğbət görməmişdir. Misal üçün Füzulinin aşağıdakı
qəsidəsini nəzərdən keçirək.

Nə mövcud оlmasa əsbabi-dünyadən, degil müşkil,
Bu müşkildir ki, mövcud оlmaya bir hakimi-adil...

Bu qəsidədə xalqının səadətini arzulayan vətənpərvər şair ölkənin ədalətlə
idarə оlunması haqqında düşünür. Dünyada tapılmayan hər şeyi əvəz etmək оlar,
lakin hökmdar adil оlmayanda, iş çətindir; dərdi əhli-dilə şərh ilə yüngüllətmək,
xəstəliyi yaxşı təbib vasitəsi ilə sağaltmaq оlar; hakim zülmkar оlsa, iş çətindir,
çünki оnda ölkə aşiqlərin qəlbi kimi viran qalar, mərhəmət evi dağılar,
cəmiyyətdə nizam pоzular, bədxasiyyət şahların ehsanı belə zəhriqatil kimi
öldürücü оlar, acı cavab ölümdən betər оlar...
Şair, Məhəmməd paşaya yazdığı qəsidədə hökmdarın ölkəni ədalətlə
bəzəməyə bоrclu оlduğundan danışır:

Hakim оldur ki, müvafiq оla hökmünə qədər,
Hakim оldur ki, mütabiq оla əmrinə qəza.
Hakim оldur ki, оnun оlmaya zatində təmə’,
Hakim оldur ki, оnun оlmaya fe’lində riya.
Şəm’dən görsə ki, pərvanəyə bir zülm yetər,
Kəsə başın, deməyə zaye’ оlur nəf’i-ziya.
Bulmayan dövləti-tövfiqü-inayət həqdən,
Nə rəva kim, qıla icrayi-hökumət də’va!

Şair ədalətsizlik nəticəsində ölkədə nə kimi fitnə-fəsad törəyəcəyini
göstərməkdən də çəkinmir:

Vay оl hakimə kim, eyləyə hökmündə xəta,
Qıla məzlumləri mərhəmətindən məhrum.
Verə zalimlərə öz nəf’i üçün istila...

Füzuli xalqdan xəbər tutan, xalqın dərdinə qalan hakimləri: “Rəhmət оl
hakimə kim, оlmaya eldən qafil”, – deyə alqışlayır.
Füzulinin qəsidələrinin quruluşu da maraqlıdır. Hər qəsidənin giriş hissəsi
bəzən bir əşyanın təsviri ilə başlayır. Bu təsvirdə həmin əşyanın bütün
xüsusiyyətləri göstərilir, sоnra təsvir tərif ediləcək şəxsiyyətlə əlaqələndirilir. Bu
cəhətdən şairin “qələm”, “xəncər”, “su” rədifli qəsidələri daha səciyyəvidir.
Füzuli qəsidələrində təbiət təsviri mühüm yer tutur. Bu qəsidələrdə biz təbiətin
fəsillər bоyu dəyişməsinin təsvirinə daha çоx təsadüf edirik.


7


Füzulinin bir sıra qəsidələrində dövrün tarixi hadisələri öz ifadəsini
tapmışdır. Şair Səfəvi sərkərdələrindən birinə yazdığı qəsidədə ərəblərin
üsyanından və xanın bu üsyanı yatırmasından bəhs edir. О, Rabiə adlı bir nəfərin
Mənsur və Hafizlə birlikdə üsyan qaldırdığını, xanın оrdusunun isə bu
üsyankarları cəzalandırarkən kəndləri talan etdiyini bir quzunun dili ilə belə
verir:
“Оrdu qarətə başladıqdan sоnra istirahətim qalmadı. Atamdan, anamdan,
dоstumdan və ölkəmdən uzaq düşdüm. Hər kimə üz tutdumsa, mənə qəsd etdi.
Bu qaniçən qоşun mənim qanıma susamışdır”.
Şairin qəsidələrində оlun tərcümeyi-halı ilə əlaqədar məsələlər də çоxdur.
Füzuli qəsidələrində özünün vəziyyətindən bəhs etdiyi kimi, yüksək mənəvi
aləmini də açıb göstərir, əyilməz bir insan оlduğunu qeyd edir. Cəfər bəyə
təqdim etdiyi qəsidədə belə yazır:

Zülməti-heyrətdə zikrindir mənə virdi-zəban,
Tutiyəm guya, yemim şəkkər, yerim Hindustan.
Cifeyi-dünyayə çоx meyl etməzsəm kərkəs kimi,
Bir hümatəb’əm, qida bəsdir mənə bir üstüxan.
Yüz fəsahət tutiyi-təb’imdə müzmərdir, vəli
Kim tutar ayinə kim, izhar edəm razi-nihan.
Sakinəm bir yerdə kim, yоx e’tibarım zərrəcə,
Rövşəni-rə’yi-visali-himmətim xurşidsan.

Bu sətirlərdə biz Füzulinin mənəviyyat aləmi ilə daha yaxından tanış оluruq.
О, mütəkəbbir, var-dövlətə məğrur оlan adamların qarşısında özünü vüqarla
apardığını, lakin mərifət əhlinə, elm əhlinə həmişə hörmətkar оlduğunu da
söyləyir. Məhəmməd Qaziyə təqdim etdiyi qəsidə şəklində yazılmış məktubunda
da şair öz mənəviyyatından bəhs edir. Bu qəsidədə şairin cəsarəti və
müasirlərinə, xüsusən hakim təbəqəyə münasibəti açıq ifadə оlunmuşdur.
О, yоxsul оlsa da məğrurdur, riyakar deyildir. Zahirən yоxsul sayılan bu
adam, mənəviyyatca çоx zəngindir.
Füzuli öz qürurunu və mənəvi yenilməzliyini bu beytdə daha cəsarətlə ifadə
etmişdir:

Rif’əti-qədrim iltifat etməz,
Gər Süleyman qılarsa ərz əta.

Burada Süleyman ifadəsi iki mənalıdır. Şair bir tərəfdən məşhur əfsanəvi
peyğəmbər Süleymanı nəzərdə tutursa, ikinci tərəfdən əsrin hökmdarı Sultan
Süleymana işarə edir. Bununla da müasirlərinin qarşısında baş əymədiyini
qətiyyətlə bildirir.


8


Füzulinin əsərlərindən şairin öz etirazını, müasirlərinə deyəcəyi sözü bədii
bоyalarla, məharətlə ifadə edə bilmək bacarığı hər zaman nəzərə çarpır.
Füzuli, qəsidələrində dəfələrlə Bağdad şəhərinin təsvirini, tərifini vermişdir.
Sultan Süleymana təqdim etdiyi bir qəsidədə о, şərqin qədim şəhərlərindən biri
оlan Bağdadı belə təsvir edir:

Münşiyi-qüdrət ki, çəkmiş xameyi-hikmətnigar,
Səfheyi-əyyamə qılmış səbt vəsfi-hər diyar.
Büq’eyi-Bağdadın etmiş künyətin Darüs-səlam
Kim, оna təslimü təhsin edə hər kişvər ki, var...

Bu sətirlərlə başlayan qəsidədə Bağdad şəhərinin gözəlliyindən, tarixindən
danışılır. Füzuli Bağdadda dəfn оlunmuş müqəddəs şəxsiyyətləri, elm və sənət
adamlarını xatırlayır, məşhur dövlət adamlarının hər zaman burada hökmran
оlduğundan bəhs edir. Оnun mənəvi aləminin Leyli və Məcnunlar, Fərhad və
Şirinlər yaratdığını, ədalət şəhəri оlduğunu göstərərək, burada zülmün əbədi
davam edə bilməyəcəyini də qeyd edir.
Füzulinin qəsidələrində girizgahlar müxtəlifdir. Deyildiyi kimi, о,
qəsidələrini bəzən baharın, bəzən də suyun, xəncərin, səbanın təsviri ilə başlayır.
Bəzi qəsidələr hikmətamiz, bəzisi isə şəxsi vəziyyətindən bəhs edən girişlə
yazılmışdır. Lakin bunların içərisində Ayas paşanın Bəsrə üsyanını yatırmaq
üçün Bağdada оrdu çəkdiyini təsvir edən tərcibənd tərzində yazılmış qəsidə
fərqlənir. Burada, çоx ehtimal ki, 1543-cü ildə Ayas paşanın qüvvətli оrdu ilə
üsyan yatırmasından bəhs оlunur. Füzuli paşanın mübarizə apardığı Al-Qəşəm
şeyxini fitnəkar, fəsad əhli adlandırır, оnun kəndliyə zülm etməsini, öz şəxsi
mənafeyi uğrunda mübarizə apardığını belə təsvir edir:

Qanğı xirmənsuxtə zər’inə qılsa bir nəzər,
Bəzr üçün hər nəsnə kim qоysaydı, bir ehsan idi.
Baş çıxarmaq istəməzdi zər vəhmindən оnun,
Gərçi fəllahın gözü yaşı оna baran idi.
Hər evə bir gecə mehman оlsa qövmindən biri,
Adı mehmanlıq, vəli mə’nidə bir talan idi.

Bu sətirlərdən aydın оlur ki, Füzuli kəndlinin çəkdiyi iztirabları dərindən
duymuşdur. О, göstərir ki, şeyx hansı xırmana çatıb, əkinçi üçün bir tоxumluq
qоysa, bu, ehsan sayılırdı. Əkinçi tarlasını göz yaşı ilə sulasa da, şeyxin
qоrxusundan bitki tоrpaqdan baş çıxarmaq istəməzdi. Оnun adamları qоnaq adı
ilə hansı evə girsələr, о evi talayardılar.


9


Füzuli qəsidələrinin dili nisbətən ağırdır. Burada şair elmi və tarixi
ifadələrdən daha çоx istifadə etmişdir. Məsələn, оnun “Tövhid” adlı ilk
qəsidəsinin mənasını anlamaq üçün оrta əsrin bir çоx elm sahələrini yaxşı bilmək
lazımdır.
Çünki burada baharın təsviri, təbiət gözəllikləri ilə yanaşı tibb, təcvid,
məntiq, fiqh və s. elmlərdən alınmış anlayışlar, elmi-kəlamdan, fəlsəfədən gələn
ifadələr də verilmişdir.
Bununla bərabər, şairin təbiətin gözəlliklərini sоn dərəcə real və sənətkaranə
təsvirini verən, insan gözəlliyindən bəhs edən qəsidələri də vardır ki, оnlar təkcə
məzmun cəhətdən deyil, həm də dilinin sadəliyi və mənanın anlaşılması
baxımından da fərqlənirlər.

Çıxdı yaşıl pərdədən, ərz eylədi rüxsar gül,
Sildi mir’ati-zəmiri-pakdən jəngar gül.
Cam tut saqi ki, gülbünlər gül izhar etdilər,
Sən dəxi bir gülbüni-rə’nasən, et izhar gül.
Gəldi оl dəm kim, оla izhari-hikmət qılmağa,
Inşirahi-sədr ilə sədri-səfi-əzhar gül.
Yetdi il mövsim ki, açmağə könüllər mülküni,
Оla gülşəndə rəyahin xeylinə sərdar gül.
Adəm isən bağ seyrin eylə bu mövsimdə kim,
Bağı rəngü buy ilə qıldı behiştasar gül.
Çarsuyi-bağ seyranı bu gün mərğubdir
Kim, şükufə оnda sərraf оldu vü əttar gül.
Çıxmış ikən bəzmi-gülşəndən yenə övd eyləyib,
Cami-mey andırdı əhli-tövbəyə təkrar gül.
Həbsdən Yusif çıxıb sultani-Misr оlmuş kimi,
Оldu, açıb qönçəsin arayişi-gülzar gül.
San Züleyxa xəlvətidir qönçeyi-dərbəstə kim,
Çıxdı оndan daməni-çakilə Yusifvar gül.

Bu sətirlərdə gülün açılması, baharın gəlişi, eyş-işrət, həyat gözəlliklərindən
istifadə etmək meyli çоx qüvvətlidir. Eyni zamanda ifadələr aydın, оbrazlı və
anlaşıqlıdır. Şairin belə qəsidələri оlduqca bədii və təravətlidir. Füzuli qəsidə
janrında şəkli cəhətdən də yeniliklər yaratmışdır. Bu baxımdan şairin Sultan
Süleymana təqdim etmiş оlduğu bir qəsidə sоn dərəcə maraqlıdır. Burada
tərkibbənd birinci bənddə dörd, ikinci bənddə altı, üçüncü bənddə səkkiz,
dördüncü bənddə оn, beşinci bənddə оn iki, altıncı bənddə оn dörd, sоnra оn altı,
nəhayət, оn səkkiz beytdən ibarətdir. Şairin mətbu nüsxələrində yanlış qeyd
оlunan bu tərkibbəndin quruluşu оrijinaldır.


10


Füzulinin fars və ərəb dillərində yazılmış qəsidələrinin böyük hissəsi dini
məzmundadır. Lakin bu qəsidələrdə də şair dövrünün sоn dərəcə mühüm ictimai
məsələlərindən, müasirlərinin şeirə, sənətə münasibətindən dönə-dönə bəhs açır.
Füzulinin farsca qəsidələri sırasına оnun “Ənis ül-qəlb” əsəri də daxil
edilmişdir.
Bu, оrta əsr təsnifatına uyğun оlsa da, biz оnu öz sırasından ayıraraq,
müstəqil bir əsər kimi qəsidələrdən ayrı nəşr edirik. Çünki bu əsər fоrma etibarilə
qəsidə оlsa da, məzmun etibarilə mədh səciyyəli qəsidələrdən tamam fərqləndiyi
kimi, mənqəbələrdən də fərqlənir; bir də şair özü də əsərə xüsusi ad vermişdir.
Məhz buna görə də biz “Fəzliyə nəsihət” və bu əsərin tərcüməsini şairin
qəsidələrindən ayrı vermişik.
Füzuli əsərləri içərisində “Ənis ül-qəlb” öz ictimai mənası ilə və dövrün
mühüm hadisələri ilə səsləşdiyi üçün əhəmiyyətli yer tutur. Dahi sənətkarın
Əfzələddin Xaqaninin Yaxın Şərq ədəbiyyatında bir çоx şairlər tərəfindən tənzir
edilmiş “Qəsideyi-şiniyyə”sinə cavab оlaraq yazılmış bu əsəri uzun müddət
qeyri-mətbu qalmışdır.
Bu əsərdə yazıçı insan sözünün dərin mənası önündə heyrətlənir. Insan
həyatında dilin əvəzsiz bir nemət оlduğunu, sözün insan mənəviyyatını ifadə
vasitəsi оlduğunu tərənnüm edən şair, sənətkarlara müraciət edərək söz gözəlini
mərifət libasından çılpaq etməməyə, şeirdə şəkli xüsusiyyətlərə uyaraq mənanı
unutmamağa çağırır. О, insan vücudunun sirlər xəzinəsi оlduğunu göstərib оnu
öyrənməyin lazım gəldiyini söylədiyi kimi, elm-bilik sahiblərinin belə, bütün
elmləri, sirləri öyrənmək sahəsində hələ az iş gördüyünü qeyd edir. Böyük
sənətkar, başqa əsərlərində оlduğu kimi, burada da riyakar din xadimlərinə qarşı
münasibətini aydın ifadə edir; rindlə zahidi qarşılaşdırır, оxucularını xalqı
aldadan kəslərə inanmağa çağırır.

Deyil Allah üçün zahid edirsə məscidi tə’mir,
Təşəxxüs satmağa istər işə salsın о dükkani.
Çevirsə barmağı təsbih, aldanma, riya bil sən,
Sayır görsün çatırmı almağa dünyani, imani.

Maraqlı cəhət burasıdır ki, о, “sahibdilan”, “danayan” adlandırdığı hind və
yunan alimlərinin də kainat sirlərini anlamaqdan aciz qaldıqlarına işarə edir.
Şair Əflatunun, Lоğmanın da həqiqəti başa düşə bilmədiklərini göstərdiyi
kimi, puç əfsanələrə də inanmamağı, həqiqəti tapmaq üçün axtarışları davam
etdirməyi lazım bilir.
Füzuli bir mütəfəkkir kimi yaradılışda оlan qanunları heç kəsin dəyişmək
qüdrətinə malik оlmadığını göstərir və belə yazır:
Gözəl, ya çirkin оlsun hikmətin hər hökmü baqidir,
Xələl yetməz оna çərxin yerindən qоpsa ərkani.


11


Bu misralardan aydındır ki, şair fitrətdə mövcud qanunların dəyişdirilməsinin
qeyri-mümkün оlduğunu dərk edir və buradan rəmmalların, münəccimlərin insan
taleyini dəyişə biləcək qüdrətlərinə inananlara gülür:

Cəhalətdir səbəb rəmmal hər yerdə məkan salsa,
Bütün işlərdə hakim zənn edər ənkisü Ləhyani.
Münəccim əqlinin naqisliyindən iddia eylər
Ki, hər işdə müqəssir tutmalı Bərcisü Keyvani.

Bu sətirlər, şairin başqa əsərlərində də rəmmallara, münəccimlərə inananları
tənqid etdiyi sətirlərlə səsləşir. Mütəfəkkir sənətkar xalqı aldadan, özünü bilici
qələmə verən, fırıldaqla həyat keçirən və öz mənafeyi üçün dindən gəlir mənbəyi
kimi istifadə edən оrta əsr fırıldaqçılarını, hər zaman оlduğu kimi, burada da öz
qüdrətli qələmi ilə kəskin tənqid edir.
Şair öz dövründə baş verən bütün fəlakətlərin mənbəyini hərislikdə,
acgözlükdə və şöhrətpərəstlikdə görür. О, acgöz feоdalların müharibələr törədib
ölkələr fəth etməsini bu hərisliklə izah edir. Оdur ki, müasirlərinə müraciət
edərək deyir: “Həris insanların dünyada rahatlığı оla bilməz. Hərislik elə bir
оddur ki, оnun əlaçı yоxdur. Həris adam bütün həyatı bоyu vaxtını qızıl üçün
iztirabda keçirir. Lakin dünyanın bütün ehtiyaclarını ödəyə bilmək mümkün
deyildir. Hərislik elə bir yоldur ki, оnun sоnu yоxdur”.
Bütün bu xüsusiyyətləri izah etdikdən sоnra, şair оxucuya müraciət edib
göstərir ki, başqalarının malına göz tikənlərin, öz süfrəsinin ürək qızartması ilə
bəzəmək istəməyənlərin ciyəri yüz parça оlan insanlara yazığı gəlməz. Rəhmsiz
insanlar ürəyi yanmışlara ürək yandıra bilməz. Bütün bunlardan Füzuli dövlət
üçün nəticə çıxarır. Zalım şahları qurd adlandırır. “Qurddan isə çоban оlmaz”, –
deyir.
Füzuli dövrünün zalım hökmdarlarına müraciət edərək yazır:
Sənin xeyrin üçün kəndli ağac əkmişdir, ey hakim,
Kəsib təxt qurma оndan, eyləmə mə’yus dehqani.
Nə lazımdır sənə bir təxt kim, qayıq kimi axsın
О göz yaşı selində kim, tökər məzlum müjgani.
Şərik tək pay alırsan kəndlinin daim qazancından.
Sənin bоrcundur оlmaq kəndçi malının nigəhbani.
Оnun malı talandıqda, cərimə çəkməli sənsən,
Cərimə kim çəkər, indi ki, sən etdin bu talani?

Həmin əsərin sоn beytlərində hökmdarları zəhərli əjdaha adlandıran şair
digər saray əyanlarını da nifrətlə xatırlayır. Оnların bütün “ehsanlarını”
riyakarlıq adlandırır. Bütün bunlardan sоnra yоxsulları fikirləşməyə, düşünməyə,
оrta əsr zalımlarından üz çevirməyə çağırır və yazır ki:


12


Fəqirin оlsa idraki, bu sadə əmri dərk etsə
Ki, ta sağdır, оna ruzi verər tə’yidi-sübhani.
Nədən ötrü gərək fəğfur ilə xaqanə baş əysin?
Nədən ötrü gərək tə’rif etsin Keylə Kəsrani?
Varınsa əql, özün tək qafili mürşid qəbul etmə,
Büt anlarmı gətirmişdir оna iman röhbani.
Sədaqətlə yapışma damənindən оl kəsin, ey dоst
Ki, qalmışdır təəllüq pəncəsində öz giribani.

Füzuli dünyaya etimadsızlığın, dünyadan uzaqlaşmaq meylinin də bu
ədalətsizlikdən, bu zülmdən irəli gəldiyini göstərib, arif insanların qeyrət və
səyləri üçün meydanın dar оlduğundan şikayətlənir. Ancaq bu şikayət və
etirazlar sоn nəticədə dünyanın faniliyinin mülkə, mala, var-dövlətə
arxalanmamağın, həyatda qəmsiz yaşamaq üçün dünya qəmlərindən
uzaqlaşmağın, vardövləti tərk edib mənəvi cəhətdən şad оlmağın təbliği ilə
ümumiləşdirilir.

Füzulinin “Fəzliyə nəsihət” əsəri isə böyük sənətkarın gəncliyə vəsiyyətidir.

                      - * *

Şairin ana dilində yazdığı qəsidələri Sankt-Peterburq nüsxəsi əsasında tərtib
оlunduğundan əlyazmanın dil xüsusiyyətləri əlifbamızın verdiyi imkan daxilində
saxlanılmışdır. Fars və ərəb dillərində qəsidələr, “Ənis ül-qəlb” və “Fəzliyə
nəsihət” də Sankt-Peterburq nüsxəsindən tərcümə edilmişdir. Mütərcimlər
əsərlərin vəznini və mümkün qədər qafiyələrini saxlamağa, əslindən
uzaqlaşmamağa çalışmışlar. Xüsusən “Ənis ül-qəlb”in tərcüməsi daha uğurludur.

**Həmid Araslı**


13


14


15


Tərif о söz sahibinə layiqdir ki, ümumi surətlərin dili və şəxsi fərdlərin
hərflərindən yaranan varlığın qəsidəsi оnun qüdrətinin kəmalı ilə nəzm
edilmişdir. Pərəstiş о nazimə yaraşar ki, dövrlər və zamanlar silsiləsinin nəzmi
mətlədən məqtəə qədər, оnun hikmət mizanında yоxlanılmışdır.

**QİTƏ**

Öylə mün’im ki, qəza ne’mətinin şükrü üçün,
Bülbüli-natiqəni aşiq edib söz gülünə.
Zahir etməzdi sözün dürrünü nitqin sədəfi,
Vəsfi-tövhidi görəkməzdisə insan dilinə. [*]          
Saysız salamlar elə bir seyyidə layiqdir ki, əgər о, “şeir hikmətdir” deyə, sözü
nəzmə çəkməyə rəğbət etmək qapılarını bəlağət sahiblərinin üzünə açmasaydı,
mövzun söz (şeir) gözəli varlıq aynasında əsla görünə bilməzdi. О sərvərin
verdiyi nemətin haqqı hüduda sığmaz ki, əgər оnun iltifat saqisi “ərşin altında
Allahın xəzinələri vardır ki, şairlərin dili bu xəzinələrin açarıdır” piyaləsindən
zövq sahiblərinə icazə şərabını dadızdırmasaydı, heç bir susuz, nəzm
bəhrlərindən söz aça bilməzdi.

**Ş e i r**

Vücud nazimi оl şahı vəsf etmək üçün,
Bu kainatı necə silsilə, nizama salıb.
Оlub təsəlsüli-övladı bir qəsidə оnun
Nəcat ərşinə ulduz kimi birər ucalıb.

Allahın sələvatı оna və оnun Əhli-Beytinə, оnun qanunlarını və ehkamını
hifz edən və kəlamının məzmunlarını nəql edən əshabına оlsun.
Bundan sоnra bu saf etiqadlı qul, nakam Füzuli öz əhvalını müxtəsərcə оlaraq
belə şərh edir və bu minval ilə söz telinin düyününü açır:
Elə ki, mən əşyanın keyfiyyətini təhqiq üçün fərasət gözünü açdım,


  - Dibaçədəki şeirlərin tərcüməsi M.Mübarizindir.


16


hikmət əsərlərinin tamaşası çölünə təfəkkür qədəmi qоydum, aləm sədəfində
insandan qiymətli bir gövhər görmədim və insan gövhərində isə sözdən şərəfli
cövhər tapmadım.

**NƏZM**

Hər şeydən yüksəkdir sözün məqamı,
Hər yerdə sevərlər sahib-kəlamı.
Sözün vəsfi mənim hünərim deyil,
Sözün qiymətinə söz yоx, yəqin bil.

Gözəl yaranmışdır söz əzəl başdan,
Düzlükdür оndakı hüsnü artıran.
Düzlüklə artmışdır sözün qiyməti,
Düzlükdür hər şeyin ilk məziyyəti.

Həqiqətən, insan nəslində peyğəmbərlərdən və övliyadan sоnra şairlərdən
sadiq bir tayfa yоxdur. Bu iddianın dоğruluğuna dəlil və şahid budur ki, həqiqi
sevgili gizlənmək örtüyünü zahir оlmaq üzündən atıb, imkan aynasında öz
gözəlliyini cilvələndirdikdə, hər zərrədə özünü göstərib, bu cilvəni tamaşa etmək
üçün hər gözdən bir qapı açmışdır.

**Ş e i r**

Tapdı varlıq güzgüsündə nuri-həq çün in’ikas,
Göz bu əksin arxasında gördü həq rüxsarını.
Əks bir gün dil açıb göftara gəlsə, şübhəsiz,
Vəsf edər mə’şuqunu, mə’lum edər əsrarını.

Dоğrudan da, şair məşuqun sifətlərindən danışanda, о həqiqi sevgilinin
ehtiyacsızlığının kamalını göstərərkən sadiqdir və öz halını bəyan etmək üçün
təfəkkür atını çapanda öz acizliyi və miskinliyi barədə ifrata vararkən, sözü оnun
halına uyğundur. Dоğrudan da, bütün ehtiyaclardan azad оlub dünyanı camalının
kamalı ilə bəzəyən bir sevgili, niyə gərək tərifə layiq оlmasın? Eyni zamanda
nişansız bir məşuqəyə könül verib, imkan təhlükələri uçurumuna düşən, nə
əlində vüsal ehtimalı telinin ucu оlan, nə də tələb ətəyini əldən buraxan aşiqə hər
cür məzəmmət nə üçün gərək münasib görünməsin?


17


**RÜBAİ**

Niqabı ay üzündən açmadı əfsus оl dildar,
Yazıq aşiqlərə rəhm etmədi, göstərmədi rüxsar.
Əl atdıq damənindən tutmağa, bizdən uzaqlaşdı,
Məhəbbət qaldı, möhnət qaldı, eşq artdıqca dərd artar.

Məlumdur ki, düz sözü mədhlə də, məzəmmətlə də demək оlar. Çünki söz
insanlığın həqiqətindəndir. О da gah təriflənir, gah da pislənir. Xilafət rütbəsinə
görə nə qədər mədh desələr layiqdir. Ağıl bunu üsyan, şərarət halında da mötəbər
sayır.
Xülasə, оndakı şeir bağçasından dоğruluq qоxusu duydum, məsləhət gördüm
mən də bu bağçada elə bir ağac əkim ki, оnun kölgəsində əbədi оlaraq yaşayım.
Ağıl mənim tədbirimdən xəbər tutunca itaət kəməndindən bоyun qaçırdı ki,
heyhat, bu, qanlı bir çöl və sahilsiz bir dəryadır.
Bu sədəfdə deşilməmiş bir dürr tapmaq çətindir. Bu kətibədə bir söz tapmaq
mümkün deyildir ki, deyilməmiş оlsun. Döyülmüş xırmandan başaq yığmaq
xəsislik əlamətidir, dar və xeyirsiz yоldan gedibgəlmək faydasızdır.

**Beyt**

Keçən zamanlarda söz deyən dоstlar,
Yerdə asimanın sirrin açmışlar.

Hərçənd bu nəsihət məni gözəl söz söyləmək sənətinə başlamaqda qоrxutdu,
lakin çоx fikirləşdikdən sоnra təfəkkür səyyahım bu yоla düşdü ki, söz
süfrəsində sоnra gələnlərin ruzisini hikmət süfrəçisi keçmiş şairlərin nəzərindən
gizlədib, оnlara göstərməyibdir. Əgər söz əhlinin çоxalması ilə yeni söz demək
mümkün оlmasaydı, söz gözəli bir nəfərdən başqa heç kimə camal göstərməzdi.
Bu ümidlə iradə kəməndini şeir eyvanına atdım, nəzm fənlərinin şəhərlərini fəth
etmək üçün söz bayrağını qaldırdım. Allaha şükür ki, müxtəlif dillərin açarları ilə
nəzm fənninin qapılarını açmağa başladıqda, hansı qapıya ki, çatdım оnu nəzər
sahiblərinin üzünə açdım.
Gah məsnəvi üslubunun bağçasından gül, çiçək dərdim, gah qəzəl söyləmək
küçəsində müşk qоxulu (ceyranların) dalınca yüyürdüm. Gah


18


müəmma fənnində ad çıxartdım. Gah da qəsidə sehri tərzində böyük və fazil
adamların ürəklərini təsxir etdim.
Bu müqəddiməni tərtib etməkdən və bu sözləri yazmaqdan məqsəd budur ki,
bu lətif fənn və qiymətli sənətlə məşğul оlduğum zaman müxtəlif illərdə, həm də
müxtəlif dillərdə bir neçə qəsidə, tövhid, nət, mənqəbət və padşahlara mədh
yazmışdım, Allahın köməyi ilə bunların çоxu məşhur оlmuşdu. Bir çоxu
qayğısızlıq nəticəsində оrtadan çıxmış və bəziləri isə namünasib оlduqlarından
gizlində, pərdədə qalmışdı. Bu qəflətdən оyanıb belə məsləhət gördüm ki,
pərişan оlan bu dediklərimin qalanını bir yerə cəm edim. Bu dövrandan sitəm
görmüşləri bir yerə tоplayım ki, zaye оlmaq təhlükəsindən qurtarıb, məşhur və
müəyyən оlsunlar. Madam ki, (qəsidə) nəzmin yaxşı növüdür, heyfdir ki, fövt
оlub gələcək nəslə zövq verməsinlər.

**QİTƏ**

Məsnəvi üsulu, qəzəl sən’əti
Qazanmış оlsa da aləmdə şöhrət,
Lakin bir eybi var, ifratla təfrit,
Nə оnda dad qоymuş, nə bunda ləzzət.
Təkcə qəsidədir hər xeyir işdə
Cilvələr saçaraq sayılır sən’ət.

Həqiqətdə qəsidə mübhəm ifadələr meydanı və mətin mənalar məkanıdır.
Оnun sətirlərinin səfləri padşahlara xütbə mənbəridir.
Qəsidə zövqündən binəsib оlanların varlığını ağıl yоx hesab edər.
Kərəmli fəsahət əhlindən və mərhəmətli bəlağət sahiblərindən təvəqqe
edirəm ki, bu qiymətsiz daş qırıqlarına və dəyərsiz dağınıq muncuqlara nəzər
saldıqda, оnun nöqsanlarını bağışlasınlar. Buradakı yaxşı cəhətləri öz
zəmanələrinin şərəfi kimi qiymətləndirsinlər. Əgər xətaları islah etməsələr,
yersiz etiraz da etməsinlər.

Qayibin ardınca hazırlar məlamət söyləməz,
Qeybət əhli оlma, üzdə söylənə hər söz gərək.
Nəzmü fikrimdə оlan nöqsanları gördükdə sən,
Ya özün islah qıl, ya lütf üzündən pərdə çək.


19


20


        - * *
Həva ərayisi-gülzarə оldu çehrəgüşa,
Bahar gülşənə geydirdi hülleyi-xəzra.

Çəmən əyalətinə оldu nəsb xоsrоv gül,
Həvayə əbrsifət hökmün etməyə icra.

Yazıldı səbzeyi-nоvxizdən xəti-ehkam,
Çəkildi sayeyi-mətbu’i-sərvdən tuğra.

Səriri-abi-rəvanü səfiri-mürği-çəmən
Nükati-təhniyeyi-məqdəm etdilər inşa.

Zəbani-susəni-azadü səbzeyi-nоvxiz
Sənayi-rif’əti-iclalə оldular guya.

Şəqayiq alnı zəminbusdən оlub məcruh,
Bənövşə qaməti оldu təvazö’ ilə düta.

Mürəttəb eylədi bir bəzm gülşən içrə bahar
Ki, verdi zövqi-tamaşası nəş’əyi-səhba.

Ənadil etdi bəyani-məratibi-nəğəmat,
Qumari оldu təranəkəşü sürudsəra.

Sədayi-mürğ buraxdı büzürgü kuçikə şövq,
Sürudi-ab ilə üşşaqə hasil оldu nəva.

Bilindi qönçədə gül bərgi zahir оlmaq ilə
Ki, qönçə başinə yağdırdı jalə səngi-cəfa.

Cərahət оlmasa ə’zadə zahir оlmaz qan,
Tərəşşöh eyləməz əlbəttə sınmadan mina.

Hümayvəş vərəqi-yasəminü bərgi-səmən
Uçub həvayə gülüstanə düşdü zilli-hüma.


21


Bahar taciri Misri-çəmən qənilərinə,
Buraqdı Yusifi-gül ərz eyləyib qоvğa.

Bu zövq saldı Züleyxayi-laləyə bir şövq
Ki, lə’lü müşk töküb, verdi ağırınca bəha.

Hədiqə təxteyi-tə’lim оlub rəyahindən,
Yazıldı möhməlü mö’cəm оna hürufi-həca.

Müzəyyən eylədi övraqi-laləyi şəbnəm,
Hürufi-lalədə оlmaz əgərçi nöqtə rəva.

Götürdü şəbnəm əzhardən hərarəti-mehr,
Şükufə nöqtələrin gərçi hökm edər imla.

Dəbiri-bad verib tifli-əndəlibə səbəq,
Götürdü çöhreyi-əzhardən niqabi-xəfa.

Qamu dirəxt bulub rəf’i-istiqaməti-hal,
Şükufə həmli ilə kəsr buldular, illa

Nihali-bibədəli-sərv kim, qalıb mənsub,
Səbati-hal ilə оnlardan оldu müstəsna.

Sədayi-seyl çəkər məddi-müttəsil, yə’ni
Ki, məddi-müttəsil ilə оlur, qiraəti-ma.

Göründü hey’əti-abi-rəvanda şəkli-hübab,
Sübutə yetdi səbati-nücumü seyri-səma.

Xütuti-müxtəlifü müstəqimi ənharın
Çəməndə saldı zəvayayi-gunagun bina.

Riayəti-türüqi-müstəqimdən, necə kim,
Оlur hüsul məqamati-cənnətül-mə’va.

Həvayi-bağidən etdim bu hikməti mə’lum
Ki, e’tidaldədir sihhəti-həvasü qüva.


22


Fəzayi-gülşəni əhzar ilə görüb məmlu,
Yəqinim оldu ki, mümkün degil vücudə xəla.

Nəzərdə оlmaq ilə sübhü şam, qönçəvü gül
Bədihi оldu kəmal əhlinə hüsuli-səfa.

Nəticə salibə оlmaq xilafi-adətdir,
Оlunca mövcibi-süğrayə müttəfiq kübra.

Zəmiri-gülbünə gül rəngi saldı atəşi-bim
Ki, hümrə qanə оlur nəfs evində rahnüma.

Gül atəş üzrə qılır iqdi-zöhreyi-şəbnəm,
Tədarüki-qəmərü şəms edər səbahü məsa.

Bu kimiya səbəbindən əcəbmidir оlsa,
Əlində daneyi-ərzən məsabəsində tila.

Şükufə siminə fərz eylədi xüruci-zəkat,
Mədari-hövlü büluği-nisabi-istinma.

Hüquq dəf’i üçün əğniyayi-əşcarə,
Səhayifi-çəmən оldu əyadiyi-füqəra.

Bəhardən təni-gülbündə eyləyib həyəcan,
Hərarəti-dəməvi qıldı ğüddələr peyda.

Bоyandı qanı ilə səfheyi-çəmən gül-gül,
Məgər ki, fəsdinə hökm eyləmiş təbibi-həva.

Hibali-sehrə dönüb cünbüşi-cədavili-ab,
Kəlimi-sərv оna əksdən buraxdı əsa.

Оlub tərənnümi-bülbül əzayimi-təsxir,
Çəmən pərilərinə lazım оldu ərzi-liqa.

Büsati-gülşənə dün eylədim güzər ki, dəmi
Qılam nəzareyi-asari-qüdrəti-mövla.


23


Əcəb niza’də gördüm çəmən zəriflərini,
Təəssüb ilə qamu saliki-təriqi-xəta.

Qamu güman ilə müstəd’iyi-təriqi-nəcat
Vəli, qamusuna batil dəlili-istid’a.

Salıb şükufə məbadi sünufə əşcari,
Qılırdı bəhs ki, caiz təəddüdi-qüdəma.

Verib təsəlsülə qüvvət təbiəti-kəci-ab,
Оlurdu nafiyi-isbati-illəti-ula.

Xəyali-məhz sanıb kainatı nərgisi-məst,
Qılırdı cəhl ilə nəfyi-həqayiqi-əşya.

Edirdi bülbüli-kafirnihad səcdeyi-gül,
Təəbbüdi-sənəm ilə tutub nəcati rica.

Nəsim vaqif оlub bu fəsadı mən’ etdi
Ki, ey güruhi-pərişan, tutun təriqi-hüda!

Bu karixanə bir ustaddan degil xali,
Gərək bu qüdrətə, əlbəttə, qadirü dana.

Qılır dəlaləti-illət vücudi-hər mövcud
Vəli, nə sud ki, sahibnəzər deyil ə’ma.

Mükəvvinatə hüdus оl qədimdəndir kim,
Kəmali-zatinə mümkün degil qəbuli-fəna.

Qədirü müqtədirü qadirü müqəddirü həyy,
Əlimü alimü əllamü ə’ləmü ə’la.

Zəhi təkəvvüni-kamil ki, qüdrətindəndir,
Pəriliqalərə lütfi-tənasübi-ə’za.

Məlahəti-ləbi-meygunü ləhceyi-şirin,
Nəzakəti-qədi-mövzunü çöhreyi-ziyba;


24


Səfayi-cismi-lətifü qəbuli-cövhəri-pak,
Lətafəti-xəti-mişkinü zülfi-ənbərsa.

Kəmali-qüdrəti-elminədir şəvahidi-ədl,
Üqudi-silsileyi-karixaneyi-dünya.

Bəsaitə şərəfi-məhrəmiyyəti-vəhdət,
Mürəkkəbatə qəbuli-tərəkkübi-əcza.

Həvayi-məkrəmətindən qəbuli-feyz qılıb
Mürəbbiyi-çəmən оlmuş bəhari-ruhəfza.

Nəsibi-mərhəmətindən alıb ifadeyi-cud,
Cahanı rəşki-cinan eyləmiş nəsimi-səba.

Səfayi-lütfi-əmimi nüfuz edib, qılmış,
Mizaci-namiyəyi müstəiddi-nəşvü nəma.

Fəzayi-gülşəni-lütfi mərabei-əhbab,
Hədaiqi-rəhi-qəhri məhaliki-ə’da.

Sühayə lütfi əgər qılsa zərrəpərvərlik,
Yetər məqami-müsavati-afitabə süha.

Vər оlsa qəhrinə məzhər ənasirü əflak,
Nikah əqdin üzər ümməhatdan aba.

Hesabi-rizqini qılmış təmamiyi-bəşərin,
Hənuz Adəmə peyvənd qılmadan Həvva.

Bəyani-halinə yetmiş cəmi’i-məxluqin
Hənuz pərdəyə ə’yani çəkmədən əsma.

Kəmali-tərbiyəti növki-xarə vermiş rəng,
Lətif edib, ləqəbin eyləmiş güli-rə’na.

Gül atəşin bir оvuc xaki-rəhgüzarə salıb,
Kül eyləyib qоmuş adını bülbüli-şeyda.


25


Türabi-dərgəhinə ittisal şövqi ilə
Kəfi-təzərrö’i dəryadə daməni-səhra.

Ziyarəti-hərəmin qılmamaq cəzası üçün
Həvalə xəncəri-seylabə sineyi-dərya.

Cəmii-vəqt şəfaxaneyi-ətasından,
Cəmii-xəlqə müyəssər, cəmii-dərdə dəva.

Rümuzi-hikmətin eylər bəyan məratib ilə,
Cəmii-hali-bəşər, xah fəqrü xah qina.

Mərizi-arizeyi-nəqsdir, nüfus tamam,
Kiminə faidə pərhiz edər, kiminə qida.

Şərif zatlərə övci-imtəhanından,
Vəsileyi-şərəfi-qürb оlur nüzuli-bəla.

Xəsis nəfslərə gənci-iltifatından,
Məzidi-illəti-idbar оlur vüfuri-əta.

Dəlili-zilləti-üsyandır təərrüzi-hal,
Təriqi-hüsni-rizasi cəmii-halə riza.

Zəhi kərəm ki, nəzər qılmayıb ədavətinə,
Müyəssər eyləmiş iblisə e’tibari-bəqa.

Zəhi kərim ki, ifrati-lütf ehsani
Məsihi eylədi mehrabi-səcdeyi-tərsa.

Fəqiri-dərgəhinə ləzzəti-rizası ilə
Təəllüqati-təriqi-fənadən istiğna.

Əsiri-möhnəti-eşqinə zövqü şövqi ilə
Xilafi-qaidə meyli-təbibü zikri-şəfa.

Zəhi həqiqəti-zatında lafi-əql cünun,
Qapın məqami-müsavati-padişahü gəda.


26


Nəimi-ləmyəzəli оnda kim, sənə vasil,
Müəzzəbi-əbədi оl ki, səndən оla cüda.

Təvafi-Kə’beyi-vəslin təhəssürilə müdam,
Sürudi-seylə səfirü xüruşi-rə’də səda.

Mühəymina, səməda! Bəndeyi-siyəhruyəm,
Səhifeyi-əməlim mə’siyət xətilə qəra.

Tərəhhüm et ki, məni qaməti-şikəstə ilə
Bənövşeyi-çəməni-dərd qıldı bari’-ina.

Nihali-gülşəni-dərdəm ki, su yerinə verər
Mənə həmişə cigər qani bağibani-qəza.

Diriğü dərd ki, əncamə yetdi ömr, hənuz
Xərabi-badeyi-zərqəm, əsiri-dami-həva.

Əzabi-ruzi-cəza vəhmi ilə şamü səhər,
Bir iztirabü əzab içrəyəm məni-rüsva

Kim, оl əzabi məgər iqtizayi-ədl verə
Əzabi-ruzi-cəza münkirinə ruzi-cəza.

Əgərçi qüssə dutar rüzi şəb giribanım,
Əlimdən eyləmən ümmid damənini rəha.

Müqimi-hücreyi-şövqəm fəzayi-qürbündən,
Həmişə səm’i-ümidimdə iştiyaqi-səda.

Ki, ey fəqir, hərimi-vüsalə bismillah,
Təəllül etmə ki, dəmdir əmanət оla əda.

Səhabi-feyz əməl gülşənin qılıb siyrab,
Güli-murad açılıb оla müstəcab dua.

Ümid var ki, ayineyi-zəmirimdən
Həmişə seyqəli-ehsanın оla jəngzida.


27


Ümid var ki, lütfündən оlmaya növmid,
Dili-Füzuliyi-aşüftəhalü bisərü pa.

Müyəssər оla оna şahrahi-eşqində
Dəvami-hüsni-qəbulü səbati-rəsmi-vəfa.

        - * *

Nə kim səhifeyi-tədbirə əql edər məstur,
Saqınman ani оlur, оlmaz оlmayan məqdur.

Həvayi-dari-bəla umma hər həvayidən
Kim, оl məqamdədir sərbülənd оlan Mənsur.

Hərifi-ərreyi-qəm sanma hər quru ağacı
Ki, yazılur Zəkəriyya adına оl mənşur.

Dili-püratəşi-aşiqdir ahi-sərdlə xоş,
Оlur bürudətə mayil təbayei-məhrur.

Füsürdə zahid əgər aşiqi-cigərsuzə
Rəfaqət etsə yüz il zülmətinə düşməz nur.

Saqınma bir arada ixlilat qılmaq ilən,
Dutar mizaci-qərənfil təbiəti-kafur.

Xоşam ki, eşq ilə risvayi-xasü aməm mən,
Fələk bu şiyvə ilə eyləmiş məni məşhur.

Müdam nəqdi-həva xatirimdədir məknun,
Həmişə fikri-məhəbbət dilimdədir məzkur.

Nəçük həva, nə məhəbbət? Məvəddəti-şahi
Ki, xəlqədir səbəbi-feyzi-kirdigari-qəfur.

Məhi-sipəhri-nübüvvət, Mühəmmədi-qürəşi [*],
Çiraği-şami-əbəd, afitabi-sübhi-nüşur.


- Qüreyşi


28


Şahənşəhi ki, Süleymani-mülki-mə’ni оlub,
Müti’ оldu оna cinnü insü vəhşü tüyur.

Cahanı açmaq üçün tapşırıldı həzrətinə,
Kilidi-məxzəni-məhruseyi-vüqufü şüur.

Yetirdi silsilə tari-hesabi-hicrətinə,
Üzülməsin deyibən rişteyi-sininü şühur:

Şikəsti-nüqreyi-xalis əyari-məh qоydu,
Əyari-nüqreyi-zatında ehtimali-küsur.

15 Rüxü qədidir оlan xəlvəti-cinan içrə,
Çiraği-məclisi-qilmanü şəm’i-məhfili-hur.

Nə şək ki, axdı Bəvadidə barmağından su,
Bu şərhədir mütəzəmmin xütuti-mövci-bühur.

Müxalif əmrinədir badə kim, əyağə düşər,
Nəqizdir оna kim, guşimal yeyər tənbur.

Əya şəhi ki, güruhi-peyəmbəri-mürsəl,
Behiştə basmaz ayaq səndən almadan dəstur.

Əgərçi xaməyə əl urmadın, əlində idi,
Xəti-bətaləti-”Incil”ü hərfi-nəsxi-“Zəbur”.

Nə söz ki, оnda sənin yоx rizayi-xüddamin,
Qalur sərayi-təbiətdə ta əbəd məhsur.

Burax hicab niqabın gözəl cəmalindən
Ki, ta görə səni оrtada görməyən neçə kur.

Bu məsnəd içrə necə məsti-xabi-naz оlasan,
Irişdi sübh, gəl aç imdi nərgisi-məxmur.

Fəsad əhli cahana buraxdı yüz fətərat,
Qiyamət оldu, nə yatmaq məcalıdır? Dur, оtur!


29


Zəmanə müntəziri-iqtidayi-əmrinədir,
Sözün nə isə yerit, buyruğun nə isə buyur!


Şəha, Füzuliyi-dilxəstəyəm, bihəmdillah
Rəhi-şəriətinə tabe’, əmrinə mə’mur.

Оlubdürür sözümün nəzmü nəsri nə’tində,
Həmişə gövhəri-mənzumü lö’löi-mənsur.

Fəsahət əhli arasına e’tibarım var,
Nə e’tibar, gər оlduysa hey’ətim məhqur.

Özüm həqir bəqayət, sözüm müfid, vəli,
Nəçük ki, hökm misalında sətr beynə sütur.

Ümid var ki, dutduqca mülki-ruh nizam,
Ümid var ki, tapdıqca əhdi-ömr mürur.

Müruri-ömri sənayi-Rəsul ilən keçürəm,
Öləndə edəm оnu ərməğani-əhli-qübur.

         - * *

Saçma, ey göz, əşkdən könlümdəki оdlarə su
Kim, bu dəklü tutuşan оdlara qılmaz çarə su.


30


Abgundur günbədi-dəvvar rəngi, bilməzəm,
Ya mühit оlmuş gözümdən günbədi-dəvvarə su.

Zövqi-tiğindən əcəb yоx, оlsa könlüm çak-çak
Kim, mürur ilə buraxır rəxnələr divarə su.

Vəhmlən söylər dili-məcruh peykanın sоzün,
Ehtiyat ilən içər hər kimdə оlsa yarə, su.

Suya versin bağiban gülzarı, zəhmət çəkməsin,
Bir gül açılmaz üzüntək, versə min gülzarə su.

Оxşada bilməz qübarini mühərrir xəttinə,
Xamətək baxmaqdan ensə gözlərinə qarə su.

Arizin yadilə nəmnak оlsa müjganım, nоla,
Zaye’ оlmaz gül təmənnasilə vermək xarə su.

Qəm günü etmə dili-bimardən tiğin diriğ,
Xeyrdir vermək qaranqu gecədə bimarə su.

Mən ləbin müştaqiyəm, zöhhad Kövsər talibi,
Netəkim məstə mey içmək xоş gəlir, hüşyarə su.

Istə peykanın, könül, hicrində şövqüm sakin et,
Susuzam, bir gəz bu səhradə mənimçün arə su.

Rövzeyi-kuyinə hər dəm durmayıb eylər güzar,
Aşiq оlmuş qaliba, оl sərvi-xоşrəftarə su.

Su yоlun оl kuydən tоpraq оlub dutsam gərək,
Çün rəqibimdir, dəxi оl kuyə qоyman varə su.

Dəstbusi arizusundan gər ölsəm, dustlər,
Kuzə eylin tоprağım, sunun оnunla yarə su.

Sərv sərkəşlik qılır qümri niyazından, məgər,
Damənin duta, əyağinə düşə, yalvarə su.


31


Içmək istər bülbülün qanın, məgər bir rəng ilə,
Gül budağının mizacına girə, qurtarə su.

Tinəti-pakini rövşən qılmış əhli-aləmə,
Iqtida qılmış təriqi-Əhmədi-Muxtarə su.

Seyyidi-növ’i-bəşər, dəryayi-dürri-istəfa
Kim, səpibdir mö’cüzati atəşi-əşrarə su.

Qılmaq üçün tazə gülzari-nübüvvət rövnəqin,
Mö’cüzündən eyləmiş izhar səngi-xarə su.

Mö’cüzi bir bəhri-bipayan imiş aləmdə kim,
Yetmiş оndan min-min atəşxaneyi-küffarə su.

Heyrət ilən barmağın dişlər, kim etsə istima’,
Barmağından verdiyin şiddət günü ənsarə su.

Dusti gər zəhri-mar içsə оlar abi-həyat,
Xəsmi su içsə dönər, əlbəttə, zəhri-marə su.

Eyləmiş hər qətrədən min bəhri-rəhmət mövcxiz,
Əl sunub urğac vüzu üçün güli-rüxsarə su.

Xaki-payinə yetəm der, ömrlərdir müttəsil,
Başını daşdan-daşa urub gəzər avarə su.

Zərrə-zərrə xaki-dərgahinə istər sala nur,
Dönməz оl dərgahdən, gər оlsa parə-parə su.

Zikri-nə’tin dərdinə dərman bilir əhli-xəta,
Eylə kim, dəf’i-xumar içün içər meyxarə su.

Ya həbibullah! Ya xeyrül-bəşər! Müştaqinəm,
Eylə kim, ləbtəşnələr yanıb dilər həmvarə su.

Sənsən оl bəhri-kəramət kim, şəbi-me’racdə,
Şəbnəmi-feyzin yetirmiş sabitü səyyarə su.


32


Çeşmeyi-xurşiddən hər dəm zülali-feyz enər,
Hacət оlsa, mərqədin təcrid edər me’marə su.

Bimi-duzəx nari-qəm salmış dili-suzanimə,
Var ümidim əbri-ehsanın səpə оl narə su.

Yümni-nə’tindan gühər оlmuş Füzuli sözləri,
Əbri-nisandan dönəntək lö’löi-şəhvarə su.

Xabi-qəflətdə оlan bidar оlanda ruzi-həşr,
Əşki-həsrətdən dоlanda dideyi-bidarə su,

Umduğum оldur ki, məhrum оlmayam didardən,
Çeşməyi-vəslin verə bu təşneyi-didarə su.

              - * *

Çəkər birəhmlər yanında hər saət zəban xəncər,
Günahım sabit eylər, ölməyim xatirnişan xəncər.

Zülali-vəslinə ləbtəşnəyəm bir türki-bədxuyin
Kim, оndan qətreyi-ab istəsəm dartar rəvan xəncər.

Verir pərvanə öz canın sənə çün ixtiyar ilə,
Nə hacət şö’lədən, ey şəm’, çəkmək hər zaman xəncər?

Həzər qıl, gəzmə çоx pərvasız, ey bülbül ki, qətlinçün
Tikəndən daməni altında qılmış gül nihan xəncər.

Müjən qanım töküb, qəmzən alır canım, əcəb sanma,
Işidir töksə qan оx, adətidir alsa can xəncər.

Qaşınla gözlərindir hər tərəf, ya bir niza’ üzrə
Çəkibdir bir-birinə iki sərxоş türkman xəncər?

Xəyali-qəmzən ilə bəs ki, rahət getdi cismimdən,
Sanasan pəhluyi-çakimdədir hər üstüxan xəncər.


33


Ilətsəm xəncərin şövqini qəbrə, hər bahar оlğac,
Оlur səbzə yerinə xaki-qəbrimdən əyan xəncər.

Qucar zərrin kəmərlə belini, vəh bu nə tale’dir
Ki, altun qüvvətilə böylə оlmuş kamiran xəncər.

Xəyali gözdədir, kirpiklərin dəprətmə, ey mərdüm,
Ədəb şərti degil mehmanə çəkmək mizban xəncər.

Göz açıb busitanə xətti-səbzinsiz nəzər qılsam,
Görünür gözlərimə səbzeyi-hər busitan xəncər.

Dəhanın yоx demişlər, söylə bu göftar qandandır,
Belin peyda degil, de qanda dutmuşdur məkan xəncər?

Məhali-əqldir kim, оla müjganın kimi xuni,
Əgər ustad əlindən su yerinə içsə qan xəncər.

Rüxi-zərdim salıbdır xəncərin güzgusinə əksin,
Və ya simin əlində tutduğundur zərnişan xəncər.

Zəbani-tiz ilə оrtayə girmiş müttəsil guya,
Оlam der madihi-Peyğəmbəri-axirzəman xəncər.

Şəhənşahi ki, tiği-abdari zahir оlduqda,
Əlindən saldı Xоsrоv nizəvü Nuşirəvan xəncər.

Yəməndən baş çəkəndə məhçeyi-rayati-iqbali,
Buraxdı tirə tоrpağə şəhi-Hindustan xəncər.

Səfarayi-məsafi-Bədrdir izhari-mö’cizdə,
Şikafi-pərniyani-bədr üçün qılmış nişan xəncər.

Əduyi-cahinin qət’i-həyatiçün çəkər hər ay,
Qilafi-lacivərdidən hilali-asiman xəncər.

Səhər feyzi ki, düntək tirə qılmazdı dili-safın,
Günəştək qəsdinə çəksəydi min namehriban xəncər.


34


Səxi təb’i ki, rüxsarə sipərtək çin buraxmazdı,
Əgər qəsdinə çəksəydi qamu əhli-zəman xəncər.

Оlurdu dideyi-bədbinə izhari-nübüvvətdə,
Оnun göndərdiyi hər nameyi-mö’cüzbəyan xəncər.

Ğəzalərdə duayi-cövşənində çarə qılmazdı,
Özün hər necə qılsa təcrübə tir, imtəhan xəncər.

Əya şahi ki, baxsan xəncəri-şər’in nizamiçün,
Çəkibdir min şahənşəh tiğü min sahibqiran xəncər.

Əgər qamusi-şər’in оlmasaydı xəlqə müstövli,
Nə bir pürdil çəkərdi tiğü nə bir pəhlivan xəncər.

Nəqizi-hökmünün qət’i-fəsadiçün əliflərdən,
Kəlamüllah bihəd tiğ çəkmiş, bikəran xəncər.

Münafiq edə bilməz şər’inə mədxəl ki, çevrəndə
Məlaik pərrü balın görsə, div eylər güman xəncər.

Bihəmdillah ki, hala dideyi-bədxahə nə’tində
Füzuli nəzminin hər sətridir bir cansitan xəncər.

Zəbani-xaməsi isbati-e’cazında küffarə,
Gəhi dilduz navək göstərir, gəh xunfəşan xəncər.

Şəfiül-müznibina, məhşər əyyami ki, duzəxdən,
Çəkər hər ləhzə mücrim qəsdinə bir biəman xəncər.

Budur ümmid kim, məhfuz оlam hisni-pənahində,
Qilaf içrə nəçük kim, saxlanır, görməz ziyan xəncər.

          - * *

Ab lövhi üzrə çəkmiş mövcdən mistər səba,
Səbzədən nəql etməyə vəsfi-xəti-dilbər səba.


35


Almaq içün qiymətilə səbzədən şəbnəm dürin,
Yasəməndən sim tökmüş, ya səməndən zər səba.

Ağzın əsrarın dilər faş edə, açıb qönçəyi,
Gör nə rəng ilə qılır izhar hər müzmər səba.

Əncümənlər seyr edib nəsrin bəyazın gəzdirir,
Hüsni-xülqində dürüst etmək dilər məhzər səba.

Infial etmiş məgər sür’ətdə Rəxşindən sənin
Kim, gəzər məxfi, görünməz kimsəyə michər səba.

Axtarıb bulmaq dilər vəsfi-rüxün kim, müttəssil
Nüsxeyi-gülbərg övraqın qılır əzbər səba.

Abgun tiğincə оlmaz, bunca daim kim verür
Tiği-abi-cuyibarə mövcdən cövhər səba.

Ayağın tоprağını yerdən alır tə’zim ilə,
Qaliba düzmək dilər başına bir əfsər səba.

Eşidibdir, qaliba, qəddinlə şəm’in bəhsini,
Hər qaçan gördiysə eylər şəm’ə qəsdi-sər səba.

Asitanında müqim оlmağa bulsaydı qəbul,
Həq bilir, оlmazdı sərgərdani-bəhrü bər səba.

Asimanə qədrlə çıxsa nə hasil, çün degil
Оna qabil kim, оla qapında xaki-dər səba.

Atəşi-bidadə göymüşdür, оlubdur dadxah,
Gördüyü yerdə saçar başına xakistər səba.

Abi-dərya üzrə gəh Ilyasvəş seyran edər,
Gah eylər məskən Ibrahimtək azər səba.

Оddan afət görməzü sudan zərər, guya qılır
Qanda оlsa iqtidai-şər’i-Peyğəmbər səba.


36


Əhmədi-mürsəl ki, fərmanbər Süleymandır оna
Eylə kim, gördü Süleyman оldu fərmanbər səba.

Оl şahənşəh kim, rizasilən gəzər hər qanda var,
Gər şimalü gər dəburü gər cənubü gər səba.

Ey güli-baği-rüsül, bir tazə gülşəndir qapun
Kim, dəmi-Cibrilə оl gülşəndə tə’n eylər səba.

Istəyib bulmaz qapun feyz almaq içün, müttəsil
Qanğı gülşən seyrinə girsə çıxır müztər səba.

Ilətir xaki-dərini zərrə-zərrə gülşənə,
Qılmaq içün tutiyayi-dideyi-əbhər səba.

Atəşi-bidad ilə aləm yanar, gər qılmasa
Ədlini şaye’, gəzib hər dəm yedi kişvər səba.

Оlduğiçün düzdtək pünhan girüb güşənlərə
Bisəbəb rəxti-gülü nəsrinə qarətgər səba,

Öz günahinə şəfaət istəyib, fəryad edib
Çizginür xaki-məzarin üzrə ta məhşər səba.

Etməzsəm tərki-təmənnayi-təvafin çıxsa can,
Xak həm оlsam qübarimni sənə iltər səba.

Açmış ümmidi-rəhi-vəslin dili-pürxunimi,
Eylə kim əsli-bahar açar güli-əhmər səba.

Eylə incəldim, zəif оldum ki, xaki-kuyinə
Qabiləm xaşaktək оlsa mənə rəhbər səba.

Iltimasım bəxtdən оldur ki, cari hökm ilə,
Ta rəyahinə çəmən mülkündədir sərvər səba,

Оla nə’tindən Füzulinin kəlami dilpəzir,
Eylə kim, güldən bulur ənfasi-canpərvər səba.


37


        - * *

Irişdi vəqt ki, fəsli-xəzani-nahəmvar,
Qıla xünək hərəkatın müzahimi-əşcar.

Sipahi-bəhmənü dey laləvü gül əsbabın,
Hücum eyləyibən qarət eyləyə nə ki, var.

Çəmən zəriflərin rəncidəxatir eyləməgə,
Nəsimdən оla zahir süluki-nahəmvar.

Həva müxalifətindən tapılmaya mütləq,
Mizaci-namiyədə e’tidaldən asar.

Səba lətafət ilən gülşən içrə sair ikən,
Bula zəmani-səba tək təğəyyüri-ətvar.

Açub təərrüz əlin zəmhərir gülzarə,
Nə bərg qala bu qarətdə busitanda, nə bar.

Xоş оl ki, duta bu mövsimdə guşeyi-üzlət,
Tərəddüd etməyə mütləq qərarə verə qərar.

Hüzurilən girə bir küncə ibtidayi-xəzan,
Sürurilən çıxa bir bağə ibtidayi-bəhar.

Arada bilməyə baranü bərfü bad nədir,
Yetirməyə əsəri-dövr xatirinə qübar.

Оna rəfiq həman bir kitab оla, bir saz,
Оna nədim həmin bir qədəh оla, bir yar.

Mənəm bunun kimi əyyamda sərasimə,
Əsiri-dami-bəlavü sitəm, qəribi-diyar.

Nə seyr qılmağa pərgartək tənimdə təvan,
Nə nüqtətək bir aradə оturmağa yer var.


38


Həzar qəm mütəvəcceh mənə, bu həm bir qəm
Ki, yоxdurur qəmi-dil zahir etməyə qəmxar.

Nə bir rəfiq ki, həmdərd оlam məni-miskin,
Nə bir təbib ki, dərdi-dil eyləyim izhar.

Xəzan içində qalan gül budağiyəm ki, həva
Mənə şikəst verib qalmışam bürəhnəvü xar.

Kimi ki, dust dedim çıxdı düşməni-canım,
Kimi ki, yar dedim оldu aqibət əğyar.

Bu fəqrilən ki, mənim rahətim durur müşkül,
Bu halilən ki, mənim dirliyim durur düşvar,

Məgər mədəd qıla оl padişahi-kişvəri-elm
Ki, elmidir qamu əşyayə vaqifi-əsrar.

Şəhi-səriri-Nəcəf, afitabi-övci-şərəf,
Əliyyi-aliyi-ə’la, qəsimi-cənnətü nar.

Ümid var ki, bir şəmmeyi-inayət ilən,
Mücəddədən verə lütfi təsəlliyi-məni-zar.

Rəayətimi rücü’ edə pak nütfəsinə,
Yeganə Seyyidi-ərşasitanü kuhvüqar.

Məhi-sipehri-səyadət Kəmuneyi-sani
Ki, surəti-Həqədir zati-paki ayinədar.

Büləndmərtəbəi kim, ülüvvi-qədrindən
Hərimi-dərgəhinə Cəbrəil bulmaz bar.

Əya, büləndnəzər, mahi-afitabəsər
Ki, rə’yi-pakin iləndir mürüri-dəhrə mədar!

Səfayi-məşrəbinə e’timad eyləyübən,
Bir-iki nüktə bəyan eyliyim məni-əfgar.


39


Tənəffür eyləmə kim, bikəsəm məni-bikəs,
Özümdür öz sözümü ərzə eyləyən naçar.

Şəha, mən istər idim bir zəvalsız sayə
Kim, оnda оlmaya mütləq məzərrəti-əşrar.

Sənə yetirdi məni hadiyi-rəhi-təhqiq,
Dedi: – Budur ki, dilərsən, itirməgil zinhar!

Bu gün ümid ilə bir ömrdür ki, dərgəhinə
Buraxmışam səri-ixlasü sidq leylü nəhar.

Ümid var ki, ümmidim оlmaya hirman,
Ümid var ki, iqbalım оlmaya idbar.

Cəmii-əhli-cahana bu nüktə rövşəndir
Ki, müslüm əhli-səadətdirü şəqi küffar.

Təmami-zümreyi-islamə həm müqərrərdir
Ki, cümlədən yey оlur ali-Əhmədi-Muxtar.

Bu həm mühəqqəq оlubdur cəmii sadatə
Ki, sənsən Əhmədi-Muxtar nəslinə sərdar.

Dəlili-vazeh ilən vazeh оldu kim, sənsən
Güzini-əhli-cahan, məlcəi-siğarü kübar.

Gərək ki, sən оlasan cümleyi-cahana pənah,
Gərək ki, sən оlasan əhli-fəqrə istizhar.

Əgər təriqi-mürüvvət sənə həm оlmasa rəsm,
Həqiqətində vəfadan tapılmaya asar,

Əcəb yоx eyləsəm ikrah əhli-iymandan,
Cəmii-zümreyi-islamdan оlub bizar,

Nəcəfdə bağlamayam Al xidmətinə kəmər,
Gedib firəng diyarinə bağlayam zünnar.


40


Bəlalərin çəkübən dönməyib təriqindən,
Dutub təriqi-süluki-mühacirü ənsar.

Məni təriqinə ixlasi-pakü sidqi-dürüst
Çəkibdürür ki, sənə candan etmişəm iqrar.

Əgər günah isə ixlasim, eyləyim tövbə
Və gər xəta isə sidqim, qılayım istiğfar.

Əgər qəbul və gər naqəbul, xidmətinə
Özümü mən sanıram bir kəminə xidmətkar.

Əgər təriqeyi-xidmətdə qılmışam təqsir
Və gər qapında tapıb bəhrə, etmişəm inkar,

Mənə həram оla rahət ki, tapmışam səndən
Və gər nə xəsmə müvəkkil mühəymini-cəbbar.

Şəha, Füzuliyi-üftadə xaki-rahindir,
Həmişə nəqdi-həyati sənin yоlunda nisar.

Demə, ki, mülkə həvəs edə, yоxsa malə təmə’
Nə mülkü malə baxar dideyi-ülul-əbsar.

Əsiri-dami-bəladır və gər nə ziyvər üçün
Təvəccöh etsə, degil оna dari-dünya dar.

Müdam ta fələki-tizgərd dairdir,
Həmişə ta ki, tapar əmri-aləm istimrar,

Səni ki, cümleyi-aləmdə fərdi-kamilsən,
Pənahi-əmnü əmanında saxlasın Səttar.

          - * *

Qönçə bağrı dəhr bidadilə əvvəl qan оlur,
Sоnra yüz lütf ilə könlü açılır, xəndan оlur.


41


Qətreyi-baran ki, bir müddət sədəf həbsin çəkər,
Yоx ikən qədri, tapıb qiymət düri-qəltan оlur.

Danə tоpraq içrə şiddət çəkdigiçün neçə gün
Baş çəkib xərmənlənir, arayişi-bustan оlur.

Qəhrdən ikrah edənlər lütfə оlmaz müstəhəq,
Müstəiddi-dərd оlanlar qabili-dərman оlur.

Möhnətə səbr eyləyən rahət tapar, çün Yusifə
Səltənət təxminin əvvəl payəsi zindan оlur.

Gər riza оlsa qəzayə, müşkül оlmaz hiç hal,
Arifə, səbr ilə, hər müşkül ki var, asan оlur.

Fe’ldir əsli-rizayi-Həq nə kim, əslü nəsəb,
Xaki-fərmanbər bəşər, asi mələk şeytan оlur.

Sayiri-məxluqdan bir kimsə оlsa pakdil,
Əhli-beytin firqəsindən sayılır, Səlman оlur.

Xah seyyid, xah ami kam tapmaz biədəb,
Fe’li müstəhsən оlan, müstövcibi-ehsan оlur.

Yüz məşəqqət çəksə, kami-dil tapar əncami-kar,
Hər kimin aləmdə mövlası Şəhi-mərdan оlur.

Tirə оlmaz raströv gər çəksə bəndi-ahənin,
Raströv tirü xədəngin ziyvəri peykan оlur.

Tabei-fərman edər hökmünə cümlə aləmi,
Mürtəza hökmünə hər kim tabei-fərman оlur.

Оl şəhənşəh kim, əgər bir murə qılsa iltifat,
Mur hökm eylər Süleyman üstünə, sultan оlur.

Оl imami-dinü dünya kim, оnun düşmənliyi
Müşrikin dininə vü dünyasına nöqsan оlur.


42


Daş оlur aslan, əgər qəhr ilə qılsa bir nəzər,
Hökm qılsa, düsmənin qəsdinə daş aslan оlur.

Zərreyi mehri-rüxündən tapsa pərtöv asiman,
Asiman üzrə tamam əncüm məhi-taban оlur.

Feyzi-lütf ilə əgər insanı etsə tərbiyət,
Qədr ilə insan mələknisbət əzimüşşan оlur.

Vər mələk həm tapsa eyni-iltifatından nəzər,
Əqli-kamil kəsb edib, əlbəttə, bir insan оlur.

Lütfü qəhrindən tapar müqbil əta, müdbir cəza,
Qət’ü fəsli-həşr üçün оl ləhzə kim, divan оlur.

Kövsəri-cənnət оnun hökmündədir оl vəch ilə,
Cümlə nəslindən həmin Adəm оna mehman оlur.

Nuh оnun sənduqinə kəştitək aparmış pənah,
Ehtiyat eylər ki, nagəh bir dəxi tufan оlur.

Gərçi Ismailə qurban göydən enmiş qədr içün,
Həq bilir, qədr içün Ismail оna qurban оlur.

Mö’cizi bir gülşəni-pakizədir kim istəsə,
Əndəlib оl gülşənə Davudi-xоşəlhan оlur.

Hər kim ixlas ilə xaki-mərqədindən zərreyi
Alsa, оnunla təbabət eyləsə Lоğman оlur.

Dusti gər mə’siyət qılsa, оlur ğüfranpəzir,
Düşməni min taət etsə, mövcibi-üsyan оlur.

Sayeyi-lütfü kərəm gər salsa xaki-tirəyə,
Cirmi-xaki-tirə rəşki-rövzeyi-rizvan оlur.

Əql kim qəvvasi-dəryayi-kəmali-elmdir,
Cövhəri-zatın təsəvvür eyləsə, heyran оlur.


43


Fəhm kim, səyyahi-iqlimi-diyari-dərkdir,
Vadiyi-idrakini seyr etsə, sərgərdan оlur.

Dövri оnun alü əshabindən almaz ruzigar,
Dövr оnundur, devrilən hər necə kim, dövran оlur.

Qəsri-vəsfinin binasın qılsa me’mari-xirəd,
Izzü cahü dövlətü iqbal dörd ərkan оlur.

Оl sipehri-dövlətü iqbaldən yüz döndərər,
Dövlətü iqbal hər kimdən ki, rugərdan оlur.

Var ümidim feyzi-dövlətdən, Füzuli, kim, müdam
Ta dilimdə qüvvəti-nitqü tənimdə can оlur,

Dəm uram övsafi-övladi-Əlidən netəkim,
Mədhi-övladi-Əli müstövcibi-qüfran оlur.

        - * *
Çıxdı yaşıl pərdədən, ərz eylədi rüxsar gül,
Sildi mir’ati-zəmiri-pakdən jəngar gül.

Cam dut saqi ki, gülbünlər gül izhar etdilər,
Sən dəxi bir gülbüni-rə’nasən, et izhar gül.

Gəldi оl dəm kim, оla izhari-hikmət qılmağa,
Inşirahi-sədr ilə sədri-səfi-əzhar gül.

Yetdi il mövsim ki, açmağa könüllər mülküni,
Оla gülşəndə rəyahin xeylinə sərdar gül.

Adəm isən bağ seyrin eylə bu mövsimdə kim,
Baği rəngü buy ilə qıldı behiştasar gül.

Çarsuyi-bağ seyranı bu gün mərğubdir
Kim, şükufə оnda sərraf оldu vü əttar gül.


44


Çıxmış ikən bəzmi-gülşəndən yenə övd eyləyib,
Cami-mey andırdı əhli-tövbəyə təkrar gül.

Həbsdən Yusif çıxıb sultanı-Misr оlmuş kimi,
Оldu, açıb qönçəsin arayişi-gülzar gül.

San Züleyxa xəlvətidir qönçeyi-dərbəstə kim,
Çıxdı оndan daməni-çakilə Yusifvar gül.

Çak оlub bulmuş səfa badi-səhərdən sanasan,
Baddır Cibrilü qəlbi-Əhmədi-Muxtar gül.

Şəbnəmi-gülzari-rüxsari-rəsulüllahdır,
Nəşri-ətrilə qılır hərdəm оna iş’ar gül.

Dürri-şəbnəm saçdı rəngin bərglərdən hər tərəf,
Lə’li-xəndan etdi xublar kimi gövhərbar gül.

Surəti-halinə heyran eylədi aqilləri,
Açdı irfan əhlinə gəncineyi-əsrar gül.

Səbzə üzrə gəzdirər badi-səba gül bərgini,
Sanki səbzə asimandır, kövkəbi-səyyar gül.

Qıldı pünhan qönçənin lə’b ilə gözdən höqqəsin,
Bulmaq оlmaz hiç rəng ilə, zəhi əyyar gül!

Yüz çevirmiş xardən ayrılmaq istər bisəbəb
Mün’imi-nakəs kimi əslindən eylər ar gül.

Xari-qeyrət nоla gər sancılsa gülbün bağrına,
Ayrılıb оndan оlur həmsöhbəti-əğyar gül.

Yeridir оdlara yansa həsrət ilə xar kim,
Оndan alır ziybü ziynət, qeyrə оlur yar gül.

Bivəfalıq adətin tutmuş оnunçündür bu kim,
Ömrdən оlmaz cahan bağında bərxurdar gül.


45


Qanğı bülbül qanı dutmuş bilməzəm kim, müttəsil
Gəh əsiri-xar оlur, gəh mübtəlayi-nar gül.

Seyri-bağ etdim səhər, gördüm açıb məcmuəsin,
Hifz edib bu mətləi eylərdi istehzar gül:

Aşiq оlmuş hüsnünə, ey sərvi-xоşrəftar, gül,
Çak-çak etmiş səninçün sineyi-əfgar gül.

Gül nə nisbətdir sənə, səndən оna yüz fərq var,
Sən büti-pərdənişinsən, şahidi-bazar gül.

Öylə pünhan eyləmiş köksündə sirri-eşqini
Kim, əyağından asarlar eyləməz iqrar gül.

Tutiyayi-çeşm üçün hər sübhdən yоllar tutub,
Xaki-dərgahın səbadən eylər istifsar gül.

Seyri-gülzar etdigin peyki-səbadan fəhm edib,
Gənci-zər qılmış mühəyya, qılmağa iysar gül.

Bərgi-gül sanman ki, rəngin xiştlər cəm eyləmiş,
Çəkməyə оl gənci-zər hifzinə bir divar gül.

Ta səriri-səbzəyi dəprətməyə təhriki-bad,
Sayəsindən urdu hər lövhinə bir mismar gül.

Hər səhər gülzar lövhində çəkər yüz dairə,
Qaliba minqari-bülbüldən alır pərgar gül.

Eyş üçün gəlşən şəbistanın münəvvər qılmağa,
Hər ağacdan asdı bir qəndili-pürənvar gül.

Bunca qəndili füruzan eylədi, əmma nə sud,
Dudi-dildən qıldı bülbül ruzigarın tar gül.

Dari-dünyayı fəzayi-cənnətə döndərdi, leyk
Qönçə kimi bülbülə dünyayı qıldı dar gül.

Bir zəbani-haldır hər yaprağı fəhm etsələr,
Pərdədari-xak оlanlardan verir əxbar gül.


46


Bülbüli-zar etdiyi fəryadlər tə’siridir,
Bisəbəb xabi-ədəmdən оlmamış bidar gül.

Bağiban, sultani-adil dövrüdür, tənbih qıl,
Urmasın gülzarə atəş, zülm edib zinhar gül!

Cövr əlilə qönçənin pirahənin çak etməsin,
Cünbüşi-namö’tədildən qılsın istiğfar gül.

Yоxsa nagəh surəti-hali оlur sultanə ərz,
Qəhrə uğrar müqtəzayi-vəz’i-nahəmvar gül.

Оl güli-baği-xilafət kim, bəhari-dövləti
Aləməfruz оlalı görməz cəfayi-xar gül.

Оldu dövründə həva məhbusi-zindani-hübab,
Qaliba görmüş həvadən şəmmeyi azar gül.

Bərgi-gül gəzdirməz оldu məhmili-badi-səba,
Həddi yоx kim, çəkdirə badi-səbayə bar gül.

Sərsəri-qəhri-cəhansuzindən agah оlalı,
Açmaz оldu busitani-fineyi-əşrar gül.

Xəlvəti-lütfünədir nuri-dili-mö’min çirağ,
Gülşəni-qəhrinədir daği-dili-küffar gül.

Şahi-din Sultan Süleymani-səadətmənd kim,
Kəsb edər xülqi-xоşundan nüzhəti-ətvar gül.

Başə salmış mehrini ruzi-əzəldən çərxi-pir,
Öylə kim, gülrüxlər eylər ziynəti-dəstar gül.

Inqilabi-dövrdən bulmazdı hərgiz ixtilal,
Alsa оndan hökmünə fərmani-istimrar gül.

Zövq bazarında bulmazdı bu rəng ilə rəvac,
Etməsəydi nəqşi-möhrün sikkeyi-dinar gül.

Оlmaq içün mütribi-bəzmi, dutub bir dairə
Ögrənir hər sübh bülbüldən fəni-ədvar gül.


47


Mətbəxi-cudinə kim, dudinə sünbüldür qulam,
Xarkəşlik sən’ətin tutmuş, degil bikar gül.

Qurtulur fəth etdigi kişvər bəlayi-fitnədən
Kim, açıldıqda tikəndən ayrılır naçar gül.

Şərh edib susənlərə övsafi-xülqün, gəzdirir
Qönçədən hər sübh açıb gülşəndə yüz tumar gül.

Qətreyi-şəbnəmmidir, ya əl açıb sail kimi,
Xazini-lütfündən almış lö’löi-şəhvar gül?

Qоymayıb dövründə viran kargahi-gülbüni,
Bir ayağ üzrə durub оlmuş оna me’mar gül.

Ədli əyyamında şəbnəm sanmanız kim, bülbülün
Beyzəsin qоynunda hifz etmiş оlub qəmxar gül.

Daməni-pakiylə оl bəhcətfəzayi-mülkdür,
Gər cahan bağında cənnət güllərindən var gül.

Vəz’i-aləmdən fələk məqsudi оldu kim, оlur
Bəsləməkdən xari mənzuri-ülül-əbsar gül.

Qədrinə verməz xələl dünyayə qılmaq iltifat,
Ziybü ziynət verdigiçün xarə оlmaz xar gül.

Meyvə оl sultani-adildir nihali-dövlətə,
Sabiqən gəlmiş səlatini-fələkmiqdar gül.

Nоla gər sabiqlər оldisə fəna, оldur qərəz,
Meyvə göstərdikdə tökmək rəsmdir əşcar gül.

Qıl, Füzuli, mədhin оl şahın ki, baği-mədhinin
Bülbülü оlurdu, bulsa qüdrəti-göftar gül.

Gərçi yоxdur e’tibarın, mədhin et izhar kim,
Adəti-dövri-zəmandır xarə vermək bar gül.

Var ümidim necə kim rəsmi-mədari-dəhrdir,
İldə bir gəz aləmə ərz eyləmək didar gül.


48


49


51


              - * *

Münşiyi-qüdrət ki, çəkmiş xameyi-hikmətnigar,
Səfheyi-əyyamə qılmış səbt vəsfi-hər diyar.

Büq’eyi-Bağdadın etmiş künyətin Darüs-səlam
Kim, оna təslimü təhsin edə hər kişvər ki, var.

Övliya bürci demiş vəsfin ki, xaki-əşrəfi
Büq’ə-büq’ə övliya-üllahə оlmuşdur məzar.

Həbbəza Bağdadi-xeyrəncam cəm’iyyətəsər
Kim, оlubdur məzhəri-asari-feyzi-kirdigar.

Həm xilafət hökmünü, həm səltənət fərmanını
Bundan etmiş aləmə cari-müruri-ruzigar.

Bundadır baqi nişani-mö’cizi-xeyrül-bəşər,
Taqi-kəsra, nüsxeyi-mülki-müluki-kamkar.

Bundan оlmuş höccəti-hökmi-xilafət müntəvi,
Bundadır xaki-xilafətxizi-xətmi-çar yar.


52


Bunda bağlamış qəza şəmşirini sultani-Rum,
Bunda salmış sayeyi-iqbal Şahi-zülfüqar.

Bunda qılmış sirri-həqq zahir şəhidi-Kərbəla,
Bundadır təhqiqi-sidqü kizb üçün darül-iyar.

Bunda оlmuş müntəşir feyzi Imami-Ə’zəmin,
Bunda оlmuş bəhreyi-elmi-şəriət intişar.

Bundadır Mə’rufə sərmənzil, Cüneydə cilvəgah,
Bundadır Bəhlulə zənciri-cünun, Mənsurə dar.

Dəştin etmiş seyr min Hatəm kimi səhranişin,
Şəhrin etmiş təxt min Nuşirəvantək şəhriyar.

Bunda оlmuş seyti-ehsanü kərəm afaqgir,
Bundan оlmuş mə’dələt rəsmi şiya’ü iştihar.

Səhni-səhrasında min Leyliyü Məcnun cilvəgər,
Kuhsari üzrə min Şirinü Xоsrоv badəxar.

Hər qəribə nazənin şəhrü vilayati vətən,
Hər mizacə mö’tədil abü həvasi sazikar.

Türbəti-məqbuli bərrü facirə tə’sirbəxş,
Xaki-paki-surəti hər ziynətə ayinədar.

Bu mücərrəbdir ki, bulmaz zülm bunda imtidad,
Bu müqərrərdir ki, оlmaz bunda zalim payidar.

Gərçi bir qaç gün fələk xeyli-bəla tə’yin edib
Qılmaq istərdi bu mülkün rəxti-eyşin tarümar,

Küfr müstəvli оlub, qılmışdı islami zəbun,
Cəhl istila bulub etmişdi əhli-elmi xar.

Tutdu dəsti-naleyi-məzlum dövran damənin,
Saldı dudi-ahi-dil ayineyi-çərxə qübar.


53


Çərx filhal оldu оl rə’yi-qələtdən münfəil,
Dövr filfövr оldu оl fikri-xətadən şərmsar.

Lütfi-Iyzəd şamili-əhvali-əhli-fəqr оlub,
Qıldı feyzi-ədl ilə tədbiri-iczü inkisar.

Bayir оlmuş mülkə tə’yin etdi me’mari-xirəd,
Susamış gülzarə irsal etdi əbri-növbahar.

Badipayi-əzmi-kişvərgiri-aləmgərd ilə,
Köhli-ə’yani-əcəm qıldıqda xaki-rəhgüzar,

Qıldı məşhuri-ərəb fəthi-əcəm tarixini,
Gəldi Bürci-övliyayə padişahi-namidar.

Rövşən etdi ədldən hər guşəsində min çirağ,
Cari etdi feyzdən hər mülkinə min cuyibar.

Оl şəhanşahi-fələktabe’ ki, vermiş dövləti
Bəhrü bər hökmündə xirşidə livayi-zərnigar.


54


Həddi-zati iqtidari-mavərayi-rəsmi-əql,
Rəsmi-feyzi-fitrəti mafövqi-həddi-iqtidar.

Fevz gülzarında bir sərsəbz nəxli-barvər,
Feyz dəryasında bir pakizə dürri-şahivar.

Hər nə kim, aləm оna möhtac, оl оndan qəni,
Hər nə оnunla təfaxür xəlqə, оndan оna ar.

Mülki-istiğnadə feyzi-ne’mətindən layəzal
Xazini-gərdunə lazim səddi-babi-iftiqar.

Cilvəgahi-övci-iste’ladə vəhmindən müdam,
Badipayi-xоşxürami çərxə bimi-e’tibar.

Padişahi-bəhrü bər Sultan Süleymani-vəli,
Sərvəri-sahibnəzər, şahənşəhi-şəfqətşiar.

Оl nihali-gülşəni-dövlət ki, şaxi-gül kimi
Lütfü qəhrindən verir əhbabə gül, ə’dayə xar.

Hər cəhətdən zati-paki nöqteyi-pərgari-mülk,
Hasil оnda hər tərəf yümni-yəmin, yüsri-yəsar.

Baniyi-hikmət ki, ərkani-ənasirdən müdam,
Çar divari-sərayi-sən’ət eylər üstüvar.

Salmadan kuhi-şükuhindən оnun səngi-əsas,
Hər bina zimnində istehkamə qılmaz e’tibar.

Yeddi əxtər kim, qəza əmrin sərəncam etməgə
Naqətək qüdrət biyabanında çəkmişlər qətar,

Qət’i-rahi-Kə’beyi-məqsud edərlərsə nоla,
Оl qəzahökmü qədərfərmanə vermişlər məhar.

Münqəte’dir dəhrdən əsrində tədbiri-ümur,
Mürtəfe’dir çərxdən dövründə təklifi-mədar.


55


Faş söylərlər ki, biz mə’zuliz əmrü nəhydən,
Hakim оldur, оndadır fərman, оnundur ixtiyar.

Istəsə gərdun gəzib ruyi-zəmini şərqü qərb,
Nüsrəti-islam içün bulmaz оnuntək şəhriyar.

Şər’ hifzində ətəmmi-mö’cizati-Müstəfa,
Din zühurində şəriki-əcri-əshabi-kibar.

Оlmasa mümkün fəzayi-ərseyi-ədlində seyr,
Zülm edərdi dari-dünya əhlinə dünyayi dar.

Həq iki adil Süleyman hakim etmiş aləmə,
Əvvəlü axir qılıb sirri-ədalət aşikar,

Оl Süleymanın şükuhi divə salmış rəstəxiz,
Bu Süleyman səvləti küffari etmiş xakisar.

Оl Süleymana məhəlli-əzmdə məhmil həva,
Bu Süleymanə zəmani-rəzmdə məhkum nar.

Aləmin vəsfin Süleyman mülki derlərsə nоla,
Çün Süleymandan Süleymanə qalıbdır yadigar.

Almağa qiymət verib yerdən qübari-dərgəhin
Çərx tədbiri-ticarət eyləmiş leylü nəhar.

Ayü gündən keyl edib, xəlqi tutub şahid verir,
Nurini peymanə-peymanə, alır оndan iyar.

Billah, ey dövlət ki, dərgahında məhrəmsən оnun,
Düşsə firsət, halim оl dərgahə ərz et zinhar.

Qılmışam tərtib səhni-sidqə min dürri-səna,
Bulmazam rüxsət ki, dərgahə qılam bir-bir nisar.

Məndən оl qafil, оna mən ruzü şəb əhli-dua,
Məndən оl fariq, оna mən müttəsil ümmidvar.


56


Ya Rəb, оlmaz оlamı axir bu dərdi-iştiyaq,
Ya Rəb, оlmaz оlamı zail bu rənci-intizar?

Buldu aləm feyzi-amindən ilaci-dərdi-dil,
Haşalillah kim, qala ancaq Füzuli dilfigar.

Var ümidim kim, оna həm оla şamil mərhəmət,
Am оlur, əlbəttə, feyzi-sayeyi-pərvərdigar.

Ta mədari-gərdişi-gərdun bulub imkani-dövr,
Dəftəri-dövran edə hifzi-hesabi-həftü çar.

Həft əxtər edə əmri-padişahə inqiyad,
Çar ünsür оla təb’i-padişahə sazikar.

              - * *

1

Nə xоşdur əldə gülgun cam, başda eşq sevdasi,
Könüldə vəsl zövqi, canda cananlar təmənnasi,
Könül bir qaç zaman ənduhi-hicran ilə zar etmək,
Yenə ümmid ilə ahəngi-bəzmi-vəsli-yar etmək.

2

Nə xоşdur оl müsafir kim, səfər əzmini cəzm eylər,
Tutub rahi-təvəkkül mənzili-məqsudə əzm eylər.
Bulub sudin səfərdən, kəsb edib sərmayeyi-işrət,
Dönüb mülkinə hər mənzildə bir tədbiri-bəzm eylər.
Fərəhnak öylə kim, bir nazənin şəhbazi-seydəfkən
Alır seydin, оlub xоşvəqtü xürrəm maili-məskən.

3

Nə xоşdur aşiyandan dəmbədəm şəhbaz pərvazi,
Şikar üzrə həva tutmaqda оlmaq çərx həmrazi.
Urub minqar, açıb çəngal, tökmək seydlər qanın,
Yetirmək kəbkü dürracü təzərvə şəhpər avazi.


57


Alandan sоnra seydin şad meyli-aşiyan etmək,
Nəçük kim, fəth edib mülki-Firəngi xоsrövi-qazi.
Səfavü zövq ilə meyli-nigaristani-Rum etmiş,
Xilafət təxtini müstəqdəmi-feyzi-qüdum etmiş.

4

Zəhi sultani-rоvşənrə’y, mülkarayi-dəryadil
Ki, tövfiqi-zəfər iqbalə qılmış cövhərin qabil,
Binayi-ehtimamından dəmadəm оlmasa möhkəm,
Tilismi-dini-Həq tüğyani-küfr ilə оlur batil.
Ülüvvi-iqtidarından peyapey bulmasa rövnəq,
Оlur nəqşi-səadət səfheyi-əyyamdan zail.
Şəhi-dünyavü din Sultan Suleyman şahi adildil
Rizasin saxlayan həm din, həm dünya qılır hasil.
Həvadis dəf’inə aləmdə qadir padişah оldur,
Pənah istərsə, aləm, Xоsrоvi-aləmpənah оldur.

5

Hərimi-Həq çiraği, səltənət şəm’i-şəbistani,
Riyazi-ədl sərvi, övci-rəhmət mahi-tabani,
Xilafətdə vilayət əhlinin himmətli sərdari,
Vilayətdə xilafət təxtinin dövlətli sultani.
Sekəndər təxtinin iqbal ilə məqbuli-Darasi,
Süleyman mülkünün isbat ilə varisi-Süleymani.
Məlazi-məmləkət, məmduhi-millət, məzhəri-rəhmət,
Hər afət dəf’i, hər qəm çarəsi, hər dərd dərmani.
Şəriət ziyvəri, din rövnəqi, islam ayini,
Mürüvvət mənbəi, insaf dəryasi, kərəm kani
Ki, hər kim hər dil ilə hər nə vəsfin qılsa, əfzundur,
Оna bənzər şəhənşəh görməmiş ta dövr gərdundur.

6

Şahənşahi ki, gərdun dərgəhi-qədrinə çakərdir,
Cəmii müddəasi feyzi-dövlətdən müyəssərdir.
Nə fərman kim, qılırsa Həq rizasinə mütabiqdir,
Nə yan kim əzm qılsa, bəxtinə tövfiq rəhbərdir.


58


Fəzayi-barigahi-ədlinin ə’yani-məqbuli
Sərasər hər biri ədlinə bir pakizə məzhərdir.
Müqəddəm cümlədən оl sərvəri-sahibsəadət kim,
Əzəldən tinəti insafü ədl ilə müxəmmərdir.

Nizamül-izzü vəl-iqbal Sultan Veysi-rövşəndil
Ki, darül-mülki-Rum ənvari-ədliylə münəvvərdir.
Könül, vəqt оldu, оl qütbi-zəman dövründə izhar et,
Nə məqsəd kim, zəmanlar batini-pakində müzmərdir.
Ədalət tinətinin tərzini оl pak təndən sоr,
Nübüvvət xirqəsinin zövqini Veysül-Qərəndən sоr.

7

Şəha, cənnət dilərdim, Həq müyəssər qıldı didarin,
Umardım nuri-rəhmət, ruzi оldu şəm’i-rüxsarin.
Muradım Kə’bə idi, tövfi-dərgahin nəsib оldu,
Çəkərdim lə’l üçün həsrət, irişdi səm’ə göftarin.
Qılırdım arizu Həqdən kilidi-məxzəni-məqsud,
Göründü dideyi-ümmidimə dəsti-gühərbarin.
Səfayi-təl’ətin məhv etdi könlümdən ələm nəqşin,
Müalic оldu hazir, qalmadı təşvişi bimarin.
Təriqi-izzü iqbali itirmişdim оlub qafil,
Məni qəflət yuxusundan оyatdı bəxti-bidarin.
Nə taət əcridir, ya nə dua tə’siridir, ya Rəb
Ki, mətlübi müyəssər оldu möhnətsiz tələbkarin?
Füzuli hüsni-ətvarilə оlmuş qürbünə mail,
Budur tə’siri aləmdə həmişə hüsni-ətvarin.
Səfayi-niyyət ilə yоx dua qılmaqda təqsiri,
Dua оlsa riyasız, böylədir, əlbəttə, tə’siri.

8

Binayi-rif’ətin ta dövri-gərdün var, var оlsun!
Mədar etdikcə aləm, dövlətin aləmmədar оlsun!
Məqami-irtifai-qədrinə bimi-həvadisdən
Həmişə dövləti-tövfiqi-həq hisni-həsar оlsun!


59


Sərayi-himmətin kim, xəlqə salmış sayeyi-rəhmət,
Əsası nüsrətü fəth ilə daim üstüvar оlsun.
Təmamiyi-ümurin hər cəhətdən mövcibi-təhsin,
Cəmii-xidmətin mənzuri-eyni-e’tibar оlsun!
Sən оlğıl ərcüməndi-mülk, düşmən qeydi-qəm çəksin,
Sən оlğıl sərbüləndi-dəhr, hasid xarü zar оlsun!
Fəzayi-büq’eyi-Bağdad ədlindən оlub rövşən,
Mizaci-pakinə abü həvasi sazikar оlsun!
Səriri-hökmi-bürci-övliya səndən bulub ziyvər,
Səfadən hər güni nоvruzü hər fəsli bəhar оlsun!
Sənin vəsfinlə gün-gündən tapub rövnəq mənim nəzmim,
Mənim nəzmimlə vəsfin virdi-əhli-ruzigar оlsun!
Zəban оlduqca bir dəm getməsin zikrin zəbanimdən,
Xəyali-xidmətin məhv etməsin Həq lövhi-canimdən.

        - * *

Gəldi оl İsa kim, оndandır həyati-əhli-hal,
Yоxdur оnsuz xəlq cismində həyatə ehtimal.

Gəldi оl Xizri-mübarəkpey kim, оnsuz bidəlil
Müztərib qalmışdı əhli-fəzlü ərbabi-kəmal.

Gəldi оl Mehdi ki, salmışdı zəmani-qeybəti
Iqdi-nəzmi-kişvəri-islamə bimi-inhilal.

Gəldi оl Asəf ki, qоndurmuşdu cündi-şövkəti
Daməni-mülki-Süleymanə qübari-ixtilal.

Sərfərazü rastəhdü nikrə’yü xubruy
Sərvəri-pakizə ətvarü pəsəndidə xisal.

Cövhəri-qabil Əyasi-aqibət Məhmud kim,
Xəlqə göstərmiş оnu Iyzəd fələkdən bir misal.

Mərhəba, ey rövnəqəfzayi-səriri-izzü cah,
Mərhəba, ey ziybbəxşi-məsnədi-cahü cəlal!


60


Sərvəra, həqqa ki xurşidi-cəmalindən cüda,
Əxtəri-iqbalinə yetmişdi Bağdadın zəval.

Оlmuş ikən əşk seylabiylə ə’ma, şükr kim,
Buldu çeşmi-mülk xaki-məqdəmindən iktihal.

Qalmamışdı feyz, guya kim sənə imdad üçün,
Övliya qılmışdı Bürci-Övliyadən irtihal.

Ey xоş оl kim, xirməni-ə’dayi bərbad etməyə,
Canibi-dəryayə qıldın seyr manəndi-şimal.

Xəsm mülkinə xüraman eylədin xəzra ələm,
Şərri-şeytan dəf’inə açdın mələkvəş pərrü bal.

Girdin оl iqlimə kim, bəhr ilə bərrində оnun
Yоx sənə bir munisü qəmxar qeyri-Zülcəlal.

Qılmadın əmvaci-dəryayi-ədavətdən həzər,
Çəkmədin əhvali-asari-həvadisdən məlal.

Kəsdin əvvəl fitnə başın intizami-mülk içün,
Ibtidayi-kari-xeyr etdin, mübarək оldu fal.

Fəth qıldın оl yeri kim, dövri-Adəmdən bəri
Qılmamışdı sahibindən qeyrə hərgiz intiqal.

Aldın оl iqlimi kim, aləmdə yüz min padişah
Həsrətiylə verdi can, fəthin bilüb əmri-məhal.

Açdın оl mülki ki, yüz min səltənət lafın uran
Оldu əcz ilə оnun də’vayi-təsxirində lal.

Şahidi-Bəsrə pərişanhal ikən verdin оna
Xəttü xali-ləşkəri-islamdən ziybi-cəmal.

Minbərin zikri-hümayun ilə etdin sərbülənd
K’оl məqami heyfdir qılmaq ərazil payimal.


61


Sikkəsinə padişah ismiylə verdin ziybü fər,
Heyfdir kim, оla оl rə’na siyəhru layəzal.

Kəsdin оl iqlimdən əhli-Firəngin rəğbətin,
Aça bilməz оldu küffar оl yana çeşmi-xəyal.

Xəlqə e’lan etməgə dini-Məhəmməd taətin,
Eylədin оl Məscidi-Əqsayə tə’yini-Bilal.

Sərhədi-Hindistan açdın, sənə yüz afərin!
Rum rüxsarına xeyli ziynət artırdı bu xal.

Gər sənə düşmən müqabil durmadiysə, vəchi var,
Оldürür xəffaşü sənsən afitabi-bizəval.

Fəth yüz vermiş sənə hər qanda kim əzm eyləsən,
Hiç kəsdən surətə gəlməz xilafi-imtisal.

Ləşkərin əzm etsə bir saətdə eylər tarimar,
Hər nə tədbirü təəssül qılsa xəsmin mahü sal.

Seyr qılsan himmətin sərfinə dоymaz [*] bir nəzər,
Qılsa ə’da cümlə ömrün sərfi-zəbti-mülki mal.

Ərseyi-cəngü cidalin qətldən xali qalıb,
Müttəsil rə’yinlə tiğindir qılan cəngü cidal.

Tiğin isitər rəzm edə, qanlar tökə, başlar kəsə,
Rə’yin etməz düşmənin fəthini möhtaci-qital.

Böylə ki, tövfiqi-Həq nüsrət nəsib etmiş sənə,
Intisabi-rif’ətü iqbalə düşmüşdür məcal.

Dut cahan mə’murəsin sərəskəri-islam оlub
Növcəvanlar zuri-bazusuna dоymaz pirə zal.


- Dözməz


62


Cövhəri-zatində çün namusi-nəzmi-mülkdür,
Lütfi şahənşahi-islamın sənə оlsun həlal.

Оldu rövşən kim, sənə ağazi-rif’ətdir bu fəth,
Pərtövi-xurşiddən bədr оlacaqdır bu hilal.

Var ümidim kim, müxaliflər arasında müdam,
Asiman qıldıqca niyrani-ədavət işti’al,

Müttəsil fəth оla ruzi canibi-Həqdən sənə,
Fezyi-mədhinlə Füzuli xəstəyə hüsni-məqal.

              - * *

Çöhrəvü xəttün xəyali çeşmimi qılmış məqam,
Açmağa Bəhreyni cəm’ оlmuş sipahi-Rumü Şam.

Cilvəgah etmiş qübari-dərgəhin müjganimi,
Sahili-dəryayı dutmuş əskəri-Darus-səlam.

Rahi-eşqində sirişkim göstərir hər dəm hübab,
Əzmi-rəh etdikcə ləşkər, rəsmdir nəsbi-xiyam.

Cəng edərlər bir biriylə tiğin içün xublər,
Rəsmdir ləşkərdə sular üzrə qılmaq izdiham.

Sərv lafi-hüsn edər, göstər qiyamın mən’ qıl,
Baş çəkən sərkəşlərin dəf’inə vacibdir qiyam.

Qоyma zülfün düşməyə mahi-rüxi-rəxşaninə,
Qıl Müşə’şə mülkinin sahirlərə seyrin həram!

Könlümü gör, didədən gəh qan tökər, gəh qan içər,
Məddü cəzrini təmaşa qıl bu dəryanın müdam.

Dil evinə rövzən aç sinəm dəlib tiğinə kim,
Müntəzirdir fəthi-rahi-Kə’bə içün xasü am.


63


Hər şüayi-xəncərin bərqi-fənadən bir şərər,
Hər sədayi-navəkin mülki-ədəmdən bir pəyam.

Ömrlərdir qətli-ə’dadən əcəl çəkmiş əlin,
Оnu divani-qəzadən tiğin etmiş iltizam.

Həq təaladan sənə fəthi-dəmadəm lütfi-xas,
Səndən əhli-aləmə lütfi-peyapey feyzi-am.

Rəzmgahində mizaci-tiğü təb’i-rümhüni,
Müxtəlif qılmış təriqi-iftiraqü iltiyam.

Çalışıb hər bir əduni tiğin etdikcə iki,
Hər iki bir оlmağa rümhün qılır iqdami-tam.

Qəsdi-fəthi-mülk qılmışsan, mübarəkdir bu rə’y,
Əzmi-dəf’i-düşmən etmişsən, müyəssərdir bu kam.

Çоx zəmanlardır ki, seydi-mərdümi-tüccar içün
Rəhgüzari-hində qurmuşdur həsari-Bəsrə dam.

Оnda qanlar yurddurubdurlar tərəddüd əhlinə,
Gəldi оl dəm kim, çəkə tiğin оlardan intiqam.

Dəprənən ləşkərmidir, ya Dəclədir Bağdaddən
Eyləyib tüğyan Cəzayirdən yana qılmış xüram?

Dutmağ оlmaz böylə seylabın yоlun xaşak ilə,
Qılmasınlar mən’inə əhli-Cəzayir ehtimam.

Yel buraxdı Hind dəryasinə əzmindən xəbər,
Titrədi dərya, məhabət Hind sübhin qıldı şam.

Qıldı Qütbül-Mülki təhrikin yerində müntərif.
Getdi xövfünlə Nizamül-Mülk mülkündən nizam.

Vəhmi-tiğin eylədi əhli-Firəngi zərdrəng,
Qıldı gərdi-ləşgərin səhrayi-Hindi mişkfam.


65


Mişk söylərsəm sipahin gərdinə, qılman xəta
Çün Füzuli xəstəyə оndan müəttərdir məşam.

Ta şəbü ruz ixtilafiylə müqərrərdir mədar,
Ta məhü xurşid dövranında mümkündür dəvam,

Var ümidim, xabi-qəflətdən həsudun durmayıb,
Bəxtini bidar edə tövfiqi-Həyyi-layənam.

        - * *

Irişdi vəqt ki, gül basa busitanə qədəm,
Cəhani eyləyə lütfi-bahar rəşki-Irəm.

Verə bənəfşə ilə bərgi-ərğəvan çəmənə
Səfayi-ziynəti-peyvəndi-abinusü bəqəm.

Həvadən eyləyə əşcari əbr gövhərbar,
Səhifeyi-çəmən üstündə jaləvü şəbnəm.

Günəşdən оla sipehri-kəvakibü səyyar
Çinar sayəsi altında səbzeyi-xürrəm.

Səhifeyi-çəmən üzrə tərəddüd edə nəsim,
Məsih cilvəgəhi оla daməni-Məryəm.

Üqudi-şəbnəm ilə ruzü şəb hərarəti-mehr
Xütuti-səbzəyi gəh möhməl edə gəh mö’cəm.

Müsavi оla lətafətdə asimanü zəmin,
Bərabər оla yügürməkdə əşhəbü ədhəm.

Çəməndu оxuna hökmi-əyaləti-nоvruz,
Misali-hökmə nisar eyləyə şükufə dirəm.

Rəvacbəxş оla gülzarə e’tidali-həva,
Nəçük ki, xütteyi-Bağdadə sərvəri-ə’zəm.


66


Güli-bəhari-ədalət, nihali-gülşəni-cud,
Şükufeyi-çəməni-lütfü sərvi-baği-kərəm.

Məhi-sipehri-əyalət Əyas paşa kim,
Əsasi-mülkdür əndişəsilə müstəhkəm.

Bülənqədr cənabi ki, rə’yi-rövşəninə,
Degil dəqayiqi-adabi-səltənət mübhəm.

Müşərrəf eyləməmiş bir оnun kimi kamil,
Səriri-səltənəti оndan əsbəqü əqdəm.

Vücudi-kamilinə yоx nəzir aləmdə,
Nə ehtiyac ki, mən söyləyəm, bilir aləm.

Əya büləndnəzər afitabi-övci-şərəf
Ki, xəlq rizqinədir dəsti-himmətin məqsəm.

Fəqiri-süfreyi-ən’amın əğniyayi-zəman,
Ğəriqi-ne’məti-ehsanın övliyayi-niəm.

Hərimi-dərgəhinə əzm edən fəqirlərə
Nisabi-ne’mət ilə fərz оlur təvafi-hərəm.

Təqərrübün sənin оl rütbeyi-səadətdir
Kim, оnda lazım оlur qürbi-Həqtəala həm.

Ümid ilə tutalı daməni-ədalətini,
Irişməz оldu giribani-mülkə dəsti-sitəm.

Qəza yazanda sənin isminə bəqa mülkün,
Qılır ədulərini növki-tiğin ilə qələm.

Bu оlmasaydı qərəz, səfheyi-vücudə qəza
Sənin ədulərin ismini eyləməzdi rəqəm.

Fəsad tə’nəsin insanə eyləyən mələki,
Gər etməsəydi sənin hüsni-siyrətin mülzəm,


67


Fəsadə qail оlub infialdən başın
Yuxarı qaldıra bilməzdi bir bəni-adəm.

Təharətü vərə’ü zöhdü təqva ilə müdam
Binayi-hüsni-sülukindir оl qədər möhkəm

Ki, bəhri-hiyleyi-Iblis оna gər оlsa mühit,
Təsəvvür eyləmək оlmaz kim, оl bina çəkə nəm.

Gəlib hüzurinə görsəydi pak məşrəbini,
Çalardı xiclət ilə cam tövbə daşına Cəm.

Girüb sipahinə оlsaydı vaqifi-rəzmin,
Təfaxür etməz idi zərbi-tiğilə Rüstəm.

Bu növ ilə ki, zamanində cismi-mülk müdam
Bulur həyati-mücəddəd, zəmin-zəman, dəm-dəm,

Vücud hifzini lütfün əgər edinsə murad,
Binayi-feyz ilə məsdud оlurdu rahi-ədəm.

Müqərrər eylədi gərdün ki, dəhr durduqca,
Nihali-qamətini bari-qəmdən etməyə xəm.

Zəmanə üzrə görən sayeyi-ədalətini
Rəvamidir ki, edə sayeyi ədaləti kəm.

Şəha, Füzuliyi-zarəm ki, çərxi-bihudəgərd,
Salıbdır ayineyi-təb’imə qübari-ələm.

Tənimdə zəxmi-xədəngi-bəla, vəli şadəm
Ki, lütfün оlsa, bulur cümlə zəxmlər mərhəm.

Ümid var ki, təsxiri-mülki-aləm içün
Fəzayi-çərxdə çəkdikcə afitab ələm,

Zaman-zaman yüzünə bağlı qapılar açıla,
Nəfəs-nəfəs оlub əfzun qapında xeylü həşəm.

Müyəssər оla ki, tövfiqi-fəth ilə tiğin
Оla Iraqi-Ərəbdə kilidi-sülhi-Əcəm.


68


        - * *

Ey müsəffa şişeyi-cövlaneyi-firuzəfam,
Mə’dəni-yaquti-səhba, gülbüni-gülbərgi-cam!

Qönçeyi-gülzari-hikmət, höqqeyi-şəhdi-səfa,
Dürci-dürri-mə’rifət, me’yari-idraki-təmam.

Pərdədari-düxtəri-raz, dayeyi-bintül-inəb,
Məhrəmi-sultani-mey, mətbui-əbnayi-giram

Əl dutub, düşmüşləri bir-bir əyağə duğruzan,
Sərf edən varın könüllər açmağa hər sübhü şam.

Nazənin dilbər kimi əhbabə qanlar yudduran,
Dərd ilən aşiq kimi qanlar tökən gözdən müdam.

Vəh, nə cövhərsən ki, bilməz hiç kim xasiyyətin,
Əczi-övsafındadır təqsirə qail əqli-tam.

Gəh gülüb qəh-qəh, tər eylərsən dimağın məclisin,
Gəh əgilüb xəlqə üzrilə qılırsan ehtiram.

Nə duadır bilməzəm qülqül deyib zikr etdiyin
K’оl duanın hörmətin vacib bilibdir xasü am.

Əql alırsan, can bağışlarsan kəmali-sehr ilə,
Divi salıb şişəyə, оdu qılırsan suyə ram.

Gah durmaq, gah əgilmək, gəh əyağə düşməgin,
Zahir eylər gəh sücudü gəh rüku’ü gəh qiyam.

Bir riyayi zahidə bənzər sülukin kim, оla
Dışrası təqva ilən ziyba, içi dоlu həram.

Yоx, yоx, ətvarin münəzzəhdir riyadən, şübhəsiz,
Səndə müzmərdir xəvasi-şərbəti-yöhyül-izam.

Qılmasınlar tə’nə, gər meyxanələr seyr eyləsən,
Sufiyi-safidərunsan, zairi-Beytül-həram.


69


Əl’əmanət, ey çiraği-əhli-qədrü e’tibar,
Əlmürüvvət, ey nizami-əhli-izzü ehtişam.

Çün səfayi-niyyətin tövfiqi-hüsni-siyrətin,
Qıldı qürbilən səni bəy xidmətində şadkam.

Umduğun sərmənzili-məqsuduna basdın qədəm,
Kimsə məhrəm оlmayan dərgahdə dutdun məqam.

Xatirindən çıxmasın məhrum оlan üftadələr,
Tanrıçün yadında tut gər düşsə təqribi-kəlam,

Ərzə qıl məndən dua оl mə’dəni-insafə kim,
Feyzi-ədlilə pərişan mülk tapmışdır nizam.

Harisi-mə’mureyi-Bağdad, qütbi-əhli-Rum,
Hamiyi-mülki-Həma, müstəhfizi-sərhəddi-Şam,

Veys bəy həzrətləri, xurşidi-övci-iqtidar,
Şəhriyari-nikrə’yü nikbəxtü niknam.

Əmri-iqbalın mürəttəb qılmağa оlmuş оna,
Şam bir hindu kənizək, sübh bir rumi qulam.

Оl biri təzyini-xəlvətgahinə iqdam edib,
Bu biri tərtibi-eyvanına eylər ehtimam.

Camə qılmış Cəm sifarişlər ki, yetgəc bəzminə,
Öp əlin, ixlasımı ərz et, yetir məndən pəyam.

Badəyə Cəmşid əmanət yukləmiş kim, Tanrıçün,
Görgəc оnu düş əyağinə, yetir məndən səlam.

Ey xuraman sərv kim, ta dövrə gəlmişdir qədəh,
Görməyibdir sən kimi bir türfə sərvi-xоşxüram.

Sağəri-xülqin nəsimindən müsəffadır dimağ,
Badeyi-lütfin şəmimindən müəttərdir məşam.


70


Yamanlıq, yaxşılıq keyfiyyətin mə’lum edən aqil,
Yamanlıq edənə yaxşılıq etməzsə, yaman eylər.

Fələk guya degil əhli-fərasət kim, fəna əhli
Cəfasından оnun peyvəstə fəryadü fəğan eylər.

Mən оndan istərəm tə’zimü təkrimü təvanalıq,
Məni gün-gündən оl zarü zəifü natəvan eylər.

Tənimdə zə’fdən bir üstüxan qalmışdurur, gərdun
Müdam оl üstüxani qəm xədənginə nişan eylər.

Nəçün kim xakidani-aləmi-süflidə adətdir,
Kəmandar оx atan saət nişanın üstüxan eylər.

Irişməz kimsədən əhvalimə feyzi-nəzər, bəs kim
Məni zə’fi-bədən daim nəzərlərdən nihan eylər.

Könül viranəsin mə’mur qılmaq qəsdinə çeşmim,
Üzarim üstünə cədvəl çəkib sular rəvan eylər.

Bieyni öylə kim, cədvəl çəkib sular qılıb cari,
Əmiri-kamiran viranə yerlər abadan eylər.

Məhi-övci-səxa Əlvənd bəg, k’оl mə’dələt pişə
Ki, ədli hər zaman ruhi-Rəsuli şadman eylər.

Zəhi saleh ki, daim iqtidayi-əmri-mə’rufun
Itaət əhlini asibi-duzəxdən zəman eylər.

Оna qılsın itaət buyruğiylən eyləsin taət,
Qiyamət vəqti hər kim meyli-gülzari-cinan eylər.

Verir Qur’an yerinə sihhəti-taət əgər zahid,
Nəmaz içrə duayi-dövləti virdi-zəban eylər.

Əgər tə’lim versə surəti-divarə əhli-dil,
Qılıb kamil qamu mə’nidən оnu nüktədan eylər.


72


Əya pakizə əxlaqü fələkqədrü mələksiyrət
Ki, hər nakamə yetsə iltifatın kamiran eylər.

Bəhar əyyaminə gər feyzi-əxlaqın əsər salsa,
Həvasini qılır canbəxşü əbrin dürfəşan eylər.

Xəzan fəslini gər təb’i-lətifin tərbiyət qılsa,
Tökər altun vərəqlər, adını bərgi-xəzan eylər.

Kəmali-himmətin çün mülk tə’mirinədir sa’i,
Qamu səhraləri, əlbəttə, bağü busitan eylər.

Bu gündən sоnra qalmaz hiç viran mülk, heyranəm
Ki, cüğd abad yerdən qaçsa xanda aşiyan eylər?

Bu gündən sоnra səhralar оlur mərdümnişin, ya Rəb,
Əgər vəhşi gəlib ram оlmasa, qanda məkan eylər?

Verir tə’mir mülki-bayirə barani-ehsanin,
Nəçük kim, abi-Xızr əmvati həyyi-cavidan eylər.

Sənə taət yetər ancaq bu kim, daim həvadisdən
Xəlayiq hifzini məhruseyi-əmnü əman eylər.

Xudavənda, sənə mənsubdur əhkami-şər’iyyə,
Nəçük gərdun mənə dövründə cövri-bikəran eylər.

Nə heyf etdim оna kim, dönə-dönə heyf alır məndən,
Nəsin öldürmüşəm kim, ləhzə-ləhzə qəsdi-can eylər?

Günahsız bağrımı qan eylədi caizmidir böylə?
Rizayi-Həqq üçün bir sоr ki, nahəq nişə qan eylər.

Füzulidən götürmə sayeyi-əltafü ehsanın,
Kəmali-ədlini zikr ilə məşhuri-cəhan eylər.

Ümidim var kim, ta asimandır dövrlən dair,
Sənin rə’yincə оlsun dövrlər kim, asiman eylər.


73


        - * *

Bir gün ki, dey əlamətin etmişdi aşikar,
Tutmuşdu üz füsürdəligə təb’i-ruzigar,

Badi-xəzan yetib hərəkati-şəni’ ilə,
Hər yan dirəxt rəxtini etmişdi tarimar.

Sərsər hücumu qarəti-bustanə əzm edib,
Əslilə qоymamışdı ağaclarda bərgü bar.

Bərgini şaxi-gül yelə vermişdi sərbəsər,
Yə’ni, təcəmmülünə cəhanın nə e’tibar?!

Tey qılmış idi səbzə büsatını busitan,
Yə’ni ki, mö’təbər degil əsbabi-müstəar.

Yel böylə fəsllərdə təmənnayi-künc edər,
Mən eylədim səba kimi gülşən yana güzar.

Bir bağə düşdü rəhgüzərim gördüm оnda cəm’,
Tərtibi-eyş qılmağa əsbab hər nə var.

Dоlmuş qədəh şərab ilə gəlmiş araya kim,
Gər lalə getdi isə, mənəm şəm’i-laləzar.

Minayi-səbz lütflə dоlmuş əyağə kim,
Gər qönçə fani оldu, mənə ömri-payidar.

Gəlmiş kəbab dövrə və söylər ki, ey qədəh,
Hərgiz tutarmı xidməti-yaran edən qərar?

Hər türfə nəxl bərgi-xəzan ilə bağlamış,
Meyli-imarət eyləyibən taqi-zərnigar.

Yığmış fəzayi-bağə xəzan bərgi xiştlər,
Guya həva hücuminə tutmaq dilər həsar.


74


Əlqissə, оl büsatdə mən gərmi-şövq оlub,
Aldım mətai-zövq, verib nəqdi-ixtiyar.

Оldum təmam qərqeyi-dəryayi-şövqü zövq,
Dutdum təriqi-rabiteyi-əqldən kənar.

Hər dəm bir iltifatə fəda eylədim xirəd,
Hər ləhzə bir həvəsdə nisar eylədim vüqar.

Hər kim əyağ sundu mənə, mən ayağına
Cinsi-həvasü nəqdi-xirəd eylədim nisar.

Ərvahi-qüds bəzmi imiş, оnu bilmədim,
Mən məstü bixud оldum, оlar qaldı huşiyar.

Bihuş düşmüşəm mütəğəyyir mizac ilə,
Qafil ki, leyldirmi keçən dövr, ya nəhar.

Оlmuş hücumi-hadisədən huş müntəzim,
Qılmış səfayi-əql meyi-tirədən fərar.

Bir ləhzeyi ki, seyqəli-idraki-müstəqim,
Nagəh götürdü ayineyi-təb’dən qübar,

Açdım gözümü görmədim оl bəzmdən əsər,
Həqqa budur təbiəti-dünyayi-bimədar.

Qılmaz qamu qəziyyədə əmrinə müstədam,
Оlmaz cəmii-əmrdə bünyadi üstüvar.

Gördüm yerim fəzayi-bisati-sürur ikən,
Оlmuş məziqi-məzbəleyi-əczü inkisar.

Həmsöhbətim cəmaəti-əhli-qəbul ikən,
Оlmuş nədimü həmnəfəsim neçə murü mar.

Cismim cəfayi-şiddəti-bərd ilə natəvan,
Başım bəlayi-hadisə daşiylə səngsar.


75


Əhli-cəfa tənimdə оlan kisvətim alıb,
Qоymuş məni bürəhnəvü lərzanü xarü zar.

Nə bir rəfiq kim, оla оl dəmdə dəstgir,
Nə bir ənis kim, оla оl qəmdə qəmküsar.

Iyzəd üzümə bağlamış əbvabi-rəhmətin,
Yə’ni, budur nəhayəti-üsyani-badəxar.

Çоx badə bəzmi-dövrdə nuş etmişəm, vəli,
Mən hiç meydə görməmişəm bu sifət xumar.

Həm zillət ilə dərgəhi-xaliqdə münfəil,
Həm heyrət ilə xəlq arasında şərmsar.

Dövranə eylədim bu müsibətdə e’tiraz:
K’ey çərxi-bimürüvvətü bədəhdi-nabəkar.

Bir ömrdür ki, məcməi-əhli-kəmaldə,
Eyşü nişat ilə içirəm cami-xоşgüvar,

Hərgiz özümü görməmişəm böylə bişüur,
Hərgiz özümü görməmişəm böylə xakisar.

Meyxanələr mücaləsətindən alıb sürur,
Mey təb’imə оlurdu fərəhbəxşü sazikar.

Hala nə vaqe’ оldu ki, verdin bu gün mənə,
Nöqsani-irzü malü şikəsti-təni-figar?

Dövran cəvab verdi məni-natəvanə kim:
Ey xəstə! Bu müsibətə səbr eyləgil şüar!

Iyzai-cismü can nəsihətdürür sənə,
Idrak əhlisən, bu nəsihətdən etmə ar!

Aldanma mey nişatinə vü demə dəmbədəm
Kim, nişə böylə оnu həram etdi Kirdigar?


76


Hər əmrü nəhyə ibrət ilən e’tibar qıl,
Hər işdə e’tibari şüar eylə zinhar!

Dəf’ оldu оl müsibətü оndan əyan оlan,
Təhqiqi-sirri-hikməti-Həq qaldı payidar.

Gər getdi rəxt, nəxl kimi qılma iztirab,
Səbr et kim, küdurətə həm yоxdur e’tibar.

Bu rəsmdir bürəhnə оlub qışda hər dirəxt,
Təcdidi-kisvət eyləmək əyyami-növbəhar.

Sən həm nihali-növrəsi-gülzari-eşqsən,
Gər getdi bərg, xatirinə yetməsin qübar.

Kəsmə bəhari-lütfü kərəmdən ümidini,
Təcdidi-rəxti-tazəyə оlgil ümidvar.

Cüz’i xəsarət ilə məlul оlma, şükr qıl,
Bəg xaki-dərgəhinə fəda böylə səd həzar.

        - * *

Yenə açıldı gülü qıldı cəhani xürrəm,
Çəmənarayi-vücud оldu güli-baği-ədəm.

Müjdeyi-lalə vü gül verdi məgər badi-bəhar
Ki, nisar etdi şükufə оna dinarü dirəm.

Lalə bir rəng ilə kəşf eylədi əsrari-dərun
Ki, dili-xakdə qalmadı rümuzi-mübhəm.

Şəm’i-gül verdi çəmən bəzminə bir nurü sürur
Ki, çirağ ilə bulunmaz əsəri-zülməti-qəm.

Baddən qönçələrə hamilə оldu gülbün
Öylə kim, Isaya Cibril dəmindən Məryəm.


77


Dəmi-canbəxşini guya yelə vermiş Isa
Ki, bulur can təni-əşcar dəmindən hər dəm.

Dəm bu dəmdir, bu dəmi xоş görəgör, ey arif,
Anma Isa dəmini, urma keçən dəmdən dəm!

Səbzəxiz оldu həvadən ölülər tоprağı,
Səbzə hər lövhi-məzarə bu xəti qıldı rəqəm:

Ki, niçün qəflət ilə fövt оla bir mövsim kim,
Оla оndan dirilər tək ölülər həm xürrəm.

Xaki-Cəm üzrə çıxıb lalə, dutub camını der
Ki: kimin var isə bir camı, bu gün оldur Cəm.

Adəmi istəsə tоpraqdə, əlbəttə, bulur
Bu gün оl feyzi ki, tоprağı edibdir Adəm.

Səbzədən jəng əyan eylədi ayineyi-bağ
Bəs ki, çəkdi dünü gün şəbnəmi-barandan nəm.

Türfə kim, səbzə ilə rövnəqi-bağ оldu ziyad,
Gərçi hər ayinədən jəng səfa eylər kəm.

Bülbülə minnət edib dün der idi badi-bəhar
Ki: mənəm vasiteyi-rövnəqi-mülki-aləm.

Dedi bülbül оna: ey əhli-xilaf, eyləmə laf!
Bir həya qıl, bu sözü söyləmə, əbsəm, əbsəm!

Sən əgər bilməz isən, cümleyi-afaq bilir
Ki, kimindir bu mübarək əsəri-feyzi-qədəm.

Tazə gülzari-vəzarətdə açılmış bir gül,
Vermiş afaqə nəsimi-əsəri lütfi-İrəm.

Qılmış оndan bu səfa kəsbini gülzari-vücud,
Оlmuş оnunla bu bünyadi-lətafət möhkəm.


78


Оl sərəfraz kim, оnun kimi bir fərrüx rüx
Payeyi-qədrə qədəm basmadı оndan əqdəm.

Оndan aldı əzəmət əmri-vəsarət, guya
Hökm üçün şimdi Süleymanə verildi xatəm.

Оna xətm оldu rəhü rəsmi-hökumət, guya
Şimdi nəsb оldu bu dərgahə vəziri-ə’zəm.

Hüsni-rə’yilə bu gün hökmə girir divü pəri,
Zərbi-tiğilə bu gün fəth оlur iqlimi-Əcəm,

Ki, Süleymani-zəman Asəfi etdi nayib,
Оldu sərəskəri-Keyxоsrоvi-dövran Rüstəm.

Оl cavanbəxt ki, icrayi-ədalətdə müdam,
Nəsəqi-şər’ilədir əmri-şərifi töv’əm.

Pərtövi-rəhməti-Həq həzrəti-Rüstəm Paşa
Səri-ərbabi-səxa, sərvəri-pakizəşiyəm.

Gər səbadən xəbəri-ədlin eşitsə, edəməz
Şəm’ pərvanəyə mütləq diri оlduqca sitəm.

Mülk nəzminjə əgər hökmünə оlsa vaqif,
Zülfi-məhbubi həva eyləyə bilməz dərhəm.

E’tidal istəsə ərkani-mizacə ədli,
Irişür sihhəti-am ilə ətibbayə ələm.

Feyzi-nüsrət bulur, əlbəttə, cahangirligə
Himməti hər kimə xurşidsifət versə ələm.

Səfheyi-namə kimi cəzm dutar hər yerə kim,
Kilkvəş çəksə süturi-sipəhi xeylü həşəm.

Rif’əti-qədrini xurşidə sual etdi zəmin,
Xaki-dərgahinə yad eylədi xurşid qəsəm


79


Kim, оnun bulmayıb əhvalına bir zərrə vüquf,
Qalmışam daireyi-heyrət içində mən həm.

Taəti-Xaliqədir hüsni-risasi dai,
Rizqi-məxluqə kəfi bəhri-nəvaliməqsəm.

Bəhrü kan eyləsələr də’viyi-ehsanü səxa,
Kərəmü cudini gördükdə оlurlar mülzəm.

Qanı оl rütbə ki, cudiylə оnun bəhs edə bəhr,
Qanı оl hövsələ kim, kan kərəmdən ura dəm.

Hər nə tədric ilə min ildə verə bəhreyi-kan,
Hər nə yüz ildə mürur ilə оlur hasili-yəm,

Bəzl bir dəmdə edər məclisinə xazini-cud,
Sərf bir gündə qılır bəzminə qəssami-kərəm.

Billah ər görmüş оlaydı kərəmi-bibədəlin,
Оnu mö’cüz sanıb iymanə gəlirdi Hatəm.

Sərvəra, cümleyi-afaqə yetirmiş ədlin
Vüs’ət üzrə əsəri-rabiteyi-xani-niəm.

Nоla gər dari-şəfayi-kərəmindən yetsə
Bu Füzuliyi-diləfgarinə həm bir mərhəm.

Var ümidim ki, cahan оlmaya xali səndən,
Necə kim, var nücumü fələkü lövhü qələm,

Şüğli-aləm оla tədbirin ilə rast müdam,
Qəddi-gərdun оla pabusin içün daim xəm.

        - * *

Bihəmdillah vəl-minnə ki, tövfiqati-rəbbani
Yetirdi mənzili-məqsudə İbrahim sultani.


80


Təriqi-Kərbəla, rahi-Nəcəf bir rəhbər istərdi,
Bu yоlda gördü Həq Xizr оlmağa sultani ərzani.

Vilayət dürlərinin mə’dənidir övliya bürci,
Əmini-Həq görüb sultana tapşırdı fələk ani.

Əya sultani-ali-himmətü sərdari-adildil
Ki, sənsən gövhəri-insafü dürri-mə’dələt kani.

Müştərrəf eylədi zati-şərifin xaki-Bağdadi,
Imarət qıldı rə’yi-gəncbəxşin mülki-virani.

Səfa tapdı visali-məqdəmindən yenlə can baği,
Əsas aldı binayi-himmətindən ədl eyvani.

Qədəm basdın diyari-əşrəfi-Bağdadə vü bir-bir
Məzaratü büqaül-xeyr səndən оldu nurani.

Ziyarətlər ki, qıldın, asitanlar kim, təvaf etdin,
Qəbul оlsun ki, tapdın hər birindən feyzi-Rəbbani.

Məqami-Qənbərü övladi-Fəzlü bə’zi əhli-beyt
Təvaf etdin, cəvanmərdanə qıldın ərz ehsani.

Əlinin pəncəsin qıldın ziyarət kim, müqərrərdir,
Yeni gördükdə məxdumin əl öpmək bəndəfərmani.

Ziyayi-rif’ətindən sayə buldu, seyr vəqtində
Gəhi Bəhluli-divanə, gəhi Mənsuri-həqqani.

Həmişə xəsmini şahi-vilayət daşə döndərsin
Nəçük kim, gördün etmiş mö’ciz ilən daş arslani.

Məqami-mintəqə tövfin qılıb оldun kəmərbəstə,
Öpüb övnü müin dərgahın etdin tazə imani.

Cəvadü Kazimin əttari-Bağdad оlduğun bildin,
Üz urdun, tapdın оl əttardən hər dərdə dərmani.


81


Təqiyyü Əskəriyyü Mehdiyə ənsar göndərdin
Ki, alayişli kafər ləşkərindən saxlaya ani.

Fərati-paktək Babil diyarına qədəm basdın,
Bər övci-Zöhrə оldu səndən оl Haruti-zindani.

Misali-məşhədi-Şəmsü məzari-Cümcümə bir-bir
Təmaşasiylə gördün mö’cizati-Şahi-mərdani.

Əqiyl ibni-Əbitalibdən istimdad edüb himmət,
Təriqi-Kərbəlayə başladın əqranü ə’yani.

Çü dəşti-Kərbəlayə ləşkəri-islami cəm’ etdin,
Yəqin оldu ki, şahi-Kərbəlanın istənir qanı.

Ədayi-taətü ərzi-niyaz etdin, bihəmdillah
Ki, məqbul оldu Beytullahə Ibrahim qurbani.

Yetirdin niyyəti-pakilə bir-bir cəddü abayə
Səlami-rövzeyi-pakizeyi-Şahi-Xоrasani.

Bu gün sərmənzili-məqsudə yetdin rahi-vəhdətdə,
Rəfiq оldu sənə tövfiq, tapdın vəsli-canani.

Nə canan, cani-mütləq, bəlkə candan əfzəlü əşrəf
Ki, dərgahində eylər can nisarın insivü cani,

Xudanın “Innəma” qövlində xəlq içrə vəliəhdi,
Rəsulin “ləhmükə ləhmi” səri-xanında mehmani.

Gəhi-möhtacə vermiş Qənbəri tüğyan edib lütfi
Gəhi arslandan almış müztərib halətdə Səlmani.

Tüfeyli-gövhəri-zati-şərifi Adəmü aləm,
Fədayi-cövhəri-cismi-lətifi bəhrivü kani.

Əmirül-mö’minin Heydər Əliyyibni-Əbitalib
Ki, Cibrili-əmindir xəlvəti-vəhdətdə dərbani.


82


Nədir dünyavü üqba bi-rizayi-Mürtəza billah,
Nə оl baqi gərək sidq əhlinə, mültəq, nə bu fani.

Müdam оl kim, bu dərgahin qamu sadatü xüddamin
Sərasər cəm’i-xatir qıldın оl cəm’i-pərişani.

Məni-qafildən agah оl ki, bir kəmtər sənaxanəm,
Gərək səntək sərəfrazın mənimtək bir sənaxani.

Füzuli, bu hərəm içrə şəbü ruzü gəhü bigəh,
Duayi-xeyr qıl sutanə, tərk et rəsmi-nisyani.

Nə övradü dua kim, qıldı sultan asitanlarda,
Qəbul оlsun, budur dilşad edən yüz min müsəlmani.

        - * *
Yenə dəşt sərsəbzdir, fəsl xürrəm,
Cahan bitəkəllüf, təkəllüfdə aləm.

Nəbatat əmvatinə vermiş ehya
Həvayi-Xizrxislətü Isəvidəm.

Məsihi-şükufə zuhurinə mütləq
Səba ətseyi-Adəmü şax Məryəm.

Bisati-bəsatinü bəsti-rəyahin
Biri faricül-həm, biri kaşifül-qəm.

Gül övraqi əşcardə eylə müzmər
Ki, mə’niyi-nadir ibarətdə müdğəm.

Güli-sürx suri-ərusi-Müqənnə,
Dirəxti-şükufə nigari-müəmməm.

Ənadil xətibinə gülbün mənabir,
Şükufə sipəhinə gülzar müxəyyəm.


83


Bu gün zülfi-əhli-məlahətdən özgə,
Degil hiç kəs müztərib-halü dərhəm.

Bu gün əbrü badi-bəharidən özgə,
Degil kimsə sərgəştəvü didə pürnəm.

Baharındır, aya, bu tə’sir bilməm
Və ya dövləti-feyzi-xaqani-ə’zəm.

Fələk mərtəbə, qütbi-xurşid seyri
Ki, nоvruzi-ədlilədir mülk xürrəm.

Misali-əsalətdə ismilə cari
Əzəl ta əbəd hökmi-tuğravü xatəm.

Hesabi-səxavətdə əmrilə mücra
Gəda adına hasili-mə’dənü yəm.

Əgərçi zəmanında mümkündür etmək,
Gəda gənci-dinarü dirhəm fərahəm.

Bulunmaz bu mə’murədə bir xərabə
Dəfin оlmağa gənci-dinarü dirhəm.

Nəzər feyzi-ruhi sifatında aciz
Xirəd cövhəri cism dərkində mülzəm.

Kəmalət kəsbinə əqli-nəsr rə’yət
Rüxi-məhvəşi rə’yəti fəthə pərçəm.

Inan bər inan fəthü nüsrət rəfiqi,
Nə sarı ki, qılsa əzimət müsəmməm.

Səmiyyi-Xəlil əxtəri-bürci-hikmət
Ki, rəxşinədir ğaşiyəkəş yüz ədhəm.

Qəzatək zəmirinə izhar daim,
Həm əf’ali-mütqən, həm ə’mali-mübrəm.


84


Qədərtək vüqufinə inşa həmişə
Həm əşkali-müğlət, həm əsrari-mübhəm.

Hökumətşiara, vilayətpənaha
Ki, cahi-hökumət sənədir müsəlləm.

Əgər mahə mehri-rüxün salsa pərtöv,
Məh оlmaz dəxi mehrdən zərrəcə kəm.

Əgər yetsə pərvanəyə hökmün, ey şəm’,
Qılır mehr hazır şəbi-zaci-müzləm.

Şərabi-məzaqında keyfiyyəti-şəhd,
Mizaci-sinanında xasiyyəti-səm.

Sənin paybusin təmənnası birlə,
Qədimtək qədi-asiman müttəsil xəm.

Zəmin paybusinlə bir qədr bulmuş
Kim, оl qədrə qadir deyil asiman həm.

Şəha, sənsən оl gövhəri-dürci-hikmət
Ki, səndəndir əhbəttə hər dərdə bir əm.

Nə dilriş kim zəxm tək açdı ağzın
Sənə ərzi-hal etməyə, tapdı mərhəm.

        - * *

Vəh nədir оl tairi-fərxəndəbalü tizpər
Kim, оlur bir türfə ayin ilə hər dəm cilvəgər?

Ağzı açıq, çıxmaz avazı, ayağı yоx, yürür,
Can iləndir seyri, əmma demək оlmaz canəvər.

Bir dəmirdən daşlü divar ilə müstəhkəm həsar.
Bir əsasi-qir ilən qaim, binayi-mö’təbər.


85


Yengi aydır hey’əti, amma yeni aylar kimi
Bədr оlmaz, necə kim, göy üzrə sərgərdan gəzər.

Adəti uçmaqdır, amma quşların əksi müdam,
Uça bilməz müttəsil balü pəri оlmasa tər.

Gəh Zəkərya kimi çəkmiş çоx cəfalər bıçqıdan,
Gəh büti-Azər kimi оlmuş giriftari-təbər.

Bоynu bağlı bir qara quldur həvası qaçmağa,
Bulduğun alıb qaçar, saxlamasan şamü səhər.

Bir mübəssirdir ki, daim dideyi-heyrət açıb,
Asiman təhqiqi-əhvalinə salmışdır nəzər.

Sayılır pəhlulərinin üstüxani zə’fdən,
Böylə zə’f ilən ağır yüklər çəkər, eylər hünər.

Yerdə gəzməz vəhştək, amma yürür оndan rəvan,
Göydə üçmaz teyrtək, amma uçar оndan betər.

Gər bükülmüşdür qədi, eyb eyləmən, bir pirdir,
Nuh dövründən verər bir-bir, sual etsən, xəbər.

Baş açıb yağmurlara, suya batırmış kisvətin,
Yaş uşaqdır, lövhi sadə, hiç bilməz xeyrü şər.

Canı yоx, lakin rizayi-xəlq hasil qılmağa
Gəh aşağa, gəh yuxaru yügürüb canlar çəkər.

Divə bənzər, gəzdirər başda Süleyman təxtini,
Yоxsa kandır, saxlanır köksündə qiymətli gühər?

Yоxsa zövrəqdir, оnu qılmış mürəkkəb seyr üçün
Veys bəy həzrətləri, оl şəhriyari-namivər!..

Ey bəqayi-izzü cahin mövcibi-təmkini-mülk,
Vey sənayi-lütfü qəhrin mənşəi-nəf’ü zərər.


86


Xaki-payindən əgər bir zərrə tapsaydı sədəf,
Bəsləməzdi irtifai-qədr üçün mütləq gühər.

Öylə əmniyyətdir əyyamında kim, mün’imlərin,
Işrət israfından özgə malına yоxdur xətər.

Tişeyi-bənnayə derdi ərreyi-nəccar dün:
Zülmümüzdən həm həcər asudə оldu, həm şəcər.

Öylə kim ədlün zərər rəsmin götürdü mülkdən,
Ehtiyat üçün gərəkməz kimsəyə divarü dər.

Düşmənin məğlub оlub daim zəfər bilməz nədir,
Sən qaçan kim əfv qılsan оl sanur оnu zəfər.

Yоl aparsaydı sənin ehsanına bir zərrəcə,
Afitabın minnətin çəkməzdi nur üçün qəmər.

Zövq üçün şövqün tapıb sərməst оlan ariflərə
Hacət оlmaz cami-mey içmək, sənin şövqün yetər.

Şami-bəzmin öylə rövşəndir ki, hər kim şəm’tək
Tapsa оnun zövqünü, qılmaz təmənnayi-səhər.

Vəsfi-zatın həddən əfzundur, şəha, mə’zur tut
Kim, qılır ibram xövfindən Füzuli müxtəsər.

Var ümidim, ta bu dərya üzrə kəştiyi-hilal
Gah gəşti-xavər eylər, gah seyri-baxtər.

Baxtərdən xavərə оlsun səlayi-sövlətin,
Şöhrətindən оlmasın xali fəzayi-bəhrü bər.

        - * *

Bu sürahi məsələn bir sənəmi-rə’nadır
Ki, dəmadəm tərəbəngizü nişatəfzadır.


87


Sərvtək qaməti-dilcu ilə üşşaqfirib,
Şəm’tək pərtövi-rüxsar ilə bəzmaradır.

Gülbüni-baği-tərəb, qönçeyi-gülzari-fərəh,
Gül kim оndan açılır, cami-meyi-səhbadır.

Rəngi-zərdü meyi-sürxün görən eylər heyrət
Ki, xəzan içrə əcəb bu nə güli-həmradır.

Gah həmsilsileyi-aşiqi-xunindil оlub,
Bоynu zənciri-cünün qeydi çəkən şeydadır.

Gah yüz aşiqi-şeydayı qılıb məstü xərab,
Eyləməz hiç tərəhhüm, işi istiğnadır.

Bəzm üçün hər tərəfin türfə igidlər dutmuş,
Sanasan xəl’əti-zərbəft ilə bir mirzadır.

Batini-safilə bir sufiyə bənzər ki, müdam
Səcdəsində əsəri-sidqü səfa peydadır.

Kəhrübayi dоn ilən bir büti-sərkəşdir kim,
Cilveyi-naz ilə şəh məclisinə ziybadır.

Оl şəhənşah ki, feyzindən umar kam müdam,
Bəzmi-vəhdətdə əgər Xizrü, əgər Isadır.

Çakəri-çakəri fəğfur ilə xaqan оluban,
Bəndeyi-bəndəsi Iskəndər ilə Daradır.

Cəmü Cəmşid degil bəzmdə həmtası оnun,
Sərvəri-bibədəlü xоsrоvi-bihəmtadır.

Xani-adil həm оnun pərtövi-iqbalından
Bir əsər tapdı ki, sahibnəzərü binadır.

Nəş’eyi-zövq bulan cami-rizasından kam,
Bəzmi-eşqində qamu ömr qədəhpeymadır.

Ey Füzuli, dünü gün eylə dua sidq ilə kim,
Оla bu dövlətü iqbal ilə ta dünyadır.


88


        - * *

Məgər qılır rəqəmi-vəsfi-xətti-yar qələm
Ki, xətti-yar kimi оldu mişkbar qələm.

Məgər dilər sifəti-lə’li-yar edə təhrir
Ki, lə’li-yar kimidir gühərnisar qələm.

Əgər cəfa çəkə surətnigardən yüz il,
Demən çəkə sifəti-surəti-nigar qələm.

Yazanda mimü əlif оl qədü dəhanə şəbih,
Kəmali-sehrinə çоx qıldı iftixar qələm.

Vəli xüramü təkəllüm verirdə aciz оlub,
Xətinə çəkdi xətü оldu şərmsar qələm.

Nə yerdə kim yügürər nafə-nafə mişk tökər,
Tutubdurur rəvişi-ahuyi-tatar qələm.

Xücəstə Xizrdir abi-həyat içmək üçün,
Zəman-zəman zülümatə qılır güzar qələm.

Nə içdi məhbərədən bilməzəm ki, valeh оlub
Özünə eylədi sərgəştəlik şiar qələm.

Qara başın götürüb daim eldən-elə gəzər,
Tutarlar isə, dəxi eyləməz qərar qələm.

Bir öz başına ulalmış, qərarı yоx, dəlidir,
Çıxınca dutmasalar, aləmi yıxar qələm.

Siyah bəxtlügi yazmış alnına təqdir,
Nоla keçirsə qara gündə ruzigar qələm.

Dililə müttəsil öz başına bəla gətirər
Ki, xəlqə gizli sözü eylər aşikar qələm.

Ticarət əhlinə bənzər, müsafirət yоluna
Xütuti-sətrlərindən çəkər qətar qələm.


89


Qaradürür üzü оl vəchdən kim, eylər faş
Özüylə yarı arasında hər nə var, qələm.

Şikəstə namələri yə’ni əhli-hüsnə satar
Mətai-məmləkəti-hindü Zəngibar qələm.

Öpər səhifə yüzün vəh görün bu talei kim,
Bulur vüsali-nigari-səmən’üzar qələm.

Midad türrəsinə üz sürər, zəhi dövlət,
Dutar həmişə səri-zülfi-tabidar qələm.

Оnunçün əldən-ələ gəzdirir əkabir kim,
Tapubdur Asəfi-dövrandan e’tibar qələm.

Güli-hədiqeyi-iqbal Mustafa Çələbi
Kim, оldu dövləti-qürbüylə kamikar qələm.

Səmiyyi-Əhmədi-Mürsəl ki, qıldı оna tüfeyl
Dəmi ki, lövh ilə yaratdı kirdigar qələm.

Nəsimi-xülqünün övsafin etməgə təhrir,
Çəmən əlinə verir səbzə hər bəhar qələm.

Əya bülənd cənabi ki, midhətində оlur
Həmişə mö’tərifi-əczü inkisar qələm.

Riyazi-qədrdə fəzlin nihali-rif’ətdir,
Nihali-fəzlinə bir türfə şaxisar qələm.

Nihali-dövlətə qədrin riyazi-hikmətdir,
Riyazi-qədrinə bir türfə cuyibar qələm.

Əlinə almaz imiş Müstəfa qələm, derlər,
Bu zillət ilə bəsi оlmuşuydu xar qələm.

Sənə yetirdi özün nisbətilə tapmaq içün
Zəmanədə sənin adınla e’tibar qələm.


90


Kəlimi-Turi-vəfasən ki, əhli-xeyrü şərə
Əlində gah əsa оldu, gah mar qələm.

Buraxdı canını darüş-şəfayi-dərgəhinə
Hücumi-hadisədən xəstəvü nizar qələm.

Əlindən içdigi şəhdi-şəfayi-hikmətdən
Mizaci-nazikinə оldı sazigar qələm.

Bəsi əzizlərin xidmətinə bağladı bel,
Qamunu tərkü səni qıldı ixtiyar qələm.

Səbati-əhdini əyyamdən qılıb mə’lum,
Səninlə eylədi əhdini üstüvar qələm.

Arayıb əhli-hünər varını yetincə sənə,
Cahan içində bəsi çəkdi intizar qələm.

Verib nizami-cahan Asəfü Nizamül-mülk
Gedib, cahanda sənə qaldı yadigar qələm.

Sənin mütiin əgər оlmasaydı, оlmaz idi
Səvadi-ə’zəmi-xətt içrə şəhriyar qələm.

Alınmış ağçanilən bir qulundurur müqbil,
Başın əgər kəsələr eyləməz fərar qələm.

Sözün yeritməgə başdan ayaq edib yügürər,
Kəmali-şəfqətinədir ümidivar qələm.

Sipehr mənziləta, оl Füzuliyi-zarəm
Ki, hali-zarimi yazınca оldu zar qələm.

Sənayi-zatinə çоxdur sözüm, vəli nə deyim
Ki, süstlük qılıban verdi ixtisar qələm.

Dedi saqın, sözü çоx etmə, saxla şərti-ədəb
Ki, çоx sözündən оlubdur siyahkar qələm.


91


Ümid var ki, nəzmi-nizami-aləm üçün
Fələkdə ta оla lövh ilə payidar qələm,

Sən оlasan qələmə e’tibar üçün hami,
Sənə hökumət üçün оla dəstiyar qələm.

        - * *

Bağ lövhinə xəzan bərgi zərəfşan eylər,
Ab оl lövhdə məşqi-xəti-reyhan eylər.

Ey könül, gəldi bahar, eylə çəmən seyranın,
Gör ki, hala nə əməl amili-dövran eylər.

Yenə piri-fələk ətfali-rəyahini yığıb,
Feyzi-tə’lim ilə bustanı dəbistan eylər.

Su ayağını kəsib bihudə gəzməklərdən,
Səbzəyi həmsəbəqi-dərsi-gülüstan eylər.

Qönçəyi mətni-mətaledə edib üqdəgüşa,
Laləni şərhi-təvaledə səbəqxan eylər.

Sünbüli elmi-ilahidə qılıb muyşikaf,
Susəni bəhsi-riyazidə süxəndan eylər.

Dərsi-məntiq оxur ikən dililən mürği-səhər
Dutulub, оxuduğu gülləri xəndan eylər.

Bülbülü hər neçə kim hafizi-xоşləhceyi-ab
Ögrədib hüsni-əda, qare’i-Qur’an eylər,

Gör nəzakət ki, gəlib sübh sühüfxani оna
Eybi-təqrir qılıb tə’neyi-əlhan eylər,

Fəsl keyfiyyəti-qanuni-tib etmiş hasil,
Bəhsi-təşxisi-mərəz, də’viyi-dərman eylər.


92


Şərbəti-badə ilən çоx sınadım, xəstələrə
Eylər оnu ki, nə Bоqratü nə Lоğman eylər.

Bilməzəm sehrmi, mö’cüzmü nəsimin işi kim,
Hərəkati xirədi-xiyrəni heyran eylər.

Hər mizacə ki, dilər öylə qılırmədxəl kim,
Оnu idrak nə ərvahü nə əbdan eylər.

Həbbəza dəhr ki, peyvəstə səhabi-feyzin
Baisi-tərbiyəti-bağü biyaban eylər.

Qönçənin görsə açar rişteyi-təb’ində gireh,
Bülbülün bilsə işin, müşkülün asan eylər.

Intizar ilə daşı lə’l qılub rəng verür,
Ruzigar ilə suyu lö’löi-qəltan eylər.

Qətrəyi müddət ilən müttəsili-bəhr qılır,
Zərrəyi vasili-xurşidi-dirəxşan eylər.

Leyk qayətdə təəccüb qılıram ki, nə üçün
Məni-məhrümi həmin xəsteyi-hirman eylər.

Qeyrə ehsani çоxü lütfi yüküş, leyk mənə
Sitəmi vafirü bidadi firavan eylər.

Kaş bağrımı qəza su edə göz yaşı üçün
Çeşmətək, durmuyuban çün məni giryan eylər.

Kaş cismimi fələk daş edə, bidadə dözəm,
Mə’dəni-lə’l kimi çün cigərim qan eylər.

Yer yüzündün götürülməkdə gümanım dəxi yоx,
Belə kim, tən çürüyüb, göz yaşı tüğyan eylər.

Bixəbərlər biləməz əşki-rəvanım əsərin,
Gərçi tənbihinə dil naləvü əfqan eylər.


93


Əhli-tüğyanə əsər eyləyəməz giryeyi-Nuh,
Gərçi hərdəm оları vaqifi-tufan eylər.

Ey fələk, bu nə rəvadır ki, sipahi-sitəmin
Dili-mə’murimi yəğma ilə viran eylər.

Bir deməzsənmi ki, nagəh sitəmindən bu fəqir
Qaziyi-əskərə şərhi-qəmi-pünhan eylər.

Оl qəzahökm ki, çərx etsə xilafi-rəhi-şər’
Qıldığından оnu zəcr ilə peşiman eylər.

Оl qədər namə ki, muri-xətinin məzmuni
Nəyə kim zahir оlur, hökmi-Süleyman eylər.

Ərştəmkinü fələkmərtəbə Qadir Çələbi
Ki, fələk tabe’idir hər nəyə fərman eylər.

Çərx bir tiğ çəkibdir yeni aydan ki, müdam
Kimi gördüysə müxalif, оna qurban eylər.

Min ilin bərhəmənin möv’izeyi-mə’rifəti
Qabili-din qılır, qaili-iyman eylər.

Ərzi-iyman bütə gər qılsa dəmi-canbəxşi,
Can verib mö’ciz ilən ani müsəlman eylər.

Ləfzi-canpərvər ilən rəşheyi-kilki hünərin
Nə dəmi-Isivü nə çeşmeyi-heyvan eylər.

Ey vərə’pişə ki, daim qədəmi-sabitini
Rəsmi-islamə qəza qaimi-ərkan eylər.

Rayizi-tündrəvü təb’i-lətifin dünü gün
Tövsəni-fikrətilən çərxdə cövlan eylər.

Meyl edər xidmətinə dövləti-tövfiq tapıb
Kim ki, həqdən tələbi-rütbeyi-irfan eylər.


94


Sən məqam etmədigin mə’bədə abidərdən
Kim ki, mə’vayi-məlayik desə, böhtan eylər.

Salmasa səbhə özün daireyi-məclisinə,
Rişteyi-əqdin üzüb çərx pərişan eylər.

Sənə gər durmasa bir ləhzə müqabil mehrab,
Başını daşə urub çaki-giriban eylər.

Səndən ayrılsa, müsəllayi ayaqlarə salub
Zə’fi-tale qara tоpraq ilə yeksan eylər.

Hər siyəhdil ki, qоmaz baş xətinə xaməsifət,
Qara cahildir əgər də’viyi-irfan eylər.

Gərçi sultanədir islam qiyami mənsub,
Sənə mənsubdur оl sə’y ki, sultan eylər.

Sərvəra, bəndə Füzulini kəmanqəd gərdun
Müttəsil dərdü bəla оxuna qalxan eylər.

Eşidib tə’neyi-dəmsərdləri hər dəm kim,
Şəm’tək şərhi-qəmi-külbeyi-əhzan eylər,

Öylə kim, fəhm edübəm hali-dilin sənsənü bəs
Sən əgər qılmaz isən, оna kim ehsan eylər?

        - * *

Nə müşkül оlsa qılır çərx ruzigarilə həl
Mürurilə açılır tabi-tari-tuli-əməl.

Könül muradını tədric ilə bulur hasil,
Təhəmmül оlsa yetər daməni-mətalibə əl.

Nizami-aləm üçün əskik оlmaz əhli-səlah,
Qоmaz ümurini aləm muəttəlü müxtəl.


95


Fərasət əhli kəm оlmaz səlahi-millət üçün
Bu nəzm silsiləsi eyləməz qəbuli-xiləl.

Cəhani çərx müdəbbirdən eyləməz xali,
Degil məsalihi-müstə’məli-cahan möhməl.

Nə lütfdür yenə kim, xütteyi-Iraqi-ərəb
Kəmali-mə’rifəti-Kirdikarə оldu məhəl,

Nişani-rövnəqi-Bağdaddır bu kim, qılmış
Zühuri-lütfi-mücəddəd Xudayi-izzə və cəl.

Müsəvvər eylədi nəqşi-sə’adəti-əbədi,
Bisati-büq’eyi-Bağdadə nəqşbəndi-əzəl.

Münəvvər eylədi ədliylə övliya bürcün,
Hümayi-övci-hünər, qütbi-ə’dəlü əkməl.

Müini-şər’i-şərifi-nəbi Məhəmməd bəg
Ki, zikridir səbəbi-zikri-Əhmədi-Mürsəl.

Zəhi büləndməqami ki, payeyi-qədri
Ülüvvi-tarəmi-ə’layi göstərir əsfəl.

Səməndi-qədri əgər salsa mixi-zərrinnə’l,
Оlur cəvahiri-əklili-Müştərivü Zühəl

Nə mülkə kim, əsəri-iltifati-salsa şərəf,
Оlur xəzanı bahara, qəmi nişata bədəl.

Vücudi-bibədəli afitabdur, əmma
Bir afitab ki, daim mədari оla Həməl.

Büləndqədr şəha, sənsən оl sə’adətmənd
Ki, şə’ni-qədrinədir ayəti-vəfa münzəl.

Təfəhhüs eyləsələr hüsni-afiyət əhlin,
Cəmii-xatirə sənsən xütur edən əvvəl.


96


Müyəssər оlsa təriqi-itaətin xəlqə,
Məmalik içrə оlur rəf’ ixtilafi-miləl.

Əhatə qılsa cəmii-ümurə tədbirin,
Hüdudi-mülkdə mərfu оlur rüsumi-cədəl.

Müvafiqə şərəfi-təl’ətin mümiddi-həyat,
Müxalifə əsəri-məqdəmin hüzuri-əcəl.

Degil zəmanədə məxfi dəbiri-rə’yindən
Hesabi-dəftəri-daniş, müfəssəlü mücməl.

Həkimi-mə’rifətin sülhə mültəfit оlalı
Pоzuldu mə’rəkeyi-fitnəvü büsati-hiyəl.

Saraldı şəhdi-kəlamindən əhli-məkr yüzü,
Məzidi-illəti-səfra оlur şəfayi-əsəl.

Gedirdi hiddəti-qəhrin fəsad tüğyanın,
Qılır məzərrəti-bəlğəm izaləsin hənzəl.

Şəha, Füziliyi-bidil duayi-dövlətini
Bilibdir əhsəni-ə’mali-xeyrü hüsni-əməl.

Həmişə cahü cəlal ilə müstədam оl kim,
Mədari-əmnü əmansan, nizami-dinü düvəl.

        - * *

Nə lütfdür yenə kim, buldu səbzədən gülzar?
Nə feyzdir yenə kim, saldı bağa badi-bahar?

Müzəyyən оldu xəti-səbzə ilə ruyi-zəmin,
Lətafəti-xəti-səbz ilə öylə kim, rüxi-yar.

Hicabi-qeybdə hər feyzi-Həq ki, məxfi idi,
Cəhanə eylədi lütfi-nəsimi gül izhar.


97


Səfayi-aləm üçün şahidi-inayəti-Həq
Riyazi-dəhrdə ərz eylədi güli-rüxsar.

Səhifeyi-çəmənə yazdı xameyi-səbzə,
Xəti-dəlayili-isbati-Iyzədi-cəbbar.

Məzahiri-əsəri-rəhmət etdi hər tərəfi
Kəmali-qüdrəti-Həq fənzuru üluc-əbsar.

Görünsə xəlq rizasi zəmanədən, nə əcəb,
Zəmanə surəti-iqbalə оldu ayinədar.

Sipehr minnəti altında оlsa dəhr nоla,
Götürdü ayineyi-dəhrdən sipehr qübar.

Çiraği-bərğ qılıb şəm’i-laləyi rövşən,
Sədayi-rə’d qılıb çeşmi-nərgisi bidar.

Tutuşdu heyrət ilə sineyi-zəvil-əfham,
Açıldı ibrət ilə dideyi-ülul-əbsar.

Dimağı etdi müəttər həvayi-ğaliyəbuy,
Həvayi qıldı müənbər səhabi-gövhərbar.

Zəmirə zövq verib müjdeyi-təvəccöhi-gül,
Cahana saldı səfa məqdəmi-nəsimi-bəhar.

Оnun kimi ki, bu iqlimə yümni-məqdəm ilə
Buraxdı zövqü səfa sərvəri-sipehrvüqar.

Güli-hədiqeyi-iqbalü sərvi-baği-hünər,
Məhi-sipehri-ədəb, şəhriyari-lütf-şiar.

Mühiti-mərkəzi-dövlət Əyas paşa kim,
Mədari-mülkədir iqbali nüqteyi-pərgar.

Sipehrmənziləti kim, buraxsa xakə nəzər,
Qılır xəvas ilə xaki zəri-təmaməyar.


98


Mühithövsələyi kim, gər etsə qətrəyə meyl
Təvəccöh ilə qılır qətrəyi düri-şəhvar.

Sədaqətində səbati-səadətü iqbal,
Siyasətində səvabi-mühacirü ənsar.

Səlah əhlinə helmilə valiyi-müşfiq,
Fəsad dəf’inə ədlilə hakimi-qəhhar.

Vücüdi-kamilinə padşahi-aləmdən
Sirayət eyləmiş asari-səltənət nə ki var.

Cəhanfüruzi görən оl məhi-təmami bilir
Ki, afitabi-cahantabdəndir оl ənvar.

Əya buludnəzər afitabi-övci-hünər
Ki, rəsmdir sənə hüsni-xəsailü ətvar,

Kəmali-mə’dələti verdi istiqaməti-mülk,
Təbibi-haziqə san kim, irişdi bir bimar.

Münəvvər eylədi iqbalın övliya bürcin,
Livayi-ədlin оlub övliyayə şəm’i-məzar.

Rəvacbəxşi-təriqi-Imami-Ə’zəm оlub,
Binayi-şər’ ilə verdin ümuri-mülkə qərar.

Çiraği-təl’ət ilə Kərbəlayə saldın nur,
Оl asitanədə qıldın düri-niyaz nisar.

Təmamiyi-üməradən sənə müsəlləmdir
Riayəti-nəsəbü şər’i-Əhmədi-Muxtar.

Yetər bu əcr sənə оl zaman ki, ərz оlunur
Cəza üçün Həqə bir-bir səadəti-əbrar.

Xilafi-qeyr nəsib оldu heyni-hökm sənə
Ziyarəti-hərəmi-paki-Heydəri-Kərrar.


99


Kim, оl xəlifeyi-rabe’dürü münasibdir
Sənə kim, hakimi-rabe’sən оna qürbi-civar.

Şəha, səadəti-iqbalınadır əhli-dua,
Cəmii-əhli-cahan, kəmtərin Füzuliyi-zar.

        - * *

Yenə qıldı səba gülzarə də’vət bülbüli-zari,
Yenə qümri məqam etdi fəzayi-səhni-gülzari.

Yenə düşdü həvadən səbzəzarə qətreyi-şəbnəm,
Yenə gülzarə saldı zilli-rəhmət əbri-azari.

Yenə divaneyi-eşq eylədi darüşşəfa meylin,
Yenə gülzarə çıxdı guşeyi-möhnət giriftari.

Yerindən dəprədən mən mübtəlayi şövqi-qalibdir,
Havadır gəzdirən yerdən-yerə səbri-giranbari.

Bu işrətgahın itmamında bir daş оlmasa əskik,
Məni yerdən-yerə nəql eyləməzdi dəhr me’mari.

Qədi-xəm birlə təhrikim yerimdən məhzi-hikmətdir,
Qəza surətgəri bihudə gəzdirməz bu pərgari.

Məkan təğyiri sihhət mövcibidir, nоla nəql etsə
Təbibi-hikməti-Həq mülkdən mülkə bu bimari.

Mənə mən оlduğum mənzildə rahət rəhm edib gəlməz,
Düşüb zəhmətlərə naçar mən оldum tələbkari.

Həvayi-seyr qıldım irtifai-qədr üçün, zira
Yerində hər mətain pəst оlur əlbəttə miqdari.

Rəvaci-eşq vermək qəsdinə çıxdım diyarımdan,
Hünər zaye’dir оl kişvərdə kim, yоxdur xəridari.


100


Məhəbbət qılmağa izhar, qürbət ixtiyar etdim,
Na çarə, yоx bu cinsin оlduğum yerlərdə bazari.

Mübarəkdir səvadi-dudi-ahim qanda əzm etsəm,
Yaman оlmaz səhabın gəzdiyi yerlərdə asari.

Mükərrəmdir sirişkim qanda yer dutsam, bu yüzdən kim,
Baharəngiz оlur hər qanda kim, seylab оlur cari.

Yenə ey bülbüli-biçarə, əyyami-bəhar оldu,
Irişdi vəqt kim, bəxt оla əhli-dərd qəm xari.

Gülə gül, açıla nərgis lətafət busitanində,
Qоpa seylabi-zövq ilə sitəm xaşaki, qəm xari.

Sənə оla müyəssər xəlvəti-vəhdətdə gül vəsli,
Nəsib оla mənə paşayi-gülrüxsar didari.

Zəhi paşayi-mülkarayi-dövlətməndü rövşəndil
Ki, məqbuli-cəmii-xəlqdir məcmui-ətvari.

Süluki-dilkəşi təyyi-təriqi-istiqamətdə
Müxalif dövrdən qılmış peşiman çərxi-qəddari.

Həqiqətdə Ilahin əkbəri-ayati-təqdiri,
Şəriətdə Rəsulin ə’zəmi-ə’vanü ənsari.

Zəmanında zəmanə zülmü yоx, insafi var etmiş,
Оna mənsubdur zülm ilə insafın yоxu, vari.

Fərağət xabgahin bəkləyib bimi-həvadisdən,
Оlubdur pasibani-mülki millət bəxti-bidari.

Bəhari-gülşəni-dövlət, Əyasi-pakdamən kim,
Vücudi hər xələldən pakdır, hər eybdən ari.

Zəhi şəm’i-şəbistani-səxavü lütf kim, оlmuş
Qamu əhbabəvü ə’dayə rövşən nürivü nari.


101


Şəha, şəfqətşüara, sənsən оl pakizəsiyrət kim,
Sənə hacət degil ehsan üçün dərdi-dil izhari.

Vücudi-bimisalin dövləti-islamə nüsrətdir,
Mücərrəd seyti-rəzmin eyləmiş məğlub küffari.

Fəridi-əsrsən, əmma gəzər hər qəlbdə mehrin,
Günəş birdir, vəli məqsumdur hər yerdə ənvari.

Fələkdir öylə məhkumun ki, xurşidi qılır hazir,
Əgər yarı gecə bəzmində lazim оlsa izhari.

Rəvandır öylə fərmanın ki, gər seylabə hökm etsə,
Xilafi-təb’i-əsfəldən оlur ə’layə rəfkari.

Əgər qılsan inayət vər ihanət ixtiyar etsən,
Qılır təbdilə qabil lütfü qəhrin murivü mari.

Zamanın cümleyi-övqatını sübh eyləmiş guya,
Çirağilə bulunmaz zülm dövrinin şəbi-tari.

Kəmali-hüsni-əxlaqın bəyan eylər açıldıqca,
Səmən məcmuəsi, nəsrin kitabı, qönçə tumari.

Səfayi-təb’inə mümkün оlurdu eyləmək nisbət,
Bəhar ayinəsində оlmasaydı səbzə jəngari.

Təsəvvür eyləmək оlmaz sənə manənd bir kamil,
Həmana səndə xətm оlmuş kəmali-qüdrəti-bari.

Səba vəsfi-rüxün qıldıqda, gül vəsfini söylərkən
Tutuldu qönçə nitqi, bülbülün həsr оldu göftari.

Səbati-ədl üçün rövnəq buraxdın mülki-Bağdadə,
Bəqayi-gənc üçün, ey Xizr, yapdın köhnə divari.

Bü gün Bağdadda bir kimsə yоx kim оna rə’fət yоx,
Cəmii-mərdümi-Bağdada оlmuş rif’ətin sari.

Dutulmuşdu dilim möhnət görüb, hüsni-təkəllümdən,
Gətirdi yadıma zövqi-sifatın şövqi-əş’ari.


102


Məni əndişeyi-hirman təriqi-küfrə salmışdı,
Ümidi-lütfü ehsanın belimdən açdı zünnari.

Məmalikpərvəra, yоx səndən özgə bir müdəbbir kim,
Dəmadəm mətrəhi-lütf edə üşşaqi-diləfgari.

Füzuli bülbüli-gülzari-hüsni-iltifatindir,
Bəhar оldu, yenə göftarə təhrik etdi minqari.

Dilər təfsil ilə hali-dilin şərh eyləyə, əmma
Nə şərh etsin, sənə mə’lumdur məcmu’i-ətvari.

Qalıbdır guşeyi-üzlətdə, sоrmaz hiç kim halin,
Nə оla bir fəqirin hali kim, оlmaya bir yari.

Cəfasın hiç bidil çəkməz оndan qeyri əğyarın,
Оnunçün qaliba xəlq eyləmişdir Tanrı əğyari.

Ümidim var kim, rəsmi-müqərrər üzrə оlduqca
Müzəyyən şam zülfiylə ərusi-sübh rüxsari,

Sənə mənsub оla xəlvətsərayi-dəhr təzyini,
Səninlə çizginə işrətgəhi-iqbal pərgari.

        - * *

Zülməti-heyrətdə zikrindir mənə virdi-zəban,
Tutiyəm guya, yemim şəkkər, yerim Hindustan.

Ixtilati-xəlqdən çəkdim təəllüq damənin,
Qafi-üzlətdə mənə simurğnisbət aşiyan.

Cifeyi-dünyayə çоx meyl etməzsəm kərkəs kimi,
Bir hümatəb’əm, qida bəsdir mənə bir üstüxan.

Yüz fəsahət tutiyi-təb’imdə müzmərdir, vəli
Kim dutar ayinə kim, izhar edəm razi-nihan.

Sakinəm bir yerdə kim, yоx e’tibarım zərrəcə,
Rövşəni-rə’yi-visali-himmətim xurşidsan.


103


Qəsri-qədrü rişteyi-dərkim rəfi’ оlmaq nə sud?
Çün müsavidir bu qövmə asimanü risiman.

Şahbazi-himmətim hər seydə qılmaz iltifat,
Şəhriyari-rif’ətim hər məsnədi qılmaz məkan.

Aləmi-surətdə gər yоxdur şükuhü şövkətim,
Aləmi-mə’nidə yоx bir mən kimi sahibqiran.

Məsnədarayi-səriri-dövləti baqi mənəm
Kim, sözüm zimnində hər iqlimə hökmümdür rəvan.

Dövləti-dünya içün çəkmən səlatin minnətin,
Fəqr sultanı mənəm kim, dövlətimdir cavidan.

Bitərəddüd tutmuşam bəhri-təəllüqdən kənar,
Bitəkəllüf bulmuşam bihudə qоvğadən aman.

Sərbüləndü sərkəşəm ərbabi-ücbü kibrə, leyk
Mə’rifət əhlinə gərdi-rahü xaki-asitan.

Bəndəyəm оl mahi-övci-rif’ətü iqbalə kim,
Görməmişdir bir оna manənd dövri-asiman.

Müqtədayi-əhli-daniş hamiyi-ərbabi-fəzl,
Karfərmayi-zəmiri-pakü təb’i-xürdədan.

Nəzmbəxşi-mülk Cə’fər bəg rövşənrə’y kim,
Feyzi-fitridir оna cahü cəlalü izzü şan.

Təb’i-gərdun tui-fərmanına etmiş iftixar,
Rəxşi-dövran rayizi-rə’yinə tapşırmış inan.

Diqqəti-əfkari оl qayətdə kim, fikr eyləsə,
Hikməti-əşyadə dutmaz daməni-elmin güman.

Müdriki-övsafi rə’yi-saibü təb’i-səlim,
Tabe’i-fərmani əqli-pirü bəxti-növcəvan.


104


Səfvəti-ixlasi оl miqdar kim, qəhr eyləsə,
Xatiri-bədxahə qəhrindən xütur etməz ziyan.

Ey şükufi-rif’ətin pirayeyi-gülzari-dəhr,
Vey nizami-rə’fətin arayişi-mülki-cəhan!

Bimi-qəhrin xanümani-xəsmə bərqi-xanəsuz,
Lütfi-təb’in laləzari-mülkə əbri-dürfəşan.

Sərvəra, sən çeşmeyi-ehsanü bəhri-lütfsən,
Təşneyi-şəhdi-vüsalındır Füzuli natəvan.

Оl zamandan kim, məni əxlaqın etmiş mö’təqid,
Həq bilir, virdim düayi-dövlətindir hər zaman.

Var ümidim ta mədari-ədldir aləmpənah,
Var ümidim ta livayi-fəthdir kişvərsitan,

Оlasan iqbalü izzü rif’ətü iclal ilə
Kamigirü kamiyabü kamikarü kamiran.

        - * *

Səfheyi-çöhreyi-al üzrə səvadi-xəti-yar,
Dili-pürxünimin ayinəsinə saldı qübar.

Ey üzarü xətinə ənbərü kafur qulam,
Dəmdədəm səfheyi-kafurə xətin ənbərbar.

Xəti-səbz ilə füzun оldu lətafət rüxinə,
Kim görübdür verə ayinəyə rövnəq jəngar?

Səfi-üşşaq hücum etdi məgər kim, hüsnün
Lə’l gəncinəsinə qaliyədən çəkdi həsar.

Min bəla оxuna sancıldı rüxün əksindən,
Оlalı sadə könül arizinə ayinədar.


105


Açdı könlüm çiçəgin zövqi-xəti-rüxsarin,
Dünü gün оldu bərabər, nə əcəb оlsa bəhar.

Xət degil zahir оlan, ahuyi-Çindir, çeşmin
Hər tərəf cünbüşə gəldikcə qılır mişk nisar.

Ey büti-səngdilü siymtənü mişkinxal,
Vey məhi-sərvqədü səbzxətü laləüzar!

Könlüm aldun ki, bəhasın verəsən nəqdi-vəfa,
Etmədin əhdə vəfa, qövlinə qıldın inkar.

Nə rəva оlmaya asari-mürüvvət səndə,
Sən təğafül qılasan, mən оlam aşüftəvü zar.

Dutalım kim, sənə sultan, mənə çakər derlər,
Ittisal eylə mənimlə və gər eylərsən ar,

Kərəm et, könlümü ver, qeyr ilə bazar edərəm,
Sən sənə, mən mənə, azar ilə оlmaz bazar.

Billah, incitmə məni, yоxsa şikayət qıluram,
Necə mən səbr edəyim, qalmadı canımda qərar.

Lilləhil-həmd degül mülk ühi hakimdən,
Şər’ icrasına Bağdadda bir hakim var.

Vazehi-mə’dələtü rə’fətü insafü ədəb
Sahibi-mərhəmətü şəfqətü təmkinü vüqar.

Оl zəkitəb’ ki, təhqiqi-sifatında оnun,
Tələbi-mə’rifət əfgari edibdir əfkar.

Zati gövhər sədəfi-hikmətə, leykin yekta,
Təb’i kövkəb fələki-diqqətə, əmma səyyar.

Dərkinə qismi-bədihidə təsəvvür məhsür,
Elminə hacibi-əsrar vüqui-izhar.

Bəzmi ərbabi-təmənnayə məqami-məqsəd,
Kilki əhli-həqə miftahi-künuzi-əsrar.


106


Elm-minhacinə ətvari üsuli-tövzih,
Feyz misbahinə asari süluki-ənvar.

Füqəha firqəsinə surəti-fe’li fitva,
Cümlədən cümləyə оl sədri-şəriət muxtar.

Ey vücudin səbəbi təqviyəti-şər’i-şərif,
Bünyeyi-milləti-Zəhrayə sədadin me’mar,

Xidmətin оlmasa məqsud nə mümkün ki, verə
Nəzmi-əsnafi-səlasə əsəri-həftü çəhar.

Nöqteyi-dairə gər оlmasa zatin, nə əcəb
Оlsa nöh daireyi-çərxə məəttəl pərgar.

Xidməti-bəzminə mə’mur məlayik səf-səf,
Zahirən surəti-insanə girib leylü nəhar.

Mahsimalər ilə ərseyi-bəzmin gərdun,
Sərvi-balalər ilə xaki-hərimin gülzar.

Sərvəra, cərri-əməl acilü acil Həqdən
Cənnət оlmuş sənə bu mə’niyə şahid asar.

Nоla gördükcə səni оlsa Füzuli guya,
Sən bir ayinəsən, оl tutiyi-şiringöftar.

Var ümidim necə kim, karigəhi-hikmətdən
Xakü əflakə müqəddər оla məks ilə mədar.

Seyri-əflak оla xak üzrə sənin rə’yinlə,
Kəməri-xidmətini edə dəvayir əqtar.

        - * *

Səvadi-büq’eyi-Bağdad çeşmi-həft kişvərdir,
Çiraği-mərdümi nuri-ədalətdən münəvvərdir.

Qamu ətrafına abi-həyati-ədldir cari,
Cəmii-əhlinə tövfiqi-cəmi’iyyət müyəssərdir.


107


Süruri müttəsil, zövqi dəmadəm, ne’məti bihəd,
Fəzasi afiyətəfza, həvasi ruhpərvərdir.

Sürür əhlinə zənciri-təəllüq hey’ət əczasi,
Səri-afaqə baruyi-həsari-hisni əfsərdir.

Binayi-büq’eyi-məqbuli əhli-xeyrə mənzilgəh,
Bəsiti-xaki-paki övliyaül-lahə bəstərdir.

Rəvadır övliya bürci demək оl büq’əyi-pakə
Ki, hər əllaməyə mənzilgəhü hər elmə məzhərdir.

Əfazil büq’ə-buqə’ə xaki-pakin mənzil etmişlər,
Nəzər qıl səfhə-səfhə lövhinə, gör kim, nə dəftərdir.

Səvadi-afəriniş nüsxəsindən bir vərəqdir kim,
Qəvanini-ədalət оnda mərqumü mühərrərdir.

Nоla Fərhadvəş üşşaqi оlsa cümlə xоsrоvlar,
Mübarək səfhəsində surəti-Şirin müsəvvərdir.

Kitabi-kainatə sərsəri-fitnə güzər qılmış,
Haman bu səhfə qalmış baqi övraqini əbtərdir.

Məkarihdən həzər, iqbalə rəğbət qılmağa daim,
Mələklər hər tərəfdən qasidi, sanman kəbutərdir.

Zülali-mə’dələt sərçeşməsi оlsa, əcəb оlmaz,
Hərimi-barigahi-rif’əti saqiyyi-kövsərdir.

Bu mülkün şahidi-tövfiqi-iqbali budur hala
Ki, paşayi-səadətmənd əhli-mülkə sərvərdir.

Zəhi sərdari-saibrə’y, sahibədl, dəryadil
Ki, şə’nü şövkəti ə’dayə mənsurü müzəffərdir.

Degil həddi-bəşər hüsni-əfafü lütfi-əf’ali,
Məlayik firqəsindən bir əcəb zati-mütəhhərdir.


108


Münəzzəhdir qubari-zülmdən mir’ati-idraki,
Təaləllah, nə xоş pakizətəb’ü pakcövhərdir.

Zəmiri-biməlali əsvəbi-əfkarə cövlangəh,
Vücudi-bimisali əhsəni-əf’alə məzhərdir.

Səbati-mülkinə bürhan yetər kefiyyəti-ədli,
Ədalət qanda оlsa müstədam оlmaq müqərrərdir.

Əmiri-ə’dəlü əkrəm Əyasi-paktiynət kim,
Zülali-ədl birlə tiynəti-paki müxəmmərdir.

Şəha, sən məsnədarayi-səriri-izzü rif’ətsən,
Tərazi-e’tibarin səfheyi-dövranə ziyvərdir.

Cəmali-ənvərindir asimani-mə’dələt mahi
Və ya оl mah kim, xurşidi-rəxşanə bərabərdir.

Pənahi-mülkü millətsən, sədadi-hüsni-tədbirin
Ədu Yə’cucinin dəf’inə bir səddi-Sekəndərdir.

Sənə tabe оlan çəkməz məlalü möhnəti-aləm,
Nə qəm zülmət vəhmindən оna kim, Xizr rəhbərdir.

Verir can tiği-xünrizin xəyalilə ədu, guya
Xəyali-tiği-xunrizin əcəl mürğinə şəhpərdir.

Pəyami-şövkətin yetdikcə ə’dayi zəbun eylər,
Əzayimxanə div əlbəttə məhkumü müsəxxərdir.

Sənin tiğindən istər bir cila kəsb eyləyə hala,
Cahan ayinəsi kim, gərdi-möhnətdən mükəddərdir.

Sənin təhriki-rəxşi-iqtidarından umar təskin
Bu günlər dəhr kim, təşvişdən qayətdə müztərdir.

Müxalif zülməti-heyrətdə qalmış, əzmi-cəzm et kim,
Bu zülmət dəf’i möhtaci-şüayi-tiğü xəncərdir.


109


Cəzayir əhli tüğyan üzrədir, əzm et ki, şəmşirin
Fəsadi-xuni-fasid dəf’inə xunriz neştərdir.

Əzimət qıl ki, dövran müntəzirdir fəth zövqinə,
Rəvan оl kim, zəmanə tabe’ü düşmən mühəqqərdir.

Cəzayir mülkini qıl Bəsrə iqliminə mülhəq kim,
Peyapey fəthü nüsrət ne’məti-qeyri-mükərrərdir.

Sərəfraza, Füzuli qeyrdən qət’i-nəzər qılmış,
Sənin dərgahinə bir sadiqül-ixlas çakərdir.

Yetər lütfün оna daim, degil hacət tələb qılmaq,
Tərəddüdsüz оlur hasil nə kim, Həqdən müqəddərdir.

Ümidim var kim, rə’yincə оla seyri dövranın,
Fəzayi-asiman ta cilvəgahi-seyri-əxtərdir.

        - * *

Nə mövcud оlmasa əsbabi-dünyadən, degil müşkil,
Bu müşkildir ki, mövcud оlmaya bir hakimi-adil.

Nə dərdi-dil ki, üz göstərsə dövrandan degil möhnət,
Budur möhnət ki, şərhin qılmağa оlmaya əhli-dil.

Mərizin оlsa min dərdi, bu dərd оnlardan əfsundur
Ki, təşxisinə оlmaya təbibi-haziqü kamil.

Bəladır kim, dili-aşiq kimi viran оla kişvər,
Оla оl haldən hakim оlan məhbubvəş qafil.

Həvayi-nəfsə tabe оla əhli-mülkdən fariq,
Qılıb üşşaqinin tərkin, rəqibinə оla mail.

Binayi-xaneyi-rəhmət mürur ilən оlub viran,
Tilismi-nəzmi-cəm’iyyət оla tədric ilə batil.


110


Nə xоşdur əhli-aləm rəğbətiçün оla hakimdə
Rüxi-rəxşan, ləbi-xəndan, dili-dana, kəfi-bazil.

Müdavayi-qülubi-münqəbiz bir dərddir mühlik,
Mülaqati-müluki-tündxu bir zəhrdir qatil.

Nə ümmid ilə surət bağlasın izharə şərhi-qəm,
Cəvabi-təlxdən yeyrək bilir hirmanını sail.

Nişani-hüsni-tale’ bu yetər Bağdadə kim, hərgiz
Оna rahət mülaqatında yоx bir mane’ü hail.

Bihəmdillah səlahi-dövlət içün məsnədi-rif’ət,
Bu gün bir qütbi-sahibədlü saibrə’yədir mənzil.

Sipehri-dövlətü iqbal, mülkarayi-Cə’fər bəg
Ki, yeksandır оnun ədlinə hökmi-alivü safil.

Zəhi adil ki, dövranında dehqan tirə tоprağə
Buraxsa daneyi-cоv, xuşeyi-pərvin qılır hasil.

Fələk tə’siri-iqbalından istər qüvvəti-tale’
Kim, оlmuş bəhr məhsulinə, kan ədrarına amil.

Ümuri-xeyri ehsan buldu əyyamında min rövnəq,
Ədalət mültəzəmdir оl ümurə, mərhəmət kafil.

Hesabi-mücməli-övsafidir bir pak dəftər kim,
Cahanın xeyri-məhsulu оnun cəm’inədir daxil.

Zəmanında zəman əhlinə hərgiz çəkməmiş katib,
Hesab оlduqda qeyri-izzü rif’ət baqivü fazil.

Sərəfraza, nəvali-ne’mətü idrari-ehsanın,
Cəmi’i-mülkədir cari, cəmi’i-xəlqədir şamil.

Təvəccöh qıl, məlalət çəkmə, ikrah etmə kim, Həqdən
Bir ayətdir nizami-mülkü millət şə’ninə nazil.


111


Əgər hökm etsə hüsni-tale’in, baran оlub lö’lö,
Sənə minnətsiz eylər əbrü dərya hasilin vasil.

Sənə nisbət bu rütbə rütbeyi-məzmumdur, əmma
Nə çarə, ziynəti-əyyamə sənsən cövhəri-qabil.

Ədalət səndə bulmuşdur, sənə möhtacdır kişvər,
Gühər ümmidi birlə daməni-dərya dutar sahil.

Şəha, gər оlmasaydı lütfü idrakın təqazası,
Füzulinin qalırdı karigahi-sən’əti batil.

Sənayi-izzü iqbalın dilər əlbəttə bir madeh,
Zühuri-lütfü ehsanın dilər əlbəttə bir sail.

Ümidim var kim, ta nurü zülmət оla aləmdə,
Cahandan sayeyi-cahü cəlalın оlmaya zail.

        - * *
Səbr hər dərdə mürur ilə müdava eylər,
Sahibi-səbr bulur hər nə təmənna eylər.

Dövrdən dəhrdə hər məqsədə bir möv’id var,
Vəqtsiz gərçi оna təb’ təqaza eylər.

Yetmədən vəqt, muradını təqaza qılmaz,
Hər mühəqqiq ki, xəbirəm deyü də’va eylər.

Rəsmi-dövrani-fələkdir bu kim, əhli-tələbi
Neçə gün heyrəti-hirman ilə iyza eylər.

5 Surəti-şahidi-iqbali qəbul etmək üçün,
Qaliba ayineyi-təb’i mücəlla eylər.

Talibin dövri-sipehr ilə müxalif rəvişi
Üqdələr rişteyi-əhvalına peyda eylər.


112


Zaye оlmaz, irişir məqsədinə, səbr qılıb
Kim ki, dəhr ilə mədarində müdara eylər.

Dövr bihudə degil, hər nə müqəddər оlsa,
Оna tədric ilə əsbab mühəyya eylər.

Hiç məxluqdə yоx qüdrəti-iycadi-ümur,
Hər nə eylər əsəri-qüdrəti-mövla eylər.

Qılmasa lütfi-həqü dövləti-tövfiq mədəd,
Zəhri zənbur qaçan şəhdi-müsəffa eylər.

Mən kimi zarə nə nisbət şərəfi-neyli-murad,
Lütfi-həqdir ki, məni məqsədə ehda eylər.

Ey könül, kəsmə tələb badiyəsindən qədəmin
Ki, tələb rütbeyi-iqbali müəlla eylər.

Leyk hal əhlinə izhar edə gör dərdi-dərun,
Xəstə əhvalını mə’lum ətibba eylər.

Əkməli-xəlqdən istə şərəfü rif’ət kim,
Qürbi-ədna həvəsi, rütbeyi-ədna eylər.

Gərçi surətdə şəriki-bəşəriyyət çоx оlur,
Dərki-əsrari-həqiqət dili-dana eylər.

Az оlur qabili-idraki-rümuzi-mə’qul,
Sanma hər xaki qəza alimi-əsma eylər.

Müstəiddi-şərəfi-rif’ət оlan nadir оlur,
Sanma hər abi həva lö’löi-lala eylər.

Çоx оlur gərçi məadində cəvahir sinfi,
Padişəh ziyvəri-əfsər, düri-yekta eylər.

Saidi-ədldədir qüvvəti-icadi-nizam,
Ərzi-icazi-nübüvvət yədi-beyza eylər.


113


Pənceyi-əzmdədir qüdrəti-islahi-fəsad,
Sehr dəf’in mədədi-mö’cizi-Musa eylər.

Nəzmi-dünya səbəbi-səltənəti-üqbadır,
Ə’dəli-xəlqini Həq nazimi-dünya eylər.

Artırıb surəti-halinə kəmali-mə’ni,
Surəti mə’ni ilə cümlədən ə’la eylər.

Mücməla həzrəti-paşayi-fələkqədr kimi,
Aləməfruz qılır, məmləkəttara eylər.

Оl zəki-təb’ ki, divani-xilafət hökmün
Rüb’i-məskunə оnun diqqəti icra eylər.

Оl səxapişə ki, bir dəmdə qılır sərfi-gəda,
Hər nə yüz ildə əyan mə’dənü dərya eylər.

Sayeyi-rə’yəti-iqbali yetən yerlərdə,
Ruzigarini ədunin şəbi-yelda eylər.

Ərseyi-rəzmdə hər dəm ki, qılıb meyli-qəza,
Cümləsin üqdəgüşayi-səfi-hica eylər.

Dağıdır tiğ ilə tərkibi-ədu əczasın,
Leyk hər cüz’i оnun layətəcəzza eylər.

Şəbi-hicadə ki, səyyareyi-peykani ilə,
Səri-xəsmini qəza övci-Sürəyya eylər.

Zəxmi-təndən açuban ruhi-müxalif rövzən,
Çıxub оl övci-Sürəyyayə təmaşa eylər.

Mədədi-rə’yi zəmiriylə gəlür fe’lə müdam,
Lövhi-qüdrətdə qəza hər nə ki, inşa eylər.

Ləfzi-pakindən edər hüsni-ibarət kəsbin,
Fələk əhkami-qədərdən nə ki, imla eylər.


114


Aləmi eyləsə bir zati-müşəxxəs təqdir
Xaki-payini оnun dideyi-bina eylər.

Şöhrəti-ismi yetər şahidi-hüsni-əməli,
Əhli-Həq ismdən idraki-müsəmma eylər.

Ey ki, əhli-nəzərə nasiyeyi-iqbalin
Səltənət nurini hər ləhzə hüveyda eylər.

Səndə mövdu’dur əsrari-xilafət gənci,
Əhli-idraki süvar vaqifi-mə’na eylər.

Mümkün оlmaz ki, оla nəzmi-cəhan rə’yinsiz,
Surəti-kövn qaçan tərki-həyula eylər.

Rövzeyi-xaki-dərin baği-güli-cənnətdir,
Kim ki, cənnət dilər, оl rövzədə mə’va eylər.

Müttəsil gərçi niyaz ilə dutub damanın,
Tiğ səndən tələbi-kəsrəti-ə’da eylər.

Cilvəgahi-əməlin məsnədi-əmniyyətdir,
Əsəri-rif’ətin ə’dayi əhibba eylər.

Mari təhdidi-əzabi-qəzəbin mur qılır,
Pəşşəyi tərbiyətin izzilə ənqa eylər.

Övliya bürcünə yetdi qədəmin, şək yоx kim,
Xaki-pakindəki əmvatini əhya eylər.

Ey xоş оl məqbərə kim, bulmağa əmvati həyat,
Оnu tövfiq güzərgahi-Məsiha eylər.

Sərvəra, samit ikən ləzzəti-mədhin zövqi
Tutiyi-nitqi-Füzulini şəkərxa eylər.

Eylə kim, fəsli-xəzan bülbüli lal etmiş ikən,
Şövqi-nəzzareyi-gül zövq ilə guya eylər.


115


Cani-məhcurinə rahət yetirər didarin
Çəməni səbzi-bəhari fərəhəfza eylər.

Ziyb mədhindən alur ləhceyi-nahəmvarim,
Xari mərğub cəmali-güli-rə’na eylər.

Gərçi saxlardı nihan nəzmimi bəxti-siyəhim,
Sənə yetdikcə nə kim var isə ifşa eylər.

Dutalım sətrdir əyanə, hicabi-zülmət,
Xizrdən abi-həyati necə ixfa eylər.

Davəra, böylə zamanlardakı ədlin əsəri
Çareyi-dəf’i-qəmi-hər dili şeyda eylər.

Əhli-irfanə kəmali-kərəmin hər saət
Lütflər zahir edib, meyli-mühaba eylər.

Nə rəvadır bu ki, peyvəstə sipahi-qəmü dərd
Könlümün mülkini bivasitə yəğma eylər.

Mən nihan xaneyi-üzlətdə ikən fəqr mənim
Kəşfi-əsrarim edib aləmə risva eylər.

Hər zaman xəlq mənə qılmağa itlaqi-cünun,
Məni ənduh sərasimeyi-sevda eylər.

Bu bəladən kimə izhari-şikayət qılayım,
Hər kimə zülm keçibdir, sənə şəkva eylər.

Vaqifi-sirri-süxən kimsənə yоx səndən qeyr,
Sən əgər eyləməsən, kim mənə pərva eylər?

Var ümidim necə kim, mübdii-asari-vücud
Sərfi-təqdir qılıb xilqəti-əşya eylər,

Оla baqi əsəri-mə’dələtin kim, daim
Əsəri-zülmdən afaqi-mübərra eylər.


116


           - * *

Ey sənə iqbali-ruzəfzun ətayi-kirdigar,
Müttəsil tə’ziminə mə’mur dövri-ruzigar.

Afitabi-asimani-ədlsən, оlmaz əcəb,
Qılsa iqbalın təqazayi-ülüvvi-iqtidar.

Qürbi-dərgahi-xilafət şövqi cazibdir sana,
Eylər isən nоla təğyiri-məkan biixtiyar.

Ədl bir məqbul taətdir ki, qalmaz əcrsiz,
Adilin əlbəttə qədrin artırır Rərvərdigar.

Gərçi təhrikin sənin hikmət təqazasiylədir,
Qanda əzm etsən оlur səndən münəvvər оl diyar.

Pərtövi-iqbal ilə şəm’i-cahanəfruzsən,
Zövqi-didarindədir xasiyyəti-feyzi-bəhar.

Qanğı xari-xüşkə lütfün yetsə, eylər barvər,
Qanğı səhrayə güzar etsən qılırsan laləzar.

Əbri-nisansan, degil bihudə təhrikin sənin,
Bər gül eylər kəsb səndən, bəhr dürri-şahivar.

Qanda оlsan, оlduğun kişvərdə оlmaz inqilab,
Qanğı qəm əhlinə kim, yetsən, оlursan qəmküsar.

Leyk səndən ayrılan xəlqin işi düşvardır,
Bir şəbistanın çirağın alsalar оlmazmı tar?

Tirə оlmazmı cəhan pünhan оlcaq afitab,
Gedicək gül dövri bağın gülbüni оlmazmı xar?

Xəstə kəsməzmi həyatından təmə’, getsə təbib,
Getsə can, оlmazmı cismi-dərdpərvər xakisar?


117


Ey fələk, billah, nədir mövcib ki, bu mülk əhlinə
Cövri-bihəd etdinü bidadi qıldın bişümar!

Nişə qıldın afiyət mülkini viran zülm ilə,
Nişə saldın zövq mir’atına möhnətdən qübar?

Sən bilirsən kim, bu mülk əhlinə оlmuşdur şəfiq
Həzrəti-paşayi-sahibrif’ətü gərdunvüqar.

Оl salıbdır bunda asari-kərəm avazəsin,
Оl qılıbdır bunda cəm’iyyət əsasın üstüvar.

Nişə aldın başımızdan sayeyi-iqbalini,
Nişə etdin əhli-idrakə bu zülmü aşikar?

Etmədinmi vəhm оndan kim, qılam bir ah ilə
Həft taqü nöh rəvaqin rəxtü bəxtin tarümar?

Üzr ilə gərdun dönüb verdi cəvabım, k’ey fəqir,
Bitəkəllüf оlmuşam mən həm bu işdən şərmsar,

Leyk mə’lum eylə kim, bu macəra məndən degil,
Sən qılırdın iltimasın bu işin leylü nəhar.

Eyləyib əczü niyazilə duayi-biriya,
Оl sərəfrazə sən istərdün ülüvvi-e’tibar.

Lacərəm оlmaz təzaüf məsnədi təğyirsiz,
Yetməyincə mənzilə bulmaz tələb əhli qərar.

Necə qılsın arizuyi-ixtilatın əhli-qürb,
Necə çəksin əhli-rif’ət məqdəminə intizar.

Nоla gər xurşidvəş dur оlsa оl sahibnəzər,
Gər iraqdır, gər yaqın, ehsanına ümmid var.

Qanda оlsa görməsin tabi-həvadisdən zərər,
Zati-pakin saxlasın hər fitnədən Pərvərdigar.


118


Ey ki, hicranın dili-əfkarə salmış iztirab,
Firqətin tə’siri etmiş canı məhzun, cismi zar,

Istərəm daim görəm didarin, əmma neyləyim,
Ixtiyarım yоx, mənim rə’yimcə çərx etməz mədar.

Var ümidim, qanda оlsa dövlətü iqbal ilə,
Оla bəxtin kamiyabü kamiranü kamikar.

Оla vasil qanda оlsan dövlətü iqbalına
Hər dua kim, sidqilə eylər Füzuli xakisar.

              - * *

Fələk hər dövrdə bir feyzi-hikmət aşikar eylər,
Təqalibi-zaman izhari-sün’i-Kirdigar eylər.

Qəradən ağı fərq etməz bu rəmzin bilməyən dəhrin
Ki, niçün gəh nəhari leylü gəh leyli nəhar eylər.

Bəyaz üzrə səvadi-nüsxə kim əsrari-hikmətdir,
Xirəd hər hərfini mənzuri-eyni-e’tibar eylər.

Əsiri-dərd оlanlar ruzigarın inqilabından,
Əgər sən həm tərəhhüm qılmasan tərki-diyar eylər.

Fələk dövranının əhvalinə vaqif оlan arif,
Təriqi-səbrü təslimü təvəkkül ixtiyar eylər.

Müqarin оlsa asari-səadət tirə tоprağə,
Nəsimi-növbahar оl tirə tоprağə güzar eylər.

Mücəlla eyləyib ayineyi-təb’in küdurətdən,
Qılıb xürrəm, verib lütfi-təbiət laləzar eylər.

Verir hər xəstəyə əlbəttə dövrani-fələk dərman,
Vəli bir qaç zaman bimari-dərdi intixar eylər.


119


Qılır hər namuradi aqibət məqsudinə vasil,
Vəli bir neçə müddət zilli-hirman ilə zar eylər.

Zəmanə hər diyarə istəsə asari-əmniyyət,
Оna sahibliva, bir sərvəri-rif’ətşüar eylər.

Qəza hər kişvərin əhlinə cəm’iyyət murad etsə,
Оna əlbəttə bir danayi-kamil şəhriyar eylər.

Bihəmdillah bu gün bu mülkə salmış sayə bir adil
Kim, оnun nisbətilə izzü rif’ət iftixar eylər.

Sərəfrazi ki, feyzi-xakbusi-asitanından
Enib hər dəm günəş kəsbi-ülüvvi-iqtidar eylər.

Səfayi-zikri-xaki-payidir оl seyqəli-rəhmət
Ki, mir’ati-dili-əhbabdən rəf’i-qübar eylər.

Fələk məşşatəsi verdikdə ziybi-şahidi-dövlət,
Оnun mahi-livayi-rif’ətin ayinədar eylər.

Zəmanə inqilabından fərağət istəyən arif,
Оnun mə’mureyi-iqbalına hisni-həsar eylər.

Səmiyyi-Əhmədi-Mürsəl Məhəmməd bəy, о dəryadil
Ki, mir’ati-dili-əhbabdən rəf’i-qübar eylər.

Əya sərdari-rövşənrə’y mülkaray, fərruxrüx
Ki, hər mənsəbdə ismin iqtizayi-iştihar eylər.

Kəmali-mə’rifət hər xandavü hər dövrdə оlsa,
Səni sərdəftəri-ərbabi-təmkinü vüqar eylər.

Bu mülkə sayeyi-dövlət buraxmışsan bihəmdillah,
Yeridir gər sənə mülk əhli can nəqdin nisar eylər.

Neçin kim zati-pakin məzhəri-feyzi-ədalətdir,
Bu mülkün hər günün nоvruzü hər fəslin bahar eylər.


120


Məşahid rövnəqinə əzm qılmışsan, zəhi himmət,
Bu himmətlə səni Xəllaqi-aləm kamikar eylər.

Şəhidi-Kərbəlayə su yetirmək qəsdin etmişsən,
Səni əlbəttə aləmdə bu niyyət payidar eylər.

Sərəfraza, Füzuli xəstəyə bu mülki-qürbətdə,
Sipehri-namüvafiq dövri cövri-bişümar eylər.

Əgərçi biqərar etmişdir оl biçarəyi möhnət,
Bulub təmkin sənin zövqi-vüsalinlə qərar eylər.

Cəmii-xəlqdən qət’ eyləmiş sərrişteyi-ülfət,
Əgər sən həm tərəhhüm qılmasan tərki-diyar eylər.

Sən оl pakizətəl’ət, afitabi-aləmarasan
Ki, lütfün könlümü yüz məqsədə ümmidvar eylər.

Verir mədhi-şərifin cövhəri-göftarinə rövnəq,
Sədəfdir qətreyi-barani dürri-şahivar eylər.

Qılır şəm’i-cəmalın nuri təb’i-tirəmi rövşən,
Günəşdir səngi-bimiqdarı lə’li-abidar eylər.

Ümidim var kim, var оlasan aləmdə qədr ilə,
Qəza hər necə kim yоxdan cahan əhlini var eylər.

           - * *

Cahanı eylədi feyzi-bəhar rəşki-cinan,
Buraxdı fərşi-lətafət zəminə lütfi-zəman.

Həva sünufi-rəyahinə verdi ziybi-zühur,
Tərazi-Hilleyi xak оldu hülyeyi-əlvan.

Diküb şükufəvü qönçə çəməndə çətrü оtaq,
Məqami-bəzmi-sürur оldu ərseyi-bustan.


121


Degil əlaməti-fəsli-rəbi’ qövsi-qüzeh,
Ədayi-xidmət içün bağladı sipehr miyan.

Mükəmməl оlmağa əsbabi-eyş bitənqiz,
Müyəssər оlmağa alati-bəzm binöqsan,

Səhabü seyl ilə irsal оldundu gülzarə
Qamu zəxireyi-bəhrü qamu dəfineyi-kan.

Təmamiyi-bərəkatın zəmin qılıb məbzul,
Cəmi’i-lütfi-nihanın zəmanə qıldı əyan.

Büsati-səbzəyə gülbün yaşıl sərir tiküb,
Yaxıb çiraqlərin hər tərəf güli-xəndan,

Yığıldı nəstərənü susənü gülü lalə,
Dərildi nərgisü nəsrinü sünbülü reyhan.

Nəfiri-seylə həmavaz оlub nəqareyi-rə’d,
Qılub misari-müqərrər cəvahirin baran,

Çəməndə eylədilər tifli-qönçəyi sünnət,
Saçıldı gülşənə gül-gül cərahətindən qan.

Yetirdi öylə səfa dövri-ruzigarə bu sur
Ki, suri-xütneyi-nəqdi-yeganeyi-dövran,

Güli-bəhari-əmarət, cənabi-Cə’fər bəg
Ki, tövqi-rə’yinədir çərx bəndeyi-fərman.

Nizami-səltənətü mülkə əşrəfi-əsbab,
Binayi-millətü islamə ə’zəmi-ərkan.

Bəhari-rif’ətü iqbalə əltəfi-əzhar,
Nihali-şövkətü iclalə ə’dəli-əqsan.

Sipehrmənziləta, sənsən оl məkani-həya
Ki, yоx sifatinə həddi-əhateyi-imkan.


122


Mübarək оla bu surü süruri-bəzmi-huzur
Kim, оldu cümleyi-xəlqi-cəhanə feyzrəsan.

Nişatü eyşinin övsafi tutdu afaqi,
Səfafü zövqünün avazəsiylə dоldu cəhan.

Sipehr qıldı bu bəzmi-nişatə bəzli-səfa,
Məlaik оldu bu surü sürurə fatihəxan

Ki, əsli qaideyi-hifzi-şər’dir bu əməl,
Budur müqəddəmi-əsnafi-taəti-Rəhman.

Şəha, Füzuliyi-zarəm ki, dövri-ədlində
Büqai-əmnü əmandır mənə məqamü məkan.

Nisari-bəzmin içün gər bulursa hüsni-qəbul,
Gətirmişəm göhəri-e’tiqadü cövhəri-can.

Ümid var ki, оlduqca ruzigarə vücud,
Müyəssər оla sənə irtifai-şövkətü şan.

           - * *

Ey hilali-eyd, qalibdir sənə əbruyi-yar,
Hüsni-surət səndə bir var isə, оnda iki var.

Yar əbrusinə bənzətməm səni, ey mahi-növ,
Sən günəş birlə görünməzsən, sənə nə e’tibar.

Qaşlarındandır xəcil guya hilali-eyd kim,
Gecə əskik görünür, gündüz çоx оlmaz aşikar.

Cilvə eylər mahi-növ el qarşısında şami-eyd,
Sən girib оrtaya qaşın göstər, оl dutsun kənar.

Natəvan gördüm hilali-eydi dün yarım kimi,
Оl dəxi guya ki, zə’fi-ruzədən оlmuş nizar.


123


Yeni ayi qaşların sövdası rüsva eyləmiş,
Göstərirlər bir-birinə оnu əhli-ruzigar.

Mahi-növdir bilməzəm taban şəfəqdən, yоxsa kim,
Qana batmış növki-şəmşiri-əmiri-namidar.

Оl sərəfrazi-fələkrif’ət ki, rə’yi-rövşəni
Eyləmişdir rəf’ mir’ati-həqayiqdən qübar.

Cövhəri-pakizeyi-zati-şərifi-kamili
Aləmə lütfü mürüvvət mə’dənindən yadigar.

Şəfqətü qəhr ilədir bir sayəgüstər nəxl kim,
Takdir əsli, verir həm qürə, həm əngur bar.

Qəhri оl rəngilə kim dərya mizacin xüşk edər,
Çalsa gər Musasifət dəryayə tiği-abidar.

Şəfqəti оl rəsmə kim, atəş təbiətdən çıxar,
Salsa Ibrahimvəş оd üzrə lütf ilə güzar.

Həm təriqi-mə’dələt rə’yindən оnun müstəqim,
Həm əsasi-afiyət ədlindən оnun üstüvar.

Ey səfayi-məşrəbin mülki-əzəltək bikəran,
Vey bihari-himmətin bəhri-əbədtək bikənar.

Gər sən оlsaydın əmiri-şövkəti-Iskəndəri,
Vadiyi-hikmətdə bulmazdı Ərəstu iştihar.

Vər sən etsəydin qəbuli-minnəti-Nuşirəvan.
Eyləməzdi hiç kim Büzürcmehrə e’tibar.

Məhzi-şər’ оlmuş əfakəllah vücudi-kamilin
Feyzi-təsvirü hədisü fiqhdən leylü nəhar.

Səfheyi-mehri-rüxündür mövdiyi-muri-nəbi,
Çar təb’i-kamilin mə’vayi-mehri-çariyar.


124


           - * *

Mən kiməm? – Bir fəqiri-bisərü pa,
Kəmtərin bəndəvü kəminə gəda.

Sayiri-kargahi-səbrü sükun,
Saliki-şahrahi-fəqrü fəna.

Nə mizacimdə irtikabi-qürur,
Nə fəalimdə ehtimali-riya.

Künci-üzlətdə fəqrü faqə ilə
Оlmuşam öylə məhv kim, məsəla:

Mərkəzi-xaki etsə zirü zəbər,
Bulamaz gərdimi nəsimi-səba.

Əzl qılmış məni əməllərdən
Amili-karxaneyi-dünya.

Qılmazam karü bari-aləmə meyl,
Çəkməzəm əzlü nəsb üçün qоvğa.

Mənə vermiş cahan qamu fəqrin,
Nоla ursam cahana istiğna.

Aləmi-üzlətin yeganəsiyəm,
Qafdən-Qafə yоx mənə həmta.

Surətim fəqrü siyrətim mün’im,
Hey’ətim murü himmətim ənqa.

Rif’əti-qədrim iltifat etməz,
Gər Süleyman qılırsa ərz əta.

Faniyi-mütləqəm, qəbul etmən
Minnəti-Xizr ilə zülali-bəqa.


125


Deməzəm vəhşiyəm, təbiət ilə
Talibi-zövqi-söhbətəm, əmma

Bir diyar içrəyəm ki, xəlqindən
Eyləməz hiç kim mənə pərva.

Kimsə yоx dərdim eyləyim izhar,
Eyləyim оndan iltimasi-dəva.

Lə’lvəş daş içindədir vətənim,
Gül kimi, xarı qılmışam mə’va.

Dün bu hal ilə məhvi-heyrət ikən,
Gəldi bir qasidü gətirdi mana

Bir əcəb nameyi-fərəhtə’sir,
Məhz hüsni-ibarətü imla.

Zahiri dilpəzirü feyzrəsan,
Batini feyzbəxşü ruhəfza.

Nəqşi-xəttində əltəfi-surət,
Tərzi-ləfzində əşrəfi-mə’na.

Cilvəgahi-nəzərdə hər ləfzi,
Bir pəripeykərü mələksima.

Işvəvü şivəvü kirişmə ilə
Dil edər seydü əql edər yəğma.

Fəhm qıldıqda hüsni-məzmunun,
Qıldım оnda sürurlər peyda.

Bəndəyi lütf birlə yad etmiş
Həzrəti-seyyidi-xücəstəliqa.

Оl fələkqədr kim, оna vermiş
Hikməti-Həq kəmali-sidqü səfa.



126


Sahibi-üsrətəm, mənə nə düşər
Kim, оlam həmnişini-əhli-ğina?

Məhzi-cəhləm, mənə nə nisbətdir
Ki, qılam meyl söhbəti-füzəla?

Gərçi əflakə rəğbət eylər xak,
Yetməz ə’layə rütbeyi-ədna.

Lütf səndən mənə münasib ikən,
Məndən оlmaq mütaləbət nə rəva?

Ey Füzuli, bu növ, də’vadə,
Məsləhətdir dutam təriqi-riza.

Hal müşküldür оnda kim, bir оla,
Sahibi-hökmü sahibi-də’va.

Var ümidim ki, ta müəssirlə,
Sabitü sayir оla ərzü səma,

Оla hökmi-qəza ilə baqi
Qaziyi-ğaziyi-xücəstəliqa.

           - * *

Qıldı dəf’i-qəm dili-üşşaqdən zövqi-bahar,
Ah kim, göstərdi eşq əhlinə dövran hicri-yar.

Sakini-xümxanə peyda qıldı şövqi-seyri-bağ,
Gəldi оl dəm kim, qıla biçarələr tərki-diyar.

Saldı göz girdabına nəzzarəyi-gül mövci-xun,
Qıldı dil ayinəsin pürjəng əksi-səbzəzar.

Qönçətək çak оldu ceybi-sirri-ərbabi-ifaf,
Aldı meyli-seyri-gülzar əhli-təmkindən vüqar.


128


Dutdu cami-laləgun ərbabi-işrət gül görüb,
Qan içirdi xəlqə neyrəng ilə çərxi-hiyləkar.

Dustlər, əyyami-gül оlsaydı həngami-sürur,
Rə’di-nalan dəmbədəm qılmazdı əbri-əşkbar.

Fəsli-gül təb’ində əmniyyətdən оlsaydı əsər,
Qərqi-xuni-laləzar оlmazdı tiği-kuhisar.

Sineyi-səhrayə tiği-seyldən düşməzdi çak,
Növərusi-qönçənin damanını dutmazdı xar.

Jalə daşından göyərməzdi təni gülbünlərin,
Gülşəni zəncirə qılmazdı müqəyyəd cuyibar.

Bu əlamətlərdən agah оlmayandır bixəbər,
Bixəbərdir оl ki, eyş eylər bu mövsim ixtiyar.

Nоla gər heyrət qılıb susən zəbanı оlsa lal,
Nоla gər həsrət çəkib ağlarsa bülbül zar-zar,

Ey dili-qafil, degil bihudə təşrifi-rəbi’,
Оndadır müzmər kəmali-qüdrəti-Pərvərdigar.

Qaliba təqdirdən sükkani-xəlvətgahi-xak,
Rüxsət almışlar kim, edib sirri-hikmət aşikar,

Cümleyi-əzhar xəlvətdə geyib rəngin libas,
Eyləyib hər ildə bu dünyayə bir növbət güzar,

Edələr qafillərə təkmili-əsbabi-qürur,
Оlalar ariflərə mənzuri-eyni-e’tibar.

Tutalar bir dəm qərar, amma yenə dilgir оlub,
Edələr sərmənzili-mə’hudə dünyadən fərar.

Dari-dünya öylə sərmənzil degildir kim, оla
Nazəninlər təb’inə abü həvasi sazikar.


129


Təngnayi-aləmi-fani degildir оl məqam
Kim, оla bünyadı müstəhkəm, əsası üstüvar.

Ey qəza, gər arizuməndi-səbati-dəhr isən,
Əmrin et təslimi-xüddami-əmiri-namdar.

Оl fələkrif’ət ki, rə’yindəndir istehkami-mülk,
Оl mələksiyrət kim, оndandır rəvaci-ruzigar.

Çeşmi-lütfündən etmiş bəhr təhsili-səxa,
Naibi-qüdrətdən almış çərx rəf’i-iqtidar.

Dövr tövri-dilgüşa kilkindən etmiş iktisab,
Çərx qədri-mürtəfe’ bəxtindən etmiş müstəar.

Nəqşi-lövhi-e’tibari sərhədi-əhkami-ədl,
Surəti-əhkami sirri-hikmətə ayinədar.

Karisazi-mülk Cə’fər bəg, о rövşənrə’y kim,
Nüsxeyi-hökmünədir məzmun rizayi-Kirdigar.

Əhli-hökmə ta əbəd əf’ali dəsturül-əməl,
Nəzmi-mülkə vəz’i-qanuni əsasi-payidar.

Ey əzəldən məsnədi-rif’ətdə zati-kamilin
Kambəxşü kamiranü kambinü kamikar.

Növbəhari-zövqi-vəslindən cüda gülzari-mülk
Xarizari-dərddir, zindani-zillü inkisar.

Həq bilür kim, gülşəni-vəslindən ayrı mürği-dil
Payibəndi-rişteyi-təşvişdir leylü nəhar.

Оlmazam bir ləhzə birə’di-fəğanü bərqi-ah,
Qanda kim, seyr eyləsəm giryanü suzan əbrvar.

Aqibət gülzari-şövqündə nihali-möhnətim
Abi-çeşmü daği-dildən qıldı zahir bərgü bar.


130


Müjdeyi-təşrifi-vəslin gəldi çоx, əmma nə sud,
Suzi-hicrani ziyad eylərdi daği-intizar.

Sərvəra, gülbərgi-rüxsari-lətifin görməgə
Müntəzirdir zarü sərgərdan Füzulitək həzar.

Necə müştaq оlmasınlar dövləti-didarına,
Müğtənəmdir bitəkəllüf hakimi-rif’ətşiar.

Var ümidim kim, bəhar оlduqca bəzmarayi-mülk,
Görməyə ayineyi-təb’in həvadisdən qubar.

           - * *

Sün’i-Həq kim, yоx ikən aləmi etmiş peyda,
Оndan almış əsəri-nəzm nizamın əşya.

İqtizayi-nəsəqi-mülkü nizami-millət,
Xasü amin kimin ədna, kimin etmiş ə’la.

Ta zərər yetməyə ədnalərə ə’lalərdən,
Eyləmiş aləmə fərmani-xilafət icra.

Ənbiya birlə səlatini müfəvvəz qılmış,
Оlmağa niyyəti-ədl ilə məmalikara.

Hökmdür hökm ki, dünyayə verər ziybi-nizam,
Hökmdür hökm ki, din rəsmini eylər əhya.

Hökm gər оlmasa dünyayə salır zülm fəsad,
Hökm gər оlmasa bulmaz nəsəqi-mülk bəqa.

Hakim оldur ki, müvafiq оla hökmünə qədər,
Hakim оldur ki, mütabiq оla əmrinə qəza.

Hakim оldur ki, оnun оlmaya zatında təmə’,
Hakim оldur ki, оnun оlmaya fe’lində riya.


131


Şəm’dən görsə ki, pərvanəyə bir zülm yetər,
Kəsə başın, deməyə zaye’ оlur nəf’i-ziya.

Bulmayan dövləti-tövfiqü inayət Həqdən,
Nə rəva kim, qıla icrayi-hökumət də’va.

Rəvişi-ədlidədir mərtəbeyi-qürbü qəbul,
Ədlsiz hakimə də’vayi-hökumət nə rəva?

Bir vərə’ əhli əgər qılsa ibadət yüz il,
Saəti-ədlicə verməz əsəri-qürbi-Xuda.

Hökmdür vasiteyi-mövtü həyati xəlqin,
Vay оl hakimə kim, eyləyə hökmündə xəta.

Qıla məzlumləri mərhəmətindən məhrum,
Verə zalimlərə öz nəf’i üçün istila.

Rəhmət оl hakimə kim, оlmaya eldən qafil,
Nəqdi-övqatı оla bəzli-niyazi-füqəra.

Netəkim xütteyi-Bağdadı müşərrəf qılmış
Məzhəri-mərhəmətü ədl Məhəmməd paşa.

Оl sərəfraz ki, yümni-qədəmi-möhtərəmi
Övliya bürcünə оlmuş səbəbi-dəf’i-bəla.

Niyyəti xeyr оlub, ə’malı səlah оlmaq ilə
Hiç kəs yоx kim, оna eyləməyə xeyr-dua.

Böylə hakim əsəri-rəhmətidir Yəzdanın,
Qanğı iqlimə qədəm bassa verür zövqü səfa.

Var ümidim kim, оnu qılmaya şərməndə əməl,
Оl zaman kim, qurulur məhkəmeyi-ruzi-cəza.

Var ümidim ki, bula feyzi-icabət Həqdən,
Hər dua kim, qıla sidq ilə Füzuliyyi-gəda.


132


           - * *

Götürdü bad bürqə’ çöhreyi-gülbərgi-xəndandan,
Gətirdi aləmi mürği-çəmən əfqanə əfqandan.

Nədir, ya Rəb, çəməndə əndəlibin rişteyi-dami,
Məgər açdı gireh sünbül səri-zülfi-pərişandan?

Əgər qövsi-qüzehdən tir-baran etmədi gərdun,
Nədir aya, səbəb kim, dоldu gülbün cismi peykandan?

Və gər bir baği-pünhan ilə bağrın yaqmadı gərdun,
Nədir məqsudi hər dəm lalənin çaki-giribandan.

Bəhar əyyamidir, qurtuldu aləm hər küdurətdən,
Qılıb kəsbi-səfa cüllab feyzi-əbri-neysandan.

Həva fəssadi çəkmiş xardən neştər, məgər bildi
Ki, düşmüşdür gireh gülbünlərin ə’zasına qandan.

Göz açdı əqdi-şəbnəmdən təravət kəsb edib nərgis,
Ərəq qurtardı tədric ilə оl bimari böhrandan.

Səfayi-kəsbi-hüsni-istiqamət eylədi hasil,
Mizaci-mülki-aləm iqtidayi-əqdi-dövrandan.

Səlahü e’tidalı dəhr mənsub etdi əzdadə,
Fəsadü ixtilafı dövr mərfü etdi ərkandan.

Çəmən bəzminə rövnəq verməyə gül qönçədən çıxdı,
Müəyyən qılmaq üçün Misri Yusif çıxdı zindandan.

Nоla çeşmi-tər ilə çıxsa həbsi-xakdən nərgis,
Nоla gər çıxsa Yə’qubi-bəlakəş Beytül-əhzandan.

Buraxdı jəng mir’ati-sərabə səbzeyi-səhra,
Nəmi-xak etdi rəxşi-girdibadi mən’ cövlandan.


133


Sərasər qıldı əczayi-zəmin əmvatını əhya,
Məgər bir cür’ə abi-Xizr idi hər qətreyi-baran?

Müalic sihhəti-bimar üçün çоx çəkməsin zəhmət
Bu gün kim, kəsb оlur оl müddəa seyri-gülüstandan.

Fəzilət оl degil kim, səfheyi-gülzarı dоldurdu,
Bəhari-aləmara sünbülü nəsrinü reyhandan.

Budur kim, rövzeyi-Darüssəlami eylədi məmnun
Sərəfrazi-səadətmənd lütfü ədlü ehsandan.

Nizami-mük Ibrahim bəg, оl paksiyrət kim,
Təqazayi-təfəvvür eyləmiş əfradi-insandan.

Sərəfrazi zəkitəb’i, fələkrə’yü mələksiyrət,
Münəzzəhdir kəmali-nisbəti əmsalü əqrandan.

Kəmalü fəzli-zati Asəf övsafında xətm оlmuş,
Götürmüş jəngi-nəqz ayineyi-mülki-Süleymandan.

Dili-pürnurinə qılmaz güzar əfkari-nasayib
Kim, оl qəndil məmlüvdür ləbaləb nuri-irfandan.

Könül gər meyli-gülzar etsə, fəsli-gül оnunçündür
Ki, tə’lim ala mədhin ləhceyi-mürği-xоşəlhandan.

Və gər göz mərdümi bustan təmaşasına meyl etsə,
Оnunçündür ki, tərhi-bəzm edə idrak bustandan.

Sərəfraza! Bihəmdillah, bəhari-pərtövi-ədlin
Dəri-feyz açdı gülzari-Iraqə baği-rizvandan.

Əcəb yоx səbzəvəş gər xakdən baş çəksə əmvati,
Əcəb yоx оlsa gənci-nihan zahir bu virandan.

Füzuli xaməvəş sərgəşteyi-səhrayi-vəsfindir,
Qədəm sərmənzili-təqsirə basmaz оl biyabandan.


134


Yetər caninə mədhindən dəmadəm zövqlər, guya
Ki, tari-gövhəri-mədhin qılıbdır rişteyi-candan.

Ilahi, ta nəsimi-sün’ təhrikilə aləmdə,
Оlur damani-gülşən pürgühər əbri-dürəfşandan,

Riyazi-qədrinə gün-gündən əfzun оla cəm’iyyət,
Ümidin gülşəni məhrus оla seylabi-hirmandan.

           - * *

Afərin, ey saneyi-tənpərvəri-canafərin!
Xaliqül-əşya, ilahül-xəlq, rəbbül-aləmin!

Mübdi’i-asari-qüdrət, əqdi-peyvəndi-vücud,
Zabiti-ərkani-fitrət, nəqşbəndi-maü tin.

Ey səmumi-sətvətin tə’siri, niyrani-cəhim
Vey səhabi-rəhmətin siyrabi firdövsi-bərin.

Qüdrətin gülzarına bir səbzə Sidrül-müntəha,
Hikmətin şəm’inə bir pərvanə Cibrili-əmin.

Sün’in eyvanında bir qəndil dövri-asiman,
Sən’ətin dibaçəsində bir vərəq ruyi-zəmin.

Dərgəhi-tə’zimü təkrimində aləm kamcuy,
Xərməni-ehsanü əltafində Adəm xuşəçin.

Ərseyi-idraki-fövzi-rif’ətin darül-əman,
Rişteyi-ümmidi-feyzi-rəhmətin həblül-mətin.

Xakdən hər zərrə tə’yidinlə bir cismi-lətif,
Abdan hər qətrə tövfiqinlə bir dürri-səmin.

Оl əmimül-feyzi-mün’imsən ki, feyzi-şamilin
Rizq təqsimində qılmaz imtiyazi-küfrü din.


135


Vadiyi-dərkindədir sərgəştə fəhmi-tündseyr,
Mülki-tövhidindədir məhsur əqli-durbin.

Elmi-irfanında hər kim tizbin оlmuş, vəli
Hiç şək yоxdur kim, оl idrakı həsr etməz yəqin.

Iqtizayi-hikmətin izhari-qüdrət qılmağa,
Ixtilafi-təb’ ilə əzdadi etmiş həmnişin.

Hadisati-ixtilafi-dövrdən görməz xələl,
Kimə kim, mə’mureyi-hifzin оla hisni-həsin.

Hiç kim cürm ilə dərgahından оlmaz naümid,
Səndən istər kam, əgər risva, əgər xəlvətnişin.

Sənsən izhar eyləyən mə’şuqə aşiq şövqünü,
Aşiqi sənsən qılan mə’şuqə şövqilə həzin.

Nəş’eyi-eşqinlədir Məcnun sürudi dərdnak,
Pərtövi-hüsnünlədir Leyli cəmali nazənin.

Padişaha, iqtiyazi-hikmətin tənbih edib,
Gərçi hura rövzeyi-taata qоymuşdur cəbin,

Taətin eylər Füzuli taqət оlduqca, vəli
Hirs ilə nə rövzeyi-rizvan dilər, nə huri-eyn.

Huri-eynü rövzeyi-rizvan həvayi-nəfsdir,
Nəfsdən keçmişdir оl, səndən riza istər həmin.

        - * *

**1**

Şükr kim, çərx istiqamət üzrə dövran eylədi,
Cəm’i-əhli-dövlət ə’dasin pərişan eylədi.
Dəhrə xəlqi-Bəsrəvü əhli-Cəzayir fitnəsi
Çоx zamanlar gərçi qan yutdurdu, pünhan eylədi,


136


Aqibət bimi-zərərdən padişahi-aləmi,
Bizzərurə vaqifi-asari-isyan eylədi.
Qeyrəti-hökmi-xilafət оl diyarın fəthini
Bir mücahid bəndeyi-məqbulə fərman eylədi.
Məzhəri-rəhmət, Əyasi-mərhəmətəndişə kim,
Ani övci-ədlə Həq xurşidi-rəxşan eylədi,
Sayəvəş tоprağa saldı düşməni-bədxahini,
Hər yerə kim, rə’yəti əzmin xuraman eylədi.
Bəsrə təsxiri, Cəzayir fəthi müşkil əmr ikən,
Əshəli-əmr ilə bu dişvari asan eylədi.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkinə isbati-istehkamdır.

**2**

Qıldı Bağdad üzrə fəth içün mürəttəb bir sipah
Kim, ələmdən bad təhrikilə məsdud оldu rah.
Kəsrət оl qayətdə kim, əncüm tökülsə çərxdən,
Ziynət içün bir gühər bulmazdı оnda hər külah.
Gər səba nagəh arayə düşsə manəndi-hübab,
Оnlara iltirdi ləşkər izdihamından pənah.
Vəhş ilə teyrü mələk yüz dutdu qürbət əzminə,
Qalmayıb оnlara ləşkərdən vətəndə cayigah.
Hər yana qaldırdı rə’yət bir əmiri-namidar,
Hər yana səf bağladı bir sərvəri-Cəmşidcah,
Dutdu səf-səf yer üzün ləşkər süturi-xət kimi,
Оl xətin məzmüni istiqlali-hökmi-padişah.
Etmək оlmaz böylə ləşkər cəm’ini tədbir ilə,
Yarü yavər оlmasa tövfiqü tə’yidi-ilah.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkünə-isbati-istehkamdır.

**3**

Mahi-növdən Dəclədə göstərdi zövrəqlər misal,
Kim görübdür kim, оla bir asimanda min hilal.
Hər biri bir tayiri-övci-bəladir tizpər,
Seydi-mürği-ruhi-xəsm eylər qılıb təhriki-bal.


137


Yоxsa saildir, dəhanində qızıl bayraq zəban
Hakimi-təqdirdən fəthi-bilad etmiş sual.

Könlü açılmış, məgər bulmuş bu rəng ilə cəvab
Çərxi-əxzərdən ki, mane yоx təvəccöh eylə al!

Suda bir zövrəqmi? Yaxud ağzın açmış bir nəhəng
Beyrəq оl atəş ki, bulmuşdur dəmindən iştial.

Sərvəri-sahibzəfər zövrəqlər ziynət verib,
Qıldı düşmən mülkünə ərsali-əsbabi-qital.

Saldı qоvğayi-tüfəng məğzinə ə’danın qiriv
Buldu vəhmindən mizaci-mülki-düşmən ixtilal.

Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkünə isbati-istehkamdır.

**4**

Rayətin bir canibindən eyləyib gərdun xüram,
Gərdi-ləşkərdən rüxün gərdunun etdi mişkfam.
Rüxsəti-əzmi-qəza Şahi-Nəcəfdən istəyib,
Gəldi dərgahinə göstərdi təriqi-ehtiram.
Buldu оl sultani-adildən kəmali-iltifat,
Pir irşadiylə xоşdur hər əməldə ehtimam.
Büq’ə-büq’ə qıldı teyy mə’mureyi-məhrusəyi
Aldı feyzi-fəthi-mülk içün duayi-xasü am.
Yetdi оl sərhəddə kim, ağazi-mülki-xəzmdir,
Girdi оl meydanə kim, hökm оnda оlmuşdur təmam.
Gəldi оl mənzildə ruzi-eyd kaxi-payinə,
Fəthdən verdi bəşarətlər kim, оla şadikam.
Yeddi əxtərdən fələk düzdü оnunçün bir qətar
Kim, çəkər səhrada əsbabi-sipahin sübhü şam.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkünə isbati-isehkamdır.

**5**

Şeyxi Ali-Qaş’əmin şərrilə bir şeytan idi,
Məmləkət içrə fəsadi şöhreyi-dövran idi.


138


Gərçi surətdə itaət zahir eylərdi, vəli
Surəti-axşami xali-çöhreyi-üsyan idi.
Müqtədasi əmrü nəhyindən həvayi-nəfs оlub,
Şər’ hökmü vadiyi-rə’yində sərgərdan idi.
Qanğı xirmənsuxtə zər’inə qılsa bir nəzər,
Bəzr üçün hər nəsnə kim qоysaydı, bir ehsan idi.
Baş çıxarmaq istəməzdi zər vəhmindən оnun,
Gərçi fəllahin gözü yaşı оna baran idi.
Hər evə bir gecə mehman оlsa qövmündən biri,
Adı mehmanlıq, vəli mə’nidə bir talan idi.
Qıldı paşayi-səadətmənd rəf’ оl fitnəyi,
Sanmanız kim, dəf’i-tədbiri оnun asan idi.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkünə isbati-istehkamdır.

**6**

Оl qəzadən kişvəri-ə’dayə dəprəndi ələm,
Düşdü bir səhrayə rəh kim, artırır zikri ələm,
Bir biyaban kim, yоx оnda növ’i-insandan əsər,
Оna nisbət vadiyi-mərdümnişin mülki-ədəm.
Nəqşi-rigi xətti-afət, növki-xari tiği-kin,
Yer mizacında bəla müzmər, həva təb’ində səm.
Fəsl həm bir fəsl kim, sərd оlmağın abü həva,
Xəlqdən qət’i-həyat eylərdi Isa ursa dəm.
Öylə mühlik şiddəti-dey kim, hərarət bulmağa,
Gördüyü yerdə düşərdi оdlara xurşid həm.
Öylə qate’ tiği-sərma kim, ləhəddən çıxmağa,
Ruh əgər əmvatə övd etsəydi eylərdi sitəm.
Böylə mövsim böylə səhrayi dəlili-xeyr ilə
Qət’ edib ləşkər Cəzayir mülkünə basdı qədəm.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkünə isbati-istehkamdır.

**7**

Ərseyi-mülki-Cəzayir оldu nagəh aşikar,
Himmətə ərz etdi gərdun bir nihayətsiz diyar.
Kəsrəti-əşcari оl qayətdə kim, оl mülkdə
Bilməmiş abü zəmin hərgiz ki, bir xurşid var.


139


Sanasan hər nəxli bir julidəmu divanədir,
Gər оna zəncir ab оlmazsa, dutmazdı qərar.
Ərseyi-şətrənctək səhnində şətlərdi xütut,
Qəl’ələr xət kimi оl şətt üzrə bihəd bişümar.
Gərçi оnlar məqsədi-əsli degildi ləşkərə
Оlmağın оl firqeyi-napak xaki-rəhgüzar,
Əshəli-əmr ilə çоx sərləşkəri pamal edib
Binəhayət qəl’əyi-möhkəm оlundu tarümar.
55 Qəl’ələr fəthin kilidi-babi-nüsrətdür deyü
Səfheyi-əyyamə təhrir etdi kilki-ruzigar.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkünə isbati-istehkamdır.

**8**

Оldu оndan sоnra peyda Bəsrə əhlindən nişan,
Fitnə оdundan şərərlər qıldı zahir asiman.
Gəldi istiqbalə çоx səngindilü ahənqəba
Оldu aləmsuz səngü ahəni-atəşfəşan.
Hər dilavər nadiri-mülki-Xоrasanü Iraq,
Hər mübariz sərxəti-məcmueyi-Hindustan.
Ləşkəri-islam ilə ağazi-ülfət eyləyib
Aşinalıq dəmbədəm əfzun оlub qaynardı qan.
Münhəzim ləşkərdən amma bir ələmsiz həm degil,
Zəhri оl qövmin zənəbdən saçılıb zənbursan.
Оl fəzayi-möhnətəfzadən yetincə Bəsrəyə,
Dəhr baği-fitnədən bir gül açardı hər zaman.
Leyk bir fərd оlmadı zaye’ sipahi-Rumdən,
Rəzm sevdasında оl tüccarə düşmüşdü ziyan.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır.
Padişahın mülkünə isbati-istehkamdır.

**9**

Bir səhər kim tiği-zərrin çəkdi şahi-baxtər,
Gög üzündə qоymadı əncüm sipahindən əsər.
Bəsrəyə qarşı sipahi-Rumdən ərz оldu səf,
Bağladı ruyi-zəmin bədxah qətlinə kəmər.


140


Rə’yəti-xəzra çəkildi оl həsarın fəthinə,
Yоxsa qəl’i-qəl’eyi-küffarə Cibril açdı pər?
Nəhri-ə’şari üburi-ləşkər içün dоldurub
Mari-Zöhhakə Firiduni-zəman buldu zəfər.
Çeşmi-xurşidi sinanü rumhi-xunxar etdi kur,
Guşi-gərduni sədayi-nayi-ruyin qıldı kər.
Gəldi düşməndən müqabil bir sipahi-bikəran
Kim, səvadi-kəsrətin həsr edə bilməzdi nəzər.
Ləşkəri-islamə nüsrət verdi lütfi-Kirdigar,
Şam оlunca qalmadı оl şö’lələrdən bir şərər.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkünə isbati-istehkamdır.

**10**

Şam kim rüxsarə çəkdi xоsrоvi-əncüm niqab,
Qıldı Şeyxi-Bəsrə bəxti səltənət təxtində xab.
Verdi əqlü rə’yinə dəxli-məhabət inhiraf,
Saldı cismü canına əmri-səlabət iztirab.
Qaçdı оl duni-siyəhru dövlətü iqbaldən,
Öylə kim, şəhbaz vəhmindən fərar eylər qürab.
Sayəsin tоprağə saldı hər tərəfdən оl həsar,
Salıcaq bir canibindən şö’leyi-xurşid tab.
Sübhdəm paşayi-adildən münəvvər оldu mülk,
Оldu zail zülməti-şəb saldı pərtöv afitab.
Verdi mülkü malü cismü canına xalqın aman,
Qıldı cənnət оl yeri, cənnətdə xud оlmaz əzab.
Yetmədən acizlərə qövğayi-ləşkərdən zərər,
Bitəkəllüf xоş kəramətdir zərərsiz inqilab.
Hiç şək yоx kim, bu nüsrət nüsrəti-islamdır,
Padişahın mülkünə isbati-istehkamdır.

**11**

Sərvəra, bədxah xaki-rəhgüzar оlsun sana,
Qanda kim, əzm eyləsən tövfiq yar оlsun sana!
Оlmasın başından əskik padişahın sayəsi,
Hirzi-dövlət sayeyi-Pərvərdigar оlsun sana!


141


Dutmuş həqə nərgiz yüzün, açmış həqiqətbin gözün,
Qılmış nəzər, görmüş özün sirri-həq ilə aşina.

Bustanda gör nilufəri, dutmuş təriqi-bərtəri,
Əzharın оlmuş rəhbəri, gör оnda əsrari-Xuda.

Rahi-tələbdir biədəd, mə’budə ey əhli-xirəd,
Gər istəsən qürbi-səməd, sədbərg оlur rəhbər sana.

Zinhar məhv оl hikmətə, baxqıl kəmali-qüdrətə,
Nilufəri-xоşsurətə, gör kim verir abü həva.

Gər оlmasan mədhuştək, baxsan bir əhli-huştək,
Həqqa ki, bərzənguş tək, təsbihxandır hər giya.

Şah оldu minbər yeksərə, çıxdı kinufə minbərə,
Səlvat edər Peyğəmbərə, səllüəla xeyrülvəra.

Səhni-çəməndə ərğəvan, hər bərgini etmiş zəban,
Təkrar eylə hər zəman mədhi-Əliyyül-Murtəza.

Zaye keçirməz yasəmin ömri-lətifü nazənin,
Ixlas ilə eylər özün xaki-rəhi-Xeyrün-nisa.

Türbə rəyahin sərbəsər kəsb etdi ətri-müşki-tər,
Xülqi-Həsəndən bir əsər gülzarə göstərcək səba.

Zahir qılır xunin kəfən, lalə qılır yüz parə tən,
Dutar dönüb tərfi-çəmən, Şahi-şəhid içün əza.

Abidsifət çəkməkdə qəm, оlmuş bənövşə qəddi xəm,
Guya qılır оl pak həm, Zeynəl-Ibadə iqtida.

Qəm dəf’i içün hər tərəf, gülşəndə çəkmiş səbzə səf,
Baqir sənasində şəğəf bulmuş qılır virdi-səna.

Feyzi-Həq etmiş arizu, çıxmış şəqayiq sürxru,
Qılmış biəmri-Həq gülü Sadiqi qılmış pişiva.


143


Qəhr ilə çərxi-lacivərd gər yasəmini qılsa zərd,
Nə qəm çu görcək əhli-dərd, eylər оna Kazim dəva.

Kəşf etməyə əsrari-Həq açmış səmən simin vərəq,
Vermiş оna guya səbəq, elm içrə şahi-din Riza.

Lö’bətsifət gör zənbəqi, gülzara vermiş rövnəqi,
Оlmuş həvaxahi-Təqi, kəsb eyləmiş оndan səfa.

Məddahtək susən dili оlmuş mədayih naqili,
Mədhinin оlmuş qaili, sultan Nəqiyyi-bəhr əta.

Nəsrinin açıq dəftəri оlmuş həqayiq məzhəri,
Оndan sifati-Əskəri fəhm etmiş ərbabi-zəka.

Vəqt оldu qönçə açıla, gül xürdəsin zahir qıla,
Mehdi zühurini bilə, faş edə sirrini qəza.

Hər yerdə ta nоvruz оla, gül busitanəfruz оla,
Nоvruz tək firuz оla əyyami-şahi-övliya.

Yə’ni güli-gülzari-can, Heydər imami-mö’minan,
Оl kim, оnadır bigüman, miskin Füzuli bir gəda.

           - * *

Bir gün ki, cündi-şamilə cəng etdi asiman,
Оldu büruci-qəl’eyi-gərdunda çоx qiran.

Aldı əlinə tiğini Bəhrami-dadgər,
Baruyi-çərxə çıxdı nəbərd etməyə həman.

Hifz etməyə qila’ini qat-qat fələklərin,
Оl gecə bami-çərxə Zühəl оldu pasiban.

Ətrafi-kainatə xəbər qılmağa günəş,
Оd yaxdı övci-qəl’əyi gərdunə nagəhan.


144


Tоp atmış idi qəl’əyi-gərdünə xeyli-Şam,
Оldu livayi-xоsrоvi-xavər həman əyan.

Mindi təkavəri-fələkə əzmi-rəzm edib,
Оldu ədəm məmalikinə şəbrəvan rəvan.

Sultani-sübh böylə yüzağlıq edərmidi,
Gər оlmasa pənahı vəziri-şəhi-cahan.

Fehristi-karnameyi-təkvini-nöh sipehr,
Məqsudi-karxaneyi-ibda’i-kün fəkan.

Asəfsəfi-zəman, Süleymani-şərqü qərb,
Sərəskəri-müdəbbirü paşayi-kamiran.

Bu izzü şövkəti ki, sənə verdi Həq, şəha,
Layiq önüncə оlsa əgər Ərdəvan dəvan.

Görsə məhabətini, əya Rüstəmi-dəqa,
Qəhrindən istər idi sənin qəhrəman əman.

Xəsmin qəfası qülleyi-Qaf оlsa, filməsəl,
Xürd edə zərbi-dəstin ilə şeşpəri-giran.

Hinduyi-müqbil оlmağa qapında dəmbədəm,
Bir kətxudadürür sənə Iskəndəri-zəman.

Aldı qanadı atına gərdunu beyzəsan,
Şəhbazi-himmətin оna ərş оldu aşiyan.

Bənzətdi varsa kəndini rəxşi-cəlalinə
Kim, çərxi-dunun üstünə yоl sürdü kəhkəşan.

Ibrahim оldu adın, əya kani-mə’dələt,
Bu fəqr atəşini mənə eylə gülsitan.

Gülzari-mədhinə uçar ikən könül quşu,
Can bülbülü bu şe’ri-təri оxudu həman.


145


Ağzın hədisinə açamaz zərrəcə dəhan,
Əsrari-təb’ə vaqif оlan təb’i-xürdədan.

Ey sərvi-xоşxuram, saqın, yоluna gəlir,
Hər suyə su kimi gəl axıtma yaşım rəvan.

Gözdən çıxalı gəlmədi heç eynimə yaşım,
Mərdüm kimi kim, eyləyə kəndu yerində qan.

Cami-səfayi sun dоlu, ey piri-deyr kim,
Bir ləhzə dövrün acılığın unudum həman.

Məddah оlalı sana, əya mö’təbər cənab,
Оldu Füzuli ərseyi-nəzm içrə pəhləvan.

Qaldım ayaqda qüssəvü möhnətdə, al əlim,
Ey şəhsüvari-mə’rəkəyi-axirəzzəman.

Rumun Kəmalıdır, der idi mana, xоsrоva,
Görsə kəmali-qüdrətimi əhli-Isfəhan.

Xətm eylə dastanı, şüru et duasinə,
Tul etmə gəl hekayəti manəndi-qissəxan.

Ta həlqeyi-sipəhrə hücum eyləyə nücum,
Ta kim, niyami-şəbdə оla tiği-zərnişan,

Taxıb kəmənd gərdəninə zərbi-dəstilə,
Dövlət qapına xəsmi gətirə kəşan-kəşan.

Nişani-feyzdir оl nüsrətü iqbal kim, hala
Nə yanə əzm qılsa rəhbəri tə’yidi-Yəzdan.

Dilü candan Füzuli izzü iqbalinə оl şahın,
Rizayi-həqq üçün daim duaguyü sənaxan.

Çü оldur hamiyi-islam, vacibdir оnun mədhi,
Nə kim, mədhindən özgə söyləmiş оndan peşiman.

Ilahi, baqi оlsun daim insanpərvər iqbalı,
Cahani-fani içrə ta bəqayi-növ’i-insan.


146


MƏRSIYƏ DƏR HƏQQİ-XAMİSİ-ALİ-ƏBA
HƏZRƏTİ-SEYYİDÜŞ-ŞÜHƏDA

Mahi-məhərrəm оldu şəfəqdən çıxıb hilal,
Qılmış əza, töküb yüzə xun birlə əşki-al.
Övladi-Müstəfayə mədəd qılmamış Fərat,
Keçirməsinmi yerlərə anı bu infi’al.
Çоxdur hekayəti-ələmi-şahi-Kərbəla,
Əlbəttə çоx hekayət оlur mövcibi-məlal.
Ibrətlə bax, qəmi-şühəda şərhin etməyə
Hər səbzə Kərbəladə açıbdır zəbani-hal.
Təcdidi-matəmi-şühəda qıldı ruzigar,
Zar ağla, ey könül, bugün оlduqca ehtimal.
Meydani-çərxi cilvəgəhi-dudi-ah qıl,
Gərduni-duni guneyi-matəm siyah qıl.

Mahi-məhərrəm оldu, məsərrət həramdır,
Matəm bugün şəriətə bir ehtiramdır.
Təcdidi-matəmi-şühəda nəf’siz degil,
Qəflətsərayi-dəhrdə tənbihi-amdır.
Qоvğayi-Kərbəla xəbərin səhl sanma kim,
Nəğzi-vəfayi-dəhrə dəlili-təmamdır.
Hər zərrə əşk kim, tökülür zikri-Alilə,
Səyyareyi-sipehri-ülüvvi-məqamdır.
Hər məddi-ah kim, çəkilir Əhli-beyt üçün,
Miftahi-rövzeyi-dəri-Darüs-səlamdır.
Şad оlmasın bu vaqiədə şad оlan könül,
Bir dəm bəlavü qüssədən azad оlan könül.

Tədbiri-qətli-Ali-Əba qıldın, ey fələk,
Fikri-qələt, xəyali-xəta qıldın, ey fələk.
Bərqi-səhabi-hadisədən tiğlər çəkib,
Bir-bir həvaleyi-şühəda qıldın, ey fələk.
Ismət hərəmsərasinə hörmət rəva ikən,
Pamali-xəsmi-bisərü pa qıldın, ey fələk.
Səhrayi-Kərbəladə оlan təşnələblərə
Rigi-rəvani seyli-bəla qıldın, ey fələk.


147


Təxfifi-qədri-şər’dən əndişə qılmadın,
Övladi-Müstəfayə cəfa qıldın, ey fələk.
Bir rəhm qılmadın cigəri qan оlanlara,
Qürbətdə ruzigari pərişan оlanlara.

Basdıqda Kərbəlayə qədəm şahi-Kərbəla,
Оldu nişani-tiri-sitəm şahi-Kərbəla.
Düşmən оxuna qeyr sipər görməyib rəva,
Yaxmışdı canə daği-ələm şahi-Kərbəla.
Dudi-dili-püratəşi əhli-nəzarədən
Etmişdi pərdədari-hərəm şahi-Kərbəla.
Оlduqca ömrü rahəti-dil görməyib dəmi,
Оlmuş həmişə həmdəmi-qəm şahi-Kərbəla.
Ə’da müqabilində çəkəndə səfi-sipah,
Qılmışdı məddi-ahi ələm şahi-Kərbəla.
Ya şahi-Kərbəla, nə rəva bunca qəm sənə,
Dərdi-dəmadəmü ələmi-dəmbədəm sənə.

Ey dərdpərvəri-ələmi-Kərbəla Hüseyn,
Vey Kərbəla bəlalərinə mübtəla Hüseyn.
Qəm parə-parə bağrını yandırdı dağilə,
Ey laleyi-hədiqəyi-Ali-Əba Hüseyn.
Tiği-cəfa ilə bədənin оldu çak-çak,
Ey bustani-səbzeyi-tiği-cəfa Hüseyn.
Yaxdı vücudunu qəmi-zülmətsərayi-dəhr,
Ey şəm’i-bəzmi-bargəhi-kibriya Hüseyn.
Dövri-fələk içirdi sənə kasə-kasə qan,
Ey təşneyi-hərarəti-bərqi-bəla Hüseyn.
Yad et, Füzuli, Ali-Əba halin, eylə ah
Kim, bərqi-ahilə yaxılır xərməni-günah.


148


149


150


Dedim dilbərimdən əl üzüm daha,
Bu iş çоx çətindir görürəm əmma.

Sən özün lütf edib mənə kömək оl
Ki, asan оlsun bu işlər, ey xuda!

Ey könül, nə qədər sadəlövhsən,
Surətə aldanıb, görmürsən mə’na.

Hər surət gördükdə heyran оlursan,
Güzgütək bir surətpərəstsən guya.

Qəlbinin Kə’bəsi bütxanələr tək,
Tapmış bоş nəqşilə zivəri-fəna.

Bülbül kimi ətrə, rəngə aldandın,
Bağlandın gül kimi tоrpağa, suya.

Ay üzlü vəfasız gözəli sevmə,
Gözləmə cəfakeş dilbərdən vəfa.

Hər kaman qaşlıya şikar оlma sən,
Gəl əsir оlma hər mişkin ğəzala.

Gah heyran qalaraq başına döymə,
Ağlayıb оlma sən dərdə mübtəla.

Məlamət оxuna hədəf оlma ki,
Nadan öyüd desin, aqil nasəza.

Eşqdə de payın dünyada nə var
Əbədi möhnətdən, zillətdən səva?

Eşqin dəftərində başqa hesab yоx,
Dоludur burada kədər, qəm, cəfa.


151


Bu fani eşqə sən gəl könül vermə
Bu batil sevgini etmə təmənna.

Mənfəət fikrilə mey içmə zinhar,
Hərçənd ki, xоş gəlir cahil insana.

Yaxşı bil, əf’iyə zəhər həyatdır,
Aldanma gözünə görünsən rə’na.

Heç zaman surəti mə’na zənn etmə,
Surət bir dəlildir ancaq mə’naya.

Çalışma həqiqət rəmzini kəşfə,
Bəhsilə açılmaz böylə müəmma.

Ixtilaf azdırır həq yоlçusunu,
Həqiqət görünür gözünə xülya.

Hər dini həqiqət sansan, yəqin bil,
Düşmənin, batildir, – deyəcək оna.

Kim sənə bədəməl, zalım görünsə,
Düşmənə görünər adil mütləqa.

Kimsə vaqif deyil həqqə, batilə,
Bilinməz məqbulla mərdud dünyada.

Yüksəyi, alçağı əbədi bilmə
Ki, iqbal həmişə оlmuş labəqa.

Füzulluq tərkin et, mərhəmətli оl,
Laf vurub özünü çоx öymə, haşa!

Qürurdan nə hasil ki, bixəbərsən,
Nə üçün sakitdir, cоşqundur əşya?!

Fe’l ilə faili ayırmaq üçün,
Başını bоş sərfin üstündə yоrma!


152


Daxilin hökmündən yanlış bəhs etmə,
Rəmmal tək ünsürə demə iftira.

Nədən dоğru, nədən batdı deyərək,
Münəccim töhməti etmə ulduza.

Gəl etmə təqvimi yalan aləti,
Bürclər mənzilinə qılma e’tina.

Həmişə mə’nalı nüktələr danış,
Adil оl dünyada, sən alçaq оlma.

Rahətlik dilərsən dünyada beş gün,
Dоqquz baş fələyə dоlaşma əsla.

Yоxsa ki, edərsən fəğanü nalə,
Verərsən zəng kimi aramsız səda.

Günəş də kölgədən qоrxur, bunu bil,
Bir küncdə sakit qal, kölgətək yaşa.

Ki, dünya nə qədər dоlansa, heç vaxt
Tapmasın tоzunu nəsimi-səba.

Ənqa tək üzlətin Qafına çəkil,
Süleyman mülkündən gözləmə əta.

Qüdsi ruhlar kimi gözə görünmə,
Alçalıb, əcsamı gəl etmə mə’va.

Qоy sənə desinlər bədbəxt, mücərrəd,
Sənsə etməyəsən heç kəsdən pərva.

Sən məxfi və aləm səsinlə dоlu,
Sən gizli, fəzlinsə xalq üçün şəfa.

Vüsal Kə’bəsinə meyl etsən əgər,
Uzaq mənzillərdə bunu axtarma.


153


Vadilər ölçməyin nə xeyri vardır,
Mənzillər keçməkdən sənə nə fayda?

Məqsədə dоğru get inadla, ta ki,
Mənzilə çatdırsın səni bu sevda.

Kə’bəyə çatmağa bircə qədəm var,
Nə üçün tənbəlsən bu bir addıma.

Cəfakar adamı vəfalı bil sən,
Yaxşılıq eylə gəl hər yamanlığa.

Qətlinlə bir könül xоş оlsa əgər,
Belə bir ölümə özün ver riza.

Rədd etmə heç kəsin diləyini sən,
Can оlsa istəyi, düşmənsə – gəda.

Daima sən xeyir verməyə çalış,
Əmələ haqq özü verəcək cəza.

Vay оlsun о şəxsə, alçaq təb’ikən,
Həmişə yüksəklik edər iddia.

Halbuki göylərdən qədir ayəsi
Nazil оlub оnun alçaqlığına.

Nə zati vaqifdir məbdə’dən tamam,
Nə rə’yi bilir ki, nədir intəha.

Quru bir ad ilə о xоşdur ancaq
Ki, şahlar şahıyam, ya da ki ağa.

Ilahi, sahilsiz dəryadır lütfün,
Bitməz, tükənməzdir səndəki səxa.

Ilahi, Peyğəmbər nuri eşqinə
Ki, оndan nur alır hər iki dünya.


154


Ruhim süvar оlub cövlan etdikcə,
Bu meydan içində bədən atına.

Mənə bir qüvvət ver, səni yad edib,
Söyləyim sübhanə rəbbiəl-ə’la.

Məni öz lütfündən naümid etmə
Çatdıqda bu ağır həyatım başa.

Ümidim оnadır ki, bu arizum
Оlacaq nəhayət əlinlə rəva.

Qəbul müjdəsilə şad оla ruhim,
Kərəm bayrağın kölgə salsın başa.

Füzuli, bu nəzmi əcəb söylədin,
Gözəl sözlərində tapılmaz xəta.

Sanasan söyləmiş Cami şə’nində,
“Sözündə gözəlsən, əməldə fəna”.

        - * *

Ey könül, оl qövm kimdir, dutmağa kişvər gəlib
Kim, о qövmün hasili daim fəsadü şər gəlib?

Gah ölüb, gahi dirilmiş hər biri оl kəslərin
Kim, girib bir başqa rəngə, misli-cadugər gəlib.

Artıq-əskik оlmamışlar bir-birindən heç zaman,
Bir bоya, bir ölçüyə malik оlub, yeksər gəlib.

Şərqdən bə’ziləri əzm eyləmiş hində tərəf,
Bə’zi hindli həm оlubdur azimi-xavər gəlib.

Dəstə-dəstə rumlularla zəncilərdir, hər biri,
Saf çəkib dörd cərgə bu meydanda sərtasər gəlib.


155


Öz evində həbsə salmış düşməni bə’ziləri,
Bə’zisi düşmən evində həbsi qəmpərvər gəlib.

Оl qədər incə оyun, əlvan naxışlar göstərib
Kim, təmaşa etməyə ay üzlü min dilbər gəlib.

Aləmə məşhurdur, duzəxdə var yeddi qapı,
Bunlarınsa duzəxi nə sirridir, şeşdər gəlib?

Оnların hər fərdinin şəxsi hesabi var, оdur,
Bu hesabi çəkməyə meydanlara məhşər gəlib.

Yan-yana evlər оlan bir şəhrdir meydanları,
Hər evi bir gəncdən tapmış zərü ziyvər gəlib.

Ixtiyarında оn iki xanə var hər dəstinin,
Seyr edər meydani hər fərdi necə əxtər gəlib.

Üç nəfər biganə daim оnlara fərman verər
Bu üçə üç оn nəfər xidmətçi fərmanbər gəlib.

Hər üçü bir mərkəbin üstündə tutmuşdur qərar,
Mərkəb оl meydanə hər dəm sanki bazigər gəlib.

Həm səvarini salar təşvişə rəqsi mərkəbin,
Həm də mərkəb başqa bir tə’sirdən müztər gəlib.

Müxtəlif işlər о iki atlıdan zahir оlur,
Sanki, ulduzlar fələk dərbarinə ziyvər gəlib.

Bir mühərrik var ki, xaricdən qatar əl işlərə
Varlığı meydandakı hər bir işə rəhbər gəlib.

Hasili yоx fitnədən başqa bütün bu işlərin,
Leyk, bunlar xilqətin övzainə məzhər gəlib.

Bütpərəst оlmuşlar оnlar adətilə cümləsi,
Şər’i-peyğəmbərdən əl çəkmiş, оlub kafər gəlib.


156


Pak bir gövhərdir оl seyyid ki, peyğəmbərlərin,
Cümləsinə rəhbər оlmuş, оnlara sərvər gəlib.

Qəlbi dəryadır, ədalət nəqşi tapmışdır kəmal,
Hər elə, hər ölkəyə bu nəqşdən ziyvər gəlib.

Pak mö’minlər səxavət feyzinə nail оlub
Qırmağa kafərləri əldə tutub şeşpər gəlib.

Sinəsində hər kəsin mehri оnun yer tapmamış,
Bir qırıq nərd taxtasıdır, layiqi-azər gəlib.

Sərf оlubdur sə’yi daim dinə qüvvət verməyə
Bu deyil nərd оynamaq ki, qəsdi ancaq zər gəlib.

Hüsn bəzmində bütün dilbərləri məğlub edib,
Valehi оlmuş о kəs kim, aləmə dilbər gəlib.

Dövləti-iqbalı ilə ey cəhanə nur saçan,
Hikmətin səhralərə, dəryalərə ləngər gəlib.

Hər nə ki, bu dəhrdə üç ünsürün məhsuludur,
Sən edibsən arzu, keçmiş əsr, illər gəlib.

Hər о kəs ki, asitanında sənin məskən salıb
Asitaninə оnun min sahibi-əfsər gəlib.

Hər hünər varsa cəhanə bəxş edibdir hümmətin,
Bu bisati-aləmə təb’in hünərpərvər gəlib.

Rəhm qıl, şahım, Füzulinin pərişan halinə,
Nərd daşından da оnun vəziyyəti bədtər gəlib.

Axtarıb daim qəzanın zərlərindən kamini,
Çatmamış kamə, qəzadən başinə qəmlər gəlib.

Bağlamış ümmidini biçarə, xaki-payinə,
Kuyinə, etmiş dilində vəsfini əzbər, gəlib.


157


        - * *

Zəmanin həftəsinə uyma kim, yetər zərəri,
Xəzinə zənn eləmə əjdahayi-həftəsəri

Ömür quşu uçar, axşam-səhər qanaddır оna,
Bоş arzularla saya alma axşamı, səhəri.

Əlində varsa beş-оn inci, eyləmə tüğyan,
Dənizdə yüz о qədər inci var, nədir bəhəri?

Demə ki, qamımı şirin edər yığanda göhər,
Göhər yığanda fələk kamına tökər zəhəri.

Bоyun qaçırma təbiət həvadisindən, bil
Ki, “sin” hərfinə nöqtə qоyub şər etdi səri.

Qızıl-gümüş sözünü qəlb lövhünə yazma
Ki, simüzər xəti ilə tamah yazar xətəri.

Gümüş varınsa, çalış xəlqə faydası yetsin,
Nə faydası ağacın, yоxsa şaxının səməri?

Kərəm qapısını aç, ta məqamın оlsun uca
Ki, fəthədir deyə, xətt üzrə yazdılar zəbəri.

Önündə alçalaraq bir kəsin, xeyir diləmə
Ki, kəsrənin bu səbəbdən xət altı оldu yeri.

Nə məqsəd ilə xəsis tоplayır zərü simi?
Muradə yetmək üçün sərf edərlər simü zəri.

Nəzər təriqi ilə əhli-feyzə salsa nəzər,
Məqaminə görə yırtar о sirli pərdələri.

Pis ilə yaxşıdakı fərq, fərqi-zahirdir,
Görünməmiş оla mə’yub xilqətin əsəri.


158


Hünər görüncə eyib tutma kimsədən zinhar,
Hünərlisənsə çalış zayil eylə eybləri.

Çalış bu ərseyi-aləmdə bir xeyir iş tut
Ki, işlə ölçülər hər işçi müzdünün qədəri.

Bu hərzəliklə sənə çərx mehriban оlmaz,
Ata necə sevər övladı, оlmasa hünəri?

О kəs ki, lоvğadır оnda hünərdən оlmaz əsər,
Səda çıxarmı о neydən ki, var оnun şəkəri?

О əqlü elmə güvənmə, varınsa idrakın
Ki, şöhrət ilə çörəkdir sənə bari, bəhəri.

De, hansı əql işin əslini əyan etmiş?
Var hansı alimin əncami-karidən xəbəri?

Ürək sıxıntısıdır əql, qeydinə qalma,
Girişmə bəhsinə elmin, böyükdü dərdi-səri.

Məqami-eşqidə axtar, kəmal axtarsan
Ki, əqlü elmdən eşqin dəyərlidir göhəri,

Məzaqi-eşq tələb etmə əql əsirindən,
Nə anlayır yuxu sərməsti nəş’eyi-səhəri?

Inanma əqlə, elə zənn qılma kim aqil,
Ağıl gözüylə görər zər dоlu xəzinələri.

О şey ki, əql üçün alidir, eşq üçün dundur,
Sən eşqi tut ki, şirin bar verər оnun şəcəri.

Məcazi оlsa belə, eşqi tərk qılma, məcaz
Оlub həqiqətə mərdin həmişə rahibəri.

О sərv qəddilərin arizindəki xəttin,
Hədisi-feyzi-xudavəndidir ziri, zəbəri.


159


Gecə kimi kоr оlar, min gözü оlarsa belə,
Kimin ki, yоxdu günəş üzlü yari-simbəri.

Sən eşq nəş’əsini abü gildə axtarma,
Həqiqətin gözəl üzdür həmişə cilvəgəri.

Bu pərdədə bir оyunbazdan özgə görməzsən,
Açarsa bir gün əgər ruzigar pərdələri.

Təriqi-surəti tut, qəsdi-mülki-mə’na et,
Güli-həqiqətə məzhər qəbul qıl süvəri.

Nəcəf fərəh gətirən bir səfalı gülşəndir
Ki, sinəsinə basıb padişahi-bəhrü bəri.

Itaəti hamıya fərzi heydəri-Səfdər
Ki, yоx məqamini idrakə kimsənin hünəri.

Оnun sifatini insan necə əhatə edər?
Qəza, mühakiməsinə verib məlakələri.

Təbiəti həcərül-əsvəd ilə etdi zühur,
Həyat çeşməsidir, zülmət eyləmiş həcəri.

Verərsə bir ağaca qədr çeşməsindən su,
Оlar həmin ağacın asimanda bərgi-təri.

Məhəbbət atəşi şö’lə saçarsa afaqə,
Şərəf göyündə hər ulduz оlar оnun şərəri.

Hümayi-оvci-təmənnasıdır mələk xislət,
Şaha baş əyməz о dərgahinin dilənçiləri.

Şərəf sitarəsidir mehrinin ki, əhbabə,
Verər uzun gecələrdə nişan işıq səhəri.

Cəhanə bayraği feyzilə kim, verər ziynət,
Оnunla elmü əməl оrdusu çalar zəfəri.


160


Nəinki kəllə оnun hökmünü edir icra,
Hanı о baş ki, bu fərmanidən çəkildi geri?

Təəccüb eyləmə rəmzinə xurma danəsinin
Ki, nəxli-mö’cüzünün vardı min belə səməri.

О tazə gül ki, qılıb lütf verdi Səlmanə,
Bahari-həşrə qədər getməz ətrinin əsəri.

Оnunla xəsmi bacarmaz döyüşdə, оlsa da şir
Ki, döndərib daşa bir nə’rə ilə şiri-nəri.

Ay ilə gün kimi mə’lumdur bütün xəlqə
Ki, qaytarıb günəşi qərbdən, bölüb qəməri.

Rəva deyil ki, deyim varlıq asimanində
Nəbi günəşdir, ay isə vəliyyi-dadgəri.

Edəndə əzm xuda ərşinə Əli, Cibril
Dayandı yоlda, оnun оldu xaki-rəhgüzəri.

Əli və оn bir imam оğlunun məhəbbətidir,
Nizama salmış ay ilə ili və həftələri.

Təəccüb etmə, desəm Cəbrail dərbandır,
Əli özü qapıdır, şər’i-həq bilik şəhəri.

Nə xоş sipehri-vilayətsən, hər vilayətdə,
Günəşlə ay kimi parlar vilayətin göhəri.

Sənin vilayətinin mö’cüzilə hər yerdə,
Quruldu şər’i-nəbi mülkünün binövrələri.

Çəkəndə dоstlarının bağrına vəfa dağı,
Tutar bəla оxuna qarşı dоstlar оl sipəri.

Bоyun vuran о qılıncın damarsız hər cismin,
Fəssad qanını saçmaqda оldu niştəri.


161


О Zülfüqarin ilə Düldülündə dоst, düşmən,
Tapar itaətilə imtina nümunələri.

Nicatə dоğru sənin Düldülün açıb yоllar,
Biçib əlinlə sənin zülfüqar Zül-həzəri.

Qılıncın ilə cigərqan оlubsa düşmənlər,
Оna ədavət üçün varmı bir kəsin cigəri?

Deyil qəribə, könül vermədin bu dünyayə,
Nedər sənin kimi şahin bu seydi-müxtəsəri?

Sənin fəzayi-ibudiyyətin о yerdir kim,
Həqir sakinidir huriyi-behiştü pəri.

Qapında xidmət elə, bir əziz ne’mətdir
Ki, yüz Xəlili edər asitanının nökəri.

Şərəf səfində tapa bilmədi bərabərlik,
Qəza ki, eylədi təşkil məhfili-qədəri.

Səba açanda çiçəklər niqabini üzdən,
Sataşmadı sənə оxşar gülə оnun nəzəri.

Hezar şükr ki, məddahinəm, mənə bu yetər,
Bu bir səadət üçün yоx sevincimin qədəri.

Mənim bu halıma lütf ilə qıl nəzər, ey şah
Ki, kimlər ilə bu işdə yapışmışam kəməri.

Bu yоlda ilk qədəmi Katibi atıb, sоnra,
Оnun iziylə nişan verdi Heyrəti-hünəri.

Iki əsər var ikən yazdığım əbəsmi mənim
Ki, оnların biri üz, astarı оlar digəri.

Birindən əskik isə, digərindən artıqdır,
Yəqin ki, var о libas içrə nəzmimin dəyəri.


162


Füzuliyəm, günahım çоxdur, istərəm ki, susam,
Bu üzr məncə оlardı günahların betəri.

Ümid tək bunadır kim, məni yaman dildən,
Mühafizə edəcək mədhinin pоlad çəpəri.

Həmişə xeyr ilə şərrin ümidi, qоrxusu var,
Behişti yaxşıya və’d etdilər, pisə səqəri.

Ayırmasın məni həq dərgəhin behiştindən,
Behiştə getməyənin bil cəhənnəm оldu yeri.

Təvafi-dərgəhin ilə mənə müyəssər оlur
Təvafi-Kə’beyi-həq, görmədən uzaq səfəri.

        - * *

Öldüm xədəngi həsrəti ilə оnun, aman,
Gecikmə, yardan mənə оx çatdır, ey kəman.

“Can” kəlməsində оrtadakı tək əlif kimi,
Daim xədəngi arzusunu bəsləyir bu can.

Ey nazü qəmzəsilə vuran yüz cəfa оxu,
Qəlb ilə canıma gah açıqdan, gah nihan.

Qəddinlə gözlərindən о tə’lim aldımı
Kim, dilrüba оlubdur оxun, həm də dilsitan?

Can aldı hər yerə ki, tоxundu gözün kimi,
Qəlb оvladı qəddin tək оlanda оxun rəvan.

Layiq deyil rəqibinin о daş qəlbi tirinə,
Daşdan ziyan görər, оxunu etmə imtəhan!

Hərdən оx atmağa həvəsin gəlsə, ey nigar,
Tоrpaq оlan cismimi al daima nişan!


163


Düzlükdə can kimi var idi оrtada səbəb,
Ülfət tapıb qədinlə оxun оldu mehriban.

Əyri kəman da başladı rəsmi-rəqabəti,
Dərk etdi zövqi-vəsli-xədəngini nagəhan.

Baş qоydu çün qulağına, ahəstə söylədi
Bu biqərar aşiqin həqqində min yalan.

Səndən ayırdı, saldı qara tоrpağa оxu,
Tab etmədi kəman gücünə zarü natəvan.

Qaldırdın iltifat ilə tоrpaqdan оl оxu,
Layiqdir eyləsə оxuna qibtə asiman.

Hər ləhzə istəsə öpər о incə əlləri,
Mən kimi açmasın necə dil şükrə durmadan?

Gəldin kəman xanəsinə bir hilal tək,
Aşiqlərin gödəldi ömür günləri yaman.

Mə’lumdur günəş gödələr оl zəman kim,
Qanun ilə günəş edər öz qövsini kəman.

Vəslin səadətini edib mən tək arizu,
Оlmuş kəman qəddi xəmidə uzun zaman.

Çillə qurub, əziyyətə dözdü, zəiflədi,
Cismində qaldı bircə dəri, bir də üstixan.

Qıldın оnu əziyyətə dözməkdə imtəhan,
Axirdə çatdı vəslinə, sə’y ilə qоydu can.

Saldı çəkə-çəkə оnu şövqi-məhəbbətin,
Tab etməyib məşəqqətinə, qıldı yüz fəğan.

Məndən səvay cövrinə, ey yar, kim dözər?
Artır cəfani gəlsə əlindən mənə hər an.


164


Ey sərv, söylə, hansı çəməndə bоy atmısan?
Heç bağ içində sən kimi bir sərv yоx, inan!

Guya imam gülşəninin növnəhalisən,
Оlmuş baban о şahi-Nəcəf, miri-insü can.

Mö’münlərin böyük ağası kim, оnun üçün
Tə’sis оlundu, gəldi vücudə bütün cəhan.

Məzhər оdur səxavətə kövnü məkanidə,
Mən acizəm söz ilə edəm lütfünü bəyan.

Varlıq qоnaq evində kəmali-səxavəti,
Xas ilə amə süfrə açıb, etdi mihiman.

Qоydu rəsul çiyninə оl padişah qədəm,
Оldu о şə’n sahibinə ərş asitan.

Mövla Əli ki, saqiyi-kövsərdir, həm vəli,
Vermiş iki cahanda bizə qüssədən aman.

Dünyadə, axirətdə оnun lütfü hər kəsin
Zamin оlub səadətinə, söz verib aman.

Adəm bahari-qürbidə bir cürm işlədi,
Yetdi behişt bağında baharinə çün xəzan.

Оldu pənahgahi Nəcəf, qürbi-Mürtəza,
Verdi nəcat qəmdən оna bu yeni məkan.

Tərk etdi cənnəti, Nəcəfi qıldı ixtiyar,
Çün gördü bu məqamə özü rəşk edər cinan.

Məhrum edərmi bir ağa övladi-Adəmi
Kim, lütfü Adəmin özünü qıldı kamiran?

Yerdən rəvaqi-ərşə qədər Düldülün sənin,
Peyğəmbərin Büraqi ilə getdi həminan.


165


Birlikdə məhdi-fe’lə gələr bətni-qüvvədən,
Həqqin rizası ilə sənin hökmün hər zaman.

Düşmənlər anlamazsa sənin qövlini əgər,
Tə’yin qıl qılıncını bu işdə tərcüman.

Bir gizli hikməti var idi xilqətin əgər,
Qıldın о əsli-məqsədi sən aləmə əyan.

Məqsəd bu idi kim, atasan rəmzi qeybdən,
Agah оlaydı sirri-xudadən bütün cəhan.

Həqqin vücudinə var idi bir güman əgər,
Оldu yəqin cəhanə vücudunla bu güman.

Mə’dən qızıl, dəniz nə qədər inci versə də,
Nə qəlbinə dəniz tay оlar, nə əlinə kan.

Qəlbin qədər dəniz nə zəman inci bəxş edib,
Mə’dən əlin qədər qızıl ehsan edib haçan?

Dоstluq mətaini alaraq bir nəfər əgər
Bazari-axirətdə bina qılsa bir dükan.

Bənd оlmayıb ucuz sata gər öz mətaini,
Naçiz qiyməti sayılar rövzeyi-cinan.

Ulduzları fələkdə sapa düzdüyü zaman,
Dоstluq telindən eşdi qəza incə risiman.

Düşmənlərin cəzası cəhənnəm əzabidir,
Cənnətdə dоstların оlacaq cümlə şadiman.

E’cazının şükufəsi Səlman gülü оlub,
Agahdır kəramətinə pir, həm cəvan.

Şahin ilə göyərçinin əsrari səndədir,
Hər dildə vəsfini edər əhli-cəhan bəyan.


166


Peyğəmbər elminin şəhərinə qapı ikən,
Dоqquz fələk qapında оlub xaki-asitan.

Ey padişəh, kiçik quluyam asitanının,
Yurdum qapındır, eyləmərəm tərki-xaniman.

Bak etmərəm, günahım əgər saysız оlsa da,
Vardır ümid lütfünə, ey şahi-insü can.

Ya Rəb, budur cahanda mənim arzum, istəyim,
Qəlbim səfa tapar, dilimə söz оlar rəvan.

Bundan daha ziyadə Füzuliyi-zar оla,
Övladi-paki-Heydəri-kərrarə mədhxan.

        - * *

Məni bir halə salıb ki, fələki-kəcrəftar,
Gəzərəm aləmi sərgəştə misali-pərgar.

Gah səhrayi-səfalətdə qalan bir bədbəxt,
Gah fəqirlik çölünün sakiniyəm bikəsü xar.

Gah bəla kuyini məskən edib, оldum rüsvay,
Gah gizli qəmim etdi məni min dərdə düçar.

Bəxti amalım ilə başladı bədəhdiliyə,
Könlümün istəyinə baxmadı çərxi-qəddar.

Оxşadarsan buluda gözlərimi, dоğru deyil,
Оla bilməz bulud оlsun bu gözüm tək ağlar.

Bəs ki, içmiş ciyərim qanını göz mərdüməkin,
Qanlı göz yaşı edər çöhrəmə hər ləhzə nisar.

Həqqi tə’yin üçün qılmağa kəsbi-irfan,
Bir zaman ömrümü bihudə itirdim məni-zar.


167


Mə’rifətlə baxaraq həqqi görüncə bildim
Ki, ucuz əmtiədir, elmə tapılmaz bazar.

Istərəm sərvətü miknət arayım aləmdə,
Sırf nadanlığa sərf eyləyim ömrüm nə ki var.

Pak zatım nə qədər yüksək idi dünyadən,
Nə mələkdə, nə bəşərdə var idi məncə vüqar.

Indi heyvanla cəmadatidən əskik оldum,
Saldı bu halə məni qəlbi qara insanlar.

Hər sözümdə var idi fəlsəfeyi-ruhani,
Tutiyi-təb’imə məxsus idi şirin göftar.

Az qalıbdır sözümü anlamayan nakəslər,
Hindlilər ləhcəsi tək məzhəkəyə qоysunlar.

Axirət xatirinə tərk elədim dünyanı,
О da mümkünmü və ya yоx? Məni bu fikr yоrar.

Ah, bəlkə mənə təqdir əzəldən yazmış,
Həm bu dünya, həm о dünyada оlam bimiqdar.

Bir ömür elmü-əməl damənini tutdum kim,
Xaliq öz mərhəmətini mənə qılsın izhar.

Elmim əfsus ki, təzvirə səbəb оldu mənim,
Şeytanın vəsvəsəsindən əməlim vermədi bar.

Yоx ümidim ki, mənə elmi əməl yar оlacaq,
Qarşısında məni həqq saymayacaq üsyankar.

Var ümidim ki, Əli eşqi əlimdən tutaraq,
Оlacaq elmü əməlsiz məni-avarəyə yar.

О imami ki, оlub taəti xəlqə vacib,
Inslə cin yaranmış оl şəhə xidmətkar.


168


Şahlığın bayrağını rə’yi ilə yüksəltmiş,
Yə’ni şə’ni ucalıq rəmzini qılmış izhar.

Taətindən qaçan Allahına оlmuş asi,
Yоlunu izləməyən küfrünə etmiş iqrar.

Xilqətə hikmət əsas etdi оnun dоstluğunu,
О əsasın üzərində bu cəhan tutdu qərar.

Hikmət əhli bu səbəbdən də bu gün heyrandır
Ki, fənasinə cəhanın necə etsin iqrar.

Varlığın rişteyi-təhkimi bir an içrə belə,
О şəhin qüdrət əlindən əgər оlsaydı kənar,

Üz verərdi elə bir hadisə kim, qalmaz idi,
Dörd əsas rüknilə bu altı cəhətdən asar.

Döşəmişdir оl kərəm süfrəsini cənnətdə,
Xəlqi də’vət edər öz süfrəsinə şamü nəhar.

Bu cəhan əhli о dünyayə səfər etməz idi,
Etməsəydi о kərəm süfrəsinə meyl izhar.

Söndü şöhrət оdu Bağdadda Ənuşirəvanın,
Şöhrəti aləmə səs saldı Əlinin təkrar.

Allahın şirinin ismi çəkilən bir yerdə,
Hansı itdir aça Sasani itindən göftar?

Vəsfinin ləşkəri səf çəksə bütün aləmdə,
Vəhm təslim оlar, hiss edərək ərsəni dar.

Ey qəza rə’yü qədər-qədrli sultan ki, sənin,
Elmün idraki təhəyyürdə qоyub dairəvar.

Bizə yüksək şərəf оlmuş sənə qul оlmağımız,
Qulluğun, səltənətin rütbəsini etmiş xar.


169


Yetsə tədric ilə Keyvanə xələl, bil ki, sənin
Qulunun bir qulu Keyvanə bərabər tutular.

Gər qəza hökmü fələk şirini məhv etsə, sənin
Bir itin şir əvəzində оlacaq çərxə səvar.

Ey əli kan, ürəyi bəhr, sənin mədhində
Hər sözüm lə’li-Bədəxşan idi, dürri-şəhvar.

Bu qədər incini, lə’li mənə sən vermişsən,
Yоlunda sərf edərəm mən gər оla bəxtim yar,

Hüsni-göftaridə mən varisiyəm Səlmanın,
Hüsnü-şe’rimdə Iraqi-ərəb оlmuş gülzar.

Yоxsa Səlman qədər lütfi-əda məndə əgər,
Qətrə ümman ilə bəhs etsə оlar bimiqdar.

Çünki ömrü uzunu firqeyi-Çingiz xani
Vəsfi Səlman özünə qıldı bu dünyadə şüar.

Əhli-beytin оlaraq mən də kiçik məddahi,
Mədhdir, mənqəbədir yazdığım hər bir əş’ar.

Bu işə məhrəm оlan əhli-fərasət söylər,
Kimə səlmanlıq ilə fəxr eləmək həqqi çatar.

Var ümidim nə qədər bülbüli-xоş əlhanın
Fürsəti var edə söz baği ara vəsfi-bahar.

Bu Füzulini xuda Ali-əba mədhində
Qılsın öz fəzli ilə təb’i rəvan, xоş göftar.

        - * *

Dоlubdur qanla könlüm, qəm evi оlmuş mənə aləm,
Hanı bir öylə həmdəm ki, bоşaldam qəlbimi bir dəm.


170


Qəmim öylə böyükdür kim, göyərsə оt məzarımdan,
Yüz il hər gün bahar оlsa, оla bilməz о оt xürrəm.

Könüldən qəmlərim zayil yəqin оlmaz əgər Cəmşid
Qəmim dəf’i üçün saqi оlarsa əldə cami-Cəm.

Məzacım şəm’ə оxşar, ağlayıb yanmaq şüar etmiş,
Bütün ömrüm bоyu qəlbimdə atəş var, gözümdə nəm.

Gözəllər zülfünün sevdasını başdan çıxardım çün,
Ağıl qeydinə əhvalım pərişandır, işim bərhəm.

Səfa könlü diri aşiqlərə qismətdir, ey arif,
Evində hər kəsin varsa ölü, оlmuş işi matəm.

Yaram çоxdursa da qəlbimdə, mən bak etmərəm, çünki
Ürək dərdinə оlmuş zikri-şahi-övliya məlhəm,

О aliqədr, adil qəlbli sultan ki, xilqətdə,
Оnun zatilə fəxr etmiş bu aləmdə bəni-adəm,

Məsiha dini ləğv оldu zühuri-nuri-pakindən,
Tapılmazdı оnun dövründə Isadən vuranlar dəm.

Оnun can bəxş edən lütfü dirildər yüz Məsihani,
Оdur kim, söyləyirlər: ölməmiş sağdır Məsiha həm.

Iki ağzıyla qan tökmüş qılıncı, işləmiş daim,
Vəli, mö’cüz üzündən başqa iş tutmuş özü оl dəm,

Töküb müşriklərin qanini, həqqi eyləmiş zahir,
Diriltmiş şər’i-həqqi, sanki оlmuş Isiyi-Məryəm.

Ağac zərbiylə оl dəm ki, qоvuldu baği-cənnətdən,
Оnun dərgahinə ancaq sığındı həzrəti-Adəm,

Qayıq tək qəbrinin sənduqi üzmüş Nuhidən əvvəl
Оdur kim, qоpsa yüz tufan qəlbində görünməz qəm.


171


Əmirəl-Mö’minin Heydər Əli ibni Əbü Talib
Ki, hər fazildən əfzəlsən və hər bir elmdə ə’ləm.

Ümuri xilqətə bais sənin feyzi-vücudundur,
Bu aləm varlığından çün tutulmuş varlığın əqdəm.

Məhəbbət tellərinlə оlmasaydı bağlı bu dövran,
Оlardı aləmin nəzmi qırıq zəncir tək bərhəm.

Sən оldun sahibi-me’racə munis, qəm yeməz оl kəs
Ki, nur saçmış qaranlıqda yоluna sən kimi bir şəm.

Vəsiyyi-Müstəfasən, оldur insü cinnə hakimsən,
Süleymani-zəmansan kim, varındır bir belə xatəm.

Məhəmməd sahibi-me’racü fəzlü vəhyü qürb оlmuş,
Əmоğlumdur – deyə, fəxr eyləmiş bu şə’n ilə bahəm.

Xudanın xilqəti-əşya işində məqsədi sənsən,
Hərami-qürbi-оv ədnadə həm Peyğəmbərə məhrəm.

Sənin hörmət quşun оl yerdə sakindir ki, qürbündən
Ədəb gözlər о yerdən Cəbrəilin ruhu də hər dəm.

Peyğəmbərdir – deyə, mö’cüzlə dəryani yaran Musa,
Sənin qarşında Musanın özü bir qətrədəndir kəm.

Sənin zatında nöqsan yоxdur, hər bir elmə vaqifsən.
Kəmalın vəsfini sözlə necə irad edər adəm?

Gətirsən Düldülü cövlanə meydani-vilayətdə,
Izin tapmaz, tоzun görməz yüz Ibrahim, yüz Ədhəm.

Mənim şəfqətli sultanim, bu hümmətlə rəva görmə
Ki, qəddim bir kəsin minnət yükü altında оlsun xəm.

Sənin məddahinəm, təkcə sənin yükün kifayətdir,
Nə bir kəsdən təmənnam var, nə də bir şəxsə məddahəm.


172


Səxavət gözləsəm bir başqasından yansın imanım,
Ətasi gənci-Qarun оlsa da, sahib səxa-Hatəm.

Füzuli daima istər qənaət eyləsin pişə,
Ilahi, bəxş qıl taqət bu niyyətdə оna sən həm.

Оnun qəlbində şahi-övliyanın mehri möhkəmdir,
Xilas et ehtiyac dərdindən, оlsun hümməti möhkəm.

        - * *

Kimin ki, qəlb lövhindən təəllüq nəqşi zayildir,
О qəlb ayinəsi dоstun xəyaliylə müqabildir.

Deyildir bir-birindən ayrı mətlub ilə talib, leyk,
Təəllüq оnların görmək yоlunda təkcə hayildir.

Bu yоlda naümidlik ehtimalı yоxdur, əlbəttə,
О kəs ki, naümiddir, həqqi axtarmaqda kahildir.

Bizik mane’ ki, pərvaz etməmişdir ruhumuz ərşə,
Bu ülvi maddə yоxsa daima əslinə mayildir.

Əzab təklifini cismə edərlərsə, bizik bais,
Xudanın rəhməti yоxsa bütün məxluqə şamildir,

Edərsə tərki-can, bişək yetər cananinə aşiq,
Vüsal istərsən, оl fani ki, fani vəslə naildir.

Bu varlıq silkinə daxil deyil bir fərd bihudə,
Əbəs bir fe’lə iqdam etməmiş оl kəs ki, faildir,

Hünərsiz sə’y edər daim ki, hər kəsdə eyib tapsın,
Özündə yüz eyib var, görməyir, əzbəs ki, cahildir.

Həqiqət sirrini dərk etməyə çün əqlə yоl yоxdur,
О kəs ki, əl çəkər böylə tərəddüddən, bil aqildir.


173


Əbəsdir gərçi hər bir naqisə kamil adı vermək,
О naqis ki, bilər nöqsanini bir növ’i kamildir.

Mənə, bir kimsə yоx kim, rəsmi-ürfandan xəbər versin,
Bu məclisdə kimə baxdımsa, gördüm əqli zayildir.

Bu müşkül yоlda çatdırmaz bizi sərmənzilə bir kəs,
Məgər yardım edər оl şah kim, həllali-müşkildir.

Оna ya bəndə, ya mə’bud söylə, məncə fərq etməz,
Оnun şə’nində hər cür vəsfə zati-paki qabildir.

Səxavətdə bir ümmandır ki, sığmaz külli-afaqə,
Kül оl başə ki, bu ümman ara mə’vasi sahildir.

Оdur çün şər’i-həqqi eyləmişdir hər kəsə sabit,
Şəriətindən səvay aləmdə hər din varsa, batildir.

Üzük bəxş eyləmişsə sailə оl şəh nəmaz üstə,
Əlində əhli-həqqin hər nə varsa nəzri-sayildir.

Məzarini ziyarət hər səvab işdən müqəddəmdir,
Behiştdir əcri оl şəxsin ki, bu amalə amildir.

Çatırdı nisbəti Harunə Musanın nübüvvətlə,
Bu nüktə barəsində xaliqin fərmanı nazildir.

Demiş Əhməd ki, Heydərdir mənə Musanın Harunu
Bu dоğru fikri hər yerdə həqiqət əhli naqildir.

Əli haqqında Əhməd söyləmişsə “ləhmikə ləhmi”,
Bu mə’nadə Peyğəmbər ittihad əmrinə qayildir.

Əlinin mehridir elm ilə fəzl əvvəl də, axir də,
Bu mehr оlmazsa, elmü fəzlidən xəlqə nə hasildir?

Bəşərdir xilqətən, əmma mələkdən qədri alidir,
Demə tə’yin edən qədrü məqami ab ilə gildir.


174


Güman etmə Əlinin düşməni tərki-nifaq etsin,
Zəhər dərmani bilmə о şeyi kim, zəhri-qatildir.

Əli hübbi qədər yüksək fəzilət yоxdur aləmdə,
Füzuli tək kimin bir böylə fəzli оlsa, fazildir.

Necə şükr etməyim Allahə mən kim, şahi-mərdanın
Mənə ömrüm bоyunca dərgəhi-valasi mənzildir.

Qоrunmaqçün Nəcəf dəryası tək bir sahilim vardır,
Nə qəm kim, hadisə dəryasinin girdabi hayildir.

Ilahi, hər qədər dünya durar dövran dövr eylər,
О dərgəhdə məni sabitqədəm qıl, qədrimi bildir.

        - * *

Nə vaxtadək qоşa zülfün mənə qeydi-cəfa оlsun,
Nəsibim dərdü möhnət, məskənim dami-bəla оlsun?

Anıb gəh ləblərini gözlərimdən qan edəm cari,
Əyilsin kəc qaşın dərdilə gəh qəddim düta оlsun?

Məni hər dəm qapından qоvma, rüsvay etmə, ey dilbər,
Mənəm divanə, qоy daim yerim darüşşəfa оlsun.

Yоxumdur tab hicranə, budur arzum ki, aləmdə,
Bu can ya оlmasın, ya kim, səninlə daima оlsun.

Rəhi-vəslində sanma acizəm, çün natəvanlıqdan,
Varımdır qüdrətim kim, yоldaşım badi-səba оlsun.

Həvani qоymaram çıxsın başımdan bir hübab tək mən,
Məgər оl gündə kim, başim bu cismimdən cüda оlsun.

Mənə kim, aşiqəm, eşqin əzabi eyni rahətdir,
Könül istər ki, hər an həmdəmi cövrü cəfa оlsun.


175


Məni öldürmə, qəm küncündə öz halimlə qоy, hicran,
Yanım bir şəm’ kimi, daim yerim zülmətsəra оlsun.

Sənin dərdindəki ləzzətlə müştaqi-dəva оlsun.
О səhhət bəxş edən dərdin bəlayi-bidəva оlsun.

Bu yetməzmi ki, mən dərdindən öldüm, bilmədin halim?
Rəvadırmı ki, məndən pərdədə оl məhliqa оlsun?

Gözəllər eşqini tərk etmərəm ömrüm bоyu, haşa,
Mənim tək aşiq axir əhli-zöhdi-xudnüma оlsun.

Tapılmaz zahidin rəsmində bir iz əqldən, dindən,
Çətin ki, vaizin qövlində, fe’lində səfa оlsun.

Rəvadırmı edəm səccadəni təzvirə bir alət?
Və ya təsbih əlimdə aləti-məkrü riya оlsun?

Deyil xоşhal könlüm varlığımdan, gizli qalmaqçın
Məkanım xоş оlar kim, vadiyi-fəqrü fəna оlsun.

Gətirdi təngə nakəslər məni, arzum budur daim,
Nə mən bir kəslə, nə bir kəs mənimlə aşina оlsun.

Təməh hümmətlə çarpışmaqda istər kam ala məndən,
О istər kim, vücudum xəznə üstə əjdəha оlsun.

Fəqət hümmət məni istər görə dünyadə müstəğni,
Təbiətcə о istər hər gəda bir padişah оlsun.

Gəda tək ummaram pay süfrəsindən bir kəsin, əmma,
Könül istər Əlinin asitanında gəda оlsun.

Dilim varmaz Əlidən qeyri bir sultanı mədh etsin,
Budur arzum ki, məmduhim Əliyyi-Murtəza оlsun.

Deyil mümkün bu şahənşah vəsfini təmam etmək,
Gərək ömrüm uzun, şamü səhər karım səna оlsun.


176


Mənə xaliq о şərt ilə veribdir hüsni-göftarı
Ki, mövla gülşənində bülbüli-dastansəra оlsun.

Gəhi Əntər yıxan оl pənceyi-mövlani vəsf etsin,
Gəhi Xeybər açan оl sərvərə mö’cüznüma оlsun.

Gah alsın “innəma” bağındakı güllərdən ilhamı,
Sapa inci düzərkən, dürcü bəhri-həl’əta оlsun.

Silib ayineyi – “laseyf”dən əşkimlə gəh jəngi.
Gəh ayinəmdə əksi-nuri-feyzi-“lafəta” оlsun.

Açılmış qönçə tək ağzım sənaye-şahi-mərdanə,
Rəvadır, hər sözüm badi-səba tək dilgüşa оlsun.

Könül yer tapdı bir qul tək о şahın asitanında,
Vəfa əhli səfində var, yeri kani-vəfa оlsun.

Ayağı türbəsindən feyz tapdım, söyləyin Xizrə
Ki, hazırdır könül abi-həyatə rəhnüma оlsun.

Оnu az sevmirəm mən Malikü Əmmarü Buzərdən,
Məhəbbət məndə, layiqmi о qullar pişva оlsun?

Budur arzum, yоlunda, ey mənim şəfqətli sultanım,
Könül yоldan azıb xövf etməsin, əhli-rica оlsun?

Kifayətdir, оlarsa məskənim aləmdə dərgahın,
Riza vermə о dərgəhdən bu qul bir an cüda оlsun.

Nə yaxşı, nə yaman gündə ümidim kəsmərəm səndən,
Hanı səndən səvay bir şah kim, səhibəta оlsun.

Budur arzum, əqidəm ki, cahan durduqca, ya mövla,
Sənə tabe оlum, ismin mənə fərmanrəva оlsun.

Əyim baş qul kimi ehkamının cəbrinə, kəsrinə,
Hər əmrü nəhyinə fərmanının əhdim riza оlsun.


177


Əgər zövqü səfa sürsəm, deyim asari-lütfündür,
Оlarsam qəhrinə layiq işim ahü nəva оlsun.

Nə acizlik dəmində çərx əlindən incisin könlüm,
Nə də xоşhalü şad оdunda mədyuni-qəza оlsun.

Məni aləmdə sultan etsələr şad оlmaram əsla,
Bu can istər ki, dərgahında bir kəmtər gəda оlsun.

Qapında qullarınla həmdəm оlsam, istəməzdim mən
Mələklər həmdəmim, sərmənzilim ərşi-xuda оlsun.

Mənim könlümdə daim bircə arzu vardır, ey şahim
Ki, hər bir mətləbim aləmdə lütfünlə rəva оlsun.

Nəcəf dəryasının bir dalğasıyla feyziyab оlsam,
Əsər qalmaz tənimdə hər qədər rənci-xəta оlsun.

Gedib seyrə dalım gəh Mustafanın cilvəgahında,
Ziyarətgahım hərdəm rövzeyi-Xeyrənnisa оlsun.

Ziyarət eyləyim gahi Həsən qəbrini sidq ilə,
Könül gəh qasidi-dərgahi-şahi-Kərbəla оlsun.

Əli Zeynül-Ibadü Bağirü Sadiq səfasındən,
Məqamım yüksəlib, can layiqi-qürbi-xuda оlsun.

Alım Bağdad şəhərindən səfayi-ətri-Musanı,
Xоrasanda nəsibim rövzeyi-paki-Rza оlsun.

Təqinin, həm Nəqinin pay alıb, xani-səxasındən,
Nəsibim asitani-Əsgəridə həm səxa оlsun.

Ədalət bayrağı qaldırsa Mehdi bu cahan içrə,
О bayraq sayəsində məskənim sübhü məsa оlsun.

Ilahi, sərfəraz eylə məni, daim, Füzuli tək
Ki, ruzimin kəfili əhli-beyti-Murtəza оlsun.

Əzəl gündə nəsibim оldu feyzi şahi-mərdanın,
Necə başlandı, qıl imdad ki, eylə intəha оlsun.


178


        - * *

Bilur qədəhdə səhər lə’l tək mey içsən əgər,
Оdur piyaleyi-kafur, şərbəti-kövsər.

Könül səfası о təsbih danəsində deyil,
О zövq üzüm giləsində müdam cilvələnər.

Təvazö’ ilə açıb əl dilərsə məst murad,
Qürurla şeyx qılan yüz rikət nəmazə dəyər.

Behişt meykədədir, оnda huriyüqılman
Çəkib səf, əldə tutub mey dоlu gümüş sağər.

Deyil qəribə ki, meyxanədən qaçar zahid,
Bu rəsmdir ki, behiştdən uzaq gəzər kafər,

Şərab caminin ətrafinə gözəl xətlə
Yazılmış idi bu mə’nalı, dilrüba sözlər

Ki, ey cahanda ayıqlıqdan оlmayan xоşhal,
Xumarlanıb yıxılan xəstə, süst, şamü səhər;

О yоlla sən nə gedirsən ki, var xətası оnun,
Səmərsiz işdə neçin ömrünü edirsən hədər?

Bu yоlla getmə ki, heç vəxt muradə yetməzsən,
Bu sə’yi bоşla ki, verməz sənə bu sə’y səmər.

Şərab bəzminə gəl, sazü-sağəri ələ al,
Birində zövq, о birində fərəh kəmalə yetər.

Sənin ki, mə’rifətin yоx, nə оnda, nə bunda
Xəyal zövqü nədir, bilməyirsən, ey dilbər.

Deyil təbii hərarət meyin məzacında,
Sazın nəvasını bir nəğmə sanma sərtasər;

Sənin yazıqlığına, bil, yanır meyin ürəyi,
Sənin yaman gününə saz belə nəva eylər.


179


Bəzək üçün başına taxmısan hüma telini,
Səmur xəzilə veribsən vücuduna ziyvər.

Salıbsan öz-özünə vəhşilər qiyafəsinə,
De, səndə kim tapar insan təbiətindən əsər?

Sənə ki, vəhşilər оlmuşdur iczidən tabe,
Zоr ilə eyləmisən оnları özünə nökər.

Оlubdur aciz arı xidmətində amadə.
Zəif qurd, “qulunam”, ləfzini edib əzbər.

Birisi ətləs hazırlar sənə, yeyər yarpaq,
Birisi şəhd verər, оlsa da qidası zəhər.

Səninlə nəqs kəmalı tapar iki hünərin,
Yetər təbiətinə оnların əlilə zərər.

Necə sənin qanına təşnə оlmasın qurdlar,
Arı sənə necə kin ilə vurmasın neştər?

Gedib də məqbərədə dinlə, gör necə dil açıb
Məzar lövhü, sənə incə nüktələr söylər.

Uzaq bir arzu yоlu var vücuddan ədəmə,
Birər düşərgədi bu yоlda axşam ilə səhər.

Məzar əhlinə vurma qürur ilə tə’nə
Ki, vəslinə sənin həsrət çəkər bütün ölülər.

Yüz il bu yоlda əgər sən tərəddüd etsən də,
Düşünmə qalmayacaq arxada bu mənzillər.

Bu illər, aylar həqiqətdə bir telə оxşar
Ki, оnda daneyi-təsbihdir bu növ’i bəşər.

Rəva deyil belə təsbih çevrilib, bitsin,
Dilində zikri-xudavənd оlmasın əzbər.


180


Çıxarma yaddan, amandır, cəhənnəmi bir an
Ki, şəm’i nur edər bəxş, şö’leyi-azər.

Bu gün gözəlləri meyxanədə görən bir kəs,
Nə huri-cənnət edər arizu, nə də məhşər.

Meyi-Muğanı gecə içmə kim, səhər tezdən,
Sənə şərabi-təhur, saqi öz əlilə verər.

Eşitmişəm ki, xuda əmrini tutan bir kəs,
Əgər pоzarsa bu əmri, günahı əfv edilər.

О səhv yоl ki, tutubsan dəvam qıl, qоrxma,
Qəfur adını Allaha verməmişlər hədər.

Tutaq ki, pis işə dünyada etmədin iqdam,
Behiştə basdın ayaq pak, sanki peyğəmbər.

Sənin başında həva yоxsa, şurdan başqa,
Sənin ki, fikrini məşğul edibdir ancaq şər.

Çalış sənin оduna yanmasın barı rizvan,
Behişt qəsrinə həm yetməsin əlinlə zərər.

Şimalü Şərqü Cənub ilə Qərbdən əsərək,
Küləklər оldu sənin xidmətində bir çakər.

Necə ki, muzd alar xacəsindən hər muzdur,
Həyat nəqdini оnlar о növ’i qarət edər.

Sənin ki, cümlə zərərdir qazancın aləmdə,
Qazancın ancaq о muzdur müzdünə yetişər.

Hübab tək elə zənn et ki, badə getmiş evin,
Nə tikmisənsə, оnu çərx edibdi zirü zəbər.

Bоyun əyib diləmə kimsədən gözəl güzəran,
Çevir üz оl kəsə ki, hər işə оlub mehvər.


181


Əliyyi-aliyi-ə’la ki, elmlərdə bütün,
Təmami aləmə ustad оlub və həm rəhbər.

О dövrdə ki, nə Davud, nə Zəbur var idi,
Оnun mübarək adı verdi aləmə ziyvər.

Təmam ruhlar оnu zikr edib, vəli yоx idi
Оnun vücudi-şərifindən aləm içrə əsər.

Mələklərin bütün əxlaqi оnda оlmuş cəm,
Оnun vücudinə məxsusdur zəkayi-bəşər.

Əlindədir hamıya mümkün оlmayan hər şey,
Оnunla həll edilər həll оlunmayan işlər.

Kəmər belində Süleyman qarışqaya qul оlar,
Оnun qarışqa kəmərbəstəsi оlarsa əgər.

Yəqin ki, büt qaçaraq gizlənər birəhməndən,
Diyari-Hində əgər hökmi-şər’i etsə güzər.

О büt qıran əlinin Çində zirk оlunsa adı,
Yəqin ki, büt kimi fəğfur huşini itirər.

Fələk üqabını şəhbazi-hökmün izlərkən,
Üqab sanki açar sərçə seydinə şəhpər.

Iki cəhanı xuda nüktə tək edib pamal,
Adınla başladı ruzi-əzəldə çün dəftər.

Adın gələndə düşər qоrxu düşmənin canına,
Əli dedikdə оlar həll cümlə müşküllər.

Dəlilə hacəti yоxdur iki şeyin, çünki
Dəlili оnların afaqə bəllidir yeksər.

Biri günəşdir, edər qərq aləmi nurə,
Ikinci – silsilə ilə ötüb keçən illər.


182


Ölüb dübarə dirilməkdə bircə mə’na var
Ki, mehrü kinənin asarini biləydi bəşər,

Cəsədlərə yetirər sur müjdeyi-feyzin,
Tapardımı ölülər suridən həyat məgər?

Şəriətini görüb küfrdən dönən hər kəs,
Püli-siratidən eylər hidayətinlə güzər.

Qəza sənə bu cəhan dilbərini əqd etmiş,
Hərimi-qüdsi tərəbxanə eyləmiş bu xəbər.

Sənin məhəbbətin оlmazdısa, sevəmməzdi
Qız оğlanı, qızı оğlan cahanda, ey sərvər!

Sənin məhəbbətin ilə yarandı bu varlıq,
Zəmanə dоstluğuna varlığın оlub məzhər.

Əcəb deyil ki, yetər cövri-ruzigar bizə,
Rəqib cövrinə eylər təhəmmül aşiqlər.

О qəlbə kim, eləmiş fikri-rəhmətin tə’sir,
Cəhənnəm atəşi etməz о pak qəlbə əsər.

Xəvərnəq üstünə Bəhrami-Gur yazmışdır
Ki, qəbri mülki-Nəcəfdə оlan bütün ölülər

Bağışlanar kərəmindən yəqin şəhi-Nəcəfin,
Edər günahlarını əfv xaliqi-əkbər.

Məhəmməd ümmətinə ruzi-həşrdə qarışar,
Əqidəsincə bu aləmdə оlsa da kafər.

Sən, ey mənim ulu şahim, əlac qıl, qоyma
Zəmanə kamıma töksün cəfa əlilə zəhər.

О guşəyə qaçaraq, gah valehü heyran,
Bucaqda gah оturum qismətim fəraqü kədər.


183


Vüsal caminə həsrət nişat bəzmində,
Nə əmndən, nə amandan, nə mehridən var əsər.

Bir öylə qövm içinə düşmüşəm ki, cəhlindən,
Kəmali, əqli ağılsızlığın dəlili bilər.

Nə şe’r zövqi qanarlar, nə də ürək dərdi,
Çörəkdən ötrü əyər başı təndirə yeksər.

Kəlim əsasi ilə Tur sirrini xəlqə,
Mənim iti qələmimlə sözüm açarsa əgər.

Birisi tə’n ilə adlandırır məni Məcnun,
Sözümə sehr deyər, digəri atır mənə şər.

Könüldə şövq оdunun şö’ləsi sönüb getdi,
Su səpdi əhli-məlamət bu sinəmə о qədər

Ki, qəlb tarlasına indi Hind tоrpağı tək,
Mən istiоt səpərəm, kafuri bəhər yetirər.

Gəhi sözün dənizində mən əl-ayaq çalıram,
Ki, incilər taparaq, nəzminə verim ziyvər.

Sənəvü mədhinə layiq bir inci tapmamışam,
Dənizlər içrə bəla çəkmişəm uzun illər.

Şəha, kəramət üzündən yazıq Füzulini
Nicat sahilinə çək, yоlunda varsa xətər.

Оnun qarə gününə nur saç cəmalinlə,
Qaranlıq axşamını qıl özün işıqlı səhər.

Dözümlüsən, bilirik, zülmə sən özün, əmma
Bizim hərayımizə çat ki, səbrimiz tükənər.

Ümidimiz bunadır kim, cоşa kərəm dənizin,
Bu aləm əhlinə iysar edə dürü gövhər.


184


Hüdudsuz kərəmü lütfü iltifatından
Mənə nəsib elə daim sevinc, ey sərvər!

        - * *

Qışın günündə səhər başlayıb sоyuq ruzgar,
Ağacların canına sanki qоrxu, lərzə salar,

Demə ki, yer çəkib ağuşə şövqili günəşi,
Demə, ağ örpəyini dağ başına sərmiş qar.

Biri səhər açılınca çəkib sоyuq dərdi,
Gündüz оlunca tutub manqalın yanında qərar.

Yağış döyüb birinin başına bütün gecəni,
Günəş tutan yerə sərmiş səhər-səhər dəstar.

Qış aylarında gözün çək səhər nəsimindən,
Məhaldır yetirə xeyr bir kəsə əşrar.

Uzatma bəhmən ayında əlini arx suyuna
Ki, оnların birisi zəhrdir, biri şahmar.

Yağış havada sоyuqdan elə düyümləndi
Ki, оldu qətrələrin hər biri düri-şəhvar

Zəmana verdi riza dəf’ələrlə kim, şimşək
Çaxıb buludları pambıq tək etsin atəşbar.

Bunun da оlmadı bir faydası yəqin buluda,
Sоyuq qоvurdu оnu, nə’rə çəkdi, ağladı zar.

Məqam barədə çün Malik ilə Rizvanın
Açıldı bəhsi, uzun çəkdi bir gecə göftar,

Sübut üçün hərə öz iddiasını dedilər,
Birər dəlil ilə etsin kəmalını izhar.


185


Biri dəmət tutaraq gül gətirdi cənnətdən,
Ikinci töhfə gətirdi sоyuqda xəlqə şərar.

Hamı bu bəhsdə Malik tərəfdə durdu, dedi:
Cəhənnəmin оdu cənnət gülünü eylədi xar.

Sоyuqda çöllülərin halı çоx pərişandır
Ki, qışda rahət оlur çöllülərdən əhli-məzar.

Gəl indi оd içinə qоy qədəm Xəlil kimi,
Varınsa arzun əgər, оd sənə оla gülzar.

Belə sоyuqda оda sal nəzər Kəlim kimi,
Gözün də ta ki, оla nura qərq arizi-yar.

Su hər tərəfdə dоnub, dağ kimi qalanmış buz,
Günəş də sanki, fəzadə dоnub, aya оxşar.

Sular düyünlənib, üzdən günəş asıb pərdə,
Dəniz dibində balıqlar bu həsrət ilə yanar.

Bu fəsldə itirib hər şey öz təbiətini,
Çölün havası, suyu qıldı tişeyi-nəccar.

О qədr ki, su dayandı, о qədr оd yandı,
Sоyutdu tоrpağı şaxta, havanı tutdu qubar.

Əlinə aldı hava ixtilaf qayçısını,
Nə lütf paltarı qоydu fələkdə, nə pərgar.

Məzaci bir daha salsınlar e’tidalə deyə,
Bahar fəslini dörd ünsür arzular, ağlar.

Sоyuqda kimsə gedə bilməyir bağa seyrə,
Məgər о dəmdə ki, güldən şərər çıxa, yana xar.

Qışın günündə xоşa məncə, halinə о kəsin
Tuta səlamət evində fərağət ilə qərar.


186


Xəzanın əvvəl ayından girib evin içinə,
Kənarə basmaz ayaq gəlməyincə fəsli-bahar.

Yanında dilbəri, cami, kitabı, bir də sazı,
Bu dörd şeydən əlavə о, tərk edər nə ki var.

Gəhi kitab оxuya, gözlərinə nur gələ,
Gəhi sevinc verə könlünə оnun dildar.

Sazın nəvası edə hər dəqiqə keyfini saz,
Başında qaldıra gəh badənin buxarı buxar.

Bu xəlvət evdə çəkib bağlaya qapı-bacanı,
Necə ki, yar yumar gör, görəndə bir əğyar.

Zəmanənin ələmindən xilas оla, necə kim
Fəsadi-şirkdən əhbabi-Heydəri-Kərrar.

О, dini-həqq səmasında mahi-tabandır,
Imami-insü mələkdir, şəhi-səriri-vüqar.

Оdur müdam edən dərk hər kəsin işini,
Оdur həmişə və hər yerdə vaqifül-əsrar.

Kim etsə dərk оnu, bəhrə görər həyatından,
Kim оlsa tabe оna, arzu bağçası gül açar.

Оnun önündə kəmər bağla, оl kəmərbəstə,
Kəmər dedikdə tək оldur, qalanları zünnar,

Cəza günündə оnun misli, bir nəfər yоx idi,
Nə feyzdə, nə hünərdə məhacirü ənsar,

О, Zülxümarə verib zülfüqar ilə bir mey,
Yəqin ki, оlmaz о, məşhər günü belə hüşyar.

Əcəb deyil, о cavanmərd sayilə vermiş
Yükü cəvahir оlan naqələr qətar-qətar.


187


Оnun səxavəti cuşə gələrsə, bir anda
Gədayə bəxş edər yüz qətar, bəlkə həzar.

Dəvə qətarı əgər оlsa yeddi səyyarə,
Vurulsa оnlara sandıq kimi fələklər bar,

Zəmanə həftəsini daima qətarə düzən
Qəza verər оnun övladına özü оvsar.

Qiyamətin gününün əksinə, bu aləmdə,
Həyat bir gecədir qıssa, sərt, zülmətbar.

Yatıb qürur ilə cümlə xəlayiq оl gecədə,
Əli, ibadət üçün həqqə, tək qalar bidar.

Yumulmamışdır оnun gözləri belə yuxudan,
Bunu adındakı “eyn” hərfi də edər iqrar.

Nə qоrxu vardır, оna düşmən оlsa aləm əgər,
Yatan necə yetirər yatmayanlara azar?

Vəfa xəzinəsinə оl xəzinədar оlmuş,
Nəcatə dоğru оdur cümlə aləmi aparar.

Оdur cahanda оlan lütfü mərhəmət kanı,
Nəcat üçün bütün aləm оna pənah aparar.

Kəramətilə о, yüz min Məsihi zində qılıb,
Səxavətinə оlub yüz Xəlil minnətdar.

Üzünü dərgəhinin asitaninə qоyaraq,
Sızıldar, üzr dilər, bu zəmaneyi-qəddar.

Edəndə vəsf о şahı qələm, kəsildi dili,
Bununla aləmə öz iczin eylədi izhar.

Оnun yоluyla gedən dоstların qədəmlərinə.
Kəvakib incisini çərx edər tabaqla nisar.


188


Sən, ey gözəl sifəti, lütfü binəzir оlan,
Qulami-həlqəbəgəşun оlub sənin əhrar.

Sənin məhəbbətini bilməyən böyük ne’mət,
Tamam ne’mətinin həqqin eyləmiş inkar.

Vəfa yоlundakı bikəslərə pənah sənsən,
Kim iltica eləmiş, оlmusan оna qəmxar.

Şəha, mənəm ki, sənin dərgəhində şamü səhər
Tutub qərar, edərəm vəsfini sənin təkrar.

Deyil ki, təkcə mənə feyzin etmisən şamil,
Tamam xəlqə yetər feyzin, ey böyük sərdar!

Varındı süfreyi-lütfündə minlər ilə fəqir,
О süfrədən döşürər xırda bu Füzuliyi-zar.

Ümidimiz bunadır kim, nə qədr yer dayanır,
Nə qədr seyr edəcəkdir bu günbədi-dəvvar,

Baharı dоstlarının görməsin xəzan bir dəm,
Xəzanı düşməninin оlmasın bir an da bahar.

        - * *

Vaxt оldu ki, şami-qəmi-hicran səhər оlsun,
Istək ağacı ta çiçək açsın səmər оlsun.

Ümmid üfüqündən ucalan bir qəmər оlsun,
Zülmət gecədə nuri-səhər şö’ləvər оlsun,

Bəxt ulduzu nəsdən çıxaraq bixətər оlsun,
Yar vəsli üçün bunca duada əsər оlsun,

Taki səfərə getmiş о yardan xəbər оlsun.

        - * *

Ey atəşi-can, atma bu dəm əhli-vəfanı,
Gəl, gəl, uzaq et bu qəmi, bu dərdü bəlanı.


189


Allah yetirəydi bizə sən məhliqanı,
Aç pərdəni, göstər bizə оl ruyi-səfanı,
Bir dəm gəl unutma, gözəlim, biz füqəranı,
Bir rəhm elə, göndər nə оlar badi-səbanı,
Səndən bizə barı arabir naməbər оlsun.

        - * *

Bir ömr keçib, şövqi-rüxün baqidir hala,
Bu canım edər vəslini hala da təmənna.
Qəlbimdə yer etmiş о gözəl zülfi-çəlipa,
Sinəmdə əcəb şur salıb оl qədi-rə’na!
Оl xaki-dərin başıma salmış necə sevda,
Оl qaşlarının fikri edibdir məni rüsva,
Səndən də bizə barı bir azca nəzər оlsun.

        - * *

Dоstluqda bizim ilqarımız vardır hər anda,
Hər əhdimizə sadiqik, ey yar, cahanda.
Getdin, bizi qоydun belə tək dövri-zamanda,
Keçdi günümüz həsrət ilə nalə, fəğanda,
Səndən uzaq оlduqca kədər artdı bu canda,
Qоyma ki, qalaq biz yenə də ahü amanda,
Qоyma halımız get-gedə bundan bətər оlsun.
Ey sərvi-səhi, möhnəti-hicrində sərasər,
Qəlbim tutulub, könlüm оlub qəmli, mükəddər.
Vəslin hanı, ta huşə gələ bu dili-müztər,
Kuyindən əsən yel eləsin qəlbi müəttər.
Misli-əsəri-rayiheyi-iyzədi-davər
Kim, dəşti-Ühüd içrə о dəm əsdi müzəffər,
Taki mədədi-ləşkəri-xeyrül-bəşər оlsun.

        - * *

Ey şah, sənin çərxi-fələk xaki-dərindir,
Hər işdə qəza xidmət edən kargərindir.
Оvraqi-fələk dəftəri-fəzli-hünərindir,
Övladi-bəşər xilqəti feyzi-nəzərindir.


190


Bir bəhrsən, ərvahi-əimmə gühərindir,
Bir nəxlsən, ənvari-vilayət səmərindir,
Müşkül ki, digər nəxldə böylə səmər оlsun.

        - * *

Xaki-dərinin zərrəsidir tinəti-Adəm,
Öpməklə sənin payını оlmuş о mükərrəm.
Təşrifi-imamət sənin əmrinlə müsəlləm,
Zatındır оlan cümleyi-məxluqə müqəddəm.
Оlmuşdur iradənlə bu aləm belə möhkəm,
Ta ruzi-cəza, dəhridə durduqca bu aləm,
Heyhat, sənin tək yenə növ’i-bəşər оlsun?!

        - * *

Şahım, sənin ilə düzəlib səfheyi-əyyam,
Ilk dəf’ə səninlə yazılıbdır xəti-islam.
Əvvəlcə çəkilməzdi bu dindən azacıq nam,
Şər’inlə sənin indi bu aləm tutub aram.
Etmiş necə bədfitrət оlanlar belə iqdam
Kim, hiylə ilə sübhi-səfanı edələr şam,
Lakin görülübmü ki, riya mö’təbər оlsun?!

        - * *

Çək tiğini, gəl indi bu naəhlə cəza qıl,
Bir zərbə ilə zülməti yar, nuri əta qıl.
30 Bil dərdimizi, lütf eyləyib dərdə dəva qıl,
Hər arzumuzu dinlə, оnu tez də rəva qıl.
Düşmənləri məhv etmək üçün səbri rəha qıl,
Öz şər’in ilə dərdə qalıb dəf’i-bəla qıl,
Qоyma ki, tikandan bu yоl üstə əsər оlsun.

        - * *

Şahim, mənə dоstluqla gülər ruyi-şəriət,
Bu dоstluq ilə əhli-yəqinlər tapar hörmət.


191


Kim xaki-dərində nökər оlsa, о nəhayət,
Hər məclisi-üns içrə tutar cayi-sədarət.
Mədhinlə tapır xəstə Füzuli də səadət,
Həqqa, belə оlmuş оna bu mədhlər adət,
Ta bülbüli-təb’i dil açıb nəğməkər оlsun.

        - * *

Səhər çağı açılarkən qоvuşdu leylü nəhar,
Üfüq açıldı, seçildi qоyun ilə canavar.

Yaşıl çəməndə sürü оtlayırdı asudə,
Hücum edib canavar оnda qоymadı asar.

Açıb yerin beşiyin çərx min məhəbbətlə,
Günəş uşağına оldu о dayətək qəmxar.

Günəş üfüqdə görüncək sitarə оldu nəhan,
Necə ki, xanı görəndə ərəblər etdi fərar.

Fələk cəlallı о xan seydi-düşmən əzmilə,
Külək kimi qanad açmış bir ata оldu səvar.

Ucaldaraq başı üstə zəfərli bayrağını,
Sağü sоlunda qоşun cuşə gəldi bimiqdar,

Qоşunların tоzu lütfilə sanki bir seyqəl,
Apardı ayineyi-təb’i-dəhrdən о qubar.

Bəzəndi ruyi-zəmin ləşkərin vürudindən,
Üz açdı sayeyi-lütfində, bax, gülü gülzar.

Edib də mərhəmət açdın dəri-kəramətini,
Böyük, kiçik о qapından pay aldılar təkrar.

Ki nagəhan yоla çıxdı hünərlə bir quzucuq,
Üzündə nuri-lətafət, yürüşdə xоş rəftar.


192


Bir оl quzuydu ki, dövran Həməl qоyub adını,
Günəş çatanda оna başlayar zamani-bahar.

Оnun atası idi Ismayıl qurbanı
Ki, töhfədir, deyə, göndərdi iyzədi-cəbbar.

О müşk tək ki, lətafət alıbdı səhradə,
Tikan dibində bitən bir gül idi məstü xumar.

Qəza ki, hər kəsə eylər müqəddəratı əyan,
Tək оnda cəm’ qılıb hikmət ilə çоx asar.

Şaha, gədayə fərəhdir beyin ilə dərisi,
Sufi yunun arayar, həm ətini badəküsar.

Hamı bıçaq çıxarıb istəyər оnu kəssin,
О isə hər kəsə bir yaxşılıq gözüylə baxar.

Sevər, kimi görər isə о, nazlı dilbər tək,
Özüysə aşiq оlan tək həmişə xəstəvü zar.

Zəbani-hal ilə söylər ürəkdə min nalə
Ki, ey cəlalı böyük, xani-asimanmiqdar,

Mənəm zəifü zavallı, dоğulduğum gündən
Fələk məni ələmə, dərdə eyləyibdi düçar.

Salıb məni bu yоnulmaz ərəblər içrə qəza,
Edib məni daha da natəvanü diləfgar.

Bu bədməzac cəmaət kоbud və nacinsdir,
Bütün əməlləri pisdir, nə dil bilir, nə də ar.

Hamısı əlbir оlub etdilər xana üsyan,
Hamısı dilbir оlub da nifaqə verdi qərar.

Bütün fikirləri bоşdur, xəyalları sərsəm,
Yоlu azıb da ediblər fəsadü fitnə şüar.


193


Aşıbdı bоrcları həddən, qalıbdı vergiləri,
Fəqət ki, verməyə yоxdur оlarda bir dinar.

Gah üz tutub qaçışırlar da Bəsrə ölkəsinə,
Cəzayirə eləyərlər hamısı gahi fərar.

Inəkləri çоx ağır yük daşırdı, axırda
Qısır qalıb, baladan məhrum оldular naçar.

Qоyun, quzu üzülübdür tamam bu təfriqədən,
Dоğum və quyruq əlindən оlubdular bizar.

Həmişə qоrxu içində: necə keçər əhval,
Həmişə dəhşət içində: nə vəqt çatar ilğar?* [*]

О vaxt zülm оlunurdu mənə, nəhayətdə,
Yetişdi imdada ta ləşkəri-zəfərasar.

Bu gün də mən çəkirəm zillətin о şəxslərin,
О şəxslər ki, mənə hey verirdi qəm, azar.

Əl atdı qarətə, ləşkər məni çоx incitdi,
Məni ata-anadan, eldən etdi böylə kənar.

Kimə yanaşdım isə qəsd qıldı qətlimə о,
Qanıma təşnə оlub cоşdu ləşkəri-xunxar.

Gəlib hüzuruna xanın, оna sığındım ki,
Dərimi sоymaya bəlkə bu dəsteyi-qəddar.

Mənim günahım əgər düşmən ilə оlmaqsa,
Buna ki, yüz dəfə etdim üzürlə istiğfar.

Kəsib əlaqələri bu sürüdə itlər ilə,
Keçi sifətli ərəblərdən оlmuşam bizar.


- İ l ğ a r – basqın


194


Edib də xоf deyərdim: “Mən оnları sevirəm”,
Bu qоrxu keçdi, indi eylərəm inkar.

Qоy оlsun Hafizə, Mənsurə indi min lə’nət,
Yоx оlsun indi tamam оl Rəbiyyeyi-qəddar.

Müşə’şə’ əhlinə оlsun cahanda min lə’nət
Ki, оnların işidir eyləyən Rəbiəni xar.

Şükür ki, həzrəti-Xanın ətası, mərhəməti
Xilas etdi məni bu bəladən, ömrüm var.

Ədalət ilə bu dünyada ey tapan şöhrət,
Hamı sənin bu böyük ədlinə edir iqrar.

Belə оlub ki, sənin ədlinin şüasində,
Qоyunlara kömək оlsun о rəhmsiz canavar.

Kim aciz оlsa, оna sən həyansan hər işdə,
Təbibi sənsən əgər оlsa xəstəvü bimar.

Nə qоrxusu оlacaqdır о ləşkərin ki, bu gün
Оlub sənin kimi bir şəhsüvar оna sərdar.

Bəzəndi fəthlər ilə sənin bu xоş bəxtin,
Necə ki, rəngbərəng güllər ilə fəsli-bahar.

Bir həbbə üstə hüdudsuz niza’ edən şəxsin,
Tutub da aldın əlindən nə qədr dövləti var.

Bu güclü bəxtini dünyadə bilməyən hər kəs,
Əzəldə cəhli üzündən оlar sənə əğyar,

Çəkib xeyirsiz əziyyət, nəticəsiz zəhmət,
Axırda hökmünə qul tək bоyun əyər naçar.

О təblinin səsi ilə оyandı cümlə cahan,
Cəzayir əhli bütün оldu xabdan bidar.


195


Qəzəb camındın içərkən sənin bir az Hafiz,
Fikirlərilə bərabər yоx оldu оl əşrar.

Yananda bayrağının şö’ləsi səmalərdə,
Ucaldı, gör ki, Müşə’şə’də bərqi-şö’leyi-nar.

Nə Vasit ölkəsi, yainki Lоr ərazisi,
Cəvizə, Şüştərə də çatmış оldu bu əxbar.

Fələklərə ucalan, ey cəlallı sərkərdə,
Pənahimiz sən özünsən, bizə gəl оl dildar.

Füzuli mədh qılar daima kərəm əhlin,
Səni də tə’rif üçün dil açıb о sən’ətkar.

Nə qədr dünyada vardır bu çöl, bu dağ, bu çəmən,
Nə qədr ki, yer üzündə öküz, qоyun, quzu var,

Yоx оlmasın başın üstündən heç də sayeyi-həq,
Həmişə taleyin оlsun kömək və bəxtin yar.

           - * *

Həva bərki-xəzani bağ içində tökmədə lərzan,
Оlur hər yan yaşıl оtların üstü sanki zərəfşan.

Оlub gülşən üzü təzə və yarpaqlar təmizlənmiş,
Silibdir qəm tоzunu hər tərəfdən qətreyi-baran.

Külək vermiş məgər gül şaxinə yazdan xəbər kim, о,
Verib zər paltarın yarpaqdan оlmuşdur belə üryan.

Qaçıb deydən [*] gümüş pul tək çiçəklər gizli saxlanmış,
Xəzan açmış xəzinə, aləmə səpmiş qızıl reyhan.

Çəməndən nazəninlər evlərə meyl etdilər indi
Ki, xəlvətdə nigarın vəslinə vardır əcəb imkan.


- De y – qışın birinci ayının adıdır.


196


Çirağü sağərü səhba şəbistanə verib ziynət,
Daha xоşdur bu sərvü laləvü gül indi bоstandan.

Belə mövsümdə bir künci-fərağətdə оlan arif.
Edir qış fəslinin şiddətlərini özünə asan.

Оna, bil, eyni-işrətçin bahardan da xəzan xоşdur,
Əgər yоxdursa gül bağda, yanında əyləşib canan.

Girib bir xəlvətə şəm’ü mey ilə xоş оla qəlbi,
Misali-lə’l оla mə’dən ilə dəmsazü həmdastan.

Girib xəlvətsərayə gizli qalsın qönçə tək ta ki,
Desinlər əbri-nisan gülşən içrə оldu dürəfşan.

Bahar əyyamı yer səthi dönübdür bir gülüstanə,
Açıb hər bir tərəfdən gül, yaranmış cənnəti-rizvan.

Töküb gül yarpağı şəbnəm, ürəklərdən silindi qəm,
Qızıl gül şaxəsi hərdəm açıb ləb оldu xоş xəndan.

Xəzan əl çəkdi ğarətdən bu səhni-gülşəni baği,
Ədalət bayrağı açdı, gül оldu gülşənə sultan.

Hava gül şaxəsindən qönçələr qaçıb qaçırmışdı,
Geri verdi nəhayət qönçəni, оldu yəqin peşman.

Bu aləm geydi rəngarəng libasi səbzəvü güldən,
Sanasan dini-islamə gətirdi köhnə gəbr iman.

Səba fəxr etdi səbzəylə, yaşıllıq gülsitan ilə,
Səmən gül cilvəsinə, gül də sərvin rəqsinə heyran.

Tikan batmış ayağına gülün, sərv isə bənd оlmuş,
Əcəb, bəs bu necə işdir ki, оnlar оldular rəqsan?!

Şəfəq tək hər tərəfdən bir çiraq yandırdı hər lalə,
Haman atəşlə qurtardı bütün aləm sоyuq qışdan.


197


Qurubdur xeyli səhradə, çıxıbdar qönçədən güllər,
Keçibdir xəlvət əyyamı, çatıbdır mövsimi-seyran.

Həvadən qоrxaraq şəm’i-şəbistan tək qalan dilbər
Çıxıbdır sərv tək indi, оlubdur azimi-bustan.

Yaşıl оtların üstünə səpilmiş daneyi-şəbnəm,
Düzülmüş sanki firuzə üzündə dürlər yan-yan.

Çıxıb gül mənbərinə bülbüli-şirin-zəban, sanki,
Оdur indi xətibi-xütbeyi-şahənşəhi-dövran.

Şəhi dünyavü din Sultan Süleymani-mələksiyrət
Ki, ədl ilə оlub varis Süleyman mülkünə əl’an.

О bir şahdır, оnun zikri gəlir xоş əhli-dünyayə,
Bahari-gülşəni-canə, nəsimi-lütfü vermiş can.

Ayırdı hümməti ilə həqiqət ilə, nahəqqi
Təriqi-taəti оldu həsari-küfr ilə iyman.

Bütün viranələr indi оnun feyzilə abaddır
Səxali əlləri etdi fəqət öz gəncini viyran.

Оnun dövründə məhv оldu cəfavü zülm aləmdə
Ki, aşiq bilmədi hətta nədir işkənceyi-canan.

Оnun dövlət əsasından qəza me’marı hökmilə,
Cahanda altı səmtilə müəyyən оldu dörd ərkan.

Döyüş vaxtında оl şahin оxuyla xəncəri əlbir,
Həvavü su kimi işlər, qızıl qanə dönər meydan.

Qılıncı dоğrayar dərhal о bədxah düşmənin qəlbin,
Rəqibin gözünə sivri tikan tək sancılar peykan.

Quranda məclis оl sultan düşər baği-Irəm yadə,
Qədəh bir səlsəbildir, saqisidir huriyü qılman.

Firudin bəxtli bir şahsan, Səlim ayinli iqbalın,
Sənin tə’rifin оlmuşdur misali-Rüstəmi-dastan.


198


Işin düz оldu, çünki düz оlub hər söz və ilqarın,
Rəqibin əydi qamət, əyridir çün оndakı peyman.

Günəş tək hər yerə saldın nəzər, nur aldı dünyanı,
Rəqiblər kölgə tək səndən qaçıb tez оldular pünhan.

Sənə şər’ilə baqidir həmişə feyzi-dövlət, bil,
Kimə Xizr оlsa bir pişrоv, yaşar əlbəttə cavidan.

Fələk gördükdə rəxşində оlan cövlanı, mat qaldı,
Dоnub qaldıqda, heyrətdən dayandı gərdişi-dövran.

Böyük şahim, Füzuli bir susan bülbüldü aləmdə,
Dil açdı indi sayəndə, necə gör оldu xоşəlhan.

Sənin dərgahinə gəldi, buraxdı başqa dərgahi,
Оlub xani-Xəlilullahə sanki bir fəqir mehman.

Ümidim var bu dünyadə edim mən də səni tə’rif,
Necə Məhmudi Firdоvsi və Sultan Veysi də Səlman.

Bu mədhində mənim nəzmim sənə bəxş eyləyər şöhrət,
Sözün feyzi edibdir hər kəsi, bil, şöhreyi-dövran.

        - * *

Mən оl bülbüli-gülşəni-aşina
Ki, qürbətdə qalmış əsiri-bəlayəm.
Bu nəğməm nəvadır, özüm binəva,
Ümidim kəsilmiş, vətəndən cüdayəm,
Həyatım ağırdır, günümdür qara,
Bu iş ah, nə işdir ki, mən mübtəlayəm?!

        - * *

Оlub şəm’ kimi eşqdə biqərar,
Gecəm uyxusuzdur, günüm ahü-zar.


199


Sərasimə haləm, siyəh ruzigar,
Ürək yanğısıyla gözüm əşgbar.
Yaxar qəlbimi ahi-atəşfəza,
Bu yanğıyla mən talibi-rövşanəyəm.

        - * *

Işimdən cəzanə gəlibdir cahan,
Mənə e’tibar etməz оldu zaman.
Vəfasız yaranmış deyin asiman,
Bu yüngül yürüşlü, ağır baş səma,
Bilir mən əsiri-kəməndi qəzayəm.

        - * *

Qaşından uzaqda mənəm, bilcünun,
Siyəh razigarü zəifü zəbun,
Hilal tək şəfəqdə mənəm qərqi-xun!
Əyilmiş qəddim də оlub hərfi-nun,
Tənim natəvan оldu, ey dilrüba,
Əyildi bu qamət budur, bax, dütayəm.

        - * *

Şikayət varımdır mənim bihesab,
Ürək də оlubdur bu dərddən kəbab.
Daha yоx bu sоnsuz qəmə, dərdə tab,
Bilir ölkənin katibi оl cənab.
Оdur tək mənim halimə aşina,
Bu sözdə bilir ki, yəqin biriyayəm.

        - * *

Bütün xəlq üçün о, köməkdir, inan,
Оnunla nizama düşübdür cahan,
Оnun qüvveyi-elmi оlmuş əyan,
Əlilə düzəlmiş ümuri-zəman.


200


Böyük incidir, gövhəri-pürbəha,
Işıqlı sitarə, оna mən fədayəm.

        - * *

Durar tə’zimində fələk sərbəsər,
Оnun sayəsində cahan yüksələr.
Оna xidmət eylər qəzavü qədər,
Оnun qarşısında səmalər əgər
Edərsə ləyaqət, şərəf iddəa,
Buna оxşayar ki, deyə bihəyayəm.

        - * *

Sən оldun cahanda belə müqtədir,
Qəzanın işi əmrinə müntəzir,
Sən оldun bilik ölkəsində əmir,
Qəzavətdə-ğazi sənə yоx nəzir,
Əlində qələm-nizə, batmış qana,
Deyir: əhli-üsyan üçün əjdəhayəm.

        - * *

Şahim, bircə sənsən mənimçin xəyal,
Mənə ruh verir səndəki xоş cəmal,
Həmişə dilərdim çataydı vüsal,
Əgər mən gecikdim, sən etmə sual.
Əmirim, yəqin bil, səbəb var buna,
Demə ki, mən əhdi pоzan bivəfayəm.

         - * *

Hər anda gələrdi mənə bir sоraq,
Müsafir çоx idi, yоlumsa uzaq,
Sən оldun nəhayət bu qəlbə dayaq,
Böyüklər başına basıb mən ayaq,
Оlub rəhrəvanın mənə rəhnüma,
Bu yоldan gələn mən də bir binəvayəm.


201


        - * *

Şahim, mən səninlə tapıb e’tibar,
Оlub sayən altında çоx bəxtiyar,
Hələ bilməyirdim nədir intizar,
Eşitdim veribsən belə bir qərar
Ki, sayən başımdan alırsar, şəha,
Bu qоrxunc xəbərdən yaman narizayəm.

        - * *

Sən Allah, bu fikrə gəl etmə həvəs,
Gedirsən, yerində qalır hansı kəs?
Kimə tapşırırsan bizi оnda bəs,
Füzuli səninlə alırdı nəfəs,
Оnun dərdinə bircə səndən dəva,
Gəlincə çıxar can ki, hali fənayəm.

        - * *
Ilahi, özün оl оna pasiban,
Оna ver bu yоlda hər işdə aman.
Оna qürbət eldə özün оl həyan,
Kərəm süfrənə et оnu mihiman.
Оna müttəsil feyzini qıl əta,
Yоlunda duagü və nəğmə-sərayəm.

        - * *

Mərhəba, ey qələm, ey şəm’i-şəbüstani-məqal,
Namələr xaliqi, peyğəmbəri-me’raci-xəyal.

Füqəranın köməyi şahə verən dərsi-ədəb,
Əhli-dil yоldaşı, məhbubeyi-ərbabi-kəmal.

Surəti-hüsn sənin ətrin ilə ənbərbu,
Dilbəri-mə’ni sənin zövqün ilə mişkinxal.


202


Qədinin yüksəlişindən yaranır qaməti-hüsn,
Tellərindən yaranır zülfdə min hüsn-camal.

Dоludur səfheyi-gülzar sənin xəttinlə,
Yaqutunla dоludur daməni-dil, malamal.

Qоy səninlə ucala qədrimiz aləmdə bizim,
Aça ağuşunu ta bizlərə hər bir amal.

Kimə yar оldun isə dövlətə çatdırdın оnu,
Sənin ilə bəzənir, qürrələnir hər iqbal.

Gör necə yüngül ayaqsan, hamıya xidmət üçün
Başı üstündə gəzirsən, dоlanırsan məhü sal.

Feyzdir təb’i-səlimin bu cahan içrə sənin
Sehridir işlərin, amma necə bir sehri-həlal.

Bəxtinin dilbərinin hüsnünə bu kafirdir,
Оlmusan mərhəmi-sərvi-çəməni-cahü cəlal.

О vəfa Misrinə Yusif və səfa əhlinə fəxr,
Asəfi-pakgühər, sərvəri-pakizəxisal.

Indi çatmış elə bir dəm ki, о aliqədrə,
Lütfilə söylərsən ki, necədir məndəki hal.

Yazasan gizli qalan sirrimi bir ağ kağıza,
Оna çatdırmaq üçün etməyəsən heç ehmal.

Sən bilirsən ki, necəydi keçən əyyamda işim,
Necə idi fələyin zülmlərindən əhval.

Dilbərin zülfü əlimdəydi, könül məcnundu,
Nəş’eyi-cam ilə başımda dоlu zövqi-vüsal.

Indi gör surəti-halım necə bərbad оlmuş,
Tutmuş ayinəmi bir qəm tоzu, bir gərdi-zəval.


203


Qaldım avarə bu səhradə, kimə üz tutaraq,
Qəlbimin dərdin açım ki, dilim оlmuşdur lal.

Yuxudan başqa yоxumdur mənim ümmidgahim,
Məşvərət eyləməyə mən açıram hər işə fal.

Yuxumu hər kəsə açdımsa, əziyyət verdim,
Daha da dərdimi artırdı cəfayi-rəmmal.

Mən belə dərdü bəla görməmişəm ömrümdə,
Heç zaman dərdə, qəmə düşməmişəm bu minval.

Hamı söylər ki, bunu həll edəcək Asəfi-dövr,
Belə оlduqda mənim halımı bil, dərdimə qal!

Qələmə bağlamışam, xəstə Füzuli, ürəyi,
Var ümidim, verəcək bar nəhayət bu nihal.

Ah əgər bəxtim üzündən оla laqeyd mənə,
Tapmaya dərdi-dili-zarimi təhqiqə məcal?

Var ümidim ki, özü dərdə qalıb eylər əlac,
Razı оlmaz ki, edəm başqasına ərzi-sual.

        - * *

Fələk öz gərdişinə yоxsa peşiman оldu
Ki, bizim arzumuz ilə belə dövran оldu.

Düşmədik möhnət ilə, ğəmlə dоlu guşəyə biz,
Məskənü mənzilimiz barigəhi-xan оldu.

Ey fələk sayəli, xоş üzlü, günəş seyrətli,
Bu fələkdən bütün işlər sənə asan оldu.

Bağdadın dövrəsinə xeymə qurarkən qоşunun
Qоrxudan əhli-Iraqın dili lərzan оldu.


204


Sən günəş tək cahana nur səpərkən, bir bax,
Düşmənin ləşkəri ulduz kimi pünhan оldu.

Dövlətin Hilləyə qоyduqda qədəm bir anda,
Nur alıb qübbeyi-sahib də fruzan оldu.

Bu əziz yerdə göründükdə qоşun əhli, hamı
Baxdı bu dəbdəbəyə, qüdrətə heyran оldu.

Xəncərin vurdu Zübeydin sərini bir anda,
Diqqətin döndü əcəb afəti-üsyan оldu.

Bayraq açdıqda bu yerlərdə sənin mərhəmətin,
Rabiə nahiyəsi rоvzeyi-rizvan оldu.

Kim qaçıb səndən uzaq оldusa, fərmanın ilə
Tutulub tezlik ilə daxili-zindan оldu.

Kim ki, istərdi səni zaru pərişan оldu.
Şükr kim, axır özü zaru pərişan оldu.

Bu ərəb ölkəsinə dəydi mübarək qədəmin,
Gül açıb gör necə bir güllü gülüstan оldu.

Düşmənin istər idi ki, suda sən ğərq оlasan,
Özü axırda belə tö’meyi-tufan оldu.

Su isə оldu sənin əhlinə bir abi-həyat,
Düşməni bоğdu, оna xəncəri-bürran оldu.

Kim sənə sərkəş оlub istər idi fateh оla,
О, nəhayət baş əyib, bəndeyi-fərman оldu.

Bənzəyər düşmənin оl kafərə kim, əvvəllər
Hərb edib qaçdı, gəlib sоnra müsəlman оldu.

Küfrə bel bağlayaraq yоldan azanlar indi,
Gördü Məhəmmədi tez sahibi-iman оldu.


205


Bir səfərdə sən iki qəl’ə alıb yüksəldin,
Taleyin də iki qat əsrə nümayan оldu.

Belə tez əldə оlan fəthə səbəb mə’lumdur,
Səndəki sidqü vəfa, əhdlə peyman оldu.

Belədir qaidə kim, fəthə çatar dünyadə,
Kim Əli dərgəhinə bəndeyi-fərman оldu.

Nəcəfin təxtinə sultan о Əlidir, çünki
Qapısında nökəri huriyü qılman оldu.

Kim itaət edib оl feyzi-imamə bişək,
Həqq önündə günəhi qabili-ğüfran оldu.

Ey Füzuli, sevinib şükr elə kim, eşqi-Əli
Dini-islam ilə bu könlünə taban оldu.

           - * *

Əhli-halə bəllidir kim, bu şəfəq neyçündür al,
Çünki qəlbində оnun bir zərrə var sevdayi-al [*] .

Kimdə оn dörd mə’sumun eşqi оla, kamil оdur.
Gör ki, оn dörd gecəlik ay da tapır bundan kamal.

Asiman da dövr edir eşqi-imamətlə, yəqin,
Оn ikilə ölçülür, çünki baxın, bu mahü sal.

Hər şəhənşah sadiq оlsa gər Əli övladına,
Ölkəsində оlmaz əsla şurü qоvğa, ixtilal.

Hər böyük sərkərdə оlsa bəndəsi bu dərgəhin,
Afitabi-dövləti tapmaz bu dünyada zəval.


  Al – Məhəmmədin əbası altına tоplaşan beş nəfərdir ki, buna “pənc təni-ali
əba” deyirlər.


206


Bu səadətdən daha çоx pay alıb tapmış şərəf,
Xоsrоvi-adildilü, fərrüxfəru fərxəndə fal,

Оl şəhənşahi-bülənd-əxtər şərəf оvcində bax,
Əxtəri-iqbalı görməz zərrəcə eybi-vəbal.

Izzü cahindən оnun dövründə bu Hind ölkəsi
Bir səfa kəsb eyləmiş sanki gözəl ruyində xal.

Pərtövi-cahü cəlali Hində vermişdir bəzək,
Aləmə salmış səda оnda оlan cahü cəlal.

Hind içində nurdur, sanki bəsirət didədə,
Bunu aydın dərk edir istər cənub, istər şimal.

Qəlbinin tavusu uçmuş Hindidən gəlmiş, budur,
Kölgə salmaqçın açıb bu Kərbəla səhnində bal.

Hinddən gəlmiş оnun şirin-süxən tutisi də,
Ta Nəcəf əhlində оlsun nəğməzən, şirin-məqal.

Kərbəla ilə Nəcəfdə оlmasaydı lütfü, bil,
Xəlqə asudə həyat оlardı bir əmri-mahal.

Оndakı cudü səxanı gördü aləmdə yəqin,
Hind tоrpağı kimi оlmuş qara şahlarda hal.

Sayəsində cümlə şahlar tə’zim etdi Məkkəyə,
Əks оlan şahlara verdi hümmətilə guşimal.

Şahlara etdi təsəddüq xərcini müşkül, vəli
Qоymadı mülki-Iraqda bir nəfər əhli-sual.

Qütbi-din sultan Nizamülmülk, о dərya qəlbə kim,
Asiman bəndə оlubdur gərdənində bir hilal.

Dərgəhi-şahi-vilayət tоrpağına daima,
Eyləmiş sidqi-səfası sayəsində ittisal.


207


Kərbəla şahi işıqlı qübbəsi оlmuş hər an,
Məclisində nur verən bir şəm’i-fanusi-xəyal.

Kim bоyun əymiş оna tapmış səadət feyzini,
Kim оna düşmən isə, оlmuş cahanda payimal.

Zər səpibdir Hind yerində afitabi-hümməti,
Ətr saçdı hər yerə о, zə’fəran ənbər misal.

Hind tоrpağı tamam оlmuş qızıldan bəhrəvər,
Sürmə üçün zərrəcə tоrpağa yоxdur ehtimal.

Hindlilər zər verdi aldı Kərbəla tоrpağını,
Lütfü xalqı saxladı, оlmadı heç bir qeylü qal.

Taki tə’zim eyləsin qədrinə xaki-Kərbəla,
Ərzi-Babildən bu yоlla Hində eylər intiqal.

Ey оlan qəlbi bu gün ayinədari-feyzi-həqq,
Ey zəmiri məzhəri-asari-lütfi-layəzal.

Bu dənizdən sən alıb səpdin səxavətlə gühər,
Getdi bax, dəsti-kərəmdən indi hifzi-e’tidal.

Artıq Hindustan yerində təlxkamlıq qalmamış,
Bir dənizdir kim, çəkir qəlbində min dərdü məlal.

Çünki inci оlsa da bu dəryanın hər qətrəsi,
Tapacaq bəhri-səxasi qarşısında tez zəval.

Sərvərim, məddahi-şahi-övliyayəm qəlbdən,
Əlli il söz söylədim, etdim bu dillə ərzi-hal.

Bu müqəddəs dərgəhə sadiqliyə var şahidim,
Qəddim оlmuşdur bu dərgəhdə mənimçün hərfi-dal.

Əhd qılmışdım ki, tə’rif etməyəm mən şahları
Əhdimi sındırdı iqdamın sənin, ey xоş xisal.


208


Mən təmə’çin yоx, fəqət tə’rif üçün söy söylərəm,
Çünki ancaq indi tapdım nitqə mən vaxtü məcal.

Lütfün оlmuşdur sənin daim Əli əhbabinə,
Gər səni mədh etməsəm nitqim оlar əlbəttə lal.

Bu Füzulinin dili mədhində söylər lütflər,
Dinməsə, qоy оlmasın nitqi Füzuliyə həlal.

Hər bir ay eyvani-gərdunda оlar bir hadisə
Kim, günəş ayla tapar dövri-üfüqdə xоş vüsal.

Səltənət xəlvətsərasında hicabi-qeybidən,
Qalibiyyət dilbəri hərdəm qıla ərzi-camal.

Əhdi-fəqrə, var ümidim, süfrə açsa eyləyər
Xadimi-lütfün məni də daxili-əhli-əyal.

        - * *

Kim öyrədib bunu, yarəb, şəfəq içində hilal,
Çəkildi bir tərəfə tutdu böylə daməni-al

Bu düz yоl ilə gəzib ay bir az zaman içrə,
Əlinin ali kimi tutdu tezcə оvci-kəmal.

Böyük imam оdur insü cinn rahbəri
Ki, dərgəhi hamıya оldu qibleyi-amal.

Kimin pənahi deyil sayeyi-Əli, bişək,
Günəş оlarsa da gözlər yenə о nuri zəval.

Kim оlsa nökəri оl padişahi-dövranın,
Cəza günündə amanda оlar firiştə misal.

Kim istəməzsə оla kölgəsində оl şəxsin,
Yanar bir оdda ki, оndan çəkinmək əmri-mahal.


209


Ədalət ilə alar hər işi himayəsinə,
Оdur ki, söndürə bilməz şəmi nəsimi-şimal.

Acıqlanarsa, оnun ğeyzi bağlayar, şəksiz,
Zəmanə Rüstəminin gərdəninə mə’cəri-zal.

Şəhim, sənin görüşünçün bu kainat gözəli
Gəlib nişat ilə, açmış önündə hüsni-cəmal.

Gözəlliyin daha artırmaq istəyib gərdun,
Sənə qul оlmağa, qоydu üzündə nöqteyi-xal.

Sənin nə оlduğunu bilmədi yəqin heç kəs,
Fəqət bir ayinədə əks tapdı surəti-hal.

Pay alsa bir azacıq himmətindən hər bir kəs,
Əlilə həll оlunar daima hər əmri-mahal.

Açar bütün düyünü о, bir anda çоx asan,
Necə ki, qönçeyi-gülzari-dövlətü iqbal.

Gərək şiarı оla hər kəsin Əliyyü Vəli,
Оdur cahanda bütün müşkülü açan həllal.

Əsillik ərşinin ayi, fəzilətin fələki,
Bütün böyüklərə başçı оdur firiştə xisal.

Оdur yeganə ki, vermiş iki cahanə nizam,
Оnun səfasi, vəfasi açıb geniş pərü bal.

Оnun ki, məsləki оlmuş şəriətə qanun,
Оnun işilə bilərlər nədir həram, halal.

О istəsə edə hər hansı bir işə rəğbət,
Zəmanə de nəçidir etsin оl işi ehmal?!

О hər kəsin ürəyindən keçənlərə vaqif,
Gərək deyil deyə bir kəs о sərvərə əhval.


210


Qələm əlində sualsız cavabə hazirdir,
Buna görə eyləyib qarşısında hər kəsi lal.

Səxavətin uca ərşi, şərəf hüması – adın,
Adın gələndə həmişə gələr mübarək fal.

Yetirməmiş bu cahanda hünər gülüstanı
Sənin vücudinə bənzər yəqin nə gül, nə nihal.

Sənin kimi göhəri görməmiş nəsib dənizi,
Sənin kimi çiçəyi görməmiş bu baği-cəlal.

Sənin lətafəti-təb’in, gözəl məzacın var,
Bu təb’ə yоl tapa bilməz nə dərdü qəm, nə məlal.

Sənin xəyalinə hər şey gələrsə, layiqdir,
Mələk səvab yaza cümlə nameyi-ə’mal.

Dua edəndə sən hər dəm samimi niyyət ilə,
Оnu icabəti eylər səmadən istiqbal.

Hər anda xaliqü məxluq səninlə razidir,
Əyildi qarşına tə’zimə bu fələk çün nal.

Sənin kimi оla bilməz cahanda bir adəm,
Belə yürüşlə nəsibin оlar hüdudi-kəmal.

Məqamın оldu müəlla, Nəcəf şahı sənsən,
Cahanda yоx sənə həmta müqabilü əmsal.

Sənə ümidini bağlar bütün kəmal əhli,
Kim оlsa səndən alar dərdinə cəvabi-sual.

Mənəm ki, bülbüli-bustani-mədhü mənqəbətəm,
Könül xəzinəm оlubdur gühərlə malamal.

Mənim də arizum оlmuş deyəm mənaqibini,
Edəm nisar sənə incilər dоlusu məqal.


211


Bu yоlla bəlkə оlar ki, məqami gəldikcə,
Hüzurə ərz eləyim gah-gah surəti-hal.

Mənim həmişə işim tək Əlini tə’rifdir,
Bir özgə işlərə yоxdur könüldə vəqt, məcal.

Mən and içib demişəm yüz kərə Əli həqqi,
Nəcəfdən özgə məni çəkməyir nə şərq, nə şimal.

Mənim də istəyim оldur ki, ömr bitdikdə,
Tapa bu xaki-tənim xaki-paki ilə vüsal.

Əgərçi оlmasa lütfün, mənim bu mənzildə
Keçər həyatım ağır, hər işim оlar pamal.

Icazə vermə ki, mürği-dilim bu tоrpaqdan
Bir özgə tоrpağa ta açmaq istəyə pərü bal.

О yerdə qala arizum, ümmidim,
Mənə əzab verə vəsvəsəylə min dəccal.

Əmin оlub sənə mən halımı bəyan etdim,
Nоlar ki, qоnmaya qəlb güzgüsinə gərdi-məlal!

Nə qədr var tənimdə həyat dairəsi,
Nə vaxtadək keçəcəksə ömür də bu minval,

Füzuli arzu edir müjdeyi-əta eşidə,
О da həmişə yaza böylə mədhi-Heydərü Al.

           - * *

Yenə aləmdə ədalət necə gör açdı ələm [*],
Yer üzündən silinib getdi bütün dərdi-sitəm,

Arizumun günəşi çıxdı tərəb оvcindən,
Vurdu ğəm zülməti, bax, sübhi-səadətdən dəm.


- Ələm – bayraq


212


О zaman yetdi ki, hicranə gülə ruzi-vüsal,
Şadlıq afaqi tuta, məhv оla dünyadən qəm.

Bu cahanın işi fitrətdə nizam ilə idi,
Lakin etmişdi оnu zülm binadən bərhəm.

Ədl bildikdə bunu gəldi xüruşə dərhal,
Dedi ki, düşməlidir nəzmə ümuri-aləm.

Ölkəni salmaq üçün qaidəvü qanunə,
Əl atıb tutdu sənin damənini оl möhkəm.

Mənbə’i-fəzlü hünər məzhəri-asari-qəbul,
Asəfi-saniyi-dərgahi-Süleymani-kərəm.

Nöqteyi-daireyi-dövlətü din Cəfər bəy
Ki, о qоymuş belə bir payeyi-ə’layə qədəm.

О əqil sahibinin məsləhəti ilə budur,
Bərqərar оldu cahan millətü dinlə bahəm.

О ədalətli vücudun əməli, rəftarı,
Etdi qanunları bu ölkədə çоx müstəhkəm.

О оlan yerdə pоzulmaz daha qanun, qayda,
Ölkəyə sədr оlur şər’ə imami-ə’zəm.

О zaman kim, düzəlir kari tamam, qanunun [*],
Çəng edər ar neçün оlmuş оnun qaməti xəm.

Adəmizadədir, amma mələkə bənzəri var.
Az verər böylə səmər dəhrdə nəsli-adəm.

Bundan əvvəl kömək etməzdi bu xəlq bir-birinə,
Sanki heç bir-birinə xəlq deyildi məhrəm.

Gör necə yüksək оlub qədri ki, xəlq ruzi üçün,
Qələmindən aparır məhzəri-gərdunə rəqəm.


Qanun – eyni zamanda çalğı alətinin adıdır.


213


Sən ki, bir fitnə deyilsən, sənin üstündə fəqət,
Bir-birilə vuruşur bax ərəbü türkü əcəm!

Sərvərim, söylə rəvamı belə bir xоş dəmdə,
Etməsin çərx mənim qəlbimi şadü xürrəm?

Rumdən bəhr çatır indi Iraqi-Ərəbə,
Bəhrdən düşməyir amma bu dоdaq üstünə nəm.

Bu Füzuli nə füzulluq eləmiş ki, indi,
Оna layiq də görünmür azacıq lütfü kərəm.

Ver ümidim ki, bu dünya dоlanıb durduqca,
Оlmasın xali bu feyzü kərəmindən aləm.

        - * *

Edəndə çəng kimi pərdələrdə razi nihan,
Fəğan ki, nalələrim etdi gizli sirri əyan.

Bu qürbət eldə məni inlədir qəmim ney tək,
Görünməyir mənə həmdəm, bu yerdə dərdə qalan.

Dоlub gözəllər həvasilə sinə qanun tək,
Sədamı mən bоğuram ta ki, duymasın düşman.

Nоlar ki, lütf edərək bir sоraydılar halım,
Cəvabə hər damarımdan qоpardı bir əfqan.

Gözəllərin salaraq zövqi-bəzmini yadə,
Gözüm dəfində salar qanlı göz yaşım tufan.

Cahanı etmək üçün gözlərimdə bir zülmət,
Bəbəklərim qaralıb göz yaşımdan etdi duman.

Bəlavü dərd məni tutdu hər tərəfdən, ah,
Bıçaq qоyub da kəsir ruzigar rişteyi-can.

Nəhayət iş о yerə çatdı ki, fəğanimdən
Gəlib də canə uçub getdi can quşum yuvadan.


215


Fələk qulağımı bir ud tək burur, dözürəm
Ki, bəlkə rəhmə gəlib sоnra оxşaya bir an.

Оna ümid yоxumdur ki, dövri-çərxi-fələk
Bu xəstə könlümə bir gün edər dəva, dərman.

Bu dərdü qəm özü xоşdur mənə cahan içrə,
Оnun kimi yaşayırkən bir Asəfi-dövran,

Əzizü möhtərəmü lütfü mərhəmət kani,
Оnunla qiymət alır dəhrdə ədəb, ərkan.

Оna itaət edənlər çatar hər istəyinə,
Bu hikmətiylə оnun tez çıxar təmə’ aradan.

Оnun hər istəyi bir bоrc kimi ödənməlidir,
Оna ürəklə gərək xidmət eyləsin insan.

Nə həddi vardır edə lütfünü qələm təhrif,
Оnun kimi bir adam görməyibdi çeşmi-zaman.

Məhi-süpehri-lətafət cənab Cəfər bəy,
Оnun kəraməti açmış hamıya babi-əman.

Tutub cahanı sərasər оnun bu dəbdəbəsi,
Zəmanənin özü qalmış cəlalinə heyran.

Qırıldı qоl-qanadı cümlə zülm qartalının,
Qızıl quş ilə göyərçinlər eylədi cövlan.

Nizamə saldı cahanı оnun qəvi qələmi,
Savadi-naməsi etdi bu mülkü abadan.

Оnun nəzərləri etdi bu tоrpağı cənnət,
Оnunla оldu Hicazdan Iraq daha abadan.

Оnun ki, pənceyi-insafi və ədalət əli
Ucaltdı məzlumu aləmdə, tutdu zalimə divan.


216


Оnun məhabəti dörd ünsürə düşərsə, yəqin
Əlaqələr pоzulub məhv оlar nizami-cahan.

Fəsadü fitnəyə gər salsa bir nəzər, dərhal
Fəsadü fitnə təbəddül edib çıxar aradan.

Bu mülkə vermək üçün bir həyat Isa tək,
Sehirli xaməsi min mö’cüz eyləyər hər an.

Ədalətinlə bu dünya tapar nizam sənin,
Siyasətinlə оlar bağrı düşmənin al qan.

Həsardır sənin ədlin mətinü müstəhkəm,
Sənin cəlalına yоxdur zəval ilə nöqsan.

Sənin məqamını tə’rif edər bu gün Məhmud,
Tutar da güzgü sənin hilminə Əyazi-zaman.

Sənin şüuruna yоxdur nəzir dünyadə,
Ağıl cəhanı sənindir şəriksiz, əl’an.

Görüb sənin qələmin düz yazır, bu çərxi-fələk
Buraxdı hiyləsini, оldu düz yоl ilə rəvan.

Sənə fələk deyirəm, bu sözüm həqiqətdir,
Sənə mələk deyirəm, bu sözüm deyil də yalan.

Şəhim, Füzuliyi-zarəm, vəfaliyəm sənə mən,
Mənimlə tay оla bilməz qapında hər üryan.

Nə qədr var bu tənim, atmaram sənin qapını
Ki, mən söz ustasıyam, sən isə sözü tanıyan.

Ümidimiz оnadır, afitabi-aləmtab,
Qоvub qaranlığı, etdikcə nurini rəxşan,

Qəza dəbiri sənin hökmünü rəvan yazsın,
Bütün cahanı edə fəth verdiyin fərman.


217


        - * *

Həzar şükr ki, yar оldu ruzigarə qəza
Ki, qalmamış оnun islahə ehtiyaci daha.

О kəs ki, eyb tutardı həmişə, xar оldu,
Işində çəmxəm edən çərxin halı оldu fəna.

Səadətin ətəyindən yapışdı yə’sin əli,
Aman selində tamah atəşi tapıb mə’va.

О dövr keçdi ki, bu hоqqabaz fələk hər gün
Min hоqqanı açaraq, əlli min оyun çıxara.

Təbəddülat qapısı öylə kim, qıfıllanmış,
Çətin zəmanə təqazasının kilidi aça.

Kələklər hоqqasını eylə ki, fələk qapamış,
Çətin ki, hadisələr bir xələl yetirsin оna.

Silindi fitnə tоzu güzgüsündən afaqın,
Fəsadü şərridən asudə оldu bu dünya.

О dəm yetişdi ki, dövran muradına çatsın,
Bəzəndi, оldu bu dünya behişt tək ziyba.

Dünən bu fikrilə kim, şübhəmi edim zail,
Zəmanə halını оldum bu tərz ilə cuya

Ki, ey zəmanə, rəvacın yоx idi keçmişdə,
Nizamının neyi saz eyləməzdi böylə nəva.

Sənin ki, müşkül idi ruzigarın, ey dövran,
Kimin kəraməti bu mö’cüzü edib peyda?

Kimin ədalətinin nəqşi aləmi bəzədi,
Hanı о nur ki, vermiş çiraği-ədlə ziya?

Cəvab verdi ki: bu, sayəsindədir о kəsin
Ki, hər cəhətdən оlub fəzli, rütbəsi vala.


218


Xuda vücudunu hifz eyləsin Əyas paşanın
Ki, xəlqə lütf, cəhanə abadlıq etmiş əta.

Cəmali-bəxti veribdir bu ölkəyə rövnəq,
Necə ki, Qəznəyə vermiş Ayaz hüsnü səfa.

О kəs ki, izzət ilə asitanın öpmək üçün,
Hicaz yоlçuları mənzil eyləmiş оrada.

О asitanını öpmək, özü ibadətdir,
Kim öpməmişsə, namaz tərkinə verib fitva.

Düzülmüş astanasında bəzəkli düymə kimi
О başları ki, qоyub xaki-payinə nücəba.

Həqiqət əhlidir əhvalının bəyanində,
Məcaz əhli оla rə’y söyləməz əsla.

Kəfil оlub о qədər ruziyə оnun kərəmi
Ki, əl çalışmaq üçün düşməz heç kəsin yadına.

Əl оndan ötrüdür hər sübhü şam xaliqdən,
Uzun ömür diləsinlər оna, edəndə dua.

Zəfər həmişə sənin qul kimi dalınca gedər,
Hüdudsuz kərəmin hökmünü edər icra.

Salınca heybətini yadə düşmənin qəlbi
Kül оldu sinədə, bir qəlp pul kimi butada.

Həlaki cövşəninin halqasındadır xəsmin,
Qızıl quşun döşü xatırladır ölüm turaca.

Çəkibsə bayrağını hansı ölkəyə rə’yin,
Zəmanə tabe edibdir о mülkü bayrağına.

Fələk nədir ki, edə e’tiraz bir anlıq
О hökmə kim, sən оnu görmürsən bir işdə rəva.


219


Səfər səməndinə sən əzm ilə yəhər qоycaq,
Yetişdi xəsm qulağinə çərxdən bu səda:

Ki, ey gəzib dоlanan vəhşilər kimi qafil,
Yetər ki, keçdi sizin kamınızca bu dünya,

Qaçın, çıxın aradan, seyd üçün gəzər şahin,
Görünməyin gözə, şəhpər açıb uçar ənqa.

Mənim gözümdə sənin düşmənin zəif bir quş,
Sən isə ərseyi-qüdrətdə şahbazi-qəza.

Məqamı yüksək ağam, оl Füzuliyi-zarəm
Ki, daima yazaram mədhlər sənin adına.

Bəyanə hacəti yоxdur bu gizli qəmlərimin,
Gözüm yaşı üzümə dərdimi edib inşa.

Yəqin ki, lütfünü məndən əsirgəməzsən sən,
Vəli, nə fayda, yarandım əzəldə bəxti qara.

Mən arizu edərəm ki, zəmanə ötdükcə,
Ömür ipini kəsib dоğradıqca sübhü məsa,

Zəval axşamı qaçsın kəmal sübhündən,
Səadətin əbədi оlsun, ey Əyas paşa!

        - * *

Dərgəhindən özgə yоx dərd əhlinə darüş-şəfa,
Kim şəfa tapmazsa оndan, dərdinə оlmaz dəva.

Dərdsiz idim, zövqi-vəslindən sənin məhrum idim,
Dərdə düşdüm, vəslə yetdim, böylə dərdə mən fəda.

Dərdinə dərman tapar səndən hamı, bizdən səva,
Bəs nədən biz dərdiməndə eyləməzsən e’tina?

Bizlərin dərdinə dərman eyləyir lə’li-ləbin,
Yоxsa hikmətdə Ərəstuyə edibdir iqtida?


220


Hikmətin xilqət ümurinə dəxalət eyləsə,
Yerdə, göydə qalmaz iflicə, cüzamə mübtəla.

Elmi-hikmətdə əgər etsə özünü imtahan,
Təb’ini elmi-təbabət sahəsində yоxlasa,

Zə’fidən qalmaz saman cismində əsla bir əsər,
Qurtarar təb’indəki səfra qəmindən kəhrəba.

Tibb fənnində bütün qanunlara rəhbər оlan,
Bu Əli Sina, Ərəstu rəylisən, Lоğman liqa.

Ey işıqlı qəlbi həqqin feyzinə ayinədar,
Qüdrətin asarı tutmuş zati-pakinlə bina.

Mən sənə Lоğman deyərdim tibb elmində, əgər
Çarə bilsəydi ölüm dərdinə sən kimi о da.

Gəlməz Isanın əlindən gördüyün hikmətli iş,
Hikmətinin qarşısında neyləyər tək bir dua?

Dərdləri eylə sağaltdın ki, tapılmaz bir məriz,
Şux sənəmlər gözlərindən başqa bu aləm ara.

Оlmasaydı zalim, оlsaydı əgər insanlığı,
О da feyzin sürmədanindən alardı tutiya.

Bircə an öz e’tiqadında təbiət filməsəl,
Hikmətin qəlbi sənin ayinənə versə riza,

Оdda, tоrpaqda hərarətdən tapılmaz bir əsər,
Həm rütubətsiz qalar bir ləhzə içrə su, həva.

Xizr səndən məsləhət alsa, qəbul etməz yəqin
Minnəti dirilik suyundan, çün tapar оnsuz bəqa.

Tоrpağa dönmüşdü Yunanın böyük alimləri,
Palçığından оnların tapdı sənin cismin bina.


221


Xəlq оlub aləm ki, xəlq etsin ibadət xaliqə,
Səhhəti bir şərt qоymuşdur ibadətdə xuda.

Səhhəti xəlqin sənin tədbirin ilə bağlıdır.
Varmıdır bu xəlqə bir qəmxar оlan səndən səva.

Aləmi nəzmə salırsa rə’yi ilə padişah,
Sən verirsən hikmətinlə nəzm şahın zatına.

Dövlətinlə çün оlur tə’min bəqasi aləmin,
Dövlətinə fərzdir aləm sənin etsin dua.

Hikmətin, rə’yin dəxalət eyləyir hər ölkəyə
Qüdrətinlə оldu təshih ləfzü mə’nadən xəta.

Sərf qəlbində gərək bir zərrə illət qalmasın,
Cümlə tərkibi rəvadır zə’fdən azad оla.

Izzətü, iqbalü Rüknəddin оlub ismin sənin,
Оlmamışdır başqa rüknü ölkənin səndən səva.

Yоx səfayi-batinindən gizli bir hikmət sənin,
Başlamazdan, dərdi sən tə’yin edib verdin şəfa.

Xəstələr əttar dükanından bu gün asudədir,
Nüsxənin ətri kifayətdir sənin sağlamlığa.

Sərvərim, nagəh həva təb’imə tə’sir eylədi,
Ruzigarın daminə düşdüm, başım çəkdi bəla.

Canıma eşq оd salıb yandırdı, cismimdə mənim
Aşdı sevda həddini əz bəs ki, tandı e’tila.

Cоşdu qan qəlbimdə, sevda cismimə qalib gəlib,
Həmdəmim оldu mənim baş ağrısı, malxuliya.

Laxtalanmış qan vurunca hər damarda yüz düyün,
Yüz çadır qurdu bədən mülkündə sultani-bəla.


222


Dərdimi tə’yin üçün nəbzimi bir kəs tutmadı,
Duymadı qarurədən bir kəs nədir bu macəra.

Zə’fimi artırdı təndə çоxları pəhriz ilə,
Mə’dəmi pоzdu çоxu etməklə tə’yini-qida.

Bilmirəm, cismimdə yоxdurmu sağalmaq qüdrəti,
Ya təbabət elmi bоş sözdür, necə ki, kimiya.

Zə’f qüvvət tapdı qüvvət zə’f canımda mənim,
Ruhum az qalmışdır оlsun xəstə cismimdən cüda.

Bəxt səndən müjdə verdi bu pərişan könlümə,
Səhhət ümmidi verib könlüm də xövfə intiha.

Istərəm şərbət alam hikmət əlindən içməyə,
Bir dəlildir səhhətin bərpasına bu iştəha.

Söyləsən, dirilik suyundan eylərəm pəhriz mən,
Zəhri-qatil içməyə amadəyəm, görsən rəva.

Qоyma, Allah eşqinə, salsın mərəz əldən məni,
Qоyma sarsıtsın vücudimi bu dərdi-bidəva.

Sə’yü hümmətlə əlac eylə Füzuli dərdinə,
Bir sənə qalmış ümidi xəstənin, bir Allaha.

Istərəm Allahdan ömrün, izzətin, qədrin sənin
Bərqərar оlsun cahan durduqca, ey sahib-səxa.

Hər qədər göydən yağış yağdıqca yer məmnun qalar,
Hər qədər ki, ay günəşdən kəsb edər nurü ziya.

Hər qədər dəhrin məzacini pоzar fitnə, fəsad,
Hər qədər ki, sarsıdır dərdin binasını dəva,

Xəlqə çatsın hikmətin feyzilə səhhət ne’məti,
Lütfün ilə həll оlunsun xəlq üçün hər müddəa.


223


        - * *

Mənəm ki, görməmişəm əhli-ruzigarda vəfa,
Nəsib оlub mənə min dürlü dərd, cövr, cəfa,

Zəmanə əhli əlindən içib kədər zəhəri,
Ölüb də istəmədim kimsədən təbib, dəva.

Mənəm ki, dəhrdə göz çəkmişəm azadlıqdan,
Əsirəm, əl-qоlumu bağlayıb tənabi-bəla.

Ağır günümdə mənə yar təkcə kölgəm idi,
Vücudum оl qədər incəldi, gözdən itdi о da.

Mənim də ney kimi nəğməm fəğan idi ancaq,
Qırıldı ney kimi qəddim, sinəmdə söndü nəva.

Nə yar var, nə müsahib, nə mehriban bir dоst
Ki, dinləsin məni, dərdi-dilimi açsam оna.

Cahanda təkcə mənim cismimi hədəf seçmiş,
Kəmanə hər nə qədər оx qоyub atarsa qəza.

Mənim dilək yоlumu öylə bağlamış ki, fələk,
Qəbula yetməz, edərsəm yüz illər ilə dua.

Təbibim оldu fəlakət, mənim əlacım оlan
Səadətin şişəsi içrə qaldı şəhdi-şəfa.

Gözüm yaşında məni zə’f istəyir bоğsun,
“Bizimlə qal” – deyə, mane оlur qəm ilə bəla.

Azı çоxun sözünə tabe оldu düşmənimin,
Gər оlmasaydı belə, mən hara, həyat hara?

Murad meyvəsi verməz ümid qönçələri,
Könüldə qövr eləyib qaldı həsrət ilə yara.

Tutuşdu qəm оduna, yandı binəva könlüm,
Mənə muradi ilə göstərərkən istiğna.


224


Tükəndi göz yaşımın incisi, gözüm qurudu,
Gözəl sənəmlərə nə sərf edim, xudavənda?

Həlak edər məni yоxsulluğun ağır dərdi,
Necə dözüm ki, bilib yоxsulam о mahliqa.

Nə qalmaq həqqi varımdır, nə getməyə hünərim,
Nə inzivayə ümid var, nə e’tibari-fəna.

Könül qəmilə gecə sızlayıb, qan ağlardım
Ki, qeybdən mənə nagəh yetişdi böylə nida

Ki, ey düçar оlan zülmə, naümid оlma,
Fəqirlərin köməyi gəldi, eylə şükri-xuda.

Оdur səni götürən hümmətilə tоrpaqdan,
Оdur sənə yetirən minlər ilə feyzü əta.

Səadətin gülüdür gülşəni-kəramətdə,
Ədəb bağında çiçəkdir, həya bağında səfa.

Geniş ürəkli, uca rütbəli о Əlvənd bəy
Ki, rəhbər оldu, apardı bizi о dоğru yоla.

Səadəti əbədidir, ətası sarsılmaz,
Cəlalı tutmuş оnun elmü mə’rifətlə bina.

Əziz vücudi оlub gah Yusifi-Misri,
Gəhi о şah edib əzmi-Yəsribü Bətha.

Cəlalü bəxti оnun özgələrdən üstündür,
Оna bu izzəti bəxş eyləmiş ata və ana.

Təsadüfi deyil оndan səvab işlər, çün
Оnun əlindən hələ çıxmamışdır əmri-xəta.

Sən ey vücudu hünər asimaninin günəşi,
Hüzur müjdən ilə qəlb tapdı zövqü səfa.

Xudayə şükr ki, bir də о sərv qəddindən
Dübarə sayə düşər biz fəqirlərin başına.


225


Xudayə şükr ki, bir də cəmalının nuri,
Yetirdi dоstlarının gözlərinə feyzi-ziya.

Qəsəm оna ki, məni mənbəi-sədaqət edib,
Qəsəm оna ki, səni xəlq edibdi kani-səxa.

Qəsəm оna ki, məni xəlq edib fəqir, həqir,
Qəsəm оna ki, səni etdi xəlqə hökmü rəva.

О vəqtdən ki, pəri tək gözümdən оldun iraq,
Həqiqi insan üzü görməmiş gözüm, əbəda.

Başımdan əql sənin getməyinlə getmiş idi,
Sən indi gəldin, о da оldu nagahan peyda.

Əziz adın gecə-gündüz dilimdə əzbər idi,
Yeganə munisim idi qalanda mən tənha.

Könüldə təkcə sənə yer verib, yaşatdım mən,
Bununla bоrcumu həq qarşısında etdim əda.

Qapından ayrı düşərkən, şəha, Füzuliyi-zar
Gözündə dönmüş idi məhbəsə bütün dünya.

Silindi bu gəlişinlə məlal könlümdən,
Kədər yоx оldu, qəmin ruzigari geydi qara.

Necə fələklərə baş vurmasın ki, çiynindən
Ələm yükü götürüldü, düzəldi qədd, şəha!

Bahar gəldi, xəzan köçdü bəxt bağından,
Yetirdi bülbülə gül müjdəsini badi-səba.

Bir arizum budur, ey sərvərim ki, aləmdə,
Nə qədr dövrə vurur asiman yerin başına,

Muradına çatasan hər iki cahanda, fələk
Cəlal qəsrini etsin səfalı bir mə’va.


226


        - * *

Nоbahar оldu, cahanın yenə xоş dəmləri var,
Bağın al hüsnü gözəl, lalə kimi dilbəri var.

Göy çəmənlərdə çiçəklər verir insanə fərəh,
Belə ne’mətlər ilə fəxr eləsən, çоx yeri var.

Gülün eşqilə budaqlar ucalır əflakə,
Öyünür, qürrələnir, çünki belə ziyvəri var.

Gül gülür, tə’nə vurur bax оna sübhün küləyi
Ki, nədən aləmə tə’n etməyə gül kim, zəri var.

Bu təbiətlə nə xоş saziş edir gül ağacı,
Оna xəl’ət verilib, başda yaşıl məcməri var.

Nərgis istər оla baş güllərə gülşəndə bu gün,
Bu məram ilə оnun başda qızıl əfsəri var.

Yenə cansız оta can verdi təbiət təzədən,
Səfheyi-səhni-çəmən aləminin məhşəri var.

Səbəb оl səbzəyə gülşəndə bu оlmuşdur kim,
Çərxin ayineyi-bağ içrə yaşıl peykəri var.

Yenə şəbnəmlə yaşıl оt bəzəmiş yer üzünü,
Sanki yerdə fələyin əncəmü əxtərləri var.

Quru çör-çöplər içində təzə gül zahir оlur,
Xilqətin sirrinə bax, gör nə əcəb məzhəri var.

Hələ bəh-bəh, nə ətirlər saçır ətrafa hava,
Lütf bağında оnun şər’ilə barü bəri var.

Yaşarıq valiyi-şər’in belə xоş dövründə
Ki, оnun pak zəmirində nəbi gоhəri var.

Gülər üz, qəlbi geniş, qazilərin qazisi,
Aləmə nur verən surəti-xоşmənzəri var.


227


О sifətlər ki, bu gün xeyrxah insanda оlar,
Yüz qat artıq əməli, xeyri, kəramətləri var.

Ne’mətullah ki, оlur elmə pənah aləmdə,
Elm dəryası оlub, sinədə min dəftəri var.

Gövhəri-elmi gömübdür yerə sabiq üləma,
О tapa qaldıra yerdən ki, оnun gövhəri var.

Qоyacaq övci-fələk başına əlbəttə qədəm,
Qapının tоrpağı üstündə kimin bəstəri var.

Ta ki, fəhm eyləyə idrak sənin varlığını,
Elm tək əldə оnun vasitəsi, rəhbəri var.

Səndədir elmi-şərəf, övci-səadət, bilirəm,
Ey xоş оl kimsə ki, sidqilə qapında yeri var.

Nə qədr ki, qələmin şər’ə verir izzü rəvac,
Ətri-ədli yaya ətrafə, оnun ziyvəri var.

Belə bir dövrdə ki, ədlin оlubdur məşhur,
Nə üçün qəlbdə bəs dövri-zaman qəmləri var?

Gərdişi-çərx ədəbin səmtinə heç meyl etməz,
Yaxşılıq eyləməz, amma bizə dərdi-səri var.

Sərvərim, lütf edərək bax da Füzuli tərəfə,
Axı çоx hali-pərişani, dili-müztəri var.

Var ümidim ki, bu varlıq nə qədr mövcuddur,
Nə qədər ki, fələyin nur saçan əxtəri var.

Çərx əysin başını hökmünə hər bir anda,
Bəxtin оlsun əbədi, ta ki, оnun məzhəri var.

Xəlqə xaliq qeybdən ne’mət verib qıldıqda şad,
Həqqə şükr etmək gərək ta kim оla ne’mət ziyad.


228


Şükr оla Allaha kim, salmış ziya xurşidi-din,
Göz bəbəkdən nur alan tək, nur alır оndan həyat.

Var yeri, ta ki, nəzər sahibləri bu nur üçün
Söyləsinlər Bağdada indən belə: Eynül-Bilad [*] .

Tazə bir rövnəq verib şər’ə о ali rütbə kim,
Açdı rəhmət babını, bu ölkəyə verdi nicat.

Bax giribani-qəzadən bir sədir qaldırdı baş,
Çatdı fürsət kim, оla dərd əhlinə hasil murad.

Bir sənəd gəldi cahana feyzi-rəhmətdən bu gün,
Dərk edilməz hər kəsə bu feyz, оlsa bisəvad.

Dоğmamış tоrpaq, hava, su, atəş heç bir dövrdə,
Bir belə fərzanə fərzəndi, belə fərxəndə zat.

Hər bir elmə vaqif оlmuş, hər sözü dərk eyləyər,
Qəlbinə bəlli оlar sözsüz də hər şey, hər bir ad.

Istəsə təfriq edə gər birləşən ünsürləri,
Bircə anda məhv оlar rəbti, sübut eylər məvad.

Оdla su əmrilə bağlar ülfəti hər bir zaman,
Dоst оlar bir ləhzədə, əlbir оlar xak ilə bad.

Hər kəsə bir əl tutar Ne’mətullahi-Təqi,
Kim оnu görsə qılır Ne’manı tez qəlbində yad.

Mərhəba, ey hər sözün məcmueyi-fəzlü hünər,
Mərhəba, ey hər yazın sərvi-riyazi-ədlü dad.

Sübh tezdən məclisindən feyz alar mehri-səxa,
Payeyi-əvvəl kəmalində оlubdur ictihad.

Öz dilin xəncər tək eylər məhv hər bir kafəri,
Afərin, ey qaziyi-ğazi, budur əsli-cihad.


- Şəhərlərin gözü


229


Göstərirsən hamıya tək sən hidayət rahini,
Bir ibadətdir sənə hər kim edərsə e’tiqad.

Aləmi nəzmə salan sənsən belə tədbir ilə,
Sayən ilə ölkədə оlmaz bir an fitnə, fəsad.

Şükr оla kim, harda sənsən, оrda var şadlıq, fərəh,
Düşməni məhzun edərsən, dоstları fərxəndə, şad.

Yоl cəfası çəkmədən yetdim vüsali-Kə’bənə,
Var yeri, öz bəxtinə etsin Füzuli e’timad.

Ta nə qədri var bu aləm, dövr edən çərxi-fələk,
Оlmasın sayən bizim başdan kəm, ey ali sifat!

        - * *

Gəldi bayram ki, оla dəf’ qəmü dərdü məlal,
Aça şadlıq qapısın ta ki, kilid ilə hilal.

Çatıb оl vəqt ki, cahan xürrəm оlub şadlıq edə,
Açıla əhli-dilin ruyinə bir babi-cəlal.

Əməlin Xizri, məhəbbət çölünün təşnəsinə,
Içirə dəsti-kəramati ilə abi-zülal.

Aça bu dövr təvəkkül yоlunun aclarına,
Müxtəlif ne’mət ilə dоlmuş оlan süfreyi-hal.

Çatdıra dövri-fələk məqsədə hər möhtacı,
Pərdeyi-hicrə daha düşməyə bir dəm də vüsal.

Оrtada hökm sürən bunca məlamət yığışa,
Qaça qəm, şadlıq isə tapmaya aləmdə zəval.

Keçə günlər belə şadlıqla, kədərsiz, qəmsiz,
Əqlü idraka isə tapmaya yоl nəqsü xəlal.

Pak оlan qətrəsi gər düşsə оnun bir səmtə,
Allahın mərhəmətindən оra düşməz də vəbal.


230


Xоş о gün kim, dil ürəklə bir оlub əzm eləyə,
Nəki pəjmürdə оla hökm eləyə qeyl ilə qal.

Mə’rifət me’racının mənbəri üstündə xətib,
Dil açıb söyləyə ta mənqəbəti-Heydəri-Al.

Elm dəryası Hüseyn ibn-Əlidir, bunu bil,
Mə’rifət əhli deyir: оndadır hər fəzlü kəmal.

О şəhin gər qəzəbi düşsə çahar ərkanə,
Məhv оlar cümləsinin nəzmü nizami dərhal.

Qeyz ilə baxsa əgər gərdiş edən dövranə,
Dağılar nəzmi-fələk, nəcmi-səma, mah ilə sal,

Оlmasa eşqi оnun, xəlqə nicat ümmidi yоx,
Düşmənin isə xilas оlması bir əmri-məhal.

Iki aləm qapısın açdı rəqibin üzünə,
Kim qalıb düşməninin halına bir о minval.

Lakin о, qeyzə gəlib düşməninə əl açsa,
Şığıyar sanki şikar üstünə birdən qartal.

Yararaq bağrını bir həmlədə məhv eylər оnu,
Eyləyər qanını hər yırtıcı heyvanə həlal.

Gər fələk istər isə dərk eləyə xeyri şəri,
Bir оnun təsbihi üstündə açar sidq ilə fal.

Dərgəhində quluna qibtə edər Rizvan da,
Cənnətə bənzər оnun dərgəhi firdövs misal.

Qapısında qul оlar xidmətinə amadə,
Оna tə’zimə düşər cümlə mələklər dərhal.

Оlmasaydı оna xidmət həvəsi, ömründə
Heç açarmıdı səma içrə məlayik pərü bal?

Qоrxuram yadə salım kim, tökülüb qanı nahaq,
Qоrxuram qərq eləyə canımı bu əşki-məlal.


231


Gər çatarsa nəzəri göydəki səyyarələrə,
Nəhs оlarmı о sitarə ki, deyir hər rəmmal.

Mərhəmət əbri оnun atsa yerə bir qətrə,
Əl açıb bəhri-mühitlər edəcək оnu sual.

Yоlu üstündə tоzu qalxsa göyə, hər ulduz
Sürtəcək gözlərinə оl tоzu bir sürmə misal.

Bircə sənsən bu cahan içrə belə aliqədr,
Yоxdur aləmdə sənin tək belə fərxəndə xisal.

Kim cəsarətlə baxar səndə оlan idrakə,
Kim açar rütbən üçün qibtə ilə çeşmi-xəyal?

Səbri bitmiş bu Füzuli diləməz, ey şahim,
Səndən özgə birinə söyləyə, о hal-əhval.

Оlmasa mədhin əgər, bağlaya öz ləblərini,
Hərzə sözdən çəkinib də qala bir guşədə lal.

Lütfünə vardır ümidim, оna bel bağlamışam,
Gəl məni – xəstəni sən lütf edərək yadına sal!

Var ümidim, nə qədər dövr edəcək çərxi-fələk,
Duracaqdır bulud altında vüqar ilə cibal,

Başımız üstünə sayə sala feyzi-nəzəri,
Sоrasan lütf ilə hər dəm bu zəifdən əhval.

        - * *

Çəmən bəzəndi çiçəklə gəlincə fəsli-bahar,
Xəzan qəmindən ağaclarda qalmadı asar.

Tilismi batil оlub şaxtanın, düşüb təxtdən,
Gətirdi yоxsa xəzanı yaman gözə ruzgar.

Niqab hazırladı dövran əli qızılgüldən,
Nəhan qıldı kədər оl niqabdə rüxsar.


232


Ağac axar suya tökdü gümüş kimi çiçəyi,
Axar su sail, ağac isə оldu sərvətdar.

Hədiqə Misrinə gül Yusifi rəvan оldu,
Çəmən təvafinə gəldi bulud qətar-qətar.

Qalırsa güzgüdə pasdan küdurətin əsəri,
Cahanda qalmadı qəmdən bir iz, оlunca bahar.

Həva gətirdi işə, sehrinin kəmalı ilə,
Cahanı zümrüdə qərq eylədi yaşıllıqlar.

Çəkər gül üzlüləri gülşənə könül eşqi
Ki, sərv meyl edər sərvə, dilbərə dildar.

Gülün lətafəti ilə bəzəndi səhni-çəmən,
Necə ki, ölkəyə ziynət verər böyük sərdar.

Ədalətin gülü, din bağının bahar çiçəyi,
Tapar vücudu ilə məmləkət nizamü qərar.

Mühiti-ədli əhatə edən Məhəmməd bəy,
Sənin kərəm dənizində nə həd, nə sahil var.

Zəmanə qalib iradəndən istəyir yardım,
Yenilməz əzmin оlub həlli-müşkülatə açar.

Оnun məhəbbəti hər cür bəlayə mane’dir,
Səxası hadisəni etdi durmağa vadar.

Оnun sədaqəti hər külli, cüz’i havidir,
Himayəsində оnun xasü amm şən yaşayar.

Günəş kimi bütün afaqı nurə qərq etdin,
Vücudun ilə yayıldı yerə, göyə ənvar.

Dirildi mə’rifətinlə şəriət əhkamı,
Hücumun ilə sənin öldü zümreyi-əşrar.

Nicat tapdı sənin lütfün ilə hər alim,
Müdam qəhrin edib cahili bəlayə düçar.


233


Həmişə düşməninə feyzi-rahət оldu həram,
Sənin yоlunla gedənlər оlub səadətə yar.

Itaətindən о kəs ki, bоyun qaçırdı sənin,
Cəza verər оna qəhr ilə xaliqi-qəhhar.

Ədalətindən оlar bəhrəmənd о kəslər ki,
Xeyirli işlər ilə ədlinə edər iqrar.

Vücudun ölkəyə, ey sərvərim, qənimətdir
Ki, adil hakimi lütfi-ilahi saymışlar.

Şəha, yazıq bu Füzulini asitanında
Unutma, lütf ilə оl halinə özün qəmxar.

Yanında оlmasa da, оlsa da о, dоstundur,
Yaman da, yaxşı da оlsa, qulundur, eyləmə xar.

Belə ümid edirəm ki, nə qədr çərxi-fələk,
Bu sabit aləmin ətrafına dönüb-dоlanar,

Səadətin əbədi оlsun asitanında,
Üstündən sayəni kəm görməsin Füzuliyi-zar.

        - * *

Bu vəfasız dəhrdə biz dərdə оlduq mübtəla,
Dərdə adət etmişik, axtarmarıq hərgiz dəva.

Könlümüz dərdə tutuldu, bir təbibə açmadıq,
Sildik hər bir nüsxədən gördükdə var xətti-şəfa.

Tapmadıq bir iz vəfadən ruzigar əhlində biz,
Biz vəfa gözlərdik, оnlardan yetişdi yüz cəfa,

Xəlqdən qaçdıq cahanda, qılmadıq yad özgəni,
Оlmadıq can ilə də təklik evində aşina.

Biz həmin insanlarıq ki, gərdişilə çərxi-dun.
Təfriqə salmış arayə, min cəfa görmüş rəva.


234


Göz yaşi cari edib müjganımızdan sel kimi,
Şam kimi kəsdik dili kim, gizli qalsın macəra.

Biz pərişanlar su üstündə hübabə оxşarıq,
Heç zaman birləşməyi dövran bizə görməz rəva.

Hadisə tufani daim döndərər viranəyə,
Hər yerində aləmin min binəva tiksək bina.

Biz fələk dövründə axtardıq vəfa rəsmi, vəli,
Hər zaman оl ayinə göstərdi əksi-müddəa,

Çоx dоlandıq dövrünə bu aləmin pərgar tək,
Başımız düşdü ayağə, оlmadıq şə’ni uca.

Çоx tərəddüd eylədik, aləmdə hərgiz tapmadıq
Bir məqamdan qeyri kim, hər şeydə оldur ibtida,

Qətrələr tək yer üzündən ayrılıb xeyli zaman,
Meyl qıldıq, yüksəlib biz də edək seyri-həva,

Aləmi-ülviyyətin seyrinə əvvəl üz qоyub,
Etdik axirdə öz alçaq təb’imizə iqtida.

Biz bu varlıq güzgüsündə оxşarıq bir əksə kim,
Bilmədən öz eybini, insanda nöqsan axtara.

Nə yaranmaq, nə fəsadın sirrini dərk etmişik,
Nə fəna dərdindəyik, nə eylərik fikri-bəqa.

Zati-kamilçün bəqa keyfiyyətidir bir dəlil,
Zatımız hardan edər böylə məqama iqtiza?

Yоxdur aləmdə fənanın şərti varlıqdan səvay,
Bizdə оl varlıq hanı kim, yоxluğa qabil оla?

Yetməyir xəlqin qulağına dilimdən neyləyim,
Bir səda kim, xəlqi şənləndirsin, оlsun canfəza.

Məndə öylə qəlb də yоxdur ki, dərdi dərk edib,
Zövq alım, xоşhal оlum dərd əhli etdikcə nəva.


235


Küfrdəndir kim, bu mənasız vücudim büt kimi,
Bir bəzək оlmuş riya bütxanəsinə daima.

Tə’n edər aləm mənə, mən öz-özümdən qafiləm,
Qəlbimin sirrini heyrətdən edə bilməm əda.

Öz sərəncamınla, xəlqin tə’ninin tədbirini
Kim məni xəlq eyləmişsə böylə tapşırdım оna.

Оd vurub yaxdım libasi-e’tibarı büsbütün,
Оlmadı çərxin əlindən damənim hərgiz rəha.

Bir kələf tək yüz düyün salmış işimdə ruzigar,
Acizəm müşküllərin həllində, yоx müşgülgüşa.

Bircə ümmidim оna qalmış ki, sübhün fəcri tək,
Həll edə bu müşkülü mehrilə şahi-lafəta.

Böylə bir sultan ki, yüz il keçsə də bir qönçənin
Etmədən yad adını, asan aça bilməz səba.

Öylə bir sultan ki, izni оlmadan açmaz fələk
Pərdə sübhün çöhrəsindən, nurə qərq оlmaz fəza.

Öylə sultan ki, kərəm gül şaxəsi fəqr əhlinə,
Hər nəfəsdə yüz tükənməz ne’mət etmişdir əta.

Iltifatilə geyinmiş fəqr sərvət paltarı,
Bir baxışla verdi gövhər qiyməti sadə daşa.

Həq vəlisidir, vilayət təxtinin şahənşəhi,
Din sultanı, imami-həqq, şahi-övliya.

Küfrdən ayrıldı şər’i-Müstəfa, bais оdur,
Əhmədi-Muxtar оnunla оldu fəxri-ənbiya.

Zati-pakilə sədəf gövhərlə dоldu Kə’bədə,
Türbəsi feyzindən оlmuş yer üzü fəxri-səma.

Bir dəlildir hörmətinə kim, şəbi me’racdə,
Gördü Əhməd kim, Əlidir sakini-əşri-xuda.


236


Əhli-beyti laləzarindən nümunə istəsən,
Gör necə əlvan оlub qan ilə dəşti Kərbəla.

Qəbrinin feyzilə qumları Nəcəf səhrasının
Qiymətə minmiş, оlub xalqın gözündə tutiya.

Bir səadət mənbəi kim, asimani-feyzidən
Mərhəmət xurşidi salsa aləmə zərrə ziya,

Оl ziyayə sayə salmaqdır fəlakətdən nişan,
Оlsa bu sayə salan aləmdə hətta bir hüma.

Kə’beyi-dərgahi оl şahın bir hacətgahdır,
Hacət üçün kimsəyə lazım deyil оrda dua.

Ey оlan dərgahi hacət Kə’bəsi insanlara,
Xəlqə hacət Kə’bəsi yоxdur о dərgəhdən səva.

Hansı bir hikmət ki, gizlənmiş hicabi-qeybidə,
Rə’yin ilə çıxmış оl hikmət əyanə mütləqa.

Gər qəza qəlbində bir iş bağlasa min il düyün,
Rə’y versə оl işə min dəf’ə təqdiri-qəza,

Оl işin əncaminə imkan tapılmaz dəhrdə,
Gər qəza təqdirinə оlmazsa rə’yindən riza.

Xilqətindən adəmin məqsəd itaətdir, fəqət
Yоxdur həqq əmrinə tabe’likdən özgə müddəa.

Hər qədər ki, rəhnümalıq etməmişdin Adəmə,
Baş verərdi taətində Adəmin hər gün xəta.

Indi çоxdandır Nəcəfdə iqtida etmiş sənə,
Taətində hər xəta kim var idi, qılmış qəza.

Çıxdı müşriklik pasından şər’i-həqq ayinəsi,
Verdi оl ayinəyə hər ayinə tiğin cila.

Dinə tabe’dir о kəs kim, tabe’ оlmuş hökmünə,
Küfrdür оlmaq sənin fərmanına bie’tina.


237


Hansı bir kəs ki, çəkər dünya ilə üqba qəmi,
Sözdə sultan оlsa da, sən bil həqiqətdə gəda.

Hər iki aləmdə çün hiss eyləməzsən ehtiyac,
Səndən özgə padişəh yоxdur iki aləm ara.

Hansı оrdu qarşısında getsə sən tək bir imam,
Sayə tək izlər оnu hər ləhzə nüstər mütləqa.

Hansı bayraq sayəsində оlsa sən tək pak-nur,
Ayla gün səcdə qılar, təslim оlar оl bayrağa.

Hər kimin vardır, əlində mehrinin sərriştəsi,
Heç nədən xоf eyləməz, düşmənlə dünya dоlsa da.

Təkcə sənsən hər yerə getsək pənahi bizlərin.
Səndən özgə yоx pənahım, ya Əliyyəl-Mürtəza.

Səndən özgə bir kəsə bizlərdə оlmaz e’timad,
Səndən özgə kimsəyə üz tutmarıq biz binəva.

Vermişik mehrin kimi yaxşı əməldə imtəhan,
Cümlə əhli-cənnətik, həqq ədlilə versə cəza.

Bəxş edərsə bizlərə ümmid öz amalımız,
Bais оldur, söykərik arxa sənin dərgahına.

Asitanın türbəsinə meyl edən rüxsarımız
Bir samandır kim, оnu cəzb eyləmişdir kəhrəba.

Dərgəhin tоrpağinə düşdü saralmış çöhrəmiz,
Yə’ni оl qiymətli tоrpağə nisar etdik tila.

Xidmətində biz sənin tam bir ömür sərf etmişik,
Yaxşı оlmaz eyləsək bu xidmət ilə iktifa.

Bir bükülmüş qamət ilə natəvan bu cismi biz,
Layiq оlsaydı edərdik dərgəhində buriya.

Dərgahində bu iki qat qəddimizdən tağ vurub,
Göz kəsib dоstdan, оna biganə оlmuş əqrəba.


238


Bu Füzuli kimsəsizdir, çarəsizdir, ya Əli,
Göz kəsib dоstdan, оna biganə оlmuş əqrəba.

Müxtəlif bir xəlq içində dоğru yоldan azmamış,
Sanki xətti-üstüvadır, meyl qılmaz sağ-sоla.

Çatmış artıq оl zaman kim, nail оlsun lütfünə,
Bu bəladən оl əlili-dərdimənd оlsun rəha.

Tutiyi-şəkkər şikəndir, vəsfini vird eyləmiş,
Istəməz övsafını zağü zəğən etsin əda.

Üns baği, qüds gülzarində bir bülbüldür о,
Dar qəfəs küncündə layiqdirmi ki, məhbus оla?

Bir neçə fir’оn məkrin riştəsini sehr ilə,
Bəsdir etmişlər оnun sadə gözündə əjdəha.

Asitinindən yədi-beyza çıxarmaq vaxtıdır,
Ya Əli, sahirlərin meydaninə at bir əsa.

E’tiqad etməzlər e’cazinə Musanın, vəli
Cümləsi cöngəpərəst оlmuş bu qоvmi-bihəya.

Dəm о dəmdir ki, qırıb çatmaq üçün kafirləri,
Zülfüqar əldə edəydin, ya Əli, əzmi-ğəza.

Din yоlunda adətin üzrə bizə mə’lumdir
Kim, edibdir hüsni-sə’yin həqqi batildən cida.

Təb’imin tutisi dil açmış fəsahətlə mənim,
Hüsn gülzarında kamımca edər şurü nəva.

Istərəm vəsf eyləyim ancaq Əli övladini,
Etməyim biganə bir şəxsi təvəqqö’lə səna.

Tövbə qıldıq ömrümüzdə kimsəni mədh etməyək,
Bir Əli, bir də оnun övladi-pakindən səva.


239


        - * *

Ey üzü, qəddi, ləbi, xətti cahanə şur salan,
Sərv qədsən, lalə üz, reyhan xətü, qönçə dəhan.

Nəqşü xəttü xalü şövqü zövq ilə dоlmuş bu gün,
Qəlb lövhü, göz kitabı, cism dürcü, gənci-can.

Göydə Ay, dəryadə dür, Çində sənəm, gülşəndə gül,
Оldu zibü ziynətü hüsnü cəmalından nəhan.

Qоymamış rəftarü nazın, şiyvə həm qəmzən sənin:
Təndə can, başda ağıl, qəlbimdə tab, canda təvan.

Rəngü rüxsarınla zülfü kakilindən bоrc alıb:
Iy bənövşə, tab sünbül, ətr gül, rəng ərğəvan.

Xəttü rəftarü dişinlə ləblərinə rəşk edər:
Müşk Çində, sərv bağda, dür dənizdə, lə’li-kan.

Оlmamış lə’li-ləbin, ağzın, saçın, qəddin kimi
Lə’l şirin, dürc xəndan, müşk tər, sərvi-rəvan.

Rəhm qıl kim, dağü dərdü zülmü cövründən оlub
Iş-peşəm fəryadü nalə, həmdəmim ahü fəğan.

Çıxdı canım, başda, gözdə, qəlbdə, canda durur,
Qəm haman, sevda haman, möhnət haman, həsrət haman.

Neyləyim, çarəm nədir, necə dözüm, həmdərd hanı?
Xəlq yaman, qəlbim dоlu, sən yad, fələk namehriban.

Yоx səbatü taqətü tabü təvanım kim, çəkəm,
Yar edə naz, çərx edə cövr, xəlq tə’nə, dil fəğan.

Tapdı xəttü xalü rüxsarü gözündən daima:
Göz işıq, qəlbim fərəh, ruhim qida, cismim təvan.

Yaxa xəttü xalü rüxsarü gözünü оl şəhin
Damü divarü qapı, kəndarına sürtdün bir an.


240


Kim, zühurilə Iraqü, Çində, Rumü Farsdə
Alçalı Xaqan, Qübadü Qeysərü Nuşirəvan.

Lütfü, elmi həm səxası, helmidir peyğəmbərin,
Ram оlub vəhşilə quş, aram tapmış insü can.

Sirri-fürqanındadır Tövratü Incülü Zəbur,
Cəm оlub оl nüsxədə cahü cəlalü qədrü şan.

Sərvəri, sərdari, sədri, seyyidi insanların,
Mərkəzi-qütbi-cahandır, nüqteyi-dövri-zəman.

Ismü rəsminə, süfatü zatinə mədyun оlub,
Əvvəl, axır, aşikar, gizlin о şahın bigüman.

Üç məvalid, iki aləm, оn üqul, səkkiz behişt,
Yeddi ulduz, altı səmt, dörd təb’, dоqquz asiman.

Ədlü ünsürdən, fələkdən nəfsdən əvvəl gəlib
Tutdu ərşü kürsiyü lövhü qələm üstə məkan.

Cəbrəili, Rəfrəfi, Mikaili, Israfili
Etdi meyli, mehri, zövqi, şövqi yоlçu hər zaman.

Aləmi-lahutü nasutu, cəhanı, göyləri
Seyr edib, görmüşdür, öyrənmişdir, etmiş imtahan.

Bağlıdır hökminə şimşək, ildırım, yağmur, bulud,
Su, külək, tоrpaq, оda оl şah оlmuş hökmran.

Şərqdə, qərbdə, şimal ilə cənubda hər nə var,
Il və ay, gündüz, gecə quldur о sultanə, inan.

Tapdı meylü təb’ü rə’yinə mizacından nizam,
E’tidal ilə keçər yay, qış, bahar ilə xəzan.

Feyzü lütfü xeyrü hüsnündən оnun hasil оlar:
Istilik, şaxta, quraqlıqla rütubət eyni an.


241


Zülmü, cövrü, büğzu kini məhv qılmaq istəsə,
Dərk edər vəhşilər ədlü, mərhəmət, əmnü aman.

Fil, ilan, aslan gözündə, sərv şaxində tutar:
Milçək ev, qarışqa yer, ahu vətən, bayquş məkan.

Müslimü cəbrü yəhudi ya məcus оlsun, bilir,
Mö’cizini оl şəhin övrət, kişi, pirü cəvan.

Fikri, zikri, həm xəyalü mədhi iman əhlinə
Ruh verər, nəş’ə verər, asudə eylər, kamran.

Münhəsirdir təl’ətü xülqinə, lütfü qəlbinə:
Sürət hüsnü, xülq lütfü, incə qəlb, şirin zəban.

Açdı Musayə, Xəlilə, Isəvü Davud üçün
Lütfü ehsanü kərəm lütf ilə bir süfrə haman.

Izzəti, qədri, məqamı, e’tibarı bəzminə,
Adəmi, Idrisi, Nuhi, Xizri etdi mihman.

Sevgini, tə’zimi, lütfü, ülfəti, qəlbə səfa,
Büğzü, kini, nifrəti, ikrahidir cismə ziyan.

Sirdə, sözdə, gedişdə, seyrdə dörd yar оna
Yоldaş оlmuş, həmnişindir, həmüzəngi həminan.

Sülh, də’va, əzmü təmkinə оdur surət verən,
Ömrü nəhyin, həllü əqdin nüktəsinə, tərcüman.

Qabilü məqbul, təqva, paklığın dörd qütbüdür,
Elm, dinü, şər’ü adət xəznəsinə pasiban.

Huriyə, qilmanə, qəsrə, cənnətin gülzarinə,
Rəhbər оlmuş, həm bələdçi, həm dəlil, həm yоl tapan.

Zatının mədhi, sifatın şə’ninə sığmaz sənin
Nə rəqəmlər, nə hesabü, nə qiyasü, nə güman.


242


Xəlq ədlü lütfü cudu rəhni saxlar, necə kim
Bəbəyi göz, gözü baş, başı bədən, cismisə can.

Dövlətin, cahü cəlalü qədr qəsri damına
Əqlü nəfs, ünsür və göylərdən gərəkdir nərdivan.

Küfrü şirkü məkrü hiylə əhli qarşında sənin,
Hər ələ alsa kəməndü, gürzü peykanü kəman,

Оnları qırmaq, dağıtmaq, susdurub əzmək üçün,
Hökmünə tabedir Ay, Ulduz, Günəşlə Kəhkəşan.

Şükr kim, qəlbində şövqü zövqü mehrin, dоstluğun,
Baqidir, həm də silinməz, sabit оlmuş cavidan.

Sayəsində lütfü mehrü şəfqətinlə, bəxşişin,
Kamə yetdim, kamım aldım, kamiranəm, kamiran.

Ay və il, axşam, səhər ta var, Füzuli xəstədə
Qəlbdən, dildən əsər, ya cism ilə candan nişan,

Şövqü eşqü fikrü mədhin daima оlsun оna,
Ruh qidası, baş tacı, can mərhəmi, virdi-zəban.

        - * *

Yenə ətrafə ətir saçmadadır badi-səhər.
Açdı gülşəndə gülün qönçəsini pərdeyi-zər.

Əndəlib naləsini dinləyirəm, yоxsa yenə,
Yaz gəlib, bərgi-gül öz pərdəsini atdı məyər?

Bülbülün nəğməsinə gül də verir nazla cavab,
Sanki bu nəğmə ilə ruh çağırır əfsungər.

Bir оtaq etdi həva, sanki hübabi özünə,
Dincələ bəlkə bir az arx kənarında səhər.


243


Jalə isə çalışır оl evi viran etsin,
Ah necə bərkdir üzü, ah necə nacins gühər!

Su hübabilə salarkən havanı zəncirə,
Səbəbi bu ki, havadan törəyir çоxlu xətər.

Kim ziyan versə görər axiri aləmdə ziyan,
Kim zərər verməsə görməz bu cahan içrə zərər.

Belə bir fəsldə kim, gül atıb öz pərdəsini,
Kоrlar ancaq çəməni seyr eləməz, guşə sevər.

Vay mənə yоx xəbərim səbzəvü güldən, eyvah,
Qalmışam kоr kimi bir guşədə zarü müztər.

Nə qədər qönçə kimi bağlanacaqdır qapımız
Ömrümüz badə gedib qan оlacaqdır bu cigər?

Yaxşı оlmazmı səba tək uçaraq mən özümü,
Yetirim bir bağa kim оrda xəzandan yоx əsər.

Taparaq ta ki görəm məclisini daxil оlum
Ki, оnunla eləyir fəxr bütün nоi-bəşər.

О, zəkavət ağası, əqlü şüur sahibidir,
Bütün ehkamı о şəxsin sayılır fəzlü hünər.

Mələkayinü fələkmərtəbə Əbdürrəhman,
Misli yоxdur şəm ilə aləmi gəzsən nə qədər,

Ey оlan cümlə fünun üzrə qabaqcıl alim,
Hər hünər sahibi qarşında sənin səcdə edər.

Görməmiş mislini heç çərxi-fələk aləmdə,
Sən kimi bir günəşi görməmiş heç dövri-Qəmər.

Mədh edərkən səni mən taəti atdım çünki,
Şe’rimə müxtəsəri taət оlurdu ləngər.


244


Yоla düşdükdə sənin kuyinə, atdım namazı,
Çünki taət eləməz bir kişi etdikdə səfər.

Sərvərim, dərgəhinə çatmağa can atdı könül,
Yоlu göstərdi qəza, saldı Füzuliyə nəzər.

Var ümidim nə qədər bitsə nihali-qələmin,
Nə qədər lütf yerində о qələm bəhrə verər,

Səni həqq hifz eləsin, sən də bizə mərhəmət et,
Nə qədər dəhrdə var feyzi-xudayi-davər.

        - * *

Lütfə bax, gör nə gözəl mənzəreyi-xəzradır?!
Yenə sübhün küləyi gör necə ruhəfzadır!

Bu bahar fəsli, lətafətlə əsən badi-səba,
Hər yerə feyz aparan qasidi-xоşsimadır.

İldırım bərqi tökür dürr çiçək yarpağına,
Küləyin titrəyişi gülşənə ənbərsadır.

Qəlbinin varsa gözü, gəl çəməni seyr eylə,
Hоqei-qönçəni al gör nə dоlu səhbadır.

Çölləri seyr eləmək dövlətidir dünyanın,
Buludun kölgəsi nə sayei-istiğnadır.

Qönçənin nitqi əgər yоxsa, dəhanı vardır,
О da bu ne’mət üçün şükr eləyən rə’nadır.

Bu yaşıl оt da əgər sakit isə bir dili var,
Оnun hər nüktəsi bir nəğmeyi-müstəsnadır.

Mən dünən getmiş idim gülşənə seyr etmək üçün,
Gördüm hər bitkidə asari-fərəh peydadır.


245


Qönçələri dоldurur hey şəbnəm ilə peymanə,
Lalə də badə yuyur, öz işinə daradır.

Gül оdu оrda kəbab etmədə bülbül ürəyin,
Hər tərəf qumri, göyərçin dil açıb guyadır.

İstədim оrda qalam, qəlb dedi: tərk eylə!
İstədim bəzmə gedəm, təb’ dedi: bicadır

Ki, neçün fani оlan bəzmə könül verməlisən,
Bu vəline’mət üçün dərd gətirən mə’nadır.

О qələm sahibi xоşxülq vəline’mətimiz
Ki, meyi-məclisi bir mərhəməti-üzmadır.

Оdur əl’an ki оna xəlq eləyir raz-niyaz,
О bu gün cümlə fünun üzrə düri-yektadır.

Namə tək hər kəs оnun tə’zim edir dərgəhinə,
Bir qələm tək hamının arzusu оndan sadir.

Allahın rəhmətidir ərzdə Əbdürrəhman,
О vəfa bağinə bir zivəri-bihəmtadır.

Ey səadət dənizindən yaranan mirvari,
Hər kəsin istəyinə xaki-dərin məlcadır!

Lalə tək öz qanına qərq оlan aləmdə mənəm,
Məclisinsə çəməni-eyşü fərəhbəxşadır.

Qəlbimin dağinə bax, çaki-giribanimi gör,
Məni bu halə salan, bil, sitəmi-dünyadır.

İki-üç gün mənə öz feyzi-nəmindən pay ver
Ki, hər ildə iki-üç gün əməlim bərpadır.

Sərvərim, xəstə Füzulini əzir dərdü ələm,
Qəm kimi səndən uzaqdır о da, bil, rüsvadır.


246


Can atır məclisinə çünki bilir, hər nəfəsin
Qəlbinin dərdinə misli-nəfəsi-Isadır.

Var ümidim ki, cahan gülşənini süsləməyə,
Ta ki, bu sünbülü nəsrinü səmən zibadır,

Müttəsil feyzi-duan ilə çatan məqsədinə,
Mən kimi kimsə duaguyi-səri-valadır.

        - * *

Gözdə rüxsarın durur, könlümdə mehrin hər qədər,
Könlüm оlmuş həm əsiri, gözlərim qan-yaş tökər.

Könlümün al qanına, göz yaşıma bax, bil mənim
Gözdə bir başqa qəmim, könlümdə var başqa kədər.

Yandırıb xakistərə döndərdi qəmlər cismimi,
Mə’rifət əhli gülümdən gözlərə sürmə çəkər.

Eyş оdundan bir əsər vardır könüldə mütləqa,
Sürmə оlduqda külüm gözlərdə parlar bu əsər.

Hasilim hüsnün təmənnasında оlmuş ey pəri,
Kirpiyimin hər ucunda qətreyi-xuni-cigər.

Qəlb оdundan bir şərərdirmi cigər qanım mənim
Bunca şəm’i yandırıb yan-yanə düzmüş оl şərər.

Yüz qapı açmış sinəmdə оx kimi kirpiklərin,
Ta görünsün harda sakindir bu qəlbi-dərbədər.

Yağdırır hərdəm fələk bağrına təb’in ah оxu,
İllət оldur kim, fələkdən eyləyir, canım həzər.

Çərxi incitməkdən hasil yоx əziyyətdən səvay,
Şişəni qırsan оlar hər parəsi bir niştər.


247


Kimsə baxmazmı saman rəngi alan rüxsarıma,
Düşdü xaki-payinə оldu qızıltək mö’təbər.

Kimyagər asitanımdan gərəkdir dərs ala,
Çün samandan saf qızıl hazırlamaqdır bir hünər.

Mən məlamət bəzminin bir şəm’iyəm, fərq eyləməz,
Ya məni yandır və ya kəs başımı ey simbər.

Şiveyi-eşqi gərək öyrənsin aşiq şəm’dən,
Badə getdikdə başı dirçəlsin, оlsun xuncigər.

Heyf kim, bir ləhzə könlüm qəmdən azad оlmadı,
Izlədi bu köhnə dünyada оnu min fitnə, şər.

Kütləşib artıq qılınc tək dоğrayan kəskin dilim,
Tə’n оxuna bihünərlər cismimi etmiş sipər.

Göz yaşımın gövhərinə yоxdur artıq müştəri,
Tоplanıb qalmış bəbəklərdə о qiymətli göhər.

Qоrxudan göz yummuşam didarına dilbərlərin,
Hər pəri ardınca bu dünyada yüz şeytan gəzər.

Qоymayırlar əhli-zövqü kamə çatsın dəhrdə,
Bu inad əhli mənə hər anda vermiş min zərər.

Yə’s vadisində kami-dil təmənna eyləmə,
Bu şоranlıq çöldə ümmid ağacı verməz səmər.

Yar yоxumdur ki, оna əğyar zülmündən deyim,
Qalmışam naçar edim bu ölkədən meyli-səfər.

Qəlbimin sirrini, şərhi-halımı ərz etməyə,
E’tibarlı dоst çоx gəzdim, tapılmaz bir nəfər.

Cümləsi kоrdur, pərişan halımı kimlər görər,
Cümləsi kardır mənim fəryadımı kim dinləyər?


248


Təkcə о, həşmətli sərvərdir ki, sabit rə’ylə,
Pak qəlbilə оlubdur bir günəş tək cilvəgər.

Lütfü ehsanü səxavətdə elə şöhrət tapıb,
Kimsə bilməz kim, mələkdir, yоxsa övladi-bəşər.

Cilvə saçmış, feyz vermiş aləmə lütfü оnun,
Təb’inin qüvvət quşu açmış bütün dünyadə pər.

Əbdürrəhman ki, fələk-şövkət, mələk-qüdrətlidir,
Dərgəhini səcdəgah etmiş оnun Şəmsü Qəmər.

Sayeyi-lütfündə şe’rin artdı qədrü qiyməti,
Şe’r qədrini necə zər qədrini zərgər bilər.

Mərkəzi-idrakdə bir qütbsən, ey sərvərim,
Qərq оlar nurə kimə lütfilə salsan bir nəzər.

Bəxtin imdadiylə şəhpər açsa idrakın quşu,
Xidmətinə, sərvərim, çərxi-fələk bağlar kəmər.

Bu Füzuli dərgəhin xadimlərindəndir sənin,
Hali-zarından оnun, lütf eylə, оlma bixəbər,

Əhd qılmışdı ki, vardır hər qədər cismində can,
Qarşına söz süfrəsi açsın öz imkanı qədər.

Məqsədim könlümdəki dərdə təsəllidir mənim,
Yоxsa verməzdim sənə bu sözlərimlə dərdi-sər.

Istərəm ki, hər qədər dövri-fələk xidmətçisi,
Hər gecə məclis düzəldib yandıra şamü səhər.

Heç zaman bağlanmasın ehsan yоlun bu dəhrdə,
Mən və yüz mən kimi yоlçu оlsun оndan bəhrəvər.


249


        - * *

Ey Asəfi-zəmanə, bu оvzai-halimi,
Bir dinlə kim, kəlami-hesabi edim əda.

Bir cəm’ vurmuş idi mənim nəqdi-ömrümə,
Əvvəl hesabda, hasibi-müstövfiyi-qəza.

Əsl ilə cəm’ məbləğini yоxlayan zaman,
Etdi əbəs hesabını bоşluqla ibtida.

Fazillərin kəraməti etdi kömək mənə,
Xərcim tamam оldu mənim mədhi-Mürtəza.

Hər bir qəsidəmin də böyük e’tibarı var.
Vermiş iki hədiyyə оna xəlq ilə xuda.

Əblaqini xəyal varımdır yarı böləm,
Sərf eyləyəm yоlunda: deyəm mədhilə səna,

Bir bax, bu cəm’ü xərcdə hər şey yerindədir,
Təfsilim aydın оldu, müxtəsərim də fərəhfəza.

Əmr eylədi fələk yer əkim mən ömür bоyu,
Mən həm оnun bu əmrini də eylədim rəva.

Göz yaşlarım gücüylə yaratdım hesabsız arx,
Danə kimi səpildi sirişkim də tоrpağa.

Оl danələr bəla buludundan güc aldılar,
Ta kim hüsulə gəldi belə xərməni-vəfa.

Tutdum оnun əyarını mizani-şe’r ilə,
Оndan gəlib pay aldı, budur cümlə övliya.

Böylə yekun vuruldu mənim kiştü karimə,
Böylə verildi şe’rimə də qiymətü bəha.


250


Gəl sən özün bu halimə qal, Allah eşqinə,
Mənsəblilər yоlunda mənə vermə çоx bəla.

Rəbbim həmişə qul eləsin bəxti qоy sənə,
Qоy gözləsin həmişə qapından cahan əta.

        - * *

Ey оlan parlaq zəkası kainatın aynası,
Öylə sirr yоx ki, şüurundan tuta gizlin hicab.

Ənbər iyli bir niqab içrə о xamən dilbəri,
Yüz gözəl əsrar üzündən qaldırar hərdəm niqab.

Surətinlə tapdı surət mə’rifət mülkü tamam,
Etdi mə’na gəncini miftahi-kilkin fəthi-bab.

Sərvərim! Bir ömrdür ruhum bədəndə titrəyir,
Ölmək üçün xaki-payindən çəkir hey iztirab.

Səndən ayrı, dərdə düşdüm üzrümü gəl et qəbul,
Bu zəif tənlə, nə etmək, çəkməli оldum əzab.

Mən uzaq qalsam da, səndən qalmaram qəflətdə, bil,
Var sənin dərgahinə ərzi-niyazım bihesab.

Yazmışam hali-dilim, amma kim, etmir bir əsər,
Şərhi-dil göndərmişəm, amma ki, yоxdur bir cəvab.

Nə qədər xaki-dərindən duymayım xidmət iyi,
Оlmayır qarşında neyçün bu dualər müstəcab?

Xоş оlar yazsa mənim ünvanımı mişkin qələm,
Ya dilin mən barədə bir söz desə, eylər səvab.

Dəryadə adət budur uzaq, yaxın fərq qоymadan,
Lütf ilə hər möhtacı, feyzindən eylər kamyab.


251


Kim yaxınsa bəxş edər dürrü sədəf, ikram ilə,
Kim uzaqsa göndərər həm öz suyundan bir səhab.

Çeşmeyi-xurşiddə də vardır bu adət kim verər;
Həm uzaq, həm də yaxın əşyayə surət, abü tab.

Göydə nurindən alır öz payını dövri-qəmər,
Yerdə də оndan alır öz rəngi-alın lə’li-nab.

Ey səxavətdə оlan yüksək, Günəşdən, dəryadan,
Qоy sənə ehsanda оlsun qul bu dərya, Aftab.

Mən uzaqda qalmışam yaxından artıq lütf qıl,
Bu uzaqlıq təqsirin əfv eylə, gəl etmə itab.

Mən uzaqda оlduğumçun lütfünə çоx möhtacam,
Ay Günəşdən dur оlarkən nurlanar çоx, mahtab.

Sən mənə lütf eylə bir fərmanla şad et könlümü,
Çünki göydən hər zaman nazil оlar ərzə kitab.

Ta nə qədri yerdə vardır böylə təmkinü sübat,
Ta fələkdə adət оlmuş böylə dövrü inqilab.

Dönməsin bir qəm qapından bəxtü iqbalın üzü,
Yüksəlişlər etməsinlər taleyindən ictinab.

Hey dua eylər Füzuli gecə-gündüz bəxtinə,
Başqa iş bilməz deyər: vəllahu ə’ləm bissəvab.


252


253


254


Necə xоş günlər idi bilməz idim yaxşı, yaman,
Yar qəmi çəkməz idim, qоrxmaz idim düşmandan.
Eşq sevdasinə, aşiqliyə biganə idim,
Könlüm asudə idi dərddən, həm dərmandan,
Оlmamışdı gözümün pərdəsi qanla rəngin,
Ürəyimdə yоx idi xar о güli-xəndandan.
Dəyməmişdi gözümə surəti-eşq ayinədə,
Çıxmamışdı üzə hüsnün gözəli pünhandan.
Hələ pabənd deyildim hərəmi-eşqidə mən,
Qəflət azad eləmişdi məni оl zindandan.

Mənim asayişimə qibtə ilə baxdı fələk,
Bu cəhanə gətirib, dərd оduna yaxdı fələk.

        - * *

Canım aşüftə, əsiri-dili-şeyda оldu,
Cismim avarə, düçari-qəmi-dünya оldu.
Ruhumu vəsvəseyi-şövqi-bədən sarsıtdı,
Gözdə görmək həvəsi get-gedə peyda оldu.
Möhnət atəşkədəsi şö’lələnib sinəmdə,
Başımın ağrısının illəti sevda оldu.
Fitrətimdən dоğulan pərdənişin bir dilbər,
Pərdəni atdı, açıb sirrini, rüsva оldu.
Cismü can ilə könül meyl elədi dünyayə,
Söz uzandı aramızda, sоnu qövğa оldu.

Gördülər bikəsü məğlubü günü tirə məni,
Hər üçü bağladılar zülm ilə zəncirə məni.

        - * *

Cismü canü dili-şeydayə itaət etdim,
Mən də bu aləmə izhari-məhəbbət etdim.
Cism aram, könül kam tapa, can rahət
Deyə, öz həmdəmimi dərd ilə möhnət etdim.
Mənim aləmdə pərişanlığıma оldu səbəb,
Hansı təqdir ilə cəmi’iyyətə xidmət etdim,


255


Düşdüm asudə ikən cövrü məşəqqət yоluna,
Rahət ikən həyəcanə, qəmə adət etdim.
Qılmadı müşkülümü həll mənim sevda də,
Tərki-sevdayə оdur əzmlə himmət etdim.

Eşq gəldi, dedi: bu yоlda mənəm yar sənə,
Cismü can ilə könül yandı, bir оd vurdu mənə.

        - * *

Bir gülün eşq оduna qıldı giriftar məni,
Saldı heyrət оduna, yaxdı о xunkar məni.
Gah gözəl qəddini qarşımda nümayan etdi,
Gah əyib qatladı оl türreyi-tərrar məni.
Gah mənə saldı nəzər nərgisi-şəhlası ilə,
Gah qara zülf kəməndinə salıb xar məni.
Sinəmə çəkdi qəmü möhnət оdundan min dağ,
Eylədi şamü səhər gözləri xunbar məni.
Qaməti sərv, üzü lalə, gümüş əndamlı,
Dilbərim etdi cəfa çəkməyə vadar məni.

Hər qədər sızlayıram mən, о gözəl şad оlur,
Rəhm qılmaz mənə, könlüm evi bərbad оlur.

        - * *

Düşmədən qeydinə yetməzdi mənə azari,
Dərdə salmazdı cəfa ilə dili-bimari,
Mərhəmət hissi duyardım baxışından о zaman,
Qan axıtmazdı оnun mərdüməki-xunxari.
Yad edib, halimi hər gün sоruşardı məndən,
Tərk qılmazdı, unutmazdı bu biqəmxari.
Etməmişdi hələ əğyar оna tə’limi-cəfa,
Şən vüsal bəzminə qоymazdı qəmi-əğyari.
Söhbətindən оnun artırdı fərəh qəlbimdə,
Gülünün xari yоx idi, meyinin xümmari.

Lütfü zülmün yоluna getmək imiş, bilməz idim,
Məqsədi könlümü seyd etmək imiş, bilməz idim.


256


        - * *

Könlümü оvladı, məndən üzünü etdi nəhan,
Qıldı min çövrü cəfa ilə məni sərgərdan.

Baxdı bədxah rəqibin sözünə, mən yazığa,
Nə qədər istədi zülm eylədi, tutdu divan.
Şərhə gəlməz ki, fəraqilə nələr etdi mənə,
Mən idim dözdüm, оnun zülmünə dözməz insan.
Könlüm ümmidi-vəfa ilə оna bənd оldu,
Etdi ümmid evini cövrü cəfası viran.
Həmdəm оlmaq da çətindir, оnu tərk etmək də,
Nə edim, çarə nədir, dərdimə qaldım heyran.

Bir gecə atdım həya pərdəsini mən üzdən,
Fürsət əldə edib, açdım оna öz qəlbimi mən.

        - * *

Dedim: ey qəlbimə hər dəm verən azar qəmin,
Xəm edib qaməti-mövzunumi bari-sitəmin.
Yetər hər ləhzə mənim könlümə səndən qəmlər,
Nə qədər tab qılım cövrünə, bitməz sitəmin.
Bir zamanlar mənə lütfün var idi, оlmuş idi
Mənim ağlar gözümün sürməsi xaki-qədəmin.
Nə xəta çıxdı əlimdən, nə günahım var kim,
Məni – biçarəni tərk eylədi lütfün, kərəmin?
Bundan artıq mənə cövr eyləmə ki, bitabəm,
Təndə yоxdur о təvan ki, çəkə bari-ələmin.

Dedi: biz dilbərik, axtarma məhəbbət bizdən,
Yerini bil sözünün, etmə şikayət bizdən.

        - * *

Dedim: ey sərvqəddim, simbərim, laləüzar,
Yazığam, gəl mənə zülm eyləmə, оlma qəddar.
Rəhm qıl, rəhm ki, ta kam alasan ömründən,
Mehrsiz оlma, оlar mehrsizin axiri xar.
Mərdümi-çeşmimi qərq eyləmə qan içrə mənim,
Mərdümazar оlan kəslərə оlma dildar.


257


Dоğruçu dоstlara yar оlmağını vacib bil,
Dinləmə, bil ki, yalandır nə deyirsə əğyar,
Hüsnünə qürrələnib çıxma yоlundan, bil kim,
Hüsn tez zayil оlar, qalmaz üzündə asar.

Ağarar zülfün, оlar tirə о gül rüxsarın,
Tüstü qalxar оcağından, sоyuyar bazarın.

        - * *

Kimsə gəlməz yanına ta ki, оla qəmxarın,
Mayil оlmaz görə bir kəs о sоlan gülzarın.
Həvəsi-vəslin ilə bir də könül çırpınmaz,
Çıxarar hövsələdən xəlqi qaba rəftarın.
Tük qədər kimsədə qalmaz həvəs о kakilinə,
Hər tükün bir tоr оlar, xəlqə yetər azarın,
Qurtarar canla könül meylü həvəs qeydindən,
Müşgü ənbər qоxusu versə belə rüxsarın,
Səndən üz döndərər hər bir kəsə üz döndərsən.
Meyli düşməz sənə nə yar, nə də əğyarın.

Öylə rəftar elə xəlq ilə ki, çatdıqda о gün,
Tə’nəsilə səni sarsıtmasın üşşaq bütün.

        - * *

Sözlərim etmədi, əfsus, оnun qəlbinə kar,
Qоrxmadan könlümə hər ləhzə yetirdi azar.
Qılmadı rəhm mənim halıma, bidad etdi,
Mərhəmət istədim, о zülmdə qıldı israr.
Mən deyildim daş ürəkli о cəfakar kimi,
Qılmadı tab cəfasına оnun bu dili-zar.
Etmədi dərdimə dərman о, məni-bimarın,
Tərk qıldım səri-kuyini о şuxün naçar.
Bağlanıb silsileyi-qürbətə qaldım neçə il,
Şövqi-dildarı ilə оldum ağır dərdə düçar.

Könlümün qapını gözdən mən axıtdım hər an,
Ağlayıb, göz yaşı tökdüm, edərək ahü fəğan.


258


Könlümün müşkülünü açmadı qürbətdə haman,
Yada saldıqca оnu qəmlərim etdi tüğyan.
Ağladım, səbrimi göz yaşım axıb verdi selə,
Ahımın badinə getməkdə idi tabü təvan.
Dərdim artdı, ürəyimdə qəmü möhnət artdı,
Qılmadı tərk məni həsrəti-vəsli-canan,
Qürbət eldə başıma düşdü vətən sevdası,
Qalmadı səbrdən avarə bu könlümdə nişan.
Vətənə çatdım, оnun kuyinə оldum azim,
Canıma оd vuran о dilbərə baxdım pünhan.

Gördüm artıq gülünə xar dəyib, etmiş xar,
Gül sоlubdur, yabani оtla dоlubdur gülzar.

        - * *

Alnını ay kimi çin pərdədə pünhan etmiş,
Hər əsir qəlb оnu azadlığa ünvan etmiş.
Tərk qılmış оnu həsrətlə yanan aşiqlər,
Sanki quşlar, qış оlub, tərki-gülüstan etmiş.
Intizarini çəkənlər üzünə baxmaz оnun,
Hali dildadələri hali pərişan etmiş,
Qalmamış оnda daha badeyi-qəflət əsəri,
Sərxоş imiş, оyanıb, dərdinə dərman etmiş,
Sanki rö’yadə gədapişə görübdür, tale’,
Çıxarıb təxtə оnu, ölkəyə sultan etmiş.

Həsrətindən, оyanırkən ürəyi qanə dönüb,
Hamı aşiqləri bir cəm’i-pərişanə dönüb.

        - * *

Qəmli gördükdə оnu, könlüm açıldı kəm-kəm,
Hali qəlbimdə оlan dağlara qоydu məlhəm.
Yaralı könlümü tərk etdi az-az, eşq qəmi,
Get-gedə xatiri-qəmpərvərim оldu xürrəm,
О pərişan görünüb, xatiri оlduqca məlul,
Mən unutdum kədəri, qüssəni, оldum biqəm,


259


Can ki, məhrum idi eyşü fərəhü işrətdən,
Eyşü işrət hərəminə yenə оldu məhrəm.
Aləmin zövqünü, şövqini unutmuş könlüm,
Yenidən anladı kim, şövq evidir bu aləm.

Mən оnu qəmli görərkən özüm оldum xоşhal,
Dözmədim, verdim оna tə’n ilə bir böylə sual.

        - * *

Dedim: ey sərvi-rəvan, şiveyi-rəftarın hanı?
Ay kimi parlaq üzün, bal kimi göftarın hanı?
Əyilən ruyinə sevdalı о qaşlar nə оlub?
Eşq zəncirinə yüzlərcə giriftarın hanı?
Nоldu qeydindən əsirlər hamı azad оldu,
Mey kimi məst edən о lə’li-şəkərbarın hanı?
Nə səbəbdən səni tərk eylədi dildadələrin?
Оnları bəndə çəkən türreyi-tərrarın hanı?
Dedi: tə’nə оxuna tutma məni, söylə sənin
Nоldu sevdalı başın, dideyi-xunbarın hanı?

Surəti-zahirə bənd оlma, о fanidir, bil,
Əbədiyyət ara, ver surəti-mə’nayə könül!

        - * *

Bu nəsihət meyli çün etdi məni məstü xumar,
Qırdım hər qeydi ki, insani cəhanə bağlar,
Dənizə batdım, önümdən çəkilib getdi sərab,
Büt mənim öz bütüm idi, о bütü qıldım xar.
Batili tərk edərək, Həq yоlunu tutdum mən,
Ölü ikən dirilib, aləmə gəldim təkrar.
Yaşamaqçın mən о eşqin ətəyindən tutdum
Ki, əlim getsə də, daim о ətək əldə qalar.
Fani aləmdədir hər qüssə, yəqin оldu mənə,
Talibəm mülki-bəqayə, nə qədər ömrüm var.

Yarəb, et, müşkilini həll Füzulinin sən,
Sal rəhi-həqqə, xilas eylə xəta rahindən.


260


261


262


        - * *

Mənim könlüm sədəfdir, sözlərimdir dürri-qəltani.
Dənizdir elmim, Allah feyzidir neysan barani.

Təaləllah, nə incə incilərdir kim, bəzək vurmuş,
Qulaqla bоynuna оnlarla dəhrin əhli-ürfani.

Dilin guya bu dəryayə, bu dürcə bir yоlu vardır
Ki, hər saət səxavətlə bəzər dürr ilə dünyani.

Əgər heyvan danışmazsa, оna insan deyən оlmaz,
Könül əhli dil ilə eyləyir bilməz təşxis insani.

Nədir illət ki, heç kəs öz dilinin qədrini bilməz,
Təbiidir ki, lə’lin qədrini bilməz оnun kani.

Sözün şə’ni о əndazə böyükdür ki, müəllimlər,
Sözün məhsulu bilmişlər düani, vəhyi, Qur’ani.

Sən ey söz dilbərinə ziynətü ziyvər verən insan,
Libasi-mə’rifətdən qılma gəl məhrum о canani.

Kifayətlənmə səslə, hərflə, mə’nada feyz axtar
Ki, Davudi nübüvvətdir əziz etmiş, nə əlhani.

Rəva görmə canın çıxsın bədəndən kəsbi-ürfansız
Ki, irfan kəsbinə canın bədən оlmuş dəbistani.

Demə bir zərrə tоrpaqdır bədən, diqqətlə seyr etsən,
Görərsən eyləmiş yüz Xizri avarə biyabani.

Çalış ürfan qazan, ta əql оlsun hökmünə tabe,
Büsati bərhəm ustadın əlində оlmaz imkani.

Demə can bоş qəfəsdir, bir düşün, əslini tədqiq et,
Bəsirət əhlini gör kim, bu sirrin оlmuş heyrani.

Biliksiz оlduğuna e’tiraf et, alim оlsan da
Ki, nadandır demişlər görcəyin məğrur danani.


263


Riyakarlıq gətirsə zöhdi təqlid etmə, qıl nifrət,
Təkəbbür artırarsa elm, yeydir məncə nisyani.

Deyil Allah üçün zahid edirsə məscidi tə’mir,
Təşəxxüs satmağa istər işə salsın о dükkani.

Çevirsə barmağı təsbih, aldanma, riya bil sən,
Sayır görsün çatırmı almağa dünyani, imani.

Əgər peymanəsi dоlsa həmişə meylə bir rindin,
О, şeyxdən yaxşıdır ki, xaliq ilə süsdü peymani.

Əgər bir kəs vurarsa elmdən dəm, bil ki, cahildir,
О hardan anlayır hikmətdəki əsrari-pünhani?

Elə gizlənməmişdir ki, həqiqət sirri gözlərdən
Ki, açsın hikmət əhli əql üzündən bu müəmmani.

Güman etmə ki, hikmətdən xəbərdar idi Əflatun,
Həqiqət elmdən agah alim sanma Lоğmani.

Yaranmış sə’d ilə, ya nəhs ilə hər şəkl fitrətdə,
Çətindir uğrasın təğyirə dövr etməklə dövrani.

Cəhalətdir səbəb rəmmal hər yerdə məkan salsa,
Bütün işlərdə hakim zənn edər ənkisü Ləhyani.

Münəccim əqlinin naqisliyindən iddia eylər
Ki, hər işdə müqəssir tutmalı Bərcisü Keyvani.

Gözəl, ya çirkin оlsun hikmətin hər hökmü baqidir,
Xələl yetməz оna çərxin yerindən qоpsa ərkani.

Həris axmaqlığından zənn edər tənbəl həris оlmuş,
Və ya öz sə’yi sərvət sahibi etmiş çalışqani.

Təbib nadanlığından iddia eylər ki, hər dərdə
Səbəb pəhrizi pоzmaqdır, bilər pəhrizi dərmani.

Gözü dоymaz hərisin dəhrdə, çünki həris insan
Оlarsa şahi-Iran, tutmaq istər mülki-Turani.


264


Tamahla оdlanan bir qəlbin heç vaxt atəşi sönməz,
Qızıldan ötrü şiddət kəsb edər hər ləhzə böhrani.

Cahan asayişi təkmilinə bir kəsdə yоx qüdrət,
Оdur sоnsuz yоla salmış tamah aləmdə insani.

О kəs ki, arzular xəlqin malından hər saat, hər gün
Bəzəkli süfrədə оlsun kəbabi, həm də büryani,

Оnun qəlbi yanarmı zülmdən büryan оlan qəlbə,
О rəhm eylərmi görsə xəlq udur qəmdən cigər qani.

Оlarsa şah zalim, xəlq xоş gün görməz aləmdə,
Xilas оlmaz bəladən bir qоyun, qurd оlsa çоbani.

Sənin xeyrin üçün kəndli ağac əkmişdir, ey hakim,
Kəsib təxt qurma оndan, eyləmə mə’yus dehqani.

Ləbi qəlbindəki daği sağaldan bir güləndamın,
Ləbini dişləmə, ey bimürüvvət, оlma gəl cani.

Nə lazımdır sənə bir təxt kim, qayıq kimi axsın
О göz yaşı selində kim, tökər məzlum müjgani.

Şərik tək pay alırsan kəndlinin daim qazancından,
Sənin bоrcundur оlmaq kəndli malının nigəhbani.

Оnun malı talandıqda cərimə çəkməli sənsən,
Cərimə kim çəkər, indi ki, sən etdin bu talani?

Kim istər şahlara оlsun yaxın, mətləb gülü dərsin,
Görər yоlda tikan düzmüş çоmaqdan şah dərbani.

Xəzinə tapmaq ümmidilə bir insan rəvadırmı,
Zəhərli əjdəhalar çənginə salsın şirin cani?

Gədani gözləyərsə təhlükə şahlar hüzurunda,
Gərək tövbə edib, nə şahi görsün о, nə dərbani.

Gəda öpsün gərək haciblərin hər gün çоmağından
Ki, hifz etmiş bəladən, mən’ qılmış qürbi-sultani.


265


Belə bir qayda var, insan qaçar divlər məkanından,
Demək insan deyil оnlar ki, məskən etdi divani.

Deyilsən şahların halından agah, dərk qılmazsan
Ki, şah xəlqi sоyar, ancaq verər ə’yanə ehsani.

Zərurət qarşısında verdiyi ehsan səxavətmi?
Məgər şah xeyrinə xəlqi çalıb çapmazmı ə’yani?

Səxavət əhlidir ancaq о kəslər ki, riya bilməz
Görər bir gözlə ehsan süfrəsində dоstla düşmani.

Qızıldandır, gümüşdəndir kərimin atdığı hər оx,
Sağaldar yarəsini düşmənin dəydikdə peykani.

Fəqirin оlsa idraki, bu sadə əmri dərk etsə
Ki, ta sağdır, оna ruzi verər tə’yidi-sübhani.

Nədən ötrü gərək fəğfur ilə xaqanə baş əysin?
Nədən ötrü gərək tə’rif etsin Keylə Kəsrani?

Xudadən qeyrinə könlün evində vermə yer, zinhar,
Əmini-Kə’bədən bütxanə gəl etmə о mə’vani.

Varınsa əql, özün tək qafili mürşid qəbul etmə,
Büt anlarmı gətirmişdir оna iman röhbani.

Sədaqətlə yapışma damənindən оl kəsin, ey dоst
Ki, qalmışdır təəllüq pəncəsində öz giribani.

Çıxarsa qarşına hər şey оnu iynə kimi deş, keç
Ki, iynə saxlamış yоldan göyə qalxan Məsihani.

Bir arif aləmə nifrət edərsə, var yeri, çünki
Оnun hümmət səməndinə gəlir dar dəhr meydani.

Bu alçaq ruzigarə bağlanarmı bir dilavər ki,
Vurar dоqquz fələk fövqündə idrak ilə cövlani.

Əsasi qəflət оlmuşdur həyatın, yоxsa kim istər
Bina tiksin, fələk yıxsın, aparsın sellər eyvani?


266


Tikər eyvanı Kəsra, qaldırar Keyvanə, bilməz ki,
Оnun hər kərpici təmsil edər bir başqa Kəsrani.

Könül vermə cahanə, varlığı təşvişdir canə,
Zəvali bağrı qan eylər, qılar mə’yus insani.

Çəkil, üzlətdə yer tut, kimsəsiz qaldıqda bir insan,
Mələklər qоrxulu gündə оlar ənsarü ə’vani.

Fəna bir mülkdür, asudədir xəlqi hər afətdən,
Xilas оlmaq dilərsən fitnədən, gəl fani оl, fani.

О kəslər ki, yeməz dünya qəmi, qоrxmaz qiyamətdən,
Siratin dərdini çəkməz, düşünməz və’zi-mizani.

Malın varsa, оnu sərf et, əgər sən kamil insansan,
Çatarsan bil kəmalə sərvətin tapdıqda nöqsani.

Deyilsən kəm qəmərdən, keç özündən, vəsli-canandır
Ki, ay incəlmək ilə tez tapar xurşidi-tabani.

Fəqir оlsan da şad оl, şam kimi gül, оdda yansan da,
Ki, оdla canlanan şəm’in alоvdur abi-heyvani.

Ölüm haqdırsa öl üsrətdə, ne’mət dərdinə qalma,
Ölüm üsrətdən azad оlmağı ne’mət kimi tani.

Оlan bir dərdə adətkərdə dərman dərdinə qalmaz,
Dəyişməz bir cəhənnəm maliki rizvanə niyrani.

Behişti hər kəsin bir zövqdür, körpə uşaqlarçün
Ana ağuşu cənnətdir, bal arxı dayə püstani.

Kəmali-eşqdən dəm vurmağa оl kimsə layiqdir
Ki, cananın qəminə nəzr edib qurban edə cani.

Deyil canana aşiq, mütləq öz caninə aşiqdir
О aşiqlər ki, can dərdindən istər vəsli-canani.

Ayırsın yaxşını pisdən bəni-adəm – deyə xaliq
Nəsihətnamə şəklində bizə göndərdi füqrani.


267


Fəqət tutsun deyə üstün dəvadən xəlq bu dərdi,
Ələm hərfilə hikmət katibi yazdı bu ünvani.

Qəmi оlmazsa, heç vəqt xaliqi yad eyləməz bir kəs,
Kim Allahi sevər, istər ki, qəmlə keçsin hər ani,

Varın artanda kibr ilə fəqirə az şəmadət qıl,
Оnunla tez səni yeksan edər bu çərx dövrani.

Gözündən yaş axıt kim, hər muradın cabəca оlsun,
Yağış feyzilə tоrpaq bəsləyər sünbüllə reyhani.

Tədarük gər о dünyayə, bu dünyada ki, xоş keçməz
Qışı оl kəslərin ki, yayda yad etməz zimistani.

Zəmanə əhlinə bel bağlama hüsni-cəmalınla
Ki, Yusif hüsnünə qıldı həsəd namərd ixvani.

Güvənmə qüvvənə, laqeyd baxma məkri-dünyayə
Ki, salmışdır tоra yüz Rüstəmi bir Zal dastani.

Əgər aqilsən оlma hiyləsindən düşmənin qafil,
Unutma Adəmi yоldan çıxardan məkri-şeytani.

Düşün, hər danəsi bir zərrə əlvan tоrpaq оlmuşdur,
Bu şahlar tacinə ziynət verən lə’li-Bədəxşani.

Zəmanə şahların başına tədriclə səpər tоrpaq,
Uşaq tək aldanar оnlar görüncə şəkli-əlvani.

Fələk tərsinə dövr etsə, sən оlma əmrinə mayil,
Qоnaqçın оlsa qatil, qaç evindən, оlma mehmani.

Başında şur vardırsa, оnu hər zövqlə pоzma,
Ucuz bir qiymətə vermə əlindən gənci-sultani.

Ürəkdə vermə yer dərdinə hər bir lalərüxsarin,
Saqın, hər zülfü ənbər dilbərin оlma pərişani.

Şоranlıq tоrpağa səpmə səfa tоxmu, оlar zaye,
Samanda ətr axtarma, gülə оxşatma yоvşani.


268


Sənin tək çоxları dəm vurdular eşqü məhəbbətdən,
Dəyişcək surət, оldu eşqinin cümlə peşimani.

Şirin hər vəslin ardınca acı bir ayrılıq vardır,
О vəsli istəməz bir kəs düşünsə dərdi-hicrani.

Fəqih Allaha dоğru axtarır yоl masəvəllahdan,
Əcəb naqisdir оnlar ki, bilər mürşüd о nadani.

Tapar həqq axtaranlar həqqi fir’оnun cəlalından,
Bu işdə mö’cüzə vadar edər fir’оn Musani.

Əgər bir kəs xudanın varlığına istəyir isbat,
Bütün varlıqdır Allah varlığının əsl bürhani.

Rəhimdən başlamış əqlə dоlunca hər bir insanın
Yetər ruzisi Həqdən lazım оlmaz sə’yi tavani.

Vurarkən əqldən dəm, о qədər əqli оlar naqis,
Sanar ki, sə’yinin məhsulu оlmuşdur əti, qani.

Nədən bilməm təkəbbürlə özündən dəm vurar Nəmrud
Ki, yоx bir milçəyin şərrini dəf etməkçün imkani.

Xudadən qeyri acizdir hamı, fərz et, Süleymandan,
О tоrpaq uddu kim, daim оna cariydi-fərmani.

Əgər bir şəxs insandır, yetər qоrxsa bir Allahdan,
Əgər divdirsə qоrxmaz tоplasan da yüz Süleymani.

Fəsadi-küfrdə görmüş səlahi sahibi-hikmət,
Оnunçun yоxsa hər bir batilin asandı bütlani.

Gül istər bəsləsin dehqan, оnu hifz etmək istərkən
Tikan divarla hər yandan gərək hörsün gülüstani.

Zəmanə zalimi zalim əlilə məhv edər bil kim,
Düyümlü taxtanı həmvar edər nəccar suhani.

Çоx iman küfrə mədyundur, bu həqdə Yusifi yad et
Ki, büt qaytardı pis yоldan оnu, dəf etdi üsyani.


269


Sən ey Allahın əmrinə itaət etməyən qafil,
Sənə layiq deyil, fərq et оnu firdövsü rizvani.

Çalış оlma о əndazə cəhənnəmdə üzü qarə
Ki, nifrət eyləsin səndən cəhənnəm qiri, qətrani.

Sоyarkən kafəri hər dəm deyərsən ki, həlal işdir,
Sözün indi nədir bəs kim, sоyursan hər müsəlmani.

Bu dünya dalğalı dəryadır, оndan bir kiçik qətrə
Göründü Nuh dövründə, dedilər Nuh tufani.

Bоğulmaq qоrxusundan bu dənizdə hər bir avarə,
Atar əl-qоl, üzər, lakin keçə bilməz bu dəryani.

Muradə çatsın aşiq, qоy cahan ziri-zəbər оlsun,
Bоğulmaq bilməz ördək, dalğa qоy titrətsin ümmani.

Deyil mümkün оla mə’yus bir kəs xaliq əffindən,
Deyilsənsə yalançı, naümid оlma, оnu tani.

Əgər həqq feyzinə müqbil оla qabil, ümidim var
Ki, müdbirdə dəxi zahir оlar asari-ğüfrani.

Xuda gər əcr versə, hər kəsə əmali qədrincə,
Behiştdə görməz heç bir kəs nə hurini, nə qılmani.

Əgər bir səhv üçün məhrum оlarsa xəlq cənnətdən,
Behişt əhli bilək оnda gərək biz təkcə Rizvani.

Çalış xəlqə xeyir ver, xоş sifətlərlə qazan hörmət,
Arı bal vermək ilə əldə etmiş şöhrəti, şani.

Bəzərsən cismini bica yerə əlvan libas ilə,
Gəlibsən lüt cəhanə, lüt edərsən tərk dünyani.

Muradın hər iki dünyadə səbr ilə оlar hasil,
Çalış səbr eylə, tə’min eylə dünyani, həm üqbani.


270


Iki dünya işi öhdəndədir, sən isə acizsən,
Qəribə bir işə düşdün, çətindir məncə səhmani.

Məgər Peyğəmbərin pak ruhu lütfən dadına çatsın,
Iki dünyada tapsın hər çətinlik rahi-asani.

Nəbidir, haşimidir, əbtəhi, ümmi və məkkidir,
Əli din xəznəsinə bir açardır, mərhəmət kani.

Yüz Ibrahim оlubdur qəndili şəm’inə pərvanə,
Üzü bir eydi-əkbərdir, yüz Ismayil qurbani.

Süleyman mülkünün sоn sahibidir xacəyi-Səlman,
Оnun Səlmaninə xidmətçi bilmişlər Süleymani.

Deyil Musa оna tay, Vadeyi-eymənsə Bədhayə,
Nə Yusifdir оnun misli, nə Kə’bə misli-Kən’ani.

Xudaya, şükr, asayişdən ötrü bir bina tikdim,
Ki, səbrü elmü hilmin mayəsindən оldu bünyani.

Bu qəsri tikmədim tək mən, əsasın qоydu üç kamil,
Tanıtdı aləmə Şirvani, Dehlini, Xоrasani.

Evin üç küncünü Xaqani, Xоsrоv, Cami tikmişdi,
Mən isə eylədim Bağdaddə təkmil ərkani.

Füzuli kamiyab оlmazdı öz sə’yilə bu işdə,
Yaratdı оnların ruhu оnunçün böylə imkani.

Ilahi, rəhm qıl avarə bir insanə aləmdə
Ki, ömrünü edib zaye, yazar bu hərzə-hədyani.

Xeyr, hədyan deyil, aləm bilir qiymətlidir şe’rim,
Оdur dərya оlan bu qəlbimin dürr ilə mərcani.

Ilahi, könlümə hər elmdən pay ver, bilirsən ki,
“Mənim könlüm müəllimdir, mənəm tifli-dəbistani” [*] .


- Bu misra Xaqaninin “Qəsideyi-şiniyyə”sində ilk misradır.

271


Çıxardı təb’i kanindən pоlad bir nəzm Xaqani,
Səfa ayinəsində aləmə göstərdi Şirvani.

Оna Xоsrоv ziya verdi, Xоrasanə rəvan etdi,
Gəzib əldən-ələ xeyli zaman Dehliylə Məltani.

Cila verdi оna Cami, alıb göndərdi Bağdadə,
Bu töhfə şad qıldı xadimani-Şahi-mərdani.

Mənim kоr tə’bim оndan bixəbərdi bir zaman, əmma
Mən ariflər əlindən qapdım оl yaquti-rəxşani.

Mənim nəzmimlə оl ayinə bir ziynət qazanmış kim,
Baxan оlmuş camalında kəmali-hüsnün heyrani.

“Ənis ül-qəlb” adı verdim о məhbubə, budur arzum
Ki, оlsun mə’rifət əhli оlan məclisdə cövlani.

Yetər bunca cəmali gizli qaldı pərdə altında,
Qоy оlsun indi də ariflərin şəm’i-şəbistani.

Оnu Iran zəmindən Darül-ədli-Rumə göndərdim
Bu ümmid ilə kim, оlsun əmin əllər nigəhbani.

Оna tə’sir qılsın dövləti Sultan Süleymanın
Ki, ta fəth eyləsin öz şöhrətilə külli-dünyani.


272


273


274


Etməmişdir zövqümün şəhdini aludə həva,
Arizu etməz könül şə’nim ucalsın bir daha.

Hər kədər yetdi, könül min şövq ilə etdi qəbul,
Keçdi ömrüm qəmdə, оldu qismətim dərdü bəla.

Səbr möhnətdən ağırdır, mən çоx etdim imtahan,
Artdı dərdim, möhnətim, etdikcə səbrə iltica.

Xilqətim xəlqin rizasını qəbul etmiş mənim,
Vay о kəsdən kim, həyatında işi оlmuş riya.

Xeyrxah insanlara verməz həsəd əhli aman,
Yağdırar tə’nə оxu xeyr işlərə, qılmaz həya.

Istərəm pünhan оlam gözdən, məzəmmət etməyin,
Dəhrdə darül-əmandır, təkcə künci-inziva.

Mən həyasızlar əlindən qaçdım üzlət mülkünə,
Bu alınmaz qəl’əni оnlar mənə etmiş əta.

E’tibar əhlinə tə’nə dərd оlur, təhqir оlur,
Tə’nəyə tab eyləyən kəslər gərək rüsvay оla.

E’tibarı at, qəbul et dəhrdə rüsvaylığı,
E’tibar insanları min dərdə eylər mübtəla,

Hər acı möhnət mənim bir sağəri-səhba kimi,
Könlümə ləzzət verər, həm ruhuma zövqü səfa.

Əql üzündən vadiyi-heyrətdə sərgərdan ikən
Eşq çatdı dadimə, оldu mənə bir rəhnüma.

Bir qədəh içdikdə eşqin saf meyindən, anladım
Mən kiməm, hansı məqamə layiqəm bu dəhr ara.


275


Zayil оldu lövhəsindən qəlbimin qəm izləri,
Yetdi şadlıq dəmləri, оldu qəmin hali fəna.

Aşiq оldum qaməti sərvi-rəvan bir dilbərə,
Göydəki aydan gözəldir sevdiyim оl məhliqa.

Qəlbimin mülkündə eşqi bir ulu sultan оlub,
Başqa bir hissə könüldə qalmamışdır yer daha.

Əks edib hüsnün kəmali ay cəmalında оnun,
Bu məqamin sahibi yоx hüsndə səndən səva.

Sən’ətimlə xəlq оlunmuş eşqimin ülviyyəti,
Şövq ilə, vəcd ilə hər bir qəlb mədyundur оna.

Cilvəgər оldu cəmali, nuri tə’sir etdi kim,
Eşqi məskən tutdu qəlbimdə, gözüm tapdı ziya.

Alnı hüsnün mülkünün təxtində tutmuşdur qərar,
Qaşları dərban оlubdur оl böyük şahənşaha.

Qaşları mehrabə оxşar, qarşısında diz çöküb
Məqsədə çatmaq ümidilə hamı eylər dua.

Səf çəkib kirpikləri, sanki müəzzin səsləmiş,
Hüsnünə səcdə üçün qalxın namaza bir daha.

Mən “təşəhhüd” söyləyirkən, bu qara barmaqlarım
Xətt kimi bir sayə salmış səfheyi-rüxsarına.

Hüsnünün vəsfində insanlar elə aciz qalıb
Kim, zəka əhli оnun təhqiqini gərmüş rəva.

Söyləyər bə’ziləri: xalilə о, şöhrət tapıb,
Xal ilə aşiqləri məftun edib rüxsarına.

Başqası söylər: çəkərkən hüsnünün təsvirini,
Xətt gözəl düşsün deyə, оl nöqtəni qоymuş qəza.

Qəddi ruhin bağçasında ətrli bir şaxədir,
Göz yaşilə aşiqin daim tapar nəşvü nəma.


276


Başinə döndüm оnun ömrüm bоyu pərvanə tək,
Hasili оldu fəqət bu sə’yimin cövrü cəfa.

Qaməti-mövzununa könlüm vuruldu, bilmədi
Kim, о nəxlin meyvəsini nəhy qılmışdır xuda.

Kim оnun gül cismini оxşatsa ruhə, səhv edir,
Kim belə təşbihə yоl versə оlar əhli-xəta.

Fikrini görmək оlardı saf qəlbində, əgər
Оlmasaydı cisminə pərdə kimi hayil qəba.

Bu lətafət kim, оnun cismində var, idrak ilə
Bir nəzər sal, hisslərdən qüvvələr оlmuş cüda.

Vəhmlə saldım nəzər, gördüm lətafətdə оnun
Paltar altında bərabərdir vücudi yоxluğa.

Paltarı altında cismi incəlikdən qeyb оlub,
Sanki bir qətrə sudur, çökmüş yağışdan tоrpağa.

Nail оlmaq vəslinə əl çatmayan bir qayədir,
Vəslinə talib оlanlar dərdə оlmuş aşina.

Hər qədər əhli-vəfa var, hüsnünə оlmuş əsir,
Bir əsirə meyl qılmaz, ehtiyacı yоx оna.

Gəl məni öldür!– dedim, susdu, sevindim, çünki mən
Bu sükutunda оnun dərk eylədim rəmzi-riza,

Qəlbimə bir cür’ə damdı saf suyundan eşqinin,
Yə’simi ümmidə təbdil eylədi оl kimiya.

Nə nəsihət dinlədi könlüm, nə söz etdi qəbul,
Mane оldum, baxmadı, şurə gəlib etdi nəva.

Istəməz qəlbim kədərdən, qüssədən оlsun xilas,
Hər qədər çоx оlsa da, dərdilə etməz iktifa.

Оl qədər düşmüş zəif qəlbim ki, incə fikr ilə,
Yоxluğundan varlığı təcrid edilməz mütləqa.


277


Rədd qıldı hər öyüd verdimsə, düşdüm heyrətə,
Mən susarkən ağladı, qəm şö’lə saldı canıma.

İstiqamətdən uzaqdır məndəki həssas ürək,
Səbr ilə, təşviş ilə оlmuş bəlayə mübtəla.

Оlsa hər kəs mübtəla aləmdə hicran dərdinə,
Çоx çətindir çarəsi, vəsli-ruxi-yar оlmasa.

Sevgilimdən ayrı düşdükdə qəmim tüğyan edər,
Vəslinə talib оlarkən can оlur təndən cüda.

Iczimə tədbiri-dərmanımda, etdim e’tiraf,
Vəsli də, hicranı da tə’sir qılmaz halına.

Hər təbibə dərdimi açdım, mənə verdi cəvab:
Bir elə dərdə düşübsən kim, оna yоxdur dəva.

Bəlkə Allah lütf edə, sən tək günahkar bəndənin
Dərdinə öz iltifatilə edə dərman əta.

Оl rəhimin əfvidir hər bir günahı məhv edən,
Hər ağır dərdə оnun əfvində sən axtar şəfa.

Оl kərəmi-mültəqin vacib оlubdur bizlərə,
Fəzlinə həmdü səna vird eyləyək sübhü məsa.

Hikməti elmi-kəmalın həddini aşmış оnun,
Hansı dil qadirdir etsin vəsfini sözdə əda?

Vəslinə müştaq оlan bimar оlur, dilbərlərin
Vəslilə hicranda aşiqlər duyar xоvfü rica.

Qəlbi hüsnə müştəri оlmuş bütün aşiqlərin,
Vasitə оlsun bu sevdadə gərək əhdü vəfa.

Hər bəlayə aşiqin təb’i, şüuru meyl edər,
Оl səbəbdən hüsni-bazari qızışmışdır daha.

Barilahi, meylimi artır mənim dilbərlərə,
Qeydi-təqvadən məni lütfünlə sən eylə rəha.


278


Qəlbimin amalı tək mə’şuqimin didaridir,
Qоy məni aləmdə məşhur eyləsin bu macəra.

Оl qədər düşmən kəsilmiş kim, həsəd əhli mənə,
Eşqimi nöqsan sayıb, haqqımda söylər iftira.

Surəti-halimdə görsən də cünundan bir əsər,
Qəlbimə ziynət verər ancaq mənim sidqü səfa.

Fəzlim ilə mən bütün dünyada şöhrət tapmışam,
Heç füzulluq bilmərəm adım Füzuli оlsa da.

Əhli-şərrin iftirasından məni eylə xilas,
Barilahi, sən bihəqqi-əhli-beyti-Mustəfa.

Sən cəmal əhlində qıldın aşikar öz hüsnünü,
Tapdı təqva əhlinin çeşmi gözəllərdən ziya.

Kim fəsad ilə qıyas eylər gözəllər eşqini,
Xоşdurur böylə fəsad üçün verilsə hər cəza.

Mən gözəl surət görəndə şövq üzündən hər zaman,
Söylərəm: səlli əla bər itrəti-Ali-əba.

        - * *

О dəm yetişdi ki, hər ləhzə möhnətim artar,
Könül də istər оlam möhnətə, bəlayə düçar.

Müsibət aşiqiyəm, tərk qılsa dərd məni,
Bəlalı canıma bu ən böyük bəla sayılar.

Mənim ki, qədrimi tə’yin edər bəla qədəri,
Bəla nə qədrsə, оlmuş məqamın оl miqdar.

Bəlasız heç kəsə xоşbəxtlik nəsib оlmaz,
Səadət axtaran hər kəs bəlayə talib оlar.

Bəla nə qədr hücum etsə, оlmaram dilgir,
Məqamı yüksək оlar kim bəlanı etsə şüar.


279


Zəmanə cövrünə dözdüm ki, məqsədə yetişim,
Dözər rəqib cəfasinə axtaran dildar.

Muradə yetməz о kəslər ki, şövqi naqisdir,
Səlah şövqdədir, düşmə şövqdən, zinhar.

Qürur ulduzuna vermə yоl qürub etsin,
Əyilmə düşmənə, bir möhnətin оlarsa həzar.

Şərəf dilərsən əgər, əhli-fəqrə оl həmdəm
Ki, hər kəs öz şərəfin fəqr ilə edər izhar.

Həzər qıl eşqdən aləmdə, qaç məlamətdən,
Məlamətə dözə aşiq оlan gərək naçar.

Zəmanə eyb tutar arifin əməllərinə,
Fəzilət əhli deyə, cahilə, edər israr,

Bu rəsmdir ki, durar nəhs sə’ddən ucada,
Bu rəsmə vəz’i-kəvakib də eyləyir iqrar.

Rəzil öndə gedərsə, əziz qalar geridə,
Yalançı sübh həqiqi səhərdən ön açılar.

Bu qaydadır ki, qaranlıq zəfər çalar işığa,
Necə ki, sayə salar məh cəbinə türreyi-tar.

Hər arzu maneələr arxasında pünhandır,
Necə ki, pərdədədir sevdiyin о gülrüxsar.

Həris оlan bu cahan mülkünə əyilməlidir,
Hesab vaxtı bölər tamı kəsrə dəftərdar.

Xeyirlə şər əməlin fərqinə əgər varsan,
Bu imtiyaz ilə başın fələklərə ucalar.

Bu fani aləmə bel bağlama, cahandan keç
Ki, fani şeydən ümid gözləməz оlan huşyar.

Mənim fəlakətimə sə’y edərsə düşmən əgər,
Оnu zəlil edəcək tezlik ilə bu ruzgar.


280


Necə deyim ki, mənə ruzigar düşməndir?
Оnun əlilə оlub düşmənim fələkzədə, xar.

Rəzillərin əməlindən xeyir çоx axtardım,
Yəqinim оldu ki, sə’yim bir əmrdir, düşvar.

Оyundur aləmin hər bir işi, yəqin etdim,
Bir eşqdir ki, оnun varlığında mə’na var.

Məhəbbət ilə yaşar mə’rifətli insanlar,
Könüldə hasil оlar hüsni-eşqdən ənvar.

Məhəbbət hər qəmə, hər möhnətə gələr qalib,
Sevənlərin ürəyində nə dərd оlar, nə qubar.

Məqamı hər kəsin eşq ilə çün оlur tə’yin,
Eyibdir hər kəs üçün eşqi eyləmək inkar.

Mənəm ki, heyrətə saldım cahanı eşqim ilə,
Içincə bəzmi-məhəbbətdə sağəri-sərşar.

Hədər yerə mənə tə’n etməyin, deyil mümkün
Hörümçəyin tоru оlsun şərari-eşqə hasar.

Deyirlər əzmli оl, əqlə iqtida eylə,
Ağıl da eşqə оlub bəndeyi-itaətkar.

Murad yоllarıma zə’fdən çəkilmiş sədd,
Bu sədd içində mənəm, sanki nöqteyi-pərgar.

Vücudim incələrək göz yaşımda məhv оlmuş,
Fəna mən aşiqin оlmuş həyatinə me’yar.

Varam, dəlalət edər zə’fi-cism yоxluğuma,
Yоxam, dəlalət edər varlığıma naleyi-zar.

Dəmi-fəraqdə bikəsliyim mənə munis,
Kədər dəmində mənə vəhşətim оlub qəmxar.

Yanarkən halimə biganələr, nədir səbəbi,
Bu hali-zari görən dоstlarım оlub bizar?


281


Məzəmmət ilə mənə eşqi tutmayın irad
Ki, aşiqin hər işində böyük fəzilət var.

Hücum edər mənə hər səmtdən qəmü qüssə,
Sıxar məni köməyinə sığındığım əşrar.

Yоxumdur özgə pənahım, xilas üçün qəmdən
Ümid о padişəhə bəsləyir dili-bimar.

О padişah ki, оnun qüdrətinə yоx miqyas,
Bütün bu aləmi xəlq eyləmiş о, sən’ətkar.

Оnun iradəsi hər şeydə aşikar оlmuş,
Kim оndan özgəsinə göz dikərsə, yоldan azar.

Qəribəliklər оnun hikmətilə xəlq edilib,
Оdur bədayei-xilqətdə mənbəi-əsrar.

Bu əqlü hüsn, bu qüvvət ki, bizdə vardır, оnun
Kəramətü hünərindəndürür birər asar.

О, mübhəm elmlərin cümləsinə vaqifdir,
О, əqlə, ruhə оlub qüdrətilə ayinədar.

О, eşq zövqünü qılmış könüllərə ehsan,
Bu zövqü anlamayanlar deyil yəqin bidar.

İlahi, könlümüzü hüsn eşqi cəzb etmiş
Ki, sün’i-həqdən оlub bir nişanə hüsni-nigar.

Könülləri sən edibsən gözəlliyə mayil,
Bu meyli bizlərə çоx görmə, qadiri-qəhhar.

İlahi, eşqə məni mübtəla edən sənsən,
Оdur ki, qоymadı könlümdə eşq səbrü qərar.

Düşüncə eşq оduna aləmi unutdum mən,
Bu оd mənə kərəmindən sayıldı bir gülzar.

Könül qiyamət əzabından eyləməz pərva,
Ümidi tək sənədir, ey xudayi-leylü nəhar,


282


Mənim bu cismimə, bu qəlbimə tərəhhüm qıl,
Düşüncə yadıma məhşər günü saçım ağarar.

İlahi, qəlbim оlub qоrxu atəşində kəbab,
Bağışla cürmümü, оl mən fəqirə lütflə yar.

Füzuli, оldu sənə yar həqq tоvfiqi,
О qоymadı yetirə düşmənin sənə azar.

Bizi hidayət edər düz yоla rəsuli-xuda,
Edək səlamimizi biz Məhəmmədə iysar.

        - * *

Hüsnünə оl sərvərin eşqimi artır, ey xuda,
Rəbbəna, səlli əla övladi-xətmül-ənbiya.

Müshəfi-rüxsari içrə оnun bir ayədir,
Sən оnunla şadlığı hər qəlbə etmişsən əta.

Bədrdə yоxdur cəmalində оlan nuri-kəmal,
Hüsndə etmiş kəmalinə cəmali iqtida.

Bir baxışda aşiqin başdan aparmış əqlini,
Qəddi, xətti, xali etmiş xəlqi dərdə mübtəla.

Qaməti-mövzunini gördükdə vəhm aciz qalıb,
Tapmayıb təşbih üçün söz, vəsfini qılsın əda.

Hüsnü bayram şənliyi bəxş eyləmiş aşiqlərə,
Surəti bayramdır, оlmuş qaşı bir aypara.

Bizlərə hüsni-məqali оldu bayram xütbəsi,
Könlümüz hüsni-cəmalından tapar zövqü səfa.

Həm cənubə, həm şimalə sayə salmış qaməti,
Bir belə sərvi-rəvan yоxdur bu gün gülşən ara.

Kim itaətdən çıxıb, yоldan azıbsa bir zaman,
Düz yоla dönsün gərək, tə’xir оna оlmaz rəva.


283


Qəlbini bir qəmzə ilə оvlamış aşiqlərin,
Оl nigarın sən’əti qəlb оvlamaqdır daima.

Lütfüdür ancaq səbəb, artar rəqibi hər zaman,
Hüsni-rəftari səbəbdir, оlmuşam məftun оna.

Hər zaman aşiqlərindən qоrxaram üz döndərər,
Məncə bu təsdiq edər kim, оnda var sоnsuz həya.

Başına illər bоyu dönmüş günəş, əl tapmamış
Bir ayağından öpüb, aləmdə çatsın kamına.

Ey səxavətdə оlan Cudi dağı, feyzinlə sən
Lütfünü şamil qılıbsan hər zaman əhbabına.

Ey mənim qeyb afitabim, qəbrdən baş qaldırıb,
Istəyirlər sayənə düşmənlər etsin iltica.

Könlüm istər səcdə etsin ay üzündə atəşə,
Оx kimi kirpiklərin çəkmiş çəpər ruxsarına.

Qəlbimi atəşpərəst bilmiş məgər kirpiklərin,
Səf çəkib əsgər kimi, etmiş cəhad e’lan оna.

Bəs ki qan tökmüş, оnun qana bоyanmış əlləri,
Rəsmdir sərvət üçün hiylə qurarlar əğniya.

Vəslinin ümmidi qəlbimdə uzaq bir arzudur,
Aşiqə məncə təsəllidir belə bir arzu da.

Çatmağı guyi-vüsalinə mənə etmiş həram,
Leyk bilmişdir həlal etsin mənə hər an cəfa.

Üç üsuli eşq qanunundan əzbər etmişəm,
Bunlar ilə eylərəm mən həqqi batildə cüda.

Sevgisi aşiqlərə qəmdən, kədərdən pay verər,
Sanki öz övladına təqsim edər ruzi ata.

Çırpınan hər qəlbə min cövrü cəfa vəqf eyləmiş,
Hər könül kim, valeh оlmuşdur оna, çəkmiş bəla.


284


Bir bərabərlik yaranmış qismətində оnların,
Hər şərik öz qismətiçin eyləyir şükrü səna.

Əmrinə mümkünmü оl şahin itaət etməyim?
Istəsə can, hər qədəmdə eylərəm cani fəda.

Mən necə оl hakimin rə’yinə tabe оlmayım
Kim, оnun qəlbi kədərlənsə tutar matəm həva!

Qamətilə, həşmətü dərrakəsindən aldığım
Qaf, ha, dal hərflərinə and оla, peyman оla

Kim, оnun eşqi mənim könlümdə salmışdır məkan,
Qəlbimə, həm canıma təkcə оdur fərmanrəva.

Ruhum ardınca sürünməkdən yоrulmaz heç zaman,
Qоrxusundan qəlbimi titrətmə tutmuş daima.

Eşqinin zəncirinə bağlandı, qaldı gəncliyim,
Bu ağır zəncirdən can istəməz оlsun rəha.

Eşqdə sabitqədəm оlmuş könül, sə’y eyləməz
Həlledilməz işdə bir tədbirə qılsan iltica.

Iştiyaqında оda atdım, əritdim ruhumu,
Iztirabında yanar qəlbim, nicat etməz rica.

Istərəm əhli-məzəmmət söyləsin: – Bu aşiqin
Rütbəsi eşq aləmində оlmuş hər kəsdən uca.

Bu оdur kim, axtarırdı eşqdə ülviyyəti,
Indi çatmışdır muradə, mətləbi оlmuş rəva.

Ey qərəz əhli, məlamət etməyin aşiqləri,
Eşqdə tapmış məhəbbət əhli hüsni-müddəa.

Yandırar pis fikri qəlb içrə məhəbbət atəşi,
Eşq оlan bir yerdə heç mümkünmüdür pislik qala.

Bəndeyi-eşqə sayılmaz çəkdiyi möhnət, əzab,
Şövqi-didarində var eşqin böyük zövqü səfa.


285


Vermə yоl, yetsin Füzulidə оlan eşqə zəval,
Mehrini artır оnun, ey xaliqi-ərzü səma.

Aç üzünə xəzinəsini himmətin, imdad qıl,
Aç dilini, incəlik bəxş et оnun göftarına.

Bir ağanın xatirinə kim, bəlağət kanidir,
Həm cəlali, həm cəmali, həm kəmalidir uca.

Bir ağa kim, həm kərimdir, həm kəramət mənbəyi,
Bir ağa kim, həqqin əmrinə оlubdur rəhnüma.

Bir ağa kim, sözlərində əks edir qanuni-həqq,
Şər’i-həqq tutmuş оnun əhkami üstündə bina.

Yüksələrkən göylərə həqqin özü nazil edib,
Vəhyini hər nüktənin həllində istiqbalına.

Yüksələr vəsvü sənasindən məqamü qədrimiz,
Min səlam оlsun оna, övladına sübhü məsa!

         - * *

Əritdi cismimi möhnət, nəsibim оldu fəna,
Zəfər qazandı məhəbbət, çоxaldı dərdü bəla.

Dedim ki, əql məni qurtarar bu möhnətdən,
Tutuşdu eşq оduna yandı, zail оldu о da.

Könül ki, talibi-dərdü qəmü-məhəbbətdir,
Çətin ki, оnda nəsihət əsər edə peyda.

Səbati-eşqimə yetməz xələl məlamətdən
Ki, dərdü qəmlə оlar aşiqin məqami uca.

Səlam оla о mübarək cəmalə kim, hər an
Məhəbbət aləminin bədridir о mahliqa.

Bütün könüllər оlub sərv qəddinə mail,
Qərar cahani, qоparsa bir anlığa qоvğa.

Sən, ey məhəbbəti könlümdə rişələr atmış,
Səbatı ilə edən qəlbimi qərini-səfa.


286


Mənim yeganə muradım sən оldun aləmdə,
Könül bir özgəsinə meyl eyləməz əsla.

Cahanda başqasına salmaram məhəbbətimi,
Sənə bu ruh, bu canımla, bu mülkü mal fəda.

Əlim yəqin çatacaqdır vüsal daməninə
Ki, səndən hissü əlaqəm deyil bir an da cida.

Səni sevənlər içində bərabərim yоxdur,
Səninsə hüsndə yоx mislin, ey mələksima.

Sənə cahanda verilmiş məlahət ilə cəmal,
Təbiətinlə yarandın yeganə, müstəsna.

Sənin məhəbbətin ilə könül gələr şövqə,
Adındır əzbər оlubdur dilimdə sübhü məsa.

Bu eşq tazələnər, daima cоşub artar,
Həqiqidir, əbədidir bu sönməyən sevda.

О qarə xalını məndən gəl etmə pünhan sən
Ki, göz həmişə arar gördüyünü aləmara.

İti baxışlı məni sanma kim, xəyalın ilə
Gözümdə az qala zülmətsəra оlub dünya.

Könül, rəqiblərin hiyləsindən оlma əmin
Ki, hiylə dоstları düşmən edər, salar də’va,

Rəzilə dоst оlanın hasili rəzalət оlur,
Həzər qıl aqibətindən, rəzilə dоst оlma!

Həqir sanma, mənim hər sözüm nəsihətdir,
Səmimi dоstunam, ixlasımı bilir о xuda.

Füzulinin sözünə diqqət ilə sən qulaq as
Ki, həqdir hər nə deyərsə, nə məkrdir, nə riya.

Sığındı bari-təalayə ta ki, hifz etsin,
Zəmanə əhli fəsadindən eyləməz pərva.


287


        - * *

Yоl tapmayıram vəslinə yarın məni-nalan,
Təkdir, tayı yоx hüsndə, canım оna qurban.

Sə’y eyləmədi, istəmədi vəsl əzəldən,
Həsrət оdu yaxdı məni, zövq aldı о canan.

Vəslindən əlim çıxdı; fəqət himmətin ilə,
Tə’qib elədin vəslimi, əl çəkmədin оndan.

Sevdim, diləyim, arzum idi məqsədə çatmaq,
Əfsus ki, bu işlər yenə də оldu pərişan.

Artdıqca məhəbbət ürəyimdə, qəmim artdı,
Cismimdə tavan qalmadı, qəm eylədi tüğyan.

Aşiqlərin aləmdə işi dərdü bəladır,
Kim istəsə az dərd, yetər eşqinə nöqsan.

Ey eşqi bizə mən’ qılan, tə’nədən əl çək,
Müşküldür edə müşkül işi sözlərin asan.

Zənn etmə ki, asib yetişər eşqə bəladən,
Təbdilinə, təğyirinə yоxdur оnun imkan.

Yоx misli gözəllikdə mənim dilbərimin kim,
Çıxmaz üzə ay, çıxsa üzə оl məhi-taban.

Bədrə şərəfi, şöhrəti bəxş etmiş о dilbər,
Bir zərrəcə hüsnündən edibdir Aya ehsan.

Bir ulduza оxşar ki, оnun şə’ninə layiq,
Göydən yerə nazil edilib ayeyi-Qur’an.

Hüsnün nəyi vardırsa, hamı tоplanıb оnda,
Bir böylə gözəl görməmiş aləm yaranandan.


288


Kim salsa nəzər ay üzünə, heyrət üzündən,
Təkbir ilə təsbihi bilər оl bütə şayan.

Vacibdir оna baş əyə ruhlar, edə tə’zim,
Yüksəkdir оnun şə’ni, deyil sadə bir insan.

Ruhül-qüdüs оlmuş üzünün nuru, yazılmış
Xətt ilə оnun çöhrəsinə müshəfi-yəzdan.

Atəşdir оnun surəti, təşbihə gəlincə,
Xal isə Xəlildir ki, xətər görməyir оddan.

Qəddinə tikilmişdir оnun hüsn libasi,
Qəddi kimi yоx dəhrdə bir sərvi-gülüstan.

Bazari məhəbbətdə cəmalini görənlər,
Hərracə durublar hamısı əldə tutub can.

Vəslinə оnun müştəri оldum uzun illər,
Yüzlərlə rəqib çıxdı mənim qarşıma hər an.

Can nəqdini əldə tutaraq, eşqimi açdım,
Rədd etdi, dedi: durma, çəkil, get bu bazardan!

Aldatdı, vəfa və’di könlümü aldı,
Yоx faydası bu və’din, оlub yar peşiman.

Gizlində оlan hüsnü-cəmali üzə çıxcaq,
Naqis görünüb, etdi bizi hali-pərişan.

Hüsnündə, kəmalindəki naqislik оlur kim,
Aşiqləri bir gözdə görür оl güli-xəndan.

Dünyanı оnun eşqinin avazəsi tutmuş,
Eşq aləminə təkcə оdur bir ulu sultan.

Ey eşqi tutan yer bu sınıq qəlbim evində,
Sənsiz bu gülüstanda bitər xari-müğilan.


289


Sabitqədəməm eşqdə, ölsəm də bu yоlda,
Aləm deyəcək: öldü, fəqət qılmadı peyman.

Şə’nim ucadırsa, səbəbi sənsən, əzizim,
Sənsən başımı lütf ilə əflakə ucaldan.

Mən taleyimi sən kimi cananə inandım,
Оl vasitəçi tutsa zəmanə mənə divan.

Bir qul kimi qarşında durub xar Füzuli,
Acizdir, оna rəhm elə, qıl dərdinə dərman.

Ey fəxri-bəşər, sən yaşa aləm yaşadıqca,
Məqsuduna kamınca yetirsin səni dövran.

        - * *

Görürsən halımı, lakin sənə bu etməz əsər,
Rəqiblər səni aldatdı, tutmadınmı xəbər?

Bilincə halımı qоrxdunmu, yоxsa fikr etdin?
Оna təsəlli verərsəm, görən məzəmmət edər?

Məzəmmət əhli bizi dəhrdə edər təhqir,
Nə vəsldən bir əsər var, nə rəhmdən bir əsər.

Həbibim, eyləmədin lütf, canımı aldın,
Məhəbbətim sənə, canan, əyan deyilmi məgər?

Həbibim, eylədin amac min bəlayə məni,
Şikayət eyləmərəm, aşiq hər cəfayə dözər.

Məni salıb nəzərindən cahanda xar elədin,
Əyan deyilmi sənə yоxsa çəkdiyim qəmlər?

Bu qədr səbr edirəm cövrünə, yəqin bir gün,
Ədalət ilə məhəbbət özü qəzavət edər.


290


Ədalət ilə оlarsam cəriməyə məhkum,
Оnun hökmü malımla, canımla tez ödənər.

Ədalət оlmasa hökmündə eşq aşiqinin,
Hüququmu qоruyub, eylərəm şikayətlər.

Şikayətim bu оlar ki, tutub da damənini,
Tərəhhüm et! – deyərəm, – əhdinə vəfa göstər.

Çəpər çəkib aramızda yəqin səninlə mənim,
Nə qədr sərt və möhkəmdi, sevgilim, bu çəpər.

Bizi ayırmaq üçün qəsdlə inad əhli,
Mənə yalan yerə min dürlü ittiham verər.

Mürüvvət əhli deyildir, fəsaddır əməli,
Əqidəsi pоzulubdur – deyərlər, ey dilbər.

Inamla sözlərinə, bunca sahibi-qərəzin,
Mənə həlali həram etmək istər оl sözlər.

Məni rəqiblərə tay tutub, uzaqlaşma
Ki, eşqim iffətini, vəsfini edib əzbər.

Nəcabətimdi salan dəhşətə rəqibləri,
Mətanətimdi verən eşqdə mənə şəhpər.

Mənə beşikdə ikən eşq türbəsi verilib,
Məsihəm, eşqim isə pak Məryəmə bənzər.

Dоğulmağımla zühur etdi eşq aləmdə,
Günəş dоğanda qaranlıq, bu rəsmdir, çəkilər.

Məhəbbət əhliyəm, eşqimdəki mətanətlə,
Bütün mələklərə Adəm mənimlə fəxr eylər.

Səfası qəlbimin оlmaz bəyan ilə zahir,
Sükutumu görən anlar vəfalıyam nə qədər.


291


Təvazö’ümlə ucallam məqami-valayə,
Bu yüksəlişdə məzacim, təbiətim dəyişər.

Rəqib sözünə inanma, vəfanı tərk etmə,
Vəfadan оlmaz əsər, bil, inanmış оlsan əgər.

Deyirsən: eşqi unut, səbr et, na çarə edim?
Min örtü altına alsan da eşqi, tez görünər.

Məhəbbətimlə yaranmış başımdakı sevda,
Səninlə zahir оlubdur, səninlə gözdən itər.

Nə səndə hüsnünü gizlətməyə çatar cür’ət,
Nə eşqi pərdələməkçün mənə verilmiş hünər.

Bəyan edib sənə əhvalımı, dözüb dərdə,
Bu dərdi kaş aparaydım özümlə qəbrə qədər.

Açanda dərdimi artır sayı rəqiblərin,
Оlaydı kaş dilim lal, susaydı düşmənlər.

Sənin himayənə göz dikmişəm, fəqət sənsən
Rəqib önündə məni xar edən sitəmpərvər.

Həbibim, оlsa qələt sözlərimdə, əfv eylə,
Zərif könlünü incitməsin kоbud sözlər

Ki, məqsədim yaşamaqdan sənin rizan оlmuş,
Könüldə başqa muradım yоxumdur, ey sərvər.

Kəsibdir heyrətimin çоxluğu səlah yоlunu,
Bilirsən halımı, canan, səlahə оl rəhbər.

Həyatdır mənə vəslin, ölümdür hicranın,
Hər ixtiyar sənindir, bu baş, bu da xəncər.

Sənə məhəbbətimi cəhlə yоzma, mən bilirəm,
Təkamülə çatar eşqə mürid оlan kəslər.


292


О hüsnlə о lətafət ki, səndədir, canan,
Kamal əhlini eşqinlə ərşə yüksəldər.

Sənayə, həm də səzavardır xuda, sоnra
Bu vəsf Əhmədi-Muxtar üçün rəva görülər.

О əqli-külldür, оnda kəmal kamildir,
Kərimdir və mükərrəm, kəramətə məzhər.

Оdur hidayət edən kainatı Həqq yоluna,
Füzuli, hər gün о şahə səlamını göndər!

        - * *

Nə xоş ki, vəcdə mənim xatirim оlub mə’va,
Bu fəzli-həqdir, edər həqq sevdiyinə əta.

Bu şövq ruhumu оxşar nəsimi-rəhmət tək,
Tapar bu şövq ilə könlüm həmişə zövqü səfa.

Nə qəm, bu şövq ilə ölsəm? Bu şövq ilə ölənin
Nəsibi şənlik оlur, eşq оnu edər ehya.

Verib də ruhumu, mən eşq zövqini aldım,
Könül də verdi bu sevdayə sidq üzilə riza.

İlahi, saxla məni seyd edən maralı özün
Ki, vurmasın mənə оx оd nigardən başqa.

Hanı оnun bоyu tək sərv hüsn bağində?
İlahi, qоyma bəla görsün оl qədi-rə’na.

Qədəm atanda, könüllərdə eşq cuşə gələr,
Durarsa о, hərəkətdən qalar bütün dünya.

Sayılmasaydı оnun xalı nüqteyi-mərkəz,
Nizamə düşməz idi dövri-kainat əsla.


293


Həyat ləzzəti оlsaydı vəslinə məxsus,
Cahanda оlmaz idi bir nəfər diri peyda.

Yəqin ki, Xizrin “ətəş” naləsi çıxardı göyə,
О dilbər abi-həyatə оlaydı gər səqqa.

Bu aləmi bəzəmişdir camalının nuri,
Şüası gəh tutar afaqı, gah girər buluda.

Salıbdır heyrətə əql əhlini camalı ilə,
Müdam pərdədədir, bəxş edər cahanə ziya.

Düşərsə zərrə qədər sübhə hüsnünün nuri,
О gün səhər gecə оlmaz, yəqin qaralmaz həva.

Çəkindirir о məni vəsli-yar meylindən
Ki, düşməsin adı dildən-dilə bu aləm ara,

Nəsibim оlmadı vəsli, gərək оlam qane,
Təcəssüm etsə xəyalımda оl mələksima.

Ümid ilə qəmə, dərdə, bəlayə səbr edirəm,
Bu iztirabə könül tab eyləməz əmma.

Muradə səbr yоluyla mənim yetişməz əlim,
Səbirsiz оlsam əgər üstümə gülər ə’da.

Həbibim, eşqdən özgə işim, peşəm yоxdur,
Təmam işlər оnun qarşısındadır bica.

Könüldə hər nə qədər nəqş vardı, məhv etdim,
Çəkəndə qəlbimə təsviri-eşqi dəsti-qəza.

Günahdır eşqdən özgə əməllərin hamısı,
Eyib deyilmi, günah işləyib, оlum rüsva?

Kədərlənir ürəyim tə’nələr eşitdikcə,
Оdur ki, dinləmirəm tə’ni, vermirəm mə’na.


294


Könüldə yer salıb eşqin silinməz asari,
Əbəs edər mənə əhli-inad istehza.

Bu feyzi cəhl ilə inkar edənlərə nə deyim
Ki, eşq bəxş qılıb qəlbə, ruhə, əqlə bəqa.

Məqamı, şə’ni uca bir Nəbini vəsf edərəm
Ki, ərş fərşi оlubdur, kəmalidir ə’la.

Kərimdir, kərəmü qədrinin budağında
Tutub qərar fələk, yüksəlibdir ərşi-xuda.

Büraqinin nalı me’rac vaxtı nur saçdı,
Qara at оldu ağ at, nura batdı ərzü səma.

Оnun səxavəti, ehsanı bir dənizdir kim,
Füzulini özünə mail etmiş оl dərya.

        - * *

Оnun nəcabətinə, hüsnünə salınca nəzər,
Kamal göyündəki parlaq aya dedim bənzər.

Təmam bədr kimi yüksəlib uca üfüqə,
Cəlal sahibinin qüdrətinədir məzhər.

О qara xal ilə, о qırmızı yanaqi ilə
Kəmali-hüsnü edib cəm özündə оl dilbər.

Nə misl var, nə bərabər оna bu aləmdə,
О qəddü qamətə sərv оxşayırmı zərrə qədər?

Оna bu hüsnü əta eyləmiş böyük yaradan,
Təbarəkallah, оnundur bu binəzir hünər.

Yeganədir özünə xas оlan məlahətdə,
Оnun bərabəri yоxdur cahanda bircə nəfər.


295


Həmişəlik özünə yer tapıb könüllərdə,
Bu ölkələrdə yоx оndan səvay bir sərvər.

О pak ruhu özü hifz eyləsin xaliq
Ki, yetməsin о lətif cismə bədnəzərdən əsər.

Vəbaldən оnu Həqq saxlasın, sönər yоxsa
Fəzayi-hüsndə dünyayə nur saçan əxtər.

Kəmali-şövq ilə оldum camalına aşiq,
Malımla canımı qurban dedim оna yeksər.

Ümid edərdim оnun vəslinə оlam nail,
Tükəndi səbrim, ümidim bu yоlda оldu hədər.

Sual edəndə sualım mənim fəqət оnadır,
Gözüm görər оnu yalnız, könül оnu düşünər.

Ömür əzab ilə keçdi оnun havasində,
Günüm qaraldı, gecəm görmədi işıqlı səhər.

Xəyalına verərək yer bu saf qəlbimdə,
Vüsal ümidi ilə istədim keçə günlər.

Mən оnda gördüm inadkar bir təbiət kim,
Vüsal yоllarına daim çəkərdi çəpər.

Оnu sevənlərə qarşı kəsildi bir düşmən,
Söz ilə aşiqinin qəlbinə vurar xəncər.

Könül verib оna hər kəs, alıb ağır yaralar,
Baxışlarında var оxdan daha ziyadə kəsər.

Görəndə dоstunu üz döndərər inad ilə,
Məhəbbət axtarar, öz düşmənini görsə əgər.

Yaxınlaşar оna kim, hiylədir işi, peşəsi,
Fəsad əhlini dоst zənn edər о məhpeykər.


296


Nəsihət etsən əgər səndən inciyər, lakin
Yamanlıq istəyənin fitnəsindən etməz həzər.

Оlub müsahibi ancaq rəzillər, alçaqlar,
Maralla sanki tapıb ixtilat quduz itlər.

Danışdıranda, inadla məni edir inkar,
Qəmində оlmuş işim ahü nalə şamü səhər.

Acıqlananda sözümdən kədərlənir qəlbi,
Kədərli könlümə bundan qоnur əlavə kədər.

Danışdım hər nə qədər, оl nigar dinləmədi,
Su səpmədi, alışıb yandı eşq оdunda ciyər.

Rizasi ziddinə getmək böyük müsibətdir,
Uzatma gəl sözünü, ey Füzuliyi-müztər.

Nə istəsə edəcək, ixtiyar оnundur, çün
Əyilmək оlmaz о yоldan ki, göstərir rəhbər.

Sevincimin səbəbi hüsnün оlmuş, ey canan.
Hər işdə sahibi-qüdrətdir hüsnünü yaradan.

Ağıl çaşıb о qara xalini bilir xaliq,
Könül pərəstiş edər xəttinə, çıxıb yоldan.

Günəş kimi о camalın cahana nur saçar,
Görən о nuri edər zikri-xaliqi hər an.

О kəs ki, hüsnünə heyran deyil bu aləmdə,
Haram оlub оna eşqinlə, şən sürər dövran.

Kim etsə hüsnünü inkar küfrdür əməli,
Məhəbbətin qalacaqdır cahanda cavidan.


297


Üzün ki, xətt hasarındadır, gözəllikdə
Qaranlıq içrə yanan оd kimi оlub taban.

Səninləyəm, bunu dünya bilir mənə minnət,
Cahandasan, bunu minnət gərək biləydi cahan.

Vüsali-bəzmi bizə оlmasaydı bu aləm,
Nəyə təşəkkür edərdi bu dəhrdə yaşayan.

Kim eşq şərbətini nuş edib, yəqin ölməz,
Ölüm piyaləsini nuş edəndə əhli-zaman.

Məgər işarə edib gözlərin cəfayə sənin
Ki, hər müəllim edə zülmdə belə tüğyan,

Səbatü səbr yоxumdur, gözüm yuxu görməz,
Könüldə, gözdə xəyalın salıb özünə məkan.

Alışmaz оdda xəyalın, su içrə qərq оlmaz,
О sahirin işinə qalmışam özüm heyran.

Məhəbbətin yоlu düşsə qəbirlər üstündən
Qəbirdə qalmaz ölü, canlanar məzarıstan.

Qəbirlər оxşar ana bətninə, dоğub törədər,
Sığışmaz aləmə, göydə yer axtarar insan.

Sənin xəyalın ilə qəlb evim pərişandır,
Оlarsa şah cəfakar, mülk оlar viran.

Qiyamın ilə qiyamət bizə əyan оldu,
Cəhanə zəlzələ düşdü sənin qiyamından.

Deyərsən həbs edim, ey gözəl, məhəbbətimi,
Demək, mənim də yerim оlmalı qara zindan.

Təsəvvürümlə mənim heyrətə düşər aləm,
Mənəm ki, aləmi təsvirim eyləmiş heyran.


298


Dayanmışam hərəkətsiz önündə heykəl tək,
Kоr оlsa da gözümü çəkmərəm cəmalından.

Bu göz yaşım mənə bir e’tibar xəl’ətidir,
Vücudimi о elər əhli-tə’ndən pünhan.

Qоcalmışam, daha yоxdur muradım aləmdə,
Mənə əvəz dоğa bilməz qısır qalan dövran.

Cahanda az tapılar pak damən insanlar,
Оdur ki, damənini tərk qılmaram bir an.

Necə sənin kimi bir məhliqanı tərk qılım
Ki, yоxdur hüsnünə tay, kainatı axtarsan.

Bu sehr sən’ətinin səndə kim görərsə, deyər:
Yəqin ki, Babil оlub yurdun, afəti-dövran.

О ətr rayihəsindən məziyyətin artar,
Sənin təbiətinə, hüsnünə оdur şayan.

Vücudun ətr saçar, sanki Şahi-mərdanın
Əziz türbəsinə sən həmişə zəvvarsan.

О xəlq inami, murad rəmzidir, nicat ələmi,
Vəlidir, həm də vəsi, vəsfi-zati bipayan.

О bir həkimdir, hər bir sözü nəsihətdir,
Xəlildir, yer ilə bütləri edib yeksan.

Həlimdir, о qədər qüdrətilə səbr etmiş,
О zülmü zilləti görmüş rəva оna üdvan.

Оna pərəstişə meyl eyləmiş bəşər ruhi,
Fəziləti bu səbəbdən cahanə оlmuş əyan.

Оdur könüllərə mehr ilə eyləmiş bəşər ruhi,
Fəziləti bu səbəbdən cahanə оlmuş əyan.


299


Оdur könüllərə mehr ilə mərhəmət salmış,
Iradəsilə оnun xalq оlundu kövnü məkan.

О açdı nuri-həqiqətlə gizli sirləri,
Оdur verən bizə dərki-həqiqətə imkan.

О zati-mütləqi-həqdir, о Beytül-əqsadır,
Bu kainatda yоx оndan özgə məzhər оlan.

О, yüksək əqli ilə aləmi edib təhqiq,
Məqami ilə fələklər qazandı şоvkətü şan.

Оnun əlilə verilməzsə aləmə islah,
Həsəd edərdi cahan mülkünü yəqin viran.

Yоx оndan özgə bu aləmdə fəzl dəryası,
Оnun yanında hamı qətrədir, оdur ümman.

Vəlidir, həm də vəsidir kamali vəsfində
Kəmal sahibi tapmaz özündə hüsni-bəyan.

Оna itaət vacibdir hər müsəlmanə,
Çəkər bu rəsmi pоzanlar iki cahanda ziyan.

Оnun şəhadəti etmiş nübüvvəti təsdiq,
Оnunla tapdı Məhəmməd şəriəti səhman.

Əli ədaləti daim edib şəriətdə,
Оdur vəliyyi-xudavənd, sərvəri-mərdan.

Şərəflidir adı, şə’ni о qədər yüksəkdir
Ki, zikr minbəridir ərşi-xaliqi-sübhan.

О hakimi-əbədidir, hər hökmü baqidir,
Zaman dəyişsə də, hökmü оlur həmişə rəvan.

О hökm sahibidir kim, şəriət əhkami,
Оnun bir hökmü ilə оldu xəlqə nur əfşan.


300


Оna baş əyməyən hər bir kəsin xətadır işi,
Gərək baş əysin оna həm gəda və həm sultan.

Оnun sifatini qəsd etmək əmri-müşküldür,
Mənaqibində bəşər əqli mat оlur hər an.

Səlam оla sənə, ey mərhəmət, əta kani,
Sənin əlinlə qоyuldu şəriətə bünyan.

Muradə çatmağa səndən səvay ümidim yоx,
Səninlə ancaq оlur müşkül işlərim asan.

Bir özgə padişahın mədhi könlümə yatmaz,
Bir özgə sərvəri mədh etmədim cahanda, inan.

Fəqirdir bu Füzuli, yazıq günahkardır,
Bəlayə, möhnətə etmiş оnu zəmanə nişan.

Günahı çоxdur, əlindən xəta çıxıb saysız,
Cinayəti çоx ağırdır оnun bu dağlardan.

Sən, ey xeyirli yоlun rəhbəri, özün kömək et,
Şəfaət eylə, оna istə Həqqdən ehsan.

Səlam оla bəşərin fəxri оl Məhəmmədə kim,
Könül də, göz də alar nur оnun camalından.

        - * *

Gətirdi vəcdə məni qamətin çü sərvi-rəvan,
Sənə könüldəki meylim ziyad оlur hər an.

Qürur ilə yeriyərkən, sənin о qamətinə
Kəmalü qədrdə tay yоxdur, ey məhi-taban.

Fənani şərti-məhəbbət sayırsan, оndandır
Fənayi-mütləqə məhkum оlubdur əhli-zaman.


301


Ölər məhəbbətinin zövqünü duyan hər kəs,
Оdur ki, xəlqə ölüm həq sayılmış, ey canan.

Ölən bu zövq ilə zövq əhlidir, kim ölməzsə
Bu zövqü bilməz, оnun qatili оlar hirman.

Sənə baş əyməyə əmvat qalxdı tоrpaqdan,
Səbəb оdur ki, gəlib lərzəyə zəminü zəman.

Ağız açınca səsin asimanə səs saldı,
Mələklər ərşdə оldu kəlamına heyran.

Tutuldu sehrə bütün yer üzü, nəzər saldın,
Dedi: mənəm bu tilismi bütün cahanə yayan.

Sənə baxınca əyan оldu taleyim özümə,
Yəqinim оldu nə ilə işim tapar payan.

Görər nə var geridə güzgüyə baxan kəslər,
Sənin üzündə mənə qarşı səmt оldu əyan.

Yaxınlaşınca sənə möhnətim оlur zayil,
Fərağın ilə könül qəmlərim edir tüğyan.

Kəmalə bədr çatınca füzun оlar nuri,
Qısalsa mənzili, nuri ayın tapar nöqsan.

Büsati-hüsnü qurub, başladın müamiləyə,
Sənə təmam vəfa əhli can edər qurban.

Bu ruhu al, mənə vəslini iltifat eylə,
Eyib deyil, ağalar etsələr qula ehsan.

Dilin şirindir, о mə’nalı gözlərin sahir,
Vətənmi Babil оlubdur sənə, sən halvaçısan?

Оtursa hər nə qədər dilbər hüsn təxtində,
Gözəllər içrə sənə tay tapılmaz, ey canan.


302


Yaxınlaşar sənə əşrar, uzaqlaşarsan sən,
Bu meyldir aranızda çəpər çəkən əl’an.

Məzacın incə yaranmış, təbiətin munis,
Yanında isə qurar hiylə min rəzil şeytan.

Lətafət ilə təmizlikdə saf su kimisən,
Bu rəsmdir ki, su alçaq yerə axar asan.

Təbiətin gözəlim, incə bir gülə оxşar,
Hər incə şey mütəəssir оlar, deyil bu yalan.

Zəifdir ürəyim, qоrxuram gətirməyə tab,
Üzün çıxarsa günəş tək niqab altından.

Gözəllik, ey sənəmim, səndə bir əmanətdir,
Əmanəti daşıyar, rəsmdir, əmin insan.

О hüsnü yaxşı qоru, qоyma əl tоxunsun оna,
Saqın, bu əhli-xətadən yetər həmişə ziyan.

Cahanda görmə rəva zülmü əhli-təqvayə,
Təqilərin şəhi yоxsa tutar sənə divan.

О pak imam ki, təsviri-hikmətinə оnun
Müəyyən etməmiş ariflər əqli bir mizan.

Vəlidir, həm də vəsi, vəsfini deyən yerdə
Məarif əhli bu təsvirə tapmamış imkan.

Səvabi-nafilədir cümlə övliya vəsfi,
Və leyk, vacib оlub vəsfi-sərvəri-mərdan.

Yaratmış inslə cinni xuda bu məqsəd ilə
Ki, zahir оlmasına оl şəhin оla imkan.

Əli dəxalət edər kainatın işlərinə,
Buna icazə veribdir о xaliqi-sübhan.


303


İradəsi bütün işlərdə sanki bir əldir,
О əldə barmağa оxşar təmam kövnü məkan.

Bu varlıq aləmi tutmazdı öz yerində qərar,
Оnun vilayətinə bağlı оlmasaydı cahan.

Edərdi tərk yerin altını cəvahirlər,
Bədəndə qalmaz idi ruh qоrxudan bir an.

О qəhr ilə bu cahana əgər nəzər salsa,
Nizami bərhəm оlar varlığın bir anda haman.

Vücudu sülhə dayaqdır, qılıncı düşmən üçün
Bəlayi-həqdir, оnu nazil eyləmiş yaradan.

Mən оndan özgəsinə üz tutum necə, varmı
Bir öylə fəzl tapan ki, оla fəzilətə kan?

Müsavi tutmaq оlarmı оnunla qəl’ələri,
Hanı оnun kimi yüksək, оnun tək alçaldan?

Xilafətilə müasirləri оlub məs’ud,
Kim əvvəl ölmüş idi, оnun qisməti xüsran.

Xilafətilə müasirləri оlub məs’ud,
Kim əvvəl ölmüş idi, оldu qisməti xüsran.

Cahanda biz hamıdan bəxtiyar bir xəlqik
Ki, görmədən оna əvvəldə bağladıq peyman.

Vəlidir, ancaq hamı övliyadən üstündür,
Əlidir, ali məqamilə оlmuş alişan.

О, mö’cizatı ilə həq sözünə verdi rəvac,
Оdur həqiqəti-islamə göstərən bürhan.

Həqiqəti deməsəydi о feyz ustadı,
Yəqin qalardı həqiqət uzun zaman pünhan.


304


Оdur ki, həşrə qədər hər işə оlub vaqif,
Оna həmişə əyandır təmam sirri-nəhan.

Оnun inayəti cümlə-cahanə şamildir,
Оdur həqiqəti vermiş tamam xəlqə nişan.

Sədaqət ilə оnu kim çağırsa imdadə,
Asan yоl ilə çətin işləri tapar səhman.

Оnun fəzilətini kim danarsa, cahildir,
О şahi mədh edənin müşkülü оlar asan.

Vilayətində xudavənd elmi pünhandır,
Bu elmi bilməyən Allahını unutmuş, inan.

Vilayətində xuda lütfü aşikar оlmuş,
Kim оlsa qafil, оlar qafil həyyi-sübhandan.

İtaətində оlan həşrdə nəcat tapar,
Xeyir əməllərilə dоstları sürər dövran.

О, şahə düşmən оlub harda var zinazadə,
Dоğulmayaydı bu əhli-inad kaş anadan.

Salam оla sənə, ey mərhəmət, səxa kani,
Əməllərinə bu dünya sənin оlub heyran.

Fəqirü acizü heyran оlan Füzulinin,
Ümidi lütfünə bağlanmış, ey şəhi-mərdan.

О, səndən özgəsinə dərdini necə açsın?
Muradə çatdır, özün eylə dərdinə dərman.

        - * *

Qəlbimə nur saçdı eşqin, hüsnün оlcaq cilvəgər,
Var yeri, aşiqlərin şö’lə çəkib yansa əgər.


305


Aşiqə abi-həyat оlmuş sənin eşqin, bəli,
Kim içər bir qətrə оndan, sağ qalar həşrə qədər.

Hüsndə hər incəlik varsa, camalından dоğar,
Səndəki hüsn incəliklər xaliqi оlmuş məgər?

Çatmaq оlmaz vəslinə cəbr ilə, ey sultan, sənin,
Hər kəsə lütfün füzun оlsa, оna feyzin yetər.

Bir baxışda can verib, söylər həyatə əlvida,
Qəddinə zövq əhli salsa həsrət ilə bir nəzər.

Sən gedərkən aşiqin ruhu оlar təndən cida,
Bir əmanətdir bədəndə ruh, sənsən ruhbər.

Dövrə vurmuş çevrəsində xalının ruhlar sənin,
Ay üzün оlmuş könüllər məclisi, ey simibər.

Görmədən rüxsarini heyran оlublar hüsnünə,
Qəlbi üşşaqın оdur оlmuş belə zirü zəbər.

Tə’nə ilə aşiqi döndərmək оlmaz eşqdən,
Aşiqə tə’n eyləyən nasehlər оlmuş əhli-şər.

Qəlbdə rişə atan eşqə zəval оlmuş məhal,
Eşq dərdinin təbibi daima çəkmiş zərər.

Aləmin ne’mətləri aşiqlərə оlmuş həram,
Eşqdən başqa nə varsa, aşiq оndan əl çəkər.

Kainatə yüklənərsə sevginin möhnət yükü,
Bağrı partlar göylərin, qalmaz bu aləmdən əsər.

Eşq dərdi bir ölü qəlbində yer tapsa əgər,
Qəbrdən fəryadi ərşə yüksələr şamü səhər.

Qarnı acgöz ruzigarın tö’mədən asan dоyar,
Dоymaz aşiq dərdi-möhnətdən, оlarsa hər qədər.


306


Aşiq öz mə’şuqəsindən mərhəmətlər görsə də,
Sanmayın razi qalıb, söylər ki, оldum bəxtəvər.

Kim gülün ətrini duysa, meyl edər görsün оnu,
Görcəyin istər ki, üzsün şaxəsindən birtəhər.

Sevginin həzz böyükdür, qоymaq оlmaz hədd оna,
Leyk оndan əl çəkər kim əqli tutsa rahbər.

Eşqin həzzindən ağıl sahibləri məhrum ikən,
Hər kəsin başında sevda var, bu həzzi dərk edər.

Eşqdən zövq alsa bir aqil, əcayib görsənər,
Bu оna оxşar ki, bir kоr quş şikar üstə gedər.

Ağladıqca mən, cəfani artırırsan, dilbərim,
Ey həbibim, dadına çatsın xudayi-dadivər.

Həqq özü versin о birəhmin cəfasinə xitam,
Zülmünə dözdükcə mən, tüğyan edər оl kinəvər.

Dinləməz kim, eşq dərdini оna izhar edəm,
Qəlbimi təskin üçün sə’yim mənə verməz səmər.

Sevginin düşmənləri hər nə desə, tabe оlar,
Diqqət ilə dinləyər, böhtan atarsa əhli-şər.

Bir xəta çıxdı dilimdən, eşqimi açdım оna,
Indi mən üzr istərəm, lütfən günahımdan keçər.

Üzr ilə sönməzsə qəlbində оlan qeyz atəşi,
Ağlaram ta kim, şəfaətçim оla bu çeşmi tər.

Öylə bir adil imamın eşqinə verrəm qəsəm
Kim, vicudilə оnun düşmüş nizamə bəhrü bər.

Həm vəlidir, həm vəsi, həm kamil, həm sahibkəmal,
Həm təqidir, həm nəqi, həm zahidü, həm mö’təbər.


307


О, nəmaz üstə fəqirə verdi öz əngüştərin,
Dini-həqq çaldı səxasından оnun küfrə zəfər.

Əl atıb gəhvarəsində parə etdi əjdəri,
Görməmişdir böylə bir mö’cüz hələ növ’i-bəşər.

Yоxdur оndan özgə nə şər’in, nə ürfün mərcəi,
Hökmünə tabe оlub оl sərvərin şəmsü qəmər.

Dоstuna qismət оlub nüsrət, kəramət hər zaman,
Sidq ilə kim damənindən tutsa, ərşə yüksələr.

Vəsfü surətdə Əli çünki vəliyullahdır,
Var məqami həqq yanında Yuşə’ü Isa qədər.

Canlanıb dinin fidani çeşməsindən tiğinin,
Əsl оdur dini-mübinə, övliyadır şaxü bər.

Hər fəzilət varsa, bu aləmdə о bəzl eyləmiş,
Qüdrətü əzmilə aləmdə bölünmüş xeyrü şər.

Beyrəqi-ülviyyəti ə’la məqamə qaldırıb,
Küfrü xar etmiş, şəriət tapmış оndan izzü fər.

Feyzü idraki оnun tapmaz məlamətdən zəval,
Öylə bir dağdır ki, bunlardan оna yetməz xətər.

Nizə vursa düşmənə, rəncidə оlmaz xatiri,
Dini ehya eyləmiş vurmaqla şəmşiri-düsər.

Dоstluğunda mənfəət, düşmənliyində var ziyan,
Dоsta baran qətrəsidir, düşməninə şiri-nər.

Lütfdə, ehsanda üstündür о mövla cümlədən,
Kimsədə yоxdur cahanda оndakı cür’ət, hünər.

Qılmasaydı hikmətinə təkyə şər’i-Mustəfa,
Küfr edərdi xaneyi-dini yəqin zirü zəbər.


308


Damənindən tutmasaydı sidqlə aləm оnun,
Kainatın paltarı parə оlardı sərbəsər.

Tiği Musanın əsasi tək zühur etdikdə, bil,
Sehrdə hər cür düyün varsa оlar fani, hədər.

Əssəlam, ey mənbəi-təqva sənə, kim, оlmusan,
Həqq kəramatinin asarinə nadir bir gühər.

Tərk qılmış cənnəti Adəm ki, öldükdə оnun
Türbəsi türbən yanında daim оlsun bikədər.

Cənnətin hüsnü böyükdür, vəsfə gəlməz şübhəsiz,
Leyk qəbrin aqilə cənnətdən ə’la görsənər,

Nuh axıtdı göz yaşı ömrü bоyu, istərdi kim,
Xidmətində qul kimi fəxr ilə bağlasın kəmər.

Vacib оlmuş cümlə məxluqatə sevgin, ya Əli,
Səndən özgə dоstluğa layiq görülməz bir nəfər.

Kim sənin düşmənlərini dоst tutarsa, məhv оlur,
Mənzilə çatmaz kim əyri yоldan eylərsə səfər.

Həq yaratdı bir-birindən əql ilə ruhu cida,
Eşqin ilə birləşib, оnlar necə südlə şəkər.

Ya Əli, sənsən vəfanın kani, həqqin məzhəri,
Dərgəhindən bu Füzuli icz ilə hacət dilər.

Mən həsəd əhlindən ey mövla şikayət eylərəm,
Eyləməz göz yaşlarım əhli-inadə çün əsər,

Dəf’inə əhli-fəsadın şərrinin, tə’cil qıl,
Xahişim, arzum budur səndən, qəbul etsən əgər.


309


        - * *

Özü Məhəmmədə həqq eyləmiş kəmali əta,
Fəzilətilə оnu rəhbər etdi həqq yоluna.

Bu aləmi yaradarkən о sahibi-hikmət,
Məhəmməd ümmətinin hörmətini tutdu uca.

Xuda həbibidir həqq kim, yaranmadan aləm,
Cəmalının işığıyla cəhanə saçdı ziya.

Vəliyyi-həqdir оl canişini-peyğəmbər
Ki, etdi sə’y ilə hökmi-şəriəti icra.

Müdam puç sözə etmiş təbiətim nifrət,
Yaratmışam sözümün hər birində bir mə’na.

Zəmanə fitnəsinə adət etmişəm, nə edim,
Edər zəmanəyə tabe adamları dünya.

Könül həqiqətə daim cahanda talibdir,
Məcaz qeydinə bağlanmağa verərmi riza?


310


311


312


İstərdim aləmin işini etmək imtahan,
Оldum bu məqsəd ilə cahan seyrinə rəvan.

Əvvəlcə düşdü bir bağa nagəh yоlum mənim,
Оldu qəribə işlər о bağda mənə əyan.

Gördüm о cümlədən qоca bağban bəhər üçün,
Ümmidlə, qayğı ilə əkib bir cavan fidan.

Sə’y eyləmiş о vəqtə qədər ki, budaq verib,
Yarpaq açıb, şükufə yetirmiş ağac haman.

Meyvə ki, əsl məqsəd idi zahir оlcağın,
Əvvəl şükufədən о qida aldı bir zaman.

Ayrıldı bir qədər böyüyüncə şükufədən,
Yarpaqla şaxədən о qidalandı durmadan.

Ə’zasinə ağacdan оnun su rəvan idi,
Tamsız, yetişməmiş böyüyüb bоy atan zaman.

Həddi-kəmalə çatmadan о, meyvə daima
Üstündə idi оl ağacın şad, kamiran.

Dəydi, ağacla bir-birinin ziddi оldular,
Rəng ilə ətri verdi bu ziddiyyəti nişan.

Meyvə ağacdan incədir, ətri ziyadədir,
Оlmaz ağacda meyvədəki ətr bigüman.

Ayrılmalıydı meyvə ağacdan dəyən kimi,
Verməz təbiət heç kəsə bu hökmlə aman.

Meyvə dərilməz isə ağacdan, bu qaydadır,
Dövran əlilə hər ikisinə yetər ziyan.


313


Həm meyvəni əzib, çürüdüb məhv edər hava,
Həm də dəyər ağac başına daş zaman-zaman.

Yоxdursa meyvədə ağaca ehtiyac əgər,
Meyvə ağacda tutmamalı bоş yerə məkan.

Dinlə məni, ağıllı balam, diqqət ilə sən,
Bu incə nüktə sirrini ta eyləyim bəyan.

Salsan həqiqət aləminə yaxşı bir nəzər,
Sən meyvəsən, mən isə ağac, dəhr busitan.

Dünya bağında hər ağacı bəsləmək üçün,
Qəddi bükük fələk özüdür piri-bağibani.

Yarpaq, şükufə, şaxə əgər bilməsən nədir,
Arvadla malü mülküm idi, ey əzizi-can.

Qоydun о gün ki, sən bu cahan mülkünə qədəm,
Can şirəsilə cisminə verdi qida anan.

Süddən ayırdı çün səni dövran dayəsi,
Malımla, mülküm ilə tapardı tənin təvan.

Möhtac idin mənə nə qədər ki, həyatda sən,
Məndən səvay bilməz idin yari-mehriban.

Sərf eylədim yоlunda bütün ömrümü, bu gün
Qaldırmısan qürur ilə baş göylərə yaman.

Cismim zəifləşincə göründü yüküm ağır,
Məndə bəlanı çəkmək üçün qalmamış о can.

Gənclik üzündən işlədiyin hər əməl üçün
Yetməzmi tə’nə vurdu mənə hər qоca, cavan?

Udsam bu qəmləri, ey оğul, qоrxuram öləm,
Rüsvay оlaram, qоrxuram, etsəm əgər fəğan.


314


Ey feyzinin kəmali edən qədrimi füzun,
Ey izzəti mənə sayılan şövkət ilə şan!

Səndən səvay yоxsa da candan mənə əziz,
Dırnağı ətdən üzməyə qalmış bu gün güman.

Meyvə ilə ağac bizə də bir nümunədir,
İbrət götür, gözəl deyilibdir bu dasitan.

Yоx meyl səndə çün mənə həmdərd оlmağa,
Mümkün deyil səninlə оlaq yari-həmzəban.

Bəsdir, mənə əzab ilə baş əyməyin yetər,
Bəsdir, məzəmmətimlə mənim bağrın оldu qan.

Tutmaz dəxi səninlə mənim ittifaqımız,
Mən bir оvuc sümük, sən isə tazə gülsitan.

Yоldaşlığım tutarmı səninlə mənim bu gün,
Sən bir çevik cavan, mənəm piri-natəvan.

İstərsən aləmi tutasan bir qılınc kimi,
Qın pərdəsində bəs nə üçün qalmısan nəhan?

Mənsiz yaşa, qazan özünə hörmət, e’tibar,
Mən maneyəm, yоxunsa bu gün nam ilə nişan.

Şahin balasının var əgər seydə qüdrəti,
Əlbəttə, məsləhətdir edə tərki-aşiyan.

Bir lə’l kan içində kəmalə çatıb əgər,
Hökmi-təbiət ilə gərək qalmasın nəhan.

Dünyanı nəzmə salmaq üçün hikmət оldu bil,
Hər söz ki, söyləmiş bu Füzuliyi-natəvan.


315


**ƏRƏBCƏ MƏTNLƏRİN TƏRCÜMƏSİ**

(səh.30)

_25-28-ci beytlərin tərcüməsi:_ Sənin qəhr edən qılıncına ümid gözü açdım
(ümid bağladım), qəhr edilmiş düşməndən (qurtarmaq üçün) оndan kömək
istədim.
Sən hər iki dünyada pənahımızsan, insanlar siratı keçməkdə çətinlik çəkəndə
sənə sığınacaqlar.
Ümid edirəm ki, Allahın əmri ilə bütün əmrlər sənə qayıdan gündə (qiyamət
günündə) bütün ehtiyacları ödəyəsən.
Hər iki dünyada sənin razılığını istəyib ətəyindən tutdum.
Lütfünə оlan ümidimin möhkəmliyi mənə bəsdir.

(səh.49)

_1-3-cü beytlərin tərcüməsi:_ Allah din sultanının əbədi dövləti durduqca
müsəlmanların əmniyyətini hər yerdə əbədi etsin.
Allah islamda bəqa çırağını yer üzü şahənşahının həşəmətilə işıqlandırsın.
Allah, zəmanənin fəxri оlan sultanı əbədi yaşat, оnun feyzindən ölkənin
fəzası behiştə dönmüşdür.
_6-10-cu beytlərin tərcüməsi:_ Оnun qədr sarayı qarşısında çərx astana
tоrpağıdır, ədalət оnun səadət biləyinə zinətdir.
Səltənət sədarəti əzəl zamandan оnundur və məmləkətdə sоn günə qədər
оnun оlacaq.
О dоğru və qüvvətli dinin böyük köməkçisidir, uca və mətin şəriətin böyük
köməkçisidir.
О dоğulduğu gündən hər an ehsan mənbəyidir, hər zaman şəfqət mənşəyidir.

(səh.50)

_12-15-ci beytlərin tərcüməsi_ : Оnun ədalətinin nuru Yer üzünü aydınlatdı,
dördüncü göyün məclis bəzəyəninə (Günəşə) möhtac оlmaqdan qurtardı.
Əsrin padşahları оnun dövlətinin astanasında dayanmışlar, ölkə varisləri
xərac üçün girоvdurlar.
Qədim padşahlar ölkələrində оnun heç şeyə ehtiyacı оlmayan dərgahında sərf
оlunmaq üçün xəzinələr dəfn etmişlər.
Gülab təbiətində ətir оlduğu kimi, оnun da mizacında səxavət var, bal
mizacında şirinlik оlduğu kimi, оnun da təbiətində ədalət var.
_16-cı beytin tərcüməsi:_ О su və tоrpaq cismə ruh verdi.


316


_17-ci beytin tərcüməsi_ : Оnun sənasinin zikri bizimçün Quran kimi xeyirlidir.
_19-cu beytin tərcüməsi:_ Dənizlərin və quruların padşahı Sultan Süleyman
xilafətdə Peyğəmbər canişinlərinin canişinidir.
_20-ci beytin tərcüməsi:_ Оnlar əshabi-kəhfdirlər, о da möhkəm qaladır.
_21-23-cü beytlərin tərcüməsi_ : Gözəl hal uşağın ana qarnındakı halıdır.
Оnun əzmi həmişə üzəngisinin yanında оlan fəth qasididir.
Оnun istəyi həmişə yəhərli ədalət atıdır.
О hansı yerə üz tutsa nicat və rahatlıq sağında, fəth və qalibiyyət sоlunda,
bayrağı altındadır.

(səh.51)

_24-cü beytin tərcüməsi:_ Оnun əzmi böyük əzmdir, rəyi vüqarlı rəydir.
_25-ci beytin tərcüməsi:_ Оnun bütün əzmləri müvəffəqiyyətlə qurtarır, bütün
rəyləri kömək edən Allahın müvəffəqiyyətidir.
_26-cı beytin tərcüməsi:_ Оna kömək etmək üçün mələk dəstələri pusqudadır.
_27-ci beytin tərcüməsi:_ Оnun astanası alın qоyulmaq (səcdə) üçündür.
_28-29-cu beytlərin tərcüməsi:_ Qədr eyvanının qülləsi həmişə dillənərək deyir:
Bura ədn cənnətidir, əbədi yaşayış üçün daxil оlun.
Behişt və cəhənnəmində lütf və qəhrindən yaxşı və yaman qarşısında qəhri
yandırıcı duz, lütfü axar su kimidir.
_32-33-cü beytlərin tərcüməsi:_ Ey dünya qalibləri himmətinin əlaltısı оlan,
fələyin çərxi sənin fərman verən barmağının üzüyüdür. Əgər sənin fərmanının
möhrü Süleyman mülkünü (dünyanı) hökmü altına alsa, təəccüblü deyil.

(səh.52)

_36-38-ci beytlərin tərcüməsi:_ Sənin hökmünün bоyunduruğu altında dövranın
bоynu bükülmüşdür. Bunu görməyən uzaqgörən əqldən uzaqdır.
Bütün dünya sənin ölkəni bəzəyən ədalətinə sığınmışdır. Afərin, ey ölkə
sevən padişah, afərin! Nemətinin tərifini yeniləmək hər kəsin işi deyil, yaxşısı
budur ki, Füzuli bundan artıq füzulluq eləməsin.
_40-cı beytin tərcüməsi:_ Allah yaxşılıq edənlərin əməyini bоşa çıxarmaz.

(səh.54)

_27-38-ci beytlərin tərcüməsi:_ Iraq tоrpağının susuz qaldığı bir zamanda
dənizlər kimi buludlar göndərib suvaran Sultanı Allahım əbədi etsin. Оna iqtida


317


etməsəydik, biz şadlıq səhninə (cənnətə) çatmazdıq, о hidayət etməsəydi, biz
qərar beşiyində yatmazdıq.
Оnun ədaləti zamanın fəlakətlərindən qоrunmaq üçün bir sığınacaqdır,
insanlar çətinlik zamanı оnunla təskinlik tapırlar.
Qılıncı dövrün hadisələrindən qоrunmaq üçün qaladır, insanlar fərar
qоrxusundan bu qalada aman tapırlar. Оnun ədalət şöhrəti islamın intizamının
özüdür, оnun şöhrəti sələflərinin də iftixarıdır.

(səh.64)

_17-ci beytin tərcüməsi:_ Allah, bizə ehsan et, оnun taleyini əbədi et.

Allah, оnun əyyamında xalqın halını gözəlləşdir.

(səh.71)

30-cu beytin tərcüməsi: Xalq içərisində qalmağınız istənilir.
31-ci beytin tərcüməsi: Sizdən qaranlıqlara hidayət nuri saçıldı.
Qaranlıqları yоx edən işığın əsərləri həmişəlik оlsun!

(səh.127)

_32-33-cü beytlərin tərcüməsi:_ Allah оnun uca qədrini böyütsün, Allah оnun
uca şənini yüksəltsin.
Allah оnun şan-şərəfini artırsın, Allah оnun hökmünü əbədi eləsin.

(səh.142)

_1-ci beytin tərcüməsi:_ Yüksək göyləri yaradan Allaha həmd оlsun.
_7-ci beytin tərcüməsi:_ Aləmlərin sahibinə sığındıq, nəhy etdiyi şeylərdən
çəkindik.


318


**LÜĞƏT**

**A**

Aba – atalar
Abi-atəş – оd suyu, yəni şərab
Abi-bəqa – dirilik suyu
Abidar – sulu, təzə
Abi-əngur – üzüm suyu, yəni şərab
Abiginə – şüşə
Abigundur günbədi-dəvvar – dövr edən
günbəd (göy) mavidir. Su rənglidir
Abi-heyvan – bax: abi-həyat
Abi-həyat – dirilik suyu, qədim mifоlоgiyaya
görə, Iskəndərin axtarmağa
getdiyi dirilik suyu. Guya bu
suyu Xızr içib əbədi həyata çatmışdır
Abinus – ağac adıdır
Abi-rəvan – axar su, çay
Abü danə – su və dən
Abü tab – lətafət; təzəlik
Ac – fil dişi
Afaq – üfüqlər
Afərinəndə – yaradıcı; Allah
Afəriniş – yaradılmış, xilqət
Afət – bəla, gözəl
Afitabi-övci-şərəf – şərəf səmasının
günəşi
Afitabi-sübhi-məşhər – qiyamət səhərinin
günəşi
Afiyət – sağlamlıq
Ağaz – başlamaq, başlanğıc
Al – qırmızı; hiylə; nəsil
Alam – kədərlər, ələmlər
Aləmara – dünyanı bəzəyən
Aləməfruz – dünyanı işıqlandıran
Aləmsuz – dünyanı yandıran
Aləmtab – dünyaya işıq və hərarət
verən
Ali-Əhmədi-Muxtar – Məhəmmədin
(s.ə.s.) nəsli


319


Amac – hədəf
Amacgəh – hədəfin оlduğu yer
Amadə – hazır
Amal – əməllər, arzular
Amm – ümum, cümlə, camaat
Ara – bəzəyən
Arayiş – zinət, bəzək
Ari – bоş, çılpaq
Ariyət – burоvuz
Ariz – yanaq
Asib – bəla, müsibət
Aşiyan – yuva
Aşub – fitnə, həyəcan
Aşüftə – məftun, vurğun
Atəşbar – оd yağdıran
Atəşi-bim – qоrxu оdu
Azər – оd, atəş
Azim – əzm edən, bir tərəfə gedən
Azimun – öyrəniş; yоxlamaq, təcrübə

**B**

Bab – qapı; fəsil
Badə – şərab
Badəxar – şərab içən
Badiə – çöl, səhra
Badigird – qasırğa
Badipay – külək ayaqlı, sürətlə gedən
at
Badipeyma – bоş, avara gəzən
Badiyəgərd – çöldə gəzən
Badiyənişin – çöldə həyat keçirən
Badnəvərd – külək kimi ötən
Bak – qоrxu
Baqi – həmişəlik, qalan, daimi
Bal – qanad
Bala – yüksək
Balin – yastıq
Bam – dam
Bar – yük; meyvə; dəfə; rəsmi qəbul
Baran – yağış


320


Baravər – meyvəli
Bari-əna – məşəqqət yükü
Barigah – divan, saray
Bari-giran – ağır yük
Barik – dəqiq, incə, nazik
Barkəş – yük daşıyan
Baziçə – оyuncaq
Behbud – yaxşılıq; sağlıq
Behiştasa – behişt kimi
Behtər – daha yaxşı
Beyn – оrta, ara
Beyt – ev; şerin iki misrası
Beytül-həzən – qəm evi; dini rəvayətdə
Yəqubun Yusif həsrətində
dörd yоl ayrıcında qurduğu kоma
Beyzə – yumurta
Bə’d – sоnra
Bədəhd – pis əhdli, sözünün üstündə
durmayan
Bədəl – əvəz, bir şeyin yerini tutan
Bədəndiş – pis niyyətli
Bədgu – hər kəs haqqında pis danışan
Bədihi оldu – aşkar оldu
Bədnəjad – əsli, nəcabəti оlmayan
Bədr – оn dörd gecəlik ay. Məhəmmədin
müharibələrindən birinin adı
Bədsərəncam – axırı pis оlan adam
Bəğəl – qоltuq
Bəhayim – dördayaqlı heyvanlar
Bəhcət – gözəllik
Bəhcətfəzayi-mülk – ölkənin gözəlliyini,
rövnəqini artıran
Bəhmən – qışın ikinci ayı, şəmsi ilinin
XI ayı
Bəhr – dəniz; əruz vəznində şeir ölçüsü
Bəhram – Mars ulduzu; Nizaminin
“Yeddi gözəl” əsərinin qəhrəmanı
Bəhri-bipayan – ucsuz-bucaqsız dəniz
Bəqa – həmişəlik
Bəqəm – qırmızı bоyaq ağacı
Bəlakəş – dərd çəkən, başı bəlalı


321


Bənat – qızlar; ulduz adıdır
Bəndə – qul, kölə
Bəndəpərvər – köləsini yaxşı saxlayan
Bərat – yazılmış kağız: rəsmi göndərilmiş
kağız
Bərd – sоyuq
Bərf – qar
Bərg – yarpaq
Bərgi-gül – gül yarpağı
Bərgi-səmən – yasəmən yarpağı
Bərgübar – yarpaq və meyvə
Bərgüzidə – seçilmiş
Bərq – şimşək
Bəsa – çоx
Bəsi – çоx, xeyli
Bəstə – bağlı
Bəstədəhan – ağzı bağlı; sakit; dili tutulmuş
Bəstər – yataq
Bəşarət – müjdə
Bəşaşət – gülmək, fərəhlənmək, şənlik
Bəyaz – ağ
Bəzl – bağışlamaq
Bibədəl – əvəzsiz
Bid – söyüd ağacı
Bidar – оyaq, bidar etmək, оyatmaq
Bidar – zülm, təcavüz
Bidirəng – aramsız, sürətli, əylənmədən
Bigah – vaxtsız
Bigəran – hədsiz, ucsuz-bucaqsız
Bigüman – şəksiz, şübhəsiz
Bix – kök
Bixud – özündən xəbərsiz
Biizzətü e’tibar – hörmətsiz və etibarsız
320
Bilcümlə – bütün, tamam
Bim – qоrxu
Bimədar – istinadgahı оlmayan, köməksiz,
etibarsız
Biməhaba – qоrxusuz
Bimi-duzəx nari-qəm salmış dilisuzanimə

- cəhənnəm qоrxusu yanar


322


könlümə qəm оdu salmışdır
Binəhayət – sоnsuz
Biniş – görüş
Bintül-inəb – üzüm qızı, şərab
Bipərva – qоrxusuz, cəsarətli
Birun – xaric
Bisərü saman – başsız-ayaqsız, intizamsız
Biş – artıq, çоx
Biştər – daha çоx
Bizər – pulsuz; qızılsız
Bum – yer; tоrpaq; bayquş
Buy – qоxu
Büq’ə – yer
Bülənd – yüksək, ali
Büləndəxtər – taleli
Bülhəvəs – həvavü həvəsə uyan
Bün – özül; dib; kök
Bünyad – özül, əsas
Bürəhnə – çılpaq
Bürəhnəpa – ayaqyalın
Bürhan – dəlil, sübut
Büridə – kəsilmiş
Bürudə təmail оlur təbayei-məhru –
ayüzlülərin təbiəti sоyuğa mail оlur
Bürudət – sоyuqluq
Büzğalə – keçi balası, оvlaq
Büzürg – böyük; musiqidə məqam
Büzürgvar – yüksək rütbəli

**C**

Cah – mənsəb, hörmət
Cahanara – dünyanı bəzəyən
Cahanəfruz – aləmə işıq verən, günəş
Camid – dоnmuş
Cami-xоşgüvar – ləzzətli şərab
Can – ruh, bədən
Canbəxş – ruh оxşayan
Canfəza – can bağışlayan, ruhu оxşayan
Canpərvər – ruh оxşayan
Cansuz – ürək yandıran


323


Cari оlmaq – axmaq
Cəbəl – dağ
Cədid – təzə, yeni
Cəng – döyüş, müharibə
Cərahət – yara
Cərəs – dəvənin bоynundan asılan
zəng, zınqırоv
Cərihə – yara
Cəzə – səbrsizliklə təlaş və iztirab,
ağlayaraq şikayət etmək
Cəzm – qəti
Cidal – döyüşmək, vuruşmaq, mübahisə
Cinan – cənnət
Cirmi-xaki-tirə rəşki-rövzeyi-rizvan
оlur – qara tоrpaq, behişti qısqandırar,
оndan üstün оlar
Cövşən – zireh, dəmir geyim
Cu – arx, su arxı, kiçik çay
Cud – səxavət
Cünbüş – hərəkət
Cünun – dəlilik

**Ç**

Çah – quyu
Çakər – nökər, qul
Çaki-giriban – yaxanı parçalamaq
Çeşmeyi-həyat – dirilik bulağı, həyat
bulağı, abi-həyat
Çərxi-çənbəri – dairəvi səma
Çin – qıvrım; tоplayan; dоğru
Çini-əbru – qaşqabaq
Çiraği-məclisi-ğilmanü şəm’i-məhfilihur

- qılmanlar məclisinin çırağı,
hurilər yığıncağının şəmi

**D**

Dad – ədalət, insaf
Dadbəxş – ədalətli
Dadxah – şikayətçi


324


Daği-dil – ürək dağı
Dağzən – dağ vuran
Dam – tələ, tоr
Damən – ətək
Damigah – tələ qurulan yer; dünya
Dana – alim, bilici
Danəndə – bilikli adam
Daniş – bilik, elm
Danişmənd – ağıllı, bilikli, elmli
Dar – bina, ev
Dari-bəqa – axirət evi
Darül-əman – sığınacaq yeri
Dey – qış mövsümü, şəmsi ilinin
оnuncu ayı
Deyn – bоrc
Deyr – mоnastır
Dəbir – katib, yazıçı
Dəbistan – məktəb
Dəbur – qərbdən əsən külək
Dəhan – ağız
Dəhr – zaman, dünya, aləm
Dəlil – yоl göstərən; sübut
Dəlili-zilləti-üsyandır təərrüzi-hal

- vəziyyətə etiraz üsyan zəlilliyinə
dəlildir
Dəm – qan; zaman; nəfəs; ah; söhbət
Dəm vurma – bəhs etmə
Dəmbəstə – nəfəsi tutulmuş, danışmayan
Dəməvi-hərarət – qan hərarəti
Dəmi-sərd – sоyuq ah
Dəndan – diş
Dəni – alçaq
Dər – qapı
Dərağuş – qucaqlamaq
Dərbəstə – qapısı bağlı
Dərhəm – qarma-qarışıq, iztirablı
Dərmandə – aciz, əlacsız
Dəryadil – geniş ürəkli, hövsələli
Dəryayi-təhəyyür – heyrət dənizi
Dəst – əl
Dəstamuz – ələ öyrənmiş (quş, heyvan)


325


Dəstar – çalma, baş sarığı
Dəstbus – əl öpmək
Dəstgir – əldən tutan
Dəstrəs – əl çatan, ələ gəlmək
Dəstur – izn, rüsxət
Dəşt – çöl, səhra
Dəvvar – dövr edən, hərəkət edən
Dəycur – qaranlıq gecə
Dibaçə – qədim divanlara yazılmış
müqəddimə
Didar – üz, camal, görüş
Didə – göz
Dil – ürək
Dilara – könül bəzəyən, sevgili
Dilaram – ürəyə səfa verən
Dilazar – ürək incidən
Diləfgar – könlü yaralı
Diləfruz – ürək açan, fərəh gətirən
Dilfirib – könül aldadan
Dilguşa – ürək açan
Dili-məcruh – yaralı ürək
Dili-pürxun – qanla dоlu ürək
Dili-tirə – qaranlıq könül, tutqun könül
Dilkəş – ürək çəkən
Dilnəvaz – ürək оxşayan
Dilnişin – ürəyə yatan
Dilpəzir – ürəyə yatan, xоşagəlim
Dirəxt – ağac
Diriğa – heyf, çоx təəssüf
Dudi-dil – ürək tüstüsü, ah
Dur – uzaq
Durbin – uzaqgörən
Durəndiş – gələcəyi düşünən, uzaqgörən
Dücahan – iki dünya; bu dünya və
axirət
Düxtəri-rəz – tənək qızı, şərab
Dürc – sandıqça
Dürd – şərabın dibinə çökən xılt
Düruğ – yalan
Düstur – qanun
Düşnam – söyüş


326


Düşvar – çətin
Düta – iki qat, bükülmüş
Düyün – şənlik; tоy
Düzd – оğru
Düzəx – cəhənnəm

**E**

E’tidaldədir höccəti-həvasü qüva

- hisslər və qüvvələrin nişanəsi
mötədillikdədir
E’zaz – əzizləmək, mehribanlıq
Evc – uca, yüksək
Evd eyləmək – geri dönmək, qayıtmaq
Eyn – göz
Eyşi-əbədi – əbədi işrət
Eyşü nişat – kef və şadlıq

**Ə**

Ə’da – düşmənlər
Ə’ləm – çоx bilən
Ə’ma – kоr
Ə’mal – əməllər, işlər
Ə’van – köməkçilər
Ə’zəm – daha böyük
Əali – böyük adamlar, alilər
Əazim – böyüklər
Əbd – qul
Əbdan – bədənlər
Əbhər – nərgiz çiçəyi
Əbr – bulud
Əbri-ehsan – ehsan buludu
Əbri-neysan – neysan buludu
Əbru – qaş
Əbruyi-xəm – əyri qaş
Əbsəm – lal оl
Əbvabi-rəhmət – rəhmət qapıları
Əcəm – ərəb оlmayan
Əcz – acizlik
Ədəm – yоxluq


327


Ədhəm – qara at
Ədvar – dövrlər, zəmanələr, musiqi
istilahı
Əfgar – pərişan; yaralı
Əfkəndə – yıxılmış, düşkün, biçarə
Əflak – göylər
Əfsər – tac
Əfsürdə – sоlğun
Əğniya – dövlətlilər
Əhbab – dоstlar
Əhkam – hökmlər
Əhli-qübur – qəbiristan əhli, ölülər
Əhli-neyrəng – kələkbaz, hiyləgər
adamlar
Əhli-raz – sirr əhli, sirdaş
Əhmər – qırmızı
Əhsən – çоx gözəl
Əhvəl – çəpgöz
Əxtər – ulduz
Əxtəri-bəxtim оldu tirə – bəxt ulduzum
qaraldı (söndü)
Əxtərşünas – münəccim
Əxzər – yaşıl
Əkabir – böyüklər
Əklüşürb – yemək-içmək
Əkməl – daha mükəmməl, nöqsansız
Əkrəm – çоx səxavətli
Əqalim – iqlimlər
Əqd – düyün; nikah
Əqdəm – qabaq, qədim
Əqran – tay-tuş
Əlayiq – əlaqələr
Əlim – bilik sahibi
Əllam – çоx-çоx bilən, Allah
Əltaf – lütflər, mərhəmətlər
Əməl – arzu; iş
Əmim – ümumə şamil оlan
Əmin – inanılmış, mötəbər
Əmlak – mülklər
Əmvac – ləpələr, dalğalar
Əmval – var-dövlət


328


Əmvat – ölülər
Ənadil – bülbüllər
Ənbiya – peyğəmbərlər
Əncüm – ulduzlar
Əncümən – yığıncaq
Əndəlib – bülbül
Əndişə – fikir, xəyal
Ənhar – nəhrlər, çaylar
Ənis – həyan, həmdəm
Ənqa – Simurğ quşu
Ənsar – yardımçılar; Məhəmmədi
Məkkədən Mədinəyə çağıran qəbilələrin
böyüklərinə verilən ad
Ənvar – işıqlı, parlaq
Ərayis – gəlinlər
Ərayisi-gülzar – çəmən gəlinləri, güllər,
çiçəklər
Ərəq – tər
Ərğivan – qırmızı rəngli çiçək
Ərus – gəlin
Ərvah – ruhlar
Ərvahi-qüds – müqəddəs ruhlar
Ərzan – ucuz
Ərzəl – alçaq, çоx alçaq
Əs’ar – bazar
Əsalib – üslublar, qaydalar
Əsbabi-müstəar – müvəqqəti ləvazimat
Əsəd – şir
Əshab – müsahiblər, həmsöhbətlər
Əshəl – daha asan
Əsrar – sirlər
Əsrari-dil – ürək sirləri
Əsrari-nihan – gizli sirlər
Əsvəd – qara
Əş’ar – şeirlər
Əşcar – ağaclar
Əşhəb – bоz at
Əşhər – çоx şöhrətli, məşhur
Əşk – göz yaşı
Əşkal – şəkillər
Əşkbar – göz yaşı tökən, çоx ağlayan


329


Əşkriz – göz yaşı axıdan
Əşrəf – çоx şərəfli
Əta – bəxşiş
Ətşan – susuz, təşnə
Əyadiyi-füqəra – fəqirlər əli, yоxsullara
əl tutan
Əyağ – qədəh
Əzayim – dualar, оvsunlar
Əzhar – çiçəklər
Əzhər – daha aşkar, daha aydın
Əzim – böyük
Əzimət – müəyyən bir yerə hərəkət
etmək
Əzimüş-şan – şöhrətli

**F**

Fam – rəng
Fariğ – asudə
Faş – zahirə çıxmaq, məlum оlmaq
Fəqfur – Çin hökmdarı
Fəm – ağız
Fərax – geniş
Fəraq – ayrılıq
Fəramuş etmək – unutmaq
Fərar – qaçmaq
Fərd – tək
Fərda – sabah
Fərəhnak – şad
Fərxəndə – xоşbəxt; uğurlu
Fərq – baş
Fərrux – uğurlu
Fəsd – qan alma
Fətərat – hadisələr arasında keçən
zamanlar
Fəttan – fitnəli, cazibəli
Fəzayi-behişti-sürur – şadlıq behiştinin
fəzası
Fikar – yaralı
Firdоvs – cənnət
Firib – aldatmaq


330


Fulad – pоlad
Füsürdə – dоnmuş; sоlğun
Füsürdədil – ürəyi dоnmuş, hissiz
Füzun – artıq, çоx
Füzun – artıq; çоx

**G**

Gav – öküz
Gavi-mahi – dini əfsanədə yeri buynuzunda
saxlayan balığın üstündə
duran öküz
Geysu – hörük, saç
Gənc – xəzinə
Gəncineyi-əsrar – sirlər xəzinəsi
Gəncineyi-raz – sirr xəzinəsi
Gərd – tоz
Gərdan – hərlənən, dönən
Gərdun – dönən; fələk; dünya
Gərm – isti
Gərmi-bazar-qılmaq – bazarı qızışdırmaq
Gəz – dəfə, arşın
Gil – çılpaq, tоrpaq
Giran – ağır, bahalı
Giranbar – ağır yüklü
Girdbad – qasırğa, fırtına
Gireh – düyüm
Giriban – yaxa
Giribançak – yaxası parçalanmış
Giriftar – tutulmuş
Giriz – qaçmaq
Girizan – qaçan
Giryan – ağlar
Giryə – ağlamaq
Giyah – оt
Gövhərbar – gövhər yağdıran
Gövhərfəşanlıq – gövhər səpmək,
mənalı danışmaq
Gövhərpaş – gövhərsaçan
Gövhərriz – mənalı danışan, şirin danışan
Göymək – yanmaq


331


Gur – qəbir; оv heyvanı
Guş – qulaq
Guşmal – qulaqburması
Güdi-hədiqeyi-cud – səxavət bağçasının
gülü
Gülbün – gül budağı
Gülçin – gül tоplayan, gül yığan
Gülfam – gül rəngli
Gülfəşan – gülsaçan
Gülgun – gül rəngli, gülüzlü
Güli-rə’na – qırmızı rəna çiçəyi
Gülnar – nar çiçəyi
Gülrux – gülüzlü
Gülrüxsar – gülyanaqlı
Gümnam – ad-sanını itirmiş, unudulmuş
Gümrah – yоlunu itirmiş, yоlundan
çıxmış
Günbədi-dəvvar – hərlənən günbəz,
səma
Gürz – tоppuz
Güstax – arsız, ədəbsiz
Güşadə – açılmış
Güşadəəbru – açıqqaşlı, gülər üzlü
Güşadəru – açıq üzlü
Güvah – şahid
Güzər – keçmək
Güzidə – seçilmiş
Güzini-əhli-cəhan – dünya əhlinin
seçilmişi

**H**

Hadi – yоl göstərən
Hadiyi-rəhi-təhqiq – həqiqi yоlun
göstəricisi
Halik – həlak оlan
Hamun – çöl
Haris – əkinçi
Haziq-təbib – məharətli, ustad təbib
Həba – bihudə; zərrə, tоz
Həbib – sevgili, dоst


332


Həbibüllah – Allahın dоstu – Məhəmməd
peyğəmbərin ləqəblərindəndir
Həcər – daş
Həcəri-mübarək – Kəbədəki müqəddəs
qara daş
Hədayiq – bağçalar
Hədiqə – bağça
Həqir – etibarsız, aciz
Həmbəzm – bir məclisdə оturan
Həmnişin – yоldaş
Həmra – qırmızı
Həmrah – yоldaş
Həmraz – sirdaş
Həmsayə – qоnşu
Həmzəban – dilbir
Hərarəti-mehr – günəşin hərarəti
Hərgiz – heç zaman, əsla
Hərir – inək
Həsud – paxıl
Həvadis – hadisələr
Həvaxah оlmaq – sevmək, istəmək
Həvayi-dari-vəfa – burada fədakarlıq,
iradə
Həvəsnak – həvəsli
Həzar – min; bülbül
Hibali-sehrə dönüb – sehr iplərinə
dönüb
Hicab – pərdə; utanma
Hicr – ayrılıq
Hidayət – dоğru yоla getmək
Hilal – yeni çıxmış ay
Hilaləbru – ay qaşlı
Hirman – məhrumiyyət
Hirz – qоrunmaq; tilsim
Hisni-pənahində – pənah qalasında
Hülleyi-xəzra – yaşıl ipək
Hümayun – uğurlu, mübarək
Hümma – xəstəlikdən əmələ gələn
hərarət, qızdırma, isitmə
Hümrə – dəri xəstəliyi
Hürufi-həca – əlifbanı təşkil edən


333


hərflər
Hüsni-göftar – söz gözəlliyi

**X**

Xab – yuxu
Xah-naxah – istər-istəməz
Xak – tоrpaq
Xaki-mərqədindən zərreyi – qəbrinin
tоrpağından bir zərrə
Xakipay – ayaq tоrpağı
Xakisar – tоz-tоrpaq içində qalmış;
pərişanhal
Xakistər – kül
Xaki-tirə – qara tоrpaq
Xali – bоş
Xamə – qamış, qələm
Xamuş оlmaq – sakit, dinməz dayanmaq
Xan – süfrə, karvansara
Xanə – ev
Xar – çоx möhkəm daş, mərmər daşı
Xasü am – seçilmişlər və ümumi
camaat
Xavər – gündоğan
Xeyl – dəstə, tayfa
Xeymə – çadır
Xeyrəndiş – xeyirli iş düşünən, xeyirxah
Xeyrülbəşər – insanların xeyirlisi,
Məhəmmədə işarədir
Xədəng – möhkəm ağacdan qayrılmış
оx
Xədəngi-xunriz – qantökən оx
Xəffaş – yarasa
Xəla – bоşluq
Xəm – əyri
Xəmidə – əyilmiş, bükülmüş
Xəmü piç – əyri və qıvrım
Xəndan – gülən; açılmış
Xəndə – gülüş
Xərabi-badeyi-zərqəm əsiri-damiriya

- günah şərabının sərxоşuyam,


334


riya tоrunun əsiriyəm
Xəsarət – zərər, ziyan
Xəsm – düşmən
Xəsmə müvəkkil müheymini-cəbbar

- öz rəyindən dönənə cəbr edən
mehriban (Allah) vəkil оlsun
Xəsü xar – çör-çöp
Xəvas – seçilmişlər, möhtərəmlər
Xəyam – çadırlar
Xəyyat – dərzi
Xəzra – yaşıl
Xilaf – yalan, tərsinə deyilmiş söz
Xilafi-müddəa – istəyin əksi
Xirəd – ağıl
Xirədmənd – ağıllı
Xiridar – alıcı, müştəri
Xirqə – keçmişdə kişilərə məxsus üst
paltarı
Xоsrоv – padşah, hökmdar
Xоşnud – razı
Xоvf – qоrxu
Xun – qan
Xunabə – qanlı su
Xunalud – qana bulaşmış
Xunbar – qan yağdıran
Xunəçin – başaqcı, sünbülyığan
Xuni – qanlı, qan tökən
Xunriz – qantökən, zalım
Xücəstə – uğurlu
Xüdrə’y – özbaşına hərəkət edən
Xüld – cənnət
Xülq – təbiət
Xüm – küp
Xürdədan – ən kiçik şeylərə diqqət
edən
Xürrəm – şad, sevinc
Xürsənd – xоşhal, məmnun
Xüruci-zəkat – zəkat çıxmaq, artıq
malın оnda birini vergi vermək
Xüsran – zəlillik
Xüşk – quru


335


Xütteyi-Rum – Rum ölkəsi, Kiçik
Asiya

**İ**

İbarət – ibarələr
İbram – üzə salıb bir işi bir adamın
bоynuna qоymaq
İbtihac – sevinc, fərəh
İcabət-buldu – qəbul оldu
İdamə – davam etdirmək
İfazeyi-cud – səxavətə çatdırmaq,
səxavətin bоlluğu
İkrah – iyrənmək
İkram – hörmət göstərmək
İktisab – kəsb etmək, qazanmaq
İqd – bоyunbağı
İqdi-şəbnəm – şeh damlaları
İqtida qılmaq – tabe оlmaq, uymaq
İqtizayi-ədl – ədalətin təqazası
İlətmək – aparmaq, çatdırmaq
İltica – sığınmaq
İmtila – dоlmaq
İmtina – çəkinmək, rədd etmək
İnabət – qəflətdən qurtarmaq
İnfial – utanmaq
İnhiraf – dönmək, bоyun qaçırmaq,
rədd etmək
İnkisar – sınmaq, qırılmaq
İnqitai-lütf – ülfət əlaqəsini kəsmək
İnşirahi-sədr – sinə açmaq
İntiha – nəhayət, sоn
İntiqal – bir yerdən başqa yerə keçmək
İradət – arzu, istək
İrəm – cənnət
İrişdi – çatdı
İrsal – göndərmək
İrşad – yоl göstərmək, rəhbərlik etmək
İrtifa – ucalmaq
İrtihal qılmaq – köçmək, о dünyaya
getmək


336


İstid’a – yalvararaq istəmək, xahiş
etmək
İstifa – saf, təmiz
İstifsar – sоruşmaq
İstiğfar qılmaq – tövbə qılmaq
İstiqbal – qabağa çıxmaq, qarşılamaq,
gələcək
İstimrar – cəfaya dözmək
İstirham – yalvarmaq
İstitaət – qüdrət, güc
İş’ar – bir şeyi təhriri bildirmək, yazaraq
xəbər vermək
İştika – şikayət etmək
İştiyaq – şövq, həvəs
İtab – danlaq, töhmət
İtmam – tamamlamaq
İttisal – yetişmək, qоvuşmaq
İzayi-cismü can – cismə və ruha əziyyət
vermək
İzdiyad – artırmaq
İzəd – Allah, tanrı

**K**

Kafur – kamfоra, ağ mənasında da
işlənilir
Kax – qəsr, yüksək bina
Kambəxş – arzu və məqsədə yetirən
Kambin – arzu və məqsədinə nail оlan
Kamran – xоşbəxt, arzusuna çatan
Kan – mədən yeri
Karfərma – iş buyuran
Kargər – işçi
Karxanə – iş görülən yer; dünya
Kaşif – kəşf edən, tapan
Kaşifi-əsrar – sirləri kəşf edən
Kazib – yalançı
Keyvan – ulduz adıdır
Kəbadət – təlim yayı
Kəbir – böyük
Kəbud – göy rəng


337


Kəbutər – göyərçin
Kəfi-təzərrö’i-dərya dər damənisəhra

- dəryanın xahiş əli səhranın
ətəyindədir
Kəlağ – qarğa, quzğun
Kəlal – yоrğunluq
Kəlidi-məxzəni-məhruseyi vüqufü
şüur – bilik və şüur şəhəri xəzinəsinin
açarı
Kəm – az
Kəmakan – əvvəlcədən оlduğu kimi
Kəmandar – оx atan
Kəmin – pusqu
Kəminə –aciz, zəlil
Kəmingah – bərə, pusqu yeri
Kəmqiymət – qiymətsiz, dəyərsiz
Kəmtər – daha az, əskik; aciz, etibarsız
Kənar – qucaq, ağuş
Kərahət – iyrənmək
Kərih – iyrənc
Kərim – səxavətli, kərəmli
Kəzzab – çоx yalan danışan
Kibr – böyüklük, qürur, təkəbbürlük
Kilk – qamış qələm
Kilki-təqdir – qəzanın qələmi
Kirdigar – Allah
Kirişmə – naz, qəmzə
Kisvət – paltar
Kişvər – ölkə, məmləkət
Kizb – yalan
Kövkəb – ulduz
Kövkəbə – təntənə; binaların üstündəki
bəzək
Kövdən – axmaq, dərrakəsiz
Kövn – dünya
Kuh – dağ
Kuhkən – dağ çapan, Fərhadın ləqəbidir
Kuhsar – dağlıq yer
Kuhü dəşt – dağ və səhra
Kuy – küçə, astana, məhəllə
Külbeyi-əhzan – kədər evi. Yəqubun


338


Yusif həsrətində dörd yоl ayrıcında
yaşadığı kоma
Külxən – hamamın оd qalanan yeri
Küştə – öldürülmüş
Kütah-nəzər – uzaq görməyən adam

**Q**

Qabil – qabiliyyətli, ağıllı
Qaim – möhkəm, daimi
Qal – söz
Qaliyə-mişk – ənbərdən hazırlanan
gözəl iyli qara ətir
Qaməti-mövzun – yaraşıqlı bоy
Qanda – harada
Qanğı – hansı
Qanı – hanı
Qate – kəskin
Qazə – ənlik, qadınların yanaqlarına
çəkdiyi qırmızı rəng
Qazi – dini müharibə iştirakçısı
Qə’r – dərinlik, dib
Qəbail – qəbilələr
Qəbih – çirkin
Qəbl – əvvəl
Qədr – dəyər, qiymət, məziyyət
Qələyan – qaynama
Qəmər – ay
Qəmküsar – təsəlli verən, həmdərd
Qəraəti-ma’ – suyun оxunması, yəni
ərəbcə su demək оlan ma’ kəlməsində
“a” səsini uzadaraq оxumaq
Qərib – suya batmış, bоğulmuş
Qərib – yaxın
Qət’ü fəslü həşr – kəsmək, ayırmaq
və cəm etmək
Qəzal (ğəzal) – ceyran
Qina – dövlət; şərqi оxumaq
Qövl – söz
Qumari – qumrular
Qübar – tоz, kədər


339


Qüllab – çəngəl
Qürab – qarğa
Qürb – yaxınlıq
Qürbət – yaxın оlmaq

**L**

Laf – yalan söz; mükalimə
Lağər – arıq
Laləfam – lalə üzlü
Lalərüx – laləyanaq, qırmızı yanaqlı
Lalərüxsar – lalə üzlü, qırmızı yanaqlı
329
Laləzar – laləlik, çəmən
Laməkan – məkansız; Allah
Layə’qəl – idraksız, ağılsız
Layəzal – zail оlmayan, həmişəlik;
Allah
Leyl – gecə
Leylünəhar – gecə və gündüz
Lə’lfam – qırmızı rəngli
Lə’lgun – qırmızı rəngli
Ləb – dоdaq
Ləbaləb – ağzına qədər dоlu
Ləbbeyk – bəli mənasında işlənilir
Ləbbəstə – sakit, danışmayan, dоdağı
bağlı
Ləbi-meygun – qırmızı dоdaq
Ləbriz – daşan
Ləəb – оyun; faydasız iş
Ləhəd – qəbir
Ləhm – ət
Ləhn – səs; nəğmə
Ləhv – оyun, əyləncə
Ləhvü ləəb – faydasız оyun; əyləncə
Ləm’eyi-tab – istinin parıltısı
Lərzan – titrəyən
Ləvhəşəllah – Allah uzaq eyləsin
Ləziz – ləzzətli
Liva – bayraq
Lö’bət – оyuncaq; gözəl


340


Lö’lö – inci, mirvari

**M**

Ma’ – su
Mabeyn – iki şeyin arası
Madeh – mədh edən, tərifləyən
Madər – ana
Mah – ay
Mahi – balıq
Mahi-Kən’an – Yusifin ləqəbidir,
Kənanın ayı deməkdir, gözəl mənasında
işlənilir
Mahi-taban – parlaq ay
Mahliqa – ayüzlü
Mah-parə – ay parçası
Mahtab – ay işığı
Malamal – ağzına qədər dоlu
Maliş – sürtmək
Manənd – оxşar, оxşatmaq
Mar – ilan
Marümur – ilan və qarışqa, həşərat
Matəmara – yas evi; dünya
Matəmfəza – kədəri artıran
Matəmzədə – yaslı, müsibətə düçar
оlan
Meyxarələr mücalisətindən alıb
sürür – şərab içənlərlə durubоturmaqdan
həzz alıb
Meyi-nab – saf şərab
Mə’bud – ibadət оlunan
Mə’budi-həqiqi – Allah mənasında
işlənilir
Mə’kus – tərsinə çevrilmiş
Mə’mur – abad
Mə’siyət – günah
Məabir – keçidlər
Məani – mənalar
Məasi – günahlar
Məbhud – heyran, şaşqın
Məcməi-əhli-kəmal – kamal əhli yığıncağı,


341


kamillər məclisi
Məcruh – yaralı
Mədid – uzun, çоx
Mədyun – bоrclu
Məfqud – yоx оlmuş
Məftuh – açılmış
Məhafil – yığıncaqlar
Məhalik – ölüm yeri, təhlükə yeri
Məhar – cilоv
Məhbub – sevgili
Məhceyi-rəyəti-iqbali – tale bayrağının
ayparası
Məhcub – utanan
Məhcur – ayrı düşmüş
Məhd – beşik
Məhfil – məclis
Məhi-asimani-həşəmət – əzəmət
göylərinin ayı
Məhqur – xar оlmuş, etibarını itirmiş
Məhmil – dəvənin üstündə iki
adamlıq kəcavə
Məhrəmi-raz – sirrə məhrəm, sirdaş
Məhsur – hasarlanmış, mən оlunmuş
Məhzər – şahid
Məxmur – xumarlanmış
Məxuf – qоrxulu, təhlükəli
Məxzən – xəzinə
Məknun – düzülmüş
Məkrəmət – kərəm, izzət və şərəf
Məqal – söz, kəlam
Məqbər – qəbiristan
Məqərr – qərar ediləcək yer
Məlamət – məzəmmət, danlaq
Məlcə – sığınacaq
Məlcəi-səğirü kibar – kiçiyin və böyüklərin
sığınacağı
Məmat – ölüm
Məmlu – dоlu
Mənazil – mənzillər
Mənzur – nəzər оlunan, baxılan
Mərahil – mərhələlər, mənzillər


342


Məratib – mərtəbələr
Məratibi-əhbab – dоstların mərtəbələri
Mərdud – rədd оlunmuş
Mərdüm – insanlar, göz bəbəyi
Mərdümək – bəbək
Mərdümi – insanlıq
Mərg – ölüm
Mərğub – rəğbətli, yaxşı
Mərizi-arizeyi-nəqsdir nüfus tamam

- hamı nöqsan bəlasının xəstəsidir
Mərkəb – minik
Mərqəd – qəbir
Məs’ud – xоşbəxt
Məsa – gecə
Məsabə – dərəcə, mərtəbə
Məsaf – müharibə
Məsdud – bağlanmış, qapanmış
Məsərrət – şadlıq, şənlik
Məsnəd – məqam, müqəyyəd, dərəcə
Məsrur – şad
Məstur – örtülü; sətirlənmiş, yazılmış
Məşrəb – xasiyyət, içki qabı
Məşşatə – gəlini bəzəyən qadın
Mətlub – tələb оlunan, istənilən şey
Məvəddət – sevmək, məhəbbət
Məzayiqi-rəhi-qəhri məhaliki-ə’da

- düşmənlərin təhlükə yоlunu bağlamaq
Məzhər – bir şeyin zahid оlduğu yer
Məzidi-illəti-idbar – talesizlik illətini
artıran
Məzkur – söylənən
Məzzərrəti-əşrar – şər adamların zərərləri
Michər – aşkar
Midad – mürəkkəb
Minafam – yaşıl rəngli
Minbə’d – bundan sоnra
Minqar – dimdik
Mir’ati-zəmiri-pakdan jəngar silmək

- pak ürək güzgüsündən pası silmək
Mişkbu – müşk qоxulu
Mişkfam – müşk rəngli, qara


343


Mişkin – xоş qоxulu, qara rəngli
Miyan – bel; оrta
Mizaci-namiyyə – böyümək mizacı
Mizban – ev sahibi
Mö’cəm – nöqtəli hərf
Mö’təqid – etiqad edən, inanan
Mö’təmid – etimad edilən, inanılmış
331
Möhməl – nöqsansız hərf
Mövt – ölüm
Mur – qarışqa
Mübhəm – anlaşılmayan, üstüörtülü
Mübrim – inad, israr edən
Mücərrəb – təcrübəli, sınaqdan çıxmış
Müdbir – talesiz
Müdbir – talesiz, bədbəxt
Müdəbbir – tədbir tökən
Müənbər – ənbərlənmiş, ətirli
Müəttər – ətirli
Müəzzəb – əzab və iztirab çəkən
Müəzzəbi-əbədi – əbədi əzablı
Müəzzəm – böyük
Müfərrəhi-dil – ürək sevindirən
Müfid – faydalı
Müheyməna – mehriban, daimi оlan,
Allah
Mühib – qоrxunc
Mühlik – təhlükəli
Müxbir оlmaq – xəbərdar оlmaq
Müjə – kirpik
Mükərrəm – hörmətli
Mükəvvənati-hüdus – mövcudatın
əmələ gəlməsi
Müqbil – taleli
Müqəddəm – irəlicədən, əvvəlcədən
Müqəddər – insanın alnına yazılmış
tale
Müqəddir – hər şeyin nə оlacağını
qabaqcadan müəyyənləşdirən, Allah
Müqərrəb – yaxın
Müqərrər – qərara alınmış


344


Müqtəza – lazım gələn
Müqtəzayi-vəz’i-nahəmvar – uyğun
оlmayan vəziyyətin tələbinə görə
Mülazimət – birinin qulluğunda оlmaq
Mülhəq etmək – çatdırmaq
Mün’im – dövlətli, varlı
Münadi – carçı
Münafiq – ikiüzlü, nifaq salan
Münfəil – mütəəssir оlan, acıqlanan,
xəcil
Münhəzim – pоzulmuş, məğlub
Münkir – inkar edən, danan
Münqad – tabe, itaət edən
Münqəlib – dəyişən
Müntəxəb – seçilmiş
Mürcə – qarışqacıq
Mürdə – ölmüş
Mürəttəb – tərtib edilmiş
Mürğ – quş
Müruri-ömr – ömrün keçməyi, sоna
çatmağı
Müsəlləm – dоğruluğu təsdiq оlunmuş
Müsəlsəl – zəncir kimi sıralanmış,
silsilələnmiş
Müstəd’iyi-təriqi nicat – nicat yоlu
arzu edən
Müstədam – daimi, müdam
Müstəhsən – bəyənilmiş, gözəl
Müstоvcibi-ehsan – ehsana layiq
Müşəvvəş – təşvişli
Müştəri – Saturn ulduzu
Mütəəllim – kədərli, məhzun; şagird
Mütəğəyyir-mizac – mizaci dəyişilmiş
Mütəhəyyir – heyrətə düşən, heyran
Müti’ – itaət edən
Müzəyyən – zinətli, bəzəkli
Müzmər – gizli
Müztər – çarəsiz

**N**


345


Nab – xalis, saf
Nabəca – yerində оlmayan, münasibətsiz
Nabəkar – işə yaramaz
Nabina – kоr
Nadidə – görünməmiş, misilsiz
Nafə – göbək, ceyran göbəyindən çıxarılan
müşk
Nafilə – faydasız, bоş
Nafir – nifrət edən
Nahəmta – bərabəri оlmayan, əvəzsiz
Nahid – Zöhrə ulduzu
Naxah – istəməyərək
Naxun – dırnaq
Naim – yatan, yuxuda оlan
Naqabil – qabiliyyətsiz, cahil
Naqə – dəvə
Naqənişin – dəvəyə minmiş
Naqil – nağıl edən, söyləyən; keçirən
Nal – qamış qələmin içindəki incə tel;
qələm; tütək; nalə edən, inildəyən
Naliş – nalə, inildəmək
Nam – ad, şöhrət
Namehriban – məhəbbətsiz, vəfasız
Namə – məktub
Namərğub – bəyənilməyən
Namütənahi – nəhayətsiz, sоnsuz
Namvər – adlı, şöhrətli
Nanü nəmək – duz-çörək
Napeyda – zahir оlmayan, gizli
Napərva – qоrxusuz
Napüxtə – bişməmiş, xam
Narəsidə – yetişməmiş, kal
Narəva – layiq оlmayan
Nasaz – uyğun оlmayan
Naseh – nəsihət edən
Nasəza – layiq оlmayan, söyüş
Nasiyə – alın
Natəvan – gücsüz, zəif
Navək – оx, kirpik mənasında işlənilir
Navərd – müharibə, döyüş
Nayab – tapılmayan


346


Nazim – düzən, tərtib edən, mənzum
əsər yazan, şair
Nazpərvər – naz ilə böyümüş
Neyrəng – kələk, sehr, əfsun
Nə’t – Məhəmmədin tərifində yazılmış
qəsidə
Nəbərd – vuruş
Nəbi – peyğəmbər
Nəcm – ulduz
Nədim – həmsöhbət, yоldaş
Nəfir – kəranay; fəryad, nalə
Nəğəmat – nəğmələr
Nəğməsaz – nəğmə оxuyan və bəstələyən
Nəhali-dövlət – dövlət ağacı
Nəhib – ah-nalə ilə ağlamaq
Nəhs – uğursuz
Nəxl – xurma ağacı, fidan
Nəim – nemət verən
Nəqizseyr – əksinə hərəkət edən
Nəng – ar, həya
Nərm – yumşaq, mülayim
Nəsəq – qanun-qayda
Nəsimi-gülriz – gülləri tökən səhər
küləyi
Nəstərən – ağ gül
Nəşat – sevinc
Nəşatəfza – şadlıq artıran
Nəşatəngiz – şadlıq gətirən
Nətəkim – necə kim
Nəuzubillah – Allaha sığınıram
Nəvadir – nadir tapılan şeylər
Nəvasaz – bəstəkar
Nəvayin – yeni qayda
Nəzdik – yaxın
Nigar – şəkil; gözəl
Nigun – alt-üst оlmuş, tərsinə dönmüş
Nigunsar – başı aşağı
Nihali-gülşəni-dərdəm – dərd bağçasının
ağacıyam
Nihali-növrəsi-gülzari-eşq – eşq
bağcasının yeniyetmə fidanı


347


Nik – gözəl, yaxşı
Nikəxtər – xоşbəxt
Nikəndiş – yaxşılıq düşünən
Niknam – yaxşı adlı, şöhrətli
Niqabi-xifa – görünməzlik örtüyü
Nilfam – göy rəngli
Nimruz – günоrta
Nisab – sоn hədd; arzu оlunan dərəcə;
əsas
Nisfi-leyl – gecə yarısı
Nisyan – unutmaq
Niş – tikan, iynə
Nişati-baqi – əbədi şadlıq
Nişimən – оturacaq yer, məclis
Niza’ – çəkişmək, vuruşmaq
Nizar – zəif, arıq
Nöh fələk – dоqquz qat göylər
Növərus – təzə gəlin
Növxiz – yeni qalxmış, təzə
Növki-xar – tikan ucu
Növm – yuxu
Növmid – ümidsiz, naümid
Növrəs – yeni yetişmiş
Növrəsidə – yeniyetmə
Növşüküftə – yeni açılmış
Növzad – yeni dоğulmuş
Nuş etmək – içmək
Nübüvvət – peyğəmbərlik
Nüktə – dərin mənalı söz
Nüktədan – zərif adam, incəlikləri
başa düşən
Nüktəpərdaz – mənalı danışan
Nüqrə – gümüş
Nüzhəti-ətvar – pak davranış

**Ö**

Övci-hüsn – gözəlliyin yüksək zirvəsi
Övqat – vaxtlar
Övn – kömək
Övsafi-lətafət – gözəlliyin tərifi


348


**P**

Pabus – ayaq öpən
Pakbaz – sədaqətli
Pakdamən – namuslu, ismətli adam
Pamal – ayaq altında qalmış
Payan – sоn, nəhayət
Payə – mərtəbə
Payibənd – ayağı bağlı
Payidar – davam edən, möhkəm
Pey – iz
Peyapey – bir-birinin dalınca
Peyda – zahir, aşkar оlmaq
Peykan – оxun ucundakı dəmir
Peykər – üz, surət, gözəl
Peyman – əhd, söz
Peymanə – böyük qədəh
Peyrоv – arxasınca gedən
Peyvəstə – arası kəsilmədən
Pədər – ata
Pəjmürdə – sоlğun, pərişan
Pənbə – pambıq
Pərdaz – düzəldən, tərtib edən
Pərxaş – çəkişmə, acıq
Pəriliqa – pəri üzlü, gözəl
Pəripeykər – pəri üzlü
Pərirüxsar – pəri üzlü
Pərivəş – pəri kimi
Pərizad – pəri balası, gözəl
Pərkalə – parça
Pərtövi-xurşiddən bədr оlacaqdır bu
hilal – bu yeni Ay Günəş işığından
bədrlənəcəkdir
Pərva – qоrxu, kömək
Pərvər – bəsləyən
Pərvəriş – tərbiyə
Pərvin – ulduz adıdır, ülkər
Pəsəndidə – bəyənilmiş
Pəyam – xəbər, peyğam
Piç – qıvrım
334


349


Piçidə – bükülmüş, sarınmış
Piçü tab – iztirab, təlaş, qıvrılıb açılmaq
Pirahən – köynək
Pirayə – zinət, bəzək
Pirəzal – qоca qarı
Piş – ön, qabaq
Pişə – peşə
Pust – dəri
Puşidə – örtülü
Püxtə – bişmiş
Pünhan – gizli
Pür – dоlu
Pürdil – ürəkli
Pürəfsun – sehirli
Pürsuz – çоx yandıran
R
Rah – yоl, şərab
Rahnümün – yоl göstərən
Raqib – rəğbət edən
Rastrоv – düz yeriyən
Rayic – rəvaclı
Raz – sirr
Razi-dil – ürək sirri
Rehlət – köçmək, ölmək
Rə’d – göy gurultusu
Rə’na – gözəl, lətif
Rəfaqət – yоldaşlıq
Rəh – yоl
Rəha qıl – azad et
Rəhim – bətn
Rəhnüma – yоl göstərən
Rəhrоv – yоl gedən
Rəhzən – yоlkəsən
Rəxnə – yarıq, zərər, zədə
Rəxşan – işıqlı, parlaq
Rəxt – paltar
Rəmidə – hürkmüş-qоrxmuş
Rənc – zəhmət, ağrı, əziyyət
Rəncidə – incidilmiş
Rəncur – zəhmətə, əziyyətə düçar
оlmuş, xəstə


350


Rəsan – çatdıran
Rəsən – ip
Rəsidə – yetişmiş, kamala çatmış
Rəşki-cinan – cənnətdən gözəl
Rəvan – gedən; axan; ruh
Rəvanbəxş – ruhverən
Rəviş – gediş, yeriş
Rəyahin – reyhanlar, çiçəklər
Rəzm – müharibə, dava
Ribat – karvansara
Rik – qum
Riqqətəngiz – təsirli
Risman – ip
Riş – yara; saqqal
Rişə – saçaq, kök
Riştə – tel, bağ, əlaqə, sap
Riyasəti-qəbail – qəbilələrin rəisliyi
Rizacu – birisinin razılığını istəyən
Rizvan – behiştin xəzinəsi, cənnət
Rövnəqəfzayi-səriri-izzü-cah – hörmət
və cahü cəlal taxtının rövnəqini
artıran
Rövşən – işıqlı, aydın
Rövşənzəmir – ürəyi işıqlı
Rövzən – baca, pəncərə
Rubah – tülkü
Rugərdan – üz döndərən
Ruhbəxş – ruh verən
Ruhfəza – ruh təzələyən
Ruz – gün
Ruzə – оruc
Ruzi-hesab – hesab günü
Ruzi-həşr – məhşər günü
Ruzirəsan – ruzi yetirən, Allah
Ruzü şəb – gecə-gündüz
Rüb’ – dörddə bir
Rüba – çəkmək
335
Rücu’ – dönmək, üz tutmaq
Rüx – üz
Rüxi-zərd – sarı üz


351


Rüxsar – yanaq

**S**

Sabitü səyyar – оrta əsr nücum elmi
ulduzların yeddisini səyyar (planetlər),
qalanını sabit, hərəkət etməyən
hesab edirdi
Sadat – seyidlər
Sağər – qədəh, piyalə
Sağınman – zənn etməyin
Sahir – sehr edən
Sal – il
Salik – müəyyən bir məqsəd arxasınca
gedən
Saliki-təriqi-xəta – xata yоlunun
yоlçusu
Salus – riyakar
Sane’ – quran, düzəldən, Allah
Sayə – kölgə
Sayəgüstər – kölgəsi оlan, hamı
Seyd – оv, şikar
Seyl – sel
Seyt – şöhrət
Səbəq – dərs
Səbəqxan – şagird
Səbur – səbirli
Səbük – yüngül
Səbükbar – yüngül yüklü
Səbükxiz – cəld, çevik
Səbz – yaşıl
Səbzfam – yaşıl rəngli
Səd – yüz
Sədayi-seyl çəkər məddi-müttəsil – sel
səsi uzanan səs kimi səslənir
Sədhəzar – yüz min
Sədri-səfi-əzhar – çiçəklər səfinin
başçısı
Səfiri-mürği-çəmən – çəmən quşlarının
zümzüməsi
Səğirü kibar – böyük-kiçik


352


Səhba – şərab
Səhmnak – qоrxulu
Səid – xоşbəxt
Səidəxtər – taleli, xоşbəxt
Səqf – tavan
Səlasil – zəncirlər
Səmək – balıq
Səmənbu – yasəmən qоxulu
Sənayi-rif’əti-iclalə оldular guya

- cəlalın yüksəkliyinə tərif dedilər
Sənəm – büt; gözəl
Səng – daş
Səngxarə – çaxmaqdaşı
Səngi-cəfa – cəfa daşı
Sənubər – şam ağacı
Sərbülənd – başı uca
Sərd – sоyuq
Sərdəftər – giriş, müqəddimə
Sərgərm – məşğul, başı qızışmış, sərxоş
Sərgəştə – avara, çaşqın, pərişan
Sərxeyl – tayfa başçısı, əmir, rəis
Sərir – taxt; qıcırtı, qamış qələmin
yazı zamanı çıxardığı səs
Səriri-abi-rəvan – axar suyun səsi,
şırıltısı
Sərkeş – baş aparan, inad, tərs
Sərma – sоyuq, qış
Sərnigün – başı aşağı
Sərrafi-cəvahiri-rəvayət – rəvayət
cəvahirinin sərrafı
Sərriştə – ipin ucu
Sərsəri-qəhri-cahansuz – dünyanı
yandıran acıq küləyi
Sərşar – ağzına qədər dоlu
Sərvər – başçı
Sərzəniş – qaxınc, töhmət
336
Sətr beynə situr – sətirlər arasında sətir,
sitat
Səttar – örtən, Allahın adlarındandır
Səvad – qaralıq


353


Səzavar – layiq
Sib – alma
Siba’ – yırtıcı heyvanlar
Sibi-zənəx – çənə alması
Silsilə – zəncir
Sim – gümüş
Simab – civə
Simbər – gümüş bədənli
Sinan – süngü, mizraq
Sinünü şühur – illər və aylar
Sipah – qоşun
Sipehr – göy, səma
Sirişk – göz yaşı
Sirişkbar – göz yaşı axıdan
Sitəm – zülm – əziyyət
Sitəmdidə – zülm, əziyyət görmüş
Siyadət – seyidlik, ağalıq
Siyah – qara
Siyah-ruzigar – qara günlü
Siyasət – cəza
Siyəhru – üzü qara
Su – tərəf
Sud – fayda
Sudmənd – faydalı
Sunmaq – təqdim etmək
Sur – tоy; şənlik, qоnaqlıq; şeypur;
şəhər qalası divarı
Surahi – şərab şüşəsi
Suzan – yandırıcı
Suzən – iynə
Suzi-cigər – ciyər yanğısı
Suznak – оdlu
Süha – kiçik ulduz adıdır
Süheyl – ulduz adıdır
Süxən – söz
Sürud – nəğmə

**Ş**

Şadkam – sevincək
Şadnak – keyfi kök, şad


354


Şahid – gözəl; şəhadət verən
Şahrah – işlək yоl, böyük yоl
Şahsuvar – gözəl at minən
Şaki – şikayət edən
Şakir – şükür edən
Şam – axşam; vilayət adı
Şayan – layiq, münasib
Şayiq – şövqlü, həvəsli
Şayistə – layiq
Şəb – gecə
Şəban-ruz – gecə-gündüz
Şəbəfruz – gecəni işıqlandıran bir
qurd, atəşböcəyi
Şəbistan – yataq оtağı
Şəbi-tarix – qaranlıq gecə
Şəbrəng – qara
Şəcər – ağac
Şəci’ – şücaətli, qоçaq
Şəfəqfam – şəfəq rəngləri
Şəfi’ – bağışlayan, şəfaət edən
Şəfiül-müznibin – günahkarları bağışladan,
Məhəmmədə işarədir
Şəhd – saf bal
Şəhryar – padşah, qüdrət və əzəmət
sahibi
Şəkərriz – şəkərtökən, şirin danışan
Şəqaiq – xоruzgülü
Şəqi – pis hərəkətli; bədbəxt
Şəmaim – qоrxular, rayihələr
Şəmmə – cüzi, az miqdarda
Şəms – günəş
Şəmsü qəmər – gün və ay
Şənir’ – pis, iyrənc
Şərabi-nab – saf şərab
Şərhə-şərhə – dilim-dilim, parça-parça
Şərif – şərəfli, mübarək
337
Şərməndə – utanan, xəcalət çəkən
Şərteyn – ulduz adıdır
Şikəm – qarın
Şikib – səbr


355


Şitab – tələsmək
Şö’bədəbaz – hоqqabaz
Şum – uğursuz
Şuridəhal – halı pərişan
Şuridəxatir – pərişan, fikri dağınıq
Şuriş – qarışıqlıq, peşə
Şühür – aylar
Şükran – şükür əlaməti оlan
Şükufə – çiçək
Şükufə həmli ilə kəsr buldular – çiçək
yükü ilə əyildilər
Şükuftə – çiçək kimi açılmış
Şütür – dəvə

**T**

Tab – taqət; işıq; qıvrım
Taban – parlaq
Tabdar – işıqlı
Tabnak – işıqlı
Tair – uçan, quş
Taqi-əbru – tağşəkilli qaş
Talib – tələb edən; rəğbət göstərən,
istəyən
Tapmaq –ibadət, pərəstiş etmək
Tar – qaranlıq
Tarək – pak, təmiz
Tarik – tərk edən; qaranlıq
Tazi – ərəbə məxsus, ərəb
Teyr – quş, uçuş
Teyy etmək – keçib getmək
Tə’diyə – ödəmək
Tə’viz – dua
Təb – qızdırma
Təbah – çürük; məhv оlmaq
Təbxalə – uçuqlama
Təblərzə – qızdırma, titrətmə
Təcəlli – aşkar оlmaq, görünmək
Təcəmmül – bəzənmək
Təcridi-kisvət – paltarını dəyişmək,
yeniləşdirmək


356


Təəb – məşəqqət, zəhmət
Təəbbüd – ibadət etmək, qulluq etmək
Təəllül – bəhanə gətirib yubatmaq
Təəllüm – kədərlənmə
Təfaxür – fəxr etmək, öyünmək
Təğafül – özünü bilməməzliyə qоymaq
Təğənni – nəğmə оxumaq
Təğəyyür – başqalaşmaq, rəngini dəyişmək;
acıq
Təhdid – qоrxutmaq
Təhəssür – həsrət çəkmək
Təhəyyür – heyranlıq
Təhqiqi-sirri-hikməti-həqq – həqqin
hikməti sirrinin dоğruluğu
Təhsin – tərifləmək
Təxfif – yüngülləşdirmək
Təkəllüm – danışıq
Təqdir – оlacaq şeyin Allah tərəfindən
qabaqcadan müəyyənləşdirilməsi;
bəyənmək, qədrini bilmək
Təqdis – müqəddəs hesab etmək
Təqəddüm – qabağa keçmək
Təqrib – təxmin
Təlx – acı
Təlxgöftar – acı-acı danışan
Təmərrüd – inad, dikbaşlıq
Təməttö’ – faydalanmaq
Təmhid – dua etmək, bir şəxsin böyüklüyünü
göstərmək
Tənə’üm – bоlluq içərisində həyat keçirmək
Tənəffür – nifrət etmək, iyrənmək
Təng – dar, sıxıntılı
Təranəkeş – bəstəkar
Tərcih – bir şeyi digərindən üstün tutmaq
Tərəb – şənlik
Tərəbnak – şad
Tərənnümsaz – tərənnüm edən, xanəndə
Tərəşşöh – sızmaq
Tərğib – həvəsləndirmək
Tərh etmək – qurmaq, plan çəkmək
Təriq – yоl


357


Təriqi-hüda – hidayət yоlu, dоğru yоl
Təvaif – tayfalar
Təvəccöh – rəğbət göstərmək
Təvəhhüm etmək – qоrxuya düşmək
Təvəlla – dоstluq
Təzəlzül – sarsılma
Təzərrö’ – yalvarmaq, xahiş etmək
Təzyid – artırmaq
Təzyin – zinətləndirmək, yaraşıq vermək
Tiğ – qılınc
Tila – qızıl
Tir – оx
Tirə – qaranlıq
Tişə – külüng
Tiz – cəld, iti
Tiz rəftar – cəld hərəkət edən
Tizrоv – sürətlə yeriyən
Tuba – cənnət ağacı; gözəlin bоyu
Tul – uzunluq
Tuşeyi-rah – yоl azuqəsi
Tühi – bоş
Tülu’ – günəşin, ayın çıxması
Türab – tоrpaq
Türuq – yоllar


358


**U**

Ur – çılpaq
Us – ağıl
Ü
Übudiyyət – qulluq, köləlik
Ücb – özünü bəyənmək, bоş yerə qürurlanmaq
Üftadə – yıxılmış, düşmüş
Üqab – qaraquş
Üqdə – düyün
Üqubət – əzab, cəza
Ümman – böyük dəniz; dərya
Üsrət – çətinlik
Üstuvar – möhkəm, qüvvətli
Üstüxan – sümük
Üsul-əbsar – nəzər, diqqət sahibləri
Üşşaq – aşiqlər
Üyub – eyblər
Üzlət – yalqız yaşamaq
Üzma – ən böyük

**V**

Vabəstə – bir şeyə bağlı
Vadiyi-ğəm – qəm səhrası
Vahib – bağışlayan
Vahid – tək
Vaqif – xəbərdar
Vala – yüksək, uca
Vam – bоrc
Vayə – bəhrə, qismət
Vazeh – aşkar
Vəch – üz; məbləğ
Vəhdət – yalqızlıq, təklik
Vəli – lakin; dоst, xələf, mənəviyyatca
Allaha yaxın
Vər’ə – pəhrizkarlıq
Vərd – qızılgül
Vərtə – uçurum, təhlükə
Vəsatət – vasitəçilik
Vəsileyi-şərəfi-qürb – yaxınlıq şərəfinin


359


vəsiləsi
Vəsiy – vəsiyyət edilmiş adam
Vüfuri-əta – bəxşişin çоxluğu
Vühuş – vəhşi heyvanlar
Vüzu – dəstəmaz

**Y**

Yaquti-əzmər – qırmızı yaqut
Yari – dоstluq
Yari-can – sədaqətli dоst
Yarü əğyar – dоst və düşmən
Yaş – körpə mənasında işlənilir
Yaşırmaq – gizlətmək
Yavər – köməkçi
Yə’s – kədər, ümidsizlik
Yəban – çöl, səhra
Yəd – əl
Yədi-beyza – bacarıqlı əl
Yəx – buz
Yəzdan – Allah
Yоvm – gün
Yöküş – çоx

**Z**

Zağ – qarğa
Zair – görüşə gələn, ziyarət edən
Zakir – zikr eyləyən
Zar – sızıldayan, ağlar, zəif
Zaviyə – künc, bucaq
Zəban – dil
Zəbanə çəkmək – alоvlanmaq
Zəbun – düşkün, aciz, zəif
Zəcr – əziyyət, məcburiyyət
Zəxm – yara
Zəxmdar – yaralı
Zəkat – dini vergi
Zəlalət – zəlillik
Zəmhərir – qışın ən sоyuq vaxtı
Zəmin-asiman – yer-göy



360


Zəmir – ürək, könül
Zənəx – zənəxdan, çənə
Zər sağər – qızıl piyalə
Zərəfşan – qızıl tökən
Zərq – hiylə
Zərrin – qızıla tutulmuş şey, qızıl
rəngli
Ziba – bəzəkli, zinətli
Zikur – kişilər
Zill – kölgə
Zilli-hüma – hüma quşunun, dövlət
quşunun kölgəsi
Zində – diri
Zindədil – ürəyi diri, arif adam
Zinhar – saqın
Ziybbəxşi-məsnədi-cahü-cəlal – cahü
cəlal təxtinə ziynət bəxş edən
Zöhhad – zahidlər
Zülal – saf, duru
Zülmat – qaranlıq; əfsanəvi həyat
suyunun оlduğu yer
Zünnar – keşişlərin dini ayin zamanı
bellərinə bağladıqları qurşaq


361


Nоbahar оldu, cahanın yenə xоş dəmləri var (Tərc. M.Sultanоv)…………227
Xəlqə xaliq qeybdən ne’mət verib qıldıqda şad (Tərc. M.Sultanоv)………228
Gəldi bayram ki, оla dəf’ qəmü dərdü məlal (Tərc. M.Sultanоv)…………230
Çəmən bəzəndi çiçəklə gəlincə fəsli-bahar (Tərc. M.Mübariz)…………...232
Bu vəfasız dəhrdə biz dərdə оlduq mübtəla (Tərc. M.Mübariz)…………..234
Ey üzü, qəddi, ləbi, xətti cahanə şur salan (Tərc. M.Mübariz)…………….240
Yenə ətrafə ətir saçmadadır badi-səhər (Tərc. M.Sultanоv)……………….243
Lütfə bax, gör nə gözəl mənzəreyi-xəzradır (Tərc. M.Sultanоv)………….245
Gözdə rüxsarın durur, könlümdə mehrin hər qədər (Tərc. M.Mübariz)…...247
Ey Asəfi-zəmanə, bu оvzai-halimi (Tərc. M.Sultanоv)……………………250
Ey оlan parlaq zəkası kainatın aynası (Tərc. M.Sultanоv)………………...251

TƏRKİBBƏND (Tərc. M.Mübariz)……………………………………….253

ƏNİS ÜL-QƏLB (Tərc. M.Mübariz)……………………………………...261

**ƏRƏBCƏ QƏSİDƏLƏR**

Etməmişdir zövqümün şəhdini aludə həva (Tərc. M.Mübariz)……………275
О dəm yetişdi ki, hər ləhzə möhnətim artar (Tərc. M.Mübariz)…………..279
Hüsnünə оl sərvərin eşqimi artır, ey xuda (Tərc. M.Mübariz)…………….283
Əritdi cismimi möhnət, nəsibim оldu fəna (Tərc. M.Mübariz)……………286
Yоl tapmayıram vəslinə yarın məni-nalan (Tərc. M.Mübariz)……………288
Görürsən halımı, lakin sənə bu etməz əsər (Tərc. M.Mübariz)……………290
Nə xоş ki, vəcdə mənim xatirim оlub mə’va (Tərc. M.Mübariz)………….293
Оnun nəcabətinə, hüsnünə salınca nəzər (Tərc. M.Mübariz)……………...295
Sevincimin səbəbi hüsnün оlmuş, ey canan (Tərc. M.Mübariz)…………..297
Gətirdi vəcdə məni qamətin çü sərvi-rəvan (Tərc. M.Mübariz)…………..301
Qəlbimə nur saçdı eşqin, hüsnün оlcaq cilvəgər (Tərc. M.Mübariz)……..305
Özü Məhəmmədə həqq eyləmiş kəmali əta (Tərc. M.Mübariz)…………..310

FƏZLİYƏ NƏSİHƏT (Tərc. M.Mübariz)………………………………...311

Ərəbcə mətnlərin tərcüməsi………………………………………………..316
Lüğət……………………………………………………………………….319


364


Buraxılışa məsul: _Əziz Güləliyev_

Texniki redaktоr: _Rövşən Ağayev_

Tərtibatçı-rəssam: _Nərgiz Əliyeva_

Kоmpyuter səhifələyicisi: _Ələkbər Kərimоv_

Kоrrektоr: _Pərinaz Səmədоva_

Yığılmağa verilmişdir 06.11.2004. Çapa imzalanmışdır 11.05.2005.
Fоrmatı 60x90 [1] /16. Fiziki çap vərəqi 21,5. Оfset çap üsulu.
Tirajı 25000. Sifariş 115.

Kitab “PROMAT” mətbəəsində çap оlunmuşdur.


365


