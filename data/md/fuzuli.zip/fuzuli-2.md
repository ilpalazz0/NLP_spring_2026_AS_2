1


**MƏHƏMMƏD FÜZULİ**

# **ƏSƏRLƏRİ**

**ALTI CİLDDƏ**

**II CİLD**

"ŞƏRQ-QƏRB"
BAKI-2005


2


_Bu kitab_ _**"Məhəmmad Füzuli**_ _Əsərləri. Altı cilddə, II cild" (Bakı, "Azərbaycan "_
_naşriyyatı, 1996) nəşri əsasında təkrar nəşrə hazırlanmışdır._

Tərtib edəni: **Həmid Araslı**

Redaktoru: **Teymur Kərimli**

**894.3611 - dc 21**
**AZE**
**Məhəmməd Füzuli. Əsərləri** . Altı cilddə. II cild. Bakı, "Şərq-Qərb", 2005, 336 səh.

Orta əsrlər Azərbaycan dilində yüksələn şerin ən uca zirvəsi Füzuli yaradıcılığıdır. Yalnız
Azərbaycan xalqının deyil, bütün türk xalqlarının ədəbiyyatına Nəvaidən sonra qüvvətli təsir
göstərmiş bu ən böyük sənətkar doğma dilin elə imkalarını kəşf etmişdir ki, ondan sonra
ədəbiyyatımızda fars və ərəb dillərində yazıb-yaratmağa bir ehtiyac qalmamışdır. Azərbaycan şeir
dilinin müdrik, qanadlı və ibrətli poeziya səviyysinə yüksəlməsi üçün tarixi iş görmüş Füzuli ana
dilində yaratdığı əsərləri ilə türkcəni də Şərqdə hakim dil səviyyəsinə qaldırmışdır.
Duyğu dünyasının sonsuz çalarlarını yaşaya-yaşaya onun türk dilindəki bənzərsiz ifadəsini üzə
çıxarmış Füzulinin "Leyli və Məcnun"u - eşq haqqında dastan deyil, eşq məqamına yüksələn,
məcnunlaşan şerin özüdür. Bu mövzu şerimizdə Füzuli ilə başlamayıb, amma Füzuli ilə qurtarıbdı.
Ölməz bəstəkarımız Üzeyir Hacıbəyli 1908-ci ildə yaratdığı ilk Azərbaycan operasını məhz bu
poema üzərində qurmuşdur.
Füzuli əsərlərinin təqdim olunan ikinci cildində Şərqin bu ən səmimi, ən həssas şairinin "Leyli
və Məcnun"undan başqa alleqorik poemalarından "Bəngü Badə". "Söhbət ül-əsmar", eləcə də ana
dilində yazdığı digər əsərləri - müəmmaları, məşhur şikayətnaməsi, məktubları və Ə.Camidən bədii
tərcüməsi -"Hədisi-ərbəin" toplanmışdır.

**ISBN 9952-418-51-2**

©"ŞƏRQ-QƏRB", 2005


3


4


**ÖN SÖZ YERİNƏ**

Füzuli əsərlərinin ikinci cildinə şairin "Leyli və Məcnun" əsəri, alleqorik
poemalarından "Bəngü Badə" və "Söhbət ül-əsmar", ana dilində yazdığı
müəmmalar, məşhur "Şikayətnamə"si, Qazi Əlaəddinə, Əhməd bəyə, Bayəzid
Çələbiyə yazdığı məktublar və Əbdürrəhman Camidən tərcümə etdiyi "Hədisiərbəin" daxil edilmişdir.
Beləliklə, I və II cildlər Füzulinin qəsidələrindən və "Hədiqət üs-süəda"dan
başqa ana dilindəki bütün əsərlərini əhatə edir.
"Leyli və Məcnun" Füzuli yaradıcılığının yüksək zirvəsidir. Şərq xalqları
içərisində çox geniş yayılmış bu mövzunun qədim bir tarixi vardır. Hələ qədim
zamanlardan ərəb şifahi ədəbiyyatında mövcud olaıı bu mövzuda ilk dəfə 1188ci ildə Nizami Gəncəvi epik poema yazmış, sonralar onlarca Şərq şairi bu
mövzuya müraciət etmişlər. "Leyli və Məcnun" türk ədəbiyyatının da sevimli
mövzularından olmuş və hələ XV əsrdən başlayaraq türk dilində bir çox "Leyli
və Məcnun" əsərləri yaranmışdır ki, bunların içərisində geniş şöhrət qazanıb
nadir sənət nümunəsi kimi əbədiləşən Füzuli poeması olmuşdur.
Füzuli özünün həssas sənətkar təbiətinə çox uyğun olan bu mövzunu
sələflərindən fərqli bir şəkildə işləyərək, əsərə bir çox yeni epizodlar və mövzu
ilə bağlı türk xalq ədəbiyyatında yayılan rəvayətlər əlavə etməklə insanın mənəvi
əzəməti, insan gözəlliyinin ülviliyi və məhəbbətin qüdrətini tərənnüm edən
ölməz sənət abidəsi yaratmışdır. Saf, təmiz eşqin mənəvi qələbəsini təsdiq edən
bu əsərində şair bir sıra ictimai məsələlərə də toxunmuş, sevgi azadlığı,
məhəbbət aləmində bərabərlik, insan şəxsiyyətinə hörmət, vəfa, sədaqət,
fədakarlıq, dəyanət kimi gözəl sifətlərdən bəhs etmişdir. Poemada Füzulinin
fəlsəfi-irfani düşüncələrinə də geniş yer verilir. Və həm də bu problemlər burada
da yenə insan qəlbinin bu ali hissilə bağlı şəkildə öz bədii-fikri tutumunu
tapmışdır. Şair eləcə də İnsan və təbiət probleminin həllində bu zəmindən çıxış
edir. Poemada "hünər və kamal əhli" olan zəka sahiblərinin müsibəti, müqəddəs
arzular önünə çıxan maneələrin keçilməzliyinə etiraz da baş mövzu ilə ustalıqla
əlaqələndirilir.
Əsərdə xüsusi diqqəti çəkən problemlərdən biri də orta əsr qadınlarının
hüquqsuzluğuna, kölə vəziyyətinə etiraz və usyandır. Əsərin qadın qəhrəmanı
Leylinin dilindən deyilmiş aşağıdakı sətirlərə diqqət edək:

_Mən gövhərəm, özgələr xiridar,_
_Məndə deyil ixtiyari-bazar._


5


_Dövran ki, məni məzada saldı,_
_Bilmən kim idi satan, kim aldı._
_Olsaydı mənim bir ixtiyarım,_
_Olmaz idi səndən özgə yarım._

Bu sətirlərdə, eləcə də Leylinin şama, pərvanəyə, aya, səbaya, buluda
müraciətlərində şair qüvvətli bədii ümumiləşdirmə ilə qadının mənəvi azadlıq
istəyini ifadə edir.
Zəmanəsinin ictimai dərdlərini mahir sənətkar qələmilə göstərən bu poema
həm ideya baxımından, həm də bədii gözəlliyi ilə klassik Şərq poeziyasının
misilsiz nümunələrindən biri kimi tanınmaqdadır. Son dərəcə maraqlı
kompozisiyası, sadə, zəngin dili ilə seçilən bu əsəri şair lirik ricətlər, baş verən
əhvalatların ruhuyla səsləşən gözəl təbiət təsvirləri ilə daha da zənginləşdirmiş,
hadisələr və qəhrəmanların əhvali-ruhiyyəsinə uyğun ecazkar qəzəl
nümunələriylə zinətləndirmişdir. Bədii sözə zərgər dəqiqliyi ilə yanaşmağı
bacaran ustad sənətkar doğma dilin zəngin ifadə imkanları və klassik poetikanın
qayda-qanunlarından məharətlə bəhrələnmiş, şeirin məna tutumuna təsir edən və
zahiri gözəlliyini artıran bədii vasitələri bir-birilə vəhdətdə işlətmişdir. Poemada
xalq danışıq ifadələri, xalq məsəlləri, sadə el deyimləri, xalq ədəbiyyatının dərin
hikmətini özündə əks etdirən aforizmlər ustalıqla əsas məzmuna bağlanır.
Füzuli hələ gənc yaşlarında yazdığı "Bəngü Badə" əsərində də zəmanəsinin
ictimai dərdlərinə toxunmuş, alleqorik şəkildə da olsa Beng və Badənin
timsalında mülk-torpaq üstündə gedən qanlı çəkişmələrə, şöhrət, ad-san,
mənəmlik üçun aparılan qəsbkarlıq vuruşmalarına qarşı çıxaraq Bəng ilə
Badənin bir-birinə meydan oxuyan hücum və təhdidlərində dövrünün tarixi
hadisələrinə işarə vurmuşdur.
Füzuli zəmanəsində gördüyü ictimai çatışmazlıqlara, baş verən əbəs
çəkişmələrə eləcə də "Söhbət ül-əsmar" əsərində öz münasibətini bildirmiş,
yersiz qürur, mənasız öyünmələrin fayda vermədiyini, bir-birinin eyblərini
söyləməklə öz məziyyətlərini tərifləyən meyvələrin mübahisəsində göstərmişdir.
Meyvələrin xassələri və onların hər birinin insan orqanizminə təsirini gözəl bilən
şairin bu əsəri zahirən uşaqlar üçün yazılmış sadə əsər kimi görünsə də öz
fəlsəfi-nəsihətamiz ruhu ilə diqqəti cəlb edir. Əsərdə ictimai ədalətsizliyə etiraz
edən, dünyanın vəfasızlığından şikayətlənən şair yazır:

_Dünya işinin mədarı yoxdur,_
_Heç kimsəyə etibarı yoxdur._
_Eylər birisini sahibi-tac,_
_Ol birisin eylər ona möhtac._


6


Anadilli Azərbaycan Ədəbiyyati tarixində bədii nəsrin ilk nümunələrini
yaradan Füzulinin Sultan Süleymana yazdığı "Şikayətnamə" adlı bədii
məktubunda zəmanəsinin vaqf ifadələrindəki rüşvətxorluq va süründürməçilik
tənqid olunur. Xalq malı hesab ounan vəqf pullarını məmurlar tərəfindən
mənimsənildiyini, özbaşınalıq və qanunsuzluğu casarətlə aks etdirən bu əsərdə
eyni zamanda istedadlı adamların qiymətləndirilməmisinə ciddi etiraz ifadə
olunmaqdadır. Füzulinin zəmanəsinin ədalətsizliklərini ifadə edən bu əsəri bədii
dəyəri, məntiqi kəskinliyi və şairin məharətlə nümayiş etdirdiyi bədii
umumiləşdirmələri ilə sevilir. Elə ona görədir ki, о indi də öz əhəmiyyətini
itirməmiş, "Salam verdim, rüşvət deyildir deyə almadılar. Hökm gostərdim
faidəsizdir deyə mültəfit olmadılar" - cümlələri həyati mənasını saxlayaraq,
zərbi-məsəl kimi işlənməkdədir.
Füzulinin Qazi Əlaəddinə, Əhməd bəyə və Bəyazid Çələbiyə yazdığı
məktubları da bədii nəsrimizin yaxşı nümunələri kimi adəbiyyat tariximiz üçün
əhamiyyətlidir.
Şairin fars-tacik şairi Əbdürrəhman Caminin "Hədisi-ərbain" əsərinin
tərcüməsi bədii tərcümə tariximizdə özunəmaxsus görkəmli yerlərdən birini
tutur.
Fuzuli müəmmalar da yazmış və Azərbaycan dilində bu janrın diqqətəlayiq
nümunələrini yaratmışdır.
Böyük şairin bu cildə daxil olan əsərləri hələlik ən qədim və mötəbər sayılan
əlyazmaları, daş basmaları və nəşrləri əssasında tərtib edilmişdir.

_**Həmid**_ _**Araslı**_


7


8


9


**RÜBAİLƏR**

I

Ey nəş'əti-hüsni-eşqə tə'sir qılan!
Eşqifə binayi-kövni tə'mir qılan!
Leyli səri-zülfini girehgir qılaü!
Məcnuni-həzin boynuna zəncir qılan!

II

Tutsam tələbi-həqiqətə rahi-məcaz,
Əfsanə bəhanəsilə orz etsəm raz,
Leyli səbəbilə vəsfm etsəm ağaz,
Məcnun dili ilə etsənı izhari-niyaz.

III

Lütf ilə şəbi-ümidimi ruz eylə!
İqbalımı tövfıq ilə fıruz eylə!
Leyli kimi ləfzimi diləfruz eylə!
Məcnun kimi nəzmimi cigərsuz eylə!


10


**BU, HƏZRƏTİ-İZZƏTDƏN HƏMD İLƏ**
**İSTİMDADİ-MƏTALİBDİR**
**və**

**ASARİ-ŞÜKR İLƏ**
**İSTİD'AYİ-SƏTRİ-LAİBDİR**

Əlhəmdü livahibil-məkarim,
Vəş-şükrü lisahibil-mərahim.
Və hüvəl-əzəliyyü fil-bidayət,
Və hüvəl-əbədiyyü fin-nəhayət.
Qəd şaə bi-sünihi-bəyanülı,
Ma əzəmə fil-bəqai-şənüh.
Sübhanəllahi-zəhi Xudavənd,
Bişibhü şərikü mislü manənd.
Məşşateyi-növrusi-aləm,
Gövhərkeşi-silki-nəsli-Adəm.
Sərrafi-cəvahiri-həqaiq,
Kəşşafi-qəvamizü dəqaiq.
Peydakoni-hər nəan ki, başəd,
Ponhankoni-hər oyan ki, başəd.
Memari-binayi-afəriniş,
Sirabkoni-riyazi-biniş [1] .
Ya Rəb, mədədi ki, dərdməndəm,
Aşüftəvü zarü müstəməndəm!
Əz feyzi-hünər xəbər nədarəm,
Cüz bihünəri hünər nədarəm.
Şüğli-əcəbi giriftəəm piş,
Pişü pəsi-u təmam təşviş.
Səngist bərahəm uftadə,
Bəhrist məra həras dadə.
Tövfiqi-toəm əgər nəbaşəd,


1
Tərcüməsi: Əziz və mərhəmətli Allaha şükürlər olsun. O, əzəli və əbədidir. Allahı sənəti ilə
tanımaq mümkün oldu. O nə böyük, nə yüksəkdir! Bənzəri, şəriki, misli və oxşan olmayan Allah pak
və münnəzəhdir. Təzə gəlin kimi gözəl olan bu aləmi bəzəyən, insan nəslini yaradan Odur. Həqiqət
cəvahirinin sərrafı, çətin və anlaşılmazlıqları kəşf edəndir. Yaranış binasnın memarı, dünya
bağçasının suvancısıdır.


11


Vər lütfi-to rahbər nəbaşəd.
Müşkil ki, dərin giriveyi-təng
Lə'li bedərarəm öz dili-səng.
Müşkil ki, murad rox nəmayəd,
Zin bəhr düri bədəstəm ayəd.
An kon ki, diləm füruğ girəd,
Lövhəm rəqəmi-səfa pəzirəd.
Ayineyi-xatirəm şəvəd pak,
Rövşən gərdəd çiraği-idrak.
Qofli-dəri-arizu betabəm,
Hər çiz tələb konəm beyabəm.
Bəxşəd be riyazi-dövlətəm ab,
Əbri-kərəmi-Rəsulü əshab1 [1] .


1
Tərcüməsi: Ey Allah, mənə imdad et ki, dərdliyəm, çaşqınam, zar və məhzunam. Hünər
şöhrətindən xƏbərim, hünərsizlikdən başqa hünərim yoxdur. Qarşıma çox çətin birməşğələ
qoymuşam, onun əvvəli və sonu qorxulu və qarışıqdır. O, yolun üzərinsə düşmüş bir daş və məni
qorxuya salan bir dənizdir. Əgər sənin lütf və uğurun mənə rəhbərlik etmesə, bu dar dərədəki daşın
qəlbindən bir ləlin çıxarılması, bu dənizdən əlimə bir dürrün yetişməsi və məqsədimin gülməsi
çətindir. Ürəyimi işıqlandıran sinamin lövhəsinə saf yazılar nəqş etdilən işləri gör ki, xatirimin aynası
pak, əqlimin çırağı parlaq olsun. Dövlətimin bağçasına Peyğəmbər və onun əshabının nemət
buludları su versin.


12


**BU, ŞÜKUFEYİ-GÜLZARİ-TÖVHİDDİR**
**və**
**NÖVBAVEYİ-BUSTANİ-TƏMCİDDİR**

Ey munisi-əhli-zövq yadın,
Əbvabi-oraəl kilidi adın!
Ey gənci-əta tilismi ismin,
Sən gənci-nihan, cahan tilismin!
Ey cudi vücudi-kövnə vahib,
Zati kimi e'tirafı vacib.
Ey silsileyi-vücudə nazim,
Rəzzaqi-ərazilü əazim.
Ey pərdəkeşi-rümuzi-mübhəm,
Müstəhfi intizami-aləm.
Ey nəqştərazi-səfheyi-xak,
Sahibrəqəmi-xütuti-əflak!
Ey möhtəsibi-cəhati-ərkan,
Kani-gühəri-vücubü imkan!
Ey məbdəi-feyzi-afəriniş,
Səndən rövşən çiraği-biniş!
Ey pərdeyi-masiva niqabın,
Səndən özgə sənin hicabın!
Ey sirri-vücudun əmri-məlum,
Mövcud həmin sən, özgə mədum!
Ey yeddi gülü doquz gülüstan
Feyzi-kərəminlə səbzü xəndan!
Ey varı yox eyləyən, yoxu var,
Yox varlığında zənnü inkar!
Ey şahidi-qeyb pərdədari,
Fikrin güli-mə'rifət bəhari!
Ey aləmə feyzi-cud səndən,
Xəlqə şərəfi-vücud səndən!
Ey cümlə cahan sənə rizacu,
Səndən xali, səninlə məmlu!
Ey şəm'i-əzəl fitiləsuzi!
Bəzmi-əbəd əncümənffiruzi!
Ey şirkü şərikdən münəzzəh,


13


Sirri-əzəlü əbəddən agəh!
Ey bari Xudayi-aləmaray,
Təhsin işinə həmin ola ray!
Əhsəntə, zəhi həkimi-kamil!
Nə şükr ola sün'ünə müqabil?
Fitrət rəqəmin çəkən zamanda,
Həqqa ki, bir əmri-"kün fəkanda";
Höktn etdin ki, nə ola əhval,
Nə vəz' ilə çizgİnə məhü sal.
Dövran nə zamanda ola axir,
Hər dövranda nə oia zahir.
Necə ola fərdi-ııosü-Adəm,
Hər fərdi onun nə edə hər dəm.
Əşyaya çox etmozəm təhəyyür,
Səndəıı yanadır həmin təfəkkür.
Əşya əcəb olmaz olsa zahir,
Çün var sənin kimi məzahir,
Ərama çü sənə qədimdir zat,
İdrak sonə yetərmi, heyhat!
İdrakimizə kəmali-heyrət,
Tövhidinə bəsdürür dəlalet.
Əndişeyi-zat qılmaq olmaz,
Bilmək bu yetər ki, bilmək olmaz.
Ol dəm ki, urub binayi-möhkəm,
Çəkdin rəqəmİ-nizami-alom,
Həqqa ki, xoş intizam verdin,
Arayişini təmam verdin.
Etdin gərəyin gər az, gər çox,
Bir nəsnə gərəkli yox ki, ol yox.
Bir növ ilo eylədin mühəyya
Kim, gəldi qüsurdan mübərra.
Əşyadə əgərçi raz çoxdur,
Ol kim ola razm onda yoxdur.
Əşya necə səndən olsun agah,
Əlqüdrətü vəl-bəqaü lillah. [1]


1
Qüdrət və böyüklük Allaha məxsusdur.


14


1 Nəyim



**BU, MÜNACAT DƏRYASINDAN**
**BİR CÖVHƏRDİR**
**və**
**TƏZƏRRÖ' MƏ'DƏNİNDƏN BİR GÖVHƏRDİR**
Ya Rəb, kərəm et ki, xarü zarəm,
Dərgahə bəsi ümidvarəm.
Torpaq idim, eylədin bir insan,
Müstövcibi-əqlü qabili-can.
Gər can isə xaki-dərgəhindir,
Vər əql isə saliki-rəhindir.
Mən gülşəni-can içində xarəm,
Ayineyİ-əqlə bir qübarəm.
Nəm [1] var ki, laf edəm özümden,
Məhv eylə məııi mənim gözümdən.
Ol gün ki, yox idi məndə qüdrət,
Qıldın mənə qeybətimdə rəğbət.
Can verdinü sahibi-dil etdİn,
İdraki-ümurə qabil etdin.
Gər səfheyi-surətə misalim
Çokməzdi qəza, nolurdu haiim?
Hala ki, həvaləgahi-cudəm,
Məqbuli-səadəti-vücudəın,
Yüz şükr ki, yox sənə xilafım,
İnsafım var, var e'tirafim.
Öylə degiləm ki, bu aradə
Sədd ola sülukim e'tiqadə;
Hər lehzə əqidəm ola zail,
Tövhidinə istəyəm dəlail.
Rahi-tələbində biqərarəm,
Əmma tələbimdə şermsarəm.
Doğru yola getmədim' nə hasil?
Bir mənzilə yetmədini' nə hasil?
Hər ərsədə hər əsər ki, gördüm,
Sənsən deyib ol əsər, yügürdüm;


15


Çün verdi xəyal ona xəmü piç,
Mən münfəil oldum, ol əsər hiç.
Mən əqldən istərəm dəlalət,
Əqlim mənə göstərər zəlalət.
Təhqiq yolunda əql netsin,
Əmavü qərib qanda getsin?
Tövfiq edəsən məgər rəfıqim,
Ta səhl ola şiddəti-təriqim.
Gör hirsimi, istəgincə ver kam,
Səndən iqbalü məndən iqdam.
Elmində əyandır e'tiqadım,
Sənsən, səndən həmin muradım.
Dünya nədirü təəllüqati?
Əndişeyi-mövtdür həyati.
Əmma deməzəm yalandır ol həm,
Sermenzili-imtohandır ol həm.
Billah ki, bu dilfirib mənzil
Öylə mənə verdi rahəti-dil
Kim, əski məqamımı unutdum,
Sandım vətənim, məqam tutdum.
Müşkül gəlir indi tərkin etmək,
Bir özgə məqamə dəxi getmək.
Mən böylə qılırdım e'tibari
Kim, bunda olur könül qərari;
Bundan dəxi yey məqam olmaz,
Zövqü bu yerin təmain olmaz.
Əmma çü sənindürür bu göftar
Kim, dünyadan özgə axirət var;
Oldur ki, məqami-cavidandır,
Kami-dilü rahəti-rəvandır.
Göftanna e'tiqad qıldım,
Ol yaxşıraq olduğunu bildim.
Bildim bu imiş sənin muradın
Kim, əhli-kəmal ola ibadın.
Bunda yetə rütbeyi-kəmalə,
Onda yetə dövlətə-vüsalə.
Fərz oldu bir əzmə cəzm qılmaq


16


Me'raci-kəmalə əzm qılmaq.
Bu rahdən etmək olmaz ikrah,
Xoş rahdurur sənə gedən rah.
Əvvəldə çü lütffin oldu mə'lum,
Axır günü də həm etmə məhrum!
Çün yadi-vüsal edib rəvanım,
Əzmi-rəhi-qürbün edə canım,
Ol ləhzə həm etmə şəfqətin kəm,
Tövfiqinə qıl rəfiq hər dəm!
Çün əql ilə can əmanətindir,
Məndə əsəri-inayətindir,
Bunları mənimlə zar qılma,
Bir neçə əzizi xar qılma!
Ta kim, bu məqamı tərk edəndə,
Səndən yana əzm edib gedəndə,
Məndən cəzə' ilə getməsinlər,
Dərgahə şikayət etməsinlər.
Şum olmasın onlara vüsalim,
Olmasın olardan infialim.


17


1 Yiyəsindən, sahibindən



**BU, VACİBÜL-VÜCUD İSBATINA**
**BÜRHANİ-QATE 'DİR**
**və**
**BƏQAİ-SAİR MÖVCUDATA**
**DƏLİLİ-MANE'DİR**

Etmok gərək əhli-feyzi-biniş,
Təhqiqi-vücudi-afəriniş.
Bilmək gərək onu kim, cəvahir
Nə gənci-nihandan oldu zahir?
Nə dairədir bu dövri-əflak,
Nə zabitədir bu mərkəzi-xak?
Cismə ərəzi kim etdi qaim,
Narə nədən oldu nur lazim?
Hər xilqətə gərçi bir səbəb var,
Aya, səbəbi kim etdi izhar?
Gər kaf ilə nundan oldu aləm,
Aya, nədən oldu kafü nun həm?
Bihudə degil bu karxanə,
Bifaidə gərdişi-zəmanə.
Haşa ki, bu bargahi-ali
Bir dəm iyosindən [1] ola xali.
Haşa ki, bu türfə nəqşi-qərra
Nəqqaşından ola mübərra.
Fikr eylə və gör, nədir bu üslub,
Nə saniedir bu vez'i-mənsub?
Hər zərreyi-zahirin zühuri
Bir özgəyə bağlıdır zəruri.
Gər qayətə eyləsən təəmmül,
Zahir olur onda məzhəri-küll.
Versən özünə fənayi-mütləq,
İsbat olur ol fəna ilə həq.
Gər var isə mə'rifət məzaqi,
Fani sənə bəs dəlili-baqi.
Həqqa ki, həmin vücud birdir,


18


1
Səni tanımadıq



Bir zatə vücud münbəsirdir
Əksidir onun vücudi-əğyar,
Mə'nidə yox, e'tibar ilə var.
Var olani xəlq yox sanırlar,
Yox varhğma aldanırlar.
Yoxdur bu vücudun e'tibari,
Həq ayinədir, cahan qübari.
Ey əq!, ədobə riayət eylə,
Bu bilmək ilə kifayət eylə!
Təhqiqi-sifaiə qane olğıl,
Əndişeyi-zatə mane olğü!
Ol pərdəyə kimsə rah bulmaz,
Təhqiq bil, onu bilmək olmaz.
Gər yetsə idi bu sirrə idrak,
Demozdi Rəsul "maərəfhak” [1]
Xəlq oldu bu bəbri-heyrətə qərq,
Ta xəlqdən ola Xaliqə fərq.
Hər riştə ki, Haqq əyan edibdir,
Sərriştəsini nihan edibdir.
Bir kimsə əgər olaydı agah
Kim, xəlqi necə yaradır Allah,
Mümkün ki, iradətilə ol həm
Xəlq edə biləydi özgə aləm.
Verməz çü kəmali-hikməti-Həq
Təhqiqi-rümuzə rahi mütləq,
Faş oldu ki, sirri-Həq nihandır,
Aləmdə nişanı binişandır.


19


1
Nəyin



**BU, İZHARİ-E'TİRAFİ-CƏHALƏTDİR**
**və**
**İQRARİ-İSRAFİ-MƏ'SİYƏTDİR**

Ey hikmətə baxmayan nəzərsiz,
Əhvali-zəmanədən xəbərsiz!
Tə'n etmə ki, çərx bivəfadır,
Daim işi cövr ilə cəfadır.
Şərh eylə mənə ki, çərx netdi?
Ondan nə cofa zühura yetdi?
Nən [1] var idi kim, əlindən aldı,
Nə mərtəbədən aşağı saldı?
Dövrana gətirdi mehrü mahi,
Axıtdı səfidivü siyahi.
Gəh atəşə zəcri-ab verdi,
Gəh badə qəmi-türab verdi.
Şəm'i-əməlin münəvvər etdi,
Hər nə dilədin müyəssər etdi.
Qıldı səni hiçdən bir adəm,
Əsbabi-tənə'ümün fərahəm.
Çərxin xud işi səninlə böylə;
Sən neylədin onun İlə, söylə?
Hər dəm onu bivəfa oxursan,
"Dunsan" - deyə bəddua oxursan.
Çün ol sənə qıldı mehribanlıq,
Yaxşılığa eyləmə yamanlıq!
Ey ruh ki, cami-cəhl edib nuş,
Hübbi-vətən eylədin fəramuş,
Kim saldı səni bu təng rahə,
Qandan düşdün bu damgahə?
Sən tərk qılıb ədəm diyarin,
Bulduqda vücud e'tibarin,
Qılmışdı səninlə hikmətüllah,
Əcnasi-həvasü əqli həmrah.
Ta aləmə gəldigin zamanda


20


1
Ki ayineyi



Bazari-tərəddüdi-cahanda
Sərmayələrindon edəsən sud,
Ol sud nədir? - Rizayi-Mə'bud.
Hala ki, xəsarət oldu vaqe,
Sərmayələrin təmam zaye.
Heyranü mükəddərü tühidəst,
Əhvalı xərabü rütbəsi pəst.
Dönsən yenə gəldigİn raəqamə,
Qabilmi düşərsən ehtiramə?
Əlbəttə, zəlilü xar olursan,
Bu fel ilə şərmsar olursan.
Ey nəfspərəstü cismpərvər,
Olma qəmi-hirs ilə mükəddər!
Cəhd eylə, əzabi-gur yığma!
Sə'y eylə, mətayi-mur yığma!
Alma ələ sağəri-meyi-nab
Kim, qərqə edər səni bu girdab!
Olma nigərani-səbzeyi-bəng,
K'ayineyi [1] -dininə salır jəng!
Dəf kimi köküsdə ləhv qoyma!
Ney kirni həvayi-nəfsə uyma!
Damani-təriqi-şər'i tutğıl!
Hər nə ki, xilafi-şər' unutğıl!
Təhqiqi-vəsüeyi-vüsul et!
Təqlidi-şəriəti-Rəsül et!


21


**BU, SƏRDƏFTƏRİ-ƏNBİYANIN**
**KİTABİ ÖVSAFINDAN BİR VƏRƏQDİR**
**və**
**SƏRVƏRİ-ƏSFİYANIN**
**GÜLZARİ-LƏTAFƏTİNDƏN BİR TƏBƏQDİR**

Ey padşəhi-səriri-lövlak,
Məqsudi-vücudi-xakü əflak!
Olmuş əflak xaki-rahin,
Çəkmiş əflakə xak cahin.
Ey raqimi-nüsxeyi-məani,
Mə'mureyi-elmi-dinə bani!
Şahənşəhi-məsnədi-risalət,
Rəssami-qəvaidi-ədalət!
Ey ərşnəvazü fərşpərvər,
Dəftərdari-hesabi-məhşər!
Sərdəftəri-ənbiyayi-mürsei,
Onlara hənı axirü həm əvvəl!
Ey vazei-istilahi-iman,
Həqdən səbəbi-nüzuli-fürqan!
Sənsən sultanü qeyr xeylin,
Səndən özgə sənin tüfeyün.
Ey xəlvəti-qürbə şəm'i-məhfü,
Cibril tərəddüdünə mənzil!
Həqq əmri səninlə xəlqə cari,
Qövlünlə ol əmrin e'tibari.
Ey qiblənümayi-əhli-taət,
Gəncineyi-gövhəri-şəfaət,
Taci-səri-ərş xaki-payin,
Şəmi-şəbi-qədr nuri-rayin.
Ey vasiteyi-nizami-aləm,
Ə'yani-vücuda sədri-ə'zəm.
İrfani-sifatü zatə arif,
Keyfiyyəti-kainatə vaqif!
Ey zatın üçün bəşər vücudi
Adəmdə sənə mələk sücudi! "
Yasin" sədəfi-düri-sifatın,


22


"Taha" güli-bustani-zatın.
Ey məktəbi-danişə müəllim,
Məhruseyi-hökmi-şər'ə hakim!
Dərgahinə ənbiya rücui,
Tə'ziminə asiman rükui.
Təhsin sənə, ey xücəstəfərcam
Kim, və'z qılıb təriqi-islam,
Keyfiyyəti-halı rövşən etdin,
Xeyrü şər işin müəyyən etdin.
Əhvali-əvamİrü nəvahi,
Mə'lum elədin bizə kəmahi.
Sən bildirdin ki, kimdir Allah,
Sənsiz kim olurdu ondan agah?
Gümrahları təriqə saldın,
Üftadələrin əlini aldın.
Faş oldu nəsihətin cəhanə,
Sən qoymadın ortada bəhanə.
Əmma bizə yoxdur ol səadət
Kim, hifzi-təriqin ola adət.
Ehmal edəriz itaətində,
Təqsir ədayi-xidmətində.
Hər necə kif xud şərmsarız,
Bu cürm ilə həm ümidvarız
Kim, feyzi-əvatifi-əmimin
Şad eyləyə könlün əhli-bimin.
Asilərin olasan pənahi,
Nomidlərin ümidgahi.
Sənsən çü şəfıi-hər məasi,
Nə qəm əgər olsa kimsə asi.
Gər məndə ola təmam taət,
İzhar nədən bular şəfaət?
Sənsən bu sərir padşahi,
Bu mülkdə olanın pənahi.
Hər əsrdə bir nəbi zühuri,
Hər dövrdə bir rəsul nuri
Fitrət yolunu müzəyyən etdi,
Üzün şəmi ilə rövşən etdi.


23


Ta gəlməgə rövşən ola rahin,
Budur rəhü rəsmi padşahin.
Xabi-ədəm içrə şəxsi-aləm
Görmüşdü vücuddən müqəddəm
Kim, ləm'eyi-nurdən bir əfsər
Geymiş, vermiş özünə ziyvər.
Bidar olanda ol yuxudən
Getmişdi qərari arizudən.
Çün istədi ol məııamə tə'bir,
Səndən ona müjdə verdi təqdir.
Dünyayə pəyami-feyzi-nurin,
Tənbihi-səadəti-zühurin
Xəlqə verib intizari-məqdəm,
Ol dəm gəldi ki, gəldi Adəm.
Dünya tələbində oldu qaim,
Dövr ilə səni dilərdi daim.
Bir-bir yetib özgə ənbiyayə,
Me'racə çıxardı payə-payə.
Gəzməzdi səninlə sayə həmrah,
Guya ki, nihali-qəddin, ey mah,
Bu aləmə vermiş idi vayə,
Ol aləmə salmış idi sayə.


24


**BU, ŞƏBİ-ME'RAC BƏYANİDİR**
**və**
**TÜLUİ-AFİTABİ-ASİMANİDİR**

Çün feyzi-vücudin ilə, ey pak,
Rəşki-fələk oldu ərseyi-xak,
Didarını görməgi mələklər,
Pabusuna yetməgi fələklər
Çox eyləyib iztirab peyda,
Allahdan etdilər təmənna.
Bir yaxşı zaman, şərəfli saət
Rəf oldu dualara icabət.
Cibril yetib, yetirdi fərman:
-Key sərvi-riyazi-elmü irfan!
Xurşidini ərşə sayə qılğıl,
Me'raci büləndpayə qılğıl!
Ey qədri bülənd padişəh, dur!
Lütf et, şəbi-qədr qədrin artur!
Rəf eylə hicabi-masəvani,
Seyr eylə məkani-laməkani!
Müştaqi-cəmaldır mələklər,
Möhtaci-vüsaldır fələklər.
Eyvani-sipehrdə sitarə
Min-min göz açıbdır intizarə.
Xoş ol ki, minib Büraqi xoşhal,
Buldun dərəcati-izzü iqbal.
Basdın ayağın bıs çar tağe,
Çıxdın dərəcati-nöhrəvağə.
Nə'leyninə sürtdü üz mehi-növ,
Xurşid rüxündən aldı pərtöv.
Göstərdi Ütarid ehtiramın,
Xətt verdi ki, mən sənin qulamın.
Nahidin edib füzun nişatın,
Bəzmi-tərəb eylədin büsatın.
İqbalın olub qərini-xurşid,
Ögrətdi Məsihə resmi-təcrid.


25


Tiğində bulub nizam əyyam,
Tə'limi-şücaət aldı Bəhram.
Bərcisə müsaid oldu iqbal,
Feyzi-qədəmindən oldu xoşhal.
Keyvan şəbi-qədrin eylədin ruz,
Oldun ona şəm'i-məclisəfruz.
Rə'yət səfi-sabitata çəkdin,
Ol məzəər mehr toxmun əkdin.
Qıldın fələk etləsini rəngin,
Ol məhfilə verdin özgə ayin.
Lövhü qələmi müzəyyən etdin,
Kürsü ilə ərşi rövşən etdin.
Cibrili qoyub, Büraqi saldın,
Tövhid yolunda fərd qaldın.
Rəf oldu sənə hicabi-mabeyn,
Nüzhətgəhin oldu qabə-qövseyn.
Getdin o yerə ki, getmək olmaz,
Yetdin o yerə ki, yetmək olmaz.
Bizdən Həqə ərzlər yetirdin,
Həqdən bizə müjdələr gətirdin.
Lütf etdi sənə inayəti-Həq,
Tövfiq nifazü əmri-mütləq;
Həm məxzəni-mə'rifət kilidi,
Həm ne'mətü mərhəmət ümidi.
Dəryadə olub qəni gühərdən,
Zövq ilə dönəndə ol səfərdən,
Gərm idi hənuz xabgahin,
Cünbüşdə qübari-xaki-rahin.
İnsaf həmin ola siyahət,
Böylə səfər ilə istirahət.
Oldu sənə feyz bunca hasil,
Ol vaqiədən zəmanə qafil.
Qafilləri eylədin xəbərdar,
Əsrari-nihani etdin izhar.
Açdın dəri-ütifatü ən'am
Verdin gərəyincə har kəsə kam.


26


1 Ki alayişi



Çün şəfqəti-amin oldu məqsum,
Lütf eylə, meni həm etmə məhrum.
Biçarə Füzuliyəm ki, zarəm,
Zilli-günəh ilə şərmsarəm.
Tədbirdə süstəmü səbükray,
Sən bir mədəd etməsən mənə, vay!
Ey məş'əleyi-təriqi-tarik,
Vey rahnümayi-rahi-barik!
Ehsanını hadiyi-təriq et,
Bir feyzi-nəzər mənə rəfiq et,
K'alayişi [1] -ixtilafdan pak,
Peyrəvliyin eyləyim tərəbnak.
Gülzari-vücudum edə sirab,
Barani-riyazi-alü əshab!

**QƏSİDƏ**

Ya mənbəül-məkarimi və ya mə'dənül-vəfa,
Ya məcməül-məhasini və ya mənbəül-əta.

Əntəl-ləzi büistə ileyna mübəşşirən,
Vəxtarəkəl-ilahə ənil xəlqi vəstəfa.

İt'əl-ləzi təfəzzələhül-qürbə vəl qəbul,
Vəntəl-ləzi təfərrədəhül-izzü vəl-üla.

Mən irtica bilütfikə maxabə vəntəfi,
Mən iqtəda bişər'ikə mazaə vəhtəda.

Ya övnə mən təfəqqədəhü ində şiddətin,
Ya kəhfə mən təbəssənə fizzəri vənnəca.

İsa nəmirəsəd be to dər qədrü mənzələt,
Bər çərx əgər nəhəd ze səri-iqtidar pa.


27


Me'rac yafti to vü bər Tur şod Kəlim,
Fərq əz to ta Kəlim ze ərşəstü ta səma.

Abi-to bud k'atəşi-Nərarudra nişand,
Ruzi ke, kərde bud dər atəşi-Xəlil ca.

İqrari-kaforist ze şər'i-to inhiraf,
Bürhani-gümrəhist beqeyri-to iqtida.

Ta münqətə' nə gərdəd əz asibi-ixtilaf,
Şod bəste bər to silsileyi-silki-ənbiya.

Ba ənbiyast nesbəti-zati-to çun əlif,
Həm ibtida toi be həqiqət, həm intiha.

Təqdir coz rizayi-to kari nəmikonəd,
Peyvəste taəti-to əda mikonəd qəza. [1]

Ey afitabi-zatinə hər zərrə bir nəbi,
Min şər' din diyarinə hər zərrədən ziya.

Sən qayəti-vücudsənü özgələr tüfeyl,
Sən padişahi-mülksənü özgələr gəda.

Carubi-gərdi-rəhgüzərin bali-Cəbrəil,
Taqi-rəvaqü dərgəhin eyvani-kibriya.


1 Tərcüməsi: Ey kərəmlər manbəyi, ey vəfa mədəni. Ey gözəllər məcməyi, ey səxavət mənbəyi!
Sən o adamsan ki, bizə müjdə verməyə göndərildin və Allah səni bəyəndi, xalqdan səni fərqləndirdi.
Sən elə gəldin ki, yaxınlığa və qəbula üstün oldun. Sən clə gəldin ki, əzizlikdə və yüksəklikdə təksən.
Kim lütfünə sığınsa zərər çəkməz, mənfəət tapar, kim şəriətinə uysa azmaz, doğru yol tapar.
Ey böyük çəlinliklərdə köməkçi. Ey qurtuluş və zərurət zamanı mağarası qalaya dönən! İsa
fələyə ayaq bassa da qədr-qiymətdə sənə çata bilməz. Sən məraca getdin, Kəlim (Musa) Tura, səninla
Kəlimin fərqi yerlə göy qədərdir. Xəlil odda olan zaman sənin suyun Nomrudun odunu söndürdü.
Sənin şəriətindən dönmək kafirlikdir, səndən başqasına uymaq azğınlıq əlamətidir.
İxtilaf bəlasından üzülməmək üçün peyğəmbərlər silsiləsi sənə bağlandı. Ənbiyalarla sənin
nisbətin əlif kimidir, əvvəli də sənsən, axırı da. Təqdir sənin razılığından başqa bir iş görmür. Qəza
həmişə sənin itaətini yerinə yetirir.


28


Darüşşəfayi-haşrdə bimari-mə'siyət
Şəhdi-şəfaətindən umar şərbəti-şəfa.

Ey çaryari-kamilin ə'yani-nıülki-din,
Ərbabi-sidqü mə'dələtü rifətü həya.

Dövrün bu dörd fəsl ilə bir mö'tədil zaman,
Şer'in bu dörd rükn ilə bir mö'təbər bina.

Ya Mustəfa, Füzuliyi-möhtacə rəhm edüb,
İzhari-iltifat ilə qıl hacətin rəva.


29


1 Sanmayın



**BU, ƏRZİ-ƏDƏMİ-QÜDRƏTDİR**
**və**
**ÜZRİ-FİQDİ-QÜVVƏTDİR**

Arayişi-söhbət eylə, saqi!
Ver badə, mürüvvət eylə, saqi!
Bir cam ilə qıl dimağımı tər,
Lütf eylə, bir iltifat göstər!
Qəm mərhələsində qalmışam fərd,
Nə yar, nə həmnişin, nə həmdərd.
Həmcinslərim təmam getmiş.
Söz mülkündən nizam getmiş,
Bu bəzmdə sən qalıbsənü mən,
Bu bəzmi gəl edəlim müzəyyən!
Sən ver badə, mən eyləyim nuş,
Mən nəzm oxuyum, sən ona tut guş!
Bir dövrdəyəm ki, nəzm olub xar,
Əş'ar bulub kəsadi-os'ar.
Ol rütbədə qədri-nəzmdir dun
Kim, küfr oxunur kəlami-mövzun.
Bir mülkdəyəm ki, gər udub qan,
Məzmuni-ibarətə çəkib can,
Min riştəyə türfə lə'l çəksəm,
Min rövzəyə nazənin gül əksəm,
Qılmaz ona hiç kim nəzarə,
Derlər gülə xar, lə'lə xarə.
Ancaq deməzəm ki, xaki-Bağdad
Alayişi-nəzmdəndir azad.
Yoxdur bir mülk bu zamanda
Kim, nəzm rəvacı ola onda:
Nə Hind, nə Fars, nə Xorasan,
Nə Rumü Əcərn, nə Şamü Şirvan.
Olsaydı birində bir süxənsənc,
Əlbəttə, əyan olurdu ol gənc.
Gəncineyi-nəzm gizli qalmaz,
Sanmın [1] günəş olsa, nur salmaz.


30


Kanı necə kim nihan tutar daş,
Eylər onu lə'l aləmə faş.
Hala məgər iqtizayi-dövran
Oldur ki, ola o gənc pünhan.
Dövran ilə mən nəqiz seyrəm,
Dövr əhlindən məgər ki, qeyrəm.
Dövran istər ki, xar ola nəzm,
Biizzətü e'tibar ola nəzm,
Mən müntəzirəm verəm rəvacın,
Bimar isə, eyləyəm əlacın.
Ol nəfyi-kemali-hikmət eylər,
Lazım bilirəm xəsarət eylər.
Tə'miri-xərabə qalibəm mən,
İnşəallah ki, qalibəm mən.

**SAQİNAMƏ**

Saqi, mədəd et ki, dərdməndəm!
Qəm silsilesinə paybəndəm.
Qem dəf inə cami-mey dəvadır,
Tədbİri-qəm eyləmək rəvadır.
Səndən nə inayət olsa vaqe,
Fikr etmə ki, məndə ola zaye.
Mən bir sədəfəm, sən əbri-niysan,
Ver qətrəvü al dürri-qəltan.
Sənsən xurşidü mən siyəh xak,
Ver atəşü al cəvahiri-pak.
Rəhm et ki, qəribü xaksarəm,
Bimunisü yarü qəmküsarəm.
Ol bir neçə həmdəmi-müvafiq,
Yə'ni şüərayi-dövri-sabiq
Tədrİc ilə gəldilər cəhanə,
Tə'zim ilə oldular rəvanə.
Dövran oları müəzzəm etdi,
Hər dövr birin mükərrəm etdi.
Hər birinə hami oldu bir şah,


31


Zövqi-süxənindən oldu agah.
Türkü ərəbü əcəmdə əyyam
Hər şairə vermiş idi bir kam.
Şad etmiş idi Əbunüvası
Haruni-xəlifənin ətası.
Bulmuşdu səfayi-dil Nizami,
Şirvanşəhə düşüb girami.
Olmuşdu Nəvaiyi-süxəndan
Mənzuri-şəhənşəhi-Xorasan.
Söz gövhərinə nəzər salanlar,
Gəncinə verib gühər alanlar
Çün qalmadı, qalmadı fəsahət,
Ərbabi-fəsahət içrə rahət.
Ol taifə çəkdi xirqəye baş,
Halətlərin etməz oldular faş.
Ta olmaya rəsmi-şe'r məfqud,
Əbvabi-fünuni-nəzm məsdud,
Lazım mənə oldu hifzi-qanun,
Zəbti-nəsəqi-kəlami-mövzun.
Naçar tutub təriqi-namus,
Rahətdən olub müdam mə'yus,
Əhdi sözə üstüvar qıldıra,
Əş'ar demək şüar qıldım.
Çün xəlqə xilafi-müddəayəm,
Onlar zə'mincə süst rayəm.
Hər söz ki, gəlir zühurə məndən,
Min tə'nə bulur hər əncüməndən.
Eylər həsəd əhli bağlayıb kin,
Təhsin əvəzinə nefyü nifrin.
Ümmid ki, rəf olub küdurət,
Təğyirpəzir ola bu surət.
Ol qövm bu gülşənə girəndə,
Bu gülşən içində gül dərəndə,
Gül tazə idivü səbzə növxiz,
Təprəndikcə nəsimi-gülriz,
Onlar gülü dərdilər, məni-zar


32


Hala dilərəm dərəm xəsü xar.
Bu bəzmə olar verəndə təzyin,
Mey saf idi, bəzm həm növayin.
Mey safi olara oldu ruzi,
Qaldı mənə daği-dürd suzi.
Bu dürdə mən olmuşam həvaxah,
Bir nəş'ə verərmi, bilməzəm, ah!


33


**BU, SAQİYİ-BƏZMƏ BADƏ ÜÇÜN**
**XİTABDIR**

Saqi, kərəm eylə, cam gəzdir!
Durma, qədəhi müdam gəzdir!
Dövranə çox e'tibar qılma,
Gəzdir qədəhi, qərar qılma!
Tök alıb ələ gümüş sürahi,
Zər sağərə ruhbəxş rahi.
Sərf eylə riayətimdə əltaf,
Tənhalığımı gör, eylə insaf!
Şüğlüm bu büsat içində çoxdur,
Səndən özgə, mədədçi yoxdur.
Həmdəmligim ilə ar qılma!
Məndən nifrət şüar qılma!
Gər bilməz isən ki, mən nə zatəm,
Nə zülməti-çeşmeyi-həyatəm,
Feyzi-hünərim şərabdan sor,
Suzi-cigərim kəbabdən sor.
Tutsan əlini məni-fəqirin,
Həqq ola həmişə dəstgirin.
Mən şairi-Musiyi kəlamənı,
Sahirlərə mö'cüzi-təmaməm.
Mən sahiri-Babili nəjadəm,
Harutə bu işdə ustadəm.
Söz dərkinə sərf edib fərasət,
Əmlakına bulmuşam rəyasət.
Gəh tərzi-qəsidə eylərəm saz,
Şəhbazını olur büləndpərvaz.
Gəh də'bi-qəzəl olur şüarım,
Ol də'bə rəvan verər qərarım.
Gəh məsnəviyə olub həvəsnak,
Ol bəhrdə istərəm düri-pak.
Hər dildə ki, var, əhli-razəm,
Məcmui-fünunə eşqbazəm.
Bir kargərəm həzarpişə,
Canlar çəkib istərəm həmişə
Dükkanım ola rəvaci-bazar,
Hər istədigin bula xiridar.


34


**BU, BİR TƏRİQ İLƏ KƏSRİ-NƏFSDİR**
**VƏ**
**MÜQƏDDİMEYİ-MƏDHİ-PADİŞAHİ-ƏSRDİR**

Saqi, nə idi bu cami-gülgun
Kim, eylədi halımı digərgun?
Sərməst olubam, sözüm həbadır,
Hər lafki, eylərəm - xətadır.
Tə'siri salıb dimağə təşvir,
Təşviri məcazım etdi təğyir.
Mən qandanü lafı-hüsni-göftar
Kim, söz deməyə olan səzavar?
Olsaydı mənim sözümdə bir hal,
Əlbəttə, olurdum əhli-iqbal.
Müstövcibi-izzü cah olurdum,
Şayəsteyi-bargah olurdum.
Məqbul düşərdim asitanə,
Mənzuri- şəhənşəhi-zəmanə.
Ol padişəhi-büləndbiniş
Kim, xaki-rəhidir afəriniş,
Müstəhfizi-din, pənahi-islam,
Məxdumi-zəman, məlazi-əyyam.
Əbr istehsanü bərq kinə,
Şahənşəhi-Məkkevü Mədinə.
Müstəlzəmi-həq, müxilli-batil,
Sultani-muradboxşi-adil,
Ərbabi-hünər ümidgahi,
Türkü ərəbü əcəm pənahi.
Dərya kimi eyləyən dəmadəm
Əndişeyi-qürbü bö'di-aləm.
Lutfilə verən yaxına lö' lu,
Əbrilə iraqə göndərən su,
Lö'lösini eyləyən cahantab,
Ləbtəşnələri dür ilə sirab.
Gərdun kimi lütf edəndə zahir,
Damən-damən tökən cəvahir.
Gün kimi olanda cudo məzhər,


35


Xərmən-xərmən nisar edən zər,
Tuğraymisai-Ali-Osman,
Sultani-sipəhşikən Süleyman!
Yerdə düşər olsa feyzi xakə,
Tə'n eyləyə xak ruhi-pakə.
Göydə nəzər etsə gər hümayə,
Xurşid salır hümayə sayə.
Gər şərqə ura sinani-sərkəş,
Gün kimi çıxar sipehro atəş.
Gər qərbə çalarsa tiği-bürran,
Gərdunə yetər şəfəq kimi qan.
Dün çərx yana nigah qıldım,
Nəzzareyi-İövhi-mah qıldım,
Gördüm bu xəti ki, xameyi-xur
Ol lövhdə eyləmişdi məstur:
Ya Rəb ki, müzəffər ola daim
Zatilə binayi-ədl qaim.
Şayəstə ona sərirü əfsər,
Aləmlərə ədli sayəgüstər.

**BU QƏSİDƏ**
**PADİŞAHİ-İSLAM ŞƏ'NİNDƏDİR**

Zəhi-kamil ki, əqli-nüktədan dərkində heyrandır,
Vücudi-bimisali intixabi-növ'i-insandır.

Fələk bir dürc, onun zati-şərifi gövhəri-yekta,
Cahan bir cism, onun hökmi-rəvani, filməsəl, candır.

Əsasi-hökmidir, mə'nidə bir səddi-Sekəndər kim,
Onun Yə'cucdur bir yanivü bir yani insandır.

Binayi-qədrdir mə'nidə ol ali imarət kim,
Müqəməs taği-gərdun ol imarətdən bir eyvandır.

Müzəffər daima Sultan Süleyman xani-adildir
Ki, hər kim tabeyi-fərmanı olmaz - namüsəlmandır.


36


Cahangiri ki, güntək mülk təsxirinə əzm etsə,
Mühəqqər cilvəgahi ərseyi-İranü Turandır.

Səxi təb'i, mürüvvət pişeyi kim, bəhri-əltafı
Təməvvüc qılsa mövcü fəqr bünyadinə tufandır.

Kəminə kimsəyə kəmtər ətasi hasili-dərya,
Mühəqqər məclisə bəzli-həqiri bəhreyi-kandır.

Vücudi-pak ilə Həq rəhmətidir aləmə nazil,
İtaot əhlinə göstərdiyi ədl ilə ehsandır.

Süleyman bargahidir yəqin heybətli dərgahi
Kim, onda divlər tabe, pərilər bəndəfərmandır.

Müəzzəm ləşkəridir bir bulud kim, düşmənə ondan
Firəngilər sədası rə'd, toplar daşı barandır.

Səməndi səgridəndə lame' olmuş əxtəri-Saqib,
Sipahi təprənəndə mövcə gəlmiş bəhri-Ümmandır.

Səfərdə çəkmək üçün həşmətü iqbal osbabın,
Ərabə ərş lövhi, ordusu gərduni-gərdandır.

Zəmanində yetib cəm'iyyəti-əsbabə ariflər,
Olub dərhənı həmin məhbublar zülft pərişandır.

Xəlayiq sübhtək xəndan olub mehri-cəmalindən,
Dili-suzan ilə dövründə ancaq şəm' giryandır.

Həvadisdən məcazi-mülk tə'mirinə imkan yox
Kəmali-ədl ilə ta mülkə Osman oğlu sultandır.

Bihəmdüllah, bu gün xövfü xətadan şər' namusun
Bulub tövfiqi-nüsrət saxlayan Sultan Süleymandır.

Nişani-feyzdir ol nüsrətü iqbal kim, hala
Nə yan kim, əzm qılsa rəhbəri tə'yidi-Yəzdandır.


37


Dilü candan Füzuli əzmi-iqbalinə ol şahın,
Rizayi-Həqq üçün daim duaguyi-sənaxandır.

Çü oldur hamiyi-islam, vacibdir onun mədhi,
Nə kim, mədhindən özgə söz demiş, ondan peşimandır.

İlahi, baqi olsun daim insanpərvər iqbali
Cahani-fani içrə ta bəqayi-növ'i-insandır.


38


**BU, SƏBƏBİ-NƏZMİ-KİTABDIR**
**və**
**BAİSİ-İRTİKABİ-ƏZABDIR**

Saqi, tut əlim ki, xəstəhaləm!
Qəm rəhgüzərində payimaləm.
Sənsən məni-mübtəlaya qəmxar,
Səndən özgə dəxi kimim var?
Müşkül işə düşmüşəm, mədəd qıl,
Mey hirzi ilə bəlamı rəd qıl!
Həll eyləyə gör bu müşkülatı,
Kəm etmə qulundan iltifatı!
Bir gün ki, meyi-Süheyltə'sir
Vermişdi mizaci-pakə təğyir,
Həmrəngi-bəhar olub xəzanım,
Dönmüşdü əqiqə zə'fəranım.
Cəm idi yanımda ittifaqi:
Sazü məzəvü şərabü saqi.
Peyvəstə ləbaləbü peyapey,
Nuş eylər idim qədəh-qədəh mey.
Zövq üzrə mey artınrdı zövqüm,
Şövq üzrə ziyad olurdu şövqüm.
Ol bəzm idi afiyət bəharı,
Mən bülbüli-zarü biqəran.
Bir həddə irişdi nəş'eyi-cam
Kim, qalmadı əhli-bəzmə aram.
Əsrari-dil oldu aşikara,
Məsdud oluban dəmi-müdara.
Olmuşdu rəfiqü həmzəbanım,
Ayineyi-tutiyi-rəvanım
Bir neçə zərifi-xütteyi-Rum,
Rumi ki, dedin, qəziyyə mə'lum.
Yə'ni ki, qamu həqaiq əhli,
Hər məs'ələdə həqaiq əhli,
Həm elm fənində nüktədanlar,
Həm söz rəvişində dürfəşanlar.


39


Kim eylər idi həqaiqi-raz,
Şeyxidənü Əhmədidən ağaz.
Kim söylər idi ögüb kelami,
Övsafı-Cəliliyü Nizami.
Bilmişlər idi ki, hüsni-göftar
Qədrim qədərincə məndə həm var.
Çün var idi məstlikdə lafım,
Ta anlana sidqimü xilafıra,
Mən xəstəyi etdilər nişanə
Bir rəng ilə tiri-imtəhanə.
"Lütf eyle! - dedilər, - ey süxənsənc!
Faş eylə cəhanə bir nihan gənc!
Leyli-Məcnun əcəmdə çoxdur,
Ətrakdə ol fəsanə yoxdur.
Təqrirə gətir bu dastanı,
Qıl tazə bu əski bustam".
Bİldim, bu qəziyyə imtəhandır,
Zira ki, bu bir bəlayi-candır.
Sevdası dirazü bəhri kutah,
Məzmunu fəğanü naləvü ah.
Bir bəzmi-müsibəti-bəladır
Kim, əvvəli qəm, sonu fənadır.
Nə badəsinə nişatdən rəng,
Nə nəğməsinə fərəhdən ahəng.
İdrakı verər xəyalə azar,
Əfkan edər məlalı əfgar,
Olsaydı təvəccöhü münasib,
Tövcihinə çox olurdu rağib.
Olsaydı təsərrüfündə rahət,
Çox kamil ona qılırdı rəğbət.
Billah ki, nə xoş demiş Nizami,
Bu babdə xətm edib kəlami:
"Əsbabi-soxən nişatü nazəst,
Zin hər do soxən bəhanəsazəst.
Meydani-soxən fərax bayəd,
Ta təb' səvareyi nomayəd.


40


Dər gərmiyi-rigü səxtiyi-kuh
Ta çənd soxən rəvəd beənbuh?" [1]
Bir iş ki, qılır şikayət ustad,
Şagirdə olur rücui bidad.
Gərçi bilirəm, bu bir sitəmdir,
Təklifi bunun qəm üzrə qəmdir.
Əmma necə etmək olur ikrah?
Bir vaqeədir ki, düşdü nagah.
Yeydir yenə üzrdən şüruim,
Bu işdə təvəkkülə rücuim.
Ey təb'i-lətifü əqli-vala!
İdraki-büləndü nitqi-guya!
Düşdü səfərim diyari-dərdə,
Kimdir mənə yar bu səfərdə?
Hər kimdə ki, vardir istitaət,
Dərdü qəmü möhnətü qənaət,
Oldur bu müsafirətdə yanın,
Zövq əhlinə yoxdur e'tibarım.
Mərkəb gərək olsa əzmi-rahə,
Bəsdir bizə xaməvü siyahə.
Vər tuşeyi-rah olursa mətlub,
Məzmuni-xoşü ibarəti-xub,
Əzm eyləyəlim, təəllül etmən!
Mənzil kəsəlim, təğafül etmən!
Ey bəxt, vəfasız olma sən həm!
Həmrahlıq et bizimlə bir dəm!


1
Tərcüməsi: Şadlıqdır, eyhamdır sözün arğacı,
Bunlarla düzəlir söz ehtiyacı.
Gərək söz meydanı gen olsun müdam,
Atını dörd yana səyirtsin ilham.
Qumsala, daşlığa ilham gedərmi?
Getsə də, torpağa təsir edərmi?

_Tərcümə Səməd Vurğunundur_


41


**BU, SƏADƏTLİ**
**BƏY HƏZRƏTLƏRİNİN MƏDHİDTR**

Ey xameyi-sərkəşi-səbükxiz,
Vəqt oldu ki, olasan gühərriz!
Mon acizəmü bıı əmr müşkil,
İmdad dəmidir, olma qafil!
Asari-mürüvvət eyiə izhar,
Bir təprən, əgər mürüwətİn var!
Sən qıl hünori, mon alayım ad,
Sən çək ələmi, mən olayım şad.
Çün nəxli-hədiqeyi-hünərsən,
Miftahi-xəzaneyi-gühərsən,
Cəhd eylə çıxar cəvahiri-pak,
Fikr etmə ki, yoxdur əhli-idrak!
Demə ki, bolub kəsad bazar,
Bulmaz bu mətaimiz xiridar.
Yetməzmi sənə əmiri-kamil,
Sərdari-zəmanə, Veysi-adil?
Ol bəhri-ətavü kani-əltaf
Kim, şə'niııo gəldi ədlii insaf.
Sərdari-müəzzəmü mükərrəm,
Cananeyi-mülkü cani-aləm.
Zatında ormn həmişə mövcud
Elmü ədəbü şücaətü cud.
Ədlindən əgər təraneyi-çəng
Faş eyləyə bəzmdə bir ahəng,
Yel şəm'ə dəxi təərrüz etməz,
Pərvanəyə şəm' zülmü yetməz.
Hüsni-ədəb ilə eylə mö'tad,
Yanında nə vəqt qılsalar yad,
Ol sözü deməz ki, ola təkrar,
Ta yetməyə sayəsmdə azar.
Üslubi-şücaət üzrə mahir,
Xurşidsifət cahanda zahir.
Həm xas onu söyləməkdə, həm am,
Həm Rum dolu adı ilə, həm Şam.


42


Gər cudinə kimsə olsa talib,
Mümkün ola lütfi qəhrə qalib.
Yə'ni mənə öyrədib səxavət,
Bir hacəti istəmək nə hacət?
Olmuş ona xaneyi-əmarət
Bu dörd bina ilə imarət.
Ey dustnəvazü düşmənəndaz,
Şahinrəvişü büləndpərvaz!
Düzdüm sənə türfə aşiyanə,
Yə'ni abedi nişatxanə.
Mə'mur edibən binayi-ali,
Cənnət sifəti, İrəm misali.
Ta ruzi-əbəd bunu məqam et,
Bidəğdəğə işrəti-müdam et!
Billah ki, degil yaman əsər bu,
Gər adisə müddəa yetər bu.
Mən kim, sənə olmuşam sənaxan
Sultan Veysə necə ki, Səlman.
Budur qərəzim ki, cavidani
Adın tuta ərseyi-cahani.
Ta baqi ola bu səbz gülşən,
Həm mən olum əhli-zikr, həm sən.


43


**BU, TUĞRAYİ-MİSALİ-MƏHƏBBƏTDİR**
**və**
**DİBAÇEYİ-DİVANİ-MÖHNƏTDİR**

Dehqani-hədiqeyi-hekayət,
Sərrafı-cəvahiri-rəvayət
Mə'ni çəmənində gül dikəndə,
Söz riştesinə gühər çəkəndə
Qılmış bu rəvişdə nüktədanlıq,
Gülrizligü gühərfəşanlıq
Kim, xeyli-ərəbdə bir cəvanmərd,
Cəm'iyyətü izzü cah ilə fərd,
Müstəcnəi-cümleyi-fəzail
Bulmuşdu rəyasəti-qəbail.
Əmrinə ərəb mütjü münqad, Cəh
Bəirə məqamı, gah Bağdad.
Bir büq'ədə olmayıb qərarı,
Gəzməldə keçərdi ruzigarı.
Hər ləhzə urardı ol yeganə
Sərçeşimələrə siyah xanə.
Seyr eylər idi sürüb tənə'üm,
Gözlər izərə misali-mərdüm.
Övzai-xiyami-mişkfami
Xəlqə şäbi-qədrtək girami.
Hər mənzilə kim, güzar edərdi,
Səhrayi bənəfşəzar edərdi.
Gülzarlar içrə lalə çağı,
Bənzərd evinə lalə dağı.
Əmvalım cəmii-cinsdən çox,
Əmma bu cəhanda varisi yox.
Gər qılsa onu tələf həvadis,
Yox bir xələfi ki, ola varis.
Fərzəndiz adəmi tələfdir,
Baqi edən adəmi xələfdir.
Nəsl ilə olur bəqayi-insan,
Nəzmi-reşərü nizami-dövran.
Can cövhərinə bədəldir övlad;


44


Övlad qoyan, qoyar həmin ad.
Xoş ol ki, xələfdən ola xoşdil,
Dünyada bir oğlu ola qabil.
Pirayosi ola dəstgahə,
Sərmayəsi ola İzzü cahə.
Ah, ər ola bir səfihü sərkeş,
Ətvari kərihü xülqi naxoş.
Təşni' oxuna olub nişanə,
Bizar ola ondan atə-anə.
Əlqissə, ol əfzəli-qəbail,
Ol piri-həmidətül-xəsail
Fərzəndə olub həmişə talib,
Təhsili-bəqayi-nəslə rağib,
Çox mahüqa sənəmlər aldı,
Çox türfə zəminə töxm saldı.
Çox nəzrlər etdi hər məzarə,
Çox qıldı niyaz kirdigarə,
Tə'sir qılıb fəğanü ahi,
Övn etdi inayəti-ilahi.
Bir gecə açıldı babi-rəhmət,
Buldu əsəri-dua icabət.
Məqsud şəm'i münəvvər oldu,
Sənduqi-əməl dür ilə doldu.
Tədric ilə qıldı kilki-təqdir
Nəqşi-qərəzi rəhimdə təsvir.
Bər verdi nihali-baği-məqsud,
Açıldı güli-hodiqeyi-cud.
Çün və'də irişdi, doğdu bir ay,
Xurşid rüxiylə aləmaray.
Şad oldular ondan atə-anə,
Şükranə verildi çox xəzanə.
Əlqissə, ədəmdən oldu peyda
Bir tifli-müzəkkərü müzəkka.
Xurşid kimi kəmalə qabil,
İsa kimi tiflilikdə kamil.
Ol dəm ki, bu xakdanə düşdü,
Halını bilib fəğanə düşdü.


45


Axır günün əvvəl eyləyib yad,
Axıtdı sirişkü qıldı fəryad,
Yə'ni ki: "Vücud dami-qəmdir;
Azadələrin yeri ədəmdir.
Hər kim ki, əsir olur bu damə,
Səbr etsə gərək qəmi-müdamə".
Olmuşdu zəbani-hali guya,
Söylərdi ki: "Ey, cəfaçı dünya!
Bildim qəmini sənin ki, çoxdur,
Qəm çəkməyə bir hərif yoxdur.
Gəldim ki, olam qəmin hərifi,
Gəl, təcrübə eylə mən zəifi!
Hər qanda qəm ola, qılma ehmal,
Cəm' eylə, dili-həzinimə sal!
Həm ver mənə qəm yemək kəmali,
Həm aləmi qəmdən eylə xali!
Peyvəstə məni əsiri-qəm qıl!
Kəm qılma nəsibimi, kərəm qıl!
Zövq ilə keçirmə ruzigarım,
Fani olana yox e'tibarım.
Ey eşq, qəribi-aləm oldum,
Avareyi-vadiyi-qəm oldum,
Tədbiri-qəm etmək olmaz oldu,
Gəldim, geri getmək olmaz oldu.
Səndən dilərəm mədəd ki, daim
Təmkinim ola sən ilə qaim.
Bu bəzmdə kim, şərabı qandır,
Saqi-cəlladi-biamaldır,
Bir mey mənə sun ki, məstü mədhuş
Daim özümü qılım fəramuş.
Nə gəldigimi bilim cəhanə,
Nə onu ki, necədir zəmanə.
Aləm gözümə görünməyə hiç,
Bu riştədə bulmayım xəmü piç".
Dayə onu pak qıldı qandan,
Qaldırdı bit tirə xakdandan.
Qüslün verib abi-çeşrai-tərdən,


46


Süd yerinə verdi qan cigərdən.
Əqvamü qəbaili olub şad,
Ol növrəsə Qeys qoydular ad.
Can ilə qılırdı dayə e'zaz,
Əsbabi-kəmali-tərbiyət saz.
Lakin, ol edib həmişə nalə,
Xoşnud degildi heç bu halə.
Ə'zasın edib əlilə əfgar,
Eylərdi müdam naləvü zar.
Süd içsə sanırdı kim, içər qan,
Əmcək görünürdü ona peykan.
Yox idi firib ilə qərarı,
Yanında firibin e'tibarı.
Bir gün onu gəzdirirdi dayə,
Dərdini yetirməyə dəvayə,
Bir evdə məgər ki, bir pərivəş
Ol tifli bəsi görüb müşəvvəş,
Rəhm etdi, əlinə aldı bir dəm,
Tİfl onu görüncə, oldu xürrəm.
Hüsnünə baxıb qərar tutdu,
Fəryadü fəğanını unutdu.
Olduqca əlində, oldu xəndan;
Düşdükdə əlindən, oldu giryan.
Mahiyyətini çü dayə bildi,
Ol mahı ona ənis qıldı.
Oldu bu dəxi onunla mö'tad,
Nə dayə, nə anə eylədi yad.
Zatında çü var idi məhəbbət,
Məhbubu görüncə tutdu ülfət.
Eşq idi ki, oldu hüsnə mail,
Hüsnü nə bilirdi tifli-qafil.
Mə'lum idi əhli-halə ol hal
Kim, nüsxeyi-eşqdir bu timsal.
Əlbəttə, bu tifli zar edər eşq,
Aşüftəyi-ruzigar edər eşq.
Əlbəttə, qılır bu sübh təsir,
Xurşid çıxıb olur cahangir.


47


Çün tərbiyəti-ədibü dayə
Verdi əsəri-təmam ol ayə,
Gün-gündən edib kəmal hasil,
Ol mahi-növ oldu bədri-kamil.
Gəldikcə meyi-vəfadan əyyam,
Hər dövrdə sundu ona bir cam.
Ta qıldı onu Eəmam sərməst,
Tədric ilə dami-eşqə pabəst.
Çün sür'ət ilə dönüb zəmanə,
On yaşinə yetdi ol yeganə;
Atasına müqtəzayi-adət
Fərz oldu ki, onu edə sünnət.
Cəm' etdi əhaliyi-diyari,
Hər sahibi-izzü etibari;
Bəzl eylədi ol qədər zərü sim
Kim, yetdi qiyasə fərqdən bim.
Xəlq onda görəndə kəsrəti-mal,
Bim oldu ki, mün'əkis ola hal.
Ol safzəmir, pakməşrəb
Bir bəzmgəh eylədi mürəttəb
Kim, görmədi onu çeşmi-sağər,
Cəmşiddən özgəyə müyəssər.
İtmamə yetib təriqi-sünnət,
Tə'limi-ülumə yetdi növbət.
Əsbab ona eyləyib mürəttəb,
Verdilər onunla zibi-məktəb.


48


**BU, BÜNYADİ-BİNAYİ-BƏLADIR**
**və**
**MÜQƏDDİMEYİ-ƏLƏMİ-İBTİLADIR**

Məktəbdə onunla oldu həmdəm
Bir neçə mələkmisal qız həm.
Bir səf qız oturdu, bir səf oğlan,
Cəm' oldu behiştə hurüqılman.
Oğlanlara qızlar olsalar yar,
Eşqə bulunur rəvaci-bazar.
Qız nərgisi-məst edib füsunsaz,
Oğlana satanda işvəvü naz
Oğlan necə səbr pişə qılsın?
Vər səbri həm olsa, nişə qılsın?
Ol qızlar içində bir porizad
Qeys ilə məhəbbət etdi bünyad.
Bir türfə sənəm ki, əqli-kamil
Gördükdə onu olurdu zail.
Zülfeyni-müsəlsəli girehgir,
Can boynuna bir bəlalı zəncir.
Əbrusi xəmi bəlayi-üşşaq,
Həm cüft lətafət içrə, həm taq.
Hər kipriyi bir xədəngi-xunriz,
Peykani-xədəngi qəmzeyi tiz.
Dəryayi-bəla cəbini-paki,
Çin cünbüşi mövci-səhmnaki.
Çeşmi-siyəhinə sürmədən ar,
Hindusinə sürmə həm giriftar.
Rüxsarinə rəngi-ğazədən nəng,
Hərgiz ona ğazə verməmiş rəng.
Göz mərdüməkindən olsa xali,
Göz mərdüməki olurdu xali.
Lə'lü düri göstərirdi hərdəm,
Övraqi-gül içrə iqdi-şəbnəm.
Əbvabi-təkəllüm etsə məftuh,
Əmvatə verərdi müjdeyi-ruh.
Şümşadi-lətifinə mürəkkəb,


49


Sibi-zənəxü turunci-ğəbğəb.
Əndami lətifeyi-ilahi,
Dəryayi-lətafət içrə mahi.
Şəhbaz baxışlı, ahu gözlü,
Şirin hərəkətli, şəhd sözlü.
Rahü rəvişi müdam qəmzə,
Başdan-ayağa təmam qəmzə.
Ayruqca şəklü xoşca peykər,
Yaxşıca sənəm, gözəlcə dilbər.
Aləm səri-muyinin tüfeyli,
Məhbubeyi-aləm, adı Leyli.
Qeys onu görüb həlak oldu,
Min şövq ilə dərdnak oldu.
Ol nadirə həm ki, Qeysi gördü,
Min zövq bulub, özün itirdi,
Gördü ki, bir afəti-zəmanə,
Misli dəxi gəlməmiş cəhanə.


50


**BU, SİFƏTİ-MƏCNUNDUR**
**və**
**İBTİDAİ-MÖHNƏTİ-FÜZUNDUR**

Bir dilbəri-sərvqəddü gülruy,
Sərvi-xoşü gülrüxü səmənbuy.
Şirin ləbi - mənşəi-lətafət,
Rə'na qədi - durduğilə afət.
Övsafi-lətafətində söz çox,
Əltafi-məlahətində söz yox.
Şəhla gözü - nərgizi-pürəfsun,
Ziba qaşı - nərgis üzrəki nun.
Hüsni gülü laleyi-şəfəqfam,
Zülfi xəmi - lalə üzrəki lam.
Ağzı sifətin xud etmək olmaz,
Əsrari-nihanə yetmək olmaz.
Zülfi sözü - zikri-həlqeyi-raz,
Lə'li-ləbi - abi-çeşmeyi-naz.
Dövri-məhi-ruyi - çeşmeyi nur,
Xaki-kəfl-payi - sürmeyi-hur.
Bir qayət ilə şəmaili-xub
Kim, Leyli olanda ona mətlub,
Bir güzgüyə gər açıb gözünü,
Güzgüdə görəydi öz-özünü,
Öz arizinə olurdu meyli,
Qılmazdı həvayi-hüsni-Leyli.
Ol iki səmənbərü səhiqəd
Bir-birinə oldular müqəyyəd.
Ol iki xərabi-badeyi-zövq
Bir camdan içdilər meyi-şövq,
Girdabi-bəlayə oldular qərq,
Qalmadı aralarında bir fərq.
Övzai-müxalif oldu yeksan,
Guya iki təndə idi bir can.
Hər kim sorar olsa Qeysə bir raz,
Leylidən ona yetərdi avaz.


51


Kim Leyliyə qılsa bir xitabı,
Qeys idi ona verən cavabı.
Eylərlər idi xəti-vəfa məşq,
Artardı dəmadəm onlara eşq.
Leylidə oxumaq iztirabı
Olsa, rüxi-Qeys idi kitabı.
Məşq etməyə Qeys alsa bir xət,
Leyli qaşı idi ona sərxət.
Xətt üzrə qılırdı ol gözəllər
Min naz ilə bəhslər, cədəllər.
Əmma nə cədəl - kəmali-ülfət,
Nə bəhs - nəhayəti-məhəbbət.
Çün bir neçə müddət ol iki pak
Övqat keçirdilər tərəbnak.
Eşq olduğu yerdə məxfi olmaz;
Eşq içrə olan qərar bulmaz.
Eşq atəşinə budur əlamət
Kim, baş çəkə şö'leyi-malamət.
Hüsn afəti-eşq olub dəmadəm,
Gəldikcə İradət oldu möhkəm,
Bir qayətə yetdi nəş'əyi-hal
Kim, oldu həvasü əql pamal.
Qalmadı zəbanə tabi-göftar
Kim, eyləyələr məhəbbət izhar.
Keyfiyyəti-hali qılmağa faş
Gətmişdi təkəllümə gözü qaş.
Eylərdi gözilə bu xitabı,
Qaşilə verərdi ol cəvabı.
Qaşü göz ilə olan təkəllüm,
Həm qılmadı dəfi-zənni-mərdüm.
Mərdümden olam, demə, kənarə!
Mərdüm göz içindədir, nə çarə?
Həmraz ikən ol iki vəfadar,
Dəmsaz ikən ol iki cigərxar,
Rəf' odu hicabi-şahidi-raz;
Eşq oldu məlamət ilə dəmsaz.


52


1
Hamısı



Aşiqlərə gizli qalmadı hal;
Mə'lum oldu cəmii-əhval.
Gərd ayineyi-nişatə düşdü,
Minbə'd iş ehtiyatə düşdü.
Söyləşməyə ol iki yeganə
Qalmadı səbəb, məgər bəhanə.
Ta olmaya raz aşikara,
Dövran ilə qıldılar müdara.
Bir növ bəhanə ilə hərdəm
Könlünü qılırdı Qeys xürrəm.
Qəsdən unuduurdu dərsin ol zar,
Leyliyə deyirdi: "Ey vəfadar!
Hifzi-səboq etdi bağrımı xun,
Məndən bilirəm, bilirsən əfzun,
Mən bilmədigim mənə oxutgil,
Dərsim oxuyam qulaq tutgil!"
Çün lövhələr üzrə xot yazardı,
Əmdən xətini qələt yazardı.
Yə'ni ki, xəta təvəhhüm edə,
Ol gül açılıb təbəssüm edə,
Göftarə gələ ki: "Bu, qələtdir,
Tərk et ki, xilafı-rəsmi-xətdir!"
Ola səbəbi-təkəllümi-yar,
Fəhm etməyə müddəayi əğyar.
Ətfal qılanda dövr bünyad,
Vari [1] belə eyləyəndə fəryad,
Ol, yarına ərzi-hal edərdi,
Özgə dövrün xəyal edərdi.
Qılmazlar idi sözünü mə'lum,
Bilməzlər idi sözünə məfhum.
Məktəbdən olan zamanlar azad,
Vəsl üçün edərdi hiylə bünyad:
Qəsd ilə nihan edib kitabın,
Həddən aşırardı iztirabın,


53


Leyli yolunu tutub durardı,
"Sən gördün ola?" - deyib sorardı.
Yə'ni bu bəhanə ilə bir dəm,
Yarın görə, ola şadü xürrəm.
Elmi-xətə ömrün eyləyib sərf,
Məşq etmiş idi həmin iki hərf:
Bir səfhədə "lam"ü "ya" mükərrər
Yazardı, onu qılardı əzbər [1]
Kim: "Bu iki hərfdir muradım,
Rövşən bular ilədir səvadım".


1 Ərəb əlifbasında(L)- və(Y)-hərflərinin təkrarından"Leyli"- sözü yaranır.


54


1
Ki ey



**BU, LEYLİYƏ ANASI İTAB ETDİGİDİR**
**və**
**BƏHARİ-VƏSLİNƏ XƏZAN YETDİGİDİR**

Çün məkr ilə Qeysi-bədsərəncam,
Bir neçə zaman keçirdi əyyam.
Tədbir ilə eşq zövq verməz,
Tədbir diyari-eşqə girməz.
Eşq ilo riya degil müvafiq,
Rüsvay gərək həmişə aşiq.
Dildən-dilə düşdü bu fəsanə,
Faş oldu bu macəra cəhanə
Kim: "Qeys oluban əsiri-Leyli,
Leyli dəxi salmış ona meyli".
Tədrici-məbadi ilə nagah
Leylinin anası oldu agah,
Odlara tutuşdu, yasə batdı,
Ol qönçədəhanə dil uzatdı.
Yanar od olub, çəkib zəbanə,
Ol gülrüxə dedi yanə-yanə:
"K'ey [1] şux! Nədir bu göftügulər,
Qümaq sənə tə'nə eybculər?
Nəyçün özünə ziyan edirsən?
Yaxşı adını yaman edirsən?
Nəyçün sənə tə'nə edə bədgu?
Namusuna layiq işmidir bu?
Nazik bədən ilə bərgi-gülsən,
Əmma nə deyim ikən yünülsən!
Lalə kimi səndə lütf çoxdur,
Əmma nə deyim, üzün açıqdur.
Təmkini cünunə qılma təbdil!
Qızsan, ucuz olma, qədrini bil!
Hər surətə əks kimi baxma.
Hər gördügünə su kimi axma.
Mey gərçi səfa verir dimağə,


55


Axdığı üçün düşər əyağə.
Güzgü kimi qatı üzlü olma!
Nərgis kimi xiyrə göziü olma!
GÖzdən gərək olasan nihan sən,
Ta demək ola sənə ki, cansən.
Sən şəm'sən, uymagil həvayə
Kim, şəm'i həva verər fənayə.
Lö'bət kimi öziinii bəzətmə,
Rövzən kimi kuçələr gözətmə.
Sağər kimi gəzməgi həram et,
Nəğmə kimi pərdədə maqam et.
Sayə kimi hər yerə üz urma,
Heç kimsə ilə oturma, durma!
Sən sadəsən, özgə əhli-neyrəng,
Cəhd eylə verilməsin sənə rəng.
Derlər səni eşqə mübtəlasən,
Biganələr ilə aşinasən.
Sən qandanü eşq zövqi qandan?
Sən qandanü dust şövqi qandan?
Oğlan əcəb olmaz olsa aşiq,
Aşiqlik işi qıza nə layiq?
Ey iki gözüm, yaman olur ar!
Namusumuzu itirmə, zinhar!..
Biz aləm içində niknamız,
Mə'rufi-təmami-xasü amız,
Nə nəng ilə dəxi edəlim laf?
Biz deməyəlim, sən eylə insaf!
Tut kim, sənə qıymazam məni-zar,
Məndən ulu bir müdəbbirin var.
Neylərsən əgər atan eşitsə?
Qəhr ilə sənə siyasət etsə?
Minbə'd gəl eylə tərki-məktəb,
Bil əbcədini həmin cədü əb.
Etmə qələm ilə məşqdən yad,
Suzən tutü nəqş eylə bürtyad.


56


Ətfaldan eylə qət'i-ülfət,
Həmraz yetər yanında lö'bət,
Büt kimi bir evdə eylə mənzil,
Olma dəxi hər yənayə mayil.
Ənqa kimi üzlət eylə pişə,
Öylə rəviş eylə ki, həmişə
Gərçi adın ola dildə məzkur,
Görmək səni ola qeyri-məqdur.
Xoş ol ki, qızı həmişə gizlər,
Xud gizli gərək həmişə qızlər".


57


**BU, İNKAR İLƏ LEYLİ ANASINA**
**CAVAB VERDİGİDİR**
**və**
**SƏRAYİ-MÖHNƏTƏ GİRDİGİDİR**

Leyli bu itabı çün eşitdi,
Öz könlündə müqərrər etdi
Kim, şö'bədeyi-sipehri-zalim
Tərh eylədi nəqşi-namülayim.
Əyyami-vüsalə yetdi hicran,
Vəqt oldu cigərlər ola büryan.
Əmma nə desin, nəçarə qılsın,
Tədbir nə olduğun nə bilsin?!
Naçar tutub təriqi-inkar,
Asari-təcahül etdi izhar.
Gülzar- itabə ab verdi,
Giryan-giryan cəvab verdi:
"K'ey, munisi -ruziganın ana!
Dürci-düri-şahvanın ana!
Sözlər dersən ki, bilməzəm mən,
Məzmununu fəhm qılmazam mən.
Dersən məşuqü eşqü aşiq,
Mən sadəzəmir tifli-sadiq;
Bilmən nədir ol bədisə məzmun?
Söylə, necə olmayım digərgun?
Eşqin qılmazdı kimsə yadın,
Ha səndən eşitdim indi adın.
Billah, nədir, anə, eşqə məfhum?
Bu sirri-nihanı eylə məlum!
Hadiyi-rəhi-muradım olğıl,
Bu işvədə ustadım olğıl!
Mən məktəbə rə'yim ilə getmən,
Bir şüğli xilafi-rə'yin etmən.
Həm sən dərsən ki: "Məktəbə var!"
Həm dersən son ki: "Getmə, zinhar!"
Qanğı sözə e'tiqadım olsun?
Sənə necə e'timadım olsun?


58


1
Ki ol



Mən həm degiləm bu zacrə qail
Kim, hərdəm olub çiraği-məhfü,
Nacinslər ilə həmdəm olam,
Bir yerdə müqəyyədi-qəm olam.
Hər didədən edə-edə pərhiz,
Övqat keçə küduratamiz.
Peyvəstə müəlüm eyləyib cövr,
Gahi səbəq oxuda, gəhi dövr.
Billah mənə həm bu idi məqsud,
Məktəbdə olurmu tifl xoşnud?
Ayrıq bu sözü mükərrər etmə,
Lütf eylə, məni mükəddər etmə!"
Çün ana eşitdi bu cəvabi,
Tərk etdi şikayətü itabi.
Şəksiz ona rövşən oldu kol [1] mah,
Aşiqlikdən degildir agah
Bihudədir ol qamu fəsanə
Kim, aşiqdir filan fılanə.
Çün vaqeə şək məhəlli oldu,
Ol vaqeədən təsəlli oldu.
Leyli həm oturdu evdə naçar,
Düzdü sədəfinə dürri-şəhvar...
Bir bürcdə sabit oldu əxtər,
Məhbusi-xəzanə oldu gövhər.
Lə'l oldu əsiri-sineyi-səng,
Həbs oldu gülabə şişeyi-təng.
Qəmdən siyəh oldu ruzigarı,
Nomid dili-ümidvarı.
Ah eylər idi, vəli, nə hasil?
Ol yel açamazdı qönçeyi-dil.
Göz yaşı tökərdi, leyk nə sud,
Bitməzdi onunla nəxli-məqsud.
Zülfi kimi piçü tabə düşdü,
Heyran qalıb iztirabə düşdü.
Ağzı kimi xülqün etdi qəm dar;


59


Çeşmi kimi cismi oldu bimar.
Nə dərdini saxlasa, qərari,
Nə şərhi-qəm etsə, qəmküsari.
Fanusi-xəyalə döndü ol şəm',
Könlünü qılıb xəyal ilə cəm',
Hərdəm çəkib ol qəm içrə min ah,
Səbr etdi zərurət ilə ol mah.
Dərd ilə düzüb təraneyi-qəm,
Bu bir qəzəli oxurdu hər dəm:

**QƏZƏLİ-LEYLİ**

Fələk ayırdı məni cövr ilə cananımdan,
Həzər etməzmi əcəb, naləvü əfganımdan?

Oda yandırmasa gər şö'lə ilə nöh fələki,
Nə bitər atəşi-ahi-dili-suzanımdan?

Qəmi-pünhan məni öldürdü, bu hem bir qəm kim,
Gülrüxüm olmadı agəh qəmi-pünhanımdan.

Ah idi həmnəfəsim, ah ki, ol həm axır
Çıxdı ikrah qılıb külbeyi-əhzanımdan.

Mən, nə hacət ki, qılam dağı-nihanım şərhin?
Aqibət zahir olur çaki-giribanıradan.

Həq bilir, yar degil canü dilimdən qaib,
Nola gər qaib isə dideyi-giryanımdan.

Can əgər çıxsa tənimdən əsəri-mehri ilə,
Əsəri-mehrini sanman ki, çıxar canımdan.

Lütf edib sən məgər, ey bad, bu gündən böylə
Verəsən bir xəbər ol sərvi-xuramanımdan.

Ey Füzuli, qəmi-hicr ilə pərişandır hal,
Kimsə agah degil hali-pərişanımdan.


60


**TƏMAMİYİ-SÜXƏN**

Saqi, gətir ol meyi-muğani
Kim, unudalım qəmi-cəhani!
Rəhm eylə ki, qəsdi-can edər qəm,
Bağrım sitəm ilə qan edər qəm.
Qıl əqlimi badə üə zail,
Çərxin sitəmindən eylə qafil.
Fəryad ki, çərx bivəfadır,
Daim işi cövr ilə cəfadır.
Bir adət ilə mədarı yoxdur,
Dövranının e'tibarı yoxdur.
Gər həmnəfəs etsə iki yan,
Bir yerə gətirsə iki zarı,
Əlbəttə, səbəb salar arayə,
Onları əsir edər bəlayə.
Billah nə yamandır aşinalıq,
Çün vaqe olur yenə cüdalıq.


61


**GÜZARİŞİ-HALİ-MƏCNUN**

Gülzari-kəlam bağbani
Böylə bəzəmiş bu bustani
Kim, sərvi-riyazi-möhnotü dərd,
Sövdazədə Qeysi-dərdpərvərd
Hər sübh gedərdi məktəbə şad,
Məktəbdə olurdu qəmdən azad,
Məşqi-xəti-hüsni-yar edərdi,
Dəf i-qəmi-ruzigar edərdi.
Zövq ilə tutub təriqi-sabiq,
Adət üzərinə sübhi-sadiq
Gəldi yenə məktəbə fərəhnak
Ta kim, qıla zövqi-vəsli idrak.
Gördü ki, behiştə hur gəlməz,
Gün çıxdı, hənuz nur gəlməz.
Xurşidsiz oldu raz ta şəb,
Oldu başına qaranqu məktəb.
Bildi ki, sipehri-şö'bədəbaz
Bir şö'bədə eyləyibdir ağaz.
Əlbəttə, cəfayi-tə'ni-əğyar
Ol gül yoluna buraxdı bir xar.
Nomid olub etdi nalə bünyad,
Dedi: "Nədir, ey fələk, bu bidad?
Netdim sənə, qəsdi-canım etdin,
Qət'i-rəhi-dilsitanım etdin?
Kəsdin tələbi-qərəzdə rahim,
Bildir mənə kim, nədir günahim?
Əvvəl məni eylədin mükərrəm,
Vəsli-sənəm ilə şadü xürrəm,
Döndün niyə böylə, cövr edərsən?
Ol dövrə nəqiz dövr edərsən?
Vəhm eyləmədinmi kim, çəkib ah,
Suzi-cigər ilə bir səhərgah
Yandıram oda doquz rəvaqın,
Suzin sənə bildirəm fəraqın?
Tədbir qıl, ey müəllimi-pir,


62


Et sehr ilə ol pəriyi təsxir!
Ancaq mənə sanma yetdi bu qəm
Kim, yetdi mənə yetən sənə həm.
Düş, ey əlif, istiqamətindən,
Şərm eylə bu qəddü qamətindən!
Qəddi həvəsilə dəm urarsan,
Ol getdi, əcəb ki, sən durarsan!
Ey nun! Çü nihandır obruyi-yar,
Sən dəxi nəzərdə durma, zinhar!
Ey mim! Çü ağzı oldu qaib,
Oldu sənə həm edəm münasib!
Olsan nola, ey dəvat, diltəng?
Ayineyi-xatirin tutub jəng,
Ol türreyi-mişkbudan ayru
Hicran qara bağrın eyləmiş su.
Ey xamə, sirişkbar olubsan,
Sərgəştəvü biqərar olubsan!
Guya bu gim etməmiş müyəssər
Dövran sənə dəstbusi-dilbər.
Ey lövh, o xəttin eylə yadın,
Qıl sinədə nəqş qəm səvadın!"
Bir neçə gün ol əsiri-hicran.
Məktəbdə gəzib qılırdı əfğan.
Hər raz fəğanı ilə ta şəb,
Tə'zib çəkərdi əhli-məktəb.
Şəb həm qılıban fəğanü zari,
Eylərdi müxatəb ol nigari:
"Key göz nuri, könül süruri!
Sənsiz gözümün yox oldu nuri.
Əvvəl nə idi bu aşinalıq?
Axır niyə eylədin cüdalıq?
Əvvəl niyə eylədin məni məst,
İzhari-məhəbbət ilə pabəst?
Axır nə üçün xumarə saldm,
Bu möhnoti-intizarə saldın?
Saldın dili-zarə nari-firqət,
Qıldın gözümü pür abi-həsrət!


63


Könlüm odu qıldı yanə-yanə
Ahəng şəfəqtək asmanə.
Yaşım suyu oldu varə-varə
Bir bəhr ki, yox ona kənarə.
Mən isəməzəm bu gündə həmdəm,
Yanımdan itət xəyalını həm!
Olmaya düşüb xəyalın, ey məh,
Oda yana, suya bata nagəh.
Sərməsti-şərabi-iştiyaqəm,
Mədhuşi-təhəyyüri-fəraqəm,
Qoyma qəmini mənimlə həmrah,
Faş eylərəm onu xəlqə nagah.
Sərməstdə ixtiyar olmaz,
Mədhuşda e'tibar olmaz.
Can oldu qəmin yolunda bərbad,
Təşvişi-fənadən oldum azad.
Göstərdi mənə qərain məzaqi
Eyşi-əbədi, nişati-baqi.
Gər gəlsə əcəl, mənim nəm ala?
Can xud yoxdur, məgər qəm ala.
Şəm'i-şəbi-mehnətü bəlayəm,
Aşüfteyi-cünbüşi-həvayəm.
Suzi-dil ilə tökülsə yaşım,
Tiği-qəm ilə kəsilsə başım,
Candan çıxarıb həvayi-eşqi,
Tərk eyləməzəm bəlayi-eşqi.
Bu günləri kim, qəm içrə zarəm,
Hicran ələmilə biqərarəm,
Gər nameyi-ömrə kilki-təqdir
Gündür deyibən qılırsa təhrir,
Eylər məni ol hesab məğbun
Kim, surəti-haldır digərgun.
Gün şərti demişlər afitabi,
Billah ki, bu nüktədir hesabi.
Hər gün ki, görünməz afitabım,
Mən gün deməzəm, budur hesabım.
Yox kimsə bu dərdi-dildən agah,


64


1
Gizlədib



Bu dərdi-dil ilə neyləyim, ah?!
Dərdim sözə gəldigincə artar,
Oddur, yel ilə zəbanə dartar".
Əyyamü-vüsalı eyləyib yad,
Ol xəstə bu şe'ri etdi bünyad:

**QƏZƏLİ-MƏCNUN**

Ey xoş ol günlər ki, mən həmraz idim canan ilə,
Ne'məti-vəsün görüb, nazra çəkərdim can ilə.

Görməmişdi gülşəni-eyşim xəzani-təfriqə,
Olmamışdı tirə əyyamım şəbi-hicran ilə.

Məhvəşimdən, dustlar, dövran cüda istər məni,
Düşmənimdir, hiç bilmən netmişəm dövran ilə?

Yetsə gər aşiqlərin əflakə əfgam, nə sud,
Yetmək olmaz mahvəşlər vəslinə əfğan ilə.

Yaşınb [1] saxlardım eldən daği-hicranın, əgər
Etmək olsaydı müdara dideyi-giryan ilə.

Zövqdən dibaçə bağlandı kitabi-ömrümə,
Qoymadı dövran keçə övqatım ol ünvan ilə.

Ey, Füzuli, əxtəribəxtim müsaid olmadı
Kim, olam bir dəm müqarin ol məhi-taban ilə.

**TƏMAMİYİ-SÜXƏN**

Söz müxtəsər: ol əsiri-sevda
Bir növ ilə oldu xəlqə rüsva
Kim, Qeys ikən, oldu adı Məcnun,
Əhvalını etdi qəm digərgun.


65


**BU, LEYLİYƏ MƏCNUN**
**GÜZƏRDƏ MÜQABİL OLDUĞUDUR**
**va**
**GÜN MÜQABİLİNDƏ HİLALİ-MEHRİ BƏDRİ-KAMİL**
**OLDUĞUDUR**

Bir gün ki, bahari-aləməfruz
Vermişdi cəhanə feyzi-novruz,
Salmışdı niqab çöhrədən gül,
Çəkmişdi sürudi-nalə bülbül.
Şəbnəm meyi-nabi ılə lalə
Doldurmuş idi qızıl piyalə.
Olmuşdu gül ilə səbzeyi-tər
Firuzəfüruz, lə'lpərvər.
Bir neçə müsahibi-vəfadar
Məcnuni-şikəstəyi görüb zar,
Hər yan dedilər ki: "Ey bəlakəş!
Gül çağıdır, olmagil müşəvvəş!
Bu fəsldə adəmi gərək şad,
Ənduhü bolavü qəmdən azad!
Çün əbr degilsən, olma giryan,
Çün seyl degilsən, etmə əfğan!
Gül kimi buraxma sinənə çak!
Səbzə kimi etmə bəstərin xak!
Kəmtər özünü əsiri-qəm qıl,
Lütf eylə, xüramə gəl, kərəm qıl!
Səhra tutalım, mey içəlim şad,
Ənduh ilə olma böylə mö'tad!
Ey qönçədəhanü sərvqamət,
Gül, oyna, zəmani et fərağət!
Pakizə vücudə heyfdir qəm,
Böylə dəxi qalmaya bu aləm,
Şayəd açıla güli-muradın,
Möhkem qıl əsasi-e'tiqadın!
Seyr üzrə bu növbahar fəsli
Şayəd buluna nigar vəsli".


66


Məcmuni-həzin əyağa durdu,
Səhralərə seyr üçün üz urdu.
Giryan-giryan qılırdı seyran,
Heyran-heyran gəzirdi hər yan,
Gəh səbzəyə ərzi-raz edərdi,
Gəh laləyə min niyaz edərdi,
Çeşminə sürərdi lalə dağın,
Aşiq sanıban öpüb ayağın.
Nərgis gözünə nigah edərdi,
Yarın gözün anıb, ah edərdi.
Söylərdi bənəfşəyə qəmi-dil
Kim, söyləyə, yarə olsa vasil.
Bülbüllərə şərh edərdi halın,
Qumrilərə möhnətü məlalın.
Hər türfə çiçək görüb çəkib ah,
Mənzil-mənzil gəzərdi, nagah
Bir mənzilə düşdü rəhgüzari
Kim, seyrdə idi onda yari.
Bir neçə pərirüx ilə həmdəm,
Məcnuni-şikəstədən müqəddəm
Leyli güzər etmiş ol fəzayə,
Salmış gülü lalə üzrə sayə.
Bir səbzəyə səbz xərgəh urmuş,
Məh səhni-çəməndə halə qurmuş;
Qönçə kimi ol lətif xərgah,
Gül bərgi kimi içində ol mah.
Məcnunə müqabil oldu Leyli,
Bəhri-qəmə yetdi dərd seyli.
Leyli demə - şəm'i-məclisəfruz,
Məcnun demə - atəşi-cigərsuz.
Leyli demə - cənnət içrə bir hur,
Məcnun demə - zülmət içrə bir nur.
Leyli demə - övci-hüsnə bir mah,
Məcnun demə - mülki-eşqə bir şah.
Leyli demə - bir yeganeyi-dəhr,
Məcnun demə - bir fəsaneyi-şəhr.


67


Leyli - çəməni-bəla nihalı,
Məcnun - föləki-vəfa hilalı.
Leyli - məhi-asimani-həşmət,
Məcnun - şəhi-kişvəri-məlamət.
Leyli - səfi-əhli-hüsn əmiri,
Məcnun - səri-kuyi-qəm fəqiri.
Leyli işi - işvəvü kirişmə,
Məcnun gözü yaşı çeşmə-çeşmə.
Leyliyü nişati-hüsn kami,
Məcnunü bəlayi-eşq dami.
Leyliyü lətafəti-dilaray,
Məcnunü məlaməti-qəməfzay.
Leylidə kəmali-hüsn ilə zövq,
Məcnunda cəmali-Leyliyə şövq.
Leyli - sədəfi-həyayə bir dür,
Məcnuna onunla min təfaxür.
Leylidə vüsali-dust meyli,
Məcnunda həm arizuyi-Leyli.
Ol iki səhiqədü səmənbər
Bir-birinə oldular bərabər;
Fuladə sataşdı səngi-xarə,
Od düşdü qərarü ixtiyarə.
Bir sazə düzüldü ol iki tar,
Gərm oldu rəvaci-naleyi-zar.
Ol baxdı buna nişat buldu,
Bu gördü onu müqəyyəd oldu.
Məcnunda qərar tutmayıb huş,
Dəryayi-təhəyyür eylədi cuş.
Bir dəm baxa bümədi ol ayə,
Döşəndi yer üzrə misli-sayə.
Leyli həm itirdi ixtiyarın,
Bir dəm görə bilmədi nigarın,
Heyranlığı ol məqamə yetdi
Kim, düşdü ayaqdan, usu getdi.
Gül suyu səpib rəvan üzünə,
Leylini gətirdilər özünə.


68


Hər yan dedilər ona ki: "Ey mah!
Nagəh, olur atan-anan agah
Kim, qeyr ilə aşina olubsan,
Bir dilbərə mübtəla olubsan.
Verməz bu rəviş nəticeyi-xub,
Şayəstə degil sənə bu üslub!
Yaxşı nəzər eyləsən yamandır,
Həm bizə və həm sənə ziyandır!"
Ondan götürüb büsatü xərgah,
Ol mahliqayi xahü naxah
Öz bürcünə qıldılar rəvanə,
Ta olmaya vaqif atə-anə.
Söz demədilər bu macəradan,
Nə gəncdənü nə əjdəhadan.
Məcnunu həm etdi çeşmi-xunbar
Sular saçıban üzünə, bidar.
Gördü ki, nigardan nişan yox,
Bir cismi-füsürdə var, can yox.
Divanə qalıb, pəri gedibdir,
Salıb onu dilbəri gedibdir.
Çak eylədi camə, çəkdi nalə,
Halı bədəl oldu özgə halə.
Tərk etdi libasi-laləguni,
Rəxt oldu təninə əşki-xuni.
Gər matəm üçün misali-xamə,
Sarmışdı başa siyəh əmamə.
Cizgindi başına dudi-ahi,
Yandırdı əmameyi-siyahi.
İkrah ilə çıxdı pirəhəndən,
Ar etdi şəhidi-qəm kəfəndən.
Nələyni buraxdı ol bəlacu
Kim, aşiqinə payibənddir bu.
Həmdəmlərə üzr qıldı ağaz:
"Key bir neçə həmnişinü həmraz!
Seylabi-hücumi-əşk yetdi,
Mən şiftəhalı qərq etdi.


69


Olman məni-xəstə ilə həmdəm,
Ta batmayasız bu suya siz həm.
Mənrəngi-məlamətə boyandım,
Sevdazədəlik oduna yandım.
Əlbəttə, bu od ki, düşdü canə,
Axır tutuşub çəkər zəbanə.
Düşvar bəlamı səhl sanmın!
Siz dəxi mənim oduma yanmın!
Məndən sizə düşməsin bir oxgər,
Çün dəgmədi xeyr, dəgməsin şər.
Sevda siyəh etdi ruzigarım,
Eşq aldı inani-ixtiyarım.
Mən bir quşam, uçdum aşiyandan,
Mən qandanü meyfi-xanə qandan?!
Qılmın mənə ev hekayətin çox,
Dəxi mənim onda getməgim yox!
Sizdən sorar olsa ata halım,
Keyfiyyəti-möhnətü məlalım,
Söylün ki: "Fünayə verdi rəxtin,
Əyyam siyah qıldı bəxtin.
Ey piri-şikəstəhalü naşad,
Tanrıçün əlimdən eyləmə dad!
Demə ki, "nədir bu macəralar?"
Səndən mənə yetdi bu bəlalar!
Mən bilməz idim qəmi-cəhanı,
Təşvişi-zəminü asimanı.
Asudə səraçeyi-ədəmdə
Nə qüssədə idimü nə qəmdə.
Bilməzlik ilə xoş idi halım,
Nə hüsn, nə eşq idi xəyalım.
Sən vasiteyi-vücudim oldun,
Sən manei-feyzi-cudim oldun!
Uradun ki, mənimlə olasan şad,
Dərda ki, ümidin oldu bərbad.
Mən yox olubam, sən indi var ol!
Özgə xələfə ümidvar ol.


70


Mə'zur tut, ey əziz, mə'zur!
Mən qəsd ilə səndən olmadım dur.
Çox sidq ilə eylədim ona əzm
Kim, dövləti-vəslinə edəm cəzm,
Su saldı yoluma əşki-həsrət,
Damanımı tutdu xari möhnət".
Təhrir qılıb münasibi-hal,
Bu şe'ri həm etdi ona irsal:

**QƏZƏL**

Fəzayi-eşqi çün gördüm, səlahi-əqldən durəm,
Məni rüsva görüb, eyb etmə, ey naseh ki, mə'zurəm!

Əgər çaki-giriban eyləsəm, mən' eyləmən, çün mən
Mətai-nəngdən ari, libasi-ardən urəm.

Mənü səhrayi-vəhşət, mənzil etməm afiyət küncün,
Əsiri-dami-zülmət olmazam, çün talibi-nurəm.

Təmərrüd, əql fərmanından etsəm, dustlar, billah,
Məni rə'yimlə sanman, eşq sultaninə mə'murəm.

Mənə kim tənə eylər, kiın nəsihət əhli-aləmdən,
Xoşam ki, e'tibari-eşq ilə hər dildə məzkurəm.

Bəlayi-eşqü dərdi-dust tərkin qılmazam, zahid,
Nə müştaqi-behiştəm sən kimi, nə talibi-hurəm.

Xəyali-çini-zülfü taqi-əbrusilə zövqüm gör,
Sanasan həşmət ilə kəsriyəm, qədr ilə fəğfurəm.

Qərəz bir ad imiş aləmdə, mən həm eylərəm bir ad,
Bihəmdülah, Füzuli, rindü rüsvalıqda məşhurəm.


71


**TƏMAMİYİ-SÜXƏN**

Ol şiveyi-eşq içində mahir,
Qaldıqda vəsiyyətini axir,
Qıldı, gözədib təriqi-vəhşət,
Əshabdən inqitai-ülfət.
Səhrayə düşüb günəş misali,
Tənha yürür oldu laübali.
Hər daşə ki, yetdi tökdü yaşın,
Lə'l eylədi kuhü dəşt daşın
Gözyaşını bəs ki, tökdü hər su,
Hər mərhələdən axıtdı min cu.
Bir əbri-bəla idi, güvahi:
Baran - sirişki, bərq - ahi.
Baran ilə bərqi cismü candan,
Bir mərtəbədə ki, bundan, andan
Dəryalərə yetsə ləm'əyi-tab,
Səhralərə düşsə qətreyi-ab,
Dəryalar olurdu cümlə səhra,
Səhralər olurdu cümlə dərya.
Fəryad ilə doldurub bu deyri,
Fəryadə gətirdi vəhşü teyri.
Ərğanı yetirdi asimanə,
Atəş salıb ah ilə cəhanə.


72


**BU, MƏCNUN ATASININ**
**VAQİFİ-HAL OLDUĞUDUR**
**və**
**ONU BİYABANİ-MÖHNƏTDƏ**
**BULDUĞUDUR**

Gəncinəgüşayi-gəncgöftar
Olmuş bu əda ilə gühərbar:
K'ol bir neçə biqərarü məhzun
Naçar qılıb vidai-Məcnun,
Nomid dönüb şikəstəvü xar,
Qıldılar atasını xəbərdar.
Ol pir çü vaqif oldu halə,
Məcnun kimi etdi ahü nalə.
Səhralərə tutdu seyltək üz,
Vadilərə açdı çeşmətək göz,
Çox aradı, gəzdi hər məkam,
Bulunmadı oğlunun nişanı.
Ta aqibət ol şikəstəhali
Bir guşədə gördü laübali.
Düşmüş yerə, xaksarü qəmnak,
Əhvalı xərabü sinəsi çak.
Dönmüş güli-sürxi zə'fəranə,
Şümşadi-lətifi xeyzəranə.
Ayinəsini qubar tutmuş,
Jəngi-qəmi-ruzigar tutmuş;
Etmiş əlifin sitəm yükü dal,
Qılmış qələmin fələk qəmi nal.
Həmsöhbəti murü həmdəmi mar,
Təkyəgəhi xakü bəstəri xar.
Xar üzrə ona dəlik-dəlik tən,
Açmış qəm evinə dürlü rövzən.
Ol pir, çü gördü surəti-hal,
Surət kimi qaldı bir zaman lal.
Bir ləhzə onu təhəyyür aldı,
Heyrət gözü ilə baxa qaldı.
Sonra yaxa yırtıb etdi fəryad:
"K'ey bülbüli-bustani-bidad!
Hali-dilini mənə bəyan et,


73


Əsrari-nihanini əyan et.
Kim aldı əlindən ixtiyarın?
Kim eylədi tirə ruzigarın?
Billah, netə biqərar olubsan,
Aşüfteyi-ruzigar olubsan!
Nə seyrdəsən, sənə tələb nə,
Bu naleyi-zarinə səbəb nə?
Dəryadə isə sənə düri-kam,
Sən söylə, mən eyləyim sərəncam.
Zülmətdə isə şəm'i-məqsud,
Rövşən qılü məndən istə mövcud".
Məcnun dedi: "Ey mənə verən pənd,
Danayi-süxənvərü xirədmənd!
Kimsən, nədürür bu göftgulər,
Bifaidə batil arizulər?
Get, dərdimə sən dəva degilsən,
Biganəsən, aşina degilsən!
Mən böylə kəmalə tutmazam guş,
Leyli sözü söylə, yoxsa xamuş!"
Dedi: "Mənəm atan, ey bəlakəş,
Mən səngi-məlamətəm, sən aləş!"
Dedi: "Nədir, atə, yoxsa anə?
Leyli gərək, özgədir fəsanə".
Çün gördü itaətində ehmal,
Bildi ki, fəqir özgədir hal,
Verdi bu firib ilə təsəlli
Kim: "Dur gedəlim, çağırdı Leyli!
Leyli bizə gəldi, mihmandır,
Lə'li tələbində dürfəşandır".
Məcnun ki, eşitdi Leyli adın,
Sandı ki, fələk verər muradın.
"Lobbeyk" deyib ayağə durdu,
Ol Kə'beyi-məqsədə üz urdu.
Pir ilə cəvani-dilşikəstə,
Gəldi evə düfigarü xəstə.
Başında həvayi-vəsli-Leyli,
Nə ata qəmi, nə ana meyli.
Gah ata nəsihət etdi ağaz,
Gah anası oldu pəndpərdaz.


74


**BU, MƏCNUNA ANASI**
**PƏND VERDİGİDİR**
**və**
**BUSTANİ-MƏLAMƏTDƏN**
**XARİ-NƏBAMƏT DƏRDİGİDİR**

"Key rahəti-canü nuri-didə!
Fərzəndi-yeganeyi-güzidə!
Şə'nində rəyasəti-ərəb var,
Mirasi-şücaətü ədəb var.
Ətvari-müluki tut həmişə,
Ayini-şücaət eylə pişə.
Əbruyi-xəm isə gər muradın,
Süst etmə kəmanə e'tiqadın!
Müjgani-siyahdən götür dil,
Ol navəki-cansitanə mayil!
Olsan nigərani-qəddü qamət,
Qıl nizeyi-xunfəşanə rəğbət!
Gər zülf ilə görmək istəsən xal,
Gör hey'əti-nöqtə, peykəri-dal!
Könlün gözü qaşə olsa məftun,
Gör dideyi-eynü əbruyi-nun!
Sən sərvsən, olmagil giranbar!
Azad ola gör, nə kim giriftar!
Sən lə'lsən, olmagil səbüksəng,
Döndərmə günəş görüb rəvan rəng!
Etmə özünü hübabmanənd
Başında olan həvayə xürsənd!
Kim, yoxdurur ol həvayə bünyad,
Başın olur ol həvayə bərbad.
Sərgərmlik etmə şəm'nisbət,
Suzi-qəmi-eşq ilə mürüvvət.
Gör şəm'i necə düşər bəlayə,
Başına gedən, gedər fənayə.
Zövqi-dilü didə qılma adət!
Salma meyü şahidə iradət!
Məhbubü mey ilə bəsləyən can


75


Sanma olur əhli-əqlü iman!
Əqlimi olur müdam məstin?
İmani olurmu bütpərəsin?
Şe'rə həvəs etmə kim, yamandır,
Yaxşı deselər onu, yalandır!
Hala qıla gör kəmal hasil,
Fövt etmə məcal, gəzmə qafıl!
Ey baği-ümidimiz nihali,
Qılma bizi nəng payimali!
Məhbub həm istəsən, kəm olmaz,
Biz kim, səniniz, sənə qəm olmaz.
Vardır bu həşəmdə rain qəbilə,
Hor taifə içrə min cəmilə.
Bir-bir qılalım qamu sənə ərz,
Yetsin yerinə bizə olan fərz.
Bir sərvi-səhiqədii səmənbər T
əzvicini edəlim müqərrər,
Tə'yin edəlİm sənə məhü sal,
Sərf eyləyə bildigincə əmval.
Sən tutma həmin təriqi-vəhşət,
Qət'i-nəsəb eyləmə əmanət!
Bizdən bu nəsihəti qəbııl et!
Hər ləhzo bizi, yetər məlul et!
Üşşaq sefahətin qılıb yad,
Bu şe'ri nə xoş demiş bir ustad:

**QƏZƏLİ-USTAD**

Can vermə qəmi-eşqə ki, eşq afəti-candır,
Eşq afəti-can olduğu məşhuri-cabandır!

Sud istəmə sövdayi-qəmi-eşqdə hərgiz
Kim, hasili-sövdayi-qəmi-eşq ziyandır!

Hər əbruyi-xəm qətlinə bir xəncəri-xunriz,
Hər zülfi-siyəh qəsdinə bir əfi ilandır!


76


Yaxşı görünür surəti məhvəşlərin, əmma
Yaxşı nəzər etdikdə, sərəncamı yamandır!

Eşq içrə əzab olduğun ondan bilirəm kim,
Hər kimsə ki, aşiqdir, işi ahü fəğandır!

Yad etmə qara gözlülərin mərdümi-çeşmin,
Mərdüra deyib aldanma kim, içdikləri qandır!

Gər dersə Füzuli ld: "Gözəllərdə vəfa var",
Aldanma ki, şair sözü, əlbəttə, yalandır.


77


**BU, MƏCNUNUN**
**NƏSİHƏT QƏBUL ETMƏDİGİDİR**
**və**
**ATASININ DƏRDİ DƏRMANA**
**YETMƏDİGİDİR**

Məcnun ki, eşitdi bu xitabı,
Verdi bu əda ilə cəvabi:
"K'ey ruhi-rəvanın atə, anə!
Kami-dilü canım atə, anə!
Təhqiq edibəm, işim xətadır,
Hər nə desəniz mənə rəvadır.
Aludeyi-rəngi-dudi-ahəm,
Zilli-günəh ilə rusiyahəm.
Mən həm olubam bu işdən agah,
Əmma nə deyim, nə söyləyim? Ah!
Yoxdur bu işimdə ixtiyarım,
Zəbtimdə inani-iqtidarım!
Əql oldu zəifü eşq qalib,
Xatir nigaran, nigar cazib.
Tutdu tənü canımı qəmi-yar,
Qeyrəl-məhbub leysə fiddar. [1]
Məndə dəxi necə mənlik olsun,
Məndən məni istəyən nə bulsun?
Təqdir çü böylədir, nə tədbir,
Təqdiri edərmi kimsə təğyir?
Olsaydı mənə nişat ruzi,
İstərmi idim bu dərdü suzi?
Gər səhhətə qadir olsa bimar,
Dərdə özün eyləməz giriftar.
Əl versə gədayə padişalıq,
Sanman ki, qılır dəxi gədalıq.
Fitrətdə nə halət olsa məqsum,
Rəf olmadığıdır əmri-mə'lum.
İslahıma eyləmən təəmmül


1 Sevgilidən başqa kimsə yoxdur.


78


1 Vurmayın.



Kim, gül tikən olmazü tikən gül.
Keyfiyyəti-abü cövhəri-xak,
Dönmək olamı qəbuli-idrak?
Su süfləligindən ayrılırmı?
Od yandıra bilməyə bilirmi?
Ol gün ki, rəhimdə kilki-qüdrət
İcadıma verdi zibi-surət,
Doldurdu həva ilə dimağım,
Sevda ilə bağladı ayağım.
Doldu bədənimdəki rəgü pust,
Başdan-ayağa məhəbbəti-dust.
Mülk eylədi könlümü bəlayə,
Vəqf eylədi canımı cəfayə.
Yox məndə bu hökmdən təxəllüf,
Ol maliki-vəqfədir təsərrüf.
Dərdi-əzəli dəva bulurmu?
Mehri-əbədi fəna bulurmu?
Mən şəm'i-səraçeyi-fəraqəm,
Suzi-cigər ilə xoşməzaqəm.
Məndən diləyən bu suzi zayil,
Bidadimə olmuş ola mayil.
Şəm'in ki, həyatı oldu atəş,
Halı onun atəşilədir xoş.
Oddan diləyən onun nocatın,
Fani diləmiş ola həyatın.
Düşmənliyə dustluq qılıb ad,
Tədbiri-nicatını eyləmən yad.
Mən qərqeyi-bəhri-şövqi-yarəm,
Bərhəmzədeyi-qəmi-nigarəm,
Ancaq səbəbi-qərarım oldur,
Arami-dili-figanın oldur.
Onunla edin bu dərdə mərhəm,
Urman [1] dəxi özgə kimsədən dəm.


79


Dersiz mənə var dilrübalər,
Leyli kimi çox pəriliqalər...

Billah, deməniz bu hərfı zinhar!
Aləmdə bir ondan özgə kim var?
Bülbül gül üçün qılanda nale,
Dərdinə dəva olurmu lalə?
Xosrov degiləm ki, mənə dilbər
Şirin ola gah, gah Şəkkər!
Mən yekcəhətəm təriqətimdə,
Təğyir işi yox cibillətimdə".
Üzrünü bəyan edib həm ol dəm
Təqrirə gətirdi bir qəzəl həm:

**BU QƏZƏL MƏCNUNİ-DİLPƏZİRİNDİR**

Eşq dərdi, ey müalic, qabili-dərman degil!
Cövhərindən eyləmək cismi cüda asan degil!

Dövr cövründən şikayət edənə aşiq demən,
Eşq məsti vaqifi-keyfiyyəti-dövran degü!

Şəhrdən səhrayə bir fərq olduğun hər kim bilir,
Bilmiş ol kim, eşq səhrasında sərgərdan degil.

Hər kim idrak eylər öz keyfiyyəti-halın, hənuz
Düst rüxsarinə eyni-şövq ilə heyran degil.

Canı canan ittihadı fariğ eylər cismdən,
Cismdən agah olan can vasili-canan degil.

Der imiş düşmən ki, həmdəmdir Füzuli yar ilə,
Hər sözü böhtan isə, həqqa bu söz böhtan degil.


80


**BU, MƏCNUNUN ATASI**
**LEYLİYƏ XASTARLIĞIDIR**
**və**
**LEYLİ ATASININ**
**MƏCNUNDAN BİZARLIĞIDIR**

Saqi, gətir ol şərabi-nabi Kim,
yetdi nisabə qəm hesabi.
Qəm düşməni-cani-mübtəladır,
Dəf eyləyə gör ki, bir bəladır!
Söz cövhərinə olan xiridar,
Bu növ ilə qıldı gərm bazar
Kim, aciz olub qəm içrə ol pir,
Məcnununa qıldı fikri-zəncir.
Bildi ki, gər olmaz olsa Leyli,
Mümkün degil olmağı təsəlli,
Qıldı tələbin özünə lazim,
Cəm' etdi əaliyü əazim.
Ümmid ilə bağladı umub kam,
Ol Kə'beyi-arizuyə ehram.
Çün Leyli atası bildi hali,
Uydurdu əkabirü əali,
Qarşılarına olub rəvanə,
Qıldı olar ilə əzmi-xanə.
"Əhlənvə səhlən!" deyib dəmadəm,
Min gəz dedi: "Ola xeyr məqdəm!"
Çün şəm'sifət olar oturdu,
Ol sərv kimi ayağa durdu.
Ortaya buraxdı türfə xanlar,
Ta kami-dil ala mihmanlar.
Olmuşdu dolub kəbab ilə xan,
Cədyü Həməl ilə asimansan.
Əmma, əcəb ər qıla xirədmənd,
Ol xanları asimanə manond,
Hər kim qərəzin bulurdu xandan,
Bu mümkün olurmu asimandan?
Xanlar götürüldügündə ol pir


81


Təqrib ilə dərdin etdi təqrir:
"K'ey, qədrlə qibleyi-qəbail!
Səndən qamunun muradı hasil,
Əslü nəsəbim sənə əyandır,
Hökmüm neçə min evə rəvandır.
Məşhuri-qəbailəm səxadə,
Mə'rufi-təvaifəm ətadə.
Həm var məhəbbətimdə tə'sir,
Həm var ədavetimdə təşvir.
Sərdəftəri-əhli-ruzigarəm,
Hər necə desəm, yüz onca varəm.
Nəxli-əməlim səmər veribdir,
İyzəd mənə bir gühər veribdir.
Hala dilərəm bu türfə lö'lu
Bir lə'l ilə ola həmtərazu,
Ta lö'lö olanda lə'lə vasil,
Tərkib qılam müfərrihi-dil.
Çox kanlara tişəvəş üz urdum,
Çox ləl həqiqətini sordum.
Hər kanda əgərçi lə'l çoxdur,
Bir lə'l ki, layiq ola yoxdur.
Bir lə'lin eşitmişəm sənin var
Kim, lo'löümə odur səzavar.
Lütf eylə, inayətü kəroə qıl!
Ol lə'l ilə dürrü möhtərəm qıl!
Qılsın gülü sərv sayəpərvər,
Olsun gülə sərv sayəgüstər.
Fəhm et sözümü, təğafül etmə,
Bir xeyr işidir, təəllül etmə!
Gər hasil olur bu kam səndən,
Hər nə ki, dilərsən, istə məndən.
Onca qılayın sənə rəvan gənc
Kim, yer üzün eyləyə nihan gənc.
Onca gühər eyləyim rəvanə
Kim, bulmayasan ona xəzanə".
Ol sərvi-səmənbərin atası,
Ol gənci-nihanın əjdəhası


82


Lütf ilə dedi ki: "Ey xirədmənd!
Mən kimi əsiri-dani-fərzənd!
Sən xoş gəldin, səfa gətirdin,
Torpaqlardan bizi götürdün.
Müşkülcə xitabdır xitabın,
Bilmən necə verərin cəvabın?
Qürbün, bilirəm, mənə şərəfdir,
Əmma xələfin əcəb xələfdir.
"Məcnun" - deyə tə'n edər xəlayiq,
Məcnuna mənim qızım nə layiq?
Leyli deməyim ki, nazənindir,
Bir tirə kənizi-kəmtərindir,
Olmazmı kəniz cinsi-mərdüm?
Yoxdurmu kənizə həm tərəhhüm?
Div ilə pəri olurmu həmdəm?
Olmaz, sözü açma əbsəm, əbsəm!
Divanəyə zayc eyəmə rənc,
Viranə gərək ona, nədir gənc?
Tədbir ilə döndərib məzacın,
Sevdasının eyləsən əlacın,
Leyli onun olsun. eylədim əhd,
Var indi, sən et əlacına cəhd!"


83


**BU, MƏCNUN ATASININ HİRMANIDIR**
**və**
**QEYRİ BABDƏN TƏDBİRİ-DƏRMANIDIR**

Ol sahibi-nəngü namü namus
Döndü evə, gəldi xarü məyus.
Məcnuna dedi ki: "Ey cəfakəş!
Hacət bitər, olmağıl müşəvvəş!
Əql ilə açılır ol müəmma,
Leyliyi sənə verərlər, əmma
Şərti bu ki, olasan xirədmənd,
Ərbabi-xirəddən alasan pənd.
Rəf ola əlaməti-cünunun,
Əql ola həmişə rəhnümunun".
Məcnun dedi: "Ey ədibi-kamil!
Divaneyi-eşq olurmu aqil?
Gər məndə bir ixtiyar olaydı,
Tədbirimə e'tibar olaydı,
Əvvəldən ədəb şüar edərdim,
Təmkinimi üstüvar edərdim.
Olmazdı bu halə ehtiyacım
Kim, ola əzab ilə əlacım.
Məndə bu əlacə yox müdara,
Min gəz qəmim etmən aşikara.
Yoxdur rəvişimdə inqilabım,
Əvvəlki cəvabdır cəvabım.
Sən əhli-xirədsən, eylə tədbir,
Tədbirin edə məgər ki, tə'sir,
Leyliyi dəxi mən etməyim yad,
Mən aqili-vəqt olam, sən azad".
Ol piri-şikəstəhal heyran
Tədbiri-əlac edib firavan,
Hər qanda eşitdi bir təbibi,
Gülzarının oldu əndəlibi.
İzhar edib ona ehtiyacın,
Bimarına istədi əlacın.
Bimarına min təbibi-haziq


84


Bir şərbət içirmədi müvafiq.
Hər yerde ki, bildi bir nəzirgah,
Varıb ona oldu xaki-dərgah.
Çox ol gotürüb dualar etdi,
Çox nəzr verib ətalar etdi.
Rə'yilə məlulun etməyə şad,
Min pirdən almadı bir irşad.
Çox sehr oxunub yazıldı tə'vid,
Çox məkrlərə tutuldu ümmid,
Edilmədi heç birilə çarə,
Nə çarə qəzayi-kirdigarə?
Bir gün dedilər ona ki: "Ey pir!
Aləmdə sənə bu qaldı tədbir –
Kim, Kə'bəyə iltəsən əsirin,
Ola ki, Həq ola dəstgirin.
Tövfi-hərəm olsa ona hasil,
Sərgəştəlik ondan ola zail.
Ursa Həcəri-mübarakə baş,
Yumşaya, əgər ola qara daş".


85


**BU, MƏCNUNİ-BİÇARƏNİN KƏ'BƏYƏ ÜZ**
**URDUĞUDUR**
**və**
**MÜNACATLA SEVDASI ARTDIĞIDIR**

Ol pir bu xeyr işə qalıb cəhd,
Məcnuna mürəttəb etdi bir məhd.
Aldı onu, əzmi-rah qıldı,
Əzmi-hərəmi-ilah qıldı.
Çün Kə'bəyə irdi ol nikuxu,
Məcnuna dedi ki: "Ey bəlacu!
Tut Kə'bəyə ruy, taət eylə!
Təmkinü ədəb riayət eylə.
Tə'zim şəraitin oda qıl,
İxlasi dürüst edib dua qıl.
Ola ki, qəbul ola niyazın,
Həq şəfqəti ola çarəsazm.
Bu yerdə qəbul olur dualər,
Bu büq'ədə bəxş olur ətalər.
Qıl tövbə ki, əhsəni-əməldir,
Cəhd eylə nicatə kim, məhəldir".
Məcnun bulub ol məqamdan zövq,
Saldı ünü çərxə nəş'əyi-şövq.
Suz ilə çəkib cigərdən avaz,
Ərz etdi binayi-Kə'bəyə raz:
"K'ey səqfi büləndü qədri ali,
Mehrabi-əazirmü əalü
Ey qibleyi-əhli-izzü iqbal,
Rüxsari-zəminə ənbərin xal!
Ey məğzi-vəfayə kisvətin pust,
Həmrəngi-pəlasi-xaneyi-dust!
Ey gülbüni-qönçeyi-ibadət,
Sənduqi-cəvahiri-səadət!
Ey daim olan mənimlə həmdərd,
Əmma nə mənim kimi cahangərd!
Köksünə uran Həcər kimi daş,
Zəmzəm kimi gözdən axıdan yaş!


86


Peyvəstə siyəh qılan libasın,
Könlündə nihan tutan həvasın!
Billah, kiməsən bu yerdə aşiq?
Söylə ki, ənisinəm müvafiq.
Olmuş sənə eşq feyzi hasil,
Qılmış səni qibleyi-qəbail.
Ya Rəb, bu hərəmsəra həqiçün,
Bu mə'bədi-pürsəfahəqiçün,
Qıl məndə binayi-eşqi daim,
Manəndi-əsasi-Kə'bə qaim!
Sal könlümə dərdi-eşqdən qəm,
Hər ləhzəvü hər zəmanü hər dəm!
Eşq içrə müdam şövqüm artır,
Şövq ilə həmişə zövqüm artır!
Hər qanda ki, aləm içrə qəm var,
Qıl könlümü ol qəmə giriftar!
Əndişeyi-əqldən cüda qıl,
Eşq ilə həmişə aşina qıl!
Artır mənə zövqü şövqi-Leyli,
Daim mənə onda qıl təcəlli!
Çoxdur bəni-adəm içrə bidad,
Et könlümü vəhşət ilə mö'tad,
Bir mülkdə ver mənə qərari
Kim, yetməyə adəmi qübari".
Ol zairi-Kə'bəyi-inabət
İstərdi dua qılıb icabət,
Tüğyani-bəladən etməyib fikr,
Bu şe'r idi hər dəm etdigi zikr:

**QƏZƏL MƏCNUNİ-DİLPƏZİRİNDİR**

Ya Rəb, bəlayi-eşq ilə qıl aşina məni!
Bir dəm bəlayi-eşqdən etmə cüda məni!

Az eyləmə inayətini əbli-dərddən,
Yə'ni ki, çox bəlalərə qıl mübtəla məni!


87


Olduqca mən, götürmə bəladən iradətim,
Mən istərəm bəlanı, çü istər bəla məni!

Təmkinimi faəlayi-məhəbbətdə qılma süst,
Ta dust tə'n edib deməyə bivəfa məni!

Getdikcə hüsnün eylə ziyadə nigarımın,
Gəldikcə dərdinə betər et mübtəla məni!

Mən qandanü mülaziməti-e'tibarü cah,
Qıl qabili-səadəti-fəqrü fəna məni!

Öylə zəif qıl tənimi firqətində kim,
Vəslinə mümkün ola yetirmək səba məni!

Nəxvət qılıb nəsib Füzuli kimi müənə,
Ya Rəb, müqəyyəd eyləmə mütləq mana məni!


88


**BU, KƏ'BƏDƏN MƏCNUNUN**
**MÜRACİƏTİDİR**
**və**
**VÜHUŞ İLƏ MÜSAHİBƏTİDİR**

Bir-bir eşidib sözün atası,
Bildi ki, qəbul olur duası,
Əfzun olur ol qəmü məlamət,
Mümkün degil oğluna səlamət.
Çox qıldı fəğanü naləvü zar,
Oğlundan ümidi kəsdi naçar.
Ol pir qalıb orada heyran,
Məcnun tutuban rəhi-biyaban,
Tənha səfər ixtiyar qıldı,
Əzmi-səri-kuyi-yar qıldı.
Gündüz gözü yaşı hadiyi-rah,
Gecə yolu şəm'i şö'leyi-ah.
Gərdi-rehi-yari yad edərdi.
Gəh otura, gəh dura gedərdi.


89


**BU, MƏCNUNUN DAĞ İLƏ**
**MÜSAHİBƏTİDİR**
**və**
**CARİ OLAN ÇEŞMƏ İLƏ**
**MÜNASİBƏTİDİR**

Bir dağə irişdi yolda nagah,
Qəddinə libasi-vəhm kutah.
Tığındə uqabı-çərx qam,
Müzmər kəmərində lə'l kanı,
Mün'im sifəti, libası faxir,
Cibü bəğəli dolu cəvahir.
Dərya qürban ona təzərrö'
Eylerdi zəxirəsin təvəqqö'.
Səhra edibən ona təvəlla,
Eylərdi məişətin təmənna.
Ol çeşmələr eyləyib rəvanə,
Olmuşdu olara ata-anə.
Tə'zim ilə qılmış onu həq yad,
Qur'anda "Əlcibalu ovtad".
Məcnun ona eyləyib təmaşa,
Bir odlu sürud qıldı inşa.
Olduqda sürud ilə nəvasaz,
Ondan həm eşitdi əksi-avaz,
Sandı ki, özilə həmnəfəsdir,
Dedi: "Məna bir rəfiq bəsdir.
Yüz şükr ki, yari-qar buldum,
Gəzdim bu cəhanı yar buldum".
Eşq odun ona həm etdi rövşən;
"K'ey guşəmşini-pakdamən!
Suzi-cigərimdən oldun agah,
Əhsənt, əhsənt, barəkallah!
Bir aşiqi-mübtəla imişsən,
Dərd əhlinə aşina imişsən.
Sənsən mənə həmdəmi-müvafiq,
Dağ ilə olur həmişə aşiq.
Bidad ilə köksünə urub daş,


90


Dərd ilə gözündən axıdıb yaş,
Noldu sənə, böylə məst olubsan,
Qəm daminə paybəst olubsan?
Qan ilə dolubdurur kənarın,
Nə güldən ola bu laləzarın?
Bağrın gorürəm olubdurur su,
Nə sərvqədin həvasıdır bu?
Gəl, ağlayalım bu macərayə,
Bir dəm qoşalım səda-sədayə!"
Çün bir dəm onunla ağladı zar;
Dərdi-dili-zann etdi izhar.
Əzm eylədi xaki-kuyi-yarə,
Leylinin evi olan diyarə.


91


**BU, MƏCNUNUN QƏZAL İLƏ**
**MƏQALATIDIR**
**və**
**EŞQ BABINDA ONUNLA**
**OLAN HALATIDIR**

Gördü ki, bir ovçu dam qurmuş,
Daminə qəzallər üz urmuş.
Ol damə cəfayi-çərxi-qəddar
Bir ahunu eyləmiş giriftar.
Boynu burulu, ayağı bağlı,
Şəhla gözü nəmli, canı dağlı.
Əhvalına rəhm qıldı Məcnun,
Baxdı ona, tökdü əşki-gülgun,
Könlünə qatı gəlib bu bidad,
Yumşaq-yumşaq dedi ki: "Səyyad!
Rəhm eylə bu mişkbu qəzalə!
Rəhm etməzmi kişi bu halə?
Səyyad, bu natəvanə qıyma!
Qıl canına rəhm, canə qıyma!
Səyyad, saqın, cəfayamandır!
Bilməzsənmi ki, qana qandır?
Səyyad, mənə bağışla qanın!
Yandırma cəfa oduna canın!"
Səyyad dedi: "Budur məaşım,
Açman əyağın, gedərsə başım.
Qətlində bu seydin etsəm ehmal,
Ətfalü əyalıma nolur hal?"
Məcnun ona verdi cümlə rəxtin,
Pak eylədi bərgdən dirəxtin.
Ol türfə qəzalın açdı bəndin,
Şad eylədi cani-dərdməndin.
Üz urdu üzünə, qıldı əfgan,
Göz sürdü gözünə, oldu giryan:
"K'ey badiyəgərdü badnavərd!
Nazik bədənilə nazpərvərd!
Sən zinəti-hər gili-zəminsən,


92


Gül kimi lətifü nazəninsən
Ey, səbzeyi-cuybari-vəhşət'
Rə'na səməni-bəhari-vəhşət!
Tənha qoyma məni-zəbuni,
Olğıl mənə dəşt rəhnümuni!
Gəz bir neçə gün mənimlə həmrah,
İnsan deyib etmə məndən ikrah!
Yaşım kimi getmə çeşmi-tərdan,
Kəsmə əyağın bu rəhgüzərdən!
Sərçeşmeyi-çeşmim eylə mənzil,
Sərmənzilimizdən olma qafil!
Olsun bəbəgim qərargahın,
Əşkü müjə ab ilə giyahın.
Ey çeşmi-nigar yadigari'
Səhl eylə mənə qəmi-nigari!
Qıldıqda xəyali-çeşmi-Leyli,
Sən ver məni-xəstəyə təsəlli".
Çün ol, bəşəriyyətin unutdu,
Ahu həm onunla üns tutdu,
Onun səbəbilə həm çox ahu,
Səhradə onunla tutdular xu.


93


**BU, MƏCNUNUN KƏBUTƏRƏ**
**ŞƏRHİ-HALIDIR**
**və**
**ONDAN İLTİMASİ-TƏDARÜKİ-MAFİLBALIDIR**

Bu mənzilə yetdi zarü müztər,
Bir damdə gördü bir kəbutər.
Hər rövzəni-dami bir dəri-qəm,
Min qəm mütəvəcceh ona hər dəm.
Məcnun ona baxdı, yandı canı,
Yaşı kimi cuşə gəldi qanı.
Səyyadına eylədi təzərrö',
Qurtarmağın eylədi təvəqqö'.
Səyyad dedi ki, mən fəqirəm,
Fəqrə bu həmamətək əsirəm.
Haşa ki, bu mürği-tizrəftar
Azad ola, mən qalanı giriftar.
Gər var İsə qiymətin əda qıl,
Ondan bunu damdən rəha qıl!
Əvvəl məni eylə qüssədən şad,
Ondan bunu dami-qəmdən azad!"
Var idi qolunda bir düri-tər,
Şəffaf çü dideyi-kəbutər,
Verdi onu, aldı ol əsiri,
Üftadənin oldu dəstgiri.
Sürtdü qədəminə çeşmi-pürxun,
Onca ki, ayağın etdi gülgün.
Hər dəm ona ərzi-raz edərdi,
Min nəğmeyi-şövq saz edərdi:
"K'ey tizpərü büləndpərvaz!
Ərbabi-vəfayə məhrəmi-raz!
Bu rəngi-libasi-nilfamın,
Ənduhü məlaməti-müdamın
İzhar qılır nişaneyi-qəm,
Kim qıldı səni əsiri-matəm?
Gər aşiq isən, sən ey cahangərd,
Qaçma ki, mənəra səninlə həmdərd.


94


Bir ləhzə mənimlə həmnişin ol,
Gəncineyi-razimə əmin ol!
Başım tükün aşiyanə qılğıl,
Göz yaşımı abü danə qılğıl,
Sən qasid imişsən, ey həmamə,
Məndən həm ilət nigarə namə!
Gör hicri-rüxündə iztirabım,
Peyğamım ilət, gətir cəvabım.
Billah, səri-kuyinə gedəndə,
Hər cizginibən təvaf edəndə,
Yad eylə məni, səvabıma gir,
Bir tövf səvabını mənə ver.
Qon xaki-dərinə, istə danə,
Qıl özünə danəni bəhanə.
Olduqca məcalın etmə namus,
Məndən yetir ol yerə zəminbus!"
Onca dedi ona həm qəmi-dil
Kim, qıldı onu həm ünsə mayil.
Başında olub şəb aşiyani,
Gündüz olur oldu pasibani.
Zatında görüb nişaneyi-xeyr,
Həm vəhş mütii oldu, həm teyr.
Ram oldu bəhaim ol figarə,
Bir fövc yığıldı varə-varə.
Ol zar idi mülki-dərd şahi,
Xeyli-dədü dam onun sipahi.
Olmuşdu bəşərdən öylə bizar
Kim, öz əksin sanırdı əğyar.
Dartıb göyə dudi-şö'leyi-ah,
Öz sayəsin istəməzdi həmrah.


95


**BU, LEYLİ ƏHVALINDAN**
**BİR XƏBƏRDİR**
**və**
**MƏ'ŞUQÜ AŞİQ ƏTVARINDAN**
**BİR ƏSƏRDİR**

Saqi, mütəəllimi-xumarəm,
Müştaqi-şərabi-xoşgüvarəm!
Üftadəligim gör, etmə ehmal,
Rəhm et, bir eyağ ilə əlira al!
İzhar qılıb səfayi-məşrəb,
Bu bəzmi çü eylədin mürəttəb,
Bəzm əhlinə növbət ilə ver cam,
Həm xas riayət eylə, həm am!
Məcnunə həmin şərab tutma,
Leyliyi kİ, əsldir unutma!
Dehqani-fəsihi-farsizad
Bu gülşənə böylə dikdi şümşad
Kim, ol çəməni-vəfa bəhari,
Daği-qəmi-eşq laləzari,
Yə'ni rəvişi-vəfadə möhkəm,
Leyli, sədəfi-cəvahiri-qəm
Girmişdi həsarə gəncmanənd,
Urmuşdu ayağə pənddən bənd.
Nə bir fərəhi, nə bir nişati,
Nə kimsə ilə bir ixtilati.
Bizar atadənü anadən,
Biganə cəmii-aşinadən.
Yanına olurdu xublər cəm',
Pərvanəsifət həvaliyi-şəm',
Şad olmağa xatiri-həzini,
Əylənməyə təb'i-nazənini
Min türfecə-türfəcə fəsanə
Şirin söz ilə çəkib bəyanə,
Eylərlər idi zaman-zaman yad,
Təqrib ilə, ləhzə-ləhzə bünyad.
Ol tərk qılıb nişatü rahət,


96


Bir üzvünü eyləyib cərahət,
Eylərdi bəhanə ilə nalə,
Düşməzdi olar düşən xəyalə.
Qızlar qaşa versə vəsmədən rəng,
Can güzgüsünə salardı ol jəng.
Qızlar üzə qoysa nildən xal,
Ol nilə çəkərdi rəxt filhal.
Qızlarda xəyalı-nəqşi-diba,
Ol nəqşi-xəyal ilə şəkiba.
Qızların əli hənadə gülgun,
Onun əli əşki ilə pürxun.
Nə ignədə, nə ipəkdə meyli,
Müjganə tökərdi əşk seyli.
Qızlar qılıb arizuyi-ziyvər,
Gər riştəyə çəksələrdi gövhər,
Ol dəxi çəkərdi eyləyib rəşk,
Tari-bədəninə gövhəri-əşk.
Məcnundan idi cürtuni əfzun,
"Leyli" deyənə deyərdi "Məcnun!"
Dünlər ki, gedib yanından ol cəm',
Bir guşədə ol qalırdıvü şəm'
Şəm'ə qəmi-dil bəyan edərdi,
Suzi-cigərin əyan edərdi.


97


**BU, LEYLİNİN ÇİRAĞLA**
**MACƏRASIDIR**
**və**
**ONDAN ÇAREYİ-DƏRDİ-DİL**
**TƏMƏNNASIDIR**

"K'ey didəsi bağlı, bağrı dağlı'
Başı qaralı, ayağı bağlı!
Gəl, olalı həmnəfəs mənü sən,
Razi-dili-zarin eylə rövşən!
Nə dərd səni nizar edibdir,
Alüftəvü zərdü zar edibdir?
Başdan ayağa nədir bu yanmaq,
Dudi-dilə dəmbədəm boyanmaq?
Nə cinsdir əslin, ey bəlakəş
Kim, abi-həyatın oldu atəş?
Şərhi-dili-gərmü çeşmi-tər ver,
Sərrişteyi-razdən xəbər ver!
Hər ləhzə düşərsən iztirabə,
Həm atəşə qərqsən, həm abə.
Nə sehr qılırsan, ey səhərxiz
Kim, atəşin abdən olur tiz?
Mən suxtədən həm olma qafil,
Məndə dəxi var bir qəmi-dil.
Mən həm sənə bənzərəm vəfadə,
Bəlkə neçə mərtəbə ziyadə.
Sən gecə həmin yanarsan, ey zar!
Mən gecəvü gündüzəm giriftar.
Səndə əsəri-həva ziyandır,
Nisbət mənə rahəti-rəvandır.
Xoşdur sənə sirrini, töküb yaş,
Məclislər içində eyləmək faş.
Könlün çü degil vəfadə qaim,
Könlündəkidir dilində daim.
Mən sabiti-ərseyi-bəlayəm,
Ney kimi xəzaneyi-həvayəm.
Olmam olur-olmaz ilə dəmsaz,


98


Başım kəsilirsə söyləmən raz.
Derdim sənə söyləyəm qəmi-dil,
Səndə dəxi tab yox, nə hasil?
Doymaz cigərim bu şərhi-razə,
Ahım gətirər səni güdazə.
Bir yarə bu dərdi eylədim faş,
Olmadı mənə bu yolda yoldaş.
Səbr eyləmədi bu dərdü dağə,
Qatlanmadı, düşdü daşa-dağə.
Yanında sənin həm urmayam dəm,
Ta qaçmayasan irağə sən həm".
Şəm'in çü görərdi yox zəbanı,
Dəm urmağa yox yarımda canı,
Pərvanəyə şərh edərdi razın,
Ərz eylər idi olan niyazın.


99


1 Hanı



**BU, LEVLİNİN PƏRVANƏYƏ**
**KƏŞFİ-RAZIDIR**
**və**
**ONUNLA FİLCÜMLƏ**
**İZHARİ-NİYAZIDIR**

"K'ey, tairi-aşiyaneyi-eşq!
Sərgəşteyi-abü daneyi-eşq!
Sənsən rəhi-eşq içində sadiq,
Aşiqsən, əmma təmam aşiq.
Bir görməgə yarı can verərsən,
Bir zövqə iki cahan verərsən.
Xoşdur tələbi-vəfadə halın,
Guya ki, fənadədir vüsalın.
Hər necə ki, şöhreyi-cahansan,
Eşq içrə səramədi-zamansan,
Müşkül ki, mənim kimi olub zar,
Məncə ola səndə şövqi-didar.
Sən seyrdəsən həmişə sərməst,
Mən dami-bəladə dərdə pabəst.
Dünlər sənə dust həmnişindir,
Hicran mənə müttəsil qərindir.
Bir şö'ləyə sən nisar edib can,
Düşvar qəmin qılırsan asan.
Mən can ilə istərəm çəkəm qəm,
Min can dilərəm qəm içrə hər dəm.
Məncə sənə yox qəmi-nihani;
Gər var desən, qanı [1] nişani?
Qanı nəmi-çeşmi-əşkrizin?
Qanı dəmi-sərdü gərmxizin?
Qanı sitəmü bəlayə durmaq?
Eşqə duruşub cəfayə durmaq?"
Pərvanədə həm görərdi nöqsan,
Bulmazdı onunla dərdə dərman.
Naçar qılıb təhəmmülü səbr,


100


Ol kəsra dilərdi qeybdən cəbr.
Yan gecələr ki, çeşmeyi-xab
Gözlər çəmənin qılırdı sirab,
Zülmatə düşərdi nuri-biniş,
Aram bulurdu afəriniş,
Yuxuya gedərdi yarü əğyar,
Dərd əhli həmin qalırdı bidar,
Səhraya çıxardı evdən ol mah,
Kamınca qılardı naləvü ah.
Fəryadın edib büləndpayə,
Razi-dilini açardı Ayə.


101


**BU, LEYLİNİN AY İLƏ MÜNAZİRƏ QILDIĞIDIR**
**və**
**XURŞİD KİMİ ŞÖVQ ODUNA YAXILDIĞIDIR**

"K'ey gah qədim kimi xəmidə'
Gahi pür olan misali-didə!
Gəh zahir olan mənə qəmimtək'
Gəh qaib ənisü həmdəmimtək!
Şahiddir ona bu inqilabın
Kim, aşiqisən bir afltabın!
Hicranı ilə nizar olubsan,
Sərgəşteyi-ruzigar olubsan.
Ey möhnəti-eşqdən xəbərdar,
Gör, Tanrı üçün, nə möhnətim var!
Qıl şö'leyi-ahimə nəzarə'
Gər var isə rəhmin, eylə çarə!
Seyr eylə fəzayi-hər diyari,
Gəz cümleyi-dəştü kuhsari.
Gör qandadır ol mənim pənahim'
Şahim, mahim, ümidgahim!
Hali-dilim ona ərz eylə,
Billah, necə gördün isə söylə!"
Ta vəqti-səhər bu idi hali,
Təşvişdən olmaz idi xali.
Mürği-səhəri çəkəndə avaz,
Eylərdi bir özgə növhə' ağaz:
"K'ey vay, tükəndi mayeyi-ömr!
Xurşidə irişdi sayeyi-ömr!
Dəmdir dəri-fürsət ola məsdud,
Müşkül görünə boyani-məqsud.
Dəmdir oyana yuxudan əğyar,
Şərhi-qəmi-dərdim ola düşvar.
Mən əxtəri-bürci-iştiyaqəm,
Mən şəm'i-səraçeyi-fəraqəm.
Gündüz həbsim, gecə nicatım,
Gündüz mövtim, gecə həyatım.
Olmuş dünümə günüm mütabiq,
Gün görməz imiş bəlalı aşiq!"


102


1
Eyləmirsən



**BU, LEYLİNİN SƏBAYA PƏYAMİ-ƏHVALIDIR**
**və**
**ÜMİD İLƏ DƏF'İ-MƏLALIDIR**

Eylərdi səbaya dərdin izhar:
"K'ey badi-səba, dur indi, zinhar!
El qafil ikən bu macəradən,
Suitanə səna yetir gedadən.
Gör munisü qəmgüsan kimdir,
Bizdən ki usandı, yarı kimdir?
Könlü kimin ilədir təsəlli,
Yadına gəlirmi hiç Leyli?
Ərz eylə ki: "Ey gözəl şəhənşah!
Haqdır sənə bəndədən bu ikrah...
Əvvəl ki, bu dilfigan gördün,
Bir tazəvü tər bəhan gördün.
Hala ki, əsiri-dami-dərdəm,
Manəndi-xəzan zəifu zərdəm.
Meyl eyləmisən [1] məni-nizarə,
Döndisə iradətin, nə çarə?
Mən bərgi-xəzanəm, olmuşam xar,
Sən tazə bəharəsən tələbkar.
Hər necə ki, xarü xakisarəm,
Həm şəfqətinə ümidvarəm.
Tərk etmə əvatifi-əmimi,
Yad eylə məvəddəti-qədimi!"
Şəb ta səhər ol büti-səmənbər
Bidar qalıb misali-əxtər,
Eylərdi bu suziş ilə şivən,
Ol dəm ki, olurdu ruz rövşən,
Nəğmə kimi pərdədar olurdu,
Bir pərdə içində zar olurdu.
Daim keçirərdi ol cigərsuz
Övqatı bu rəsm ilə şəbü ruz.
Peyvəstə çəkərdi ol güləndam
Əndişeyi-sübhü möhnəti-şam.


103


**BU, LEYLİNİN BAHAR ƏYYAMİ**
**SEYRİ-GÜLZAR ETDİGİDİR**
**və**
**GÜLZARDA MURADINA YETDİGİDİR**

Bir gün ki, bahari-aləmaray
Zövq əhlinə oldu rahətəfzay,
Ayineyi-dövrdən gedib jəng,
Dövr etdi zəmini asimanrəng.
Feyzi-şəbi-kimiya əsərdən,
Tə'siri-şəmameyi-səhərdən
Açıldı xəmi-bənövşədən tab,
Şəbnəm gülə saçdı lö'löi-nab.
Gülzarə həva əbir tökdü,
Səhrayə qübari-mişk çökdü.
Yağdırdı səhab jalə daşın,
Ol daş ilə yardı qönçə başın,
Zəxminə urub şükufə mərhəm,
Pambıq yenilər ona dəmadəm.
Səbzə gülə verdi mişk bacın,
Gül səbzəyə mülkünün xəracın.
Xoş rəng ilə yığdılar təcəmmüt,
Firuzəvü lə'lü səbzəvü gül.
Dərk eylədi qönçə rəmzü iyma,
Gül adına açdı min müəmma,
Məzmuni-rübaiyi-ənasir
Feyz olduğu xəlqə oldu zahir.
Susən vərəqi uçub həvayə,
Hər səbzəyə kira, salardı sayə,
Ol səbzəyə uğrayıb axan cu,
Fuladə əgər verəydi bir su,
Fulad dəmində can bulurdu,
Şəmşirsifət zəban bulurdu.
Arayişi-səbzədən zəmanə
Bənzətdi zəmini asimanə.
Xurşid, çiraği-çeşmi-aləm,
Göydən yerə düşdügündə hər dəm


104


Təhqiq edibən çıxıb gümandan,
Bilməzdi zəmini asimandan.
Gülzarlar oldu işrətabad,
Hər yerdə olundu bəzm bünyad.
Hər guşədə hər kim aldı bir kam,
Hər büq'ədə hər kim içdi bir cam.
Leylinin anası gördü mütləq
Yox Leyliyi-natəvanda rövnəq,
Meyli-gülü sərvü səbzə qılmaz,
Min qönçə açıldı, ol açılmaz.
Sərf etdi şükufətək dirəmlər,
Cəm' eylədi nazənin sənəmlər,
Səhrayə çıxardı ol nigarı,
Qıldı gülə ərz növbahan,
Ta qüssəvü qəmdən ola azad,
Bir dəm gülə, oynaya, ola şad.
Ol bir neçə bikri-pakdaman,
Həmrah olub oldular xuraman,
Üzdən götürüb ədəb niqabın,
Rəf eylədilər həya hicabın.
Hər kim nə bilirsə lə'b ya ləhv,
İzharə gətirdi etməyib səhv.
Gah eyləyibən sürudlər saz,
Bülbüllərə oldular həmavaz.
Gah göstərib oynamaqda halət,
Şümşadə yetirdilər xəcalət.
Lakin həvəs eyləməzdi Leyli,
Olmazdı bu ləhvü lə'bə meyli.
Artırmış idi bahar dərdin,
Gül zövqü rüxi-nigar dərdin.
İstərdi fərağət ilə bir dəm,
Tənha tuta bir bucaqda matəm.
Ayrılmayıb ol pəriliqalər,
Artırdı bəlasına bəlalər.
Çün eylədi kəsrət onu diltəng,
Neyrəng ilə verdi onlara rəng:
"K'ey sərvlər, eyləmən iqamət,


105


Ta evdə çəkilməyə nədamət!
Durun, qılalım tərəf-tərəf gəşt,
Seyr eyləyəlim həvaliyi-dəşt
Sancıb belə nazənin ətəklər,
Cəm' eyləyəlim gözəl çiçəklər!
Çox dərməgə hər kim olsa qadir,
Oldur bu sənəmlər içrə nadir."
Bir yaniye getdi hər pərivəş,
Dağıldı şərər, tutuşdu atəş.
Tənha qalıb etdi naləvü zar,
Qıldı gözün əbrvəş gühərbar.


106


1 Və ey



**BU, LEYLİNİN ƏBR İLƏ**
**İZHARİ-NİYAZIDIR**
**və**
**EŞQ BABINDA KƏŞFİ-RAZIDIR**

Əbr ilə təkəllüm etdi ağaz:
"K'ey ahim ilə həmişə həmraz!
Göz yaşın ilə göyə yetərsən,
Sanma məni-zardən betərsən!
Ərz eyləmə rə'dü bərqü baran,
Bəhs etmə mənimlə ruzi-hicran!
Fəryad qılıb dəmi-səhərgah,
Əflakə çəkəndə şö'leyİ-ah,
Seylabi-sirişk edəndə cari,
Gəl gör məni-zari-biqərari!
Ey əbr, hər əksiləndə suyin,
Dəryalərə tökmə abi-ruyin!
Al suyi bu çeşmi-xunfəşandan,
Dəryalərə həm bağışla ondan!
Ey əbr, mənə dəmi vəfa qıl,
Düşdü sənə hacətim, rəva qıl!
Var ol üzü gül nigarə məndən,
Zar ağla və söylə yarə məndən:
K'ey türfə nigari-nazəninim,
V'ey [1] arizuyi-dili-həzinim!
Gəl gör ki, qəmində necə zarəm,
Sənsiz necə zarü biqərarəm!
Gəl gör ki, nədir qəmində halım,
Rəngi-rüxi-zərdü əşki-alım!
Can bari-bədən götürməz oldu,
Göz rəngi-vücudu görməz oldu.
Canım canı, gözümün çırağı,
Rəhm eylə ki, gəldi rəhm çağı!
Mən bilməz idim, belə imiş eşq,
Bir dərdli macəra imiş eşq.


107


1
Və əgər



Derdin ki: "Bəla yolunda fərdəm,
Eşq içrə sənə şəriki-dərdəm.
Saldın məni-xəstəyi bu halə,"
Dərdə məni eylədin həvalə!
Hər dərd ki var, Leyli aldı,
Mə'lumdurur, sənə nə qaldı.
Ey, mərd mənəm, - deyə uran laf,
İnsafmıdır bu? Qanı insaf!?
Tut kim, xəsü xari-rəhgüzarəm,
Torpaq kimi yolunda xarəm.
Xurşudi-cəmalın, ey məhi-növ,
Toprağa nola buraxsa pertöv?
Barani-vüsalın, ey düri-nab,
Qılsa xəsü xarı nola sirab?
Olma meyi-qəflət ilə mədhuş;
Həmsöhbətin eyləmə fəramuş!
Ey yari-müvafiqü vəfadar!
Ey mən kimivü mənə səzavar!
Gəl yanimə, kəsmə aşinalıq,
Yaxşımı olur bu bivəfalıq?
Derlər səni aşiq, ey nikuru!
Aşiqlərə böyləmi olur xu?
Hər kim gərək öz işində kamil,
Aşiq nə rəva ki, ola kahil,
Aşiq gərək olmayıb qərarı,
Tövf edə müdam kuyi-yarı.
Düşməz bu yana sənin güzarın,
Var ola məgər br özgə yarın?
Yarın mən isəm, mənə nəzər qıl!
Gahi bu yanayə bir güzər qıl!
Gər səndə olan fərağəti-dil,
Bir dəm mənə olsa idi hasil,
Geysuyi-müsəlsəlü girehgir
Boynumda gər olmasaydı zəncir,
V'ə [1] bağlamayaydı bəndi-xəlxal


108


Qeyd ilə əyağımı məhü sal,
Eyb ilə çəkilməsəydi adım,
Billah, bu idi həmin muradım
Kim, sayə misalı səndən, ey nur,
Olduqca vücudum, olmayam dur!
Əmma nə edim? Əsiri-qeydəm,
Bir boynu, əyağı bağlı seydəm.
Bildirməgə möhnətü məlalım
Bu şe'r yetər bəyani-halım:"

**BU QƏZƏL LEYLİYİ-DİLPƏZİRİNDİR**

Eşq daminə giriftar olalı zar olubam,
Nə bəladır ki, ona böylə giriftar olubam?

Dil deməkdən kəsilib, tən hərəkətdən, vəh kim,
Künci-qəmxanəyə bir surəti-divar olubam.

Qüdrətim yox ki, qılam kimsəyə şərhi-qəmi-dil,
Öylə kim, arizeyi-hicrilə bimar olubam.

Həzərim tə'nədən ol qayətə yetmişdir kim,
Yarə əğyar olub, əğyarım ilə yar olubam.

Deməzəm dəxi: "Sənə aşiqəm", ey gül! Zira
Sənə aşiqligim izhar edəli xar olubam.

Əqlü səbrü dilü din getdi, bihəmdillah kim,
Səfəri-sahili-dəryayə səbükbar olubam.

Yox, Füzuli, xəbərim mütləq özümdən, bəs kim,
Valehi-nəqşi-xəyali-rüxi-dildar olubam.


109


**BU, LEYLİNİN KÜNCİ-QƏMDƏ**
**GİRYANLIĞIDIR**
**və**
**MƏCNUNUN VADİVİ-EŞQDƏ**
**SƏRGƏRDANLIĞIDIR**

Zar ağlar ikən bu rəsmə ol mah,
Bir türfə səda eşitdi nagah.
Bir kimsə oxurdu şe'ri-Məcnun,
Bu nüktə ibarətində məzmun:
"K'ey nəş'əyi eşqdən uran dəm!
Məcnunu saqınma Leylidən kəm!
Məcnun ilə Leylini bərabər
Gər kimsə deyərsə, qılma bavər!
Leylidə əgərçi dərd çoxdur,
Məcnuni-həzincə dərdi yoxdur.
Leyli əli ignədəndir əfgar,
Məcnuna qılıclar eyləməz kar.
Leyli istər ki, əksilə qəm,
Məcnun qəmin artırar dəmadəm.
Leylini edər hərir dilgir,
Məcnuna verər nişat zəncir.
Məcnundur olan qəmə giriftar,
Leyli kimə olmuş ola qəmxar?
Məcnuna yetər şikənceyi-təb,
Leyli kimədir təbib, ya Rəb?
Məcnundur əsiri-dami-Leyli,
Leyli kimə salmış ola meyli?"
Leyli tutub ol təranəyə guş,
Öz nəğməsin eylədi fəramuş.
Təhqiq ilə bildi bu hesabı
Kim, yox şərərində şö'lə tabı.
Əlbəttə, bəlavü dərdi gərdun
Məcnuna veribdir ondan əfzun.


110


**BU, LEYLİNİN İBNİ SƏLAMA**
**GİRİFTAR OLDUĞUDUR**
**və**
**YARDAN MƏHRUM VƏ**
**MÜQƏYYƏDİ-ƏĞYAR OLDUĞUDUR**

Me'mari-səraçeyi-ibarət
Böylə bu evi qılır imarət:
Kim, seyrdən olmayıb təsəlli,
Öz mənzilinə dönəndə Leyli
Vermişdi özünə dürlü zivər,
Hər zivərə bir nəticə müzmər.
Ta məhv ola gözdən axıdan xun,
Həm kömləyi, həm donuydu gülgun.
Ta kim, ola dudi-ahə manənd,
Bağlanmış idi bənövşə sərbənd.
Ta kim, ola sövti-nalə pamal,
Qullanmış idi sədalı xalxal.
Ta olmaya əşk üzdə məlum,
Rüxsarına lö'lö idi mənzum.
Rə'na başa sərpübən ləçəklər,
Nazik belə sancıban ətəktər,
Pərvanəsiz eyləməzdi şəm'in,
Eylərdi diri-sirişk cəm'in.
Rə'na-rə'na yürürdü ol mah,
Bir şəkl ilə kim, təbarəkəllah!
Ol əsrdə var idi ərəbdə
Bir mö'təbər əsldə, nəsəbdə.
Mənzuri-əazimü əali,
Məqbuli-əkabiri-əhali.
İdrakı büləndü hüsni dilkəş,
Ətvan xücestə, siyrəti xoş.
Vermiş Həq onun olan muradın,
Bəxt İbni Səlam qılmış adın.
Ol türfə hümayi-övci-İqbal,
Asudəzəmirü fariğülbal
Ov qəsdinə eyləmişdi pərvaz,


111


Altında üqab, əlində şəhbaz.
Bir rahgüzərdə ol nigarə
Uğraşdı vü qıldı bir nəzarə,
Canü cigərində qalmadı tab,
Mehv oldu, necə kim, odda simab.
Tərk etdi əziməti-şikan,
Gəldi evə, getdi ixtiyarı.
Tərh etdi binayi-resmi-peyvənd,
Tədbir ilə buldu bir xirədmənd
Kim, lütf ilə söz qılanda təqrir,
Təqriri verərdi daşə təğyir.
İn'am edibən ona bəsi mal,
Leyli tələbinə qıldı irsal.
Şərt eylədi ol büləndəxtər
Kim, olsa bu kami-dil müyəssər,
Sərf eyləyə gəncü mali-aləm,
Cananə yolunda, bəlkə can həm.
Çün gəldi bu razi-dil bəyanə,
Oldu ona razı atə-anə.
Ol Müştəriyə verildi Zöhrə,
Şayəstə görüldü Mah Mehrə.
Çün İbni Səlamə yetdi peyğam,
Tənbihi-nişatü müjdeyi-kam,
Dəryayi-nişatı gəldi mövce,
Baş çəkdi nihali-bəxti Övcə.
Məxzən-məxzən cəvahir açdı,
Xərmən-xərmən nisar saçdı.
Açdı dəri-gənci-gövhərü zər,
Fəqr əhlini eydədi təvangər.
Ol sərvin ayağı bağlı oldu,
Azado ikən adağlı oldu.


112


**BU, NÖVFƏLİN MƏCNUNLA**
**MÜQƏDDİMEYİ-İXTİLATIDIR**
**və**
**OL CƏVAHİRİ-PAKDAN İNBİSATIDIR**

Saqi, yenə qəsdi-can edər qəm,
Ver cam ləbaləbü dəmadəm!
Bikəs qalıbam məni-səbükray,
Sən eyləməsən mənə mədəd, vay!
Mən şiftənin pənahı olğıl!
Bikəslər ümidgahı olğıl!
Cəhd eyləvü qılma bir işə əhd,
Vər əhd eləsən, vəfaya qıl cəhd!
Şəmşiri-mübarizi-fəsanə
Bu rəzmdə böylə batdı qanə
Kim, var idi bir xücəstəfərcam,
Ol əsrdə adilü nikunam,
Tiğilə məsaf müşkili həll,
Mə'rufi-zəmanə, adı: Növfəl.
Həm eşq yolunda çox yügürmüş,
Həm çox sitəmi-zəmanə görmüş.
Bəzmində misali-dürri-məknun
Bir gün oxunurdu şe'ri-Məcnun.
Qayətdə bəyəndi tərzi-pakın,
Məzmuni-kəlami-suznakın.
Sordu sifətin, dedilər: "Ey şah,
Aşüftə qılıbdır onu bir mah.
Rüsvalıq edib özünə pişə,
Damü dəd ilə gəzər həmişə".
Növfəl qılıb arizuyi-Məcnun,
Əshab ilə qıldı əzmi-hamun.
Bir guşədə gördü zarü məhcur,
Halı nəsəqi-səlahdən dur.
Ətrafını teyrü vəhş almış,
Vəhşət onu bir həsarə salmış.
Çün daireyi-sibaü hail,
Qət' etdi, sipəh görüb səlasil.


113


Məcnuna yetişdi ol vəfadar,
Asari-tələttüf etdi izhar:
"K'ey xəstə, nədir bu çəkdigin rənc,
Viranədə zaye etdiyin gənc?!
Vəhşi nə bilir sənin məqamın?
Həmcinslərindən istə kamın!
Hal əhlisən, istə əhli-hali,
Səbralərə düşmə laübali.
Dövlət diləsən, hümaden istə,
Gənc istəsən, əjdəhadən istə!
Qəm çəkmə ki, mən olunca qəmxar,
Yarın sənə ənqərib olur yar.
Gər olsa zər ilə iş sərəncam,
Yük-yük tökəlim zər, alalım kam,
Vər olsa qərəz məsafə möhtac.
Biz qan tökəlim, sən eylə tarac.
Ancaq ola gör mənimlə həmdəm,
Mən kim səninəm, sənindir ol həm".


114


**BU, MƏCNUNUN NÖVFƏL İLƏ**
**DƏRDİ-DİL ƏDASIDIR**
**və**
**ŞƏRHİ-TƏFSİLİ-MACƏRASIDIR**

Məcnun dedi: "Ey yeganeyi-əhd!
Tədbirimə çoxlar etdilər cəhd,
Çox əhli-əzaim etdi tədbir,
Olmadı pəri bu divə təsxir.
Topraqlara töküldü çox zər,
Olmadı bi kimiya müyəssər.
Səndə bilirəm ki, lütf çoxdur,
Nə sud, çu məndə bəxt yoxdur?!
Sürmə, bilirəm ki, artırır nur,
Nə faidə, göz əgər ola kur?
İqbalıma yoxdur e'timadım,
Müşkül görünür mənim muradım.
Ah ər qılasan bu şüğlə iqdam,
Rə'yincə iş olmaya sərəncam,
Həm dustum olmaya mənə yar,
Həm düşmən ola nə dust kim var.
Bəxtim, bilirəm, mənim yamandır,
Sud istədigin mənə ziyandır.
Bəxtim sifətində bir qəzəl var
Daim qılıram mən onu təkrar:"

**BU QƏZƏL MƏCNUM-ZARİNDİR**

Vəfa hər kimsədən kim, istədim, ondan cəfa gördüm,
Kimi kim, bivəfa dünyada gördüm, bivəfa gördüm.

Kimə kim, dərdimi izhar qıldım, istəyib dərman,
Özümdən həm betər bir dərdə onu mübtəla gördüm.

Mükəddər xatirimdən qılmadı bir kimsə qəm dəfn,
Sefadan dəm uran həmdəmləri əhli-riya gördüm.


115


Əgər su damənin tutdum, rəvan döndərdi üz məndən,
Və gər güzgüdən umdum sidq, əksi-müddəa gördüm.

Ayaq basdım dəri-ümmidə, sərgərdanlıq əl verdi,
Hünər sərriştəsin tutdum, əlimdə əjdəha gördüm.

Mənə göstərdi gərdun tirə bəxtim kövkebin yüz gəz,
Məni-bədbəxt ona hər gah kim baxdım, qara gördüm.

Fizuli, eyb qılma üz çevirsəm əhli-aləmdən,
Nədən kim, hər kimə üz tutdum, ondan yüz bəla gördüm.


116


**BU, NÖVHƏLİN MƏCNUNA**
**ÜMİDVARLIQ VERDİGİDİR**
**və**
**HÜSNİ-MÜSAHİBƏTLƏ RİZASINA**
**GİRDİGİDİR**

Növfəl dedi: "Ey ədibi-kamil!
Feyzi-nəzərimdən olma qafil!
Lülahühəmd qeyrətim var,
Qeyrət qədərincə qüdrətim var.
Sən cəhd elə ki, yar ola əhl,
Çün yardır əhl, kardır səhl".
Məcnun həm ümid ilə olub şad,
Tərk etdi təriqi-təb'i-mö'tad,
Həm südi qübari-fərqi-geysu,
Həm eylədi qət' naxunü mu.
Həm cisminə verdi zibi-camə,
Həm başına zivəri-əmamə.
Bəzmi-tərəbi məqam tutdu,
Meyli-tərəb etdi, cam tutdu.
Növfəl həm olub mülazimi-əhd,
İmdadına qıldı can ilə cəhd.
Aldı ələ müşkbar xamə,
Leyli həşəminə yazdı namə:
"K'ey taifeyi-büləndpayə,
Biganəlik etmən aşinayə!
Edib məni iltifata məmnun,
Leylini edin rəfiqi-Məcnun!
Ol lalə isə, bu nəstərəndir,
Şümşad isə ol, bu narvəndir.
Ol buna bu onadır səzavar,
Ey əhli qərəz, nədir bu azar?!
Kam olsa nizasız müyəssər,
Ha, gənci-dürü xəzaneyi-zər!
Vər olsa bu xeyr işdə təxir,
Ha, tə'ni-sinanü zərbi-şəmşir!"


117


Ol qövmə çü rövşən oldu əhval,
Oldu bu cəvab olardan irsal
Kim: - "Bizdə cünun əlacı yoxdur.
Divanələr ehtiyacı yoxdur.
Gəncü dürə eyləmə təfaxür!
Bəsdir bizə gəncimizdəki dür!
Laf ilə qılıncdane urmağıl dəm
Kim, var qılıncımızğbizim həm!"


118


**BU, NÖVHƏLİN LEVLİ HƏŞƏMTLƏ**
**RƏZM ETDİGİDİR**
**və**
**RƏZMDƏ QALİB OLMAYIB**
**SÜLHƏ ƏZM ETDİGİDİR**

Novfəl ki, eşitdi bu cəvabı,
Tərk eylədi şahidü şərabı,
Cəm etdi sipahi-binəhayət,
Çaldırdı nəfırü çəkdi rə'yət.
Ol qövm bəm oldular xəbərdar,
Cəm eylədilər sipahi-xunxar.
Rəf oldu iki tərəfdən azərm,
Həngameyi-rəzmi etdilər gərm.
Bir sübh ki, qıldı xosrovi-Rum
Şam əhünə Hind fəthini şum;
Səyyarədən aldı mehr meydan,
Çaldı qılıncın, götürdü qalxan,
Gün xəncəri oldu aşikarə,
Gərdun zirehini etdi parə,
Şətrəncsifət ol iki ləşkər
Bir-birinə durdular bərabər.
Gəh nizə qılırdı cansitanlıq,
Gəh navək edərdi xunfeşanlıq.
Ol bənzər idi qədi-nigarə,
Bu qəmzeyi-dilfiribi-yarə.
Eylərdi zəbani-tə'ni-şəmşir
Əhvali-ədəm vücudə təqrir.
Əhvalına xəlqin ağlayıb zar,
Çeşmi-zireh olmuş idi xunbar.
Gürz ilə olurdu xürd hər su,
Cövşənlərü üstüxani-pəhlu.
Rəzm oldu bəla yağışlı bir miğ,
Rə'dü bərqi tüfəng ilə tiğ.
Göstərdi güzar gürzü peykan,
Qalxanda zireh, zirehdə qalxan.


119


Məcnun olara qılıb nəzarə,
Çəkmişdi özünü bir kənarə,
Durmuşdu ələmmisal bibak,
Bir ərsədə şərmsarü qəmnak.
Çəkmişdi bu ləşkər içrə rayət,
Ol ləşkər üçün dilərdi nüsrət.
Bunlar ilə hay-huy edərdi,
Fəth onlara cüstcuy edərdi.
Bu ləşkər ona müinü qəmxar,
Ol talibi-fəthi-ləşkəri-yar.
Gər öz sipəhində görsə məqtul,
Şükr eyləməyə olurdu məşğul.
V'ər görsə qətili-qövmi-dildar,
Dərd ilə qılırdı naləvü zar.
Səbzə kimi, olsa gər müyəssər,
Öz ləşkərinə urardı xəncər.
Bir kimsə dedi ki: "Ey siyəhruz!
Xəsmini dilərmi kimsə firuz?
Biz can qılırız yolunda pamal,
Sən düşmən üçün dilərsən iqbal?
Əqlə bu iş eyləməz dəlalət,
Gər aqil isən, nədİr bu halət?"
Məcnun dedi: "Mən fədayi-yarəm,
Vəslinə onun ümidvarəm.
Çün ləşkəri-yardır qılan rəzm,
Ol rəzmə nə layiq eyləmək əzm?
Çün dust sipahidir edən cəng,
Düşmənliyə xoş degildir ahəng.
Xoşdur ki, bulam vüsalə fürsət,
Yarım tərəfində ola nüsrət.
Canım ola dust dilpəziri,
Ya küştəsi ola, ya əsiri.
Bu mə'rəkədə nişatməndəm,
Ol silsilədə əsiri-bəndəm.
Müşkül işə olmuşam giriftar,
Əğyarım yarü yarım əğyar.


120


Gər qətlimə dust çəksə şəmşir,
Yox məndə rizadan özgə tədbir.
Xoşnud degilmiyəm bu halə
Kim, canı verəm, yetəm vüsalə?!"
Çün böylə cəvab eşitdi sail,
Ol fəzlü kəmala oldu qail.
Gəldikcə olub ziyadə aşub,
Az qaldı ki, Növfəl ola məğlub.
Əlqissə, müyəssər olmayıb kam,
Ol gün cədəl oldu sübh ta şam.
Çün oldu əyan təliəyi-şəb,
Meydani-sipehri tutdu kövkəb.
Asayişə hasil oldu fürsət,
Can almağa verdi mərg möhlət.
Hər səf bir arada tutdu mənzil,
Bir-birinə qondular müqabil.
Həmdəmlərə razın açdı Növfəl
Kim: "Müşküli-halımı qılın həl!
Mən əşcə'i-əhti-ruzigarəm,
Xurşidi-sipehri-karzarəm.
Yox kimsədə tabi-tiği-tizim,
Əndişeyi-taqəti-sitizim.
Bu rəzmdə bilməzəm nədir hal
Kim, fəthimə nüsrət eylər ehmal?
Əlbəttə ki, Həq rizasıdır bu,
Bir əhli-Həqin duasıdır bu".
Ərz eylədilər ki: 'Ey cahandar!
Məcnundan olubmusan xəbərdar?
Biz can qılırız onun fədası,
Ə'damızadır onun duası.
Biz qəsd edəriz onun muradın,
Ol düşmənə bağlar e'tiqadın".
Növfəl ki, eşitdi ol kəlamı,
Qalmadı ol əmrə ehtimamı.
Bilmişdi ki, sahibi-nəzərdir,
Əlbəttə, duası mö'təbərdir.


121


Bildi ki, müyəssər olmaz ol kam,
Tə'sir qılır dua sərəncam.
Çün vəsl degildi hökmi-təqdir,
Müşkül ki, əsər verəydi tədbir.
Vəhm etdi ki, mün'əkis ola hal,
Rəzmində mübarək olmaya fal.
Kirdarını görmədi münasib,
Nəzr etdi ki, gər olursa qalib,
Zikr etməyə dəxi Leyli adın,
Tərk edə bu əmr üçün inadın.


122


**BU, NÖVFƏLİN İKİNCİ NÖVBƏT**
**RƏZM EDİB QALİB OLDUĞUDUR**
**VƏ**
**FAYİ-ƏHDƏ KAZİB OLDUĞUDUR**

Çün tiğ çəkib mübarizi-Rum,
Şam əhlini etdi əmrə məbkum,
Fəth oldu sipahi-türkə mənsub,
Oldu ərəbin sipahı məğlub.
Adətcə yenə ol iki ləşkər
Rəzm etməgi etdilər müqərrər.
Tiğ aldı əlinə pəhləvanlar,
Başlar kəsilib töküldü qanlar.
Can eylədi tərki-xaneyi-tən,
Ol çıxmağa açdı tir rövzən.
Başlarda bəlanı çox görüb əql,
Bir özgə məqama eylədi nəql.
Peykan zireh içrə oldu peyvənd,
Gül şaxələrində qönçəmanənd.
Əlqissə, xilafi-rəzmi-əvvəl,
Ə'dayə müzəffər oldu Növfəl.
Xəsm etdi qəbul hökmi-taət,
Başlandı təzərrö'ü şəfaət.
Leylinin atası açdı başın,
Doldurdu gözünə qanlı yaşın,
Əcz ilə dedi ki: "Ey xudavənd!
Şahənşəhi-adilü xirədmənd!
Gər Leyli üçündür iztirabın,
İkrah ilə verməzəm cəvabın.
Əmma rəhü rəsmdir müqərrər,
Bir övrətə eybdir iki ər.
Leyli bu həşəmdə namizəddir,
Əqd ilə müqəyyədi-əbəddir.
Çün hökmün edər bu rəsmi pamal,
Bari, onu qeyrə vermə, sən al!
Gülbərgimizi həvaya vermə!
Namusumuzu fənaya vermə!"
Növfəl dedi: "Ey güzidə əşraf!


123


Yox məndə xilafi-ədlü insaf.
Mən məhz mürüvvətü vəfayəm,
Gəncineyi-gövhəri-ətayəm!
Bidadü sitəm degil şüarım,
Ədl içrə təmamdır əyanın.
Mən həm xəciləm bu macəradən,
Acizlərə qıldığım cəfadən.
Həqqa bu degildir e'tiqadım
Kim, hasil edəm mən öz muradım.
Bir sınmışa mumiya dilərdim,
Bir xəstə üçün şəfa dilərdim.
Gördüm görünür bu əmr müşkil,
Bimar degil əlaca qabil.
Bidaddən olmuşam peşiman,
Əfv edə məgər bu səhvi Sübhan.
Gəlməz gözümə əyalü malın,
Malın sənin olsunü əyalın.
Var, indi sen eymən ol xətərdən,
Minbə'd təvəhhüm etmə şərdən".
Bunu dedi, açdı aləti-rəzm,
Öz məmləkətinə eylədi əzm.
Məcnun dəri-e'tiraz edib baz,
Ol sərvərə tə'nə etdi ağaz:
"K'ey bihudə qövlünü qərarın!
Əhdində bumudur e'tibarın?
Nə faidə sikkəsiz dirəmdən?
Nə sud nəticəsiz kərəmdən?
Sayən uludur, vəli, nə hasil
Kim, feyz dəmində oldu zail".
Hər necə ki, etdilər müraat
Kim, "eyləyəlim buna mükafat,
Ondan yegin edəlim, sənə yar,
Asan işini gəl etmə düşvar!"
Mütləq əsər etmədi ona pənd,
Zənciri-həva qaçan tutar bənd?
Əfğan çəkib etdi xirqəsin çak,
Səhralara düşdü zarü qəmnak.


124


**BU, MƏCNUNUN ZƏNCİRƏ ÖZÜN**
**MÜQƏYYƏD ETDİGİDİR**
**və**
**BƏHANƏ İLƏ LEYLİ TƏRƏFİNƏ GETDİGİDİR**

Bir gün səhər ol mücaviri-dəşt,
Eylərdi güruhi-vəhşlə gəşt.
Bir piri-həzin göründü nagah,
Zəncirli bir əsir həmrah.
Məcnunun əsirə yandı canı,
Ol piri-həzinə sordu anı
Kim: "Bu nə əsirdir, bəyan et?
Cürmün məni-mücrimə əyan et!"
Sirri-dilin etdi pir rövşən
Kim: "Dustdur, degil bu düşmən.
Mən xəstəvü bəsteyi-əyaləm,
Fəqr ilə ikən şikəstəhaləm.
Bu həm məni-zardən betərdir,
Avarəvü xarü dərbədərdir.
Bir ruzi üçün olub füsunsaz,
Hər dəm qılırız füsunlar ağaz.
Ta hasil ola məaşi-ətfal,
Bir şö'bədədir bu gördüyün hal.
Bu, qanlılığa qılıbdır iqrar,
Mən eyləmişəm bunu giriftar.
Sahib diyətəm mənü bu xuni,
Gör vəchi-məaş üçün füsuni.
Ta kim, gəzib eyləyə gədalıq,
Bəndinə qıla girehgüşalıq;
Hər nə qazanır gəzəndə ev-ev,
Təqsim edəriz arada cöv-cöv.
Qismətdə həm etmişiz qərarı,
Mən yarıyamü bu şəxs yan!.
Məcnun dedi: "Səhv edibsən, ey pir!
Divanələrə gərək bu zəncir.
Gəl hacətimi mənim rəva qıl,
Bənd eylə məni, bunu rəha qıl!


125


Sayəntək olub səninlə həmseyr,
Mən əhli-kərəmdən istəyim xeyr.
Hər nə yığılırsa biş, ya kəm,
Varım sənə eyləyim müsəlləm.
Qəsdim bu ki, eyləyəm məni-zar,
Evdən-evə seyr Müştərivar.
Şayəd ki, bir evdə ola mümkün,
Ol Zöhrəyə olmağım müqarin".
Pir oldu ümidi-nəf ilə şad,
Əvvəlki əsirin etdi azad...
Zəncirə girib rəmid Məcnun,
Ərbabi-cünunə verdi qanım.


126


**BU, MƏCNUNUN ZƏNCİRƏ ŞƏRHİ-QƏMİDİR**
**və**
**BƏYANİ-SİLSİLEYİ-ƏLƏMİDİR**

Ol silsiləyə olub həmavaz,
Ağlardı ki, "Ey, mənimlə həmraz!
Sən gənci-bəlayə əjdəhasan,
Sərrişteyi-möhnətü bəlasan.
Şərhi-qəmə var min dəhanın,
Təprəndikcə çıxar fəğanın!
Başdan-əyağa dəlik-dəlik tən,
Könlündəki razı etdi rövşən.
Ey muntəziri-nəzareyi-yar,
Nəzzareyi-yarə min gözün var!"
Gəzmək həvəsilə xanə-xanə,
Ol pir ilə oldular rəvanə.
Tövfiq olub onlar ilə həmrah,
Leyli həşəmi göründü nagah.
Məcnun rəsəni əlində ol pir,
Ev-ev həşəmi gəzərdi bir-bir:
Leyli evinə irişdi növbət,
Ol xəstəyə qalib oldu heyrət.
Sərgəşteyi-aləm oldu pabest,
Meyxanə önündə düşdü sərməst.
Çün çəkdi bir ixtiyarsız ah,
Leyli ev içində oldu agah;
Bir ah ilə qıldı xeyməsin çak,
Məzlumuna açdı çeşmi-nəmnak.
Gördü ki, görünməz olmuş ol zar,
Olmuş qəm ilə zəifü bimar.
Qaşı kimi qaməti bükülmüş,
Yaşı kimi peykəri tökülmüş.
Cismi qəm içində can şəbihi,
Dərki, nəzəri, qəmi bədihi.
Didar ilə ol şəhi-lətafət
Mehmanına eylədi ziyafət.
Razi-dili-zarın etdi ifşa,
Bu şe'ri-bədihi qıldı inşa:


127


1 Nəyimiz



**BU QƏZƏL LEYLİ DİLİNDƏNDİR**

Yar rəhm etdi məgər naləvü əfğanimizə
Ki, qədəm basdı bu gün külbeyi-əhzanimizə?

Əşk baranı məgər qıldı əsər kim, nagah
Bitdi bir şaxi-güli-tazə gülüstanimizə?

Bizə ah atəşinin yandığı ondan bilinir
Ki, çirağ eylədi rövşən şəbi-hicranimizə.

Bu vüsalə yuxu əhvalı demək mümkün idi,
Əgər olsaydı yuxu dideyi-giryanimizə.

Bir xəyal olsa məgər gördügümüz, yoxsa nigar,
Mütləqa xatirə gəlməz ki, gələ yanimizə.

Yar mehmanımız oldu, gəlin, ey canü könül,
Qılalım serf nəmiz [1] var isə mehmanimizə!

Dilbərin canə imiş qəsdi, Füzuli, gəl kim,
Can verib dilbərə, minnət qoyalım canimizə.


128


**BU, MƏCNUNUN LEYLİYƏ MÜQABİL OLUB**
**ƏHVÄLIN BİLDİRDİGİDİR**
**və**
**FÜRSƏTLƏ RAZİ-PÜNHANIN**
**ƏYAN ETDİGİDİR**


Məcnun ki, ona nəzarə qıldı,
Razi-dilin aşikarə qıldı,
Çəkdi fələkə fəğanü ahı,
Sultanının oldu dadxahı:
"K'ey qədri bülənd padşahım,
Bildir mənə kim, nədir günahım?
Fərmana müxalifətmi qıldım?
Ə'daya müvafiqətmi qıldım?
Bədxahlərinmidir bu tədbir?
Qəmmazlərinmidir bu təzvir?
Mən mö'təqidəm bu asitanə,
Ya Rəb, nola rəddimə bəhanə?
Kimdəndir ola, bu məkrü hiylə,
Kim oldu ola buna vəsilə?
Ta xaki-dərindən olmuşam dur,
Aşüftəvü xəstəhalü rəncur,
Gahi çəkərəm şikənceyi-qəm,
Gahi oluram bəlaya həmdəm.
Tənha keçər oldu ruziganın,
Səhrada nə munisü nə yarım.
Sən xud gözəlim, qəmim yeməzsən,
"Ol şiftə qandadır" - deməzsən.
Məndən bu təğafülün əcəbdir,
Guya ki, nişaneyi-qəzəbdir.
Mən böylə neçün zəbunü xarəm,
Ha gəldim, əgər günahkarəm.
Çökdüm yerə gərdənimdə zəncir,
Bismillah, əgər olursa tə'zir,
Fərman səndən, qəbul məndən,
Olma, gözəlim, məlul məndən!


129


Zülfü müjə, xəncarü rəsən bəs,
Hökmünü yerit, həm asü həm kəs!
Gər arada bir qübar' qoyma,
Öldür məni, şərmsar qoyma!
Tə'zirimə eyləsən təəllül,
Lazım məni öldürər təğafül.
Ey laləüzarü ənbərin mu,
Gəncinəcəmalü mar geysu!
Ta zülfünə olmuşam giriftar,
Zənciri-cünuna rəğbətim var.
Qəm silsiləsinə paybəndəm,
Divanələr içrə sərbüləndəm.
Sövdadə dönüb ziyana sudim,
Peyvəstə bu şe'rdir sürudim:

**BU QƏZƏL MƏCNUN DİLİNDƏNDİR**

Küfri-zülfün salalı rəxnələr imanimizə,
Kafər ağlar bizim əhvali-pərişanimizə.

Səni görmək mütəəzzir görünür böylə ki, əşk
Sənə baxdıqda dolar dideyi-giryanimizə.

Cövrü çox eyləmə kim, olmaya nagəh tükənə,
Az edib, cövrü cəfalər qılıban canimizə.

Əskik olmaz qəmimiz bunca ki, bizdən qəm al
Hər gələn qəmli gedər, şad gəlib yanimizə.

Var hər həlqeyi-zəncirimizin bir ağzı,
Müttəsil verməgə ifşa qəmi-pünhnimizə.

Qəmi-əyyam, Füzuli, bizə bidad etdi,
Gəlmişiz əcz ilə dad etməgə sultanimizə.


130


**TƏMAMİYİ-SÜXƏN**

Bir ləhzə qılıb bu rəsmə fəryad,
Suitaninə zülmi-eşqdan dad,
Zəncirini etdi parə-parə,
Tutdu yenə xəlqdən kənarə.
Əndamı şikəstə, çeşmi nənmak,
Rüsvavü xərabü məstü bibak.
Ardınca qoşun-qoşun uşaqlar,
Əhvalına kim gülər, kim ağlar.


131


**BU, MƏCNUNUN KORLUQ BƏHANƏSİLƏ**
**DİLDAR CƏMALIN GÖRDÜGÜDÜR**
**və**
**DİDEYİ-ÜMİDİN TUTİYAYİ-MƏQSUDƏ**
**YETİRDİGİDİR**

Bir gündəxi ol bəhanəpərdaz
Bir özgə bəhanə qıldı ağaz:
Bağladı iki gözün ki, kurəm,
Əhvali-cəhanə bişüurəm.
Ərz eylədi zə'fü binəvalıq,
Ev-ev gəzib eylədi gədalıq.
Təqribilə əzmi-yar qıldı,
Leyli evinə güzar qıldı.
Ol dusta zahir eyləyib raz,
"Ya dust!" deyib, yetirdi avaz.
Leyli ki, eşitdi ol sədayı,
Bildi eşigindəki gədayı.
Evdən çıxıb etdi ərzi-didar,
Qıldı sədəqə zəkati-rüxsar.
Pünhan baxıban ol afitabə,
Məcnun yenə gəldi bu xitabə:
"K'ey xali-siyahı göz səvadı,
Can arizusn, könül muradı!
Gər bağlı isə gözüm rəvadır;
Sərçeşmeyi-ləcceyi-bəladır.
Bənd eyləməsəm önün dəmadəm,
Seylabə gedər təmami aləm.
Göz kim, seni eyləyib nəzarə,
Rüsva qılır əhli-ruzigarə,
Təhqiq edibəm ki, düşmənindir,
Mən qıydım ona, riza sənindir.
Dərgahinə bağladım gətirdim,
Baş üzrə əyağına yetirdim.
Ey qəmzəvü lə'li şəhdü şəmşir,
Xah əfv elə onu, xah tə'zir.
Dərgahinə gəldigimdə, ey hur


132


Sərmayə idi gözümdəki nur,
Ögrətdi mənə qəmin ticarət,
Yüz şükr ki, qılmadım xəsarət.
Göz nurini xaki-payə verdim,
Az cinsimi çox bəhayə verdim.
Şahim, nəzər et məni-gədayə,
Biganəlik etmə aşinayə!
Can bağına qəm nihalı dikdin,
Tən mülkünə dərd töxmü əkdin!
Ol töxmü nihalə nəf hasil
Oldu nəmi-əşkü suzişi-dil.
Gəl mülkünə, bağına güzər qıl,
Məhsulü mənafeə nəzər qıl".
Bunu deyib ol qəribü heyran
Tutdu rəhi-badiyə kəmakan.


133


**BU, İBNİ SƏLAMIN LEYLİ VƏSLİNƏ**
**RAĞİB OLDUĞUDUR**
**və**
**BU DƏ'VADA SÜBHİ-ÜMİDİ**
**KAZİB OLDUĞUDUR**

Saqi, bizə rahəti-rəvan ver,
Cansızlara himmət eylə, can ver!
Qıl məst bizi meyi-muğandan,
Əvvəl xoşü xürrəm eylə, ondan
Sor kim, necədir səbati-aləm,
Əncami-fərəh, nəhayəti-qəm.
Dünya işi e'tibarsızdır,
Çərxin rəvişi qərarsızdır.
Çox kimsənə gənc üçün çəkər rənc,
Qeyrinə onun nəsib olur gənc.
Gör onu ki, hər nihali-sərkəş
Sudəndirü sərf eylər atəş.
Təqdirədir əsli-əmri-mənsub,
Xoşdur bu ki, talib ola mətlub.
Çün İbni Səlam bildi hali,
Meydani-muradı gördü xali,
Cəm' etdi əkabirin diyarın,
Ə'yanını əhli-ruzigarın,
Göndərdi nikah üçün bəsi mal,
Şərt etdigin etdi cümlə İrsal.
Min zərrin nə'l, əsbi-tazi,
Misrivü İraqiyü Hicazi.
Min cariyəvü qulami-ziba,
Pirayələri hərirü diba.
Min naqə nəbatü qənd yüklü,
Nəsrin dərili, bənövşə tüklü.
Min təblə əbirü ənbərü müşk,
Yüz yük gühəri-tərü zəri-xüşk.
Əsbabi-nikah olub rəvanə,
Kabini kəsildi nəqdi-canə.
Leyli bu cəfadan oldu agah


134


Kim, buldu bəhanna xəzan rah.
Ümmidi-gözünə doldu topraq,
Məqsudi-nihali tökdü yapraq.
Əksi-qərəz oldu surəti-hal,
İdbarə mübəddəl oldu iqbal.
Gül istər ikən sataşdı xarə,
Nur istər ikən tutuşdn narə.
Əfğan ilə matəm etdi suri,
Matəmkədə məhfili-süruri.
Məşşatə dilərdi zülfü xalın
Artırmağa zib ilə cəmalın.
Ol ahü sirişk ilə dəmadəm
Xalı güm edərdi, zülfü bərhəm.
Əgməzdi hilalı vəsməyə baş,
Gözdən gedirərdi sürməsin yaş.
Geysusi çəkərdi şanədən sər,
Bir bar idi gərdənində gövhər.
Güzguyə kədər verərdi ahı,
Zülmati-xət istəməzdi mahı.
Pabusinə bulmayıb həna dəst,
Etmişdi onu qəm ilə pabəst.
Əklilə rüxü urardı atəş,
Buyi-xoş ona gəlirdi naxoş.
Tə'nə tikənindən etməyib bak,
Gül kimi qılırdı geydigin çak.
Hər ləhzə qılırdı ahü fəryad,
Derdi ki: "Əlindən, ey fələk, dad!
Səndən bumidi mənim muradım?
Dövranına bağlı e'tiqadım?
Vəslinə təvəqqe etdigim yar,
Billah, bu degil, yanılma, zinhar...
Ol - nəqşi-səhifeyi-vəfadır,
Bu - tərzi-cərideyi-fənadır.
Ol - qərqeyi-bəhri-zövqi-candır,
Bu - məhvi-tənə'ümi-cahandır.
Ol - xeyr yoluna rahbərdir,
Bu - başladığı təriqi-şərdir.


135


Cananəsi üçün ol dilər can,
Öz canı üçün dilər bu canan.
Mən onunam, ol mənim əzəldən,
Saxla bu əlaqəyi xaləldən.
Ey çərx! Bu əqd olanda möhkəm,
Bəlkə yox idin arada sən həm.
Gəl tərki-təğəllübü sitəm qıl,
Tanrını arada gör, kərəm qıl!
Vermə qəviyə zəif malın,
Düşmənlərə dustlar həlalın!
Məcnunumu sanma kimsədən kəm,
Bir mərdi-rəhi-bəladır ol həm.
Ey İbni Səlami-bisərəncam,
Bilsən sənə məkr edibdir əyyam;
Məcnuna qoyubdur ad - Leyli,
Eylər səni ad ilə təsəlli.
Sən kami-dil istə, mən bəlayam,
Sən gənc dilə, mən əjdahayam.
Əmma deməzəm işin xətadır,
Nisbət mənə qayəti-ətadır.
Qurtar məni atadan-anadan,
Bir qəm yey olur iki bəladan!"
Dərd ilə qılırdı naləvü ah,
Əsbabi-təcəmmülündən ikrah.
Dövrandan edib fəğanü fəryad,
Bu şe'ri oxurdu ol pərizad:

**BU QƏZƏL LEYLİ DİLİNDƏNDİR**

Xilafi-rə'yim ilə, ey fələk, mədar etdin!
Məni, gül istər ikən, mübtəlayi-xar etdin!

Müruri-ömrdə bir dönmədin muradımla,
Dönə-dönə mənə zülm etməyi şüar etdin!

İhanətimdə nədir, bilməzəm, muradın kim,
Əzizi-aləm ikən xarü xakisar etdin!


136


Ümidvar idim əvvəl ki, bir nişat görüm,
Binayi-möhnətimi indi üstüvar etdin!

Cəfa əlilə qılıb çak pərdeyi-səbrim,
Nihan olan qəmimi xəlqə aşikar etdin!

Vəfada verməgə can vermədin mənə möhlət,
Məni bu əhd vəfasında şərmsar etdin!

Bir özgəni mənə yar eyləməklə sən guya
Mənimlə yar olanı özgə ilə yar etdin!

Məgər bilindi, Füzuli, sənə fələk halı
Ki, varını bu cəhanın yox e'tibar etdin!

**TƏMAMİYİ**      - **SÜXƏN**

Ol növ görənlər iztirabın,
Təzyinü ciladən ictinabın.
Eylərlər idi güman ki, ol zar
Bir özgə bəlayədir giriftar.
Qılmışdır ol afitabı müztər
Hicrü-pədərü fəraqi-madər.
Dərlərdi: "Haqındır, ey səmənbu!
Tutmuşdun atan-anan ilə xu,
Hala ki, bulardan ayrılırsən,
Qürbət sitəm olduğun bilirsən!
Əfğaninə hiç mən' yoxdur,
Sən kimi yanan fəraqa çoxdur.
Əmma, bu imiş çü xəlqə adət,
Sən həm cəzə eyləmə ziyadət.
Qız daim ata evində qalmaz,
Peyvəstə anaya mehr salmaz.
Lazım meyi-qəflət eyləyib nuş,
Eylərsən atan-anan fəramuş.
" Leyli bu sözə qılırdı iqrar,


137


Deməzdi bir özgə möhnətim var.
Görməzdi onu özünə layiq
Kim, tə'nə edə ona xəlayiq.
Qız hər necə olsa yarə talib,
Əlbəttə, gərək həyası qalib.
Bir əhli-həya, min əhli-ibram,
Üsyan ilə olmaz iş sərəncam.
El tə'nəsi ilə xahü naxah,
Təklifə düşüb bəzəndi ol mah.
Ol ziynətü ziybə ziybü ziynət
Bir şəkl ilə verdi ziybi-surət
Kim, onu görəndə derdi gərdun:
İnsaf... kəmali-səbri-Məcnun!
Pirayəsiz ol məh idi afət,
Pirayədən artırıb lətafət,
Bir həddə irişdi afitabi
Kim, oldu niqab hüsni tabi.
Çün tutdu ərusi-xəlvəti-şam,
Təmkin ilə xəlvətində aram,
Zülmat ziyayə oldu qalib,
Yandırdı məşailin kəvakib,
Əncüm gühəri olub şəbəfruz,
Qıldı şəbi-tari qeyrəti-ruz.
Gülçöhrə sənəmlər oldular cəm',
Hər bir sənəmin əlində bir şəm',
Rəsmi-tərəb etdilər mürəttəb,
Beş yüz büti-gülrüxü şəkərləb.
Yüz qönçə dəhənli mahparə
Gül suyu səpərdi rəhgüzarə.
Yüz gülrüx əlində məcməri-ud
Eylərdi həvayı ənbəralud.
Yüz mahliqa olub qinasaz,
Qoşmuşdu sədayi-sazə avaz.
Yüz nərgisi-məst gəzdirib cam,
Əhbabə verərdi cami-gülfam.
Yüz gül başı üzrə yüz təbəq zər
Olmuşdu nisar üçün müqərrər.


138


Bir təxti-rəvan içində Leyli,
Nə şövkətə, nə şükuhə meyli,
Hər ləhzə fəğanü ah edərdi,
Sərgəştəvü müztərib gedərdi.
Əndişeyi-zövqü eyşdən pak,
Seylabdə san gedərdi xaşak.
Çün yetdi hərəmsərayə ol mah,
Dağıldı olan rəfiqü həmrah.
Gül xəivəti oldu səhni-gülzar,
Dur oldu büsatdan xəsü xar.
Bəxt İbni Səfamı etdi agah
Kim, oldu sənə müsəlləm ol mah.
Ol talibi-gövbəri-yeganə
Gövhər həvəsilə girdi kanə,
Nə gördü? Niqab içində bir nur,
Gözdən rüxi-dilfüruzi məstur.
Gərm oldu məhəbbətin məzaqı,
Təprəndi vüsalə iştiyaqı.
Əl urdu ki, aça ol niqabı,
Rəf eyləyə ortadan hicabı,
Leyli dedi: "Ey hərifi-qabil,
Sənsən sərü sərvəri-qəbail!
Övsafın eşitmişəm ziyadə,
Kamilsən ədəbdəvü həyadə.
Mə'lum edibəm ki, Qaf ta Qaf,
İnsafına el veribdir insaf.
Mən kim, degiləm qəni, fəqirəm,
Mehman deməyim, sənə əsirəm!
Zülm eyləmək etmə mən əsirə,
İzhari-tərəhhüm et fəqirə!
Gör canü tənimdə iztirabım,
Sor hali-dilim, eşit cəvabım!
Mən məktəbə getdigim zamanlar,
Hifzi-səbəq etdigim zamanlar;
Bir şəxs mənə göründü nagah,
Oldum pəri olduğundan agah.
Cinnilər içində ol pərizad


139


Ülfət mənim ilə qıldı bünyad.
Hər ləhzə durar mənə bərabər,
Der kim: "Bəniadəm etmə həmsər!
Yoxsa qılaram dəmində fani,
Bir zərb ilə həm səni, həm ani!"
Çox məkr qılındı, oldu tədbir,
Boynumdan alınmadı bu zəncir.
Dəf olmadı bu bəliyyə hərgiz,
Həm ata, həm ana oldu aciz.
Çün bulmadı kimsə çareyi-kar,
Məndən ata-ana oldu bizar.
Şeydalığım oldu aləmə faş,
Nifrət qılır oldu yarü yoldaş.
Sən həm ki, bizim diyara yetdin,
Əlbəttə, bu qissəni eşitdin.
Hala ki, səninlə düşdü bazar,
Oldun düri-əqdimə xiridar.
Qarşımda həm ol pəri durubdur,
Qeyrət qılıcına əl urubdur.
Tərk et ki, bu vəsl bimi-candır,
Həm özünə, həm mənə ziyandır!
Bir neçə zaman təhəmmül eylə,
Dərmanın elə, təvəkkül eylə!
Ola ki, müyəssər ola məqsud,
Səndən açıla bu babİ-məsdud.
Qət' ola zəbani-tə'ni-düşmən,
Həm sən yetəsən murada, həm mən.''
Ol sadəzəmir ona inandı,
Cinni xəbərin səhih sandı.
Vəhm etdi ki, olsa yara vasil,
Nöqsan ola canü caha hasil.
Cananə yolunda ömrü cahı
Ol naqisin oldu səddi-rahı.
Bir rəsmi-qədimdir cahanda:
Sud istəyən, istəmək ziyan da.
Canan diləyən cəfaya dözmək,
Gənc istəyən əjdəhaya dözmək.


140


Eşq əhli məhəbbət etsə izhar,
Əvvəl onu imtahan edər yar.
Gər görsə onun cəfaya səbrin,
Kəsrini edər təmam cəbrin.
Gör görməsə cövrə ehtimalın,
Salmaz ona sayeyi-vüsalın.
Çün İbni Səlama bimi-nöqsan
Ol vəsldə ruzi etdi hicran,
Meyl etmədi mütləq ol nigarə,
Hərgiz ona qılmadı nəzarə.
Tədbiri-əlaca durdu qaim,
Dərdinə dəva sorardı daim,
Hər qanda görərdi əhli-təsxir,
Divanəsinə dilərdi zəncir.


141


1 Ki etdin



**BU, ZEYD VƏFADARIN MƏCNUNA**
**XƏBƏR GƏTİRDİGİDİR**
**və**
**İBNİ SƏLAM İLƏ LEYLİNİN PEYVƏNDİ**
**MÜJDƏSİNİ YETİRDİGİDİR**

Sahibxəbəri-fəsanəpərdaz
Bu tərz ilə qıldı qissə ağaz
Kim, var idi bir nədimi-nadir,
Zeyd adlı, vəfayi-əhdə qadir.
Məşhur idi fəzlivü kəmalı,
Mə'ruf idi hüsnüvü cəmalı.
Olmuşdu əsir bir nigarə,
Büt ziybli Zeynəb adlı yarə.
Çəkmişdi məhəbbətin cəfasın,
Görmüşdü məlamətin bəlasın.
Ol aşiqi-müstəməndi-məhzum
Eylərdi həmişə meyli-Məcnun,
Söylərdi ona kəmali-eşqin,
Ustadına göstərərdi məşqin.
Leyli ərə getdigindən ol zar
Təhqiq ilə oldu çün xəbərdar,
Məcnuna özün yetirdi filhal,
Rəngi-rüxi-zərdi əşkdən al.
Dolmuş gözü, peykəri pozulmuş,
Nitqində təkəllümü tutulmuş.
Məcnun dedi: "Ey vəfalı yarım!
Qəm mərhələsində qəmgüsanın!
Adətcə görünməz ixtilatın,
Hər günküyə bənzəməz nişatın.
Noldu sənə, söylə, zar olubsan?
Bitaqətü biqərar olubsan?!
Əqrəbdə idi bu gün məgər mah,
K'etdin [1] bu yana əziməti-rah?
Qandan bu küdurət oldu hasis?


142


1 Ki əfganə



Noldu səbəbi-məlaləti-dil?"
Zeyd ol xəsi-xüşkə urdu atəş,
Suz ilə dedi ki: "Ey bəlakəş!
Dün əxtəri-bəxtin oldu tirə,
Dövran sitəm etdi sən fəqirə.
Yar İbni Səlamə ruzi oldu,
Ruzi sənə dərdü suzi oldu.
Yar özgəyə oldu şəm'i-məhfil,
Qaldı sənə tabi-atəşi-dü.
Əğyar ilə oldu yar Leyli,
Var, indi sən ondan ol təsəlli.
Zaye sənin ol fəğanü ahın,
Suzi-şəbü ahi-sübhgahın".
Məcnun ki, xəbərdən oldu agah,
Gərduna yetirdi şö'leyi-ab.
Vəhşilər içində ol giriftar
Bir dərd ilə qıldı naləvü zar
K'əfganə [1] gətirdi marü muri,
Ağlatdı vühuşi, həm tüyuri.
Xamə kimi yaş töküb dəmadəm,
Namə kimi qamətin qılıb xəm,
Yazdı alıban əlinə xamə,
Dildarma bir itabnamə.


143


**BU, MƏCNUNDAN LEYLİYƏ**
**BİR NAMEYİ-İTABAMİZDİR**
**və**
**PEYĞAMİ-ŞİKAYƏTƏNGİZDİR**

"Dibaçeyi-namə nami-Mə'bud,
Qəyyumü qədimü həyyü mövcud.
Ol perdəkəşi-hicabi-əsrar
Kim, aləmi yoxdan eylədi var.
Gün güzgüsün eyləyən mücəlla,
Dün türrəsin eyləyən mütərra,
Çün bir neçə həmd toxmun əkdi,
Dərdi-dilini bəyanə çəkdi
Kim, bu mütəhəmmili-bəladən,
Sərgəştəvü zarü mübtəladən
Bir namə ki, məhz dərdü qəmdir,
İzhari-şikayətü sitəmdir,
Ol dilbərə kim, vəfası yoxdur,
Bu aşiqinə cəfası çoxdur.
Ey əhdə vəfası olmayan yar,
Əğyarimə gül olan, mənə xar!
Noldu sənə nəqzi-əhd qıldın?
Sındırmağa əhdi cəhd qıldın,
Tənhalığıma gətirmədin tab
Kim, eylədin arizuyi-həmxab?
Tar oldumu olduğun nişimən
Kim, eylədin onda şəm' rövşən?
İncitdimi dərdi-dil məzacın
Kim, oldu təbibə ehtiyacın?
Pəjmürdəmi oldu sərvi-dücu
Kim, cəhdlə vermək İstədin su?
Bədxahını etdi qəsdi-gülzar
Kim, böylə uruldu rəxneyi-xar?
Nə bim ilə hifzi-gövhər etdin
Kim, bəsteyi-əqdi-şövhər etdin?
Mövcib nə idi məni unutdun,
Tərkim qılıb özgə yar tutdun?!


144


Hər ləhzə olub güvahi halım,
Xaki-dərinə sirişki-alım
Mütləq güzər eyləməzmi oldu,
Məndən xəbər eyləməzmi oldu?
Aya nə idi bu bivəfalıq,
Biganələr ilə aşinalıq?
Çəkdin yeni yarını kənarə,
Rüxsətmidir indi əski yarə?
Məndən idi möhnətü məlalın,
Xoş oldu ola onunla halın?
Mən əhdü vəfaya aldanırdım,
Əhdində vəfa ola, sanırdım.
Bilməzdim ola zəif rayın,
Nöqsanı ola təmam Ayın.
Göftarın ola mənimlə daim,
Könlün ola özgə ilə qaim.
Zahirdə mənimlə olasan yar,
Batində tutasan özgə dildar.
Səndən mən olam cahanda bədnam,
Bir namü nişanı yox ala kam.
Mə'zursan, ey nigar, mə'zur!
Bu dövr ilədir zəmanə məşhur.
Gül qönçəliyində xar iləndir,
Açılsa bir özgə yar iləndir.
Əslində tikan çəkər əzabın,
Fəslində həkim alır gülabın.
Ey arizuyi-dili-figanın,
Qəhri çoxü mehri az nigarım!
Ey adı olan vəfada məzkur,
Cismimdəki can, gözümdəki nur!
Sevdayi-dimağımın əlacı,
Bazari-cünunumun ravacı!
Sən mehrcəmalü məhcəbinsən,
Qayətdə lətifü nazəninsən.
Mən xarmizacü xak xuyəm,
Bəs tündzəban, tirəruyəm.
Sən hali-dil ilə eyləyib ar,


145


1 Əgər



Dersən ki: "Sənə nə nisbətim var?"
Mən həm sənə söylədim müvafiq
Kim, mən sənə, sən mənə nə layiq?
Mən xud olubam xəyala qane,
Sən layiqin istəsən, nə mane?
Əmma mənü səndən özgə çoxdur
Kim, sözləri bizdən özgə yoxdur.
Gördükdə mən eyləyən vəfayı,
Bildikdə sən eyləyən cəfayı,
Aya kimə bivəfa deyərlər?
Kimin işini xəta deyərlər?
Yaxşımıdır eyləmək yaman ad
Kim, qılmaya kimsə xeyr ilə yad?
Son gərçi tutub xilafi-adət,
Bir özgəyə bağladın iradət,
Çoxdur sənə mən kimi cigərxun,
Hər kimə ki, baxdın, oldu məcnun.
Mən kim, kəsəyin derəm səlamı,
Səndən çakəyin bu intiqamı,
Tutmaq dilərəm sənin kimi yar,
Əmma əcəb, ər [1] sənin kimi var?!
Peyvəndini qeyr ilə eşitdim,
Billah ki, bəsi təəccüb etdim.
Ey çeşmeyi-abi-zindəgani!
Sən canım içindəsən nihani!
Bir ləhzə gözümdən olmadın dur,
Vəslin necə oldu qeyrə məqdur?
Gər İbni Səlama nuri-Leyli
Bir vəch ilə eyləmiş təcəlli,
Leylidən olan xəyalı görmüş,
Öz vahiməsilə eyş sürmüş,
Leyli deməsin, mənə qərindir
Kim, ona xəyalı həmnişindir.
Məcnundan edərmi ol cüdalıq
Kim, qeyr ilə edə aşinalıq?


146


Ey gövhəri-tac, taci-tarək!
Məqsuduna yetdigin mübarək!
Əshab yığıb, tərəb qılıb şad,
Bu xeyr işi eyləyəndə bünyad,
Çox zövq ilə çəkdim intizarı
Kim, yad edesən məni-figan.
Sən xud demədin ki, bir qulum var,
Boynunda təriq ilə yolum var.
Gər sandın isə ki, bihüzurəm,
Şayisteyi -sərvəti-sürurəm,
Şərt idi mənə həm etmək e'lam,
Ta mən həm alam bu bəzmdən kam.
Lillahilhəmd əlim degil dar,
Can kimi nüquda qüdrətim var.
V'ər sandın isə ki, natəvanam,
Azürdeyi -möhnəti-cəhanam,
Həm şərt idi üzr qılmaq irsal,
Etmək məni bir soz ilə xoşhal.
Nə böylə edib, nə öylə, ey gul,
Yaxşımıdır eyləmək təğafül?!
Ey canım içində cana düşmən!
Hər necə ki, düşmənəm sənə mən,
Ayini-qədimini unutma!
Min yar tut, özgə xuy tutma!
Qeyr ilə olanda şadü xürrəm,
Təqribilə yad qıl bizi həm.
Nəqş et bu mürabbe'i hərirə,
Gör onu, bizi gətir zəmirə:

**MÜRƏBBE'**

Qeyr ilə hər dəm nədir seyri-gülüstan etdigin?
Bəzm edib, xəlvət qılıb, yüz lütfü ehsan etdigin?
Əhd bünyadın mürəvvətdirmi viran etdigin?
Qanı, ey zalım, bizimlə əhdü peyman etdigin!?


147


Ləhzə-ləhzə müddəilər pəndini guş eylədin,
Qanə-qanə qeyr cami-şövqümi nuş eylədin,
Varə-varə əhdü peymanı fəramuş eylədin,
Qanı, ey zalım, bizimlə əhdü peyman etdigin!?

Qeyrə salıb mehrini bizdən sovutdun aqibət,
Tərki-mehr etdin, təriqi-zülm tutdun aqibət,
Əhdlər, peymanlar etmişdik, unutdun aqibət,
Qanı, ey zalım, bizimlə əhdü peyman etdigin!?

Cürmümüz noldu ki, bizdən eylədin bizarlıq?
Biz qəmin çəkdik, sən etdin özgəyə qəmxarlıq?
Sizdə adət bumudur? Böylə olurmu yarlıq?
Qanı, ey zalım, bizimlə əhdü-peyman etdigin!?

Çərxtək bədmehrlik rəsmini bünyad eylədin,
Yaxşı adın var ikən, döndün yaman ad eylədin,
Dönə-dönə bizi qəmnak, özgəni şad eylədin,
Qanı ey zalım, bizimlə əhdü peyman etdigin!?

Könlümüz minbə'd zülfünçün pərişan olmasın,
Bağrımız lə'lin həvasilə dəxi qan olmasın,
Bivəfasan! Çeşmimiz yadınla giryan olmasın,
Qanı, ey zalım, bizimlə əhdü peyman etdigin!?

Və'deyi-vəsl ilə aldın səbrimiz, aramımız,
Olmadı bir gün vüsalından müyəssər kamımız,
Keçdi hicr ilə, Füzulidən betər əyyamımız,
Qanı, ey zalım, bizimlə əhdü peyman etdigin!?

**TƏMAMİYİ-SÜXƏN**

Payanə çü yetdi sə'yi-xamə,
Təslim olundu Zeydə namə.
Məktubla Zeyd olub səbükpər,
Əzm eylədi öylə kim kəbutər.


148


Çün yetdi nigar olan diyarə,
Məkr ilə vüsalə qıldı çarə.
Əfsun ilə urdu sehrdən dəm,
Ta İbni Səlamə oldu həmdəm.
Leylinin eşitdi vəsfi-halin,
Keyfiyyəti-möhnətü məlalin,
Dedi: "Bilirəm nədir dəvası,
Uş yazılı məndədir duası".
Bağlandı onun sözünə ixlas,
Xəlvətgəhi-qürbə qıldılar xas.
Çün Leyliyə Zeyd oldu vasil,
Məqsudini etdi bəxt hasil.
Bir dəm oturub gəlib qiyamə,
Əl urdu rəvan çıxardı namə.
"Tə'viz" dedi vü qıldı tə'zim,
Əvvəl öpüb ondan etdi təslim.
Çün naməni aldı Leyliyi-zar,
Ol namədən aldı buyi-dildar.
Bildi ki, bir özgə qeyddir bu,
Nə nüsxeyi-Əmrü Zeyddir bu.
Çün nameyə qaldı bir nəzarə,
Can kisvətin etdi parə-parə.
Ol feyzi bilib özünə iqbat,
Göz mərdümünə buyurdu filhal
Kim, dürr ala bəhri-çeşmi-tərdən,
Lə'l ala xəzaneyi-cigərdən,
Ol namənin eyləyə nisarın,
Əfzun edə qədrü e'tibarın.
Çün dürcdən aldı dürri-məknun,
Məktubu oxudu bildi məzmun,
Fəhm etdi məaniyü ibarət,
Bildi nəyədir olan işarət.
Canına qılıb itab tə'sir,
Ol namə cəvabın etdi təhxir.


149


**BU, LEYLİNİN MƏCNUNA**
**PEYĞAMİ-CAVABIDIR**
**və**
**ÜZRÜ İTABIDIR**

Bu tərz ilə kilki oldu cari
Kim, əvvəli-namə, nami-bari,
Me'mari-binayi-əqdü peyvənd,
Vəhhabi-ətayi-malü fərzənd.
İzhari-vücud edən ədəmdən,
İcadi-hüdus edən qidəmdən,
Məşşateyi-şahidi-zəmanə,
Sultani-bülənd asitanə,
Bu namə ki, bir figardəndir,
Yə'ni məni biqərardəndir,
Bir sahibi-izzü e'tibarə,
Yə'ni Məcnuni-dilfigarə.
Ey xakbüsati xarbastər,
Kami-dili-təngü dideyi-tər!
Hər tə'nə ki, eyləsən rəvadır,
Səndən xəciləm, üzüm qəradır.
Bəsdir mənə çəkdigim xəcalət,
Şərməndəligimdəki məlamət.
Çün mö'tərifəm ki, var günahun,
Öz lütfünü eylə üzrxahım.
Mən gövhərəm, özgələr xiridar,
Məndə degil ixtiyari-bazar.
Dövran ki, məni məzadə saldı,
Bilmən kim idi satan, kim aldı?
Olsaydı mənim bir ixtiyarım,
Olmaz idi səndən özgə yarım!
Gər töhmətə olmuşam giriftar,
İkrah ilə məndən olma bizar.
Bir dür degiləm ki, ola həkkak
Aldıqda təsərrüfündə çalak.
Gər ibni Səlamə dilfüruzəm,
Şəm'i-şəbü afitabi-ruzəm,


150


Qanedir iraqdan ala bir nur,
Mən ondanü məndətı ol ola dur.
Dur olsa görər furuğü tabım,
Olduqda yaxın, çəkər əzabım.
Fikr etmə ki, mən nişatməndəm,
Bir dami-qəm içrə paybəndəm,
Nə zəhreyi-seyri-kuçəvü kuy,
Nə tabi-təpançeyi-sərü ruy.
Gahi həvəs eyləsəm fəğanə,
Əvvəl ona istərəm bəhanə.
Ya atavü ana eylərəm yad,
Ya söhbəti-həmnişinü həmzad.
Ger rəxtimi etmək istəsəm çak,
Xəyyatına oluram qəzəbnak
Kim, eyblidir bu damənü ceyb,
Cəhd eylə ki, zahir olmaya eyb.
Gahi tələb eyləsəm vüsalın,
Bilmək diləsəm ki, noldu halın,
Bir çeşmə yana olub rəvanə,
Qüsli-bədən eylərəm bəhanə,
Tənha oluram orada üryan,
Muyı-sərim eylərəm pərişan,
Ayinədə eylərəm nigahi,
Halın görürəm sənin kəmahi.
Boynumda yox özgə tövqdən bar,
Lə'lımdə bulunmaz özgə göftar.
Boynum qolunu dilər həvadan,
Lə'lim ləbini sorar səbadan.
Candan qəmin içrə naümidəm,
Şəmşiri-cəfa ilə şəhidəm.
Qanlı kəfənimdir al pərdə,
Mən gurdəyəm, saqınma ərdə.
Gəl şəm'i-məzarım eylə ahın,
Zibi-ləhəd et qübari-rahın.
Mən bülbüli-baği-firqətəm zar,
Əmma qəfəs içrəyəm giriftar.
Bilmən bu qəfəsdə nola halım,


151


Sındırdı bəla pər ilə balım.
Bir vəhşi ilə gər etmişəm xu,
Müstövcibi-sərzəniş degil bu.
Vəhşilər imiş səninlə həmdəm,
Həmrəng olubam səninlə mən həm.
Ey aşiqi-müstəməndü məhcur,
Tutğıl məni-müstəməndi mə'zur!
Səbr et neçə gün, ola ki, gərdun
Bu günləri eyləyə digərgun.
Ancaq özünü nizar sanma,
Sərgəşteyi-ruzigar sanma!
Bu şe'ri gər oxusan dəmadəm,
Mə'lumun olur mənim qəmim həm:

**BU MÜRƏBBE' LEYLİ DİLİNDƏNDİR**

Giriban oldu rusvalıq əlilə çak, damən həm,
Mənə rüsvahğımda dustlar tə'n etdi, düşmən həm.
Rəhi-eşq içrə can qıldım giriftari-bela, tən həm,
Bu yetməzmi ki, bir dərd artırırsan dərdimə sən həm?

Əgər tutsam qəmim eldən nihan, səbrü qərarım yox,
Və gər şərhi-qəmi-pünhanım etsəm, qəmgüsanm yox,
Əsiri-bəndi-zindanəm, əlimdə ixtiyanın yox,
Bu yetməzmi ki, bir dərd artırırsan dərdimə sən həm?

Olubdur əşki-xunab ilə gülgun çöbreyi-zərdim,
Yanıbdır atəşi-hicranə cani-dərdpərvərdim,
Cəfayi-çərxi-kəcrəftar əlindən var min dərdim,
Bu yetməzmi ki, bir dərd artırırsan dərdimə sən həm?

Gəhi şövqi-vüsalü gəh bəlayi-hicr ilə zarəm,
Özüm həm bilməzəm dərdim nədir, mən necə bimarəm?
Qəmi-eşq içrə bir dərmanı yox dərdə giriftarəm,
Bu yetməzmi ki, bir dərd artırırsan dərdimə sən həm?


152


Cüda səndən bəlavü dərdi-hicran ilə tutdum xu,
Qılır hər dəm mənə bidad dord ayru, bəla ayru.
Bəlavü dərdə düşdüm, ruzigarım böylə, halım bu,
Bu yetməzmi ki, bir dərd artırırsan dərdimə sən həm?

Təbibi-eşqə çün izhar qıldım dərdi-pünhanı,
Məni-bimarə mütləq olmadı bir səhhət imkanı,
Əzəldən var min dərdim ki, yoxdur hiç dərmanı,
Bu yetməzmi ki, bir dərd artırırsan dərdimə sən həm?

Füzuli, hər zaman bir tə'n ilə bağrım qılırsan qan.
Əcəb, bilməzmisən kim, eşqdən keçmək değil asan?
Bilirsən, düşmüşəm bir dərdə kim, yoxdur ona dərman,
Bu yetməzmi ki, bir dərd artırırsan dərdimə sən həm?

**TƏMAMİYİ-SÜXƏN**

Yazıldı çü naməyə qəmi-dil,
Zeydə dedi: "Ey həkimi-kamil,
Tə'vizin ilə xoş oldu halım,
Zayil oluban qəmü məlalım.
Xəttin mənə nüsxeyi-səfadır,
Tə'vizin əsər qılır, duadır.
Hər gün gəlü yaz böylə tə'vid,
Ta səhhətə tutmaq ola ümmid.
Bir yazılı nüsxə var məndə,
Billah, belə al onu gedəndə.
Gərçi bilirəm onu ki, xətdir,
Bilməm ki, səhih, ya qələtdir.
İğlaqinə ver kəmali-izah,
Gər var isə səhvi, eylə islah".
Təqrib ilə verdi Zeydə məktub,
Böylə gərək əhli-əqlə üslub.
Məcnunə çü namə oldu vasil,
Dür gördü əqiqinə müqabil.
Məfhumdan etdi kəsbi-məqsud,
Leyli tərəfindən oldu xoşnud.


153


**BU, MƏCNUNU ATASI**
**SƏHRADA BULDUĞUDUR**
**və**
**NƏSİHƏTLƏ İSLAHINDAN**
**ACİZ OLDUĞUDUR**

Təhrir qılanda əhli-inşa
Böylə bu misalə çəkdi tuğra
Kim, qüsseyi-dəhr mübtəlası,
Məcnuni-şikəstənin atası
Qalmışdı məlamət içrə dün-gün,
Nə günü gün idi, nə dünü dün.
Getmiş idi əldən ixtiyarı,
Gündüz səbri, gecə qəran.
Qılmazdı tərəddüdündə təqsir,
Bulmazdı bu dərdə hiç tədbir.
Bir gün onu etdilər xəbərdar,
"Key piri-şikəsteyi-diləfgar!
Dün Leyli atası, ol siyəhdil,
Ol mün'imi-süflə, piri-cahil
Sərxeyli yanında dad edərdi,
Məcnımi-həzini yad edərdi
"Kim, bu dəli hökmə olmayıb ram,
Xəlqə bizi eylər oldu bədnam.
Peyvəstə bizə yetər bəlası,
Növfəl qəzəbindən et qiyası.
Hər necə ki, təndə canı vardır,
Namusumuza zıyanı vardır.
Çün məhz şər oldu zati-əf i,
Vacib gorünür müdam dəfi.
Namus bizim degil, sənindir,
Dəf eyləyə gör ki, düşmənindir."
Çün kim zərərində gördülər nəf,
Əzm eylədilər ki, edələr dəf.
Yadın degil, eylə oğlunu yad!
Qıl çarə ki, düşmən olmaya şad."
Ol pir düşüb min iztirabə,


154


Naçar özünü verib əzabə,
Səhralara tutdu seyltək ru,
Cəhd ilə yügürdü gəzdi hör su.
Manzü-mənzil sirişki qanın,
Rəhbər qılıb istədi nişanın.
Çün gecəyə gündüz oldu təğyir,
Oldu gecə zülməti cahangir.
Rəf' oldu əlameyi-mənazü,
Ol pirə tərəddüd oldu müşkil.
Sərgəştə gəzərkən eyləyib ah,
Bir şö'lə ona göründü nagah.
Ol pirin olub dəlili-rahı,
Ruz etdi ol od şəbi-siyahı.
Sandı odu yandıran ərəbdir,
Xeylü həşəm ol oda səbəbdir.
Pervanə kimi üz urdu narə,
Çün yetdi vü eylədi nəzarə,
Gördü ki, bu şö'lə bir nəfəsdir,
Nə şö'leyi-cirmi-xarü xəsdir.
Məcnunundur bu ahi-sərkəş,
Çəkmiş, urmuş cahana atəş.
Qət'i-nəzər eyləmiş cahandan.
Keçmiş sərü çeşmü cismü candan.
Nə mülk, nə mal cüstcusu.
Nə ata, nə ana arizusu.
Getmiş yelə bərgi-e'tibarı,
Ol qalmışü marg intizarı.
Ol pir çü gördü oğlu halın,
Tökdü rüxi-zərdə əşki-alın.
Yanında oturdu zarü qəmnak,
Əl urdu ki, çöhrəsin edə pak.
Ol şiftə açdı çeşmi-püməm,
"Kimsən - dedi, - ey mənimlə həmdəm?
Gər elçi isən, yetir pəyamın,
Ver müjdəsin ol məhi-təmamın!
V'ər yolçu isən, oturma qafıl,
Əzm eylə, gözət bir özgə mənzil!"


155


Ol pir təzərrö' etdi ağaz:
"K'ey nəqdi-həyata kisəpərdaz!
Mən dürcəmü sən düri-şəbəfruz,
Yə'ni atanam məni-siyəhruz!
Ey hasili-məzrəi-vücudim!
V'ey ömr xəsarətində sudim!
Ey cövhəri-canımın həvası!
V'ey dideyi-bəxtimin ziyası!
Derdim olasan mənim pənahım,
Fəxrim, şərəfim, ümidgahım.
Məndən bu sərir olanda xali,
Sən olasan əhli-mülkə vali.
Xəlq edə səni görəndə yadım,
Baqi sənin ilə ola adım.
Gər tifliliyində məstü bibak
Səhraya düşüb, yaxan qılıb çak,
Oldun rəhi-eşq içində məşhur,
Mə'zur idin ol zamanda, mə'zur!
Hər vəqtdədir bir əmr qalib,
Hər əhddədir bir iş münasib.
Növrəslərə eşq bir hünərdir,
Sərhəddi-kəmala rahbərdir.
Hala ki, məqami-əql buldun,
Təhsili-kəmala qabil oldun,
Səndən nə rəva bu macəralar,
Sərmayeyi-eyb olan sədalar?
Gər qafil idin, ol indi aqil,
Səhraləra düşmə, gəzmə qafil!
Vəhşilər ilə nədir bu birlik,
İnsan ilə xoş degilmi dirlik?
Vəhşi ilə vəhşi, teyr ilə teyr,
Həmcins ilə xoşdur eyləmək seyr.
Rəhm et məni-zarü namuradə,
Qoyma bu məşəqqətü bəladə.
Kafurvəş oldu mişki-nabım,
Bu sübhdə sənsən afitabıra!
Olmaq əlifim qərineyi-dal.


156


Meylim sinə olmağınadır dal [1] .
Dövran sitəmib canə yetdim,
Mən özgə diyar əzmin etdim.
Gəl, tapşırayım sənə məqamım,
Zəbt eylə büsatü ehtiramım.
Nə sud həmişə məstlikdən,
Nə faidə bütpərəstlikdən?
Ey məst, kəmali-hiddətindən
Yoxdur xəbərin qəbahətindən!
Ol ləhzə ki, huşiyar olursan,
Əlbəttə ki, şərmsar olursan.
Ey bütkədələr sənəmpərəsti!
Çün rəf ola bu hicabi-məsti,
Məzmum olub etdigin bu halət,
Əlbəttə, sənə yetər xəcalət.
Bir dilbərə ver könül ki, daim
Bünyadi-səbatı ola qaim.
Gər olsa yolunda bu cahan xak,
Damanı ola qübardan pak.
Sən seydi olan xücəstə şəhbaz
Hər ləhzə qılır bir əldə pərvaz.
Gəh Növfələdir mütii-fərman,
Gəh İbni Səlama munisi-can.
Sən - böylə bəlalara giriftar,
Ol - öylə çiraği-bəzmi-əğyar.
Şərm eylə bu eşqbazlıqdan,
Bifaidə cangüdazlıqdan!
Yoxdur çü bəqası ruzigarın,
Fərz eylə ki, oldu yar yarın,
Vəsl etmə onunla kim, bilirsən
Bir gün olur ondan ayrılırsan.
Tərk eylə bu hərzə-hərzə seyri,
Yad eylə ilahi, amma qeyri
Kim, nəfsə məadü mərcə oldur,
Qət' et ona söz ki, məqtə' oldur.


1 Yəni belimin bükülməsi qəbrə tərəf yaxınlaşmağıma dəlalət edir.


157


Həq sanei-dəhrü kargəhdir,
Bunda əməl etməmək günəhdir.
Hər kimsə gərək gələn məhəldə,
Bu kargəh içrə bir əməldə.
Hər kim nə əməl qılırsa bünyad,
Muzdunu verər əməlcə ustad.
Ey kargəhi-cahana daxil,
Sən həm əməl eylə, olma qafil!
Vəqt oldu səfər qılam cahandan,
Avarə olam bu xakidandan.
Vəqt oldu verəm fənaya təxtim,
Qədr ilə çəkəm bəqaya rəxtim.
Gəl yanıma, eylə fikri-halım!
Biganəyə vermə mülkü malım!
Çün onu yığınca çəkmişəm rənc,
Qıyma ki, nəsibi-qeyr ola gənc.
Eşqin bilirəm ki, böylə qalmaz,
Daim səni qəm bu halə salmaz.
Bəxtin oyananda bu yuxudan,
Hirsin yorulanda cüstcudan,
Qorxum bu ki, özgə ola halım,
Dünyada nə mən qalam, nə malım.
Bikəslik olub sənə müqərrər,
Bikəs olasan müdam, bizər.
Aqil kişi durbin gərəkdir,
Dünyada ümid bir dirəkdir."
Çün pəndi tükətdi ol xirədmənd,
Məcnuna təfavüt etdi ol pənd.
Dövlətli sözünə oldu mayil,
Bir fikr elədi ki, ola aqil,
Qət' edə səlasili-cünunu,
Sövdasının olmaya zəbunu,
Tərk eyləyə arizuyi-düdar,
Eşqə dəxi olmaya giriftar.
Əmma yenə eşq şəhriyarı
Fərmanına çəkdi ol figarı:
"K'ey varı olan mənim cahanda!


158


1 Nəyin



Nən [1] var sənin bu cismü canda.?
Cana təmə' etmə kim, mənimdir!
Tərk eylə təni ki, məskənimdir!
Məndən keçü canü təndən ayrıl!
Qoy varlığın, özünlə sən bil!"
Gülbün kimi qanı cuşə gəldi,
Bülbülsifəti xüruşə gəldi:
"K'ey eyni-səlah olan bəyanı!
V'əzi mənə afiyət nişanı!
Mən həm buna qailəm ki, pəndin,
Məzmuni-kəlami-sudməndin
Nisbət mənə xeyrdir, degil şər,
Gər olsa eşitməyi müyəssər.
Gərçi sözünə qulaq tutdum,
Nə sud, eşitdimü unutdum.
Sən demə ki, tut xəbər sözümdən
Kim, yox xəbərim mənim özümdən.
Eşq aldi dərinümü birunim,
Getdi yelə səbr ilə sükunim.
Mən əqlə təvəccöh eylərəm çox,
Sevda yolumu tutar ki: "Yox, yox!
Sən qandanü tərki-eşq qandan?
Eşqi-əzəli çıxarmı candan?"
Tə'nin sitəmilə cana yetdim,
Tərk eylə məni çü tərkin etdim!
Lütf eylə, zaman-zaman verib pənd,
İslahıma olma arizumənd!
Artar ələmim bu macəradan,
Atəş kimi cünbüşi-həvadan.
Bir şişə ki, oldu parə-parə,
Peyvəndinə hiç varmı çarə?
Təklifimi qılma xanimanə,
Gör sürəti-gərdişi-zəmanə.
Çün sən həm onu qoyub gedirsən,
Onda məni əyləyib nedirsən?


159


Ancaq mənə ərzü-mülkü mal et!
Oğlunu özün kimi xəyal et!
Fərz eylə ki, malə oldu vali,
Getdi, yenə qeyrə qoydu mali".
Ol kişvəri-eşq padişahı,
Ol övci-bəlavü dərd mahı
Üzr ilə qılırdı eyləyib ah,
Babasına şərhi-qəm ki, nagah
Lərzan oluban təni-həzini,
Qan doldu qolundan astini.
Əl verdi atasına təhəyyür,
Məcnun dedi: "Eyləmə təfəkkür!
Fəsd eylədi ol büti-pərizad,
Niş urdu onun qoluna fəssad.
Ol zəxm əsəri göründü məndə,
Biz bir ruhuz iki bədəndə.
Bizdə ikilik nişanı yoxdur,
Hər birinin özgə canı yoxdur.
Sən sanma ki, oldur ol, mənəm mən,
Bir can ilə zindədir iki tən.
Xürrəm oluram, ol olsa xürrəm,
Qəm yetsə ona, mənə yetər qəm".
Ol pir çü vaqif oldu hala,
İnsaf gətirdi ol kəmala.
Bildi ki, degil bu nəqş batil,
Olmaz hiyəl ilə eşq zayil.
Minbə'd nəsihət etməz oldu,
Tə'n ilə fəzihət etməz oldu.
Tərk etdi təriqeyi-nizain,
Nomid olub eylədi vidain.


160


**BU, MƏCNUN ATASININ**
**TƏRKİ-NİZA ETDİGİDİR**
**və**
**NAÇAR HƏSRƏTLƏ VİDA ETDİGİDİR**

"K'ey rişteyi-gövhəri-muradım!
Ayineyi-hüsni-e'tiqadım!
Bir ləhzə mənə tərəhhüm eylə,
Göftanm eşit, təkəllüm eylə!
Pərvayi-məni-şikəstəhal et,
Əzmi-səfər eylədim, həlal et!
Naxoş sənə məndən idi əhval,
Mən getməli oldum, indi xoş qal!
Zinhar şikayət etmə məndən,
İncikli hekayət etmə məndən!
Dirlikdə çü səndən almadım kam,
Tövsənliyə düşdün, olmadın ram.
Budur kərəmindən iltimasım
Kim, tutasan öldügümdə yasım!
Hər ləhzə edib fəğanü zari,
Toprağıma edəsən güzari.
Təklifi-nişatü eyş qılmən
Kim, sən deyəsən, "bu rəsmi bilmən".
Fəryadü fəğandır əsli-matəm,
Sən xud bu rəvişdəsen müsəlləm.
Öz adətin ilə nalə eylə!
Əcrini mənə həvalə eylə!
Budur qərəzim ki, dustu düşmən
Görsün səni, eyləyəndə şivən.
Bikəsligim olmaya mənə ar,
Mə'lum edələr ki, varisim var".
Çün qıldı vəsiyyət ol pərişan,
Döndi evə gəldi zarü giryan.
Dərdü ələm etdi onu rəncur,
Qalmadı həyatı şəm'inə nur.
Dərdinə bulunmaz oldu dərman,


161


"Məcnun!" dedi, verdi aqibət can.
Dünyaya ümid tutmaq olmaz,
Hərgiz ölümü unutmaq olmaz!
Xoş xaneyi-eyşdir bu aləm,
Dərda ki, degil əsası möhkəm.


162


**BU, MƏCNUNUN ATASI VƏFATINDAN**
**XƏBƏRDAR OLDUĞUDUR**
**və**
**MƏZARINA YOL BULDUĞUDUR**

Saqi, meyi-laləfam yoxmu?
Dözmən bu xumara, cam yoxmu?
Öldürdü məni qəmi-nihani,
Yoxdurmu şərabi-ərğəvani?
Qəm dəf inə, durma, eylə tədbir!
Əldən gələni gəl etmə təqsir!
Dünya ki, nigari-dilrübadır,
Zinhar, inanma, bivəfadır.
Sən gərçi olubsan ona məftun,
Oldur tələbində səndən əfzun.
Sənsən ona cəhl ilə tələbkar,
Oldur sənə elm ilə həvadar
Hər necə ki, ona mihmansan,
Eyşü tərəbilə kamiransan.
Ondan səfər ixtiyar edəndə,
Qürbi-Həqə üz tutub gedəndə,
Göz sürməsi eyləyib qübarın,
Ta məhşər olur nigahdarın.
Yolunda özün verər fənaya,
Saxlar, səni tapşırar bəqaya.
Həm kim ki, bu nüktədəndir agah,
Dövrani-fələkdən etmez ikrah.
Həm dirlikdə əzabı olmaz,
Həm mövtdən ictinabı olmaz.
Bir gün axıdıb sirişki-gülgün,
Nəcd üzrə oturmuş idi Məcnun.
Min tə'n ilə bir cofaçı səyyad
Ol zara yetişdi, qıldı fəryad:
"K'ey ardan el içində ari!
V'ey naqis olan əyari-kari!
Yox səndə nişani-namü namus,
Əfsus ki, arsızsan, əfsus!


163


İnsaf degil sitəmdə israf,
İnsafsız olduğuna insaf!
Dirlikdə atanı etmədin şad,
Ban qıl onu öləndə bir yad!
Can verdi məhəbbətində ol pir,
Yad eyləmədin, nədir bu təqsir?
Yoxdurmu cibillətində azərm?
Allahdan eyləməzmisən şərm?"
Məcnuna buraxdı ol səda suz,
Artırdı fəğanın ol siyəhruz.
Baran kimi daşa urdu başın,
Mey kimi əyağa tökdü yaşın.
Qəbrin sorub istədi nişanə,
Oldu gözü yaşıtək rəvanə.
Çün gördü atasının məzarın,
Şəm' eylədi ona cismi-zarın,
Tari-tənə dərdi tab verdi,
Dil atəşü didə ab verdi.
Lövh eylədi köksünü məzarə,
Dırnaq ilə qıldı parə-parə.
Bağrına basıb məzari-pakın,
Gül yarpağı etdi lövhi-xakın.
Əfğan ilə tazə qıldı matəm,
Əfganı içində dərdi hər dəm:
"K'ey baniyi-bünyeyi-vücudim!
Üsyanı ziyan, rizası sudim!
İrşadını bilmədim qənimət,
Yüz vay ki, fövt olundu fürsət.
Yüz heyf ki, tutmadım təriqin,
Bir neçə gün olmadım rəfiqin.
Feyzin mənə olmadı müyəssər,
Sən xeyr dedin, mən eylədim şər.
Cövr ilə sənə cöfalar etdim,
Yanlış vardım, xətalar etdim.
Ey dövlətim, olma dur məndən!
V'ey şəm', götürmə nur məndən!
Olsam qəmi-aləmə giriftar,


164


Ancaq sən idin ənisü qəmxar.
Həmrazım idin şikayətimdə,
Dəmsazım idin hekayətimdə.
Noldu qəmimə gətirmədin tab?
Qorxutdu məgər səni bu girdab?
Noldu səbəb, eylədin əzimət?
Məndənmi idi sənə həzimət?
Ey mənşei-cövhəri-həyatım,
Xoşnudluğundadır nicatım!
Bildim işimi, günahkarəm,
Gəldim sənə, xarü şərmsarəm.
Dünyada səni mən eylədim zar,
Üqbada məni sən eyləmə xar!
Yaxdın məni atəşi-cəfaya!
Saldın qəmü möhnətü bəlaya!
Sən məyü-fəraqü rahət etdin,
Bir küncü tutub fərağət etdin!
Kim eylədi həll müşkilatın?
Kim verdi bu qüssədən nicatın?"
Şəb ta səhər ol əsiri-hicran
Matəm tutub etdi ahü əfgan.
Çün mişkə töküldü gərdi-kafur,
Zülmata buraxdı pərtövün nur,
Ehya qılıban mərasimi-vəcd,
Tutdu rəhi-gurxaneyi-Nəcd.

**TƏMAMİYİ-SÜXƏN**

Ərbabi-kəmala ol əyandır
Kim, hüsn ilə eşq tovəmandır,
Hüsn ayineyi-cahannümadır,
Keyfiyyəti-eşq ona ciladır.
Hüsn olmasa, eşq zahir olmaz,
Eşq olmasa, hüsn mahir olmaz.
Hüsn olmasa, eşqdən nə hasil?
Mə'şuq edər əhli-eşqi kamil.


165


Olmaz isə eşq, hüsn olur xar,
Eşq ilədir əhli-husna bazar.
Мəcnun idi sam'i-məclisafruz,
Leyli ona atəşi-cigarsuz.
Məcnun idi cami-rahətəfza,
Leyli ona badeyi-müsaffa.
Leylidən idi kamali-Məcnun,
Hüsn ila olurdu eşqi əfzun.
Macnundan idi cəmali-Leyli,
Eşq idi edən camala meyli.
Bir gün Macnuni-dilşikəstə
Səhrada gəzirdi zaru xəstə,
Bir səhfədə gördü iki реуkər,
Leyli Мəcnun ilə müsavvar.
Məhv eylədi nəqşi-dilsitanın,
Qoydu özünün həmin nişanın.
Sordular ona həqiqəti-hal:
"Kim, nişə bir oldu iki timsal?"
Dedi: "Bizə birdürür həqiqət,
Birlikdə yaraşmaz iki surət.
Olmaq gərək ahli-danış agah
Kim, biz ikilikdəniz munəzzəh".
Sail dedi: "Bu degilmidir ar
Kim, yar ola yox, san olasan var?
Sən netə qalırsan, ol olur həkk?
Barı onu qoy, sənə qələm çək!"
Dedi: "Rəhi-eşqdə nə layiq
Məşuqə ola niqabi-aşiq?
Üşşaq tənü həbib candır,
Tən zahirü təndə can nihandır.
Mə'şuqə nə bak, olursa məstur,
Aşiq gerək el içində məşhur
Kim, aləmə aşiq axıdan yaş
Mə'şuq kim olduğun qılır faş".


166


**BU, MƏCNUNUN**
**ŞƏMMEYİ-KEYFİYYƏTİ-HALIDIR**
**VƏ**
**BƏ'Zİ SİFATİ-KƏMALIDIR**

Məcnun idi mulki-dərd şahı,
Xeyli-dədü dam onun sipahı.
Ahunun alırdı mişki-bacın,
Rubah səmurunun xəracin.
Bir sarvar idi kərimü adil,
Cumlə dedü damə adlı şamil.
Xuni-cigərindən ol vəfadar
Xunxarları qılırdı xunxar.
Xunabi-cigar töküb dəmadəm,
Qılmazdi siba' rizqini kəm.
Dövründə dərəndələr olub ram,
Tutmuşdu bir-birilə aram.
Gur olmuş idi pələngə həmraz,
Gürg olmuş idi gəvəznə dəmsaz.
Şir olmuş idi ənisi-nəxcir,
Nəxcir əmərdi şirdan şir.
Yaninda tutardi mur xana,
Goz yaşindan yigardi dana.
Gahi olub əşk seyli qaim,
Seylaba gedordi min bəhaim.
Gah odunu tando tab edərdi,
Min canavari kabab edərdi.
Bel olmuş idi alinda dırnaq,
Yerdən sovurardi başa topraq.
Muyinda qtibar olub fərahəm,
Əşк ilə çəkib zaman-zaman nəm,
Abubara sabzazari oldu,
Gulzari-сünun bahari oldu.
Gor tutsa idi gəvəzn ilə xu,
Axardi gözündən ol qədər su
K'ol sudan olurdu tazəvü tar,


167


Həm bərg verərdi şaxi, həm bər.
Hər ləhzə alıb əlinə bir mar,
Xürsənd oluban deyirdi ol zar:
"K'ol sünbüli-mişkbuyi tutdum,
Sərrişteyi-arizuyi tutdum".
Qaplan kimi cana urdu min dağ,
Arslansifəti uzatdı dırnaq,
Arslanların oldu pişvası,
Qaplanların oldu müqtədası.


168


**BU, MƏCNUNUN SİDQ İLƏ**
**MÜNACAT ETDİGİDİR**
**və**
**NAVƏKİ-DUASI HƏDƏFİ-İCABƏTƏ**
**YETDİGİDİR**

Bir gecə ki, zülməti-ziyasuz
Zülfi-şəbi etdi bürqeyi-ruz,
Bir lə'li edib sipehr nayab,
Göstərdi yerinə min düri-nab.
Bir sancağı eyləyib nigunsar,
Min məhçeyi-rayət etdi izhar.
Qətrə-qətrə həkimi-əflak
Xaşxaşlarında tutdu tiryak.
Danə-danə ərusi-gərdun
Qaftanına tikdi dürri-məknun.
Girdaba düşüb səfineyi-mah,
Qıldı özünə Məcərrədən rah.
Saçıldı Ütaridin rnidadı,
Artırdı bu sefhəyə savadı.
Zöhrə dağıdıb siyah geysu,
Geysusi içində gizlədi ru.
Xurşid nihan olub, sitarə
Göz açdı təriqi-intizarə.
Təprəndi səri-sinani-Bəhram,
Fəth oldu ona vilayəti-Şam.
Bərcis girib siyəh libasə,
Xurşid qəmində batdı yasə.
Ayinə olub sipehri-gərdan,
Baxdı ona, əks saldı Keyvan.
Gərduna səvabit oldu mismar,
Ta tökməyə dün büsati-pərgar.
Göydə Həməl oldu aşikarə,
Ahubərə çıxdı səbzəzarə.
Gavi-fələk oldu gavi-ənbər,
Doldurdu cahana ənbəri-tər.
Cövza kəməri mürəssə oldu.
Gərdun bədəni müfəmmə oldu.


169


Xərçəng qılıb səhər yelin dəf',
Xasiyyəti verdi zülmətə nəf.
Oldu Əsəd Afitabdan dur,
Pürdud misali-şəm'i-binur.
Geysusinə verdi Sünbülə tab,
Mişk üstünə tökdü ənbəri-nab.
Mizanı edib fələk tərazu,
Sərrafı-zəminə çəkdi lö'lu.
Əqrəb buraxıb kəməndi-pürxəm,
Divi-şəbə qıldı qeydi möhkəm.
Qövsini qurub sipehri-laib,
Atıldı xədəngi-nəcmi-saqib.
Büzğaleyi-asiman töküb mu,
Göy səhfəsin eylədi siyəhru.
Dəlvi dəlib afəti-zəmanə,
Min qətrə saçıldı asimanə.
Hut eylədi həbsi-Yunisi-ruz,
Bərqi-şəfəq oldu asimansuz.
Ərz eylədi Əxbəşə cinasın,
Cəbhə dəxi cəbhəsin ziyasın.
Həm Həq'ə cəmala verdi zivər,
Həm Hən'ə mükəlləl etdi əfsər.
Şərteynü Büteyn, Səmakü Əklil
Nur etdilər asimana təhvil.
Ta Sadirü Varidə, Nəaim
Sərf eyləyə sərf ilə dəaim.
Təzyin üçün etdilər mühəyya,
Lə'lin Dəbəran, dürün Sürəyya.
Verdi rəvişi-sipehrü əxtər,
Tərtibi-Müqəddəmü Müəxxər.
Məcnun mütəhəyyirü pərişan
Qalmışdı sipehr işində heyran.
Gərduna açardı dideyi-tər,
Yer üzünə doldurardı əxtər.
Hər əxtərə ərzi-hal edərdi,
Min arizuyi-məhal edərdi.
Əvvəl olub asimana mayil,
Şərh etdi Ütaridə qəmi-dil:


170


"K'ey əhli-hesaba karfərmay!
Müstövfiyi-əqlü məşrəfi-ray.
Ey nasixi-nüsxeyi-məani,
Fehristi-rümuzi-asimani!
Qəssami-məqasidü mətalib,
Rəssami-münasibü məratib!
Dərdi-düimin hesabı çoxdur,
Səndən özgə dəbir yoxdur.
Bir nameyə dərdimi rəqəm qıl,
Sultanıma ərzə et, kərəm qıl!
Şayəd əsər edə feyzi-xamən,
Tə'vizi-cünunim ola namən".
Gördü ki, Ütarid anlamaz raz,
Bir özgə tərənnüm etdi ağaz.
Döndərdi üz ondan ağlayıb zar,
Mərrixə niyazın etdi izhar:
"K'ey valiyi-məsnədi-şücaət!
Şəmşirinə aləm əhli-taət!
Sən sahibi-nüsrətü zəfərsən,
Ərbabi-silaha taci-sərsən!
Mən acızəmü qəvidir əğyar,
Mən bikəsü xəsmdir sitəmkar.
Acizlərə lütf edib mədəd qıl!
Bikəslərdən bəlanı rəd qıl!
Çək tiğini, eylə dəf i-düşmən,
Ta dusta həmnişin olam mən!"
Çün gördü bülənd yerdədir kam,
Nə Tir yetər ona, nə Bəhram.
Tiğ ilə qələmdən oldu nomid,
Tutdu rehi-barigahi-tövhid.
Dərgaha tutub rüxi-niyazın,
Mə'budinə ərzə qıldı razın:
"K'ey tiğə müinü kilkə rəhbər!
Bəhram - qulamü Tir - çakər.
Ey fərqi-əməl külahduzi,
Sahibrəqəmi-bərati-ruzi!
Rəhm et məni-zarü binəvayə,
Dərdi-düimi yetir dəvayə!


171


Leyliyi sən eyfədin pərivəş
Kim, cana cəmah urdu atəş.
Sən qıldın onu bəlayi-aləm,
Ol etdi məni şikəsteyi-qəm.
Verdin ona hüsni-aləməfruz,
Saldı mənə atəşi-cahansuz.
Dərd ilə məni sən eylədin zar,
Mən qandanü Leyliyi-cəfakar?
Leyli ki, məni bəlaya saldı,
Bir görmək ilə qərarım aldı.
Yoxdur rəvişində ixtiyarı
Kim, döndərə aldığı qərarı.
Biçarədir öz işində ol həm,
Səndən bulunur bu zəxmə mərhəm.
Həm sən kərəmindən et əlacım,
Kəs qeyri kişidən ehtiyacım!
Ey dərdə qılan məni giriftar!
Kimdir mənə səndən özgə qəmxar?
Çox-çox hükəmaya söylədim hal,
Təşxisi-mərəzdə oldular lal;
Bildim ki, həkimi-fərd sənsən!
Danayi-cəmii-dərd sənsən!
Gər dərd və gər dəva sənindir!
Hakim sənsən, riza sənindir.
Yə'ni ki, gətir kəmala zövqüm,
Gündən-günə qıl ziyadə şövqüm!
Sal çeşmimə lə'linin xəyalın,
Ver təb'imə hüsnünün kəmalın.
Daim onu məndə zahir eylə,
Lütf et, iki surəti bir eylə!
Qədrim, qəmi içrə mö'təbər qıl!
Dərdin, mənə ruzi ol qədər qıl!
Kim, kimsəyə ol olub müyəssər,
Kimsə mənə olmaya bərabər.
Görmək rüxün olmaz olsa məqdur,
Xunbar gozümdə olmasın nur.
Zövqi-ələmi olursa nayab,
Məcruh tənimdə olmasın tab.


172


1 Ki açdı



**BU QƏZƏL**
**MƏCNUNİ-HƏZİN DİLİNDƏNDİR**

Ya Rəb, kəmali-mərtəbeyi-Mustəfa həqi!
Sidqü səfayt-silsileyi-ənbiya həqi!

Səndən yetər vəlilərə tə'yidü iqtidar,
Sən müqtədayi-aləm edən rəhnüma həqi!

Düşməz hərimi-qürbünə biganələr yolu,
Ol barigahə məhrəm olan aşina həqi!

Qəhrindəki siyasətü asibü xövf üçün,
Lütfündəki lətafəti-feyzü rəca həqi!

Üşşaqə yar qıldığı cövrü cəfa üçün,
Mə'şuqə aşiq etdiyi mehrü vəfa həqi!

Leylidə zahir eylədigin feyzi-hüsn üçün,
Məcnuna verdigin qəmü dərdü bəta həqi!

Fəqrü fəna səadəti lütf et Füzuliyə,
Onda olan səadəti-fəqrü fəna həqi!

**TƏMAMİYİ-SÜXƏN**

Eylərdi bu suz ilə münacat,
Möhnətlərə istəyib mükafat.
K'açıldı [1] güli-hədiqeyi-ruz,
Göstərdi günəş cəmali-firuz.
Mürği-dəmi-sübh çəkdi avaz,
Zaği-şəbi-tirə qıldı pərvaz.
Həm səfheyi-aləm oldu rövşən,
Həm daneyi-əncüm oldu xərmən.


173


Gün ayinədarı oldu gərdun,
Tökdü qədəminə dürri-məknun.
Sübh urdu səfayi-sidqdən dəm,
Açıldı güli-nişati-aləm.
Tə 'siri-səfayi-cami -Xurşid
Göy gülşənin etdi bəzmi-Cəmşid.
Lalə kimi dağə çıxdı Məcnun,
Nəzzarəyə açdı çeşmi-pürxun.
Gördü ki, gəlir nədimi-kamil,
Həmrazi-qədim, Zeydi-qabil.
Rüxsarında nişatdən nur,
Behcət gözünə cəmah mənzur.
Yox zərrəcə qüssəvü məlalı,
Məcnuna əcəb göründü hali.
Sordu ki: "Nədəndir inbisatın?
Adətcə görünməyən nişatın?
Məqsudinə dəstrəsmi oldun?
Dildarinə həmnəfəsmi oldun?
Nə qədr ilə sərbülənd olubsan?
Noldu ki, nişatmənd olubsan?"
Zeyd açdı düri-xəzaneyi-raz:
"Key türfə hümayi-övci-e'zaz!
Dün tövfi-diyari-yar qıldım,
Ol sərv yana güzar qıldım.
Tə'viz vəsiləsilə bir dəm
Oldum hərəmi-vüsala məhrəm.
Gördüm məhi-arizin ziyasız,
Ayineyi-təl'ətin cilasız.
Nə lə'li-ləbində qətreyi-ab,
Nə mah rüxündə zərreyi-tab.
Lə'li-tərə əşki gövhərəngiz,
Bərgi-gülə nərgisi gühərriz.
Gördü məni etdi naləvü zar,
Raz açdı mənə ki: "Ey vəfadar!
Düşdü ola Nəcdə rəhgüzarın,
Gördün ola halın ol figarın?


174


Məcnunumu gördün isə, billah,
Eylə məni-zarı ondan agah!
Necə keçər ola mahü salı,
Kim ola rəfiqi, nola halı?
Billah, güzər etsin ol yanaya.
Rəhm et məni-zarü mübtəlaya,
Məndən ona şərhi-zə'fi-hal et!
Halın məni-xəstədən sual et!
Söylə, necəsən hücumi-qəmdən?
Tüğyani-məşəqqətü sitəmdən?
Matəmzədə olduğun eşitdim,
Qıldım yaxa çakü şivən etdim.
Ol sərv ki, çıxdı bu çəməndən,
Məngən getdi, degil ki, səndən.
Ancaq bir ol idi kim, çəkib qəm,
İstərdi məni səninlə həmdəm.
Çox gördü bizə sipehri-qəddar
Yüz min əğyar içində bir yar.
Bir zülmdürür bu aşikarə,
Əldən nə gəlir, buna nə çarə!
Bu dərdi ki, az degil, yügüşdür,
Həm səbr edəlim ki, səbr xoşdur.
Mən, tut ki, müqəyyədi-həsarəm,
Məhbusi-hicabi-nəngü arəm.
Gər şəm'ə açılsa şərhi-razım,
Sayəmdən olur min ehtirazım.
Gər sayəmə söyləsəm qəmi-dil,
Şəm'in həsədi gəlir müqabil,
Nə yazmağa namə ixtiyarım,
Nə etməyə ərz razdarım.
Qönçə kimiyəm məni-pərişan,
Ağzım tutulu, içim dolu qan.
Sən kim, şəhi-kişvəri-rizasan,
Hər kimə dilərsən aşinasan.
Yox hökmü sənə çü xamə qeyrin,
Öz başınadır həmişə seyrin.


175


Aya nə üçün qılırsan ehmal,
Hali-dilin eyləməzsən irsal?
Öz nəzmi-lətifü dilkəşindən,
Məzmuni-ibarəti-xoşundan
Lütf ilə qılıb həmişə təhrir,
Göndərmədigin degilmi təqsir?
Səndən degiləm bu işdə razi,
Hala kərəm et xilafi-mazi,
Nəzm eyləyibən bəyani-halın,
Şərhi-rüxi-zərdü əşki-alın,
İrsal edə gör məni-həzinə,
K'ol cövhərə can edim xəzinə.
Əlfazi olub həmişə zikrim,
Bu kargəh içrə bikri-fikrim.
Tərzi-qəm edəndə cana təsvir,
Ol nəqşdən ola çaşnigir".
Həm hali-dilin qılırdı izhar,
Həm bu qəzəli qılırdı təkrar:

**BU QƏZƏL LEYLİYİ-DİLPƏZİRİNDİR**

Neçün ol şəm' kafur üzrə kilkin mişkbar etməz?
Yazıb bir rüq'ə min lütfə bizi ümmidvar etməz?

Mənimlə dust lütfün az edib, çox tə'n edər düşmən,
Neçün lütf eyləyib, düşmənləri bir şərmsar etməz?

Gəl, ey göz, yar xəttin namədə görmək həvəs qılma
Ki, xətti-namə dəf i-dərdi-hicri-xətti-yar etməz!

Kəbutərdən umardım naməsin, gör zəf tale kim,
Görüb ahım odun məndən yana ol həm güzar etməz.

Füzuli, nameyi-dildar bir tə'vizdir guya
Kim, onsuz xəstədillər xatiri bir dəm qərar etməz.


176


**TƏMAMİYİ-SÜXƏN**

Məcnun ki, eşitdi ol pəyamı,
Bəxti-mütəmərrid oldu rami.
İqbalına e'tiqadı oldu,
Dildarına e'timadı oldu.
Xunabi-sirişkdən çəkib nəm,
Gülzari-zəmiri oldu xürrəm.
Həm güldü üzü çırağlartək.
Həm könlü açıldı dağlartək.
Zeydə dedi: "Ey rəfiqi-sadiq,
Mən vəhşiyə həmdəmi-müvafiq!
Çün müjdeyi-mərhəmət yetirdin,
Yarım xəbərin mənə gətirdin,
Məndən həm ona yetir sənalar,
Ərz eylə dürudlar, dualar.
Xaki-dərinə yetir niyazım,
Dərgahinə ərz eylə razım:
"K'ey canıma dadlu dərdü dağı,
Könlüm fərəhi, gözüm çırağı!
Lillahülhəmd yar imişsən,
Mən istədigimcə var imişsən.
Əhdində vəfa bulundu axır,
Şəhdində şəfa bulundu axır.
Bildim ki, məni sevirsən, ey mah!
Əhsənt, əhsent, barəkallah!
Lütfün xəbəri qərarım aldı,
Şirin sözün ixtiyarım aldı.
Lütfün eşidib olur cigər tab,
Şirin sözünə gətirməzəm ab.
Ah, ər qılıb özgə rəsm bünyad,
Nagəh tutasan təriqi-bidad,
Təlx ola sözün misali-badə,
Lütf olmaya, qəhr ola aradə.
Xuban işi cövr ilə cəfadır,
Səndən görünən mənə vəfadır.
Qurban sənə özgə nazəninlər,


177


İdrakına yüz min afərinlər!
Kimsə çü sənə vəfada yetməz,
Canın sənə kimsə versə itməz.
Mə'şuqə ikən olub vəfadar,
Aşiqligini həm etdin izhar.
Aşiq der imiş mənə xəlayiq,
Görmən buna həm özümü layiq.
Mən naqisəm, ey harifi-qabü,
Sənsən rəhi-eşq içində kamil.
Təhsin ki, yeganeyi-zəmansan,
Can vermək olur sənə ki, cansan.
Hər şuxdə gər olaydı bu tövr,
Sən olmaz idin yeganeyi-dövr.
Ger qeyrə bu hal olaydı məqdur,
Sən olmaz idin cahanda məşhur.
Yad eyləməgindən olmuşam şad,
Sən şad olasan həmişə, mən yad.
Ha böylə məni-həzini şad et!
Gah-gah tərəhhüm eylə, yad et!
Ey sərvi-səmənbəri-güləndam,
Taraci-mətai-səbrü aram!
Ey xosrovi-kişvəri-məlahət,
Məhtabi-şəbi-nişatü rahət!
Çün bəndəyə rəhmət eylər oldun,
İzhari-məhəbbət eylər oldun,
Minbə'd təriqi-mehr tutğıl,
Əvvəlki təriqini unutğıl!
Qoyma çıxa həsrət ilə canım,
Həddən ötə naləvü fəğanım!
Meyli-məni-zarü biqərar et,
Gahi bu yanaya bir güzar et.
Həmdərdim isən, mənimlə yar ol,
Həmdərdligin yox isə, var ol!
Sən - öylə müqimi-məsnədi-naz,
Mən - böylə bəlavü dərdə dəmsaz.
Sən - məhfili-eyş kamikarı,
Mən - guşeyi-dərd dilfigarı.


178


Eşq içrə, gözüm, rəvamıdır bu?
Rahü rəvişi-vəfamıdır bu?
Gər doğru isə vəfada lafın,
Məndən nə üçündür inhirafın?
Gəl, rəf edəlim qəmi-fəraqı,
Yandıralım oda iştiyaqı,
Olsun dünü gün mənimlə seyrin,
Çün mən səninəm, sən olma qeyrin!
Vər İbni Səlam mane olsa,
Səddi-rəhi-vəsl vaqe olsa,
Bildir, qılayın siyah bəxtin,
Bir ah ilə tarümar təxtin".
Çün razi-dilin tükətdi ol yar,
Zeyd eylədi əzmi-kuyi-dildar.
Pərvanə sözün deyib çirağə,
Bülbül xəbərin yetirdi bağə.


179


**BU, İBNİ SƏLAMIN**
**KEYFİYYƏTİ-VƏFATIDIR**
**və**
**LEYLİNİN OL BƏLADAN**
**NİCATIDIR**

Saqi, fələkin gör inqilabın!
Göstər qədəh içrə mey hübabın!
Mey ayineyi-cahannümadır,
Xaki zər edən bu kimiyadır.
Bu faidə bəs degilmi ondan
Kim, fariğ edər qəmi-cahandan?
Bir xabü xəyal imiş bu aləm,
Bu xabü xəyala olma xürrəm!
Əhvali-zemanə münqəlibdir,
Ondan xirəd əhli müctənibdir.
Qəm matərain eyləyəndə bünyad,
Neyyah bu növ çəkdi fəryad
Kim, İbni Səlamı etdi gərdun
Amaci-xədəngi-ahi-Məcnun.
Ol səddi götürməgə aradan,
Əşk oldu rəvan iki yanadan.
Ol növrəsi-natəvan, dəmadəm
Şövq ilə çəkərdi möhnətü qəm.
Həsrət ələmi yaman ələmdir,
Qəm bödriqeyi-rəhi-ədəmdir.
Dərdü qəmi-həsrəti-nihani
Sərvi-qədin etdi xizərani.
Üz urdu pozulmağa tilismi,
Bir qayətə yetdi zə'fi cismi
Kim, peykəri nəqşi-bəstər oldu.
Rə'na qədi bəstər istər oldu.
Gün-gündən olub xərab halı,
Qalmadı sağalmaq ehtimalı.
Dərdinə dəva bulunmaz oldu,
Rəncinə şəfa bulunmaz oldu.


180


Əndişeyi-ömrü oldu batil,
Catı verdivü Həqqə oldu vasil.
Kimdir ki, gəlib cahana getməz?
Kim kamil olur, o zavala yetməz?
Budur rəhü rəsmi ruzigarın
Kim, ola xəzanı hər bəharın.
Leylini gətirməgə fəğanə,
Ol vaqeə oldu bir bəhanə.
Matəm tutub etdi ol giriftar,
Dırnağı ilə üzünü əfgar.
Çak etdi fərağət ilə camə,
Faş etdi fəğanı xasü amə.
Yandırdı evin, qopardı təxtin,
Taraci-fənaya verdi rəxtin.
Geysuyi-müənbər etdi bərbad,
Əflaka yetirdi ahü fəryad.
Gərdun kimi rəxti niylə urdu,
Atəş kimi başa kül sovurdu.
Derlər, bu idi ərəbdə adət
Kim, ər əgər ölsə, qalsa övrət,
Bir il, iki il tutardı matəm,
Fəryadü fəğan edib dəmadəm.
Xoş gəldi bu adət ol nigarə,
Fəryadü fəğana buldu çarə.
Matəmkədə eylədi məqamın,
Matəmdə keçirdi sübhü şamın.
Bir neçə gün onda ağlayıb zar,
Həm ata evinə döndü naçar.
Əmma dünü gün fəğan edərdi,
Xunabi-cigər rəvan edərdi.
Fəryadə gələndə gahü bigah,
Öz könlündə deyərdi ol mah
Kim: "İbni Səlama rəhməti-Həq,
Eşqim ravişinə verdi rövnəq.
Rəf eylədi pərdeyi-müdara,
Pünhan qəmim etdi aşikara".


181


Ol vaqeəden olub xəbərdar,
Tutdu rəhi-dəşt Zeydi-qəmxar,
Gördü ki, şikəstəhal Məcnun
Durmuş dədü dam içində məhzun,
Çün verdi səlara, qıldı e'lam
Kim, İbni Səlama netdi əyyam.
Verdi bu qəziyyədən bəşarət
Kim: "Qıldı müarizin xəsarət.
Dəhr İbni Səlamı qıldı pamal,
Leyİi öz evinə döndü xoşhal.
Məcnun çəkib ah, qıldı nalə,
Əfgan edib ağladi bu halə.
Heyrətlərə düşdü Zeydi-qafil;
Bu halət ona göründü müşkil
Kim, fövti-rəqib eşitsə aşiq,
Gülmək gərək, ağlamaq nə layiq?!
Təhqiqi-bəyani-hal qıldı,
Ol vaqeəden sual qıldı.
Məcnun dedi: "Ey vəfalı yarım!
Yoxdurmu bu yolda nəngü arım?
Cananəyə can verib yetibdir,
Can verməyən arada itibdir.
Ol dostum idi, degildi düşmən,
Həm ol ona aşiq idi, həm mən.
Ol canını verdi vasil oldu,
Öz mərtəbəsində kamil oldu,
Nəqsim mənim irmədi kəmalə,
Eyb eyləmə ağlasam bu halə".

**QƏZƏL**

Aşiq oldur kim, qılır canın fəda cananinə,
Meyli-canan etməsin hər kim ki, qıymaz caninə.

Canmı cananə verməkdir kəmalı aşiqin,
Verməyən can, e'tiraf etmək gərək nöqsaninə.


182


Vəsl əyyam! verib cananə can, rahət bulan,
Yeydir ondan kim, salır canın qəmi-hicraninə.

Eşq rəsmin aşiq öyrənmək gərək pərvanədən
Kim, göyər gördükdə şəm'in atəşi-suzaninə.

Fani ol eşq içrə kim, bənzər fənası aşiqin
Feyzi-cavid ilə Xızrın çeşmeyi-heyvaninə!

Eşq dərdinin dovası qabili-dərman degil,
Tərki-can derlər bu dərdin mö'təbər dərmaninə.

Hiç kim canan üçün can verraogo laf etməsin
Kim, gəlibdir bu sifət ancaq Füzuli şaninə.


183


**BU, LEYLİNİN İBNİ SƏLAMDAN SONRA**
**MACƏRASIDIR**
**və**
**ZAVİVEYİ-MÖHNƏTDƏ**
**VAQE OLAN BƏLASIDIR**

Çün ata evinə döndü Leyli,
Əfğana olub həmişə meyli,
Tutmuşdu təriqi-əhli-matəm,
Təcdidi-əza qılıb dəmadəm,
Hər qanda bilirdi var bir zar,
Ənduhü müsibətə giriftar,
Cəm' edib olurdu əncümənsaz,
Eylərdi sürudi-növhə ağaz.
Gər İbni Səlam idi bəhanə,
Məcnun idi bais ol fəğanə.
Ağzında idi bir özgə zikri,
Könlündə idi bir Özgə fikri.
İzhar qılırdı özgə adın,
Pünhani edərdi özgə yadın.
Bu rəng ilə daim ol pərizad
Eylardi fərağət ilə fəryad.
Suzi-dilinə gətirməyib tab,
Bir gecə dağıldı yarü əshab,
Ancaq ona şəm' qaldı həmdəm,
Söndürdü bir ah ilə onu həm.
Yə'ni nə rəva şəbi-siyahım
Şəm' istəyə qeyri-bərqi-ahım?!
Tənha qalıb etdi naleyi-zar,
Dərdü qəmə qıldı əczin izhar:
"K'ey dərdü qəmi-zəmanə, billah,
Olman bu gecə mətıimlə həmrah!
Tənhalıq ilə mən eylərəm xu,
Siz özgə müsahibə tutun ru!"
Gördü qəmü dərdə yox nihayət,
Qıldı şəbi-tirədən şikayət:
"K'ey bəxti-siyahımın nəziri,
Aşüftə qılan məni-əsiri!


184


Əvvəl yox idi sənin qərarın,
Seyr ilə keçərdi ruzigarın.
Hala nə üçün qərar edibsən,
Tərki-rəviş ixtiyar edibsən?
Sərmənziləmi özün yetirdin?
Ya zülmət içində yol itirdin?
Matəmzədəsən, siyəh libasın,
Kimdən ola, nişədir bu yasın?
Dərdü ələmim dənizi daşdı,
Seylabi-bəla başımdan aşdı.
Tiri-fələkə nişanə oldum,
Tahuneyi-çərxə danə oldum.
Matəmkədədir bu gecə aləm,
Mən bəxtiqara bir əhli-matəm.
Nə səbr qalıbdurur, nə aram,
Bilmən ki, nolur mənə sərəncam.
Olmuş bu gecə təmam kövkəb
Azarım üçün fələkdə Əqrəb.
Sübh ayinəsini jəng tutmuş,
Feyzi-səhəri fələk unutmuş.
Ey sübh, sənin nə oldu halın,
Dəm urmağa qalmamış məcalın?
Könlün xoş isə, təbəssüm eylə!
Mehrin var isə, tərəbhüm eylə!
Fəryadıma həmdəm et xorusu,
Avazıma qoş sədayi-kusu.
Mürği-səhəri gətir zəbanə,
Göstər dəmi-sübhdən nişanə!"
Çox ağladı, etdi naləvü zar,
Dərdi-dili-zarın etdi təkrar.
Gördü mədədinə sübh yetməz,
Şəb derdi-dilinə çarə etməz,
Üz tutdu ona ki, feyzi-ami
Çəkmiş bu mədarə sübhü şami.
Razi-dili-zarın etdi ağaz:
"Key vaqifi-halü arifi-raz!
Yoxdur qəmi-dərdimə nihayət,
Qəmdən kimə eyləyim şikayət?
Qəm bihədü mən bəsi zəifəm,


185


Mən böylə qəmə qaçan hərifəm?
Ya ver mənə möhnətimdə taqət,
Ya taqətim olduğunca möhnət.
Gər cameyi-səbrim eyləsəm çak,
Hökmün yolu görünür xətərnak.
V'ər könlümə versəm istimalət,
Taqətcə degil qəmü məlalət.
Namusdan eyləsəm cüdalıq,
Məcnun ilə qılsam aşinalıq,
Qorxum bu ki, israət ola pamal,
Fərmana müvafiq olmaya hal.
Qılsam bu həvada hifzi-namus,
Mə'mureyi-vəslim ola məhrus.
Qorxum bu ki, dudi-ahi-Məcnun
Əhvalımı eylayə digərgun.
Sadiqlərin ahı mö'təbərdir,
Ondan həzər etməmək xətərdir.
Ol öylə, bu böylə neyləyim, vay!
Bilmən məni-acizə nədir ray?
Ya Rəb, mütəhəyyirəra məni-zar,
Möhnətlərə olmuşam giriftar!
Sərmənzili-əmnə rah bilmən,
Səndən özgə pənah bilmən.
Gör badeyi-qəflət ilə mədhuş,
Qıl pərdeyi-lütfünü xətapuş!
Derilər ki, sitəmrəsidə Məcnun
Olmuş məni-mübtəlaya məftun.
Mən bisərü pa ona nə layiq
Kim, hüsnümə ola kimsə aşiq ?
Mən zərreyi-xarü xaksarəm,
Gərdi-rəhi-xaki -rəhgüzarəm.
Ruhum ki, bədəndədir, -sənindir,
Hər nəş'ə ki, məndədir, - sənindir.
Gəncineyi-hüsnünə əminəm,
Sənsən səbəbim ki, nazəninəm.
Ya Rəb, mədəd et ki, bu əmanət
Məhfuz ola ta dəmi-qiyamət!
Ta qürbə təvəccöh etdigim çağ,
Alnım açıq olavü üzüm ağ!"


186


**BU QƏZƏL LEYLİ DİLİNDƏNDİR**

Ya Rəb, kəmali-bargəhi-kibriya həqi!
Yə'ni furuği-nuri-rüxi-Mustəfa həqi!

Qıl qərqə bəhri-eşqə vücudim səfinəsin,
Fərmani-Xizrə Musa edən iqtida həqi!

Sübhi-vüsalə eylə bədəl şami-hicrimi,
Sübhün dəmindəki nəfəsi-dilgüşa həqi!

Dərdü bəlamı rahi-məhəbbətdə qılma kəm,
Rahi-məhəbbətindəki dərdü bəla həqi!

Əhli-zəlalətəm, mənə göstər hidayətin,
Ehdayi-rahi-rast qılan rəhnüma həqi!

Ənduhü dərdə könlümü sahibtəhəmmül et,
Dərdə təhəmmül eyləyən əhli-riza həqi!

İxlasım et duaya Füzuli kimi dürüst,
Dərgahda icabətə layiq dua həqi!

**TƏMAMİYİ-SÜXƏN**

Əcz ilə dua qılırdı ol mah,
İzhari-niyaz edib ki, nagah
Çəkdi cərəs ərrəhilə avaz,
Rəsmi-hüdi etdi sariban saz.
Köç oldu, açıldı bargəhlər,
Büxtilərə məhd çəkdi məhlər.
Bir məhmilə girdi Leyliyi-zar,
Kuhi-qəmin etdi nəqəyə bar.
Əfganı edib cərəs ünün pəst,
Eşqi meyi etdi naqəni məst.


187


**BU, LEYLİNİN NAQƏYƏ ƏRZİ-RAZIDIR**
**və**
**ZƏBANİ-HAL İLƏ İZHARİ-NİYAZIDIR**

Çün naqədə gördü nəş'əyi-hal,
Qıldı ona həm bəyani-əhval:
"K'ey qaliyəmuyü ənbərinbuy,
Gülçöhrəvü xar-xar, xoşxuy!
Ey başı açıq, ayağı yalın,
Bulmuş neçə gəz hərəm vüsalın.
Sövdazədə nişədir dimağın?
Köksündə nədir bu əski dağın?
Kimdən sənə yetdi zülmü bidad,
Hər ləhzə nədir fəğanü fəryad?
Üşşaq təriqidir təriqin,
Gər aşiq isən, mənəm rəfiqin.
Nalan qəmi-eşqi-yardansan,
Sən dəxi bizim qatardansan.
Mən kimi yox əidə ixtiyarın,
Bir özgə əlindədir məharın.
Çün düşdü səninlə ittifaqım,
Rəhm eylə mənə, gör iştiyaqım.
Lütf eylə, binayi-kari-xeyr et,
Məcnunum olan diyara seyr et!
Bu şiftəyi yetir ol ayə,
Bu dərdi yetişdir ol dəvayə".
Nagah, gedərdi, oldu bihuş,
Mütləq Özün eylədi fəramuş.
Bihuşluğunda düşdü ol nur,
Həmrahı olan güruhdən dur.
Ol növ idi zülməti-şəbi-tar
Kim, olmadı sariban xəbərdar.
Çün gəldi özünə ol pərivəş,
Oldu bu qəziyyədən müşəvvəş.
Göz açdı, özünü gördü itmiş,
Həmrahı buraxmış onu, getmiş.
Dərd üzrə müzaəf oldu dərdi,


188


Təprətdi həyuni-rəhnəvərdi.
Çox cəhd ilə eylədi təkapu,
Çox yol arayıb yügürdü hər su.
Nə rah, nə rahibər bulundu,
Nə qafilədən əsər bulundu.
Tənha yürür oldu ol səmənbər,
Zülmətdə misali-mahi-ənvər.
Çün seydi-fələkdə Leyliyi-mah
Şəb qafiləyi itirdi, nagah
Leyli sifətində gün çıxıb fərd,
Cəmmazəyə çəkdi məhmili-zərd.
Düşdü güzər ol səmənüzarə,
Məcnuni-həzin olan diyarə.
Hər yan nigəran gəzərdi ol mah,
Bir şəxsi-həzin göründü nagah,
Sormağa əlameyi-mənazil,
Ol şəxsi-həzinə oldu mayil.
Lütf ilə təkəmmül etdi ağaz:
"Kimsən?" - deyibən yetirdi avaz.
Baş qaldırıb ol əsiri-məhzun,
Döndərdi cəvab ona ki: "Məcnun!"
Leyli dedi: "Ey özünə məğrur,
Haşa deyə əjdəha sözün mur!
Haşa deyə zağ, bülbüləm mən,
Ya laf ura xar kim, güləm mən!"
Məcnun dedi: - "Ey düri-yeganə,
Məcnuna bilirmisən nişanə?
Ol şiftənin nədir nişanı,
Gördükdə nədən bilirsən anı?"
Leyli dedi: "Ol pəriliqadır,
Rüxsarlə qəddi dilrübadır.
Sən şiftəsən, əsiri-matəm,
Rüxsarı şikəstə, qaməti xəm.
Sən xarsan, ol əzizi-aləm,
Sən bisərü pasan, ol müəzzəm."
Məcnun dedi: "Əhü-eşq olur xar,
Hüsn əhlinədir səfa səzavar."


189


Leyli dedi: "Ey bəhanəpərdaz!
Qeydi-dili-zarimə füsunsaz!
Peykər, tutalım töküldü qəmdən,
Ya qamətin oldu xəm sitəmdən.
Məcnunu deyərlər əhli-idrak,
Əş'an lətiffi ləhcəsi pak.
Səndə qanı ol ədayi-dilsuz,
Əş'arü hekayəti-difəfruz?"
Məcnun dedi: "Əhli-hal olur lal,
Bəsdir nəmi-əşk şahidi-hal.
Tərtibi-ibarətü fəsahət
Eşq əhlinədir dəlili-rahət.
Rahətdən olan mənim kimi dur,
Gər samit ola degilmi mə'zur?"
Leyli dedi: "Çün sənə şəkim var,
Məcnun isən, eylə halın izhar,
Leyliyi sevirsən, eylə bünyad
Bir şe'r, keçən zamanın et yad!"


190


**BU, MƏCNUNUN LEYLİYƏ**
**İZHARİ-HALİ-ZAR ETDİGİDİR**

Məcnuni-həzin eşitdi sövgənd,
Gördü onu şe'rə arizumənd,
Təfsili-qəminə verdi icmal,
Qıldı ona ərzi-surəti-hal:
"K'ey səbzeyi-dərdimə verən ab!
Sərrişteyi-razdan açan tab!
Sorma necə keçdi ruzigarın,
Eşq içrə nə oldu hali-zarın?
Düdar qəminmi söyləyim, ah,
Ya pəndi-mühibbü tə'ni-bədxah?
Çəkdim neçə gün cəfayi-məktəb,
Hər ruz məşəqqət ilə ta şəb.
Axır ki, çox oldu tə'ni-əğyar,
Ayrıldı məni-şikəstədən yar.
Faş oldu çü aləmə fəsanəm,
Tədbirimə düşdü atəm, anəm.
Gəh dəğdəğeyi-təbib gördüm,
Gəh sə'y ilə Kə'bəyə yügürdüm.
Açılmadı hiç babdən bab,
Tədbirimə aciz oldu əhbab.
Gah Növfələ eylədim təzərrö',
Feyzində bulunmadı təvəqqö'.
Geh İbni Səlama yar olub yar,
Verdi dili-mübtəlaya azar.
Gəh Zeyd pəyamına inandım,
Hər və'd ki, verdi doğru sandım.
Ümmid ilə ömrüm oldu zaye,
Halım betər etdi zə'fi-tale.
Əlqissə, vücudum oldu bərbad,
Bir ləhzə fələkdən olmadıra şad".
Könlünə qılıb fəraq tə'sir,
Bir türfə qəzəl həm etdi təqrir:


191


**QƏZƏL**

Ah kim, bir dəm fələk rə'yimcə dövran etm’di,
Vəsl dərmanilə dəf i-dərdi-hicran etmədi.

Yardan min dərdi-dil çəkdim, bu həm bir dərd kim,
Biluin dərdi-dilim, bir dərdə dərman etmədi.

Vadiyi-qürbətdə can verdim, məni ol şahi-hüsn
Bir gecə xani-vüsalı üzrə mehman etmədi.

Dustlar, çaki-giribanım görüb eyb eyləmən,
K'ol kim gördü kim, çaki-giriban etmədi?

Fəqr mülkün tut, gər istərsən kəmali-səltənət
Kim, mülkün fəthini fəğfurü xaqan etmədi.

Tiği - bidad ilə hər dəra qanımı tökmək nədir?
Ey fələk, hər kim dəm urdu eşqdən, qan etmədi.

Əhdü peyman etdi yarım kim: "Səne yarəm", vəli,
Yarlıq vəqti vəfayi-əhdü peyman etmədi.

Əql meydanını zindani-bəla bilməz hənuz,
Kim ki, bir müddət cünun mülkünü seyran etmədi.

Sirri-eşqin etmədi ancaq Füzuli aşikar,
Bu mübarək işi hər kim etdi, pünhan etmədi.


192


**BU, LEYLİNİN MƏCNUNDAN**
**XƏBƏRDAR OLDUĞUDUR**
**və**
**MƏTAİ-VƏSLİNƏ NƏQDİ-CANLA**
**XİRİDAR OLDUĞUDUR**

Çün büdi kim olduğunu Leyli,
Rüxsarına axdı əşk seyli,
Giryan dedi: "Ey gözüm çırağı!
Vəhşilərə el, mənimlə yağı!
Sən men dedigim həbib imişsən,
Dərdi-dilimə təbib imişsən.
Sənsən dünü gün dilimdə zikrim,
Könlümdə olan xəyalü fikrim.
Gər tanıya bilmədim rəvadır,
Məstəm mənü məst işi xətadır.
Kimsə ki, özündən ola qafil,
Bir özgəyi bilməyə nə qabil?
Ol dəm ki, dimağa yetdi buyin,
Göz gördü şüai-mahi-ruyin,
Can bixəbər oldu, əql şeyda,
Tən qıldı min iztirab peyda,
Dəryayi-təhəyyürə olub qərq,
Əğyardan etmədim səni fərq.
Mə'zur tut, ey sənəm, bu halım,
Tə'n eyləmə, vermə infıalım.
Sənsiz mən idim şikəstəxatir,
Yüz şükr, sənə yetişdim axir.
Gülzari-ümidim oldu sirab,
Ya Rəb, bu xəyaldırmı, ya xab?
Eyşü tərəbim çırağı yandı,
Bəxtim yuxudan məgər oyandı?
Ey dil ki, edərdin ahü nalə,
Daim nigəran olub vüsalə,
Ha, dövləti-vəslü zövqİ-didar!
Billah, dəxi etmə naləvü zar!
Ey didə, töküb sirişki-gülgun


193


Hər dəm der idin ki: "Qanı Məcnun?"
Mənzurun olubdur ol səmənbər,
Qıl məqdəminə nisar gövhər!
Ey can ki, çəkərdin intizarı,
Görmək diləyib həmişə yarı,
Yetdin ona, gəl, çıx indi təndən,
Get yarə, kəs ixtilatı məndən".
Dərdini deyirkən ol pənzad
Suz ilə bu şe'ri etdi bünyad:

**BU QƏZƏL LEYLİ DİLİNDƏNDİR**

Açmadı könlüm fələk, ta bağrımı qan etmədi,
Qılmadı xürrəm məni, ta zarü giryan etmədi.

Qılmadan bidad üə yüz parə pürxun könlümü,
Bu çəməndə gül kimi bir ləhzə xəndan etmədi.

Şükr kim, verdi fələk kamım, məni nomid edib,
Şiveyi-mehrü məhəbbətdən peşiman etmədi.

Dərd yoxdur kimsədə, yoxsa təbibi-feyzi-eşq
Kimdə gördü dərd kim, ol dərdə dərman etmədi?

Səbr yoxdur mərdümi-aləmdə, vərnə ruzigar
Qansı müşküldür ki, tədric ilə asan etmədi?

Tutdu seylabi-dü çeşmim yerüzün, əmraa xoşa
Kim, binasın səbrimin ol seyl viran etmədi.

Eşq sövdasında sud etdin mətai-vəsldən,
Ey Füzuli, can verən canana nöqsan etmədi.


194


**BU, MƏCNUNİ-HEYRANIN**
**NİHAYƏTİ-HEYRƏTİDİR**
**və**
**LEYLİDƏN İSTİĞNÄ İLƏ QƏFLƏTİDİR**

Məcnun dedi: "Ey açan mənə raz,
Lütfilə qılan məni sərəftaz,
Kimsən? Mənə zahir eylə adın!
Bu badiyədə nədir muradın?
Can tazələnir fəsahətindən,
Bü ləhceyi-pürməlahətindən.
Xülqi xoşü ləfzi canfəzasan,
Böylə görünür ki, aşinasan.
Billah nə diyardan gəlirsən?
Nə rahigüzardan gəlirsən?
Gər lalə isən, na dağdansan?
V'ər susən isən, nə bağdansan?
Şirin-şirin təkəllümün var,
Hali-dilimə tərəhhümün var.
Biganədən ummazın bu hali,
Bir ülfətdən degil bu xali.
Bihudə degil bu könlüm almaq,
Gəlmək, başım üzrə sayə salmaq.
Əql olsa idi mənimlə həmrah,
Əhvalından olurdum agah.
Qəm könlümü etməsəydi bitab,
Göz pərdəsi olmayaydi ximab,
Qəflət xələlindən ayrılardım,
Əlbəttə, kim olduğun bilərdim.
Çün məndə yox ehtimali-idrak,
Sən söylə özün ki, kimsən, ey pak?"


195


**BU QƏZƏL MƏCNUN DİLİNDƏNDİR**

Öylə sərməstəm ki, idrak etməzəm dünya nədir,
Mən kiməm, saqi olan kimdir, meyü səhba nədir.

Gərçi canandan dili-şeyda üçün kam istərəm,
Sorsa canan, bilməzəm kami-dili-şeyda nədir.

Vəsldən çün aşiqi müstəğni eyler bir vüsal,
Aşiqa mə'şuqdən hərdəm bu istiğna nədir?

Hikməti-dünyavü mafiha bilən arif degil,
Arif oldur, bilməyə dünyavü mafiha nədir.

Ahü fəryadın, Füzuli, incidibdir aləmi,
Gər bəlayi-eşq ilə xoşnud isən, qovğa nədir?


196


**CƏVABİ-LEYLİ**

Leyli dedi: "Ey qərineyi-ruh,
Kami-dili-mübtəlayi-məcruh!
Müjdə ki, zəmanə verdi kamın,
Doldu meyi-işrət ilə camın.
Müjdə ki, müyəssər oldu məqsud,
Sövda ilə axır eylədin sud.
Müjda ki, muradın oldu hasil,
Məqsudə səni Həq etdi vasil.
Leyli mənəm, arizuyi-canın,
Kami-dili-zarü natəvanın.
Müştaqi-cəmal idin həmişə,
Möhtaci-vüsal idin həmişə.
Hala ki, müyəssər oldu didar,
Təqsiri-təəllül etmə, zinhar!
Gör dövləti-vəslimi qənimət,
Gəl yanıma, fövt qılma fürsət!
Dil nəzri-vüsali-qamətindir!
V'ər canım isə, əmanətindir.
Çün düşdü məcalın, etmə ehmal,
Gəl nəzrini tut, əmanətin al!
Gər xəstə isən, mənəm təbibin,
V'ər aşiq isən, mənəm həbibin.
Gəl bəzmi-vüsala məhrəm olğıl!
Bir ləhzə mənimlə həmdəm olğıl!
Ver nərgisə lalə ilə rövnəq,
Reyhani-tər ilə zibi-zənbəq.
Firuzəyi et qərini-yaqut,
Qıl tutiyə qəndi-nabdən qut.
Peyvəndi-gül eylə erğəvanı,
Xızra yetir abi-zindəganı.
V'ər aşiqi-mübtəla degilsən,
Məcruhi-qəmü bəla degilsən,
Təqlid ilə göstərib əlamət,
Qılma özünü, məni məlamət!
Bir əqlü fərasət eylə peyda,


197


Ancaq, bizi etmə xəlqə risva!
Ey gül, bu mənə degilmidir nəng
Kim, olmayasan mənimlə həmrəng?
Mən ərz edəm afitabi-rüxsar,
Sən qılmayasan hərarət izhar?
Mən cam tutam, deyim ki, "gəl al!",
Sən durmayasan ayağa filhal!
İzhari-camalın eyləmək gül,
Bülbül görüb eyləmək təğafül?
Çox təcrübə etmişəm olur az:
Mə'şuqinə aşiq eyləmək naz".
Təqrib ilə ol büti-düara
Bir türfə qəzəl həm etdi inşa:

**BU QƏZƏL LEYLİ DİLİNDƏNDİR**

Ey qılan şeyda məni, məndən bu istiğna nədir?
Nişə sormazsan ki, əhvali-düi-şeyda nədir?

Gər mənə xəlq içrə pərva qılmadın, mə'zursan,
Böylə tənhalıqda qılmazsan mənə pərva, nədir?

Səhldir gər bilməyib halım, tərəhhüm qılmamaq,
Halımı bilmək, tərəhhüm qılmamaq əmda nədir?

Gül təmənnasında derlər bülbülün qövğaların,
Çün gülü gördükdə qılmaz meyl, bu qövğa nədir?

Ol pəri mütləq məni-rüsvayə qılmaz iltifat,
Ey Füzuli, bilməzəm cürmi-məni-rüsva nədir?


198


**BU, LEYLİYƏ MƏCNUNUN**
**İSTİĞNASIDIR**
**və**
**İSBATİ-SƏFAYİ-İMLASIDIR**

Məcnun dedi: "Ey büti-pərivəş!
Xaşaki-zəifə urma atəş!
Yandırmağıma yetər xəyalın,
Yoxdur mənə taqəti-vüsalın.
Zinhar, gətirmə, ey səmənbər,
Ayineyi-arizin bərabər.
Bir zərrəyə kim, vücud yoxdur,
Ayinədən ona sud yoxdur.
Ol gün ki, gözümdə var idi nur,
Gözdən üzünü yaşırdm, ey hur!
Hala ki, nəzarən oldu müşkil,
Durmaq nə üçün mənə müqabil?
Eşq etdi binayi-vəsli möhkəm,
Mə'nidə məni səninlə həmdəm,
Rəf oldu bu e'tibari-surət,
Haşa ki, olam şikari-surət.
Ləzzət rüxi-yari-dilsitandan
Candır bulan, ey diriğ candan!
Canım gedəli bəsi zamandır,
Cismimdəki indi özgə candır.
Sənsən hala tənimdə canım,
Gözdə nurim, cigərdə qanım.
Məndən bəri eylədin məni sən,
Ərzə kimə eyləyim səni mən?
Məndə olan aşikar sənsən,
Mən xud yoxam, ol ki var - sənsən!
Daim sənə məndədir təcəlli,
Mən qeyrdən olmuşam təsəlli.
Gər mən mən İsəm, nəsən sən, ey yar?
V'ər sən sən isən, nəyəm məni-zar?
Çün mən olubam səninlə məmlu,
Vəhdət rəvişində xoş degil bu


199


Kim, dışrada istəyəm nişanın,
Bir özgə məkan biləm məkanın.
Əvvəl bu işi edəndə bünyad,
Mən tifl idimü zəmanə ustad.
Etmişdi sənə məni müqəyyəd,
Guya oxudurdu dərsi-əbcəd.
Hala qılıbam kəmal hasil,
Əbcəd səbəqin oxurmu kamil?
Çün yetdi kəmala sərxəti-eşq,
Sərxət görüb ancaq eylərəm məşq,
Rüsvalığa çün mən etmişəm ad,
Sən həm bu süluki etmə bünyad.
Tut pərdeyi-ismət içrə aram,
Rüsvay mənəm, sən ol nikunam!
"Məcnun" mənə derlər əhli-aləm,
Ancaq mənədir cünun müsəlləm.
Sən olma fəsaneyi-xəlayiq,
Məcnun işi Leyliyə nə layiq?
Məcnun mənəm, ey vəfalı dildar!
Divanəliyə mənəm səzavar!
Sən eyləmə halını digərgim,
Leyli nə rəva ki, ola məcnun?
Qəmxarsan, ey büti-pəriru,
Qəmxarlığın həmin yetər bu
Kim, pərdənişin olub həmişə,
Daim qılasan hicab pişə.
Gün kimi çıxıb müdam seyrə,
Göstərməyəsən cəmal qeyrə
Kim, səndə nə olsa rəsmü adət,
Ətvarımadır mənim şəhadət,
Mən eşq güzərgəhində xakəm,
El cümlə bilir məni ta, pakəm,
Rəhm et mənə, ey büti-vəfadar,
Tə'n əhlinin ağzın açma, zinhar!
Çün mən rəhü rəsmi-eşq tutdum,
Namus təriqini unutdum.


200


Namusunu saxla hər xətəldən,
Sən əql ətegini qoyma əldən".
Təqrib ilə oləsiri-məhcur
Bu nadirə şe'ri etdi məzkur:

**BU QƏZƏL MƏCNUN DİLİNDƏNDİR**

Xəyalilə təsəllidir, könül meyli-vüsal etməz,
Könüldən dışra bir yar olduğun aşiq xəyal etməz.

Həqiqi eşq çün müstövcibi-nöqsan degil, mütləq,
Özün əhli-həqiqət valehi-hüsnü cəmal etməz.

Kəmali-eşqə talib möhtərizdir hüsni-surətdən
Ki, qeydi-hüsni-surət aşiqi sahibkəmal etməz.

Dəlili-cəhldir eşq əhlinə surətpərəst olmaq
Ki, aqil iftiraqı mümkün ilə ittisal etməz.

Könüldə dust təmkin bulsa, olmaz gözdə cövlanı,
Məhəbbət sabit olsa, öz yerindən intiqal etməz.

Səvadi-masivadan lövhi-dil xali gərək daim,
Müvəhhid səfheyi-idraka nəqşi-xəttü xal etməz.

İradət zaye etməz əhli-mə'na surətən hərgiz,
Həqiqət cövhərin cəhli-məcaza payimal etməz.

Müqəyyəd olmaz əhli-surətin rənginə hal əhli,
Füzuli kim, müqəyyəddir, məgər idraki-hal etməz?


201


**BU, LEYLİNİN MƏCNUN ƏTVARINA**
**TƏHSİNİDİR**
**və**
**HÜSNİ-E'TİQADINA HÜSNİ-YƏQİNİDİR**

Leyli dedi: "Ey vücudi-kamil,
Qürbi-Həqə ismət ilə qabil!
Me'raci-kəmalını sınardım,
Keyfiyyəti-halını sınardım.
Oldum necə olduğundan agah,
Xoş mərtəbədir bu, barəkallah!
Əhsəntə ki, zati-pak imişsən,
Pakizə vücudi-xak imişsən.
İnsaf həmin ola qənaət,
Təskini-bəvaya istitaət.
Eşqində riya güman edərdim,
Ətvarını imtəhan edərdim.
Əlminnətü lillah oldu mə'lum,
Vəsl olduğu məşrəbində məznıum.
Qəmnak idim, eylədin məni şad,
Bu qeyd təəllüqündən azad.
Bir qafili-xudpərəst idim mən,
Cəh! ilə müdam məst idim mən.
Arayişi-zülfü xal edərdim,
Peyvəstə munu xəyal edərdim
Kim, sən tələbi-vüsal edərsən,
Nəzzareyi-zülfii xal edərsən.
Hala mənə rövşən oldu halın,
Me'raci-həqiqəti-kəmalın.
Mən bəslədigim bu zülfü xalı,
Çeşmi-siyəhü Üzari-alı
Öz canım üçün degil, şəbü ruz,
Nezri-nəzərindir, ey diləfruz!
Ta eyləyəsən dəmi nəzarə,
Təskin verəsən dili-figarə.
Həm sən olasan murada vasil,
Həm ola mənə səvab hasil.


202


Yoxdur çü nəzarə meyli səndə,
Neylər bu cəmali-xub məndə.
Tən dürcünədir düri-rəvanım,
Gənci-bədənimdə nəqdi-canım
Derdim ola sərfi-rəhgüzarın,
Gördükdə rəvan qılam nisarın.
Tövfiqü vüsalın edəm idrak,
Əndişeyi-hicrdən olam pak.
Hala ki, müyessər olamaz kam,
Olmaq nə rəva arada bədnam?
Nəsxi-xəti-e'tibar qıldım,
Rahi-ədəm ixtiyar qıldım.
Ta necə verə qübari-surət
Ayineyi-zatıma küdurət?
Vəqt oldu ki, rövşən ola mir'at,
Müstəğni ola süfatdan zat.
Vəqt oldu bu qönçə ola xəndan,
Tə'sir edə sübhi-feyzi-canan.
Xunabi-qəmilə doldu könlüm,
Qönçəsifəti tutuldu könlüm.
Fərz oldu ki, tey qılam büsatım,
Qət' edəm özümdən ixtilatım.
Sitri-tətı edəm ədəm hicabın,
Rüxsara çəkəm fəna niqabın.
Ta hüsni-rüxüm ki, istəməz yar,
Olmaya nəsibi-çeşmi-əğyar.
Zira ki, nəsibi-hüsni-qabil
Oldur, ona aşiq ola mayil.
Hüsnümdə çü yox qəbuli-aşiq,
Nöqsan ilə olmağım nə layiq?"
Bu hala münasib ol pərizad
Filhal bu şe'ri etdi bünyad:


203


**BU QƏZƏL LEYLİ DİLİNDƏNDİR**

Nə dilbər kim, dəmadəm aşiqə ərzi-cəmal etməz,
Qalır naqis, bulub feyzi-nəzər kəsbi-kəmal etmə.

Degil cəzb etməyən üşşaqı mə'şuq olmağa qabil,
Nə hasü hüsni-surətdən ki, cəzbi-əhli-hal etməz.

Gərək rüxsareyi-mə'şuq məxfi qeyri-arifdən
Ki, arif olmayan idrak sün'i-zülcəlal etməz.

Həvayi-vəsldir kim xublər vəslinə talibdir,
Və gər nə, eşqi-kamil fərqi-hicranü vüsal etməz.

Olan nəqdi-həyatın aşiqin mə'şuqə sərf eylər,
Bu zülmü, ah, əgər mə'şuqinə aşiq həlal etməz.

Məcaz əhlinə xublar cilveyi-naz eyləsinlər kira,
Özün əhli-həqiqət mübtəlayi-xəttü xal etməz.

Füzuli, aləmi-surətdə sərgərdan gəzər zahid,
Zəhi qafil, bu sevdanın sərəncamın xəyal etməz.

**TƏMAMİYİ-SÜXƏN**

Xətm eyləmədən sözünü ol mah,
Bir naqənişin göründü nagah.
Naqə ilə bir nəfər səbükxiz,
Gördü ki, gəlir nəsimtək tiz.
Bildi büti-gülrüxü səmənbuy
Kim, özü üçündür ol təlcü puy.
Bildi ki, rəqib bədgümandır,
Ənduhi-dilü bəlayi-candır.
Ol mahivəş olduğunda qaib
Olmuş ona sürət ilə talib.
Gülzara hənuz yetmədən xar,


204


Gül qıldı vidayi-səhni-gülzar.
Ol halına vaqif olmadan qeyr,
Təprətdi cəmazeyi-səbükseyr.
Cuyəndə görüb ol afitabı,
Tərk etdi şitabü iztirabı.
Tövfiqi-murada oldu xoşdil,
Düşdü önə, qıldı əzmi-mənzil.
Şəhbazı yetirdi aşiyana,
Tapşırdı nihah bağibana.
Məcnun yenə qaldı zarü məhcur,
Həmsöhbəti marü həmdəmi mur.
Nə durmağa taqətü qəran,
Nə gəzməyə əldə ixtiyarı.


205


**BU, MƏCNUNUN ME'RACİ-FƏZAİLİDİR**
**və**
**BƏYANİ-MƏRTƏBEYİ-HÜSNİ-XƏSAİLİDİR**

Şahənşəhi-mülki-möhnətü dərd,
Yə'ni Məcnuni-dərdpərvənd
Bir pak idi ki, bu ərseyi-xak
Onun kimi görməmişdi bir pak.
Mömureyi-qürbi-Həq məqamı,
Ərvaha fərizə ehtiramı.
Çün nifrəti-şəm'-nəsli-adəm
Qıldı ona vəhşəti müsəlləm,
Hər vəhşi donunda bir firiştə
Yar oldu ol adəmisiriştə.
Zahirdə rəfiqi vəhşlə teyr,
Batində məlaik ilə həmseyr.
Qılmışdı kəmali-e'tidali
Kəsrət ələmindən onu xali.
Çəkməzdi cahanda ol cahangərd
Əndişeyi-gərmü qüsseyi-sərd.
Bilmişdi cahanın e'tibarın,
Yox yerinə satmış idi varın.
Tutmuşdu təriqi-əhli-tövhid,
Bulmuşdu kəmali-tərkü təcrid.
Olmuşdu vücudi-pakı pürnur,
Alayişi-əklü şürbdən dur.
Təhsil qılıb səfayi-siyrət,
Görmüşdü məcazdan həqiqət.
Ə'yana yox idi e'timadı,
Nəqqaş idi nəqşdən muradı.
Mövzun idi təb'İ-nüktədam,
Hər nüktəde vaqifi-məanı.
Avazi idi bəsi mülayim,
Üslubu dürüst, üsulu qaim.
Təhrir ilə hər çəkəndə avaz,
Quşlara tutardı rahi-pərvaz.
Gahi qəzəlü gəhi qəsidə


206


İnşa qılıb ol sitəmrəsidə
Suz ilə oxurdu gahü bigah,
Bir neçə əziz onunla həmrah,
Yazarlar idi təmam şe'rin,
Oxurlar idi müdam şe'rin.
Aləmlərə ol qəribü məhcur
Əksər bu səbəbdən oldu məşhur.
Avaziyü zehniyü cəmalı
Qılmışdı müqəyyəd əhli-halı.
Kim olsa bu üç kəmala qabil,
Demək olur ona zati-kamil.
Peyvəstə qılıb kəmalın izhar,
Bu beytləri qılırdı təkrar:

**BU QƏZƏL MƏCNUN DİLİNDƏNDİR**

Biz cahan mə'murəsin mə'nidə viran bilmişiz,
Afiyət gəncin bu viran içrə pünhan bilmişiz.

Gər özün dana bilir təqlid ilə surətpərəst,
Aləmi-təhqiqdə biz onu nadan bilmişiz.

Bixəbərlər şərbəti-rahət bilirlər badəyi,
Biz həkimi-vəqtiz, onu tökmüşüz, qan bilmişiz.

Bilmişiz kim, mülki-aləm kimsəyə qılmaz vəfa,
Ol zamandan kim, onu mülki-Süleyman bilmişiz.

Ayrı bilmişsən, Füzuli, məscidi meyxanədən,
Sehv imiş ol km, səni biz əhli-irfan bilmişiz.


207


**BU, LEYLİNİN**
**BAHARİ-ÖMRİ XƏZANA İRDİGİDİR**

Saqi, gözə gəldi nəş'əyi-mey,
Bir neçə qədəh yürüt peyapey!
Əzmi-tərəb etdin, ehtimam et,
Zövqün tərəb əhlinin təmam et!
Bəzm əhlinə cami-laləgun tut,
Əmma mənə cümlədən füzun tut!
Zira ki, hənuz nimməstəm,
Qəm silsiləsinə paybəstəm.
Xoşdur tərəb əhlinin bu bəzmi,
Dağılmağa olmasaydı əzmi.
Tarixnəvisi-halieyyam,
Bu qissəyə böylə verdi itmam
Kim, vəsldən olmayıb təsəlli,
Məcnundan olanda dur Leyli
Kəsmişdi təəllüqün cahandan,
Qət'i-nəzər eyləmişdi candan.
Bir fösl ki, dəsti-qarəti-dey,
Gülzar büsatın eylədi tey,
Matəmkədə oldu ərseyi-bağ,
Matəmdə sürud naleyi-zağ.
Leyli kimi oldu lalə məstur,
Məcnun kimi şaxi-ərğəvan ur.
Rənci-yərəqandan oldu əşcar
Lərzanü zəifü zərdrüxsar.
Söndü gülü laləniıı çırağı,
Sərsər yeli zülmət etdi bağı.
Gül bimi-təərrüzi-həvadan,
Lalə sitəmi-dəmi-səbadan
Rəxtini yaşırdı [1] bağlarda,
Lə'lini itirdi dağlarda.
Bir mar misalı oldu hər nəhr.
Hər lərzədə su məsabeyi-zəhr.


1 Gizlətdi


208


Göydən yerə endigində baran,
Hər qətrə olub misali-peykan,
Guya ki, yetirdi bağə bidad
Kim, şö'bədeyi-təhərrüki-bad
Bir sehr ilə abı ahən etdi,
Ondan təni-bağə cövşən etdi.
Bir gün bu həvada Leyliyi-zar
Qəm dəf'inə etdi meyli-gülzar.
Gördü gülü lalədən əsər yox,
Ənvai-şəcərdə bərgü bər yox.
Səhni-çəmənin səfası getmiş,
Nöqsani-səfa kəmala yetmiş.
Nə səbzə tənində tab qalmış,
Nə bərg üzündə ab qalmış.
Matəmkədə gördü busitanı,
Riqqət oduna tutuşdu canı.
Suzi-cigərilə yanə-yanə,
Şərh etdi qəmini busitanə:
"K'ey bağ, nədir bu ahi-sərdin?
Mən xəstəyə zahir eylə dərdin!
Mən dəxi sərtin kimi nizarəm,
Bir güldən iraqü zərdü zarəm;
Nə dövləti-qürbünə qəbulum,
Nə rövzeyi-kuyinə vüsulum.
Sən gərçi xəzanəsən giriftar,
Əlbəttə, bəharə yetməgin var.
Ümmidi-vüsal məndə yoxdur,
Səndən qəmü qüssə məndə çoxdur!"
Artırdı qəm ağladıqca dərdin,
Giryan göyə tutdu ruyi-zərdin.


209


**BU, LEYLİNİN ANASINA**
**VƏSİYYƏT ETDİGİDİR**
**və**
**DUST YADI İLƏ DÜNYADAN**
**GETDİGİDİR**

Mə'budinə ərz qıldı razın,
Bildirdi könüldəki niyazın:
"K'ey hakimi-ərseyi-qiyamət!
Sultani-səriri-istidamət!
Nomidilik atəşinə yandım,
Billah, bu vücuddan usandım!
Çün dust yanında naqəbulam,
Billah, bu həyatdan məlulam!
Mən şəm'i-şəbi-fəraqi-yarəm,
Suzanü siyah ruzigarəm.
Yandırdı məni cəfayi-aləm,
Dinlənməzəm, ölməyincə bir dəm.
Dərdim ki, vücudum ola baqi,
Şayəd düşə vəsl ittifaqi...
Pərtöv bürcündə afitabım,
Bildim ki, vücud imiş hicabım.
Ya Rəb, məni et fənaya mülhəq
Kim, rahi-fəna imiş rəhi-Həq."
Pak idi, duası etdi tə'sir,
Filhal mizacı oldu təğyir.
Tə' siri-həvayi-namünasib
Tərkibinə qıldı zə'f qalib.
Gəldikcə ziyadə oldu dərdi,
Təblərzə fərağətin gedərdi.
Məhv oldu təb içrə ol pərivəş,
Bir şəm' kimi ki, görə atəş.
Əksildi ərəqdə hüsni-tabı,
Bir gül kimi kim, gedər gülabı...
Zə'fi-təni ol məqamə yetdi
Kim, bəstər içində cismi itdi.


210


Bəstərdə tələb qılan nişanın,
Görməzdi vücudi-natəvanın.
Rəf oldu nişaneyi-səlamət,
Mövtinə göründü min əlamət.
Əzm eylədi olmağa müsafir,
Rehlət əsəri çü oldu zahir,
Rəf etdi hicab ehtirazın,
Faş etdi anayə gizli razın:
"K'ey dərdi-dilim dəvası ana!
Şəm'i-əməlim ziyası ana!
Qəm gizləmək ilə canə yetdim,
Ta mümkün idi, təhəramül etdim.
Hala ki, müqərrər oldu getmək,
Fərz oldu bu sirri zahir etmək.
Olsun sənə, ey zəifə, rövşən
Kim, tiği-həva həlakıyam mən.
Cismimdə yox özgə dərd tabı,
İlla qəmi-eşq iztirabı.
Mən aşiqi-zarü binəvayam,
Bir mahliqaya mübtəlayam.
Sevdası ilə yox oldu varım,
Keçdi həvəsilə ruzigarım.
Çox arizu eylədim cəmalın,
Bir dəm görə bilmədim vüsalın.
Hala gedirəm könüldə süzi,
Əldən nə gəlir, bu idi ruzi.
Ancaq degiləm məni-pərişan
Ol yar qəmində zarü giryan.
Ol həm məni-zarə mübtəladır,
Sərgəşteyi-vadiyi-bəladır.
Məndəndir onun cünuni əfzun,
Qeys ikən olubdur adı Məcnun.
Daim keçirər qəmimdə əyyam,
Bir gün ona hasil olmayıb kam.
Rüsvayi-zəmanə oldu məndən,
Afaqə fəsanə oldu məndən.


211


Bihudə degil fəğanü ahı,
Yaqmazmı məni onun günahı!?
Mən kim, gedirəm bu xakidandan,
Dərdim bu ki, şərmsarəm ondan,
Ey munisi-ruzigarım ana,
Qəmxanmü qəmküsarın ana!
Mən dari-bəqaya əzm edəndə,
Dünyaya vida edib gedəndə,
Mənsiz çəkib ahlar, fəğanlar
Səhraləra düşdügün zamanlar
Düşsə yolun ol olan diyara,
Ərzi-qəmim eylə ol figara.
Zinhar ona olanda vasil,
Xoş kimsədir, ondan olma qafil!
Damanını tut, rizasın istə,
Mən mücrim üçün duasın istə.
Ərz eylə ki: "Ey vəfalı dildar!
Can verdi yolunda Leyliyi-zar.
Eşqində yerinə yetdi lafı,
Də'vasının olmadı xilafı".
Söylə məni-zarü mübtəladan:
"K'ey eşqdə laf edən vəfadan!
Xəlvətgəhi-ünsə məhrəm oldum,
Azadəvü şadü xürrəm oldum.
Sən həm gələ gör, təəllül etmə!
Mən müntəzirəm, təğafül etmə!
Gər sadiq isən bu yolda, sən həm
Səbr eyləmə, eylə tərki-aləm.
Gəl kami-dil ilə olalım yar,
Bir yerdə ki, yoxdur onda əğyar...
Daim olalım bir evdə həmraz
Kim, çıxmaya dışra ondan avaz.
Xoş mənzili-əmnə bulmuşam rah,
Bitə'neyi-dustü cövri-bədxah.
Məndən səni eyləmək xəbərdar,
Bismillah, əgər iradətin var!"


212


Çün qıldı vəsiyyətini axir,
Əzmi-səfər etdi ol müsafir.
Yad eylədi yari mehribanın,
Vəsl arzusu ilə verdi canın.
Kimdir ki, cabanda fani olmaz?
Dövri-fələkin amani olmaz!
Dünya yedi başlı əjdəhadır,
Əndişeyi-ülfəti xətadır.
Hər lütfünədir dəfinə min qəhr,
Hər şəhdinədir qərinə min zəbr.
Dövran üzərindədir zəmanə,
Əlbəttə, galən gedər cəhanə.
Ərbabi-zəmanəyə verib pənd,
Bu şe'ri nə xoş demiş xirədmənd:

**QƏZƏL**

Bu aləm kira, könül, qeydin çəkərsən, möhnətü qəmdir,
Fəna sərmənzilin seyr eylə kim, bir xoşca aləmdir.

Anıb tənhalığı qəbr içrə nifrət qılma ölməkdən,
Təriqi-üns tut kim, hər ovuc topraq bir adəmdir.

Degil möhkəm cahan mülkündə hər bünyad kim, qılsan,
Bəqa mülkündə tut mənzil kim, ol bünyad möhkəmdir.

Əcəl alayişi-xövfü xətərdən qurtarar nəfsi,
Bu cövhər kimiyayi-nəfsə bir iksiri-ə'zəmdir.

Kəmali-eşqi-insan mövt iləndir rahi-hikmətdə,
Bəli, mücra qılan hökmün misalın nəqşi-xatəmdir.

Bahar əyyamı girsən laləzara, xak əczasın
Mühəqqər görmə kim, hər zərrə bir cam ilə bir Cəmdir.

Əsiri-nəfsdir əhli-cahan, bilməz fəna qədrin,
Füzuli, tərk təcridi sənə ancaq müsəlləmdir!


213


**TƏMAMİYİ-SÜXƏN**

Leyli güli-gülşəni-lətafət
Çün gördü xəzan yelilə afət,
Pamali-xəzan olub baharı,
Əncama yetişdi ruzigarı,
Biçarə anası açdı başın,
Başından aşırdı qanlı yaşın.
Kafurini tökdü zə'fərana,
Suzi-dil i!ə gəlib fəğana,
Çox ağladı, etdi ahu nalə,
Ağlar, kim olursa böylə halə.
Əlqissə, tutub təriqi-matəm,
Ol vaqeəyə yığıldı aləm.
Tə'zim ilə tutdular əzasın.
Qəbrin düzüb urdular binasın.
Tən oldu müqimi-ərseyi-xak,
Ruh oldu qərini-övci-əflak.
Şövq əhlinə qürb hasil oldu,
Dəryasına qətrə vasil oldu.


214


**MƏCNUNUN LEYLİ VƏFATINDAN**
**XƏBƏRDAR OLDUĞUDUR**
**və**
**DUST YADI İLƏ DÜNYADAN**
**GETDİGİDİR**

Möhnət çəmənində gül dərənlər,
Aləmdə yaman xəbər verənlər
Qəm nüsxəsin eyləyəndə təhrir,
Vermişlər ona bu növ təşhir
Kim, Zeydi-sitəmrəsideyi-zar
Ol vaqeədən olub xəbərdar,
Filhal qılıb əziməti-rah,
Məcnuni-həzini etdi agah:
"K'ey şifteyi-şikəstətale!
Əfsus ki, sə'yin oldu zaye!
İdbari-tilismin oldu batil,
Bu məşğələdən dəxi nə hasil?
Bazar pozuldu, yığ büsatın!
Bu silsilədən kəs irtibatın!
Leyli sənə verdi zindəgani,
Sən ol baqi, ol oldu fani!
Sən sədqəsi olduğun pərivəş
Sədqə sənə oldu, ey bəlakəş!
Əzmi-rəhi-cənnət etdi ol hur,
Firdövs məqamın etdi mə'mur."
Məcnun ki, xəbərdən oldu agah,
Suzi-cigərilə çəkdi bir ah
Kim, qülqüləsin həm ol zamanda
Cananı eşitdi ol cahanda...
Az qaldı ki, naləsilə dildar
Ol xabi-əcəldən ola bidar.
Bir ləhzə bülənd olub xüruşi,
Düşdü yerə, getdi əqlü huşi.
Çün gəldi özünə, qıldı nalə,
Yağdırdı xəzanı üzrə jalə...


215


Tə'nə sözün etdi Zeydə bünyad:
"K'ey saqiyi-bəzmi-zülmü bidad!
Netdim sənə qəsdi-canım etdin?!
Qəsdi-dili-natəvanım etdin!
Qıydın məni-zarii natəvana,
Urdun sitəm atəşini cana.
Zəhr idi məgər bu verdigin cam
Kim, mərg pəyamın etdi e'lam?
Bir murçəyə nədir bu kinə,
Fulada döyərmi abiginə?
Tə'siri-sitəmdən ictinab et,
Barı bu günaha bir səvab et!
İlət məni yar olan diyara,
Şəm' eylə məni məzari-yara!"
Düşdü yola, oldu Zeydə həmrah,
Bir hal ilə kim, nəuzübillah...
Çün gördü məzari-gülüzarın,
Düşdüyü qucaqladı məzarın.
Köksünü qılıb ləhəd kimi çak,
Mərqəd kimi saçdı başına xak.
Qəbr üzrə axıtdı qanlı yaşın,
Lə'l eylədi yaşı qəbri daşın.
Yer üzün edib sirişki məmlu,
Keçdi yerə ol sirişkdən su.
Oldu düri-əşki-biqərarı
Qəbr içrə nigarının nisarı.
Göz yaşını eylədi müxatəb:
"K'ey tirə şəbi-fəraqə kövkəb!
Çıxmaq sənə oldu indi vacib
Kim, oldu ol afitab qaib!
Bir bürci məqam tutmuş ol mah
Kim, olmaz ona nəsim həmrah.
Sən durma əgər mürüvvətin var,
Gir torpağa, istə onu zinhar!
Gör qandadır ol düri-yeganə,
Netmiş ona afəti-zəmanə!


216


Pabus edibən yetir niyazım,
Bildir bu təzərrö ilə razım:
"K'ey şəm', nədir bu ictinabın?
Mən bəxti siyahdan hicabın?
Cami-meyi-qəm tutanda aləm
Həm sən içdin bu camı, mən həm.
Məst etdi məgər səni bu badə
Kim, bəzmdə durmadın ziyadə?
Bir nadirə şərn' idin şəbəfruz,
Düşdü sənə zövqi-eşqdən suz,
Bir neçə zaman əgərçi yandın,
Suzi-dilə dözmədin, usandın.
Bidarlığa gətirmədim tab,
Şəhla gözün oldu maili-xab.
Həmrahım idin bu yolda, ey mah!
Həmrahı qoyub gedərmi həmrah?
Əflaka təfaxür eylə, ey xak
Kim, oldu rəfiqin ol düri-pak!
Zülflinə müariz olma, ey mar,
Kim, onda müqimdir dili-zar!
Xalına təərrüz etmə, ey mur,
Kim, bağlıdır onda cani-məhcur!
Ey ömr, gəl indi başa sən həm
Kim, çeşmimə tirə oldu aləm!
Aləm xoş idi ki, var idi yar,
Çün yar yox, olmasın nə kim var!
Ey can, təni-xəstəni vida et,
Bu xəstə ilə yetər niza et!
Müştaqinəm, ey əcəl, kərəm qıl!
Dəf i-ələm ilə rəf i-qəm qıl!
Qurtar məni iztirabi-qəmdən!
Ver müjdə vücudimə ədəmdən!
Ayinəmi eylə jəngdən pak,
Qıl pərdeyi-e'tibarımı çak!
Rəf et, nə isə arada hail,
Eylə məni ol nigara vasil!


217


Təklifİ-vüsal edər mənə yar,
Bir xəlvətə kim, yoxdur əğyar.
Mən getməmək eyləsəm, xətadır,
Səndən mənə bir mədəd rəvadır.
Billah, mədədimdə qılma ehmal
Kim, bəxtimə üz veribdir iqbal.
Ya Rəb, mənə cismü can gərəkməz,
Cananımsız cahan gərəkməz!
Minbə'd zəlilü xar qılma,
Sərgəşteyi-ruzigar qılma!"
Əfganda ikən gedib qərari,
Oldu bu qəzəl dilində cari:

**QƏZƏL**

Yandı canım hicr ilə, vəsli-rüxi-yar istərəm,
Dərdməndi-firqətəm, dərmani-didar istərəm.

Bülbüli-zarəm, degil bihudə əfgan etdigim,
Qalmışam nalan qəfəs qeydində, gülzar istərəm.

Dəhr bazarında kasiddir mətai-himmətim,
Bu mətai satmağa bir özgə bazar istərəm.

Fani olmaq istərəm, yə'ni bəlayi-dəhrdən
Rahəti-cismi-zəifü cani-əfgar istərəm.

Nola gər qılsam şəbi-hicran təmənnayi-əcəl,
Neyləyim, çoxdur qəmim, dəf'inə qəraxar istərəm.

Çün bəqa bəzmindədir dildar, mən həm durmazam
Bu fəna deyrində, bəzrai-vəsli-dildar istərəm.

Ey Füzuli, istəməz kimsə rizasilə fəna,
Mən ki, bundan özgə bilmən çarə, naçar istərəm.


218


**TƏMAMİYİ-SÜXƏN**

Çün razi-dərunin etdi təqrir,
Rə'yinə müvafiq oldu təqdir.
İmdad qılıb inayəti-Həq,
Qıldı onu məqsədinə mülhəq.
Gül dərdi hədiqeyi-əməldən,
Mey içdi sürahiyi-əcəldən.
Qəbrini qucaqladı nigarın,
Can sədqəsi etdi ol məzarın.
"Leyli!" - dedi verdi cani-şirin
Ol aşiqi-biqərarü miskin.
İnsaf, həmin ola məhəbbət,
Bu dairədir məqami-heyrət.
Guya ki, əlində idi canı,
Daim gözədirdi ol zəmanı,
Çün dövr ilə yetdi ol zəmana,
Ondan bir icazət oldu cana.
Hər necə ki, var idi nigarı,
Aləmdə idi onun qərarı,
Çün qıldı nigan tərki-aləm,
Bu aləmi tərk qıldı ol həm.
Çün gördü bu halı Zeydi-qəmnak,
Əfğan qılıb etdi yaxasın çak,
Fəryad ilə qıldı növhə bünyad,
Övci-fələkə yetirdi fəryad.
Zar ağladı öylə kim, həm ol dəm
Ahı oduna yığıldı aləm.
El cəm' olub etdilər nəzarə,
Məcnuni-siyahruzigarə.
Qəbr üstünə gördülər yıxılmış,
Cananəyə can nisar qılmış.
Əhvalına ağlayıb sərasər,
Dəfn etməgin etdilər müqərrər.
Qüsl eyləyibən təni-nizarın,
Dildarının açdılar məzarın.
Qoydular onu həm ol mazara,


219


Qəmnak yetişdi qəmküsara.
Ruh oldu fələkdə ruha həmraz,
Tən oldu tən ilə yerdə dəmsaz.
Rəf oldu təəllüqati-hail,
Mətlubuna talib oldu vasil.
Bir bəzm iki şaha məhfıl oldu,
Bir bürc iki maha mənzü oldu.
Qəbr üstünə qoydular nişanə,
Faş oldu bu macəra cəhanə.
Tövfündə qılıb murad hasil,
Ol qəbrə xəlayiq oldu mayil.
Keçdikcə zaman mükərrəm oldu,
Hacətgəhi-əhli-aləm oldu.
Budur əsəri-məhəbbəti-pak,
Xoş mərtəbədir bu, qılsan idrak.



220


**BU, ZEYDİN LEYLİ İLƏ MƏCNUNU**
**RÖ'YASINDA GÖRDÜGÜDÜR**

Ol məşhədə Zeyd olub mücavir,
Asari-sədaqət etdi zahir.
Tə'mir üçün etdi çox ətalar,
Tədric ilə qıldı çox binalar.
Peyvəstə hərarəti-cigərdən
Qəndili-məzarın etdi rövşən.
Carub ilə ab olan mətlub,
Müjgan ilə əşki abü carub.
Hər ləhzə qılırdı tazə matəm,
Qılmazdı fəğanü naləsin kəm.
Ol munisü müşfiqü müvafiq
Bir gecə qəribi-sübhi-sadiq,
Bimar tənində qalmayıb tab,
Qılmışdı məzara yastanıb xab;
Xab içrə göründü ol nizarə
Bir bağdə iki mahparə.
Rüxsarlərində zövqdən nur,
Bimi-qəmü dərdü qüssədən dur.
Xoşvəqtü nişatməndü dilşad,
Əğyar təərrüzündən azad.
Hər məhvəşə min fıriştəsurət
İxlas ilə olmuş əhli-xidmət.
Sordu ki: "Bular nə mahlərdir?
Nə rütbəli padşahlərdir?
Bu rövzə nə rövzeyi-bərindir,
Bu qövm nə qövmi-nazənindir?"
"Budur, - dedilər, - riyazi-rizvan,
Bu qövmi-xücəstə - hurü qılman.
Bu iki məni-xücəstərüxsar
Məcnun ilə Leyliyi-vəfadar.
Çün vadiyi-eşqə girdilər pak,
Ol paklik ilə oldular xak,
Mənzilləri oldu baği-rizvan,
Çakərləri oldu hurü qılman,


221


Çün bunda riza verib qəzaya,
Səbr eylədilər qərnü bəlaya,
Getdikdə cəhani-bivəfadan,
Qurtuldular ol qəmü bəladan.
Çün Zeyd yuxudan oldu bidar,
Bu nüktəyi etdi xəlqə izhar.
Xəlqin olub e'tiqadı əfzun,
Ol qəbrə ziyarət oldu qanım.

**TƏMAMİYİ-SÜXƏN**

Saqi, mütəğəyyir oldu halım,
Söyləşməyə qalmadı məcalım!
Minbə'd ziyadə vermə badə,
Rəhm eylə ki, sərxoşam ziyadə!
Xoş qəflət ilə keçirdim əyyam,
Bilmən ki, nolur işim sərəncam?
Sənnayeyi-ömr getdi əldən,
Sud etmədim etdigim əməldən.
Fəryad bu cövrdən ki, gərdun
Əhvalımı eylədi digərgun.
Dün dideyi-tər qılıb gühərbar,
Gərduna dedim ki: "Ey cəfakar!
Hərgiz rəvişindən olmadım şad,
Dami-qəmü möhnətindən azad.
Əhbaba nəqiz dövr edərsən,
Ərbabi-kəmala cövr edərsən.
Məcnun əgər olsa idi cahil,
Olmazdım itaətində kahil,
Fərmanına inqiyad edərdin,
Könlünü müdam şad edərdin.
Əhli-hünər olduğu səbəbdən,
Sahibnəzər olduğu səbəbdən,
Əqranı içində xar qıldın,
Biizzətü e'tibar qıldın.
Leyli gər olaydı bir həyasız,


222


Ya, sən kimi mehrsiz, vəfasız,
Olmazdı ona həmişə cövrün,
Kamınca müdam olurdu dövrün.
Fəzl əhlinə mayil olduğundan,
İdrak ilə kamü olduğundan,
Daim qəm əlində zar qıldın,
Aşüfteyi-ruzigar qıldın.
Mən həm gər olaydım əhli-təzvir,
Etməzdin ianətimdə təqsir.
Səndən qərəzim olub sərəncam,
Dövründə mənə olurdu aram.
Çün əhli-vüqarü nəngü arəm,
Cövrünlə həmişə xarü zarəm.
Bu üzdən imiş sənin mədarın,
Var, indi ki, yoxdur e'tibarın!"
Gərdun eşidib mənim itabım,
Verdi bu əda ilə cəvabım:
"K'ey surəti-haldən xəbərsiz!
Hər hikmətə eyb edən hünərsiz!
Mən əmrə müvafiq eylərəm dövr,
Hikmətdə vəfadır etdigim cövr.
Əmma, sən edən əməl xətadır
Kim, piri-təriqətin həvadır.
Şairtiyə iftixar edibsən,
Kizbi özünə şüar edibsən.
Məcnun dedigin vücudi-kamil
Hər danişə məndən oldu qabil.
Divanə ona sən eylədin ad,
Səndən ona yetdi zülmü bidad!
Leyli dedigin məhi-təmami,
Mən pərdədə saxladım girami.
Rüsvayi-xəlayiq eylədin sən,
Min tə'nəyə layiq eylədin sən.
Gəh İbni Səlama zülmü ilhaq,
Gəh Növfələ qədri qıldın itlaq.
Şərm et, bu nə hərzədir, nə möhməl?
Nə İbni Səlamü qanğı Növfəl?


223


Şərh eyləmək istədin fəsanə,
Qıldın sözə onları bəhanə.
Gördü çürümüş sümüklər azar,
Töhmətlərinə olub giriftar,
Əmvat məzaliminə girdin,
Asudələrə əzab verdin.
Cürmünə olanda xəlq mülzəm,
Lazım sorulur bu iftira həm.
Olmazmı bu baisi-əzabın?
Bu məsələdə nədir cəvabın?"

**CƏVABİ-MƏSƏLƏ**

Ey tutiyi-bustani-göftar,
Sərrafı-süxən, Füzuliyi-zar!
Aldanma, əgər sipehri-laib,
Tə'n itə sənə dedisə kazib.
Əş'arə yaman deyib usanma,
Sərmayeyi-nəzmi səhl sanma!
Sözdür gühəri-xəzaneyi-dil,
İzhari-sifati-zatə qabil!
Can sözdür, əgər bilirsə insan,
Sözdür ki, deyərlər, özgədir can.
Bİllah, bu yamanmıdır ki, hala
Əmvata söz ilə verdin əhya?
Məcnun ilə Leyliyi qılıb yad,
Ərvahlarını eylədin şad?


224


**BU, BƏYANİ-ÜZRİ-TƏ'LİFİ-KİTABDIR**
**və**
**TARİXİ-ZƏMANİ-FƏTHİ-BABDIR**

Ey kilki-rəvəndə, barəkallah!
Oldun məni-rəhnəvərdə həmrah.
Min sə'y ilə hacətim bitirdin,
Bir mənzilə aqibət yetirdin.
Rəhmət sənə kim, sən etdin imdad,
Bu əski binayı etdin abad:
Əşk ilə biruni siməndud,
Ah ilə dəruni ənbəralud,
Məxzənləri gənci-gövhəri-dərd,
Rövzənləri mənfəzi-dəmi-sərd.
Əlqissə, mürəttəb oldu bir bağ,
Zər laləsi bağrı üzrə yüz dağ.
Xuni-cigər abi-cuyban,
Növki-müjə əbri-növbəharı.
Ol dəm ki, bu nüsxə oldu mərqum,
"Leyli-Məcnun" adıyla mövsum,
İzharə gəlib rümuzi-vəhdət,
Vəhdətdə təmam olub hekayət,
Tarixinə düşdülər müvafiq:
Bir olmaq ilə ol iki aşiq [1] .


225


**BU, ƏRBABİ-VƏFADAN**
**TƏVƏQQÖİ-QƏBULİ-MƏ 'ZİRƏTDİR**
**və**
**ƏSHABİ-ZƏKADAN**
**TƏMƏNNAYİ-DUAYİ-MƏĞFİRƏTDİR**

İnsaf ver, ey həsud, insaf,
Tə'n etmə ki, cövhərin degil saf!
Əhvalımı gör xərabü müztər,
Ənduhi-zəmanədən mükəddər.
Söz dairəsi degil bu əhval,
İnsaf mənə kim, olmazam lal.
Məndən təmə1 etmə fıkri-saib,
Əhvalımadır sözüm münasib.
Azdır demə cövhəri-səfasın,
Bir sor ki: "Nə verdilər bəhasın?"
Billah, gər olaydı bir xiridar,
Min gənci-nihan qılardım izhar.
Filcümlə bu həm ki, oldu məstur,
Bir şövq ilə zövqdən degil dur.
Eybi hünər ixtiyar qılma!
Şe'rim həsədin şüar qılma!
Bihudə yetər, təərrüz eylə,
Gər qadir isən, cəvab söylə!
Tərk eylə təərrüzü inadi
Kim, vadiyi-cəhldir bu vadi!
Dəm xeyr sözündən ur dəmadəm,
V'ər xeyr deməzsən - əbsəm, əbsəm!


226


227


228


Ey verən bəzmi-kainatə nəsəq,
Buraxan cami-eşqə nəş'əyi-Həq!
Eşq meyxanəsin qılan mə'mur,
Sunan ondan cəhana cami-qürur
Kim, edib ol qürur camın nuş,
Əhli-nitq ola valehü mədhuş;
Cümlədən məxfi ola əsrarı
Olmaya hiç kim xəbərdan.

**ARİZU**
**KƏRDƏNİ-TƏRİQİ-SƏVABI** **[1]**

Ey sifatında xirə hər müdrik!
"Ma ərəfnakə həqqə mə'rifətik". [2]
Nəş'eyi-danişin müfərrihi-can,
Ari ol keyfiyyətdən əhli-cahan.
Meyi-eşqindən afəriniş məst,
Bəzmi-şövqündə cüralə badəpərəst.

**DƏR**
**MÜNACATİ-FATEH-ÜL-ƏBVAB** **[3]**

Ya Rəb, əfsürdəyəm məni-nahl,
Həddən ötdü xumari-badeyi-cəhl.
Qoyma əfsürdəvü pərişanhal,
Eşq odundan mənə hərarət sal.
Bəzmi-eşq içrə sun mənə bir cam,
Leyk cami ki, nəqsim edə təmam.


1 Savab yolu arzulamaq
2 Biz sənı layiqincə tanımadıq
3 Qapılar açanın (Allahın) münacatı

229


Qıla asari-mə'rifət izhar,
Ola miftahi-məxzənül-əsrar.
Nə şərabi ki, əqli zail edə,
Taətindən könülnü qafil edə.
Ola mütləq fəsadi-din səbəbi,
Bula ondan zəval şər'i-nəbi.

**HƏST İN**
**NƏ'Tİ-ƏHMƏDİ-MUXTAR** **[1]**

Nəbuiyi-Haşimi ki, bəzmi-vücud
Cami-eşqindən aldı nəş'əyi-bud.
Piri-meyxaneyi-qədimü qidəm,
Saqiyi-bəzmü həlqeyi-xatəm.
Hər zaman min səlamü min sələvat,
Onavü ol imamə qıl bizzat.

**ŞƏMMEYİ-VƏSFİ-HEYDƏRİ-**
**KƏRRAR** **[2]**

Yari-Səlmanü xaceyi-Qənbər,
Valiyi-Rövzə, saqiyi-Kövsər.
Oldur ayinədari-surəti-Həq,
Nə vəsi, varisi-nəbi mütləq.
Nazimi-şər'ü saqiyi-Kövsər,
Babi-Şübbeyrü validi-Şəbbər.

**BAŞƏD İN**
**MƏDHİ-PADŞAHİ-ZƏMAN** **[3]**

Saqiya, sübhdəmdir, eylə şitab,
Dövrə gəlsin çü mehr cami-şərab!
İztirab içrəyəm, xumarım var,
Badəyə xeyli intizarım var.


1 Bu, Əhməd-Muxtarın (Məhəmmədin) nətidir
2 HeydəriKərrarın (Əlinin) sifətlərindən bir neçə kəlmə
3 Bu, zəmanə padşahın mədhidir

230


Qalib olmuş mənə raəhabəti-bəng,
Vəhm edib eylərəm hər işdə dirəng.
Cami-mey sun ki, ta diliranə
Mədh edim padişahi-dövranə.
Ol səfabəxşi-cami-Cəm ki, müdam
Təxt qeyrinədir çü badə həram.
Ol ki, başlar zamanda bəzmi-fərağ,
Padişahlar başından eylər əyağ.
Cami-feyzin içən, Məsihatək,
Feyzi-ruhül-qüdüs tapar bişək.
Mey kimi ruhi-xəlqə nəş'ərəsan,
Nəş'ətək hökmü el başında rəvan.
Dövrü bir bəzmdir behişti-bərin,
Tac zərrin, sürahi həm zərrin.
Bu sürahidən olmayan xoşhal,
Dürd nisbət müdam ola pamal.
Camtək təlxkam olub əbəda,
Bəngtək təndən ola başı cüda.
Məclisəfruzi-bəzragahi-Xəlil,
Cəmi-əyyam, şah İsmayil.
Ondan asudədir qəniyyü gəda,
Xəllədəllahü mülkəhü əbəda. [1]
Ol ki, cami-mey olalı bünyad,
Qədəh ondandır, ol qədəhdən şad.

**BAŞƏD İN**
**VƏSFT-SAQİYT-DÖVRAN** **[2]**

Saqiya! Badə sun ki, fürsətdir,
Bizə fürsət bu gün qənimətdir.
Lalətək qoymağıl əlindən cam,
Var ikən fürsət, eylə eyş müdam.
Nərgisi gör ki, nəş'əsi getməz,
Başı gedərsə tərki-can etmez.


1 Allah onun mülkünü əbədi etsin.
2 Bu, zəmanə saqisinin tə'rifidir.


231


Sən dəxi aciz olma, canın var,
Canın olduqca badə tut zinhar
İstəsən kim, mey abi-Kövsər ola,
Ol sənə müttəsil müyəssər ola,
Bezmi-ali-Əlidə məskən tut,
Məstlər kimi özgə bəzmi unut.

**İBTİDAİ-HEKAYƏTİ-MEYÜ BƏNG** **[1]**

Saqiya, bilməzəm mənim nəmdir,
Həmdəmim qüssə, məhrəmim qəmdir.
Qəm meyi-lə'l axıtdı yaşımdan,
Qüssə bəngim uçurdu başımdan.
Kəlləxüşk olmağım çü Bəng yetər,
Bir əyağ ilə qıl dimağımı tər,
Ta sənə bir əcəb hekayət edim,
Bəng ilə Badədən rəvayet edim:

                    - * *
Bir gün əyyami-növbaharda mən
Tutmuş idim çü lalə tərfi-çəmən.
Səbzəvü gül solumda, sağımda,
Bəng başımda, mey əyağımda.
Bəngtək nəş'ə ilə başım xoş,
Bəngü mey hazirü məaşım xoş.
Bağ həm qeyrəti-behişti-bərin,
Bəzm qurmuş cəhana xüld ayin.
Lə'li-tərdən nəsimi-ənbərbu,
Qönçə minasın eyləmiş məmlu.
Nüql ilə dolmuş idi gül təbəqi,
Qürsi-limu töküb səmən vərəqi.
Doldurub saqiyi-səba hər dəm
Cami-gül içrə badeyi-şəbnəm,
Bülbüli-xəstədən aparmış huş,


1
"Badə və Bəng" hekayəsinin başlanğıcı

232


Qumriyi-zarı eyləmiş mədhuş.
Yasəmən doldurub sürahiyi-zər,
Zərdcə badə ilə vəqti-səhər,
Səbzəni etmiş eylə layə'qil ki,
düşüb cuya rəxtin etmiş gil.

**DƏR SİFATİ-ŞƏRABÜ SÖHBƏTİ-U** **[1]**

Gördüm ol bəzm içində bir məhbub,
Surəti xubü sirəti mərğub.
Türfə adı zəmanə məşhuri,
Ləqəbi Badə, əsli ənguri.
Sifət ilən qərineyi-xurşid,
Nütfeyi-Cəm, sülaleyi-Cəmşid.
Etmiş ol Badeyi-Süheyl xəvas,
Neçə həmdəmlər ilə söhbəti-xas.
Hazirü cəm' xidmətində çü cam,
Ərəqü Buzəvü Nəbid tamam.
Gərm ikən məclis içrə nuşanuş,
Ötərək məst olub Mey etdi xüruş
Ki: - Mənəm hər nə var ona faiq,
Xidməti-xəlqdir mənə layiq!
Olamı kimsə göstərə cür'ət,
Mənə endirməyə səri-taət?"
Badə qüğac şücaət izharın,
Gərm edib zərqü laf bazarın,

**SÜXƏNİ-SAQİYÜ İHANƏTİ-U** **[2]**

Dizi üstə çöküb rəvan Saqi
Dedi: - Ey Badə, işrətin baqi!
Dün ki, məhrum idim cəmalından,
Düşmüş idim cüda vüsalından;


1 Şərabın sifətləri və söhbəti
2 Saqinin söhbəti və onun etirafı


233


İstər idim səni gəhü bigah,
Bir əcəb bəzmə uğradım nagah.
Sədri-bəzm olmuş onda bir sərhəng,
Sərkəşü səbzpuşü sufirəng.
Zahirin xub gördüm öylə ki, var,
Batini həm degildi biəsrar.
Də'vi eylər ki: "Xızrdır mənə pir,
Ondan aldım dua ilə təkbir".
Bir zaman mən ona ki, həmdəm idim,
Bitəkəllüf ki, şadü xürrəm idim.
Söhbəti dilgüşa, özü xoşxu,
Leyk qayətdə zərqü lafi ulu.
Urar ol həm yeganəlikdən dəm,
Der ki: - "Aləmdə hər nə var mənəm".
Belə kim, mənlik eylər ol nakəs,
Baş çəkən səndən özgə oldur bəs."

Qatı məğrurü xudpərəst idi Mey,
Axiri-məclis idi, məst idi Mey.
Zuri-dəstinə e'timad etdi,
Nasəza ilə Bəngi yad etdi.
Tündü təlx oldu ol hekayətdən,
Qəzəbü qəhri artdı qayətdən.

**QƏZƏBİ-MEY BE SAQİYİ-SADƏ** **[1]**

Dedi: - Ey saqiyi-rəkiksüxən!
Bu nə sözdür, məgər ki, bəngisən?
Anladım böylə rəngi-ruyindən,
Bu diliranə göftü guyindən
Ki, xəyali-nifaq edibsən sən,
Bəng ilə ittifaq edibsən sən.
Bu aradan məni götürmək üçün,


1 Meyin sadəlövh Saqiyə qəzəblənməsi


234


Onu bir dövlətə yetirmək üçün.
Görəyim ol xəyali-xam olsun,
İltifatım sənə həram olsun.
Neçə yerlərdə gördüm, ey ovbaş,
Səni əgri vü qılmadım elə faş.
İmdi naçar üzünə çıxdım,
Səndən oldu ki, könlünü yıxdım.
Durma, dur imdi ər müvafiq isən,
Nüqltək söhbətimdə sadiq isən,
Dedigin serkeşin gətir başın,
Dəstgir eylə yarü yoldaşın!"

***

Saqi ol işdə tapdı heyranlıq,
Çəkdi ol qissədən peşimanlıq.
Qıldı məkr ilə ol şər işdə hiyəl,
Dedi: - Məstəm, aman mənə bu məhəl!
Sübhdəm kim, düşə güzarım ona,
Varayım, yazuyim xumarım ona.
Onu daş ilə səngsar edəyin,
Sındırıb cismini qübar edəyin."
Badə tünd oldu təəllüldən,
Bir qərəz anladı təğafüldən.
Saqiyi tutdu Mey, yaman tutdu,
Belə tutar kimi ki, qan tutdu.
Oldu saqi Meyin giriftarı,
Faş edən böylə olur əsrarı.

**ƏZMİ-TƏDBİR KƏRDƏNİ-BADƏ** **[1]**

Saqiya, qılma tərki-badeyi-nab,
İstəsən, Meydən istə fəthül-bab.
Meydir ayineyi-cəmalül-lah,
Zinhar, ondan eyləmə ikrah!


1 Badanin tədbir görmək cəhdi


235


Bir qədəh başla, nəş'əm eylə təmam
Ki, tapam qüvvəti-ədayi-kəlam.
***

Saqi olğac əsirü Mey müztər,
Atəşi-fitnə çəkdi şö'leyi-şər.
Yığdı yanına Badə əshabın,
Açdı tədbiri-dövlət əbvabın
Ki, bu dəklü [1] fəsada çarə nədir,
Çarə ol zişti-nabəkarə nədir?

**MƏSLƏHƏT DİDƏNİ-ƏRƏQ**
**BA MEY** **[2]**

Dedi əvvəl Ərəq ki: - Ey Meyi-nab!
Qılma nəş'ə xəyalı ilə şitab!
Şahsan, xəsmə çakər etmə özün,
Bir qulunla bərabər etmə özün.
Surəti-halına nəzər qılma,
Böyüdüb anı mö'təbər qılma!
Düşmə sövdasına, təğafül qıl,
Neçə gün səbr ilən təhəmmül qıl!
Ol sənin qədrü şövkətin nə bilir?
Öz-özündən çürür, ərir, əzilir.

**GÖFTÜ GUYİ-NƏBİD HƏM**
**ƏZ PEY** **[3]**

Çün Ərəq sozləri tükətdi, Nəbid
Dedi: - Ey nütfeyi-Cəmü Cəmşid!
Dövlət oldur ki, düşmən ola zəbun,
Olmadan bir şərarə şö'lə füzun;


1 "Kimi" mənasındadır
2 Arağın meyə məsləhəti
3 Ondan sonra Nəbidin (xurma şərabının) söhbəti.


236


Bir şəbixun ilə həlak edəyin,
Hiddətindən cəhanı pak edəyin.
Olmaya az ikən bu iş çox ola,
Dəxi dəf inə çarəsi yox ola.

**SÜXƏNİ-BUZƏ DƏR TƏDARÜKİ-HAL** **[1]**

Çün Nəbid eylədi sözünü təmam,
Dedi Buzə ki: - Ey Meyi-gülfam!
Nə təğafül, nə cəng qıl pişə,
Bu işə qıl bir özgə əndişə.
Ver ona lütf müjdəsilə firib,
Ola kim, ixtilatı ola nəsib.
Yanına gəlgəc ol fəsadi-zəman,
Eylə məkr ilə dəf ini pünhan.
Nə məsaf eylə kim, yaman ola ad,
Nə təğafül ki, gün-gün arta fəsad.

**HƏM İBA KƏRDƏNİ-MEY ƏZ ƏQVAL** **[2]**

Qılmadı hiç qövlü Badə qəbul,
Gəlmədi hiç söz ona məqbul;
Dedi: - Oldur səlah kim, əvvəl
Qılmayam irtikabi-cəngü cədəl,
Göndərəm qasid ilə, pənd verəm,
Bir neçə pəndi-sudimənd verəm.
Pənd isə tabe olsa, yarımdır,
Olmasa, cəng xud şüarımdır.
Kimdir imdi ki, əzmi-rah qıla.
Sayeyi-dövlətim pənah qıla,
Özünü Bəng məclisinə sala,
Sözümü söyləyə, cəvabım ala?"


1 Tədbir görülməsində Buzənin (pivənin) məsləhəti.
2 Şərabın danışıqlardan boyun qaçırması


237


**RƏFTƏNİ-BUZƏ**
**BORDƏNİ-PEYĞAM** **[1]**

Gəldi göftara Buzeyi-bədnam,
Laflar urdu ol nəməkbəhəram
Kim: - Mənə əmrin olsa, münqadam,
Mən səfər şiddətinə mö'tadam.
Bəngə peyğamın eyləyim iysal,
Görməsəm sülhə onda istiqbal,
Zərb ilən onu sərnigun edəyin,
Əzeyin, yencəyin zəbun edəyin."

                      - * *
Tutdu Mey Buzənin sözünə qulağ,
Dedi: - Ey Buzə, yaxşısan, üzün ağ!
Yeri, onun şükuhini sındır,
Badipayi-qüruridən endir!

**SİFƏTİ-BƏNGİ-ZİŞTÜ**
**BƏDFƏRCAM** **[2]**

Söylə məndən kim: ey füsürdə mizac,
Dəlisən, eylə bu cünuna əlac!
Bir əlac eylə, dəf i-sövda qıl!
Başına çarə tap, müdava qıl!
Ey zina kişvərinin övbaşı,
Müttəsil nikbətilərin başı.
Ey əsasi-binayi-hər vəsvas,
Əntə xənnasü fı südurinnas. [3]
Ey sərasər təsəvvürün batil,
Fisqü iğlamə ruzü şəb mayil!
Qaliba kim, xəmirini təqdir


1 Buzənin sifariş aparçası
2 Çirkin və pis xasiyyətli Bəngin sifətləri
3 Sən insan ürəyinin şeytanısan

238


Yüz fəsad ilə eyləmiş təxmir.
Der imşsən ki: "Hər nə var mənəm".
Kə'bsən, gər yetər başın göyə həm.
Sən yaman cəhl içində qalmışsan,
Ayın [1] öz başına ulalmışsan.
Hiç mə'qul söz deməzsən sən,
Qandadır kim, kötək yeməzsən sən?
Kimə olsan müsahib, ey cahil,
Olur əlbəttə, tənbəlü kahil.
İş məcalı qılırsan, ey sərsam,
Bir zamanın işin bir ildə təmam.
Əkl vəqti sənədir, ey bədşəkt,
Bir ilin quti bir zəmanlıq əkl.
Ey xirəd rəhgüzarının tikəni,
Tanrı xar eyləsin səni əkəni!
Baisi-nikbətü fəlakətsən,
Bəs ki, bədşəklü bədqiyafətsən.
Xah dərviş olavü xah qəni,
Usu [2] azar duşunda görsə səni.
Hər səadətsiz olsa yar sənə,
Şəmmeyi qılsa e'tibar sənə,
Məhv olub onda mərdlik əsəri,
Mütləq olmaz şücaətə cigəri.
Xürrəm olma ki, səbzdir sənə rəng,
Sənsən ayineyi-təbiətə jəng.
Səndən olur yünül ağır başlar,
Səni hər kim ələ alır, daşlar.
Əməlindir müxalifi-hikmət,
Xəlqə səndəndir əsli-hər illət.
Bu işə bitməgin gərək naçar
Ki, olasan qapımda xidmətkar.
Ya bu iqlimdən başın al get,
Yoxsa başın götür hüzuruma yet!
Məsttək məndən olma bipərva,


1 "Çox" mənasındadı.
2 Ağıllı


239


İttibaimdən etmə istiğna.
Mən əgər razı olmasam səndən,
Başına çox bəla gələr məndən.
Kəlləxüşk olmağı şüar etmə,
Gəl dimağın tər eylə, ar etmə.
Yaxma hirs oduna qurun, yaşın,
Həzər et kim, xətərdədir başın.
Şərm qıl, sərgiranlıq etmə yügüş,
Həddini tam, gəl ayağıma düş.
Yox özündən məgər sənin xəbərin
Ki, nə tərkibsən, nədir hünərin?
Guş qıl, fəzlini bəyan edəyin,
Olan əsrarını əyan edəyin.

**QİSSEYİ**
**DƏR SİFATİ-ƏSRARƏST** **[1]**

Var idi İsfəhanda bir meykəş,
Bəng manənd müttəsil sərxoş.
Bir əcəb qəsrdə tutub mənzü,
Meyə olmuşdu ruzü şəb mayil.
Bir gün ol rind məclisində şərab
Oldu manəndi-kimiya nayab.
Hasil oldu ona səda'i-xumar,
Yedi dəfinə zərreyi-əsrar.
Əsəri-bəng edib hücumi-təmam,
Tapdı mir'ati-əqli jəngi-zülam.
Şəb idi, leyk mahi-şəbəfruz
Qılmış idi cahanı qeyrəti-ruz.
Rəngi-məhtab idi nümuneyi-ab,
Qəsr ol ab içində şəkli-hübab.
Qəsrdən rind dışra qıldı nigah,


1Əsrarın (Bəngin) sifətləri haqqında bir hekayə.


240


Su göründü gözünə pərtövi-mah,
Dedi: - Ey vay, oldu iş müşkil,

Seyl tutmuş cahanı, mən qafil.
Suya, çarəm budur, özüm buraxım,
Dolmadan qəsr bir kənara çıxım.
Özümü qurtarım səbahət ilən,
Bir kənara çıxım fərağət ilən.
Ələ bir taxta parəsin aldı,
Yerə məhtab tək özün saldı.
Lət görüb başı fərş daşından,
Zərblən bəngi uçdu başından.
Dərdi-sər gördü, gəldilər hükəma,
Dedilər dərdinə şərab dəva.
Sənə budur hünər ki, şərh etdim,
Əhli-idrakə sor ki, mən netdim?
Mənim əslim, köküm təfəhhüs qıl,
Hörmətim səndən artıq olmağı bil.

**SİFƏTİ-XUBİYİ-MEYÜ**
**MEYXAR** **[1]**

Bilmiş ol kim, əzimü cəbbaram,
Sərkəşü sərfərazü sərdaram.
Kim ki, bəhs ilə baş qoşarsa mana,
Gər Firidun isə hərifəm ona.
Gəh olur huş alım dimağından
Ki, başın bilməyə ayağından.
Mən kiməm? - Həmdəmi-Cəmü Cəmşid,
Saflıqla qərineyi-xurşid.
Məhəki-cövhərim təmam əyar,
Laleyi-kuhsari-hilmü vüqar.
Bir binadır vücudi-şər'i-bəşər,
Sirri-təhqiqə olmağa məzhər.
Hər binada ki, yaxşıdır bünyad,
Onu əfzunraq eylərəm abad.
Hər binada ki, süstdür ərkan,


1 Şərabın və şərab içənlərin yaxşı sifətləri


241


Onu əslilə eylərəm viran.
Bu səbəbdən mənə yetən əshab,
Kimi xoş vəqtdir, kimisi xərab.
Düşdü Davuddan zəmirimə zövq,
Hüsni-avazə hasil etdim şövq.
Ərz qıldım Kəlimə surəti-hal,
Rifqimi qıldı ümmətinə həlal.
Qövmi-tərsayə mən tanıtdım rah,
K'etdilər [1] İqtidai-Ruhullah.
Mən həqiqətdə əhli-irfanəm,
Deməsinlər şəriki-şeytanəm.
Adəmə səcdə qılmayıb şeytan,
Tapdığında qürur ilə üsyan;
Məndən olsaydı nəş'əsi bir dəm,
Min gəz eylərdi səcdeyi-Adəm.
Riqqətəfzayi-aşiqi-zarəm,
Çöhrə-əfruzi-hüsni-dildarəm.
Nəzəri-aşiqü rüxi-məhbub,
Biri talib durur, biri mətlub.
Hicr ilə müşkil ikən onlara hal,
Mən buraxdım araya tərhi-vüsal.
Gərçi düşmənligimdə fitnəm çox,
Dustluqda dəxi misalım yox.
Hər nə dərd olsa, mən dəva verərəm,
Təb' güzgüsünə cila verərəm.
Bir xirədmənd aliməm mahir,
Batin əhvalın eylərəm zahir.
Məktəbi-meykədəmdə şamü səhər
Şərhi-təcrid oxur müdərrislər.
Padişahları, istəsəm, asan
Qılıram bir gəda ilə yeksan.
Gər gədaları, istəsəm filhal
Qılıram padişahi-bizərü mal.
Mənəm ərbabi-rif'əti-dərəcat,
Baisi-xeyrü daxili-həsənat.


1 Ki etdilər


242


Mənəm ol şəhryari-həft iqlim
Ki, mənə şahlar qılır tə'zim.
Hər kim olsa, əyağıma baş urar,
Mən gəlincə qamu əyağa durar.
Gövhərimdir mənim müfərrihi-zat,
Mənəm, əlqissə, mənşəi-həsənat.
Həsənatimi ondan eylə qiyas
Ki, demiş həq mənafeün-linnas.
Vəsfi-zatimdə bir hekayət var,
Guş gər tutsan, eylərəm izhar.

**SİFƏTİ-MAHRÜYİ-GÜLRÜXSAR** **[1]**

Var idi Reydə bir xücəstəxisal,
Mahtəl'ət nigari-mişkinxal.
Meyi-lə'li-ləbi nişatəfzay,
Nüqli-göftarı nəğzü bəzmaray.
Meyə düşmüşdü əksi kimi, müdam
Aliban müttəsil qədəhdən kam.
Bir gün ol sərvqəddü gülrüxsar
Qıldı zöhhad məclisinə güzar.
Gördü bir zahidi-pərişanhal,
Keçmiş övqatı zöhd ilən məhü sal,
Bilməmiş kim, məzaqi-badə nədir,
Xətti-mişkinü ruyi-sadə nədir.
Xəlqə eylər hekayəti-məhşər,
Sifəti-huri, cənnətü Kövsər.
Növcavan qıldı meyli-Kövsərü hur,
Dedi əcz ilə: - Ey xudayi-qəfur!
Var ümidim ki, əhli-cənnət olam,
Mən dəxi müstəiddi-rəhmət olam.
Qeybdən gəldi bir nidayi-lətif
Qulağına ki: "Ey hərifi-zərif!
Tanrı bir padişahi-adildir,


1 Ayüzlü, gülyanaqlının sifəti


243


Feyzi məcmui-xəlqə şamildir.
Kərəmindən o qadiri-qəyyum
Eyləməz hiç kimsəni məhrum.
Kimi dünyada şadiman eylər,
Kimi üqbada kamiran eylər.
Sən ki, dünyada əhli-işrətsən,
Sakini-məsnədi-məsərrətsən,
İçdigindir nişatilən meyi-saf,
Kövsər ummaq degil sənə insaf.
Qərəzin Kövsər isə meydən keç,
Yoxsa al nəqdi, nisyə istəmə heç.
Badə məhrumi abi-Kövsər içər,
Kimsə, Kövsər demə mükərrar içər.
Bu dəlil ilə Badə Kövsər imiş,
Gör nə xoş nəsnəyə bərabər imiş.
Bəng kimdir hərifi-Badə ola?
Bəhs qılsa, həramzadə ola.
Cəddi-pakim həqiçün, ey Əsrar,
Olmasan dərgəhimdə xidmətkar,
Gəlib endirməsən əyağıma baş,
Eyləsən aqibət mənimlə savaş,
Qılmadan tirə ruzigarını mən,
Göyə savurmadan qübarını mən,
Tutsam aram biqərar olayın,
Rəddi-dərgahi-kirdgar olayın!"

**SİFƏTİ-BƏZMİ-BƏNGİ-**
**NAFƏRHƏNG** **[1]**

Badə qılğac təmam göftarın,
Buzə nəqşi-zəmir edib varın,
Qıldı əzmi-rəhi-məhəlleyi-Bəng,
Oluban qasidi-Meyi-gülrəng.


1 Hünərsiz Bəngin məclisi haqqında


244


                    - * *
Bəngi-xoşsirətü nikukirdar,
Neçə həmdəmlər ilə fəsli-bahar,
Bir əcəb mərğzar içində müdam
Tutmuş idi nişatilən aram.
Bərş idi həm Müfərrihü Əfyun,
Hər biri rə'ylən bir Əflatun.
Gəh düşüb elmi-şər'dən göftar,
Gah hikmət sözü olub təkrar.
Gərm ikən bəhsi-elmü fəzlü kəmal,
Mütəvatir olub cəvabü sual,
Verdilər Bəng həzrətinə xəbər
Ki, "Durubdur qapında bir çakər,
Der ki, Meydən gətirmişəm peyğam,
İstərəm rüxsəti-ədayi-kəlam".
Bəngdən rüxsət eyləyib hasil,
Buzeyi-ziştruyi-naqabil
Girdi ol bəzmi-xasə amanə,
Başladı hərzə-hərzə əfsanə.
Mey sözün dedi ol pəlidi-kərih,
Bəlkə yüz nüktə həm məzidün-fih.

**DİDƏNİ-BUZƏ TƏ'NƏHA ƏZ BƏNG** **[1]**

Bu xəbərlərdən oldu şeyda Bəng,
Buzəyə düşdü bimühaba Bəng.
Başına çıxdı qəhrdən sevda,
Buzəni qıldı tə'n ilə iyza:
"K'ey qəlizü pəlidü nahəmvar!
Gəndeyi-ziştü natəmam əyar!
Sən qədimi mənim ənisim idin,
Nə ənisim ki, kasəlisim idin.
Badənin xud səninlə yox meyli,
Olsa ondan bəiddir xeyli.


1 Buzenin Bəngdən tənələr eşitməsi.


245


Sən nəsən ki, səninlə yar olalar,
Gizli işlərdə razidar olalar?
Heyf, Mey həm əgərçi düşməndir
Ki, rəfiqi bu növ' kövdəndir.
Layiq oldur səni məlamət edəm,
Bu günü başına qiyamət edəm.
Kövdənü əhməqü turuşrusən,
Bədrəgü bədxisalü bədxusən.
Meyə oldun bu fitnədə ortaq,
Sınacaqdır sənin başında çanaq.
Fərz olubdur sənə cəfa qılmaq,
Ağ ikən üzünü qara qılmaq.
Haliya çün rəsulsən naçar,
Sənə məndən rəva degil azar.
Mihmansan, bu gecə etgil xab,
Verəyin sübh sözlərinə cavab."
Bəzmi-Bəng içrə Buzə tutdu səbat,
Bəng xüddamı etdilər xədəmat.
Buzə ol cəm'ə həmnişin oldu,
Sə'd ilə nəhs həmqərin oldu.
Məclisi-xas idivü cəm'i-zərif,
Mə'məni-pak idivü qövmi-şərif.
Çün küdurət gedib səfa gəldi,
Gərm olub mə'də iştəha gəldi,
Çəkdilər türfə-türfə maddələr,
Öylə kim, şairi-əcəm söylər:
"Hərçi əndişə dər güman avərd. [1]
Mətbəxi rəftü dər miyan avərd."
Gah paludə gəldi, gah həlva,
Gəh müzə'fər çəkildi, gəh buğra.
Çünki çox gördü bəngiyanə təam,
Püxtəlik qıldı Buzeyi-bədnam,
Qalmadı qəltəbanın ol cuşi,
Oldu göftari-Mey fəramuşi,
Dedi: "Ey Bəng! Badədən keçdim,


[1] (Xidmətçi) mƏtbəxə getdi və güman gələn hər şeyi ortaya gətirdi.

246


Getməzəm ol yanaya, and içdim.
Mən sənin bir kəminə çakərinəm,
Eşigində qulami-kəmtərinəm.
Çoxdurur Badənin fəsadü şəri,
Səndədir fəqrü məskənət əsəri.
Buzə çün Bəngə oldu xidmətkar,
Bəng feyzilə vaqifi-əsrar,
Ol gecə Bəngü sairi-əshab
Qıldılar rahətü sürur ilə xab.
Sübhdəm kim, sipehri-camxüram
Saçdı Bəng üstünə meyi-gülfam,
Dürdsa təhnişin olub əxtər,
Saf meykimi çıxdı şö'leyi-tər.
Bəng fikrət dənizinə daldi,
Ortaya tərhi-məşverət saldı
Ki: "Nədir çareyi-şərarəti-Mey,
Necə təskin tapar hərarəti-Mey?"

**DƏR NƏSİHƏT NUMUDƏNI-ƏFYÜN** **[1]**

Dedi Əfyun ki: - Olmağıl qəmnak,
Mənəm ol zəhr dəfinə tiryak.
Qılayın gecələr yuxunu haram,
Yeməyəm nəsnə, tutmayam aram,
Edəyim zaye etdigi əməgin,
Ağrıdıb həmnişinlərin yürəgin.

**BƏRŞ HƏM MÜTTƏBE ŞÜDƏ ƏKNUN** **[2]**

Bərşə çün düşdü söz, dedi: - Ey Bəng!
Onun ilə nə hasil eylər cəng?
Nə rəva cəng öylə sərkeş ilə,
Ələfı-xüşk netsin atəş ilə?


1Əfyunun nəsihət etməsi
2 Bərşin də ona tabe olması.


247


Necə kim, mülkə ol verir rövnəq,
Kimsə meyl eyləməz sənə mütləq.
Sınmadan bu nizai tərk edəlim,
Bütün ikən bu mülkdən gedəlim.

**PƏNDİ-MƏ'CUN BƏ GUŞİ-ƏSRARƏŞ** **[1]**

Dedi Mə'cun ona ki: - Ey Əsrar.
Nə həzimət, nə cəng eylə şüar.
Layiq oldur onunla sülh edəsən,
Gər tələb qılsa, yanına gedəsən.
Eylə dəf inə məkr ilən tədbir,
Safdildir, yeri, mizacinə gir.
Qafil etmə özün müdaradan,
Hiylə yeyrək degilmi qövğadan?

**BƏNG TƏDBİR KƏRDƏN İZHARƏŞ** **[2]**

Qılmadı Bəng hiç qövlü pəsənd,
Gəlmədi hiç söz ona xürsənd,
Dedi: - Mən həm rəsul göndərərəm,
Sözlərinə cəvab döndərərəm.
Qılsa taət, riayətim görsün,
Qılmaz olsa, siyasətim görsün.

**ZİKRİ-MƏ'CUNÜ DƏR RİSALƏTİ-U** **[3]**

Ey Müfərrih, sənədir indi ümid,
Olasan fəth qapusinə kilid.
Səndədir hüni-xülqü lütfi-əda,
Çox görübsən məcalisi-hükəma.


1 Mə'cunun Bəngə (Əsrara) nəsihəti.
2 Bəngin öz tədbirini söyləməsi
3 Mə'cunun elçiliyiə göndərilməsi


248


Səndə irfan cəvahiri çoxdur,
Səndəki rütbə kimsədə yoxdur.
Qərəzim olmağa sən eylə şitab,
Sən mənə qövmsən, nə bu əhsab.
Var, məndən Meyə nəsihət qıl!
Gər qəbul etməsə, fəzihət qıl!

**DƏR SİFATİ-MEYÜ**
**ŞƏRARƏTİ-U** **[1]**

Söylə: Ey bihəyayi-bihudəgərd,
Müfsidi hər səlah olan namərd!
Həmdəmin hər kim olsa leylü nəhar,
Gah divanədir, gəhi bimar.
Bu cahanda budur sənə tə'sir,
Ol cahanda dəxi zəqumü səir.
Sənsən ol rəhnümayi-əhli-əzab
Ki, ayağın yetən yer oldu xərab.
Məkrilən alın et evini yıxar,
Bu fəsadın saqınma, başə çıxar.
Ey bəsa əhli-təxtü sahibi-tac
Ki, qılıbsan bir ətməyə möhtac.
Ey bəsa huşiməndi-fərzanə
Ki, qılıbsan səfihü divanə.
Baisi-fitnəvü şərarətsən,
Nəcisül-eynü bitəharətsən.
"İnnəməl-xəmrü" ayesini oxu
Ki, sənindir kinayətində çoxu.
Qanda gəbr olsa, həmnişinindir,
Bu səbəbdən ki, dini dinindir.
Ulular səndən etməyə ikrah,
Olur, əlbəttə, asiyi-dərgah.
Kiçilər səndən etməsə pərhiz
Çıxar, əlbəttə...


1 Meyin sifətləri və onun (törətdiyi) şər haqqında


249


Çün xəmirən zinaya rağibdir,
Axta qılmaq səni münasibdir.
Sənsən olmuş müqəyyəd öz-özünə,
Cüzvi işdən çıxarsan el üzünə.
Kimə oldunsa məhrəmü yoldaş,
Gizli sirrini qıldın ellərə faş.
Əsərin düşsə hər yerə çoxü az,
Qılmaz əhli-şəriət onda namaz.
Çakərin oldu çəng, zar oldu,
Damənin tutdu dürd, xar oldu.
Tutdu bir ev himayətində hübab,
Eylədin al ilə evini xərab.
Şeyx Sən'ana bir dəm oldun yar,
Tərki-din etdi, bağladı zünnar.
Həmzə tədbirin ilə qıldı əməl,
Naqeyi-Salehə yetirdi xələl.
Səndə yoxdur təriqeyi-cədü əb,
Sən ədəbsizsən, onlar əhli-ədəb.
Səndə yoxdur təbiəti-fərzənd,
Son münafiqsən, ol səadətmənd.
Sirkə səndən dönəndə tapdı qəbul,
Məclisi-ehli-şər'ə rahi-vüsul.
Bisəbəb hərzə-hərzə qılma qəzəb,
Şişəni çalma daşa, saxla ədəb.
Bəs ki, əhli-xətasənü mürtəd,
Qanda üz qoydun isə oldun rədd.
Bəsi evlər xərabdır səndən,
Çox bağırlar kəbabdır səndən,
Açaram sirrini, tər olmaz isən,
Dürd nisbət mükəddər olmaz isən.


250


**SİFƏTİ-MEY Kİ,**
**HƏST NAMƏŞRU** **[1]**

Misr mülkündə var idi bir pir,
Hərgiz ixlası tapmamış təğyir,
Alimü arifü əfifüz-zeyl,
Qılmamış xübs ilə xəyanətə meyl.
Axiri-ömr olanda rikkəti-şeyb,
Saldı tərkibinə mərəzdən eyb.
Oldu tədbirə illəti möhtac,
Dedilər Badədir bu dərdə əlac.
Eylədi meyli-mey zərurət ilə,
İçdi bir cür'ə mey küdurət ilə.
Zövqi-mey saldı çün dimağına şur,
Arizu qıldı mütribü tənbur.
Müğbəçə mütribi çəkib avaz,
Eylədi qarşısında cilvəvü naz.
Pir şövq ilə mayil oldu ona,
Qüvvəti-nəfs hasil oldu ona,
Dedi; - Ey sərvqədd, siməndam!
Nola versən məni-şikəstəyə kam?
Məni vəsl ilə şadiman etsən,
Pir ikən yenlədən cəvan etsən.
Dedi: - Məndən murad hasildir,
Leyk din ixtilafi müşkildir.
Dinin ər dinimə münasib olur,
Sənə məndən murad hasil olur.
Pir ta razı ola xatiri-yar,
Tərkidin etdi, bağladı zünnar.
Oldu zaye cəmti-taatı,
Gör ona netdi mey mülaqatı!
Ey Meyi-ziştxu, budur əməlin,
Dinü dünyaya çoxdurur xələlin.


1 Haram olan Meyin sifəti


251


**FƏTİ-BƏNG DƏR XƏYALATƏŞ** **[1]**

Mənəm ol tiztəb', pakzəmir
Ki, lətif etdi tiynətim təqdir.
Məndədir şəfdi-qübbeyi-xəzra,
Əxtərim şahdanədən peyda.
Şeyxlər eylər ehtiram mənə,
Başları üzrədir məqara mənə.
Cövhərim qədr ilən mükərrəmdir.
Külli-tərkibə cüz'i-ə'zəmdir.
Fələki-əncümün mühəndisiyəm,
Cümlə elm əblinin müdərrisiyəm.
Nola gəlsə mənə siğarü kübar,
Almağa dərsi-məxzənül-əsrar.
Səbzeyi-busitani-idrakam,
Zövqbəxşi-zəmiri-qəmnakam.
Xızr vaqif olub həqiqətimə,
Girdi ol rütbə ilə kisvətimə.
Mənə eldən dəgər təpançəvü zur,
Elə məndən yetər nişatü sürur.
Künci-hər mədrəsə məqamımdır,
Firqeyi-əhli-elm ramımdır.
Şövkət əhlinə olmazam həmdəm,
Çəkməzəm şiddəti-məşəqqətü qəm.
Dövlətin çün məşəqqəti çoxdur.
Dövlətim var ki, dövlətim yoxdur.
Qanda bir müflisü qələndər var,
Mənəm ol müflisü qələndərə yar.
Məndə yox Mey kimi məhəbbəti-şur,
Dadlı sevməkdə olmuşam məşhur.
Meydən imanda gəlmişəm əfzun,
"İnnəməl-mö'minunə həlviyyun" [2]
Füqəra firqəsinə mən başəm,
Müttəsil əhli-fəqrə yoldaşəm.


1 Bəngin öz təsəvvürünə görə sifəti
2 Möminlərin hamısı şirinlik şey sevəndir


252


Səndən olğac əsiri-dərd mizac,
Sihhət üçün mənə olur möhtac.
Qanda olsam müqərrəbü məhrəm,
Onda olmaz nişani-qüssəvü qəra.
Mənəm ayinədari-feyzi-əzəl,
Surətim jəngü siyrətim seyğəl.
Versəm ayineyi-zəmirə cila,
Görünür onda cümleyi-əşya.
Səbzxət dübərəm, hicabım yox,
Mənə aşiq yügüş, müqəyyəd çox.
Munca fasiqlər içrə bibakəm,
Tə'n edər xəlq, leyk mən pakəm.
Mənə ariflərin iradəti var,
Arif oldur ki, saxlaya əsrar.
Ey bəsa binəvayi-müflisi-dun
Ki, xəyal ilə eylərəm Qanın.
Degiləm Badə kim, görüb atəş,
Əksilə nəsnə məndənü çıxa qəş.
Çəkmişəm şiddəti-hərarəti-nar,
Çıxmışam xalisü tamam əyar.
Aləmi bir xəyaldır dedilər,
E'timadı məhaldır dedilər,
Qütbi-aləm bu gün mənəm məşhur
Ki, qılır min xəyal məndə zühur.
Dərki-zatım saqınma asandır,
Sirri-karimdə əql heyrandır.
Bilməzəm qanda görmüşəm məktub,
Öz sifatımda bir hekayəti-xub:

**DƏR SİFATİ-MÜRİDÜ HALATƏŞ** **[1]**

Bəsrədə bir müridi-rövşəndil
Bəngə olmuşdu ruzü şəb mayil.
Onu salmışdı nəş'eyi-Əsrar
Hər zaman bir xəyala leylü nəhar.


1 Müridin sifətləri və əhvalı haqqında


253


Bildi pir ol müridin əf' alın,
Zövqi-Bəng ilə xoş keçən halın,
Qıldı məmnu' sohbətindən onu,
Etdi məhrum həzrətindən onu.
Bir gün ol namuradi-xəstəcigər
Saldı əcz ilə pir saru güzər.
Dedi: - Ey hər kəmala rahbərim,
Ustadım, müəllimi-hünərim!
Nə səbəbdən günahkar olubam,
Nə günah eylədim ki, xar olubam?
Pİri-saleh müridə verdi cəvab
Ki: - Mənə bu işində qılma itab.
Derlər Əsrar ilə olubsan yar,
Zövqi-Bəng ilə vaqifi-Əsrar.
Saluban qəsri-asimana kəmənd,
Çox qılırsan təxəyyülati-bülənd.
Göydədir müttəsil sənin seyrin,
Sənə dərki qaçan yetər qeyrin?
Kamilüs-seyr olduğun bildim,
Tərki-dərsü təəllümün qıldım.
Bu dəlil ilə Bəng kamil imiş,
Xəlqə ondan murad hasil imiş.

**ŞODƏNİ-MEY BƏCƏNG AMADƏ** **[1]**

Eyləgəc Bəng sözlərini təmam,
Qıldı Mə'cun risalətə iqdam.
Leyk ta görməyə cəfayi-qədəh,
Oxudu min kərə duayi-qədəh.
Badeyi-ruhbəxşü canpərvər,
Qalmış idi mükəddərü müztər,
İntizar içrə kim, qaçan Buzə
Dönə bir dəxi ol cigərsuzə;
Qıla Bəngin hekayətin təqrir,


1Meyin döyüşə hazır olması


254


Görələr bir ona göra tədbir.
Dedilər: - Bəngə döndü Buzeyi-dun,
Leyk gəldi risalətə Mə'cun.
Şükr qıldı ki: - Nikbətim getdi,
Dövlətimdir ki, onu dur etdi.
Meyə Mə'cun verib xəbər varın,
Sərbəsər zahir etdi əsrarın.
Badənin hiddəti füzun oldu,
Qəhrdən rəngi laləgun oldu.
Yığdı yanına Badə əshabın,
Cəm' qıldı məsaf əsbabın.
Dedi Mə'cunə: - İxtiyarın var,
Xah get, xah bunda eylə qərar.
Bildi Mə'cun ki, Bəng olur məğlub,
Özünü qıldı Badəyə mənsub.
Bəngdən keçdi, Badəxar oldu,
Sahibi-izzü e'tibar oldu.

**BƏNG HƏM DƏR MÜQABİL**
**İSTADƏ** **[1]**

Bəng bəm oldu haldan agah,
Yığdı məqdur olduğunca sipah;
Hər biri bir tərəfdə çəkdi səfi,
Oldu rənginbüsat hər tərəfi.

**ƏZMİ-MEYDAN**
**NÜMUDƏNİ-ƏSRAR** **[2]**

Əvvəl Əsrar girdi meydana,
Səhni-meydanda gəldi cövlana,
Başını açdıvü götürdü kötək,


1 Bəngin da qarşı durması
2 Bəngin meydana girməsi


255


Girdi meydana pəhlivanlartək,
Urdu qayətdə pəhlivanlığa laf,
İstədi pəhlivan kim, edə məsaf.

**GÖFTƏNİ-SÜLH**
**NÜQLİ-XİDMƏTKAR** **[1]**

Nüql gördü ki, ol iki bibak
Qılmaq istər bir-birini həlak.
Bildi kim, onlar ilə olsa cidal,
Ayağ altında ol olur pamal.
Bəng başına cizginib hər dəm
Yalvarıb düşdü Mey əyağına həm
Ki, məgər dəf ola təriqeyi-cəng,
Nə Mey etdi sözün qəbul, nə Bəng.

**MƏN'ŞAN KƏRDƏNİ-MƏVİZ**
**ƏZ CƏNG** **[2]**

Var idi bir müdəbbir, adı Məviz,
Vaqe' ol əsrdə bir əhli-təmiz.
Həm şərabın atası, qardaşı,
Həm səfərlərdə Bəng yoldaşı.
Şamdən qıldı sülh üçün ilqar,
Qıldı onlara və'zlər təkrar.
Olmadı və'zü pənd faidəmənd,
Əhli-cəhlə nə sud və'zlə pənd?


1 Xidmətçi Nogulu sülh təklifi
2 Mövüzün onları davadan çəkindirməsi


256


**ŞÜDƏNİ-NÜQL**
**DƏR MÜQABİLİ-BƏNG** **[1]**

Nüql çıxdı onunla qılmağa cəng,
Qıldı bir həmlədə şəhid onu Bəng.

**DƏR MƏSAF AMƏDƏN**
**MƏVİZİ -TƏMİZ** **[2]**

Etdi əzmi-məsafi-Bəng Məviz,
Ol dəxi olmadı hərifi-sitiz.

**ƏZ PEYƏŞ**
**HƏM KƏBABİ-ATƏŞİ-TİZ** **[3]**

Ərseyi-rəzmi gərm qıldı Kəbab,
Zərbinə ol dəxi gətirmədi tab.

**KƏRDƏNİ-BADƏ CƏNGRA**
**MƏQDƏM** **[4]**
Gördü Badə ki, ləşkəri bir-bir,
Oldu ol nabəkar əlində əsir.
Vermədi qeyrə cəng üçün rüxsət,
Özünü çəkdi ortaya qeyrət.
Çün sipahilik içrə mahir idi,
Ona tədbiri-cəng zahir idi.
Bir neçə itrətini qoydu kəmin,
Özü yalqız məsafa girdi həmin;


1 Noğulu Bəngə qarşı çıxması
2 Movüzün döyüşə girməsi
3 Ardınca iti odlu kababın gəlməsi
4 Badenin müharibəyə başlaması.


257


Girdi meydana, eylədi cövlan,
Üzə çəkdi hübabdan qalxan.
Bəng ilə çün müqabil oldu Şərab,
Ləhzeyi qıldılar süalü cəvab.

**KƏRDƏNİ-BƏHS BƏNGÜ MEY**
**BAHƏM** **[1]**

Mey edir [2]

   - Mən nəbireyi-takəm!
Bəng edir:

   - Sən pəlidü mən pakəm!
Mey edir:

   - Mən nədimi-sultanəm!
Bəng edir:

   - Mən bir əhli-irfanəm!
Mey edir:

   - Hakimi-həvasəmü huş!
Bəng edir:

   - Sufiyəm mən əzrəqpuş!
Mey edir:

   - Mən şəfəq kimi aləm!
Bəng edir:

   - Mən sipehr timsaləm!
Mey edir:

   - Xoş mənimlədir aləm!
Bəng edir:

   - Qütbi-aləməm mən həm!
Mey edir:

   - Qəmli xəlqə qəmxarəm!
Bəng edir:

   - Səncə mən dəxi varəm!
Mey edir:

   - Mən çiraği-əncümənəm!


1 Mey ilə bəngin mübahisəsi .
2 Edir, aydır - "deyir" mə'nasındadır.


258


Bəng edir:

- Rəşgi-səbzeyi-çəmənəm!
Mey edir:

- Eşq piri-rahimdir.
Bəng edir:

- Ol mənim pənahimdir!
Mey edir:

- Növrəsi-cahansuzəm!
Bəng edir:

- Piri-danişamuzəm!
Mey edir:

- Eylərəm səni fani!
Bəng edir:

- Dinmə, həddini tani!
Bəhs ilə olmadı çü qət'i-niza,
Fitnə sülhü səlaha qıldı vida.
İbtida oldu çünki cəngü cədəl,
Bir neçə həmlə oldu rəddü bədəl,
Hiddəti-Bəng Meydən idi füzun,
Bəng qüvvət tapıb, Mey oldu zəbun.
Gördü çün dövlətində bimi-xələl,
İstədi üzri-səyyiati-əməl.
Nəzr edib eylədi Xudayı güvah
Kim, bu növbət bu düşmən olsa təbah,
Kimi tutdiysə eyləyə azad,
Etməyə kimsənin fəsadım yad.
Tapdı sail icabəti məs'ul,
Saf idi qəlbi, nəzri oldu qəbul.
Çıxdı nagəh kəmindən ol ləşkər,
Oldu Bəngin sipahi-zirü zəbər.
Buzəvü Bərşü Bəng əsir oldu.
Kimi xürdü, kimi xəmir oldu,
Badənin xatirinə yetdi səfa,
Nəzr qılmışdı, nəzrə qıldı vəfa,
Qıldı azad o dörd sərhəngi:
Saqiyü Bərşü Buzəvü Bəngi.
Hər birin qıldı bir işə mə'mur.


259


Aləmi etdi ədl ilə mə'mur.
Aqibət Bəng edib ihanətə ar,
Badənin xidmətindən etdi fərar.
İmdi gəzdikdə qorxa-qorxa gəzər,
Badə hər qanda görsə onu əzər.
Özünü mütləq aşikar etməz,
Mey olan yerlərə güzar etməz.

**TƏLƏBİ-MƏĞFİRƏT**
**Zİ RƏBBİ-QƏFUR** **[1]**

Tövbə, ey K'irdigar-üzrpəzir
Sözlərimdən kim, etmişəm təqrir.
Nitq verdin ki, vəsfi-zatın edəm;
Şərhi-keyfiyyəti-sifatın edəm;
Nə ki, övsafı-Mey qılıb əmda,
Bəng vəsfində olayım guya.
Allah-Allah, bu mehz üsyandır,
Qayəti-küfrü eyni-küfrandır.
Çün Füzulidürür mənim ləqəbim,
Əcəb olmaz gər olmasa ədəbim.
Var ümidim ki, üzrüm ola qəbul,
Olmaya böylə cürm ilə məs'ul.


1 Bağışlayan Allahdan əfv istəmək.


260


261


262


Qəvvasi-bəvahiri-rəvayət,
Səyyahi-bəvadiyi-hekayət
Dəryayi-rəvayəti üzəndə,
Səhrayi-hekayəti gəzəndə
Düzmüş bu nizam ilən göhərlər,
Vermiş bu əda ilən xəbərlər
Kim, var idi bir xücəstəsima,
İdrakı tamam, təb'i qərra.
Əşya təkəllümündən arif,
Hər əlsinədən olurdu vaqif.
Bir gün ki, şəhi-sipehri-rabe'
Tiğini Həməldə qıldı lame',
Təsxiri-Həməl qılan zamanda,
Xuni-Həməl axıdan zamanda,
Hər səbzəgəhə güzər edəndə,
Bir tövr ilə dövr edib zəmanə,
Bir özgə fəza yetib cəhanə,
Əbvabi-xəyal olundu meftuh,
Əmvati-nəbatə yetdi çün ruh.
Çün məşvü nüma bulub çəmənlər,
Çak etdi nəbat pirəhənlər,
Mey neş'ə ilə əyağ çəkdi,
Lalə cigərinə dağ çəkdi.
Nərgis ki, göz açdı bağə girdi,
Bir baxmaq ilən özün itirdi.
Kəcgərdən olub bənövşəyi-zar,
Bir nəş'əyi-meylə oldu xummar.
Qönçə yaxasını eylədi çak,
Bülbül baxuban olub fərəhnak.
Bağ İçrə açıldı qırmızı gül,
Başladı əninü nale bülbül.
Əlqissə, fəzalanıb çəmənlər,
Xoş, tazə geyindi yasəmənlər.


263


Seyr etmək üçün o pakdamən
Tutdu rəhi-bağü tərfi-gülşən.
Bir bağə güzər edən zamanda,
Hər meyvəyə bir nəzər qılanda
Gördü ki, fəvakihü səmərlər
Öz-özünə iftixar edərlər.
Aluçə edərdi şükri-səttar
Kim,

- Mən kimi xoş cahanda kim var?
Təblərzəyə mən şəfa verirəm,
Təlxiyyi-fəmə səfa verirəm.
Əklimdən olur baş ağrısı dur,
Demiş hükəma bu sözü cümhur.
Ol sözünü axıra yetirdi,
Xişmindən Alu özün itirdi,
Aluçəyə söylədi ki:

- Ey zar!
Fəxr eyləmə, eyləməzmisən ar?
Kim turş, dəxi zəlilsən sən,
Əsmar ara əlilsən sən!
Əklində sənin qamaşı dişlər,
Xoş təb'lərə rütubət işlər.
İflicəvü küft cümlə azar
Səni yeyənə olur səzavar.
Ol qadiri-bimisalü həmta
Aluyə məni qılıb müsəmma.
Çün dürri-qələndəri bəguşəm,
Yüz min tərəfə saçıldı xuşəm.
Gəh səbzəvü gah ərğəvani,
Gəh sürxü səfid, zə'fərani.
Onun səsini Gilas eşitdi,
Bu zərb ilə ona tə'nə etdi:

- Key nakəsü dun, utanmadınmı?
Azərm oduna yanmadınmı?
Kənduzini bunca vəsf etdin,
Qurtar sözünü ki, həddən ötdün!
Hər kim səni yesə etməz əhlal,


264


Gündə gərək ona üç kərə bal.
Ol dəm ki, məni Həq etdi zahir,
Verdi tənimə libasi-faxir,
Rəxtim kİmi yoxdu hiç cövhər,
Cismim kimi yoxdu hiç gövhər.
Gəh Zöhrəvü gah Müştəriyəm,
Gahi mələkü gəhi pəriyəm.
Sərv ağacı təkdir hər budağım,
Xublar çəkəllər iştiyaqım.
Zərdalu eşitdi, nə'rə urdu
Kim,

- Gilasi görgilən, qudurdu!
Dedi ki,

- Ey əhqəri-zəmane!
Vey zağü kəlağa abü danə!
Nə föxr ilə özünü ögərsən?
Bu eyb ilə sən nə fəxr edərsən?
Bir qətrə su, bir də üstüxansan,
Hər kim ki, yesə, ona ziyansan.
Gər səni qurutsa bağbanlar,
Axır günü çox çəkər ziyanlar.
Ol əsli-binayi-cümlə bünyad,
Zərdalu mənə qoyubdu həm ad.
Gəh səbz oluram zümrürüdasa,
Gahi bədənim olur mütəlla.
Gər məni qurutsa bağibanlar,
İstər məni cümlə karivanlar.
Hər qanda aparsalar əzizəm,
Hər təbxə buraxsalar təmizəm.
Ərik sözün Alına guş qıldı,
Acıqlanuban xüruş qıldı:

- K'ey qarnı vərəmli, sinəsi çak,
V'ey caməsi tozlu, ləzzəti xak!
Xasiyyətini ki, sən bilirsən,
Kənduzinə rişxənd qılırsan.
Hər kim səni yedi qarnı şişdi,
Dəryayi-bəla içinə düşdi.


265


Ənvai-bəlavü dərdü sevda
Səni yeyənə olur mühəyya.
Ol qadirü həyyü fərdü fəttah
Adımı mənim qoyubdu Tüffah.
Həm çöhrəmə verdi sürx rəngi,
Həm əguimə ətləsi-firəngi.
İki yarın arasında məhrəm
Yox mən kimi dəhrdə müqəddəm.
Həm peyki-nigari-nazəninəm,
Həm qasidi-yari-məhcəbinəm.
Təbliği-risalətimdə söz yox,
Təflhimi-bəlağətimdə söz çox.
Xəlvətgəhi-yarə əhli-sirrəm,
Mə'şuqinə aşiqi yetirrəm.
Bir bəzmdə gər ola müyəssər,
Təcmii-fəvakihü səmərlər,
Mən həm gər o bəzmdə bulunsam,
Əsmar içində hazır olsam,
Cümlə məni intixab edellər,
Həm qeyrdən ictinab edəllər.
Alma edər idi yüz təfaxür,
Əmrud özünü qıldı zahir,
Səsləndi ki, - Ey fəsadi-dövran!
V'ey müfsideyi-misali-şeytan!
Gər qabili-iftixar ofubsan,
Alma adını neçün qoyubsan?
Gər yaxşı olardın al deyərdin,
Alma neçün adını qoyardm?
Ol həzrəti-layəzali-mə'bud,
Ad qoydu məni lətifə Əmrud,
Verdi mənə yaxşı xasiyətlər,
Həm əklimə çox-çox afiyətlər.
Hər xəstəyə mən şəfa verirəm.
Hər cərgəyə mən səfa verirəm.
Əmrud edərdi vəsf halın,
Bilməzdi öz işinin məalın,


266


Nagəh səsini eşitdi Əngur,
Qeyzə gəlib oldu məstü məsrur.
Bu tə'nə ilə itab qıldı,
Əmrudə o dəm xitab qıldı.

- K'ey rəngi saralmış illətindən!
Başı yekə zə'fİ-qüvvətindən!
Öz başına sən təbib oldun,
Bimarlara nəsib oldun,
Kənduzinə vardır ehtiyacın,
Eylərmisən özgələr əlacın?
Dəxi kəl əgər təbib olurdı,
Əvvəl başına dəva qılırdı.
Əvvəl varıb özünə dəva ver,
Ondan sora xəstəyə şəfa ver.
Ol caili-zülmətin ilənnur
Ad qoydu məni-hərifə Əngur.
Verdi mənə dürlü xasiyətlər,
Lütf etdi mənə çox afiyətlər.
Mən səbzəvü kişmişü məvizəm,
Əsmar içində çox ləzizəm.
Məndəndi şərabi-ərğəvani,
Məndəndi sürurü şadimani.
Mən saqiyi-məclisi-vəfayam,
Ziynətdəhi-məhfili-səfayam.
Turşu ilə həmnişin mənəm, mən!
Həlva ilə həmqərin mənəm, mən!
Heyva eşidib bu göftguyi,
Qeyzə gəlibən saraldı ruyi.
Əngurə dedi ki:

- Yum dəhanın!
Danışma ki, lal ola zəbanın!
Şüğlün qəmü möhnətü ələmdir,
Mədhin özünə tamam zəmdir.
Bir kəslə ki, ittihad qılsan,
Bir cam mey ilə şad qılsan,
Ol şadlığı tamam olur qəm,
Qəm üstünə qəm gəlir dəmadəm.


267


Əvvəl ki, edər xilafi-əhkam,
Dəxi həm olur cahanda bədnam.
Həm əqli-mürəccəhi olur fəsl,
Həm cəhli-mürəkkəbi olur vəsl.
Gər mün'im ola gedər tilası,
V'ər müflis ola gedər həyası.
Ol cümleyi-müşkili edən həll
Adımı mənim qoyub Səfərcəl.
Var ləzzətü rəngü dad məndə,
Həm namü ləqəb, xoş ad məndə.
Ətrimlə dolubdu bağü bağça,
Həra mənzilim oldu tağü tağça.
Məni aparırlar hər diyara,
Həm töhfə verirlər hər nigara.
Konduzini vəsf edərdi Heyva,
Narınc eşidibən oldu peyda.
Heyvaya xitab qıldı:

- Key zar!
Danışma ki, səndə yox məgər ar?
Rəngin saralıbdı büğzü kindən,
Yoxdur xəbərin məgər özündən?!
Min tə'nə edər sənə xəlayiq,
Onlar ki, dedin, sənə nə layiq?
Qarnın dolu kirmü büğzü kinə,
Kirmə bədənin olub xəzinə.
Mədhin özünü məzəmmət eylər,
Vəsfin sənə cümlə lə'nət eylər.
Ot leyli nəhar edən, günü şəb
Narınca qılıb məni müləqqəb.
Lütf etdi mənə qəbayi-faxir,
Ol don ilə eylərəm təfaxür.
Yüz şükr edərəm mən ol xudaya,
Yüz fəxr tənimdəki qəbaya.
Bir don mənə lütf eyləyibdir
Kim, qeyriyə dəxi verməyibdir.
Şəklimi dəxi edibdi püstan,
Püstanı sevəllə cümlə məstan.


268


Yüz fəxr ilə söylər idi Narınc,
Nagah səsini eşitdi Turunc.
Göftara gəlib dedi ki:

- Ey dun!
Fəxr etmə qəbaya kim, nədir don?
Gər eşşəyə məhmil etsələr cül,
Ol cüli münəqqəş ola gül-gül,
Eşşəkdə zəval həm kəm olmaz,
Minbə'd o eşşək adəm olmaz.
Ol qaziyi-həşrü nəşrü miad,
Turunc mənə qoyubdular ad.
Mən əfşüreyi-təami-şaham,
Yemişlər içində padşaham.
Sərdəftəri-meyvəcati-bağam,
Əsmar içində çün çırağam.
Hər nə ki, desəm ziyadəyəm mən
Kim, daima səbzü tazəyəm mən.
Bu sözləri Nar edib təfəhhüm,
Ağzın açıb eylədi təbəssüm
Kim, rənginə fəxr edirdi Narınc,
Həm özünü vəsf edirdi Turunc.
Dedi ki:

- Nədir bu göftügulər?
Bifaidə batil arizulər!
Gər rəng ilə olsa işvəvü naz,
Rəng içrə şükufəm oldu mürataz.
V'ər kimsə edərsə sui-təhsin,
Var məndə zülali-turşü şirin.
Kənduzimi mədh etməzəm mən,
Öz halımı şərh etməzəm mən
Kim, meyveyi-rövzeyi-cinanam,
Namü ləqəb ilə mən Rümanam.
Dünya səməri mənə nə nisbət
Kim, mə'xəzim ola baği-cənnət.
Narıncü Turunc çəkərimdir,
Heyva ilə Sib nökərimdir.
Hər danəm olubdu lə'li-qəltan,


269


Hər cövhər ona olubdu heyran.
Nar öz sifətini vəsf etdi,
Bağ içrə səsin Rütəb eşitdi.
Xişm ilə o dəm ayağa durdu,
Qehr ilə Ənara nə'rə urdu:

- K'ey baği-behiştdən uran dəm,
Səndən degiləm o vəsfdə kəm.
Mən qabili-əkli-ənbiyayam,
İftari-cəmii-ətqiyayam.
Məşhur əcəmdəvü ərəbdə,
Mə'ruf həm əsldə, nəsəbdə.
Mə'kul tamami-xasü aməm,
Səyyahi-biladi-Misrü Şaməm.
Əzbəs ki, mənəm həbibi-əhbab,
Bu vəch ilə mənə çoxdur əlqab.
Xəstaviyü Zahidi, Müfəttəl,
Həm Əş'əmiyü dəxi Müfərcəl.
Xoş büq'ələr içrə hazirəm mən,
Məşhədlərə çün mücavirəm mən.
Sürtəllə məni məzari-yara,
Töhfə aparırlar hər diyara.
Vəsfmi Rütəb çün etdi itmam,
Yüz xişmlə nə'rə urdu Badam.
Xurmaya dedi ki:
-Ey cahangərd!
Zəmminde sənin bəsindi bu fərd:
Gəh Bağdadisən, gəh İsfəhani,
Hərcayiliyin tutub cahani.
Vəsf eyləməgində həddən ötdün,
Danışma ki, sən məni əritdin.
Çox dürlücə xasiyyət mənim var,
Şərh etməgə özüm eylerəm ar
Kim, abi-nəbatü nüqlü həlva
Olur məni-zardən mühəyya.
Püstə ki, eşitdi ağzın açdı,
Badama bu növ ilən sataşdı:

- K'ey bağlı dəhanı xissətindən,


270


Puşidə üzü ləamətindən!
Bir zərrə sənin səxavətin yox!
Bihəddü ədəd xəsasətin çox.
Min daş yetişməyincə canə,
Qənnadiyə verməsən ki, danə.
Xəllaqi-cəhan zülmətü nur
Püstə mənim adımı qoyubdur.
Qönçə kimi ağzım açmışam mən,
Hər talibə danə saçmışam mən.
Bir yandan eşitdi Xoxü Fıstıq,
Həm Süncüdü Şahpaludü Fındıq.
İnnab ilə Tut, Alubalu,
Əncirü Zoğalü Cövz, Limu;
Hər biri bir afəti-zəmanə,
Hər biri sölərdi bir fəsanə.
Şaftalu deyərdi:

- Padişahəm,
Fıstıq ki:

- Əncüm içrə mahəm.
Həm Cövz deyərdi:

- Xosrovam mən.
Fındıq deyərdi:

- Sərvərəm mən.
Limu ki:

- Mənəm bu bağa mahmud.

- Şaham ki, deyərdi Şahpalud.
Həm Cövz deyərdi:

- Pəhlivanam,
Əncir ki:

- Şöhreyi-cahanam.
İnnab deyərdi:

- Mən vəcihəm.
Zoğal ki:

- Mən sənə şəbihəm.
Həm vəsf edib özün Gilənar,
Tut oldu ki, bağa tuti göftar,
Qıldı nəzər ol xücəstəsima,


271


Gördü ki, olub bu bağda qövğa.
Gəlmişdi ki, eyləyə səyahət,
Ləzzət aparıb qıla fərağət.
Gördü ki, bağ içrə yoxdu ləzzət,
Fəsx eylədi, əzmin etdi ric'ət.
Düşdü yola həm gözətdi xanə,
Nagəh yolu düşdü bustanə.
Bir növ ilə gördü bustanı,
Az qaldı ki, tərk edə cahanı.
Eylərdi Xiyar şükri-xaliq
Kim:

- Qıldı məni cahanda haziq.
Əklimdə olur məriz dilsərd,
Vəsfimdə mənim bəsimdi bu fərd.
Mən dafei-dərdi-möhriqatam,
Mərhəmnəhi-sədri-mütbiqatam.
Gərmək ki, eşitdi bu məqalı,
San kim, mütəğəyyir oldu halı.
Üz tutdu Xiyara:
-K'ey cəfakar!
Bu vəsf sənə degil səzavar.
Yoxdu ləzatin həmin bir adın,
Camuş ətinə dönübdü dadın.
Ol mədhlərin sənə nə layiq?
Ol vəsflərə mənəm müvafiq.
Mən xəstələrə şəfa verirəm.
Mən qəlblərə səfa verirəm.
Var əmzicə ilə e'tidalım,
Hər təb ilə mö'tədildi halım.
Gərmək sölər İdi yüz fəsanə,
Bu yandan eşitdi Hindivanə.
Bir nə'rə çəkib xüruş qıldı,
Dərya kimi daşdı, cuş qıldı.
Dedi ki:

- Məgər bu xasiyətlər
Mən möhtörəmə degil müyəssər?
Mən sinələrə səfa verirəm,


272


Mən didələrə cila verirəm.
Səfravü hərarətə dəvayəm,
Bağ ağrısına əcəb şəfayəm.
Xoştə'm, ləziz, rəngim əhmər,
Suyum dəxi çün zülali-Kövsər.
Bimarlara dəva mənəm, mən!
Həm xəstələrə şəfa mənəm, mən!
Övsafın edərdi Hindivanə,
Qavun eşidib çəkib zəbanə,
Vermişdi çü Qarpıza vəzarət,
Həm Gərməyə mənsəbi-vəkalət,
Etmişdi Xiyari çün mülazim,
Şəmmaməni həm özünə xadim,
Bostançıya əmr qıldı Qavun,
Verdirdi cəzasını bularun.
Soydurdu dərisini Xiyarın,
Aldırdı əlindən ixtiyarın.
Həm Gərməyə urdu neçə yarə,
Cismini elətdi parə-parə.
Qarpızı o dəmdə şaqqalatdı,
Şəmmaməni bir kənara atdı.
Dedi ki:

- Mənəm sizin pənahız,
Bu bustan içrə padişahız!
Şəh məclisinə müsəddərəm mən,
Əsmar içində sərvərəm mən.
Hər kim yesə məni, qılsa rehlət,
Yetər ona rütbeyi-şəhadət.
Ətrim dəxi ətri-mişkə bənzər,
Nə mişk ki, bəlkə ətri-ənbər.
Vermişsə mənə zülal Kövsər,
Saqisi o Kövsərindir Heydər.
Əlqissə ki, bustanda Qavun
Vəsf etdi özünü həddən əfzun.
Qeyz ilə o dəm ayağa durdı,
Öz başını xişm ilə ayırdı.
Bunu görüb ol xücəstəsima,


273


Bustana həm etməyib tamaşa
Bildi ki, bu dövrdə vəfa yox,
Dünyanı sevən çəkər cəfa çox.
Pəs etdi yəqin ol cəfakeş,
Olmaz bu cahanda kimsə dilxoş.
Bildi ki, olub bu deyr fani,
Tərk eylədi ləzzəti-cəhani.
Dünya işinin mədarı yoxdur,
Heç kimsəyə e'tibarı yoxdur.
Eylər birisini sahibi-tac,
Ol birisin eylər ona möhtac.
Leylaya verib üzari-gülgun,
Qeys onu görəndə ola Məcnun.
Həm Yusifə verdi hüsni-ziba,
Oldu ona mübtəla Züleyxa.
Əzraya veribdi hüsni-bihəd,
Qılmış ona Vamiqi müqəyyəd.
Bu köhnə evin vəfası yoxdur,
Ənduhu qəmü cəfası çoxdur.


274


275


276


l.İmam ismində.

İstədi məndən nisari-müjdeyi-təşrif yar,
Gövhəri-ixlas xaki-payinə qıldım nisar.

2. Həmzə.

Xalini ta zülf pünhan etdi piçü tab ilə,
Kiprigim məhv etdi göz mərdümlərin seylab ilə.

3. Solam.

Çün qəmi-pünhanım isbatində ahimdir güvah,
Dustlar, eyb eyləmin gər aşikar eylərsəm ah.

4. Dara.

Yandırar hər dəm dili-rişi iraqdan bir xəyal,
Vay, əgər ol şəm' ilə qılsa dili-riş ittisal.

5. Əsəd.

Nəçük ki, rabətiçün qu yatur yuvasında,
Dili-şikəstə yatur oxların arasında.

6. Mö'min.

Dövrdən aləmdə kimdir bulmayan təğyiri-hal?
Ol ki, hər dəm edə bir həmcinsi ilə ittisal.

7. Mustafa.

Kimə tövfiq rəfiq olsa olur müşkülü həll,
Məqsədindən biri olmaz ki, ona yetməsə əl.


277


8. Həmzə.

Artırır yüz şövq hər dəm aşiqi-bimarinə,
Qəddin eylər cilvə gər zülfün salır rüxsarinə.

9. Sadiq.

Ahimin, ey məh, eşit övsafını,
Firqətindən dutdu göy ətrafım.

10. Möhsün.

Əyağ aldıqca alə möhtəsib eylərsə yasaq,
Möhtəsib başına axır sınacaqdır bu əyaq.

11. Qiyas.

Yenə bir mahvəşin hüsnünə meyl etmiş dil,
Gün kimi surəti-bimislinə olmuş nail.

12. Şah.

Ta gözüm mərdümləri seyd etdi rəngi-al ilə,
Sadə rüxsari müzəyyən oldu mişkin xal ilə.

13.Qərib.

Səri-zülfün əgər qılsan məhi-rüxsarinə ziyvər,
Könül məhrum olur mahi-rüxün görməkdən, ey dilbər!

14. Bəha.

Mövsimi-güldür, diriğa, guçeyi-gülzar yox,
Guşeyi-gülzar həm olsa, münasib yar yox.

15. Həsən.

Dürfəşan gözdə nəmi-əşkdən, ey lalə'üzar!
Görəli mehri-rüxün varı yox oldu, yoxu var.


278


16. Uluğbək.

Daği-dil çün dərd dəf in eylər, ey can, müttəsil,
Xoşdur ol kim, ola hər yan binihayət daği-dil.

17. Qayabək.

Necə bir batsın bəla peykanı bağrım qanına.
Necə bir tiksın məm dilbər oxu peykanına.

18. Xurşİd.

Cövr rəsmin yenə ol mahvəş İzhar etdi,
Dili-nalanımızı dərdə giriftar etdi.

19. Müslim.

Müşəvvəş olmasın şanə üzülsə zülfünün tarı,
Peşimanmı olur azad edən yüz min giriftarı?

20. Övliya.

Çeşmi-nəmnakım görəndən bərlü ol mahın yüzün,
Daneyi-xalinə mənzil görmədi illa özün.

21.Əhli.

Olduğiçün qibleyi-hacət onun xaki-dəri,
Xaki-dərgahinə eylər meyl mahü müştəri.

22. Talib.

Qıldıqca fələk əsiri-hicran könlü,
Şad eylər ümidi-vəsli-canan könlü.

Ümmidi-vüsali-yar ilə cəm' edərəm
Hər necə fələk qılsa pərişan könlü.


279


23. Əman.

Sərvə su rövnəq verər, incitmə, ey sərvi-rəvan!
Xaki-rahin üzrə tutsa qətreyi-əşkim məkan.

24. Sultan.

Həsrəti-rüxsarın ox urmuş səmən qəlbinə çox,
Ərz qıl rüxsarını, çıxsın səmən qəlbindən ox.

25. Seydi.

Zikri-yar ilə dil bolur aram,
Xoş olur sinə yadı ilə müdam.

26. Mühyi.

Mühitı-eşqə qəvvas olalı can,
Özünü eylədi xak ilə yeksan.

27. Xeləf.

Gərçi qıldın cana cövri-bihədi,
Səndən, ey xurşid, yüz döndərmədi.

28. Aləm.

Təl'ətin rövşən edər hər gecə şəm'in gözünü,
Yandırar, görüncək (ol) mahi-rüxün, şəm' özünü.

29. Müttəqi.

Düri-əşkim bulalı xaki-rəhinlə imtizac,
Buldu çün qiymət, qılır, əlbəttə, anı başı tac.

30. Budaq.

Eyləyib bülbülləri dərhəm, nihan eylər gülü,
Qaliba badi-səba aşüftə istər bülbülü.


280


31.Davud.

Gül yaxasın çak edib hər ləhzə badi-sübhdəm,
Aqibət andan sınar bülbül kimi gül könlü həm.

32. Ğeybi.

Aşiqi-bisərü pa yaşını eylərdi rəvan,
Buldu təskini-dil anı görüb ol sərvi-rəvan.

33. Fərrux.

Xəttin ləbi-lə'lin üzrə məskən qılmış,
Tuti şəkəristanı nişimən qılmış.

34. Əmir.

Vəhm edüb peyvəstə ahimdən rüxün eylər nihan,
Anın üçün ot dəhanü zülfdən bulman nişan.

35. Adəm.

Möhnətsərayi-sinəmə gəldikcə müttəsil,
Bəzl eylərəm xədənginə hər ləhzə xuni-dil.

36. Nuri.

Nəqqaşi-çərx kilki-şüa ilə sübhdəm
Gün səfhəsinə qıldı yüzün nəqşini rəqəm.

37. Şeyxim.

Nəziri-mah demişlər məhim rüxinə əvam,
Rəvamıdır ki, verərlər ona şikəsti-təmam.

38. Ubeyd.

Görsə qalmış ol sinəm rüxsarəsi üstündə xal,
Seyd olur billah, səba, ərz et nihan etsin cəmal.


281


39. Paşa.

Görəli xaki-dərin, aşiq açub çeşmi-tərin,
Axır ol xaki-dərə tökdü olunca gühərin.

40. Məqsud.

Zaman-zaman ruxun ol mahvəş ki, ərz qılır,
Mudam zülfünü üzdən alıb əyağə salır.


282


283


284


**MÜQƏDDİMƏ**

Nasixi-əqavili-mənqulə və ətəmmi-əhadisi-məqbulə ki, əshabi-fəsahət nəqşisəhifeyi-e'tibar edib, ərbabi-bəlağət tərzi-cərideyi-ixtiyar edərlər ol münşiyiərqarai-hikmət və mümliyi-əhkami-qüdrət həmdidir ki, kəlimati-nəsayeh
məzmun və nükati-məaniyi-məknun möcizbəyani-rəsulinə cari edib dəsturüləməli-sükkani-səradiq tə'yin və nəsbül-eyni-ümmali-məsalihiddin etmiş.
Səlləllahi əleyhi ve alihi və əshabihi əyyidnən mim həmləti ə'lami ulumihi və
nəqlət ehkami adabihi.
Əmma bə'd bu, qırx hədisi-mö'təbərdir, bəlkə qırx danə gövhərdir ki, ustadigirami mövlana Əbdürrəhmani-Cami əleyhirrəhmə intixab edib, farsi mütərcəm
etmiş və şərti mən həfəzə min ümməti ərbəinə hədisən yəntəfiunə, bihi qəbləcəza
bəəsəhullahu yovməl-qiyaməti fəqi-hən alimən məqaminə yetmiş. Ümum feyz
üçün tərcümeyi-türki olunur.

**1**

Mö'min olmaz kişi, həqiqət ilə
Tutmayınca təriqi-tərki-həva.
Hər nə öz nəfsinə rəva görsə,
Yarü qardaşa görməyincə rəva.

2

Rəhm qıl, rəhm xəlqə kim, Həqdən
Bulasan aqibət cəzayi-əməl.
Xəlqə sən rəhm qılmayınca, sana
Rəhm qümaz Xudayi-əzzə və cəll.

**3**

Müslim oldur ki, əhli-aləm ilə
Sidq ola qövli, xeyr ola əməli,
Zərərin görməyə müsəlmanlar,
Ola pakizə həm dili, həm əli.


285


**4**

Qıl kərəm, xuyini yaman etmə
Ki, sənə demək ola mö'mini-pak.
Olmaz, əlbəttə, əhli-imanda
Müctəme' xuyi-ziştlə imsak.

**5**

Sübhdür fatehi-xəzaneyi-rizq,
Talibi-xabi-subhdur məzmum.
Sübh vəqtində xabə rağib olan
Vüs'ətı-rizqdən olur məhrum.
**6**

Adəm oğlun zəmanə pir qılıb,
Zə'fə etdikcə qüvvətini bədəl,
İki xislət igitlənir onda:
Hər zaman hirsi-malü tuli-əməl.

**7**

Mustəfa qövlü ilə məl'undur
Dünyəvü hər nə onda var tamam.
Tanrı zikrindən Özgə kim, oldur
Səbəbi-izzi-xasü ne'məti-am.

**8**

Zinhar olma əhli-aləm ilə
Münqəzib təb'ili, yaman sözlü,
Tanrı ol bəndəsin sevər ki, müdam
Ola xoş xülqlü, gülər üzlü.
**9**

Ey qılan arizuyi-vüs'əti-rizq,
Xübsdən çək həmişə damanın!
Müttəsil daməni-təharət tut
Ki, qoya fəqr əli giribanın.


286


**10**

Xeyr görmək dilərsən, eylə müdam
Xubsurətlərə bəyani-sual.
Rağibi-hüsni-surət ol ki, olur
Hüsni-surət dəlili-hüsni-xisal.

**11**

Tutma hərgiz vəfasına ümmid,
Sənə hər kim cəfa işin işlər.
Mö'mini sanma kim, iki növbət
Bir dəlikdən çıxıb ilan dişlər.

**12**

Olsa əbri-ətayi-sübhani
Cümleyi-kainatə gövhərbar,
Ola məhrum bəndeyi-dirhəm,
Ola mə'yus abidi-dinar.

**13**

Hər kim istər həyati-qəlb müdam,
Dəmbədəm hərzə-hərzə çox gülməz.
Qəlbə qət'i-həyatdır gülmək,
Qəlbi çox gülməyənlərin ölməz.

**14**

Analar hörmətin tutun ki, müdam
Qabili-rəhməti-ilah olasız.
İstək onlar əyağı altında,
Gər dilərsiz ki, cənnəti bulasız.

**15**

Ey ki, hər məclis içrə məhrəmsən,
Səndə məclis sözü əmanətdir.
Etmə ifşayi-razi-hər məclis
Ki, bu siyrət böyük xəyanətdir.


287


**16**

Ey xoş ol kim, həmişə feyzi-xirəd
Qıla islahi-nəfsə mayil onu,
Kəndi eybinə iştiğal etmək
Qeyr eybindən edə qafil onu.

**17**

Məşvərətdə səni əmin edənə
Rəhnümayi-səvab qıl sözünü.
Saxlama məsləhət sözün ondan,
Xain etmə əmin ikən özünü.

**18**

Bəzl qıl mayeyi-mədaxilini,
Sud isə mayedən sənə məqsud.
Qürbi-Həq hasil eylə, zikri-cəmil
Ki, bulunmaz bulardan ənfə' sud.

**19**

Ol degildir qəni ki, yetmiş ola
Mal ilə bir məqami-e'laya.
Qəni oldur ki, mütləqa nəfsi
İltifat etməyə bu dünyaya.

**20**

Gər diiərsən səvab, qılğıl dur
Güli-ehsanı xari-minnətdən.
Feyzi-ehsam minnət eylər məhv,
Saxla ol hasili bu afətdən.

**21**

Mali-dünyaya meyl qilma kim, ol
Qabili-nəqs olan bizaətdir.
Adəmizadəyə tükənməz mal
Nəqdi-gəncineyi-qənaətdir.


288


**22**
Ol təvangər degil ki, nəqşi-təmə'
Səfheyi-qəlbinə müsəvvər olur.
Qeyr olanda olan təcəmmüldən
Kəsən ümmidini təvangər olur.

**23**

Edə gör ehtiraz çox sözdən
Kim, olur çox sözün bəlaları çox.
Çox sözündən düşər bəlaya kişi,
Çox sözün çox bəlasına söz yox.

**24**

Ol səadətlidir ki, dünya üçün
Hirsdən boynuna buraxmaya bənd.
Görmədən möhnəti-zəmanə hənuz,
Ala bir qeyr möhnətindən pənd.

**25**

Sənə bər kim yetirsə bir ehsan,
Qıl onun şükri-ne'mətin hər dəm.
Şükri-məxluqa olmayan qadir
Qılmaz, əlbəttə, şükri-Xaliq həm.

**26**

Ey olan vaqifl-dəqaiqi-din,
Etmə hisni-cəsəddə həbsi-ülum.
Müstəiddinə olmağıl mane',
Müstəhəqqini etməgil məhrum.

**27**

Cəhdin olduqca xəlqə nəf yetir,
Xəlqi et iltifatinə məmnun.
Əhsəni-xəlqi-aləm oldur kim,
Xülqdən xəlqə ola nəf 'i füzun.


289


**28**

Gər dilərsoıı inayəti-Həqdən
Şəm'i-islaminə ziyad ola nur,
Demə bir söz ki, ola qeyri-müfid,
Tutma bir iş ki, ola qeyri-zərur.

**29**

Necə vaizdən iltimas edəsən
Ki, verə pəndi-sudmənd sana,
Mövti-əhbabü inqilabi-zaman
Dəmbədəm bəs degilmi pənd sana?

**30**
Ey ki, yox istitaətin mütləq
Sədəqə verməgə bir əhli-Həqə!
Yaxşı söz tərkin etmə kim, olmaz
Yaxşı sözdən səvabı çox sədəqə.

**31**

Kişiyə ol günah yetər ki, dili
Şö'leyi-şərr olub zəbanə çəkər.
Sədəfi-səm'inə düşən gühəri
Çıxarıb rişteyi-bəyanə çəkər.

**32**

Həzm oldur ki, xəlqi-aləm ilə
Hər əməldə gümanım ola yaman.
Ola əhli-fəsad məkrindən
Hafizin hisni-ehtiyatü güman.

**33**

Dustlardan həmişə xoş görünür
Bir-birin hədyə ilə etmək yad.
Hədyə irsalı bir müamilədir
Ki, məhəbbət olur onunla ziyad.


290


**34**

Açma göz məhrəm olmayan üzünə
Ki, bu sövdada hasil olmaz sud.
Bil ki, İblisin oxlanndandır,
Hər nəzər bir xədəngi-zəhralud!

**35**

Gah-gah et ziyarəti-əhbab,
Nifrət olmaqdan ehtiyat eylə.
Dustluq gər dilərsən ola ziyad,
Tərki-ifrati-ixtilat eylə.

**36**

Gər tutarsan təriqi-əhli-vəfa,
Peşə et və'dəyə vəfa qılmaq.
Qərzdir və'də etdigin nəsnə,
Fərzdir qərzini eda qılmaq.

**37**

Pəhlivan ol degil ki, hər saət
Yıxa bir pəhlivanı qüvvət ilən.
Oldurur pəhlivan ki, vəqti-qəzəb
Nəfsinə hökm edə ihanət ilən.

**38**

Deynə çox rağib olma kim, ondan
Dinə bir ziştlik mülazim olur.
Olmadıqda ədaya bir qüdrət,
Hiyəlü küfrü kizb lazim olur.

**39**

Kamil olmaq dilərsən imanın,
Qıl təmənnayi-nəfsdən ikrah.
Büğzü hübbü ətavü mən'dən et
Müqtədayi-əməl, rizayi-ilah.


291


**40**

Mö'min oldur ki, mümkün olduqca.
Qonşusun qeyrə etməyə möhtac.
Ol degil kim, hüzurilə gecələr
Özü tox yata, qonşusu yata ac.

          - * *

Əsəri-ərbəini-əhli-süluk
Qürbi-Həqq rütbəsin qılır hasil.
Umarız kim, Füzuliyi-miskin
Ola bu ərbəin ilə vasil.


292


293


294


Maliki-mülkarayi-aləm və hakimi-hikmətfəzayi-əqalimi-hikem mə'mureyicəhani vəqfi-ərbabi-istirzaq edib, tövliyətin müluki-ədalətşüar və hükkamimerhəmətdisarə təfvİz etdikcə və xanogah-təngnayi-ersəyi-İmkanda asariərbabHstehqaq olub, hər fərdinə miqdarmca xəzaneyi-qeybdən vəzifeyİmüstəmirrə yetdikcə, ol mümliyi-ərqami-dvvam-xilafətin qələmİ-mişkbarlan
miftahi-künuzi-ərzaqi-əshabİ-istehqaq ola. Ve ol naqili-ə'lam istehkami-bünyanisəltənətin rəqəmi-ənbərnisarlarmda hədayiqi-əhdaqi-ərbabi-nəzər bəsarət bula.
Şərhi-şəmmeyi-səna və rəfi-şiymeyi-duadan sonra:

Ərz edər xakisari-bimiqdar,
Bəndeyi-kəmtərin Füzuliyi-zar
Ki, müqimi-məqami-üzlət ikən,
Sakini-guşeyi-qənaət ikən,
Başıma düşdü cah sevdası,
Zövqi-əhli-təmə' təmənnası.
Həvəsi-kəsbi-nəngü nam etdim,
Tələbi-rif'əti-məqam etdim;
İstədim kim, ülüvvi-qədr bulam,
Məzhəri-lütfi-padşahi olam.
Bilmədim kim, şikəstəhal oluram,
Həsəd əhlinə payimal oluram.
Təmə' əşrara xadim olmaq imiş,
Süfəhaya mülazim olmaq imiş,
Kim ki, Allahdan iba eylər,
Qeyr dərgaha iltica eylər,
Hasili zillətü xəsarət olur,
Rəxti-ümmidi yə'sə qarət olur.

Əlhasil, fərqi-iqüdarımı əfsəri-qənaət ilə, qalibi-e'tibarımı xəl'əti-üzlət ilə
müzəyyən qılıb və təmliki-əvalimi-mə'nayı təsxiri-əqalimi-surətdən yeyrək bilib,
padişahi-mülki-istiğnavü hakimi-ələlitlaqi-məmaliki-fəqrü fəna ikən, cövhərizatım iqtizayi-təkmil


295


edib və surəti-sülukimdən rəngi-təvəkkül gedib, aləmi-himmətdən bir süruşa
mülhəm oldum və bu ilhamı isğa qıldım ki:

  - Ey qafil, aləmi-surət məzhəri-sifati-ilahidir və məhbiti-ənvari-hüzuzatinamütənahidir. Hər ayinə mülki-mələkutdan münfəkk olmaz və xəsaisi-mülkdən
bəhrəmənd olmayan sərairi-mələkuta dəstrəs bulmaz. Lacərəm, hükkami-mülkə
təvəssül mucibi-hüsuli-məvahibdir və müluki-əsrə təvəssül baisi-vüsalimətalibdir. Və hədisi-səhihdir ki: "Əssultanü zillüllahi" [1] və ondan istiğna xətadır.
Və xəbəri-sərihdir ki: "La rütbətə fövqə rütbətis-sultani illa li-nəbiyyin mürsəlin
ov mələkin müqərrabin", 2Və ondan inhiraf narəvadır. Xüsusən bizim
padişahımız ki, rütbeyi-səltənəti mə'nidə payeyi-xilafətdir və səriri-hökuməti
həqiqətdə masnədi-imamətdir.

**QİT'Ə**

Padişahi-bəhrü bərr Sultan Süleymani-vəli,
Ol ki, məhzi-ədldir zati-vilayətpərvəri.
Xali ondan olmasın, ya Rəb, vilayət ta əbəd
Kim, vilayətdən degil xali səfayi-cövhəri.

Əlqissə, bu təhrik ilə dərgahi-müəlladan bir nəsibə talib olub və ərkanidövlətdən səadəti-imdad və şərəfi-is'ad bulub doqquz əflaka payi-istiğna unurkən
övqafdan doqquz ağça vəzifəyə qənaət qılıb ərz aldım. Və bərat üçün dərgahialəm-pənaha irsal edib, vüsulinə mütərəssid oldum. Müddəti-tərəssüd münqəzi
olduqda və oyyami-intizar sərəncam bulduqda mübəşşirlər ki, müjdeyi-hüsuliməqsəd yetirdilər, mənə bir misali-meymun və bərati-hüımayun gətirdilər.
Hilyəyi-maarif ilə arastə və ziyvəri-əvatif ilə pirastə. Ənbəri-səvadində sibğəti"vəlleyli İza səca" [3] və kafuri-bəyazında səfvəti - "vəssübhi iza təcəlla". [4]
Səhifəsində xətti səhaibi-əmtari-məvahib və xütutində əfradi-nuqət kəl-kəvakib,
ənvəri-mətalibi məsabeyi-sədəfi-dürr idi, lö'löi-sirab iIə məmlüv dəryayiməkarim təməvvüc edib kənara


1 Sultan Allahın kölgəsidir.
2 Rütbələrdə mürsəl Peyğəmbər və Allaha yaxın mələklərdən sonra ən yüksək
Rütbə sultanındır.
3 "And olsun gecənin qaranlığına" ayəsinin rəngi
4 "And olsun sübhün aydınlığına" ayəsinin saflığı


296


salmış. Və müşabehi-nafeyi-mişknab ilə dolub qaidi-izzü ehtiramla varid olmuş.
Fatiheyi-ünvani kərimeyi-"hüvəl-həqqül mübin" [1], xatimeyi-tarixi: "əl-aqibati lilmüttəqin", [2] qayəti-məzmuni "zalikə fəzlül-lahi yö'tihi mən yəşaü vəl-lahü-zülfəzlil-əzim". [3] Nihayəti-məfhumi "in-nəhü min Süleymanə və innəhü bismillahirrəhmanir-rəhim". [4]

Zəhi misali-şərifü nişani-alişan!
Zəhi mürasileyi-zövqbəxşü feyzrəsan!
Zahi lilali-sipehri-əvatifü əşfaq!
Zəhi kilidi-künuzi-mərahimü ehsan!
Zəhi səhifeyi-safidilü səfaəngiz!
Zəhi cərideyi-ənbərnisarü mişkəfşan!

Həqqa ki, ol ulu ayeti-rəhmət nüzulindən xatiri-fatirə bir növ məsərrət sirayət
etdi ki, vəsfi qabili-təqrir degil və xarici-ihateyi-təhrirdir. Ol sərmayeyi-dövlət
vüsulunda qəlbi-münkəsirə bir sürur yetdi ki, zikri mafövqi-ehtimali-təqrirdir.

BEYT

Nəfsə onunla yetən zövqdən oldura agah,
Qültü inni ləki, qalət hüvə min indəllah.

Mücmələn ümmidi-tamam ilə ixtiyarsız durdura. Və ibrazi-hökm üçün
mütəvəlliyi-övqaf hüzurinə üz urdum. Əlhəqq, mütəvəlli mülaqatına fürsət
düşmədi. Və onun daməni-mülazimətinə dəsti-neyl irişmədi.
Əmma divani-bəlağətə təhəccüm etdim. Çün ənhəsi-övqatda və əzMəfihalatda hüzurlarına getdim, bir cəm' gördüm, hekayətləri pərişan. Nə səfadan
onda əsər, nə sidqdən onda nişan var. Cəmiyyətləri dami-hiyəl, hüzzariməclisləri "ülaikə-kəl-ən'ami bəlhüm əzəllü" [5], hərəkati-nahəmvarları məsabeyisuhani-rub və kəlimati-pürazarları müşabeyi-əmvaci-tufani-Nuh.


1 O aşkar həqqdir.
2 Etiqad edənlərdən başqa, aqibəti olan yoxdur.
3 O, Allahın fəzlidir, onu istədiyinə verir; Allah böyük fəzilət sahibidir.
4 O, Allahın fəzlidir, onu istədiyinə verir; Allah böyük fəzilət sahibidir.
5 Onlar qaramal kimidir, bəlkə ondan da alçaqdırlar.


297


Salam verdim - rüşvət degildir deyü almadılar.
Hökm göstərdim – faidəsizdir deyü mültəfit olmadılar.
Əgərçi zahirdə surəti-itaət göstərdilər, əmma zəbani-hal ilə cəm'i sualıma cavab
verdilər.
Dedim:

  - Ya əyyühəl-əshab! Bu nə fe'li-xəta vü çini-əbrudur?
Dedilər:

  - Müttəsil bizim adətimiz budur.
Dedim:

  - Mənim rəayətimi vacib görmüşlər. Və mənə bərati-təqaüd vermişlər ki,
övqafdan həmişə bəhrəmənd olam. Və padşaha fərağət ilə dua qılam.
Dedilər:

  - Ey miskin! Sənin məzaliminə girmişlər və sənə sərmayeyi-tərəddüd
vermişlər ki, müdam faidəsiz cidal edəsən. Və namübarək üzlər görüb,
namülayim sözlər eşidəsən.
Dedim:

  - Bəratımın məzmunu nə üçün surət bulmaz?
Dedilər:

  - Zəvaiddir, hüsuli mümkün olmaz.
Dedim:

  - Böylə övqaf zəvaidsiz olurmu?
Dedilər:

  - Zəruriyyati-asitanədən ziyadə qalırsa, bizdən qalırmı?
Dedim:

  - Vəqf malın ziyadə təsərrüf etmək vəbaldır.
Dedilər:

  - Ağçamız ilə satın almışız, bizə həlaldır.
Dedim:

  - Hesab alsalar, bu sülukunuzun fəsadı bulunur.
Dedilər:

  - Bu hesab qiyamətdə alınır.
Dedim:

  - Dünyada dəxi hesab alınır xəbərin eşitmişiz.
Dedilər:

  - Ondan dəxi bakimiz yox, katibləri razı etmişiz.


298


Gördüm ki, sualıma cavabdan qeyri nəsnə verməzlər və bu bərat ilə hacətim
rava qılmağı rəva görməzlər, naçar tərki-mücadilə qıldım və mə'yusü məhrum
guşeyi-üzlətimə çəkildim.
Mən bəratimdən ihanət çəkdigim üçü münfəil, bəratim məndən faidasiz əzab
verdigi üçün xəcil. Ol, şahidi-məcruh kimi təqrirdən peşiman, mən müddəiyikazib kimi təşni'dən pərişan. Ol ayəti-mənsux kimi məmnuül-əməl, mən ümmətimənsux kirai məqtuül-əməl.

QİT'Ə

Mən ona fitnə, ol mənə afət,
Mütanəffir mən ondan, ol məndən.
Mən ona qüssə, ol mənə möhnət,
Mütənəkkir mən ondan, ol məndən.

Əlqissə, şiddəti-hirman kəmala yetdikdə və dəryayi-heyrətim tüğ-yan etdikdə
xatirimə bu yetdi və qəlbimə bu mə'ni sirayət etdi ki, əlbəttə, mətlə'i-məkarimdən
tale' olan aftabi-məkrəmet ehticabi-səhabi-tirə qəbul etməz. Və mənbə'imərahimdən tərəşşöh qılan zülali-mərhəmət girdabi-təzəlzüidən qubari-fəna
tutmaz. Ənqərib maneinə mane, bulunur və dafeinə dafe' zahir olur.

QİT'Ə

Haşalillah kim, fərağət küncünün sükkanına
Mətrəhi-məkr ola dərgahi-xilafat dəstgah,
Haşalillah kim, qənaət gəncinin müştaqına
Əjdəri-bidad ola tuğrayi-hökmi-padişah.

Xudavənda! Məxfi buyrulmaya və məstur olmaya ki, varid olan bəratihümayun məzmuni irsal olunan ərzə mütabiq olmayıb ibarətində ləfzi-zəvaid
zaid vaqe' olmuşdur və ləfzi-zəvaiddir ki, onun mizani-təsərrüffində miqdarin
naqis qılmışdır.
Filvaqe' əgər ləfzi-zəvaiddən qərəz bu isə ki, vəzaifi-xüddam və rəvabitiərbabi-təqaüd və ixracati-əliqi-dəvabb, ələfi-əvamil və mayəhtaci-həfrü binadan
sonra bəndəyə bir faidə mütərəttib ola, həqiqətdə dərgahi-müəlladan böylə işarət
olunmaqdadır ki, bəndeyi-vacibüt-təqsir Füzuliyi-fəqir iste'dadi-təqəddüm və
istehqaqi-təkər

299


rüm də'vasın qılır ikən və kəndisin əksər ərbabi-isthqaqdan müqəddəm bilir ikən
məkrəməti-mülukanəm və mərhəməti-xosrovanəm zühurə gətirib bu bəratisəxavətayəti verdim. Və buyurdum ki, minbə'd rütbeyi-iqtidarın və payeyie'tibarın cəmi'i-gədalərdən, bəlkə bəhaimdən, daşdan və topraqdan əxəssü edna
bilə. Və bihudə təsərrüfi-bərat qılmayıb, mərtəbəsindən xəbərdar ola. Bitəkəllüf
bu mərtəbəyə qənaət etmək səhldir və bu inayətə məmnun olmaq nəhayəticəhldir.
Həqqa ki, bu vaqiədən mənim çəkdigim rəncü məlamət və etdigim xərcü
xəsarət üçün degil.
Məhza təhrirində həzrətiniz çəkdigi əmək üçündür ki, zaye' oldu. Nedəlim?
Əldən nə gəlir? Xəzaneyi-qeybdən əvəz müyəssər ola və qələmi-qəza tədarük
qıla.

NƏZM

Sərvəra, gərdişi-sipehri-kəbud
Daim olmaz müvafiqi-məqsud.
Bağlamaz hər şükufə meyveyi-tər,
Əksəri bitdigi yerində itər.
Gərçi ənduhü möhnətim çoxdur,
Hiç kimdən şikayətim yoxdur.
Taleimdir mənə cəf'a gətirən,
Hər bir anında min bəla gətirən.
Yoxsa dərgahi-padişahi-zəman
Lütfə mənbə'dürür, mürüvvətə kam.
Var ümidim ki, ol büləndməqam
Ola payəndə ta zəmani-qiyam.
Sərfəraz ola cümlə a'yani,
Bitəzəlzül cəmi'i-ərkanı.


300


301


302


**QAZİ ƏLAƏDDİNƏ MƏKTUB**

Əlminnətü-lillah ki, şəcəreyi-elmü irfan gün-gündən mütənəvve' olub,
səməreyi-asarı fəvaid saçmaqdadır, Və nihali-fəzlü ehsan saət-bəsaət təravət alıb
dimaği-əhli-imanı müəttər qılmağa tazə-tazə şükufələr açmaqdadır. Hər ayinə
nəqşbəndi-nigarxaneyi-vücud kargahi-qüdrətdə bir surəti-mücəddəd çəkməkdən
xali olmaz. Və bağbani-hədiqeyi-cud riyazi-hikmətdən hər saət bir nihali-tazə
dikməkdən məlamət bulmaz.
Əgər bu təriqeyi-mərziyyə nəhci-istimrar bulmasaydı və bu adəti-mə'hudə
müstəmir olmasaydı, bəqayi-süvəri-növiyyə və əfradi-şəxsiyyə zərurət ehtimalı
bulmaz idi. Və silsileyi-nizama istehkam müyəssər olmaz idi.

Bu bahri-niligun min mövc hər saət əyan eylər,
Ülul-ebsara bir-bir kəşfi-əsrari-nihan eylər.

Bəşaşət çehreyi-ruzəfzun və əsəri-sürur, əhaliyi izzü e'tibardan xasü əvama
bu məzmun vazeh olmuş və vəziü şərif bu surətə ittila' bulmuş ki, iradeyiqüdrəti-baliğeyi-rəbbani və məşiyyəti-hikməti-kamileyi-sübham müstəd'iyiistidaməti-rəvaci-şəriət və müstəziyyi-istiqaməti-mülkü millət olub, xəlvətsərayifəzilətdə mücəddədən bir şəm'i-füruzan münəvvər etmiş ki, pərtövi-zühurindən
ləməati-feyzi-ruhani cəmi'i-afaqa yetmiş.

Yenə gülzari-cahan xürrəmü xəndan olmuş,
Bir gül açılmışü afaq gülüstan olmuş.

Mücmələn bu hekayət kinayətdir ondan və bu rəmzü iyma işarətdir ona kim,
təkmili-əsbabi-hüsuli-qayəti-izzü iqbal və tətmimi-aləti-vüsuli-dərəceyi-kəmal
təriqjla bəzrəti-mexdumi-ələl-itlaq “əlləzi faqəhü külli raən fil-afaqi” [1], yə'ni
əqza-qüzatül-raüslümin ələl-izzü vəl-iqbali vəddin rəfəəl-lahü mədarice iclalihi
ə'la şə'nə


1 Elə Allah ki, kainatdakı hər kəs ona möhtacdır


303


iqbalihi. [1] Divani-inayəti-əzəli və müqimi-ətiyyati-ləmzəyəlidən mövhibeyifərzəndi-dilbənd və ətiyyəyi-xələfi-salehi-səadətmənd birlə sərəfraz olmuşlar. Və
dəryayi-arizudə bədriqeyi-tövfiq birlə gövhəri-məqsuda dəstrəs bulmuşlar.

**NƏZMİ-TARİX**

Qaziyi-adil Əlaəddini-aliqədr kim,
Hökmi-məqbuli qəzadan hasil etmişdir riza.
Bir xələf vermiş ona İyzəd ki, zati-qabili
Elm cəm'ini, hünər kəsbini etmiş iqtiza.
Nəqdi-qazidir əcəbmi ol nıütəhhər nütfəyə
Olsa tarixi-viladət "Kövkəbi-övri-qəza".

NƏZM

Bihəmdillah ki, bəxti-nikfərcam
Bezəd dəsti-əməl bərdaməni-kam.
Cohanra bəxti-ayini digər dad,
Nihali-elm gül kərdü səmər dad.
Fərazi-təxti-istiqlali-təmkin,
Əlaül izzi vel-iqbali vəd-din,
Müyəssər did əsbabi-bəqara,
Bə dəst avərd əsli müddəara.
Füruzan gəst əz dövlət çirağəş,
Zi gülbərgi müəttər şod dimağəş,
Dirəxti-niyyəti-u şod bərumənd,
Xuda dadəş yeki fərzanə fərzənd.
Mübarək məqdəmü pakizə didar,
Xöcəstə taleü fərxundə asar.
İlahi! Ta cəhan manəd, bəmanəd,
Cəhan ura bekamı dil rəsanəd.


1 Allah onun cəlal dərəcəsini yüksəltsin və iqbalı şənini ucaltsin.


304


**ƏHMƏD BƏYƏ MƏKTUB**

Şükr kim, rə'yimcə dövran etdi çərxi-çənbəri,
Tale' oldu feyz bürcündən səadət əxtəri.
Gəldi nagəh bir humayun tairi-fərxündəfal,
Ziyvər almış bir mübarək namədən balü pəri.
Mətlə'i-ənvari-behcət, məzhəri-asari-feyz,
Ehtimalı nəqşdən ari, məayibdən bəri.
Feyzü rifət nüsxəsi, lütfü kərəm məcmuəsi,
Fəzl tumarı, hünər divanı, hikmət dəftəri.
Həm səvadi-nurbəxşi zülməti-abi-həyat,
Həm bəyazi-rövşəni Ayineyi-İskəndəri.
Rabəti-dil hifzinə qat-qat dəruni bir hisar,
Ləşkəri-qəm dəf inə səf-səf xütuti bir çəri.
Filməsəl, hər sətri bir nəxlİ-məarif meyvəsi,
Miücmələn, hər ləfzi bir dürci-məani gövhəri.
Məscidi-əqsa kibi pakizə səhni-səffəsi,
Səf-səf olmuş sətrlərdən pays-payə minbəri.
Vaizi-idrakın ol minbərdə təqrir etdigi
Bir dua kim, sübhü şam olmuş məlaik əzbəri.
Qaşı nun, qəddi əlif, geysuləri cim, ağzı mim,
Bir səmənbər, nazənin məhbubə bənzər peykəri.
Sirri ifşasında qılmış ağzının tərkin dəvat,
Kəsbi sə'yimdə tökülmüş xamə alnının təri.
Sətrlərdir müntəzəm, ya hər biri bir riştədir
Kim, düzülmüşdür ona əsrari-hikmət gövhəri.
Valeh olmıış səfheyi-ruxsarinə əhli-nəzər,
Tazə gəlmiş çöhreyi-pakinə xətti-ənbəri.
Sözmüdür mərqum, ya bimarə göndərmiş həkim,
Kağəzə sarıb bir az parə nəbati sükkəri.
Dilgüşadır, nəş'əsi guya ki, məzmunundadır,
Musili səhbalərin keyfiyyəti-canpərvəri.
Yoxsa təhririn qılan Musil meyindən nuş edib,
Məstlik vəqtində ol məhbuba vermiş ziyvəri.


305


Gənci-gövhərdir, gədalar nəzri olmuş hifz üçün,
Möhr urmuşlar anın üstünə bəy həzrətləri.
Ol fələkrif ət ki, andan sadir olmaz qeyri-xeyr,
Yaxşı fe'lin yoxdur andan özgə əsla məsdəri.
Var ümidim ki, cəmii-binəvalar üstünə,
Ta əbəd memdud ola zilli-ütufətgüstəri.

**NƏSR**

Heyni-heyrəti-hirman və əvam-həvani-hicran ki, lisana qüvvəti-iqtidayi-cinan
və cinana qüdrəti iqtidayi-lisan mütəəzzir idi qəvafili-məsaliki məhzi-əltaf və
rəvahili-mərahili eyni e'taf ilə ehda və ithaf olunan əmtieyi-əxbari-sihhət və
cəvahiri-asari-behcətiniz hüsnü vürudu ilə mühərriki-səlasili-übudiyyət və
mücəddidi-qəvanini-müxaləsətimiz düşüb ol tərz xameyi-mişkbarın və ol nəqşinameyi-məsər-rətasarın hər sətri üruci-rütbeyi-iqtidara bir nərdiban və hər ləfzi
hüsuli-dərəceyi-e'tibara bir müjdərəsan olmağın xirədi-xürdmiqdar və əqliaqilişüar bu izzət ehtimalın mütəcavizül-adə və bu dövlət İstihsalın hevsələdən
ziyadə görüb qərqeyi-dəryayi-heyrət və sərgəşteyi-badiyeyi-dəhşət olmaqda ikən
dəsti-qeyrət daməni-himmət tutub lazım etdi ki, istiqbali-idraki-məzmununa
cövhəri-can və gövhəri-rəvan nisar oluna. Əmma yenə ümumi-inayətinizdən
zimmətimizdə olan sənalərin və şümuli-şəfəqatünüzdən niyyətimizdə olan
dualərin təxvifi-tövfiqi-müstəd'iyi-istibqayi-həyatımız və mümiddi-istehkamisəbatımız vaqe oldu. İstid'a olunur ki, həmvarə məzəlleyi-ülüvvi-rif'ət və
süradiği-sümüvvi-dövlət ətnabi-müasiri-hüsni-fial və övdati-nətaici-lütfi-xisal ilə
məfariqi-kafeyi-zənil-e'tiqada və rüusi-ammeyi-ülüləncada muzil və mümtəd ola
və həmişə hediqeyi-ərbabi-nəzər və cinani-cənani-əshabi-hünər rəşahəti-əmtariasari-mərahim və nəfəhati-əzhari-izhari-məkariminizdən nəzarət bula. Həqqa ki,
zəmani-mübaədəti-mülazimətinizdə müstəmir olan övqati-zəmimə və həngamimülaziməti-mübaədətinizdə keçən saati-qeyri-səlimə nə qabili-təhrir və nə
daxili-hövzeyi-qəbuli-təqrirdir. Əgər küdurəti-kufbeyi-əhzan dəf'inə əzimətibustan müsəmməm olunsa, bu fəraq əsərindən sineyi-cuyibar çak və dideyi-hövz
nənmak və nihali-turunc turşruy və nəxli-xurma pərişanmuy görünüb nə
səbzələrdə fəraqdan bir rəng bulunur və nə bülbüllərdə nişatdan bir ahəng.


306


Və əgər məlaləti-baği-ədimül-fəraq dəf'inə sakini-külbeyi-əhzan olmaq
murad olunsa, bu iştiyaq istilasından dili-şəm' suzan və cigəri-pərvanə büryan
görünüb rövzənləri ahi-sərd çəkməkdə və divariarı gərdi-küdurət tökməkdədir.
Göz hüzurunuzda olan təməttö'ləri uyxuda görməyə qane'dir, əmma giryeyibiixtiyar uyxuya mane'dir və xatirə müşahidəniz təxəyyüldə hasildir, əmma nə
hasil, təxəyyül edib təhəmmül etmək müşküldür.

QİT'Ə

Gər şərhi-qəm eyləsəm, ona payan yox,
V'ər səbr həm eyləsəm, ona dərman yox.
Çün təcrübə eylədim vüsalindən qeyr,
Ənduhi-fəraq dərdinə dərman yox.

Təvəqqe ki, mətləi-lətaifi-rəbbani və məşriqi-əvatifi-sübhanidən şümusivəsaili rəf i-zülməti-fəraq və biduri-vəsaiti-iqtibasi-ənvari-dəf i-iştiyaq tülu' və
zühur edincə bu nəhci-qədim və caddeyi-müstəqim üzərinə qədəmi-hiramət və
qələmi-şəfqət sabitü sayir olub əbvabi-təfəqqüd məsdud və əsbabi-təzəkkür
məfqud buyurulmaya (Baqi - dövlət müstədam və iqbal bərdəvam bad bərəbbi
ibad).


307


**BAYƏZİD ÇƏLƏBİYƏ MƏKTUB**

Ətəni kitabün bəl riyazün münəvvərün. Lə-qəd zadəni min novrihin-nuru-filbəsəri. Misalün bi hüsnil ehtimami müsəvvərün əla-əltəfil-əlvahi-fi əhsənissüvəri. Süturün kə-əflakin işarətüha'-şühubi. Xütutün kə-əc'sannin ibarətüha əzzəhrü. Fə-fi külli nəsrin minhu kənzün minəl-müna. Və fi külli nəzmin minhü
iqdün minəd-dürəri. Səhifətün imhəvət fiha fünunü'l-ma'arifi və hədiqətün unş'ət
minha qüsunül-avarifi, mürəttəbətün bi təvşihis-sənayi kəl-beytü-mə'muri və
müzəyyənətün bi-tərşihi'1-bədaye'i k'ər-rovzi'1-məm-turi, vərrədə vurudüha hida
iqən'n-nəvaziri və həllət bibülümihə's səmmrətü fi'z-zəma'iri. Təəlləmə minha
sü'ü-l amali və zalə və tərənnəmə fiha lisanü'1-hal və'lməqali [1]

Baz əbri səbzeyi-pəjmürdeyira ab dad.
Növbahari xari-xüşkira güli-sirab dad.
Didei-dovlət zi xabi-naümidi gəşt baz.
Dəsti-himmət qufli-əbvabi-əməlra tab dad.
Qasidi aməd mühibbani-qədimü'l əhdra,
Bəhri-təcdidi-səfa peyğami-əz əhbab dad. [2]

Mücəddədən cəvahiri-nükati-şekvəəngizi-inayətməzmun və zəvahiri-lüğatişikayətamizi-şəfqətməkmunun ədvieyi-ətibba kibi təlxtə'm və rahətfəza və


1 Tərcüməsi: Mənə bir məktub, bəlkə də çiçəkli bir bağça gəldi. Onun çiçəkləri gözümün nurunu
artırdı. O, ən lətif lövhələr üzərinə diqqətlə ən gözəl bir şəkildə təsvir edilmiş rəsm kimi bir misaldır.
Onun sətirləri, işarələri şəhablar kimi olan fələklərə bənzəyir. Yazılan budaqlar, ibarələri də çiçəklər
kimidir. Onun hər nəsri arzular xəzinəsidir. Bütün nəzmlərində inci danələri vardır. O, mə'rifət
fənnlərini ehtiva edən bir səhifə, bilik budaqlarının yetişdiyi bir bağçadır. Beytül-mə'mur kimi
sənətlər bəzəyilə bəzənmiş və yağmurla islanmış bir bağça kimi bədiələr tərşiyilə süslənmişdir. Onun
gəlişi göz bağçalarını çiçəkləndirdi. Onun gəlməsilə qəlblərdə meyvələr hasil oldu. Ondan pis
əməllər kədərləndi və zail oldular. O, bağçada hal və qal dili tərənnüm etdi.
2 Tərcüməsi:
Yenə bir bulud pəjmürdə bir səbzəni suladı.
Bir növbahar qurumuş bir tikanda gül bitirdi.
Dövlət gözü ümidsizlik yuxusundan oyandı,
Himmət əli aməl qapılarının qıfılını açdı.
Əski dostlardan bir qasid gəldi,
Dostluğumuzun səfasını yeniləmək üçün dostdan
bir xəbər gətirdi.


308


peymaneyi-səhba kimi cigərsuz və dilgüşa ki, əvaniyi-nəzm və nəsrə mövzu' və
əyyadi-həddü həsrə mövdu' olunub təriqi-tə'dibi-ərbabi-qəflət və səbili-tənbihiəshabi-heyrət-dən irsal olunmuş. İsal olunduqda can istiqbali-idraki-dəqaiqinə
azim və cinan istehsali əsrari-həqaiqinə cazim olub, mütaliə və müşahidə-dən
sonra dideyi-can məfhumundan mənzərəi-canan qılub məşami-cinani
mərqumundan istişmami-rayihəyi-canan etdi. Əmma əksəri-hikayəti
şikayətnümunə və övfəri-kitabəti kinayətgunə olmağın qəzali-xəyal mərati' və
mərabia'i-işarati şərifində həmləi-şahini-şika-yətdən lərzən və tairi-xatir səhari və
bərari ibarəti-lətifindən sədməi-üqabi itabdən gürizan olub, lisani-hal və zəbaniməal ilə tərənnüm və təkəllüm etdilər ki:

**BEYT:**

Çe bəd kərdim, ya Rəb, əz çe ru rəncidə yar əz ma,
Çe vaqe şod, çera bər daşt çeşmi-e'ribar əz ma. [1]

Həmana bir qaç gün insidadi-türüqi-tərəddüd manei-irsal və izbari-təvəddüd
inqita'i-sübuli-təsadür və təvarüd qət'i-isali-asari-təfəqqüd olmaqla qübarsudisineyi-mir'ati-zəmirinizə rəngi-küdurət yetirib surəti-məhəbbət məhv olmuş və
sərsəri-fəsad e'tiqadi-gülşəni-xatiri-münirinizə xələl verüb, rəngi-gülbərgiməvəddət solmuş.

Məkon-məkon ki, nikuməhzəran çenin nəkonənd. [2]

Həqqa ki, əgər nəfsi-nəfis təriqi-bərqi fənada müntəfi olsa, mevqidivücudumdan iltihabi-niyrani-həqiqət intifa' bulmaz və əgər rişteyi-rabiteyi-canü
tən və silsileyi-əlaqeyi-ruhü bədən münhəl və münqəte' olsa riqbeyi-iradətim
ribkeyi-itaətdən xaric olmaz.

Gər bər kənəm dil əz to vü bər darəm əz to mehr,
An mehr bər ke əfkənəm, an del koca bərəm. [3]


1 Tərcüməsi: Ya Rəb, biz nə etdik ki, sevgili bizdən incidi,
Nə oldu ki, bizə qiymət verməyib gözündən saldı?
2 Bunu etmə ki, yaxşı insanlar belə şey etməzlər
3 Əgər mən səndən könlümü alsam və məhəbbətimi kəssəm,
Könlü kimə bağlayacağam və ya sevgini kimə verəcəyəm?


309


**LÜĞƏT**

**A**

_Ab_ -su
_Aba_ '- atalar
_Abginə_ - şüşə
A _bidar_ - sulu; təzə
_Abi-heyvan_ - dirilik suyu
_Abi-həyat_ - dirilik suyu
_Abü danə_ - yemək-içmək; su və
dən
_Abü tab_ - lətafət, təzəlik
_Ac_ - fil sümüyü
_Afaq_ - üfüqlər
A _fərinandə_ - yaradan, Allah
_Afəriniş_ - yaradılmış, xilqət
_Afət-_ Bəla: gözəl
_Afitab-_ günəş
_Afiyət-_ sağlamlıq
_Agah_ - xəbərdar
_Ağaz_ - başlamaq, başlanğıc
_Al_ - qırmızı; hiylə; nəsil
A _lam_ - kədərlər, ələmlər
_Alayiş_ - bəzək, zinət, süni zinət,
bulaşmaq
_Aləmara -_ dünyanı bəzəyən
_Aləməfruz -_ dünyanı işıqlandıran
_Aləmsuz -_ dünyanı yandıran
_Aləmtab  -_ dünyaya  işıq  və hərarət verən
_Ali - yüksək_
_Amac - hədəf_
_Amacgah_ - hədəfin olduğu yer
_Amadə_ - hazır
_Amal_ - əməllər, arzular
_Ara_ - bəzəyən


310


_Arayiş_ - zinət, bəzək; arayişisöhbət eylə, saqi - saqi, söhbəti bəzə
_Ar_ i - boş, çılpaq
_Ariyət_ - burovuz
_Ariz_ - yanaq
_Asayiş_ - rahatlıq
_Asib_ - bəla, müsibət
_Aşiyan_ - yuva
_Aşub_ - fitnə, həyəcan
_Aşüftə_ - məftun, vurğun
_Atəşbar_ - od yağdıran
_Avaz_ - səs, səda
_Ayin_ - adət, qayda-qanun
_Azim_ - əzm edən, bir tərəfə gedən
_Azimun_ - öyrəniş, yoxlamaq,
təcrübə

**B**
_Bab_ - qapı, fəsil
_Babi-məsdud_ - bağlı qapı
_Bad_ - külək
_Badə_ - şərab
_Badigird_ - küləkdən əmələ gələn
qasırğa
_Badiyə_ - çöl, səhra
_Badiyəgərd_ - çöldə gəzən
_Badiyənişin_ - çöldə həyat keçirən
_Badnavərd_ - küləklə döyüşən
_Badpay_ - yel ayaqlı, sürətlə
gedən at
_Badpeyma -_ boş, avara gəzən
_Bak_ - qorxu
_Baqi_ - həmişəlik, qalan, daimi


311


_Bal_ - qanad
_Bala_ - yüksək
_Baliğ_ - yetişmiş, həddi-büluğa
çatmış
_Balin_ - yastıq
_Bam_ - dam
_Bani_ - bina edən, əsasını qoyan
Bar - yük; meyvə; dəfə
_Baran_ - yağış
_Baravər_ - meyvəli
_Barigah_ - saray; divanxana
_Bari-giran_ - ağır yük
_Barik_ - dəqiq, incə, nazik
_Barkə_ ş - yük daşıyan
_Batil_ - əsassız, həqiqətə uyğun
olmayan
_Bavər etmək_ - inanmaq, etimad
etmək
_Baziçə_ - oyuncaq
_Behbud_ - yaxşılıq, sağlıq
_Behiştasa_ - behişt kimi
_Behtər -_ daha yaxşı
_Beyn_ - orta, ara
_Beyt_ - ev; şe'rin iki qoşa misrası
_Beytül-həzən_ - qəm evi
_Beyzə -_ yumurta
_Bə 'd_ - sonra
_Bəd_ - pis, çirkin, yaramaz
_Bədəl_ - əvəz, bir şeyin yerini tutan
_Bədəndi_ ş - pis niyyətli
_Bədgu_ - hər şey haqqında pis
danışan
_Bədxah_ - hər kəsin pisliyini istəyən
_Bədnam_ - pis adlı
_Bədnəjad_ - əsli-nəcabəti olmayan
_Bədr -_ on dörd gecəlik ay
_Bədsərəncam_ - axın pis olan adam


312


_Bəğəl_ - qoltuq
_Bəhayim_ - dördayaqlı heyvan
_Bəhcət_ - gözəllik
_Bəhr_ - dəniz; əruz vəznində şeir
ölçüsü
_Bəhram_ - Mars planeti
_Bəga_ - həmişəlik
_Bəqayi-nəsli-insan_ - insan
nəslinin həmişəlik qalması
_Bəlakeş_ - dərd çəkən, başı bəlalı
_Bəna_ t - qızlar
_Bandə_ - qul, kölə
_Bəndəpərvər_ - köləsini yaxşı
saxlayan
_Bəng_ - tiryək
_Barat_ - yazılmış kağız; rəsmi
göndərilmiş kağız
_Bərd_ - soyuq
_Bərf -_ qar
_Bərg_ - yarpaq; bərgi-gül - gül
yarpağı; bərgi-səbz - yaşıl
yarpaq
_Bərgüzidə_ - seçilmiş
_Bərq_ - şimşək
_Bəsa_ - çox
_Bəsi_ - çox, xeyli
_Bəstə_ -bağlı.
_Bəstədəhan_ - ağzı bağlı; sakit;
dili tutulmuş
_Bəstər_ - yalaq
_Bəşarət -_ müjdə
_Bəşaşət_ - gülmək, fərəhlənmək,
şənlik
_Bəya_ z - ağ
_Bəzl_ - bağışlamaq
_Bəzm -_ məclis
_Bəzmgəh eylədi mürəttəb_ məclis düzəltdi



313


_Bid_ - söyüd ağacı
_Bidad_ - zülm
_Bidirəng -_ aramsız, yubanmadan
_Bigah_ - vaxtsız
_Biganə_ - yad
_Bigüman_ - şəksiz, şübhəsiz
_Bihəd_ - hədsiz
_Bix_ - kök
_Bixud_ - özündən xəbərsiz
_Büzzətü e'tibar_ - hörmətsiz və
etibarsız
_Bikəran_ - hədsiz, ucsuz-bucaqsız
_Bikəs_ - kimsəsiz, köməksiz
_Biqəra_ r - qərarsız, narahat
_Bilcümlə_ - bütün, tamam
_Bim_ - qorxu
_Bimar_ - xəstə
_Biməhaba_ - qorxusuz
_Bina_ - görən, qabağı görən
_Binəhayət_ - sonsuz
_Binəva_ - yazıq
_Bini_ - burun
_Biniş_ - görüş
_Bipərva_ - köməksiz; qorxusuz,
cəsarətli
_Birun_ - xaric
_Bisərü saman_ - başsız-ayaqsız,
intizamsız
_Biş -_ artıq, çox
_Biştər_ - daha çox
_Bivayə_ - adamsız, yersiz
_Bizar -_ pulsuz, qızılsız
_Bum_ - yer, torpaq; bayquş
_Bustan_ - bağça, çiçəklik
_Buy_ - qoxu
_Büq'ə_ - yer
_Bülənd_ - yüksək, ali
_Bühndəxtər_ - xoşbəxt taleli



314


_Bülhəvəs_ - həvəsə uyan
_Bün_ - özül; dib, kök
_Bünyad_ - özül, əsas
_Bürəhnəpa_ - ayaqyalın
_Bürha_ n - dəlil, sübut
_Büridə_ - kəsilmiş
_Bürudə_ t - soyuqluq
_Büt_ - ədəbiyyatda gözəl mənasında işlədilir
_Büzqalə_ - keçi balası, ovlaq
_Büzürg -böyük_
_Büzürgvar_ - yüksək rütbəli

**C**

_Cah_ - mənsəb; hörmət
_Cahanara_ - dünyanı bəzəyən
_Cahanəfru_ z - aləmə işıq verən,
günəş
_Camə_ - paltar
_Camid_ - donmuş
_Can_ - ruh, bədən
_Canbəxş_ - rub verən
_Canfəza_ - can bağışlayan
_Canpərvər_ - ürəyə xoş gələn
_Cansuz_ - ürək yandıran
_Cari olmaq_ - axmaq, tökülmək
_Cəbəl_ - dağ
_Cəbin_ - alin
_Cədd_ - baba
_Cədəl_ - mübahisə
_Cədid_ - təzə, yeni
_Cəng_ - döyüş, müharibə
_Cərahət_ - yara
_Cərəs_ - dovanin boynundan
asılan zəng, zınqırov
_Carihə_ - yara


315


_Cəzə_ ' - səbirsizliklə təlaş və
iztirab keçirmək, ağlayaraq şikayət etmək
_Cəzm_ - qəti
_Cibal_ - dağlar
_Cidal_ - döyüşmək, vuruşmaq
_Cigərsuz_ - ürək yandırıcı
_Cinan_ - cənnətlər
_Cövşən_ - zireh, dəmir geyim
_Cu_ - arx, su arxı, kiçik çay
_Cuşiş_ - cuşə gəlmək, coşmaq
_Cuybar_ - kiçik çay
_Cüda_ - ayrı
_Cünbuş_ - hərəkət
_Cünun_ - dəlilik

**Ç**

_Çah_ - quyu
_Çahi-zənəxdan_ - çənə çuxuru
_Çak etmək_ - parçalamaq
_Çakə_ r – nökər, qul
_Çaki-giriban_ - yaxa cırığı
_Çapuqsüvar_ - sürətlə gedən
_Çarəcu_ - çarə axtaran
_Çarəsaz_ - əlac tapan
_Çeşm_ - göz
_Çeşməyi-həyat_ - dirilik bulağı
_Çənbər_ - dairə
_Çərxi-çənbəri_ - dairəvi səma
_Çin_ - qıvrım, toplu, doğru
_Çinə_ - quş dəni
_Çini-əbru_ - qaşqabaq

**D**

_Dad_ - ədalət, insaf
_Dadbəxş_ - ədalətli
_Dadxah_ - şikayətçi


316


_Dağidar_ - son dərəcə mütəəssir
olmaq; dağlanmış
_Daği-dil_ - ürək dağı
_Dağizən_ - dağ vuran
_Dam_ - tələ, tor
_Damən -_ ətək
_Daməni-_ kuh - dağ ətəyi
_Damigah -_ tələ qurulan yer; dünya
_Dami-qəm_ - qəm tələsi
_Dana_ - alim, bilici
_Danəndə_ - bilikli adam
_Daniş_ - bilik, elm
_Danişmənd_ - ağıllı, bilikli, elmli
_Dar_ - bina, ev
_Dari-bəqa -_ axirət evi
_Darül-əman_ - sığınacaq yer
_Dehqani-hədiqeyi-hekayət_ hekayət bağçasının bağbanı
_Dey_ - qış mövsümü; hicri günəş
ilinin onuncu ayı
_Deycur_ - qaranlıq gecə
_Deyn_ - borc
_Deyr_ - monastır, kilsə
_Dəb_ - adət, ənənə
_Dəbir_ - katib, yazıçı
_Dəbistan_ - məktəb
_Dədü dam_ - vəhşi heyvanlar
_Dəhan_ - ağız
_Dəhr_ - çöl, səhra
_Dəqaiq əhli_ - incə, xırda şeyləri
bilənlər, zərif düşünənlər
_Dəlil_ - yol göstərən; sübut
_Dəm_ - qan; nəfəs; ah; söhbət
_Dəm vurmaq_ - bəhs etmək
_Dəmadəm_ - zaman-zaman, arası
kəsilmədən
_Dəmbəstə_ - nəfəsi tutulmuş, danışmayan


317


_Dəmi-sərd_ - soyuq ah
_Dəmsaz_ - sirdaş, yoldaş
_Dəndan_ - diş
_Dəni_ - alçaq
_Dər_ - qapı
_Dərağuş_ - qucaqlamaq
_Dərbədə_ r- qapı-qapı gəzən
_Dərdi-dil_ - ürək dərdi
_Dərdnak_ - dərdli
_Dərhəm_ - qarmaqarışıq
_Dərmandə_ - aciz, əlacsız
_Dəryadü_ - geniş ürakli, hövsələli
_Dəryayi-təhəyyür eylədi_ cuş heyrət dənizi dalğalandı
_Dəst_ - əl
_Dastamuz_ - ələ öyrənmiş (quş,
heyvan)
_Dəstar_ - çalma, sarıq
_Dəstgir_ - əldən tutan
_Dəstrəs_ - əl çatan, ələ gəlmək
_Dəstur_ - İzn, rüxsət
_Dəvvar_ - dövr edən, hərəkət edən
_Dibaçə_ - müqəddimə
_Didar_ - üz, camal, görüş
_Didə_ - göz
_Digərgun_ - pozulmuş
_Dil_ - ürək
_Dilara_ - könül bəzəyən, sevgili
_Dilaram_ - ürəyə səfa verən
_Dilazar_ - ürək incidən
_Diləfgar_ - könlü yaralı
_Diləfruz_ - könülə fərəh gətirən,
ürək açan
_Dilfirib_ - könül aldadan
_Dilkaş_ - ürək çəkən
_Dilnəvaz_ - ürək oxşayan
_Dilnişan_ - ürəya yatan
_Diriğa_ - heyf, çox təəssüf



318


_Divanə_ - dəli
_Dövr bünyad etmək_ - mollaxanada
uşaqların öz dərslərini avazla
təkrar etmələri
_Dud_ - tüstü
_Dur_ - uzaq
_Durbin_ - uzaqgörən
_Durəndiş_ - gələcəyi düşünən.
uzaqgörən
_Duzəx_ - cəhənnəm
_Dü cahan_ - iki dünya; bu dünya
və axirət
D _ürc_ - sandıqça
_Dürd_ - şərabın dibinə çökən xılt
_Düruğ_ - yalan
_Düstur_ - qanun
_Düşnam_ - söyüş
_Düşvar_ - çətin
_Düyün_ - şənlik, toy
_Düzd_ - oğru

**E**

_E 'vaz_ - əzizləmək, mehribanlıq
_Eybcu_ - eyb axtaran, rişxəndçi
_Eyn_ - göz
_Eys_ - kef, işrət; eyşi-əbədi -əbədi işrət

**Ə**

_Ə 'da_ - düşmənlər
_Ə 'ma_ - kor
_Ə 'mal_ - əməllər
_Ə 'van_ - köməkçilər
_Ə 'zayim_ - dualar, ovsunlar
_Ə'zəm_ - daha böyük
_Əali_ - böyük adamlar, alilər
Ə _azim_ - böyüklər


319


_Əbcəd -_ ərəb əlifbasında say
sistemi
_Əbd-_ qul
_Əbdan -_ bədənlər
_Əbr_  - bulud
_Əbri-neysan_  - neysan buludu
_Əbru_  - qaş; əbruyi-xəmi bəlayiüşşaq - əyri qaşı aşiqlərin bəlasıdır
_Əbsəm_  - lal ol
_Əbvab_  - qapılar; əbvabi-təkəllüm
etsə ağaz - söz qapılarını açsa,
danışsa
_Əbyat -_ beytlər
_Əcəm_  - ərəb olmayan
_Əcz_  - acizlik
_Ədəm_  - yoxluq
_Ədəmdən oldu peyda_  - yoxdan
var oldu
_Ədüv_  - düşmən
_Ədvar_  - dövrlər, zəmanələr
_Əfgar_  - pərişan, yaralı
_Əfkəndə_  - yıxılmış, düşkün, biçarə
_Əflak_  - göylər
_Əfsər_   - tac
_Əfsürdə_  - solğun
_Əfza_  - artıran
_Əğyar_  - özgələr, yadlar
_Əhbab_  - dostlar
_Əhlən və səhlən_  - ərəbcə "xoş
gəldiniz" mənasında işlədilən
ifadə
_Əhli-neyrəng_   - kələkbaz, hiyləgər adamlar
_Əhli-raz_   - sirr əhli, sirdaş
_Əhmər_  - qırmızı
_Əhsən_  - çox gözəl
_Əhvəl_  - çəp


320


_Əxgər -_ qor; odlu kül
_Əxtər_ - ulduz; əxtəri-bəxtim
odlu tirə - bəxt ulduzum qaraldı (söndü); əxtərşünat
münəccim
_Əxzər_ - yaşıl
_Əkabir_ - böyüklər
_Əkbər_ - daha böyük
_Əklü şürb_ - yemək-içmək
_Əkməl_ - daha mükəmməl, nöqsansız
_Əkrəm -_ çox səxavətli
_Əqalim_ - iqlimlər
_Əqd -_ düyün, nikah
_Əqdəm_ - qabaq, əvvəl
_Əqli-vali_ - yüksək ağıl
_Əqran_ - tay-tuş
_Əqrəba_ - yaxın qohumlar
_Əlaim_ - əlamətlər, nişanlar
_Əlayiq_ - əlaqələr
_Əlcibali-övtad_ - şiş dağlar
_Ələm_ - bayraq; dərd-qəm
_Əltaf_ - lütflər, mərhəmətlər
_Əmarət_ - əmirlik
_Əmin_ - inanılmış, mö'təbər
_Əmn_ - rahatlıq, sülh
_Əmval_ - var-dövlət
_Əmvat_ - ölülər
_Ənadil_ - bülbüllər
_Ənbiya_ - peyğəmbərlər
_Əncüm -_ ulduzlar
_Əncümən -_ yığıncaq
_Əndəlib_ - bülbül
_Əndişə_ - fikir, xəyal
_Ənfas_ - nəfəslər
_Ənis_ - həyan, həmdəm
_Ənqa_ - Simurğ quşu



321


_Ənvər_ - işıqlı, parlaq
_Əraq_ - tər
_Ərğivan_ - qırmızı rəngli çiçək
_Ərməğan_ - hədiyyə
_Ərsa_ - meydan
_Ərus_ - gəlin
_Ərvah_ - ruhlar
_Ərzan_ - ucuz
_Ərzəl_ - alçaq
_Əs 'ar_ - bazar, nırx
_Əsalib_ - üslublar, qaydalar
_Əsbab_ - səbəblər, vasitələr
_Əsəd_ - şir
_Əshab_ - müsahiblər, həmsöhbətlər
_Əshəl_ - daha asan
_Əsrar_ - sirrlər; əsrari-dil - ürək
sirrləri; əsrari-nihan - gizli
sirlər
_Əsvəd_ - qara
_Əş 'ar_ - şeirlər; əş 'ar bulub kəsadi-əs 'ar - şeirin bazarı kasad
olub, şeir qiymətdən düşüb
_Əşcar_ - ağaclar
_Əşhər_ - çox şöhrətli, məşhur
_Əşkal -_ şəkillər
_Əşkbar_ - göz yaşı tökən, çox
ağlayan
_Əşkbar -_ göz yaşı
_Əşhiz_ - göz yaşı axıdan
_Əşrəf-_ çox şərəfli
_Əta_ - bəxşiş
_Ətrak_ - türklər
_Ətşan_ - susuz, təşnə
_Ətvari kərihü xülqi naxoş_ - hərəkətləri iyrənc, xasiyyəti xoşagəlməz
_Əyan_ - açıq, aşkar


322


_Əyyam_ - zaman, günlər
_Əzhar_ - çiçəklər
_Əzhər_ - daha aşkar, daha aydın
_Əzim -_ böyük
_Əzimət_ - müəyyən bir yerə
hərəkət etmə

**F**

_Faxtə_ -çöl göyərçini
_Fam_ - rəng
_Fanusi-xəval_ - xəyal fənəri
_Fariğ -_ asudə
_Faş_ - zahirə çıxmaq, məlum
olmaq
_Fəm_ - ağız
_Fərax_ - geniş
_Fəraq_ -ayrılıq
_Fəramuş etmək_ - unutmaq
_Fərar_ - qaçmaq
_Fərd_ - tək
_Fərda_ - sabah
_Fərəh_ - şadlıq
_Fərxəndə_ - şad, xoşbəxt, uğurlu
_Fərq_ - baş
_Fərrux_ - uğurlu
_Fərz oldu_ - vacib oldu
_Fərzənd_ - oğul
_Fəttan_ - fitnəli; cazibəli
_Figar_ - yaralı
_Firdövs_ - cənnət
_Firib_ - aldatmaq
_Fulad_ - polad
_Füsürdə_ - donmuş, solğun
_Füsürdədil_ - ürəyisolğun, hissiz
_Fütada_ - düşmüş
_Füzun_ - artıq, çox



323


**G**

_Gav_ - öküz
_Gavi-mahi_ - dini əfsanədə yeri buyunuzunda s
axlayan və balığın üstündə duran öküz
_Geysu -_ hörük, saç
_Gənc_ - xəzinə
_Gəncineyi-nəzm_ - şeir xəzinəsi
G _əncinəgüşa_ - xəzinə açan, yeni
söz deyən şair
_Gərd_ -toz
_Gərdan_ - hərlənən, dönən; gərd
ayineyi-nişatə-düşdü - şadlıq
aynasi tozlandı; gərdalud toza, torpağa bulaşmış
_Gərdişi-zəmand_ - zəmanənin
dolanması
_Gərdun_ - dönən; fələk; dünya
_Gərm_ - isti; gərmi-hazar qılmaq
bazan qızışdırmaq
_Gəz -_ dəfə, arşın
_Gil_ - palçıq, torpaq
_Giran_ - ağır, bahalı
_Giranbar_ - ağır yüklü
_Girdab -_ burulğan, firtına
_Gireh_ - düyün
_Giriban_ - yaxa; giribançak yaxası parçalanmış
_Giriftar_ - tutulmuş
_Giriz_ - qaçma; girizan - qaçan
_Giryan_ - ağlar
_Giryə_ - ağlama
_Giyah_ - ot
_Gövhərbar_ - gövhər yağdıran
_Gövhərfəşanlıq_ - gövhər səpmək, mənalı danışmaq
_Gövhərpaş_ - gövhərsaçan


324


_Gövhərriz_ - mənalı danışan, şirin
danışan
G _öymək_ - yanmaq
_Gur_ - qəbir; qulan
_Guş_ - qulaq; guş tutmaq - qulaq
asmaq
_Gülbün_ - gül budağı
_Gülçin_ - gül toplayan; gül yığan
_Gülfam_ - gül rəngli
_Gülfəşan_ - gülsaçan
Gülgün - gül rəngli
_Gülxən_ - hamamın od qalanan yeri
_Güli-hədiqeyi-cud_ - səxavət bağçasının gülü.
_Güli-sürx_ - qırmızı gül
_Güli-tər_ - təzə gül
_Gülnar_ - nar çiçəyi
_Gülrizlik_ - gül səpmək
_Gülru_ - gülüzlü Gülrüxsar - gülyanaq
_Gümnam_ - ad-sanını itirmiş:
unudulmuş
_Gümrah_ - yolunu itirmiş: yolundan çıxmış
_Gürz_ - toppuz
_Güşadə_ - açılmış; güşadə əbru -açıqqaşlı:
gülər üzlü; güşa-dəru - açıq üzlü
_Güvah_ - şahid
_Güzər_ - keçmək
_Güzidə_ - seçilmiş

**H**

_Hadi_ - yol göstərən
_Halik - həlak olan_
_Hamun_ - çöl


325


_Hariz_ - əkinçi
_Haziq təbib_ - məharətli, ustad,
təbib
_Həba_ - bihudə
_Həbib_ - sevgili, dost
_Həcər_ - daş
_Həcəri-mübarək_ - Kəbədəki
müqəddəs daş
_Hadayiq_ - bağçalar
_Hədiqs_ - bağça
_Həqir_ - etibarsız, aciz
_Həmamə_ - göyərçin
_Həmbəzm_ - bir məclisdə oturan
_Həmdəm_ - yoldaş
_Həmnişin_ - yoldaş
_Həmra_ - qırmızı
_Həmraz_ - sirdaş
_Hamsayə_ - qonşu
_Hərgiz_ - heç zaman, əsla
_Hərir_ - ipək
_Həsud_ - paxıl
_Həvadis_ - hadisələr
_Həvaxah olmaq_ - sevmək, istəmək
_Həvəsnak_ - həvəsti
_Həyuni-rəhnəvərd_ - yol gedən
dəvə
_Həzar_ - min; bülbül
_Həzarpişə_ - müxtəlif peşə sahibi
_Hicab_ - pərdə; utanma
_Hicr_ - ayrılıq
_Hidayət_ - doğru yola getmək
_Hifzi-səbəq_ - dərs əzbərləmək
_Hilal_ - yeni çıxmış ay
_Hilaləbru_ - ay qaşlı Hindusinə sürmə həmgiriftar
-sürmə də qara gozlərinə məftunidi
_Hirman_ - məhrumiyyət


326


_Hirz -_ qorunmaq, tilsim
_Hümayun_ - uğurlu, mübarək
_Hümma_ - xəstəlikdən doğan
hərarət, qızdırma; isitmə
_Hünərmənd,_ hünərvər - hünərli
_Hüsni-göftar_ - söz gözəlliyi

**X**

_Xab_ -yuxu
_Xah-naxah_ - istər-istəməz
_Xök_ -torpaq
_Xakidan_ - dünya
_Xaki-kəfi-payı  sürməyi-nur_ ayağının torpağı hurilərin gözünə sürmə idi
_Xakisar_ - toz-torpaq içində qalmış; pərişanhal
_Xakistər -_ kül
_Xakpay_ - ayaq torpağı
_Xali_ - boş
_Xama_ - qamış qələm
_Xamuş olmaq_ - sakit, dinməz
dayanmaq
_Xan_ - süfrə; karvansaray
_Xana_ -ev
_Xar_ - tikan; fəqir, zəlil
_Xarə_ - çox möhkəm daş, mər-mər, qranit
_Xavər_ - gündoğan
_Xeyt -_ dəstə, tayfa
_Xeymə_ - çadır
_Xeyrəndiş_ - xeyirli iş düşünən,
xeyirxah
_Xədəng_ - möhkəm ağacdan qayrılmış ox
_Xədəngi_ -xunriz-qan tökən ox


327


_Xələf-_ əvəz edən; "oğul" məna
sında işlənir
_Xəlxal -_ keçmişdə  qadınların

ayağa taxdıqları zinət
_Xəm -_ əyri
_Xəmidə -_ əyilmiş, bükülmüş
_Xəmü piç_ - əyri və qıvrım
_Xəndan -_ gülən; açılmış
_Xəndə -_ gülüş
_Xərgah -_ çadır
_Xəsarət -_ zərər, ziyan
_Xəsm-_ düşmən
_Xəsüxar -_ çör-çöp
_Xətm etmək -_ qurtarmaq
_Xəyyat -_ dərzi
_Xəzanə -_ xəzinə
_Xəzra -_ yaşıl
_Xüridar -_ alıcı, müştəri
_Xilaf-_ yalan, tərsinə deyilmiş söz
_Xilafi-müddəa_ - istəyin əksi
_Xirəd -_ ağıl
_Xirədmənd -_ ağıllı
_Xiragözlü_ - fərsiz; qamaşmış,

şaşqın gözlü; bihəya
_Xirqə -_ keçmişdə kişilərə məxsus

üst paltan
_Xosrov -_ padşah, hökmdar
_Xoşnud -_ razı
_Xövf-_ qorxu
_Xudrəy -_ özbaşına hərəkət edən
_Xun -_ qan
_Xunabə -_ qanlı su
_Xunalud -_ qana bulaşmış
_Xunbar_ - qan yağdıran
_Xunin -_ qanlı
_Xunriz -_ qan tökən
_Xuraman -_ sallana-sallana

(yerimək)



328


_Xurşid -_ günəş
_Xurşid rüxilə aləmaray_ _-_ günəş

üzü ilə aləmi bəzəyən
_Xücəstə -_ uğurlu
_Xüld -_ cənnət
_Xülq -_ təbiət
_Xüm -_ küp
_Xürdədan -_ ən kiçik şeylərə

diqqət edən
_Xürrəm -_ şad
_Xürsənd -_ şad
_Xüsran -_ zəlillik
_Xüşk_ -quru
_Xütteyi-Rum -_ Rum ölkəsi, Kiçik

Asiya


İ


_İbarəti-xub -_ yaxşı  ifadələr,

bədii ibarələr
_İbram -_ üzə salıb bir işi bir ada
mım boynuna qoymaq
_İbtihac -_ sevinc, fərəh
_İcabət buldu -_ qəbul oldu
_İdamə -_ davanı etdirmək
_İdbar -_ bəxtsiz, talesiz
_İkrah -_ iyrənmək
_İkram -_ hörmət göstərmək
_İklisab -_ kəsb etmək, qazanmaq
_İqd -_ boyunbağı
_İqdi-şəbnəm -_ şeh damlaları
_İltica -_ sığınmaq
_İmtila -_ dolmaq
_İmtina -_ çəkinmək, rədd etmək
_İnabət -_ qəflətdən qurtarmaq
_İnfial -_ utanmaq
_İnhiraf -_ dönmək, boyun qaçır
maq, rədd etmək



329


_İnkisar -_ sınmaq, qırılmaq
_İnqitai-ülfət qıldı -_ əlaqəsini kəsdi
_İntiha -_ nəhayət, son
_İntixab -_ seçmək
_İntiqal -_ bir yerdən başqa yerə

keçmək
_İntişar -_ yayılmaq
İ _radət -_ arzu, istək
İ _rəm -_ cənnət
İ _rişdi -_ çatdı
_İrsal -_ göndərmək
_İrşad -_ yol göstərmək, rəhbərlik

etmək
_İrtifa -_ ucalmaq
_İstiğna -_ ehtiyacsızlıq, laqeydlik
_İstiqbal -_ qabağa çıxmaq, qarşı
lamaq, gələcək
_İstirham_ - yalvarmaq
_İstitaət_ - qüdrət, güc
_İştika -_ şikayət etmək
İ _ştiyaq -_ şövq, həvəs
_İtab -_ datılaq, töhmət
_İtmam -_ tamamlamaq
_İttisad -_ yetişmək, qovuşmaq
_İyzəd -_ Allah, Tanrı
_İzdiyad -_ artırmaq

_K_
_Kafur -_ ağ rəngli və qoxulu yağ
_Kax_ - qəsr, yüksək bina
_Kam -_ məqsəd, arzu; ləzzət
_Kambəxş -_ arzu və məqsədə

yetirən
_Kambin -_ arzu və məqsədinə nail

olan
_Kamran -_ xoşbəxt, arzusuna çatan
_Kan -_ mədən



330


_Kar -_ iş
_Karfərma -_ iş buyuran
_Kargər -_ işçi
_Karxanə -_ iş göryülən yer; dünya
_Kaşif-_ kəşf edən
_Kaşifi-əsrar -_ sirləri kəşf edən
_Kazib -_ yalançı
_Keyvan -_ Satum planeti
_Kəbbadə_ - təlim yayı
_Kəbir -_ böyük
_Kəbud -_ göy rəng
_Kəbutər -_ göyərçin
_Kəlağ -_ qarğa, quzğun
_Kəlal -_ yorğunluq
_Kəlami-mövzun -_ vəznli söz, şeir
_Kəmakən -_ əvvəlcədən olduğu

kimi
_Kəmandar -_ ox atan
_Kəmanəbru -_ yay qaşlı
_Kəmin -_ pusqu
_Kamingah -_ bərə, pusqu yeri
_Kəmqiymət -_ qiymətsiz, dəyərsiz
_Kəmtər -_ daha az, əskik, aciz, etibarsız
_Kənar -_ qucaq
_Kərahət -_ iyrənmək
_Kərih -_ iyrənc
_Kəsad -_ alış-verişin durğunluğu, kasadlıq

_Kəvakib -_ ulduzlar
_Kəzzab -_ yalançı
_Kibr -_ boyüklük, qürur
_Kilk -_ qamış qələm
_Kilki-təqdir -_ qəzanın qələmi

_Kirdigar -_ Allah
_Kirişmə_ - naz, qəmzə
_Kişvər_ - ölkə, məmləkət, vilayət
_Kizb –_ yalan


331


_Kövdən_ - axmaq, dərrakəsiz
K _övkəb_ - ulduz
_Kövkəb_ ə - təntənə;  binaların
üstündəki bəzək
_Kövn_ - dünya
_Kuh_ - dağ
_Kuhikən_ - dağ çapan. Fərhadın

ləqəbidir
_Kuhsa_ r - dağlıq yer
_Kuhü dəşt_ - dağ və səhra
_Kutah_ - gödək, qısa; kutah nəzər

uzaq görməyən adam
_Kuy_ - küçə, astana
_Külah_ - papaq
_Külbə_ - daxma
_Külbəyi-əhzan_ - kədər evi
_Küstax_ - arsız, ədəbsiz, həyasız
_Küştə_ - öldürülmüş


Q

_Qabil_ - qabiliyyətli, ağıllı
_Qaim_ - möhkəm, daimi
_Qal_ - söz
_Qaliyə_ - mişk-ənbərdən hazırlanan gözəl iyli qara ətir
_Qaməti-_ mövzun - yaraşıqlı boy
buxun
_Qanda_ - harada
_Qanğı_ - hansı
_Qanı_ - hanı
_Qate'_ - kəskin
_Qazə_ - ənlik; qadınların yanaqlarına çəkdiyi qırmızı rəng
_Qə 'r_ - dərinlik, dib
_Qəbahət_ - günah, təqsir
Q _əbail_ - qəbilələr
Q _əbih_ - çirkin


332


_Qəb-qəb_ - buxaq
_Qəbl_ - əvvəl
_Qədəhpeyma_ - şərab içən
Q _ədr_ - hiylə, vəfasızlıq, haqsız
lıq, zülm
_Qədr_ (ğədr) - dəyər, qiymət,

məziyyət
_Qələyan_ - qaynama
_Qəmər_ - ay
_Qəmgüsar_ - təsəlli verən, həmdərd
_Qəmnak_ - qəmli, kədərli.
_Qəm rəhgüzərində payimaləm_ - qəm

yolunda ayaqlar altında qalmışam
_Qəni_ - varlı, dövlətli
_Qərib_ - yaxın
_Qəriq_ - suya batmış, boğulmuş
_Qət'i-rəhi_ -dilsitanım etdin 
sevgilimin yolunu kəsdin
_Qəvvas_ - üzgüçü, dalğıc
_Qəzal_ - ceyran
_Qəzənfər_ - şir
_Qissəpərdaz_ - nağıl söyləyən
_Qönçədəhan_ - ağzı qönçə kimi

kiçik və yaraşıqlı
_Qönçələ_ b - qönçə dodaqlı, qırmızı dodaqlı
_Qövl_ -söz
_Qübar -_ toz
Q _üllab_ - çəngəl
_Qüra_ b - qarğa
_Qürb -_ yaxınlıq
_Qürbət_ - yaxın olmaq
_Qüsl_ - yuyunmaq


333


L

_Laf_ - danışıq, yalan söz
_Lağər_ -arıq Laləfam - lalə üzlü
_Lahrüx_ - laləyanaq, qırmızıyanaq
_Lahrüxsar_ - lalə üzlü, qırmızı

yanaqlı
_Laləzar_ - laləlik, çəmən
_Laməkan_ - yersiz; Allah
_Layəqəl_ - idraksız, ağılsız
_Layəzal_ - zail olmayan, həmişəlik; Allah
_Leyl_ - gecə
_Leylü nəhar_ - gecə və gündüz
_Lə 'lfam_ - qırmızı rəngli
_Lə 'lgun_ - qırmızı rəngli
_Ləb_ - dodaq
_Ləbaləb_ - ağzına qədər dolu
_Ləbbeyk_ - "bəli" mənasında

işlənilir
_Ləbbəstə_ - sakit, danışmayan,

dodağı bağlı
_Ləbriz_ - daşan
_Ləəb_ - oyun
_Ləhəd_ - qəbir
_Ləhm_ - ət
_Ləhn_ - səs, nəğmə
_Ləhv_ - oyun, əyləncə
_Ləhvü ləəb_ - faydasız oyun,

əyləncə
_Ləm 'eyi-tab_ - istinin parıltısı
_Lərzan_ -titrəyən
_Ləziz_ - ləzzətli
_Liva_ - bayraq
_Lö'bət_ - oyuncaq
_Lö'lö_ - inci, mirvari
_Lövhəşəllah_ - Allah uzaq eləsin


334


M

_Ma' -_ su
_Mabeyn_ - iki şeyin arası
_Madər_ - ana
_Mah_ - ay
_Mahi_ - balıq
_Mahi-Kən 'an_ - Yusifin ləqəbidir,

Kənanın ayı deməkdir; gözəl
mə'nasında işlənir
_Mahiparə_ - ay parçası

_Mahi-taban_ - parlaq ay
_Mahliq_ a - ay üzlü
_Mahru_ - ay üzlü
_Mahtab_ - ay işığı
_Malamal_ - ağzına qədər dolu
M _aliş_ - sürtmək
_Manənd_ - oxşar, oxşatmaq
_Mar_ - ilan
_Marümur_ - ilan və qarışqa
_Matəmara_ - yas evi, dünya
_Matəməfza_ - kədəri artıran
M _atəmzədə_ - yaslı, müsibətə

düçar olan
_Mə 'bud_ - ibadət olunan
_Mə'budi-həqiqi_ - "Allah" mənasında işlanir
_Mə 'kus_ - tərsinə çevrilmiş
_Mə 'mur_ - abadan
_Məabir_ - keçid
_Məani_ - mənalar
_Məasi_ - günahlar
_Məbhut_ - heyran, şaşqın
_Məcruh_ - yaralı
_Mədəd_ - kömək
_Mədid_ - uzun, çox
_Mədyun_ - borclu


335


_Mafqud_  - yox olmuş
_Məftuh_  - açılmış
_Mahafil_  - yığıncaqlar
_Məhalik_ -ölüm yeri
_Məhar_  - cilov
_Məhbub_  - sevgili
_Məhcub_  - utanan
_Məhcur_  - ayrı düşmüş
_Məhd_  - beşik
_Mahfıl_  - görüşəcək yer, məclis
_Məhi-asimani-həşmət_  - əzəmət
göylərinin ayı
_Məhmit_  - dəvənin üstündə iki
adamlıq kəcavə
_Məhrəm_ i-raz - sirrə məhrəm
_Məxfi_  - gizli
_Məxuf_  - qorxulu, təhlükəli
_Məxzən_  - xəzinə
_Məqal_  - söz, kəlam
_Məqbər_  - qəbir
_Məqərr -_ qərar ediləcək yer.
_Məlamə_ t - məzəmmət, danlaq
_Məlcə_  - sığınacaq
_Məmat_  - ölüm
_Mənazil_  - mənzillər
_Mənzur_  - baxılan
_Mərahil_  - mərhələlər, mənzillər
_Mərdud_  - rədd olunmuş
_Mərdüm_  - insanlar; göz bəbəyi
_Mərdümək_  - bəbək
_Mərdümi -_ insanlıq
_Mərg_  - ölüm
_Mərkəb_  - minik
_Mərqəd_  - qəbir
_Məs 'ud_  - xoşbəxt
_Məsdud_  - bağlanmış, qapanmış
_Məsərrət -_ şadlıq, şənlik
_Məsnəvi_  - iki misrası qafiyələnən
nəzm
_Məsrur_  - şad
_Məstur_  - örtülü



336


_Məşrəb_ - xasiyyət; içki qabı
_Məşşat_ ə - gəlini bəzəyən qadın
_Mətlub_ - tələb olunan, istənilən
şey
_Məzaq_ - zövq
_Məzhər_ - bir şeyin zahir olduğu yer
_Məzkur_ - söylənən
_Midad_ - qələm
_Minafam_ - firazə rəngli
_Minbə 'd_ - bundan sonra
_Minqar_ - dimdik
_Mir 'at_ - güzgü
_Mişkalud_ - ətirli
_Mişkbu_ - mişk qoxulu
_Mişkfam_ - mişk rəngli, qara
_Mişkin_ - xoş qoxulu, qara rəngli
_Miyan_ - bel; orta
_Mö'təqid_ - etiqad edən, inanan
_Mö 'təmid -_ etimad edilən
_Mövt -_ ölüm
_Mur_ - qarışqa
_Murçə_ - qarışqacıq
_Mübhəm_ - anlaşılmayan, üstü
örtülü
_Mübrim_ - inad, israr edən
_Müdbir_ - talesiz
_Müdəbbir_ - tədbir tökən
_Müənbər_ - ənbərlənmiş, ətirli
_Müəttər_ - ətirli
_Müəzzəb_ - əzab və iztirab çəkən
_Müəzzəm_ - böyük
_Müfərrəhi-_ dil - ürək sevinci
_Mühib_ - qorxunc
_Mühlik_ - təhlükəli
_Müxbir olmaq_ - xəbərdar olmaq
_Müjə_ - kirpik
_Mükərrəm_ - hörmətli
_Müqbil_ - taleli
_Müqəddəm_ - irəlicədən, əvvəlcədən
_Müqəddər_ - insanın alnına yazılmış tale, qəzavü qədər
_Müqərrəb_ - yaxın


337


_Müqərrər_ - qərara alınmış
_Müqtəza_ - lazım gələn
_Mülazimət_ - birinin qulluğunda
olmaq
_Mülhəq etmək_ - çatdırmaq
_Mün 'əks_ - əksinə
_Mün 'im_ - dövlətli, varlı
_Münadi_ - carçı
_Münqad_ - tabe, itaət edən
_Müntəxəb_ - seçilmiş.
_Mürdə_ - ölmüş
_Mürəttəb_ - tərtib edilmiş
_Mürğ_ - quş
_Müsafir_ - yolçu, səfərə çıxan
_Müsafirət_ - səyahət etmək,
keçmək
_Müsahib_ - həmsöhbət
_Müsələm_ - təslim edən, doğruluğu təsdiq olunmuş
_Müsəlsəl_ - zəncir kimi sıralanmış, silsilələnmiş
_Müstəcməi_ -cümleyi-fəzail - bütün
fəzilətləri cəraləşdirən
_Müşəvvəş_ - təşvişçi
_Müştəri_ - Yupiter planeti
_Mütəəllim_ - kədərli, məhzun;
şagird
_Mütəhəyyir_ - heyrətə düşən
_Müti' -_ itaət edən
_Müzəkka_ - təmiz
_Müzəkkər_ - erkək, oğlan uşağı
_Müzəyyən_ - zinətli, bəzəkli
_Müzmər_ - gizli Müztər - çarəsiz


338


N

_Nab_ - xalis, saf; azı dişi
_Nabəca_ - yerində olmayan, münasibətsiz
_Nabəka_ r - işə yaramaz
_Nabina_ - kor
_Nadid_ ə - görünməmiş, misilsiz
_Nafə_ - göbək; ceyran göbəyindən
çıxarılan mişk
_Naf'ilə_ - faydasız, boş
_Nafir_ - nifrət edən
_Nahəmta_ - bərabəri olmayan,
əvəzsiz
_Nahəmvar_ - əyri
_Nahid_ - Zöhrə, Venera planeti
_Naxah_ - istəmədən Naxun - dırnaq
_Naim_ - yatan, yuxuda olan
_Nakam -_ məqsədinə nail olmayan
_Nakə_ s - alçaq, sayılmayan adam
_Naqə_ - dəvə
_Naqənişi_ n - dəvəyə minmiş
_Naqil_ - nağıl edən, söyləyən;
keçirən
_Nal-_ qamış qələmin içindəki incə
tel; qələm; tütək; nalə edən,
inildəyən
_Naliş_ - nalə, inildəmək
_Nam_ - ad, şöhrət
_Namehriban_ - məhəbbətsiz,
vəfasız
_Namə_ - məktub
_Naməhrəm_ - biganə, yabançı
_Namərğub -_ bəyənilməyən
_Namövzun_ - vəznsiz
_Namübarək_ - uğursuz
_Namütənahi_ - nəhayətsiz, sonsuz


339


_Namvər_ - adlı, şöhrətli
_Nanu namək_ - duz-çörək
_Napeyda_ - tapılmayan, gizli
_Napərva_ - qorxusuz
_Napüxtə_ - bişməmiş, xam
_Narəsid_ ə - yetişməmiş, kal
_Narəva_ - layiq olmayan
_Nasaz_ - uyğun olmayan
_Naseh_ - nəsihət edən
_Nasəza_ - layiq olmayan, ləyaqətsiz
_Nasiy_ ə - alın
_Nasüftə dürr_ - deşilməmiş inci
_Naşad_ - qəmli
_Natəvan_ - gücsüz, zəif
_Navək_ - ox, kirpik mənasinda
işlənir
_Navərd_ - müharibə, döyüş
_Nayab_ - tapılmayan
_Nazim_ - düzən, tərtib edən;
mənzum əsər yazan şair
_Na_ zpərvər - naz ilə böyümüş
_Neyrəng_ - sehr, əfsun, kələk
_Neyyah_ - ağı deyən, ağıçı
_Nə 'leyn_ - ayaqqabı
_Nəbərd_ - vuruş
_Nəbiz_ - xurmadan hazırlanmış
şərab
_Nəcm_ - ulduz
_Nədim_ - həmsöhbət, yoldaş
_Nəfi_ r - kəranay, fəryad
_Nəğməsaz_ - nəğmə oxuyan və
bəstələyən
_Nəhib_ - ah-nalə ilə ağlamaq
_Nəhs_ - uğursuz
_Nəxl_ - xurma ağacı; fidan
_Nəxli_ -ənidlim səmər veribdir arzu ağacım meyvə veribdir
_Nəim_ - ne'mət verən
_Nəqiz seyrəm_ - əksinə hərəkət
edənəm
_Nəng_ - ar, həya


340


_Nərm_ - yumşaq, mülayim
_Nəsab_ - nəsil
_Nəsaq_ - qanun-qayda
_Nəsimi_ -gülriz - gülləri tökən
səhər küləyi
_Nəstərən_ - ağ gül
_Nəşat_ - sevinc
_Nəşatəfza_ - şadlıq artıran
_Nəşatəngiz_ - nəşə qaldıran
_Nəuzubillah_ - Allaha sığınıram
_Nəvadir_ - nadir tapılan şeylər
_Nəvasaz_ - səslə oxuma
_Nəzdik_ - yaxın
_Nigah_ - baxış
_Niga_ r - şəkil; gözəl
_Nigun_ - alt-üst olmuş, tərsinə
dönmüş
_Nigunsar_ - başı aşağı
_Nihadə_ - qoyulmuş
_Nihal_ - təzə və yeni bitmiş ting
_Nihan_ - gizli
_Nik_ - gözəl, yaxşı
_Nikəxtər_ - xoşbəxt, xoş taleli
_Nikəndiş_ - xeyirxah
_Niknam_ - yaxşı adlı, şöhrətli
_Nilifam_ - göy rəngli
_Mim_ - yarı
_Nimruz_ - günorta
_Nisab_ - son hədd; arzu olunan
dərəcə, əsas
_Nisf-_ yarı
_Nisfi-leyl_ - gecə yarısı
_Nisyan_ - unutmaq
_Niş_ - tikan, iynə

_Nişati-baqi_ - əbədi nəşə
_Nişimən_ - oturacaq yer, məclis
_Niza_ - çəkişmək, vuruşmaq,
mübahisə
_Nizar_ - zəif, arıq
_Nöh fələk_ - doqquz qat göylər



341


_Növayin -_ yeni qayda
_Növərus_ - təzə gəlin
_Növxiz_ - yeni qalxmış, təzə
_Növm_ - yuxu
_Növmid_ - ümidsiz, naümid
_Növrəs_ - yeni yetişmiş
_Növrəsidə_ - yeniyetmə
_Növşüküftə_ - yeni açılmış
_Növzad_ - yeni doğulmuş
_Nuş etmək_ - içmək
_Nüqrə_ - gümüş
_Nüqtə_ - dərin mənalı söz
_Nüqtədan_ - zərif adam, incəlikləri başa düşən
_Nüqtəpərdaz_ - mənalı danışan

Ö

_Övci-hüsn_ - gözəlliyin zirvəsi
_Övqat_ - vaxtlar
_Övn_ - kömək
_Övraqi-lətafət_ - gözəlliyin tərifi
_Övza_ - vəziyyət

P

_Pabəstə_ - ayağı bağlı
_Pabus -_ ayaq öpən
_Pabürəhnə_ - ayağıyalın
_Pakbaz_ - sədaqətli aşiq
_Pakdamən_ - namuslu, ismətli adam
_Pakizə_ - lətif, nazik
_Pamal_ - ayaq altında qalan
_Pay_ - ayaq
_Payan_ - axır, nəhayət
_Payə_ - mərtəbə
_Payibənd_ - ayağı bağlı
P _ayidar_ - davam edən, möhkəm
_Pey_ - iz
_Peyapey_ - bir-birinin dalınca
_Peyda_ - zahir, aşkar olmaq
_Peykan_ - oxun ucundakı dəmir;


342


tikan
P _eykər_ - üz, surət, gözəl
_Peyman_ - əhd, söz
_Peymanə_ - böyük qədəh, ölçü
_Peyrov_ - arxasınca gələn
_Peyvəstə_ - arası kəsilmədən
_Pədər_ - ata
_Pəjmürdə_ - solğun, pərişan
_Pənbə_ - pambıq
_Pərdaz_ - düzəldən, tərtib edən
_Pərdənişin_ - pərdə arxasında
oturan; çadralı
_Pərxaş_ - dava, döyüş, mübahisə
_Parirüxsa_ r - pəriüzlü
_Pərivəş_ - pəri kimi
_Pərizad_ - pəri balası, gözəl
_Pərkalə_ - parça
_Pərtöv_ - işıq; nəsihət
_Pərva_ - qorxu, kömək
_Pərvaz etmək_ - uçmaq
_Pərvər_ - bəsləyən
_Pərvəriş_ - tərbiyə
_Pərvin -_ ulduz adıdır
_Pəsəndidə_ - bəyənilmiş
_Pəyam_ - xəbər
_Pəyamavər_ - xəbər gətirən
_Piç_ -qıvrım



343


_Piçidə_ - bükülmüş, sarınmış
_Piçü tab_ - iztirab, təlaş; qıvrım
_Pir_ - qoca, yaşlı
_Pirahən_ - köynək
_Pirayə_ - zinət, bəzək
_Piri-həmidətül-xəsail_ - gözəl
xasiyyətli qoca
_Piş_ - ön, qabaq
_Pust_ - dəri
_Puşidə_ - örtülü
_Püxtə_ - bişmiş
_Pünhan_ - gizli
_Pür_ - dolu
_Pürdil_ - ürəkli
_Pürəfsun_ - sehirli
_Pürsuz_ - çox yandıran

R

_Rağib_ - rəğbət edən
_Rah_ - yol; şərab
_Rahnümu_ n - yolgöstərən
_Rayic_ - rəvaclı
_Raz_ - sirr
_Razi_ -dil - ürək sirri
_Rehlət_ - köçmək, ölmək
_Rə 'd_ - göy gurultusu
_Rə 'na_ - gözəl, lətif
_Rəfiq_ - yoldaş
_Rəh_ - yol
_Rəha qıl_ - azad et
_Rəhnuma_ - yol göstərən
_Rəhrov_ - yol gedən
_Rəhzən_ - yolkəsən
_Rəxnə_ - yarıq, zərər, zədə
_Rəxşan_ - işıqlı, parlaq
_Rəxt_ - paltar
_Rəmida_ - hürkmüş, qorxmuş
_Rənc_ - zəhmət, ağrı
_Rəncidə_ - incidilmiş
_Rəncur_ - zəhmətə, əziyyətə



344


düçar olmuş
_Rəsan_ - çatdıran
_Rəsən_ - ip
_Rəsidə_ - yetişmiş, kamala çatmış
_Rəvaq_ - binanın tağı
_Rəvan_ - gedən, axan ruh
_Rəvanbəxş_ - ruhverən
_Rəviş_ - gediş, yeriş
_Rəzm_ - müharibə, dava
_Ribat_ - karvansara
_Rig_ - qum
_Riqqətəngiz_ - təsirli
_Risman_ - ip
_Riş_ - yara, saqqal
_Rişə_ - saçaq, kök
_Riştə_ - tel, bağ, əlaqə, sap
_Riyasəti-qəbail_ - qəbilələrin başçılığı
_Rizacu_ - birisinin razılığını
istəmək
_Rizvan_ - behiştin qapıçısı
_Rövşən_ - işıqlı, aydın
_Rövşənzəmi_ r - ürəyiaçıq
_Rövzən_ - baca, pəncərə
_Rubah_ - tülkü
_Ruhbəxş_ - ruh verən
_Ruhəfza_ - ruh təzələyən
_Ruz_ -gün
_Ruzə_ - oruc
_Ruzi-hesab_ - qiyamət günü
_Ruzirəsan_ - ruzi yetirən, Allah
_Ruzü şəb_ - gecə-gündüz
_Rüb_ ' - dörddə bir
_Rüba_ - çəkmək
_Rücu_ - dönmək, qayıtmaq
_Rüx_ - üz
_Rüxsar_ - yanaq

**S**

_Sabir -_ səbr edən
_Sadəzəmir_ - sadəlövh, açıq ürəkli


345


_Sağər_ - qədəh, piyalə
_Sahir_ - sehr edən
_Sal_ - il
_Salik_ - müəyyən bir məqsəd
arxasınca gedən
_Salus_ - riyakar
_Sani'_ - quran, düzəldən; Allah
_Sayə_ - kölgə
_Sayəgüstər_ - kölgəsi olan, hami
_Seyd_ - ov, şikar
_Seyl_ - sel
_Seyt_ - şöhrət
_Səbavət_ - uşaqlıq
_Səbəq_ - dərs
_Sabəqxan_ - şagird
_Səbur_ - səbirli
_Səbük_ - yüngül
_Səbükbar_ - yüngül yüklü
_Səbükxiz_ - cəld, çevik
_Sabükrəvan_ - iti yeriyən
_Səbz_ - yaşıl
_Səbzfam_ - yaşıl rəngli
_Səd_ - yüz
_Sədhəzar_ - yüz min
_Səhba_ - qırmızı şərab
_Səhmnak_ - qorxulu
_Səid_ - xoşbəxt
_Səidəxtər_ - taleli, xoşbəxt
_Səqf-_ tavan
_Səlasil_ - zəncirlər
_Səmək_ - balıq
_Səmənbu_ - yasəmən qoxulu
_Sənəm_ - büt, gözəl
_Səng_ - daş
_Səngi-xara_ - mərmər daşı, çaxmaq daşı, bərk daş
_Sənubər_ - şam ağacı
_Sər_ - baş
_Saraçeyi_ -ədəm - yoxluq sarayı
_Sərağaz_ - başlanğıc
_Sərapa_ - başdan-ayağa
_Sərçeşmə_ - çeşmə başı, bulaq


346


başı
_Sərdəfiər_ - dəftərin başında qeyd
olunan, məşhur
_Sərgərm_ - məşğul, başı qızışmış,
sərxoş
_Sərgəştə_ - avara, şaşqın, pərişan
_Sərxeyi_ - tayfa başçısı, əmir, rəis
_Sərir -_ taxt
_Sarkaş_ - baş aparan, inad, tərs
_Sənna_ - soyuq
_Sərnigun_ - başı aşağı
_Sərrafi_ -cəvahiri-rəvayət - rəvayət
cəvahirinin sərrafi
_Sərriştə_ - ip ucu
_Sərşar_ - ağzına qədər dolu
_Sərvər_ - başçı
_Sərvi-riyazi_ -möhnətü dərd - dərd
və qəm bağçasının sərvi
_Sərvqəd_ - ucaboy, uzunboy
_Sərzəniş_ - qaxınc, töhmət
_Səvad_ - ölkə; qaralıq
_Səyyad_ - ovçu
_Səyyar_ - hərəkət edən, gəzən
_Səyyarə_ - hərəkət edən ulduz,
planet
_Səzavar -_ layiq
_Sib_ - alma
_Siba'_ - yırtıcı heyvanlar



347


_Təfaxür_ - öyünmək, fəxr etmək
_Təğafül_ - özünü bilməzliyə
qoymaq
_Təğənni_ - nəğmə oxumaq
_Təğəyyür_ - başqalaşmaq, rəngini
dəyişmək, açıq
_Təğyirpəzir ola bu surət_ - bu hal
dəyişib
_Təhdid_ - qorxutmaq
_Təhəmmül_ - dözmək
_Təhəssür_ - həsrət çəkmək
_Təhəyyür_ - heyran olmaq
_Təhi_ - boş, səbəbsiz, hikmətsiz
_Təhidəs_ t - əliboş
_Təhrik_ - bir işə sövq etmək
_Təhrir etmək_ - yazmaq
_Təhsili_ -bəqayi-nəslə rağib - nəslin artırılmasını istəyən
_Təhsin_ - tərifləmək
_Təxfif_ - yüngülləşdirmək
_Təkapı_ ı - o tərəf-bu tərəfə qaçmaq
_Təkəllüm_ - danışıq
_Təqdir_ - olacaq şeyin Allah tərəfindən qabaqcadan
müəyyənləşdirilməsi; bəyənmək, qədrini bilmək
_Təqdis_ - müqəddəs hesab etmək
_Təqəddüm_ - qabağa keçmək
_Təqrib_ - təxmin
_Təqrirə gətir_ - söylə; burada
qələmə al mə'nasındadır
_Təqsim_ - bölmək
_Təlx_ - acı
_Təlxgöftar_ - cıdil, acı danışan
_Talxkam_ - övqatı təlx olmaq
_Təmərrüd_ - inad, dikbaşlıq
_Təməttö_ ' - faydalanmaq


348


_Təmhid_ - dua etmək, bir şəxsin
böyüklüyünü göstərmək
_Təmkin_ - ağırlıq, vüqar
_Tən_ - bədən
_Tənə 'üm_ - bolluq içərisində həyat keçirmək
_Tənəffiir_ - nifrət etmək, iyrənmək
_Təng_ - dar, sıxıntılı
_Tər_ - təzə
_Təranə_ - nəğmə
_Tərci_ - bir şeyi digərindən üstün tutmaq
_Tərəb_ - şənlik
_Tərəbnak_ - şad
_Tərənnümsaz_ - tərənnüm etmək
_Tərğib_ - havəsləndirmək
_Tərh etmək_ - qurmaq, plan çəkmək
_Təriq_ - yol
_Təvaif_ - tayfalar
_Təvəccöh_ - rəğbət göstərmək
_Təvəhhüm  etmək_ - qorxuya düşmək
_Təvəlla_ - dostluq
_Təzəhül_ - sarsılma
_Təzərrö'_ - yalvarmaq, xahiş ctmək
_Təzyi_ d - artırmaq
_Təzyin vermək_ - zinətləndirmək,
yaraşıq vermək
_Tifli-müzəkkəri-müzəkka_ - zəkalı
oğlan uşağı
_Tiğ_ - qılınc
_Tir_ - ox
_Tirə_ - qaranlıq
_Tiri_ -imtəhan - imtahan oxu
_Tişə_ - külüng
_Tiz_ - cəld, iti
_Tizpərvaz_ - sür'ətlə uçan
_Tizrəfta_ r - cəld hərəkət edən
_Tizröv_ - sürətlə yeriyən
_Tövcih_ - bir məzmunu başqa
ibarələrlə qələmə almaq
_Tövfi-hərəm_ - Kəbənin başına
dolanmaq
_Tuba_ - cənnət ağacı; gözəlin


349


boyu
_Tu_ l - uzunluq
_Tuşeyi-ruh_ - yol azuqəsi
_Tülu_ - günəşin, ayın çıxması
_Türab_ - torpaq
_Türfəndə_ - vaxtından əvvəl
yetişən
_Türreyi-mişkbu_ - mişk qoxulu saç
_Türrə_ - saç

U

_Ur_ - çılpaq
_Us_ - ağıl

Ü

_Übudiyyət_ - qulluq, köləlik
_Ücb_ - özünü bəyənmək, boş yerə
qürurlanmaq
_Üftadə_ - yıxılmış, düşmüş
_Üqab_ -qaraquş, qartal
_Üqubət_ - əzab, cəza
_Ümman_ - böyük dəniz, okean
_Üsrət_ - çətinlik
_Üstüxan_ - sümük
_Üstüvar_ - möhkəm, qüvvətli
_Üyub_ - eyblər
_Üzlət_ - yalqız yaşamaq
_Üzma_ - ən böyük

V
_Vabəstə_ - bir şeyə bağlı
_Vadiyi-qəm_ - qəm səhrası
_Vahib_ - bağlşlayan
_Vahid_ - tək
_Vahimə_ -qorxu
_Vaqif_ -xəbərdar
_Vala_ - yüksək, uca
_Vam_ - borc
_Vayə_ - bəhrə, qismət



350


_Vəch_ - üz; məbləğ
_Vəhdə_ t - yalnızlıq, təklik
_Vəhm_ - qorxu; tərəddüd
_Vərd_ - qızıl gül
_Vəra_ ' - pəhrizkarlıq
_Vərtə_ - uçurum, təhlükə
_Vəsatət_ - vasitəçilik etmək
_Vəsi_ - varis, vəsiyyət edilmiş
adam
_Vühuş_ - vəhşi heyvanlar; vühuşü
tiyur - vəhşi heyvanlar və
quşlar

Y

_Yaban_ - çöl, səhra
_Yaquti-əhmər_ - qırmızı yaqut
_Yar_ - yoldaş, dost; sevgili
_Yaran_ - dostlar
_Yari-can_ - sədaqətli dost
_Yari-ğar_ - mağara yoldaşı,
köməkçi
_Yarü əğyar_ - dost və düşmən
_Yaş_ - körpə mənasında işlənir
_Yaşırmaq_ - gizlətmək
_Yavər_ - köməkçi
_Yeka yek_ -bir-bir
_Yekcəhət_ - müttəfiq, bir tərəfli
_Yekdəm_ - bir zamanda, bir an
_Yekrəng_ - bir rəngli, fikrində və
özündə sabit olan adam
_Yeksan_ - bərabər
_Yeksər_ - hamısı
_Yekta_ - tək, bərabəri olmayan
_Yekzəban_ - bir dilli
_Yə 's_ - kədər, ümidsizlik
_Yəd_ - el; yədi-beyza - ağ əl
_Yəx_ - buz
_Yəzdan_ - Allah
_Yövn_ - gün



351


_Yügüş_ - çox

Z

_Zağ_ - qarğa
_Zair_ - görüşə gələn, ziyarət edən
_Zakir_ - zikr eyləyən
_Zar_ - sızıldayan, ağlar, zəif
_Zə mincə_ - rəyincə, fikrincə
_Zəban_ - dil
_Zəband_ - alov; zəbanə çəkmək

   - alovlanmaq
_Zəbti_ -nəsəqi-kəlami-mövzun  şeir qayda-qanunlarını saxlamaq
_Zəbun_ - düşgün, aciz, zəif
_Zəc_ r - əziyyət, məcburiyyət
_Zəxm_ - yara
_Zəxmda_ r - yaralı
_Zəki_ - zəkalı, cəld
_Zəlalə_ t-zəlillik
_Zəmin_ - yer
_Zəmi_ r - ürək, könül
_Zən_ - qadın
_Zər_ - qızıl
_Zər sağər_ - qızıl piyalə
_Zərafə_ t - zəriflik
_Zərəfşan_ - qızıl tökən
_Zərq_ - hiylə
_Zərrin_ - qızıla tutulmuş şey
_Zib_ - bəzək, zinət
_Ziba_ - bəzəkli, zinətli
_Zifaf_ - toy gecəsi, gərdəyə
girmək Zill-kölgə Zində - diri
_Zindədil_ - gözüaçıq, arif adam
_Zinhar_ - saqın
_Zükur_ - kişilər
_Zülal_ - saf su
_Zülfeyni_ -müsəlsəlsi girehgir - iki
zəncir kimi qıvrım hörük
_Zülmat_ - qaranlıq, əfsanəvi həyat
suyunun olduğu yer


352


**MÜNDƏRİCAT**

_Ön söz yerinə_ ………………………………………………………….4

Leyli və Məcnun………………………………………………………9

Bəngu Badə………………………………………………………...229

Söhbət ül-əsmar…………………………………………………….263

Müəmmalar………………………………………………………...277

Hədisi-ərbəin……………………………………………………….285

Şikayətnamə………………………………………………………..295

Məktublar…………………………………………………………..303

Lüğət………………………………………………………………..311


353


Buraxılışa məsul: Əziz Güləliyev


Texniki redaktor: Rövşən Ağayev


Tərtibatçı-rəssam: Nərgiz Əliyeva


Kompyuter səhifələyicisi: Rəvan Mürsəlov


Korrektor: Pərvanə Məmmdova



Yığılmağa verilmişdir 08.10.2004. Çapa imzalanmışdır 09.04.2005.



Formatı 60x90 [l] /16. Fiziki çap vərəqi 21. Ofset çap üsulu.



Tirajı 25000. Sifariş 74.



Kitab "PROMAT" mətbəəsində çap olunmuşdur.


354


