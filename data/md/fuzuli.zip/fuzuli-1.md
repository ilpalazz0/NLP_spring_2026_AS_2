1


**MƏHƏMMƏD FÜZULİ**

## **ƏSƏRLƏRİ**

ALTI CİLDDƏ

I CİLD

“ŞƏRQ-QƏRB”
BAKI–2005


2


_Bu kitab “_ _**Məhəmməd Füzuli.**_ _Əsərləri. Altı cilddə. I cild” (Bakı,_
_“Azərbaycan” nəşriyyatı, 1996) nəşri əsasında təkrar nəşrə hazırlanmışdır_

Tərtib edəni: **Həmid Araslı**

Redaktoru: **Teymur Kərimli**

**894.3611 - dc 21**
**AZE**
**Məhəmməd Füzuli. Əsərləri.** Altı cilddə. I cild. Bakı, “Şərq-Qərb”,
2005, 400 səh.

Azərbaycan-türk şerinin tacidarı Məhəmməd Füzuli Şərq xalqlarının
ədəbiyyatına qüvvətli təsir göstərən dahi bir sənətkardır. Xaqani, Nizami, Rumi,
Nəsimi, Yunus Əmrə, Nəvai kimi ölməz şairlər sırasında əzəmətlə dayanan
Füzulinin şerimizdə yeri ucalardan ucadır. Yaxın və Orta Şərq ölkələrinin heç
birində ondan sonra onun səviyyəsində şair yetişməmişdir.
Bu gün də şerin dan yerində Füzuli ahından əbədi şam yanır!.. Əsil şairlər hələ
də ilham çırağını bu ahın, bu şamın odundan yandırırlar.
Füzulinin adı da ilahi haləyə bürünən və Islamda müqəddəs sayılan imzadan
götürülübdür – Məhəmməd; hətta doğulduğu yer dünyada ən böyük ziyarət
ünvanlarından biridir – Kərbəla. Qəbri də Imam Hüseyn türbəsindədi...
Eşq beşiyində paklıqla tərbiyələnən, sözün fəlsəfi mənasında məhəbbət və
dinin, dünya miqyasında bənzərsiz bir eşq təliminin banisi – filosofu və şairi olan
Füzuli bütün dövrlərin ən böyük “aşiq”idir...
“Əsərləri”nin təqdim olunan birinci cildi XVI əsrin bütün Yaxın və Orta
Şərqində bədii ənənədə təşəkkül tapan ümumi, vahid türk dili məkanının bu böyük
müəllifinin azərbaycanca olan lirik irsini əhatə edir. Füzuli ana dilində yaratmış
olduğu bu “Divan” boyu şairliyindən yox, aşiqliyindən bəhs açır, böyük sələflərini
şairlərin deyil, aşiqlərin arasında tapır...

**ISBN 9952-418-50-4**

© “ŞƏRQ-QƏRB”, 2005

3


4


**FÜZULİ “DİVAN”ININ ƏLYAZMALARI VƏ**
**NƏŞRİ HAQQINDA**

Füzuli “Əsərləri”nin oxuculara təqdim olunan birinci cildi şairin Azərbaycan
dilində olan lirik irsini əhatə edir.
Dahi şairin çoxcəhətli zəngin yaradıcılığında lirika mühüm yer tutur. Füzuli klassik
şerin, demək olar ki, bütün növlərində əsərlər yazmış, fəlsəfi-ictimai tutumuyla yanaşı
poetik dəyəri ilə də ölməz sənət nümunələrinin müəllifi kimi tanınmışdır. Şairin
xüsusən ana dilində yaratmış olduğu “Divan” türk dili anlaşılan ölkələrdə yayılmış,
məhəbbətlə oxunaraq türk xalqlarının ədəbiyyatlarına qüvvətli təsir göstərmişdir.
Füzuli özünün qəlb aləmindən xəbər verən lirik şeirləri, xüsusilə qəzəllərində saf,
təmiz bir qəlbin incə, kövrək duyğuları, ülvi bir məhəbbətin həyəcanlarını ifadə edir,
oxucusunu bədii sözün qüdrətilə sehirləyib düşünməyə, öz mənliyini, kainatı, həyat
gözəlliklərini dərk etməyə çağrır, dostluğa, məhəbbətə səsləyir. Füzuli bütün dünyaya
aşiq nəzəri ilə baxır, məhəbbəti kainatın yaranmasının əsası sanır. Səhərin açılmasında,
günəşin doğmasında, baharın gəlişində, bülbülün naləsində bir məhəbbət duyur, bütün
bunları məhəbbət dili ilə izah edir.
Füzuli qəzəlləri həm də fəlsəfi-irfani səciyyə daşıyır. İlahi bir ənginlik duyulan bu
qəzəllərdə əhli-həqqin Tanrıya məhəbbəti də zaman-zaman öz əksini tapır. Bütövlükdə
isə ümumi ruhu ilə Füzuli şerində məhəbbət insanları bir-birinə yaxınlaşdıran, dostluq,
mehribanlıq, fədakarlıq, səmimiyyət yaradan müqəddəs bir qüvvədir. O, insana
gözəlliyi duymağ, dərk etməyi öyrədir, daxilən təmizliyə, şəxsi varlığından belə
keçməyə, qorxmazlığa sövq edir. Bu cəhət Füzuli qəzəllərində o qədər bədii, səmimi
və aydın ifadə olunmuşdur ki, xalq hikməti və xalq zəkasının qüdrəti ilə aşılanmış bu
könül nəğmələrini oxuyan və ya dinləyən hər kəs qəlbində bir saflıq, xeyirxahlıq,
həyata məhəbbət, insana və onun maddi və mənəvi gözəlliyinə hörmət duyğularının
qüvvətləndiyini hiss edir…
Təqdim olunan cild şairin elm aləminə məlum olan türkcə “Divan”ının ən qədim
nüsxəsi əsasında hazırlanıb, sonrakı “Divan”lar və nəşrlərlə müqayisə edilmişdir.
Məlumdur ki, Füzulinin öz əlyazmaları bizə gəlib çatmamışdır. Hətta şair tərtibçisi
olduğu “Divan”da belə bütün qəzəllərini toplaya bilməmişdir. Bunu şairin öz
“Divan”ına yazdığ dibaçədən aydın görmək mümkündür.
Füzuli əsərinin dibaçəsində yazdığı qəzəlləri bir “Divan” şəklinə salmaq istədiyini
qeyd etdikdən sonra, müxtəsər “Divan” tərtib etdiyini göstərir: “Naçar məhmilie’tibarimdə bu ibarə lazımdır deyü, zəmani-tüfuliyyətimdə sadir olub, mütəfərriq olan
qəzəllərdən bir müxtəsər “Divan” cəm’ etmək səlahin gördüm. Və ol vəqtdə məndən
iltimasla alanlardan iltimasla alıb surəti- cəm’i ixtisar üzrə itmamə yetirdim”.
Şairin şöhrəti, əsərlərinin əsrlər boyu sevilə-sevilə oxunması xüsusilə, qəzəllər
məcmuəsi olan “Divan”ının saysız-hesabsız adamlar tərəfindən köçürülmüş nüsxələrlə
yayılmasına səbəb olmuşdur. Odur ki, Şərq əlyazmalarının saxlandığı dünya muzey və
kitabxanalarının hamısında Füzuli əsərlərinin müxtəlif əlyazmaları vardır. Lakin
Füzulinin öz xətti ilə yazılmış əsərinə hələlik təsadüf edilməmişdir.
Füzulinin öz xətti ilə yazılmış külliyyatı XVII əsrin əvvəllərində Səfəvilərin saray
kitabxanasında varmış. Bunu Şah Abbasın (1587-1629) kitabdarı Sadıq bəy Əfşarın
(Sadiqinin) “Məcmə’ül-xəvas” əsərində verdiyi məlumata əsasən təxmin etmək olur.


5


Sadiqi Füzulidən bəhs edərkən: “Təxminən otuz bin beyt əş’arı bar kim, bu həqir
öz xətti bilə mütaliə qıldım” [1] deyir ki, bu da Füzuli əsərlərinin saray kitabxanasında
olduğunu təxmin etməyə imkan verir.
Dünya muzeylərində olan Füzuli “Divan”ları içərisində qədim tarixi olan bitkin
nüsxələr çox azdır. Füzuli əlyazmaları haqqında məlumat verən prof. Y.E.Bertels
məşhur muzeylərdə olan əlyazmalarını belə təsvir edir:
“Füzuli əsərlərinin əlyazmaları olduqca çoxdur. Demək olar hər bir böyük
kitabxanada onun əsərlərindən bir neçə nüsxə vardır. Məsələ yalnız bu əlyazmalarının
keyfiyyətindədir. Mən, demək olar ki, bütün Avropa kitabxanalarının kataloqlarını
gözdən keçirmiş və aşağıdakıları müşahidə etmişəm. Avropada şairimizin yeddi
əsərinin 41 əlyazması vardır: zahirən bu say çoxdur, lakin bunlardan 13-ü nöqsanlı və
yalnız 9-u tarixlidir; belə ki, həmin əlyazmalarından üçü XVII əsrə, biri XVIII əsrə və
ikisi XIX əsrə aiddir”.
Sonra Bertels Sankt-Peterburq Şərqşünaslıq Institutunda olan yeni Füzuli
külliyyatının təsvirini verir və hicri 997-ci (miladi 1589-90) ildə yazıldığı təsdiq olunan
bu külliyyatın dünya muzeylərində olan Füzuli əlyazmalarının ən qədimi və ən
mükəmməli olduğunu söyləyir.
Bu məlumatdan aydın olur ki, məşhur muzeylərdə saxlanılan Füzuli əlyazmaları
içərisində ən qədimi Sankt-Peterburq nüsxəsidir. Bu nüsxəni təsvir edən Bertels eyni
zamanda katibin ərəb və Azərbaycan mətnlərini farscaya nisbətən yanlış köçürdüyünü
də qeyd edir. Buna görə də elm aləminə məlum olan Füzuli “Divan”larının ən etibarlısı
hesab ediləcək bu nüsxəni də tənqidi mətn hazırlamaq üçün əsas götürmək mümkün
deyildir.
Lakin Azərbaycan Elmlər Akademiyasının Əlyazmaları İnstitutunda saxlanılan bir
Füzuli “Divan”ı elm aləminə məlum Füzuli əlyazmaları içərisində ən qədim nüsxədir.
Həmin nüsxə fonda mərhum Salman Mümtaz tərəfindən bağşlanmışdır.
2062 №-li bu əlyazması 65 vərəqdən ibarətdir; həcmi 26,2 x 15, 2 sm-dir. Hər
səhifədə 20 misra vardır. Qalın, sarımtıl kağızda yazılmışdır. Mətn zər haşiyə içərisinə
alınmışdır. Nəstəliq xəttilədir. Dibaçə və qəzəllər birbirindən ayrılır. Hər ikisi kiçik,
zərif naxışlı bəzəklə başlanır.
Çox mükəmməl olan bu nüsxə yaxşı saxlanmışdır. Lakin bir sıra səhifələrdə bəzi
yerlər çətin oxunur. Iki yerdə tarix vardır. Birinci tarix dibaçənin, ikinci tarix isə
“Divan”ın sonundadır. Dibaçənin sonundakı tarix belədir:
“Təmam şod dibaçeyi-divani-Füzuli fi yovmis-salisi şəhri məhərrəmülhəram min
şühuri sənəyi səb’i tisini tis’əmiə (tərcüməsi: Füzuli “Divan”nın dibaçəsi doqquz yüz
yetmiş yeddinci ilin məhərrəmül-həram ayının üçüncü günü tamam oldu).
Bu, katibin “Divan”ı 1569-cu il iyun ayında başladığını aydınlaşdırır. Son tarixdə
katibin adı da məlum olur: “Təmmət həzəl-kitab biövni inayəti məlikil vəhhab əla yədi
Məhmud ibni Davud-əl-Uluyəvi, əşşəhir bis-Səidi qəfərə-l-lahü və li-valideynihi və
əhsənə ileyhima və alihi fi əvaxiri rəcəbilmürəccəb, sənəti səmaninə və tis’i miə-980”
(tərcüməsi: Bu kitab Allahın mərhəmətindən rəcəbül-mürəccəb ayının axırında, doqquz
yüz səkkizinci idə Səidi ləqəbilə məşhur Mahmud ibn-Davud Ülunyəvi əli ilə qurtardı.
Allah onu və onun valideynini bağşlasın və onlara əcr versin). Bu sətirlər həm də
əlyazmasının 1572-ci ilin noyabrında bitdiyini göstərir.


1
Sadiqi. “Мəcмəül-xəvas”, səh.21. Sankt-Peterburq Şərqşünaslıq Institutunda olan
əlyazмasının fotosurəti.

6


Deməli, həmin nüsxə elm aləminə məlum olan Füzuli “Divan”larının ən qədimi
olub, şairin vəfatından 16 il sonra yazılmışdır. Lakin bu nüsxə təkcə qədimliyi ilə
deyil, öz mükəmməlliyi və düzgünlüyü ilə də dünyada ən nadir nüsxədir. Bu nüsxənin
əhəmiyyətini daha aydın təsəvvür etmək üçün onu Füzulinin çap olunmuş “Divan”ları
və foto surəti əlimizdə olan Sankt-Peterburq nüsxəsi ilə müqayisə edək.
Füzuli əsərləri İstanbul, Təbriz, Daşkənd və Misirdə dəfələrlə çap olunmuşdur. Bu
kitabların çoxu “Külliyyati-divani-Füzuli”, bəziləri “Divani-Füzuli”, “Divani-Füzuli
mə’ə Leyli və Məcnun” adları, bəzən də təkcə “Leyli və Məcnun” adı ilə nəşr
edilmişdir. Lakin biz bunların hamısını deyil, ən son və tanınmış bir nüsxəni nəzərdən
keçirəcəyik.
Bu nüsxə 1924-cü ildə M.F.Köprülüzadənin müqəddiməsi ilə çap olunmuş
“Müsəhhəhi-külliyyati-divani-Füzuli”dir. Müqayisədən əvvəl belə bir cəhəti də qeyd
etmək lazımdır ki, 1328-ci (1910-cu) ildə Çələbizadə Məhəmməd Münir Dağıstaninin
nəşr etdiyi külliyyatın mətni əsla dəyişdirilmədən bu çapda təkrar olunmuşdur. Ona
görə də çap üçün göstərəcəyimiz nöqsanlar eynilə Çələbizadə nəşrinə də aiddir. Başqa
nüsxələri isə yeri gəldikcə xatırlatmaq lazım gələcəkdir. Bizim nüsxədə olan
qəzəllərdən 30-u Sankt-Peterburq nüsxəsində, 11-I İstanbul çapında, 5-i Təbriz və 32si Daşkənd çapında yoxdur.
Göstərdiyimiz təkcə bu xüsusiyyətlər əlimizdəki nüsxənin elm aləminə məlum
Füzuli “Divan”ları içərisində mükəmməlı nüsxə olduğunu təsdiq edir.
Biz müqayisədə çap və əlyazma nüsxələrindəki təhriflərin hamısını nəzərdən
keçirə bilmərik. Bu halda Füzuli “Divan”ı boyda başqa bir əsər yarana bilərdi. Odur ki,
yalnız bir neçə əsas təhrifi göstərməklə, geniş yayılmış çap nüsxələrinin dəyərini
müəyyənləşdirib, onlar haqqında yürütdüyümüz fikri əsaslandırmağa çalışacağıq .
İstanbul nəşrindəki təhriflərin müəyyən hissəsi şairin işlətdiyi qədim Azərbaycan
sözlərini yeni sözlərlə əvəz etmək meylindən irəli gəlmişdir. Belə təhriflər bəzən
mənaya təsir etməsə də, şairin həqiqi dil ehtiyatını müəyyənləşdirməyə imkan vermir;
tarixi gerçəkliyi pozur, dil tariximiz üçün əhəmiyyətli olan xüsusiyyətlərin itirilməsinə
gətirib çıxarır. Məsələn, 140-cı səhifənin 14-cü sətrində oxuyuruq:

_Dil çəksə nola canü təni xaki-kuyinə,_
_Xarü xəs artar onda ki, quş aşiyan tutar._

Bu beytin ikinci misrasındakı “artar” kəlməsi bizim nüsxədə “iltər”dir. “Iltər”
aparar deməkdir. Bu halda beytin mənası aydın olur: ürək can və bədəni sənin kuyinə
çəkir, necə ki quş yuvasına çör-çöp aparır. Demək, qədim Azərbaycan sözü “iltər”in
“artar”la əvəz olunması beytin mənasını itirir.
Yaxud 151-ci səhifənin 11-ci sətrində oxuyuruq:

_Müqimi-kuyi-dərd eylər məni ahi-cigərsuzim,_
_Bu ahəngi-məlaləfzayə bundan xoş məqam olmaz._

İkinci misrada işlənən “xoş” kəlməsi bizim nüsxədə “yey”dir. “Yaxşı” mənasında
olan “yey” burada daha münasibdir. Yenə İstanbul nüsxəsində oxuyuruq:

_Məgər qan içmək adət eyləmişdir nərgisi-məstin,_
_Bəsi mey nuş edənlər gördüm, olmaz böylə qan sərxoş._

Beytdə misralar arasında məntiqi münasibət yoxdur. Bizim nüsxədə isə ilk misra
belədir:

7


_Məgər qan içmək ilə əsrümüş nərgislərin, vər nə,_

Burada məna aydındır. İstanbul nüsxəsində qədim Azərbaycan sözü olan “əsrük”
kəlməsi “məst” ilə əvəz olunduğu üçün beyt əsl mənasını itirmişdir.
İstanbul nüsxəsindəki təhriflərin müəyyən hissəsi mətnə şairin dilinə yabançı olan
bəzi kəlmələrin artırılmasından ibarətdir. Bu təhriflər mənaya təsir etdiyi kimi, şairin
dil xüsusiyyətlərini də pozmuşdur. Məsələn, İstanbul nüsxəsində oxuyuruq:

_Rəhm et iştə dili-dərviş çəkən ahlərə_
_Ki, gəda ahi əsər eylər olur şahlərə._

Bizim nüsxədə belədir:

_Rəhm et, ey şəh, məni-dərviş çəkən ahlərə_
_Ki, gəda ahi əsər eylər olur şahlərə._

Yenə də Füzulinin İstanbul çapında belə bir beyt vardır:

_Demə Fərhad qanın tökmüş ancaq eşq şəmşiri,_
_Bənim gör qanlu yaşım həm ki, həp ol macəradəndir._

Burada “həp” kəlməsi nəzəri cəlb edir. Füzuli, “iştə” kimi, bu kəlmənidə heç bir
yerdə işlətməmişdir. Həm də bu söz fikri yaxşı ifadə etmir. “Həm ki, həp” ifadəsi
qulağa yaxşı gəlmədiyi kimi, tarixi həqiqəti də pozmuş olur. Bizim nüsxədə isə beyt
belədir:

_Demə Fərhad qanın tökmüş ancaq eşq şəmşiri,_
_Mənim gör qanlu yaşım kim, bu həm ol macəradəndir._

Yaxud İstanbul nüsxəsində çox yerdə şairin “bilmən”, “gəlmən”, “görmən”,
“alman”, “demən” və s. ifadələri “bilməm”, “gəlməm”, “görməm”, “almam”, “deməm”
və s. şəklində yazılmışdır (məs.: 142-6; 145-13; 151-10; 154-13 və s.)
Çap nüsxələrindəki təhriflərin çoxu Füzuli şerinin bədii məntiqinin mənasını
pozur, onu anlaşılmaz bir şəklə salır.
Məsələn, İstanbul nüsxəsində oxuyuruq:

_Dili-zarimdə dərdi-eşq gün-gündən füzun olmaq_
_Yetən bidərdə tədbir ilə dərman etdigimdəndir._

Deməli, şairin ürəyində eşq dərdi onun üçün gün-gündən artır ki, o hər yetən
dərdsizə dərman edir. Aydındır ki, burada məntiqi əlaqə pozulmuşdur. Əvvəla,
dərdsizin dərmana ehtiyacı olmaz, həm də özgəsinə dərman etmək adamın öz dərdini
artırmaz.


8


Bizim nüsxədə isə beyt belədir:

_Təni-zarimdə dərdi-eşq gün-gündən füzun olmaq_
_Yetən bidərd tədbirilə dərman etdigimdəndir._

Burada məna aydındır. Dərdsiz adamların tədbirilə dərman etdiyindən şairin dərdi
daha da artır.

Yenə də İstanbul nüsxəsində oxuyuruq:

_Fəqihi-mədrəsə mə’zur tut anınla eşq etsə,_
_Yox özgə elminə inkarımız, bu elmə cahildir._

Aydındır ki, birinci misra məntiqsizdir, ikinci misra ilə də heç bir əlaqəsi yoxdur.
Bizim nüsxədə beytin ilk misrası belədir:

_Fəqihi-mədrəsə mə’zurdur inkari-eşq etsə…_

Bu zaman beytin mənası aydın olur. Fəqih eşqi inkar etsə üzürlüdür, çünki o, eşqdə
cahildir.
İstanbul nüsxəsində oxuyuruq:

_Hər tərəf əşklərimdir görünən, ya yığılıb_
_Gəldi su xəlqi sirişkim suyu nəzzarəsinə._

Burada göz yaşları ilə “su xəlqi” arasında münasibətin nədən irəli gəldiyi
aydın deyildir. Lakin Füzuli belə yazmamışdır.
Bizim nüsxədə beyt belədir:

_Hər tərəf əkslərimdir görünən, ya yığılıb_
_Gəldi su xəlqi sirişkim suyu nəzzarəsinə._

Indi məna aydındır. Şair burada bədii bir lövhə yaradır; o, o qədər göz yaşı
tökmüşdür ki, ətrafını su almışdır, odur ki, hər yana baxanda öz əksini görür, onun
şəkli suya düşür. O soruşur: ətrafımda görünən mənim əkslərimdir, ya göz
yaşımın tamaşasına yığılmış su adamlarıdır?
İstanbul nüsxələrində yazılır:

_Zahida, gör sinə çakin şö’ləsin, bizdən saqın,_
_Bir ocağız biz ki, sudandır dərü divarımız._

Burada sinə çakinin şöləsilə dərü divarın su olması arasında heç bir münasibət
yoxdur, çünki beyt təhrif olunmuşdur. Bizim nüsxədə isə belədir:

_Bir ocağız biz ki, suzandır dərü divarımız…_


9


İstanbul nüsxəsində yazılır:

_Saxlamazdım navəkin gözdən, bəlasın çəkmişəm,_
_Bəsləməzdim su verib ol nəxli-kami barsız._

Beytdə məna yoxdur. Bizim nüsxədə isə belədir:

_Saxlamazdım navəkin gözdə, bəlasın çəkməsəm,_
_Su verib ol nəxli bəslərdimmi olsa barsız?_

Beytin əsl poetik mənası da budur.
İstanbul nüsxəsində oxuyuruq:

_Bilirmi dövləti-vəslin bulan məğrur olan aşiq,_
_Vəfa rəsmin sanır düşvar, asan olduğun bilməz._

Beytdən məna çıxmır, çünki ilk misra bundan sonra gələn beytin ilk
misrası ilə qarışmışdır. Bizim nüsxədə isə belədir:

_Qılır təqsir, edüb bir lütf hər dəm könlüm almaqdan,_
_Vəfa rəsmin sanır düşvar, asan olduğun bilməz._

Burada hər şey aydındır.
Biz belə misraların sayını xeyli artıra bilərdik. Lakin göstərdiklərimiz də
kifayətdir.
Beləliklə, Füzuli “Divan”ının 1924-cü il nəşrinin nə qədər nöqsanlı olduğu
aydınlaşır. Bu nöqsanlar Daşkənd çapında da vardır. Daşkənd naşirləri Füzulinin
əsərlərini dəyişib Nəvai dilinə yaxın bir şəkildə çap etmişlər. Təbriz çaplarında isə
qələt daha çoxdur. Azərbaycan sözləri düz olsa da, son əsrin dil xüsusiyyətlərinə
uyğunlaşdırıldığından, ifadələrin bir çoxu dəyişdirilmişdir.
Sankt-Peterburq nüsxəsində də səhv çoxdur. Burada ən adi ifadələr
belə təhrif edilmişdir ki, bu da katibin Azərbaycan dilini bilməməsindən irəli
gəlir.
Bütün bunlar Azərbaycan Elmlər Akademiyasının Əlyazmalar Institutundakı
Füzuli “Divan”ının elmi əhəmiyyətini aydınlaşdırır. Odur ki, Füzuli
əsərlərinin elmi nəşrində və birinci cildin tərtibində, əsas nüsxə olaraq, həmin
əlyazmasından istifadə edilmişdir.

_**Həmid Araslı**_


10


**FÜZULİ SÖZÜNÜN SEHRİ**

Ədəbiyyat və mədəniyyət tariximizin iftixarı olan Füzuli dünya ədəbiyyatı
tarixində də böyük hadisədir. Hökm kimi səslənən bu fikri aşağıdakı danılmaz
faktlar doğruldur: hələ heç kim Şərqin üç möhtəşəm dilində (türk, fars və ərəb)
divanlar bağılayaraq Füzuli kimi mükəmməl əsərlər yarada bilməmişdir; heç
kimin qələmi mənsub olduğu dövrün ədəbi aləmindəki bütün əlvan forma və
janrların sınağına məruz qalarkən Füzuli qələmi kimi gözəl və cilalı nümunələr
yaratmamışdır; “qəlb şairi” kimi tanınan şairimiz qədər heç kim oxucu ürəyinə
hakim kəsilməmişdir; ikinci elə bir şair tapmaq çətindir ki, onun yaratdığ ədəbi
məktəb qədər sirayətedici olsun və öz davamçılarını çıxılmaz təsir dairəsində
saxlamaq iqtidarında olsun; orijinal və təkrarsız üslub sahibi olan Füzuli kimi heç
kəs ədəbi yaradıcılıq qarşısında müxtəlif dövrlərin (ictimai quruluşların) və
zamanların sınağından uğurla çıxa bilmək keyfiyyətini elmi-tarixi və mənəvi
dəyər şərti kimi irəli sürməmiş və öz yaratdığı əsərlərlə bu şərti dolğun şəkildə
doğrultmaq mümkün olduğunu sübuta yetirməmişdir: fars və ərəb dillərində də
yazmaqla və bu dillərdənbəhrələnməklə yanaşı, ədəbi dilimizi tarixən heç kəs
Füzuli kimi həmin dillərin hegemonluğundan xilas edə bilməmişdir; nəhayət, çox
az şairə müyəssər olar ki, mənəviyyatı, qəlbi və ruhu hər misrasından görünsün və
əzəli məhəbbətdən, səmimilikdən yoğrulmuş ədəbi şəxsiyyəti yaradıcılığında və
üslubunda Füzulidəki qədər bütün əzəməti və aydınlığ ilə həkk olunsun!..

*******

Füzuli təkcə Azərbaycan ədəbiyyatında deyil, bütün Şərq ədəbiyyatında
əsərləri dönə-dönə köçürülən, yaxud nəşr olunan, çox sevilən və çox oxunan ən
tanınmış sənətkarlardandır. XX yüzillikdə Türkiyədə, Azərbaycanda, eləcə də
başqa ölkələrdə Füzulinin həyat və yaradıcılığ, dili və üslubu haqqında onlarca
tədqiqat əsəri yazılmışdır. M.F.Köprülü, Ə.Qaraxan, Ə.Tərlan, H.Araslı,
Y.Bertels, Ə.Gölpınarlı, Mir Cəlal, M.Quluzadə, M.C.Cəfərov, Ə.Cəfər,
V.M.Qocatürk, H.Mazıoğılu, Ə.Dəmirçizadə, H.Mirzəzadə, Ə.Mirəhmədov,
F.Qasımzadə, M.Adilov, T.Hacıyev, A.Vəfalı, Ə.Səfərli, S.Əliyev, A.Rüstəmova,
V.Feyzullayeva və başqalarının kitabları, məqalələri bu gün də elmi dəyərini
saxlamaqdadır.
Azərbaycan ədəbi dilinin tarixindən məlumdur ki, Füzuli klassik şeir dilində
fikir ardıcıllığını qüvvətli prinsipə çevirən, onlarca qəzəl, qəsidə, qitə və
rübaisində müxtəlif motivlərin bağılanmasına incə tərzdə diqqət yetirən böyük
səkətkardır. Bununla belə, o özündən əvvəlki ədəbi irsə, Şərq poetikasının zəngin
və mürəkkəb qayda-qanunlarına sadiq qalmağ farsca divanı

11


nın müqəddiməsində özünün dediyi kimi, “əslinin səliqəsinə (yəni türk şeri
ənənələrinə) uyğun” yazmağ bacaran, sənətdə sələflərinin keçmədiyi, xələflərinin
keçə bilmədiyi aşırımlardan addayan bir üstaddır. Onun zərif üslubu
təkrarolunmazdır. Poeziyasındakı xariqüladə qüdrət və əzəməti bədii söz
qarşısında qoyduğu misilsiz tələbkarlıq doğurmuşdur.

_Şe’r zövqündən olmayan agah,_
_Əhli-nəzmi məzəmmət eyləməsin_
_Kəndi cəhlinə e’tiraf etsin,_
_Hər kəramətə sehr söyləməsin._

(Yəni: şeir zövqündən agah olmayan adam şairləri məzəmmət eyləməsin; hər
kəramətə – yeni sözə (bədii ixtiraya) sehr söyləməkdənsə, öz cahilliyini etiraf
etsin). Belə bir izahatdan sonra sanki bu kiçik qitənin məzmunu bütünlüklə
aydındır. Lakin bu dörd misradakı “cəhl”, “kəramət” və “sehr” sözlərinin əlavə
ekspressiv məna çaları oxucuya çatırmı? Yəqin ki, yox. Çünki şair həmin
misraları oxucusunun müsəlman zehniyyətli olduğuna arxayın olub söyləmişdir;
yəni düşünmüşdür ki, oxucu Quranın “Qəmər surəsindən 1-ci və 2-ci ayəni,
həmçinin Məhəmməd peyğəmbərin həyatından belə bir epizodu bilməmiş
deyildir: “Əbu Cəhl Məkkə əhalisindən bir neçə nəfəri başına yığıb, həzrət
peyğəmbərdən möcüzə göstərməyi tələb edir. Peyğəmbər adamlara ani nəzər
salıb, şəhadət barmağını bədrlənmiş aya doğru uzadır və bir an sonra ay iki yerə
bölünüb, hissələri müxtəlif mövqelərdə görünür. Peyğəmbər ətrafındakılara üç
dəfə: “Şahid olun!” deyir.
Şaşqın vəziyyətdə qalan Əbu Cəhl bu “kəramət”i qəbul etmək istəmir. “Bu,
sehrdir, şeytan əməlidir!” – deyir. Beləliklə, tarixi rəmzləri, dini-fəlsəfi anlayışları
bilməyən, beytdə bu və ya digər sözün “tövriyyəli” (mənəvi cinaslı, ikibaşlı)
olduğunu duymayan oxucuya Füzulinin əsərləri bədii məzmun sarıdan yarıbayarı
az çatır.
Füzuli sehrkar deyildi və öz ürəyinin qanı, dərin zəkası, nuru, fitri istedadı
hesabına yaratdığı sənət incilərini layiqincə, ədalətlə qiymətləndirə bilməyən,
çarəsizlikdən “sehr” adlandıran, onun özünü isə “əcaib üslublu” təbiri ilə
səciyyələndirən müasirlərindən, – adi oxuculardan tutmuş təzkirəçilərə qədər bir
çoxlarından narazı idi. Lakin qəribədir, bu günün qədirbilən oxucuları da bəzən
ona sehrkar kimi baxır, onun ucaltdığı möhtəşəm söz binasında hər bir daşın ülvi
mükəmməlliklə cilalandığını görüb heyran qalırlar.
Füzuli misra-misra, beyt-beyt böyükdür. Onun beytlərində qəfil bir şimşəyin
parıltısı, əlçatmaz zirvələrin qüdsiyyəti var. Onun beytləri xəyyamanə rübailər
kimi sənətdə həqiqi gözəlliyin, məna dolğunluğunun məhəki sayıla bilər: hər
beytin öz musiqi dili, – həmcins səslərdən, gözlənilməz qafi

12


yələrdən bəstələnmiş melodiyası, özünəməxsus obrazları, aydın fikir istiqaməti və
aforistik məzmunu varıdır! Bəzən hər şeir müstəqil və orijinal fikirlər söyləyən iki
misralıq kiçik şeirlərin, rəngarəng çalarları olan obrazların hörgüsünə, çələnginə
bənzəyir. Hər şerin zahiri və batini bir-birindən ötkün və gözəldir, – heyrətamiz
cəhət də budur!
Digər klassiklərdə olduğu kimi, Füzulidə də həm şerin əsas qayəsindən, ideya
məzmunundan təcrid edilməyən beytlərə, həm də şeirdəki ümumi məzmunla
bağılanmayan sərbəst beytlərə təsadüf edilir. Bu, orta əsrlər poetikasının ədəbi
şəkil olmaq etibarilə beytə verdiyi sərbəstlikdən, müstəqillikdən irəli gəlir.
Müxtəlif şeirlərdə şəkil və məzmunca bir-birinə oxşayan beytlərlə rastlaşırıq.
Amma onların özündə də fərqli poetik çalarlar yox deyil.
Bənzəyişi törədən səbəblər isə çoxdur: mətbuatın olmadığ şəraitdə sonrakı
dövrlərdə nüsxə fərqlərinin meydana çıxması; eyni beytin yanlış köçürülmə
nəticəsində təhriflərə uğraması, yaxud səhvən, cüzi fərqlə başqa şerə salınması,
müxtəlif şairlərin əsərlərinin qarışdırılması, oxucu yaddaşının dirçəldilməsi,
səfərbər edilməsi məqsədi ilə (poetik assosiasiya zəminində) söylənmiş fikirlərin,
məlum obrazlı ifadələrin, tərkiblərin bəzən şairin özü tərəfindən qəsdən təkrar
olunması və s.
Füzuli şerini şərhlərlə birlikdə qavramaq istərkən oxucu şairin məşhur
kəlamını bir məram kimi yadda saxlamalıdır: “Elmsiz şe’r əsası yox divar olur və
əsassız divar ğayətdə bie’tibar olur”. Beləliklə, elm şerin əsası, özülü kimi
qiymətləndirilir. Lakin burada “elm” sözünü düzgün və geniş mənada anlamaq
lazımdır. “Elmsiz şeir” ifadəsi ilə daha çox qəzəl janrından olan şeri düşünən şair
ən azı aşağıdakıları nəzərdə tutmuşdur: 1. Bədii fikir məntiqi mühakimə, tezis –
antitezis üsulu ilə ifadə edilməli. 2. Həyat həqiqəti nə qədər obrazlı şəkildə olsa
da, inandırıcı, ağlabatan tərzdə əks olunmalı. 3. Elmi (dini və dünyəvi) biliklərə,
təsbit olunmuş əqli nəticələrə istinad edilməli. 4. Xalq təfəkkürü və xəyalının
inciləri olan müdrik ifadələrə, qanadlı sözlərə, atalar sözü və zərbi-məsəllərə
əsaslanmalı. Bu şərtlərin heç olmazsa birini gözləməyən şeir “etibarsızdır”, başqa
sözlə, zəriflik və kamillikdən, imandan uzaqdır, – müxtəlif zövqlərin və idraki
ölçülərin sınağına dözmək gücündə deyildir. Füzuli isə deyilənlərin nəinki birini,
əksər hallarda hamısını qabarıq şüşədə toplanan işıq kimi öz şerində cəmləşdirə
bilir.
Füzulinin bir çox beytləri Quran ayələri, peyğəmbərin hədisləri və klassik
şeirdə geniş yayılmış sufilik anlayışlarının köməyilə izah edilə bilər. Lakin bu,
şairin hər beytinə dini-mistik don geydirməyə, yaxud hər sözündə sufizm mətləbi
axtarmağa əsas vermir. Əlbəttə, Füzulini müxtəlif yoxumda dərk və izah etmək
mümkündür; bu, təəccüblü deyil, şairin özü demişkən: “hər kimin aləmdə
miqdarıncadır tə’bində meyl...” Bununla belə, Füzuli sözündən doğan məntiqi,
real həyat eşqini sağa-sola çəkməyə ehtiyac yoxdur. Füzulini köklü


13


şəkildə qavraya bilməməkdən naəlac qalıb, subyektiv və “məqsədəuyğun”
yozmaq başqa, onun sözünə-fikrinə sadiq qalıb, fərdi dil üslubunun və
yaradıcılığının əsas meylləri və motivləri vasitəsilə elmi şərh etmək bambaşqadır!
Füzulini din şairi saymaq, sənətindəki əzəməti, dərin bədii təsiri ancaq
“mübhəm” və “zərif” dini-mövhumi anlayışlarda görmək onu başa düşməməyə
bərabərdir.
“Füzulini şərh etmək?!” Bu sözlər çox qəribə səslənir. Bu ona bənzəyir ki,
kiməsə günəş bağşlamaq istəyirsən, ancaq əliboş gedirsən: hərarəti öz qəlbində
qalır, nuru gözlərində...
Füzuli dəryadır!

***

Füzulinin Azərbaycan klassik şerini yüksək zirvəyə qaldırması orta əsrlərdə
təkcə bədii fikrimizin deyil, həm də ədəbi dilimizin böyük nailiyyəti sayılmalıdır.
Bu, ədəbi-mədəni və ictimai-fəlsəfi aspektdə o mərhələnin başlanğcıdır ki, hazırda
dilimiz çatmış və öz vəzifəsini yüksək səviyyədə yerinə yetirən üslublara
şaxələnmişdir.
Füzulinin şeir dilini və yaradıcılıq üslubunu yaxşı mənimsəyən hər kəs onda
fikrin və xəyalın əlaqəli dərinliyinə, geniş mənada, bədii məzmunun dolğunluğuna
və estetik füsunkarlığına heyran olmaya bilməz.
Füzulinin fərdi üslubunun bünövrəsində metaforik təfəkkür durur. Məcazi
düşüncə tərzi özlüyündə təzə hadisə deyildi. Bu cəhət Füzuliyə qədərki islam
Şərqinin üç dilli poeziyasının bütün ruhunu sarmışdı. Lakin onun kökü, rişələri
canlı danışıq dilində idi. Füzuli bu üsula ona görə sığınmışdı ki, onda
bitibtükənməyən işıq və enerji görürdü; yəni görürdü ki, məcazilik semantiküslubi
bir proses olmaqla həqiqəti aşkar etmək, daha gözəl təsvir və tərənnüm etmək
üçün necə geniş, görünməmiş imkanlar açır (dildəki bu xüsusiyyəti riyaziyyatda
ədəd ardıcıllığının həndəsi silsilə ilə sonsuzluğa doğru getməsi, yaxud
astrofizikada günəşin parçalanma reaksiyaları ilə müqayisə etmək olar).
Qətiyyətlə demək olar ki, bədii dilin məcazilik məsələsində Füzuli ancaq
ənənə ardınca getməmişdir. O düşünüb-aramış, nəhayət tapmışdır: yaşadığı
dövrün, feodal-ruhani quruluşunun məhdud dünyagörüşündən, qeyzli-qərəzli
münasibətindən xilas olmaq üçün məcaziliyi özü üçün təzədən kəşf etmişdir.
Füzuli “məcaz” sözünə də məcazi yanaşmış, məcazi fikirləşmək, duymaq yolu
ilə (buna hissi-intuitiv idrak yolu deyənlər də vardır) bir-birindən yeni, təravətli
ifadələrlə maddi və mənəvi aləmin həyati və parlaq obrazlarını yaratmışdır.
Əbəs deyil ki, şair məcazı “həqiqət günəşinin şöləsi, nuru” adlandırır
(“Pərtövi-ənvari-xurşidi-həqiqətdir məcaz”).
Hamı bilir ki, Füzuli gözəl istiarələr yaratmaq ustasıdır. Bəs həmin istiarələrin
təsir gücü nədədir? Istiarələr yaradıcısı kimi şair nə çün orijinal


14


və təkrarolunmaz görünür? Yəqin ki, suallara cavab verərkən formal məntiqin
sillogizmlər sxeminə uyğun olaraq bənzəyən və bənzədiləni müəyyən edib təşbeh
ünsürünün ixtisar edildiyini söyləmək kifayət deyildir. Füzuli bənzətmələri,
istiarələri ona görə mükəmməldir ki, sözün abstraktlaşdırma və ümumiləşdirmə
xarakterini maksimum dərəcədə əks etdirir.
Yığcam və ümumiləşdirilmiş idrak fəaliyyətində bənzətmə mühüm rol
oynayır. Bənzətmə müqayisə tələb edir. Müqayisə, qarşılaşdırılan tərəflərin (əşya,
hadisə, proses) əlamət və xüsusiyyətlərinin ya qismən, ya da tamamilə birindən
digərinə ötürülməsi, köçürülməsi deməkdir. Lakin bu “köçürülmə” öz-özünə baş
vermir. Müqayisə olunub bənzədilən tərəflər arasında ilkin mərhələdə mütləq
əlaqələndirici sözlər iştirak edir, tədricən həmin sözlər ixtisara düşür. Deməli,
bənzətmə əvvəlcə bütöv fikir kimi cümlə şəklində ifadə olunur, aha sonra isə
ixtisarlara uğrayaraq obraza çevrilir. Müfəssəl təşbehlərdən mükəmməl təşbehlərə
doğru inkişafın mənzərəsi bunu aydın göstərir. Məsələn, aşıq şerindən “Gözlərin
ceyrandı sənin...” misrası məlumdur. Burada “ceyran” obrazı, idrak baxımından
uğursuz olsa da (ayrılıqda gözlə ceyran arasında bənzəyiş yoxdur), lüğəvisemantik və qrammatik cəhətdən eyni model, eyni quruluş zəminində meydana
çıxmış, get-gedə bəzi sözlərin ixtisarı öz işini görmüşdür (“Sənin gözlərin ceyran
gözü kimidir...”). Elə buradaca abstraksiya doğulur, – ixtisar olunan hər dil ünsürü
konkretlikdən, müəyyənlikdən, “öz payını” aparır. Belə olmasaydı, sözlərdən
şəkilçilər yaranmazdı, bir nitq hissəsi digərinə keçməzdi, bütövlüklə sabit
qrammatik quruluş təşəkkül tapmazdı. Yazıçılar bir-birindən, hər şeydən əvvəl,
məhz bu cəhətə – ayrı-ayrı söz-obrazların abstraksiya və ümumiləşdirmə
dərəcəsinə, bədii təxəyyülün səviyyəsinə görə fərqlənirlər. Əbəs deyil ki, XX əsrin
dahi fizika alimi A.Eynşteyn üçün sənətkarlarda və onların əsərlərində bədii
təxəyyülün inkişaf səviyyəsi böyüklüyün yeganə meyarı idi.
Füzuli dünyaya filosof-rəssam gözü ilə baxır. Dünyadakı şeylərin, hadisə,
proses və münasibətlərin üzvi əlaqəsini də, onların oxşar əlamətlərini də görür.
Amma “yüz ölç, bir biç” prinsipinə sadiq qalıb, böyük həssaslıq, dəqiqlik göstərir.
Adətən, onun obrazları hər hansı əlamətə (xüsusiyyətə) yox, ən qabarıq, ən
spesifik və həlledici əlamətə, yaxud əlamətlər toplusuna istinad edir; həm də şair
bu zaman xalqın yaddaş və təsəvvürünün təcrübəsini mütləq nəzərə alır. Hiss
olunur ki, o hər hansı obrazın dildə necə iz buraxacağını, təfəkkürdə necə
rezonans verəcəyini ətraflı düşünür. Füzulinin orijinallığ da bundadır.
Füzuli obrazları əksər hallarda həyatın ictimai-fəlsəfi məna və məqsədinə,
insanın mənəviyyatına yönəlmiş olur. Ona görə də onları düzgün qavramaq
hazırlıq tələb edir.
Məsələn, “ocaq” sözünü götürək. Bu söz-obraz altında şair düşünən, mübarizə
edən, amma şirin arzularına yetməyib əzab-əziyyətə düçar olan


15


insanı nəzərdə tutarkən nə qədər düşünüb-daşınmalı idi ki, oxucular onu (onun
bədii qayəsini) düzgün anlasınlar! Axı, “insan” və “ocaq” sözləri tamam ayrı-ayrı
məfhumları əks etdirir. Demək, oxşar əlamətlər tapmaq vacibdir. Həmin məqsədlə
şair obrazı ibarəli formaya salır; “insan – yanar olacaqdır” fikrini ifadə etmək
üçün tabeli mürəkkəb cümlə qurub, “ocaq” sözünü baş cümlənin xəbəri yerində
işlədir və onu budaq cümləsindəki sözlər vasitəsilə aydın şərh edir: “Bir ocağız
biz ki, suzandır dərü divarımız”. Yəni, biz elə ocağıq ki, qapı və divarımız daim
od içindədir (insan cismən ona görə bir ocağa bənzəyir ki, məsələn, döş qəfəsinin
divarları iç üzdən qan və ya od kimi qırmızıdır; bədənin əsas qapısı ağızdırsa,
dodaqlar da od rəngini andırır).
Obraz yaradıcılığında ərəb və fars sözlərindən istifadə etmək zərurət olsa da,
türk sözləri hesabına şairin yaratdığ obrazlar o dövrün ədəbi dilində yeniliyi,
təravəti və dərinliyi ilə misilsizdir.
“Leyli və Məcnun” həzəcinin dar qəliblərinə geniş, siqlətli fikirlər
yerləşdirmək üçün sözü bədii mücərrədləşdirmə yolu ilə obraza çevirmək istedadı
Füzuliyə çox kömək etmişdir. Məsələn, Leylinin özü haqqında dediyi sözlərə
diqqət edək: “Mən bir quşam, uçdum aşiyandan...” yaxud: “Qönçə kimiyəm mənipərişan, Ağızım dutulu, içim dolu qan”. Zahirən hər şeyi Leyli özü deyir: özünü
quşa, qönçəyə bənzədir. Amma burada oxucunu öz bədii qüdrəti ilə sarsıdan
inandırıcılıqdır, bədii həqiqətlə həyat həqiqətinin dəmir yolları kimi axıradək qoşa
gəlməsidir.
Yeri gəlmişkən, obrazın obrazlarla (obrazlı sözlərlə, ifadələrlə) şərhi, yəni
tamamlanması, daha da qüvvətləndirilməsi bədii dildə Füzulinin böyük
nailiyyətidir, onun şeir dilinin “ali riyaziyyat”ıdır. Bu məsələdə Füzuli bir çox
sələflərindən və xələflərindən üstündür.
Məcaziliklə əlaqədar olaraq, Füzuli dilində mücərrədləşdirmə və
ümumiləşdirmə sistem halındadır. Həmin xüsusiyyətlər ayrı-ayrı sözlərdən
başlayıb, söz birləşmələrinə və cümlələrə (misra və beytlərə) sirayət edir. Ona
görə də bəzən ayrı-ayrı sözlərdən bəhs olunsa da, obrazın məzmununu,
obrazlılığın təbiətini misra, yaxud beyti bütünlüklə təhlil etmək nəticəsində açmaq
mümkündür. Çünki bədii təxəyyülün hərarəti bütün təsvir və ifadə vasitələrinə
eyni dərəcədə hopmuşdur.

_Xaki-rahindən məni qaldıra bilməz sayə tək,_
_Qılsa dərdun afitabın hər şüaın bir kəmənd._

Beyt bütövlükdə “vəfa”, “sədaqət” anlayışlarını obrazlı şəkildə ifadə edir. Və
ya:
_“Surətin əksin alıb, bağa girər hərdəm su,_
_Rəşkdən qan içirir bərgi-güli-rə’nayə”._


16


Füzulinin fərdi üslubunda əşya və hadisələrə poetik məna verilməsindəki
özünəməxsusluğu axıradək mənimsəməyən oxucu həmin beytin şəkil və məzmun
gözəlliyini qiymətləndirə bilməz. Çünki Füzuli, oxucudan zəngin müşahidə
qabiliyyəti, incə xəyal tələb edir. Burada da belədir. Şairin bədii mətləbi, bir növ,
“qapalı” ifadə olunmuş, onu layiqincə dərk etmək oxucunun öz ixtiyarına
buraxılmışdır. Halbuki qrammatik planda yanaşdıqda beytdə anomaliya yoxdur, –
mürəkkəb bir fikir bitmiş şəkildə və “maddi” olaraq ifadə olunmuşdur: su hər an
sənin surətinin əksini alıb bağa girir, qısqanclıqdan gözəl gül yarpağına qan içirir.
Zahirən fikir aydındır, amma səbəbiyyət əlaqəsi ilə bağılı olaraq, məntiqi nəticə –
oxucuya obrazlılıq yükünü daşıyan əsas ifadələr (“surətin əksin alıb...” və
“rəşkdən qan içirir”) aydın olmalıdır: “al yanaqlı bir gözəl tez-tez gəlib, qızılgüllər
açılmış bağın kənarındakı axar suya baxır...” Məhz bu təsəvvürə əsasən beytdəki
obrazları “doğrultmaq” olar. Belə ki, su gözəlin üzünün əksini doğrudan da “alıb”
bağa aparır. Üzün rəngi bir anlığa suyu da allaşdırır. Bir azdan sonra güllər həmin
suyu içir və guya onların ləçəkləri sudakı “allığ” özlərinə çəkib qırmızı rəngə
boyanırlar.
Şair elə bu vəziyyətdə onların rənginə məna verir: su sanki qısqanclıqdan gül
yarpağına qan içirir. Nə üçün? Çünki “alıb-apardığ əks”dən ayrılmaq istəmir.
Beləliklə, ülvi hegemonluq gözəlin üzünün əksinə məxsus olaraq qalır (Füzulidə
bu tipli obrazlara çox təsadüf edilir. Müqayisə edək:

_Ayinə sevər candan rüxsareyi-cananı,_
_Bir ğayətə yetmiş ki, ayrılsa, çıxar canı_ ”

Yəni: güzgü cananın üzünü ürəkdən sevir, nə qədər ki, onu əks etdirir, canlı
kimi görünür; həmin gözəl kənara çəkilən kimi güzgü də cansız bir əşya olur.
Misal göstərdiyimiz beytlər, şübhəsiz, “obrazlı təfəkkür”ün qüdrəti ilə
yaranmışdır. Lakin obrazlı təfəkkürün gücü özünü dildə sözün (mənaca),
təfəkkürdə məfhumun (mahiyyətcə) mücərrədləşməsi prosesində göstərir. Yəni
hər hansı söz bədii obraz pilləsinə o zaman yüksəlir ki, abstraktlaşdırma
mərhələsindən müvəffəqiyyətlə keçir.
Aristotel yazır ki, “Yalanı necə məharətlə işlətmək üsulunu başqa şairlərə ən
çox öyrədən Homerdir”. “Aldanma ki, şair sözü əlbəttə yalandır” söyləyən Füzuli
də Azərbaycan poeziyasında şairlərə bədii yalanı ən çox öyrədən sənətkardır. Ilk
baxışda dil və üslubca yekrəng və yekcins təsir bağşlayan divan ədəbiyyatında
Füzulini bütün əsrdaşlarından, sonradan onun məktəbinə daxil olan sənətkarlardan
yüksəyə qaldıran əsas təqlidedilməz cəhətlərdən biri budur. Bu mənada, şairin
yaradıcılığını layiqincə tədqiq etmiş H.Mazıoğılunun: “Füzulinin şeirlərində xəyal
cəbhəsinin zəif olduğunu görürük” fikri ilə razılaşmaq mümkün deyil.


17


Təzkirəçilər Füzulini dil və üslubuna görə daha çox Ə.Nəvai ilə müqayisə
etmişlər ki, onu Nəvaiyə yaxınlaşdırsınlar. Bu səbəbdən iki böyük sənətkarın şeir
dilindən bəzi paralel nümunələrə nəzər salmaq əhəmiyyətlidir.
Qətiyyən Füzulinin böyüklüyünü sübut etmək məqsədilə yox, hətta
nəzirələrində də orijinal olduğunu bir daha göstərmək üçün. Çünki dövrünün
görkəmli ictimai xadimi olan Nəvai həqiqətən dahi şairdir, əsl elm və sənət
cəngavəridir. Ona görə də Füzuli Nəvaini sevmişdir; onun dilində (üslubunda)
Nəvaiyə bənzərlik də vardır. Amma bu sevgi və bənzəyiş Nəvainin Nəsimiyə
sevgisindən, bənzəyişindən artıq deyildir.
Füzulinin bəzi lirik şeirləri forma etibarilə doğrudan da Nəvaini
xatırlatmaqdadır.
Füzuli də qəzəllərini Nəvai kimi əsasən yeddi beytdə qurmağ xoşlamış, onun
bir sıra rədiflərini bəyənib təkrar etmişdir: eylərəm, eyləmiş, eyləgəc, ayru, ara,
ərz, bar (var), küstax, ya rəb, könlüm, ləfz söz, təmə, tut, fəda, iməs, hənuz, ğərəz
və s. Lakin çox maraqlıdır ki, əruz vəzninin növlərinə görə Füzuli Nəvaidən
tamamilə fərqlənir. Nəvainin ən çox tətbiq etdiyi bəhr həzəc, Füzulininki isə
rəməldir...
Hər iki şairin “Sübh” rədifli qəzəlində günəş, ulduzlar və onların şüalarının
mənalandırılması ilə əlaqədar olan obrazlara diqqət edək.
“Günəş” və “ulduz” anlayışlarının obrazlı ifadəsi Nəvaidə belədir: “Qam tüni
oxim şaroridin tutaşti kukka ut Kim aninq otin kuyubtur qunbazi davvor subx”
(tərcüməsi: qəm gecəsində ahımın qığılcımından göydə od qalandı ki, onun adını
dövr edən günbəz sübh qoyubdur). Şairin dahiyanə təxəyyülü gözəl səmərəsini
vermişdir: aşiqə elə gəlir ki, göydəki ulduzlar onun ahının qığılcımlarıdır, “dövr
edən günbəz” (fələk) sübhü həmin oddan yaratmışdır.
Əlbəttə, beytin bədii təsiri güclüdür. Amma, hər halda, obrazla həyat həqiqəti
arasındakı əlaqəni elmin obyektiv gözü ilə yoxladıqda dil və məntiqcə ikinci
misradakı “adın qoyubdur günbəzi-dəvvar” ifadəsi qismən zəif və uyğunsuz
görünür. Belə ki, “günbəzi-dəvvar” istiarə kimi nəzərdə tutulmuşsa, “adını
qoyubdur... sübh” ifadəsi o qədər də cilalı deyil, mükəmməl istiarə hüququnda
bədii effekti qaldırmır (başqa sözlə, “adın qoyubdur” ifadəsi “sübh” sözünün
poetik məzmununu nasiranə izah edir). Görünür, məhz bu cəhət Füzulini təmin
etməmişdir. Onun “Divan”ında oxuyuruq:

_Batdı əncüm, çıxdı gün, ya bir əsiri-eşqdir,_
_Tökdü dürri-əşki, çəkdi ahi-atəşbar sübh?_

Bizcə, təxminən eyni fikir qrammatik və məntiqi baxımdan Füzulidə daha
aydın ifadə olunmuşdur. Eyni predmeti mənalandırmaq, eyni formada yazmaq
lazım gəldiyi halda, Nəvai təkrar olunmamışdır. Əksinə, Füzuli dilinin obrazlılığ
pillə-pillə, inandırıcı şəkildə yüksəlir; “ulduzlar batdı, gü

18


nəş çıxdı” fikri onun üslubuna xas olan şərtlərdən biri kimi paralelizmlə və
gümanlı bədii sual tərzində ifadə edilir. Yəni ulduzların yoxa çıxması qəzəl
boyunca “sadiq aşiq” kimi təsvir və tərənnüm edilən “sübh”ün yeni əlamətləri
kimi verilir: 1. Batan ulduzlardır, yoxsa eşq əsiri olan sübhün tökdüyü inci göz
yaşları?! 2. Çıxan günəşdir, yoxsa sübhün çəkdiyi ahdan toplanan atəş?! “Günəş
şüaları”nın obrazlı şəkildə mənalandırılması. Nəvaidə: “Kun şuoiy xatlari ermaski
tutmuş motamim, Yuzii anjum tirnoği birla kilib afqor subx” (Tərcüməsi:
(görünən) günəş şüasının xətləri deyildir: sübh mənə matəm tutub, ulduzların
dırnağ ilə üzünü cırmışdır). Gözəldir, obrazlar yüksək dərəcədə inkişaf etmiş
poetik abstraksiyanın məhsuludur: ulduzların iti görünən ucluqları dırnaqlara,
günəş şüaları isə (onlar sübh vaxtı qıpqırmızı olurlar!) sübhün üzündən axan qana
bənzədilir. Adama elə gəlir ki, “günəş şüaları”nı yenidən mənalandırıb orijinal
obrazlar yaratmaq imkanı tükənmişdir.
Füzulini oxuyanda isə bu qənaətdən əl çəkməli olursan; çünki o tamamilə
təzə, inandırıcı təsəvvür yaratmaq xüsusiyyətinə görə Nəvaininkindən geri
qalmayan maraqlı bir obraz yaratmışdır:

_Bir müsəvvirdir ki, zərrin kilk ilə hər gün çəkər_
_Səfheyi-gərdunə nəqşi-arizi-dildar sübh._

Yəni: Sübh elə bir rəssamdır ki, hər gün qızılı qələmlə sevgilinin üzünün
şəklini fələyin səfhəsinə (səmaya) çəkir.
Göründüyü kimi, mərkəzi anlayışlar hər iki şair tərəfindən başqa-başqa
obrazlarla ifadə edilmişdir. Nəvai beytində sübh aşiqin dərdinə şərik olan, ona
matəm tutan şəxs, Füzulidə isə rəssam kimi təqdim olunur; “şüalar” Nəvaidə qana,
Füzulidə qızılı rəngli qələmlərə bənzədilir. Hər iki şairin obrazlarında predmetlərə
böyük rəssam baxışı, rəssam zövqü, müşahidəsi ilə yanaşıldığ duyulmaqdadır.
Nəvai və Füzuli şeirlərində müqayisəyə gələn, müqayisəsi, haqqında
danışdığmız məsələ baxımından düşündürücü nəticələr doğuran xarakterik
nümunələr çoxdur. Burada dilin obrazlılıq səviyyəsini şərh etmək məqsədilə
apardığmız kiçik müqayisələr bir daha belə bir fikri əsaslandırmağa xidmət edir
ki, dil və üslubunun zənginliyi, sənətkarlığının mükəmməlliyi xüsusilə bədii
abstraksiyanın inkişaf səviyyəsi cəhətindən Füzulini kiminsə məktəbinə aid
etmək, kiminsə təsiri altına salmaq doğru deyildir.

*******

İctimai inkişafın yüksək pilləsində olan dillər mücərrəd məfhumları bildirən
sözlərlə zəngin olur. Azərbaycan dili bu cəhətdən ərəb və fars dillərindən geri
qalmır. Amma XVI əsrdə belə sözlərin əksəriyyəti hələ ədəbi


19


dilin malı olmamışdı. Əslində, Füzulinin demədiyi, lakin “türk ləfzilə ikən nəzminazik”i “düşvar” edən səbəblərdən biri bu idi. Deməli, ana dilində gözəl və mənalı
yazmaq istəyən şairin qarşısına obyektiv çətinliklər çıxmaya bilməzdi. Bu
səbəbdən də, Füzuli, obraz yaradıcılığında üç dilin materialına isnad etsə də, türk
sözünü obraz səviyyəsinə qaldırarkən öz təxəyyülünə xüsusi güc verməli
olmuşdur.
Füzuli dilində obrazlılığın xüsusiyyətlərindən bəhs edərkən belə bir cəhət
diqqəti cəlb etməlidir: konkret predmet (canlı və cansız) məfhumunu bildirən
sözlərlə digər konkret əşyaların (xüsusən, insanın) obrazı yaradılır. Yəni ocaq,
qönçə, quş, atəş, sayə, sübh və s. sözlərlə “insan” anlayışı nəzərdə tutulur.
Həmin cəhəti geniş miqyasda izlədikdə məlum olur ki, Füzuli dili mücərrəd və
konkret məfhum bildirən sözlərin obrazlılıq məqamında bir-birinə “çevrilməsi”,
bir-birinin vəzifəsini daşıması baxımından məhdudiyyət bilmir, nəinki cansız
predmetlər şəxsləndirilir, canlı əşya məfhumunu ifadə edir; hətta sırf mücərrəd
olan məfhumlar da reallaşdırılıb konkretləşdirilir, konkret əşya məfhumları ilə
əlaqələndirilir. Füzuli dilində çıxış nöqtəsi buradan başlanan saysız-hesabsız söz
birləşmələri vardır ki, onlar yuxarıdakı şərtlər zəminində meydana çıxmış və təkcə
şairin bədii ifadə yaradıcılığında deyil, bütün əsrin ədəbi dilində ulduzlar kimi
sayrışmaqdadır.
Füzulinin fərdi dil üslubunu həmin ifadələrsiz təsəvvür etmək mümkün deyil.
Çünki onlar həm ədəbi, həm də bədii cəhətdən dilin cövhəridir, keyfiyyət
nişanəsidir, dərin zəkanın, incə hissiyyatın məhsuludur; sısqa təfəkkürə
epiqonçuluğa, istedadsızlığa qarşı real “əşyayi-dəlil”dir. Bəzi faktlara müraciət
edək.
Şair “Mən səngi-məlamətəm, sən – atəş” misrasında Məcnunun atasını (həmin
sözlər onun nitqindəndir) “bəla daşı”, Məcnunu isə “od” adlandırırsa [1], biz heyran
oluruq, amma təəccüblənmirik. Ona görə ki, həmin obraz (“səngi-məlamət”)
əvvəlki nümunələrdəkiləri xatırladır; Bəlkə də xalq dilində “daş” sözünün iştirakı
ilə formalaşmış birləşmələr (elçi daşı, çaxmaqdaşı, çəki daşı və s.) beynimizdə
müəyyən assosiasiya doğurur və obrazın qavranılmasına kömək edir. Halbuki
bunu şairin işlətdiyi “rəxti-eyş” (hərfən: sevinc paltarı) tərkibi haqqında söyləmək
olmaz. Çünki bu tərkib klassik Şərq şeri fonunda o birisindən fərdi görünür,
Füzulinin təxəyyülünün nəticəsidir.
Hərfi mənada tərkibin məzmununu qavramaq çətindir: “sevinc”in də “paltar”ı
olarmı? Indi isə kontekstdə baxaq:

_Dağıdır hər ləhzə rəxti-eyşimi ahim yeli,_
_Qanğ nahəq zülmdür kim, ruzgar etməz mana_ .


1 Lakonik obrazdır, məntiqi güclüdür. Müqayisə et: dərdli ata və bədbəxt oğul yaxud
ümumiyyətlə, ata-övlad münasibəti və çaxmaq daşından törəyən od (qığılcım).


20


Yüzlərcə Füzuli beyti kimi müstəqil və kamil bir şerə bərabər olan bu beytin
təhlili göstərir ki, şairin məqsədi o təbii, adi faktı nəzərə çarpdırmaq deyil ki, yel
əsəndə paltar “dağılar”, yaxud ah çəkəndə əmələ gələn küləkdən, köksün
genişlənməsindən paltarın yaxası açılar və s. Obrazın açarı ikinci misranın
məzmununda, xüsusilə “ruzgar” sözündədir. Şair “ruzgar”ın (məcazi mənası
“dövr”, müstəqim mənası “yel”dir) insan sevincini, şənlik əhvali-ruhiyyəsini hər
anda yox etməsi ilə adi fakt arasında bənzəyiş, hətta eyniyyət görür. Aydındır ki,
kədərlənib ah çəkdikdə insanın üzünün görünüşü, şəkli tamamilə dəyişir, “sevinc
paltarı” dağılır. Beləliklə, şairin əsl mətləbi aydınlaşır.
Izafət tərkibi, yaxud təyini söz birləşmələri şəklində təşkil olunan ifadələrdə
mücərrəd isimlərin təyinlik mövqeyində çıxış etməsi az təsadüf olunan
hallardandır. Füzuliyə qədər bunun, demək olar ki, ancaq Nəsimi dilində ilk
nümunələrinə (məs.: həsrət ipi, qəm mətbəxi) rast gəlirik. Füzuli isə belə ifadələr
hesabına ədəbi dilin yaradıcılıq qüvvəsini artırdı, bədii dil üçün yeni üfüqlər açdı
və nəticə etibarilə, leksik-semantik, semantik-üslubi imkanların gələcək inkişafı
üçün tam şərait yaratdı.
Doğrudan da öz təxəyyülünə arxalanıb, konkret bir ismi mücərrəd ismin
semantik tabeliyində saxlayan şair bir-birindən təravətli ifadələr qurursa, nəinki
şeir dilinin bədii təsirini qat-qat yüksəldir, həm də praktik olaraq, sözün
(məfhumun) məna sərhədini genişləndirir. Məsələn, “ümid” sözünü götürək.
Şairin dilində (təklikdə də dönə-dönə işlənmiş) bu sözün fəallığ ilə yaranmış
ifadələrlə qarşılaşırıq: ümidim nəxli, baği-ümid, dəri-ümid, sübhiümid, ümid
gözü, gülzari-ümid.
Həmin ifadələrin yerləşdiyi kontekstləri diqqətlə nəzərdən keçirdikdə aydın
olur ki, şairin dilinin ümumi bədii-estetik səviyyəsi müqabilində “ümid” sözünü
hər yerdə təklikdə və müstəqim mənasında işlətmək məfhumun özünü
çılpaqlaşdırar, adi söz təkrarına səbəb olardı.
Buna baxmayaraq, oxucu həmişə bədii təsirə qapılmaya da bilər və həmin
birləşmələrdə sözün arxasındakı məfhumun mahiyyəti ilə də maraqlanıb soruşar: o
nədir ki, həm zaman, həm də materiya xassəsinə malikdir: həm canlıdır, həm
cansız; onun sübhü, gözü, qapısı, bağ, gülzarı vardır? Bəlkə bu, dilin və
təfəkkürün qeyri-elmi, qeyri-həyati mücərrədliyindən, məntiqsizliyindən başqa bir
şey deyildir?! Yox. Bu həmin o “yalan”dır, haqqında Aristotelin danışdığ, bədii
dildə çılpaq həqiqətdən güclü və faydalı olan rasional yalandır ki, heç də həmişə
bütün şairlərdə çatmır.
Əgər şair “ümid” sözünü hər dəfə bir obrazlı ifadə tərkibində təqdim
etməsəydi, zəngin abstraksiya əsasında onun semantik və emosional radiuslarını
böyütməsəydi, həmin anlayış oxucunun şüurunda işıqlı fikirlərin, arzuların mütləq
reallaşacağının canlı rəmzi kimi qalmazdı.
Füzuli dilində tərəfləri konkret və mücərrəd isimlərdən ibarət olan orijinal,
əlvan ifadələr çoxdur. Belə bir cəhəti qeyd etmək lazımdır ki, şair


21


məcazi obraz-ifadələr yaradıcılığında ərəb, fars və türk lüğət vahidlərinə eyni
dərəcədə etibar edir. Məsələn, tərkib hissələri alınma söz olan ifadələrdən
aşağıdakıları göstərmək olar: qəflət şərabı, lövhi-xatir, tişeyi-ah, fəzayi-eşq,
rişteyi-can, dideyi-bəxt, künci-möhnət, zülməti-heyrət, qönçeyibəxt, əcəl peyki,
ayineyi-idrak, cam gülü, tüğyani-ğəm, kitabi-ömr, gülimurad, nəxli-əməl, bərgie’tibar, vadiyi-ğürbət, fəna niqabı, bahari-ömr, şəm’i-əməl, möhnət çəməni və s.
Bir, yaxud hər iki tərkib hissəsi türk mənşəli sözlərdən ibarət olanlar: tən oxu,
dərd quşları, qəflət yuxusu, könül şəhri, dünya qapısı, ğeyrət odu, möhnət oxu,
ğəm yayı, göz evi, zövq bağ, könül mülkü, könlüm quşu, gözlər çəməni, ğeyrət
qılıncı, gün güzgüsü, dərd dənizi, həsrət əli və s.
Bu misallar belə bir fikri əyaniləşdirir ki, müxtəlif anlayışları əks etdirən
mücərrəd, yaxud konkret isimlər bir-birilə qrammatik əlaqəyə girib necə
rəngarəng ifadələrə çevrilir; eyni zamanda o da düşündürücüdür ki,
lüğəviqrammatik rabitə məhz hansı sözlər (məfhuma münasibət baxımından)
arasında əmələ gəlir: həmin mürəkkəb və incə prosesdə hər şeyi sənətkarın
intuisiyasımı həll edir, bu və ya digər uğurlu ifadənin təşəkkülü yaradıcılığın
ilhamlı anları iləmi bağılıdır, yoxsa burada da müəyyən sistem, qanunauyğunluq
vardır? Yəqin ki, vardır. Burada da gözəgörünməz söz seçimi baş verir.
Etiraf edilməlidir ki, bu tipli ifadələrin bədii dildə hər cəhətdən uğurlu çıxması
özündən əvvəlki dövrlərin mənəvi mirasına sahib olmağ, ağıl ilə hissiyyatın,
müşahidə ilə istedadın ahəngdar vəhdətini tələb edir. Füzuli bu keyfiyyətlərə
malik idi.
XVI əsr ədəbi dilində belə ifadələrin intensiv surətdə meydana çıxmasının
nəzəri və əməli əhəmiyyətini göstərən konkret miqyas tapmaq çətindir. Hər halda,
həmin ifadələr lüğət-məna sisteminin yetkinlik təzahürü idi və mahiyyətcə idrak
prosesində abstraktlaşdırma və ümumiləşdirməni təmsil etdiyi üçün perspektivli
idi: sənətdə ağılın və zövqün itiləşməsinə, dildə obrazların cilalanmasına təkan
verir, hətta elmi təfəkkürün inkişafına kömək edirdi.
Bütün bu deyilənlər göstərir ki, ədəbi dildə söz yaradıcılığına az qala biganə
qalmağ üstün tutan Füzuli ifadə yaradıcılığ sahəsində ciddi fəaliyyət göstərmiş,
Azərbaycan şeir dilinin müdrik, qanadlı və ibarəli poeziya dili pilləsinə
yüksəlməsi üçün çox böyük tarixi iş görmüşdür. Füzulinin metaforik təfəkkürü
söz ustalarının idrakına və təxəyyülünə işıq seli kimi axmış, qiymətli bəhrələr
vermişdir. Ona görə də çağıdaş ədəbi dilimizdə C.Cabbarlı və S.Vurğun kimi
nəhəng sənətkarların dilində romantik üslubla əlaqələndirilən onlarca gözəl
obrazlı ifadənin mənşəyi tarixən Nəsimidən, möhkəm və mötəbər özülü isə
Füzulinin şeir dilindən başlanır.


22


***
Bəllidir ki, Füzulinin yaradıcılığ rəngarəng bədii təsvir və ifadə vasitələri ilə
zəngindir. Şeirdə füsunkar ahəngdarlıq yaratmaq, şəkil və ya mənaca yaxın,
həmçinin əksmənalı sözlərdən məharətlə istifadə edə bilmək baxımından Füzuli
təkrarsızdır.
Dilimizdə çoxmənalı sözlər az deyil. Lakin şair həmin sözləri hazır şəkildə
alıb illüstrativ material kimi xalqa qaytarmaqla kifayətlənmir. Söz onun dilində
həqiqi və məcazi mənaları ilə qoşa qanad çalıb pərvazlanır, o qiymətli kristal daşa
bənzəyir ki, zahirən bir rəngə çalır, ancaq görmə bucağını dəyişən kimi işıq
spektrindəki yeddi rənglə alışıb-yanır. Şairin ana dilində yazdığ əsərlərdə
“yetmək” sözünün 20 mənası, “çəkmək” sözünün 40 və “tutmaq” sözünün 50-dən
artıq mənası vardır. Füzulinin qələmi sözün məna nəbzini həssaslıqla tutur. Şair,
sözün məna potensialına qızıl bir sütun kimi arxalanaraq, lüğəvi və poetik-üslubi
çalarları “benqal odu”nun qığılcımları kimi hər tərəfə səpələyir.
Füzulinin “Divan”ında “yetər”, “yetməzmi?”, “çəkər” və “tutar” rədifli
qəzəllər vardır. Həmin qəzəllərdə rədif kimi seçilən sözlər böyük fəallıq göstərir,
təkcə poetik ahəngi saxlayan “ölü qəlib” məcrasına sığşmayıb “geri qayıdır”, yeni
kontekstlər yaradılmasına xidmət edir və beləliklə, ahənrüba kimi digər sözlərin,
ifadələrin monolit birliyini yaradır. Məsələn, bir beytə nəzər salaq:

_Gün çəkər hər dəm göyə yerdən ğübari-rahini,_
_Tutiya üçün, bəli, yerdən-göyə minnət çəkər_ _[1]_ _._

İlk baxışdan birinci misradakı “çəkər” sözü, eləcə də digər sözlər öz adi
mənasındadır; lakin məhz bu sözün təzyiqi və təsirilə misra-cümlə obrazlı dərk
edilir: “günəşin ardıcıl axan işıq zərrələri gözəlin hər an göyə yerdən çəkilən ayaq
tozu kimi təqdim olunur”. Ikinci misranın əvvəlindən obraz daha da
“əsaslandırılır”: “tutiya üçün” ifadəsi “çəkər” sözünün ilk mənasını (“dartmaq”)
arxa plana keçirir, “sürtmək” anlayışını yada salır (tutiya gözə sürtülən maddədir),
oxucu bədii təfəkkürün zirvəsinə qaldırılır – “minnət çəkmək” ifadəsində sözün
mənası gözlənilmədən, lakin ustalıqla psixoloji məzmuna yönəldilir: sən demə,
günəş öz gözünə işıq vermək (gözüişıqlı olmaq) üçün hər an gözəlin keçdiyi yolun
tozunun tələbində, – həsrətindədir və tutiya kimi göyə çəkdiyi həmin tozcuqlara
görə yerdən göyə qədər minnət çəkməkdədir! Istedadlı qələm altında sözdəki
mənanın qanad açıb uçması, yerdən göyə ucalması belə olur.


1
Misal XVII əsr İstanbul əlyazma nüsxəsindən götürülmüşdür.


23


Diqqəti çəkən mühüm əlamətlərdən biri də Füzuli əsərlərində xalq ifadələrinin

- sabit söz birləşmələrinin (frazemlərin) sıxlığıdır. Qətiyyətlə demək olar ki, ədəbi
dilimizə ilk dəfə ən çox sabit söz birləşməsi gətirən və bədii dildə xalq
ifadələrindən ardıcıl, həm də yaradıcı istifadə edən, onların ekspressivlik
imkanlarını genişliyi ilə açıb göstərən, onlara söz ustalarının inamını artıran və
nəhayət, həmin kateqoriyanı öz fərdi dil üslubunun qüdrətli, çevik amilinə çevirən
yazıçı Füzulidir. Şair sabit söz birləşmələri sisteminə ümumxalq dilinin lüğət
tərkibi və qrammatik quruluşu məhvərində nitq və təfəkkür vərdişləri, sınaqları
nəticəsində formalaşan ən normal, nümunəvi təbəqə kimi baxır.
Füzuli frazeoloji vahidləri ümumxalq dilinin dərinliyindən, bünövrəsindən
ədəbi dilin zirvəsinə ucaldaraq, bu canlı təbəqənin bütün perspektivlərini açmış,
onu bədii dildə obrazlar sisteminin örnəyinə çevirmişdir. Yeri gəlmişkən, şairin
dilindəki bir çox metaforik ifadələr (ibarələr) də istər lüğəvisemantik, istərsə də
bədii-estetik qidasını frazeologiyadan almışdır.
Hiss olunur ki, Füzuli bəzi frazemləri dil vahidlərinin donuq, çılpaq və cansız
sxemi kimi almaqdan ehtiyat edir, onları statik vəziyyətdən çıxarmamağ yanlış
hesab edir və bunu xalq dilinin enerjisindən sui-istifadə etmək kimi başa düşür.
Xalq ifadələri Füzuli üçün bədii dildə əvəzsiz emosionallıq və obrazlılıq
mənbəyidir. Şair belə ifadələrin bətnində xalqın həssas müşahidəsini,
səmimiyyətini və davranışını görür.
Dilin frazeoloji ehtiyatına isnadən fikri maddi şəkildə, – söz vasitəsilə deyil,
ideal şəkildə, – dolayı olaraq (bədii məntiqlə) ifadə etmək böyük məharətdir və
Füzuli bu cəhətdən də dünya ədəbiyyatının nadir şəxsiyyətlərindəndir.
Füzulini Azərbaycan ədəbi dili tarixində klassik şeir üslubunda yazan yeganə
şair hesab etmək olar ki, ana dilinin leksik-qrammatik və üslubi sistemindəki xəlqi
istiqaməti, daxili qanunauyğunluqlarla sabitləşən cəhətləri əsas götürüb,
yaradıcılığ boyu mühafizə və inkişaf etdirmiş, ədəbi-bədii dil sahəsindəki
məramını axıradək əməli olaraq həyata keçirmişdir. Şairin belə bir yol seçməsi öz
şeir dilini ən əsas profillərdə xalq dilinə yaxınlaşdırmaqdan irəli gəlmişdir. Başqa
cür ola da bilməzdi, çünki Füzuli üçün “dilin dühası... yazıçılardan daha ağıllıdır”.

***

Yüz illər, min illər keçəcək, dünyaya gələn yeni nəsillər Füzuli şeirlərini
təkrar-təkrar oxuyub şərh edəcək, lakin şərhlər bitib-tükənmək bilməyəcək.
Şairin qədim dünyaya və gələcəyə doğru gərilmiş xəyal şəhpəri sənət
göylərində inamla süzəcək. Onun ölməz əsərləri əbədi olaraq insanlığın
xidmətindədir.


24


Nə yaxşı ki, tarixlər yaşamış bu keşməkeşli dünyaya ara-sıra Füzuli kimi
insanlar gəlir: müdrik və həssas, hər cür tamahdan, təkəbbürdən uzaq, məğrur
olduğu qədər də sadə və təvazökar, ləyaqətsiz bir mühitdə ləyaqət və şərəfini
qorumağ bacaran, tükü tükdən seçən, sözdən söz çəkən, yer üzündə ülvi sevgini,
sədaqəti, gözəlliyi və gözəllik duyğusunu, haqqı, ədaləti, azadlıq və
əməksevərliyi, səbir və təmkini, yaxşılığ, dostluq və mərdliyi, neçə-neçə bəşəri
məziyyət və fəziləti təbliğ və təlqin edən zərif ruhlu şair-insanlar!
Tarixdə Füzuli kimi şəxsiyyətlər yaşamasaydı, təbii ki, bəşəriyyət mənəvi
iflasa uğrayar, qəbahətlər dolu həyat üçün ancaq xəcalət çəkərdi.
Füzuli paklıq mücəssəməsidir, – bu gün də öz bədii sözü ilə ürəklərə
məhəbbət və xeyirxahlıq körpüsü salmaqdadır.
Füzuli sənəti xalqın dilindən və zəkasından od alıb şölə saçan, insan qəlbində
min illər boy atan ali və müqəddəs duyğuların hərarəti ilə zamanzaman daha gur
yanan bir ocaqdır. Bu ocağın odunda yanmaq səadətdir...
Füzuli “Divan”ından, – bu dərin zəka və parlaq istedad mücrüsündən hələ
oxucular çox şey öyrənəcək, çox qəlblər riqqətə və ehtizaza gələcəkdir.
Bu dirilik suyundan içən hər bir adam canlanacaq, həyatın mənası haqqında
sonsuz düşüncələrə – xəyallara dalacaq, bu dünyaya gəldiyinə sevinəcək.
Nə qədər ki, dünya və məhəbbət var, Füzuli də olacaq. Bir millətin və dilin
nəyə qadir olduğunu göstərmək üçün Füzuli kimi bir şairin varlığ kifayətdir...
Türk xalqları və türk dili durduqca Füzuli yaşayacaq.
Füzuli tarix içində mənəvi mənliyimizdir, – dilimizin, mənəviyyatımızın əbədi
və canlı heykəlidir!

**Samət Əlizadə**
1995


25


**FÜZULİ DİVANININ DİBAÇƏSİ**

Həmdi-bihədd, ol mütəkəllimi-nitqafərinə ki, səfineyi-ümmid sükkanibiharibühuri-nəzmi təməvvüci-istiğraqi - “vəşşüəraü yəttəbiühümül-ğavun” [1]
müstəğrəqi-girdabi-hirman etmişkən, silsileyi-istisnai- “illəl-ləzinə amənu” [2],
buraqub, şüərayi-islami səhihü salim sahili-nəcatə çəkmiş və sipasi-biqiyas ol
nazimi-asimanü zəminə ki, bismileyi-nəzmin əfsəri-fərqi-fürqan edib, məzrəəyiqülubi-əhli-irfanə nihali-məvəddəti-kəlami-mövzun dikmiş.

**Q i t ’ ə**

Zəhi sane’ ki, lövhi-canə gilgi-hüsni-tovfiqi,
Əzəldən iqtizayi-nəzmi-canpərvər rəğəm qılmış.
Kəmali-şe’ r kəsbi mümkin olmaz bimədəd ondan,
Ona minnət ki, təb’ i-nəzm lütf etmiş, kərəm qılmış.

**F a r s i**

Mobde’ i kəz xamaye-tovfiqe-u darəd rəqəm,
Səfheye-idraki-ərbabe-soxən nəqşe-xəyal.
Təb’ e-movzun əz əlaməthaye-lotfe-xase-ust,
Nist çun elme-digər məqdure-kəsbe-in kəmal [3] .

**Ərəbi**

Nusəbbihu mən ehdiyən-nüfusə iləl-məna
Və qəddərə əşkaləl-ümuri və həlluha.
Nuqəddisu mən lovla i’ anətə fəzlihi,
Lima əlləməl-əsmaə Adəmə külləha [4] .

Və dürudi-namə’ dud ol müxatəbi-kəlami-möciznizamə ki, fünuni-şe’ ri
məzmuni – “və ma əlləmnahuş-şe’ rə” [5] mərdudi-təbaye qılmış ikən lisani

1 Tərcüməsi: Şairlərin dalınca gedənlər yoldan azanlardır.
2 Tərcüməsi: Iman gətirənlərdən başqa.
3 Tərcüməsi: Bir yaradıcı ki, söz sahiblərinin idrak sahəsində xəyal onun tovfiq qələmilə
nəqş edilir, mövzun təb onun xüsusi lütfünün əlamətlərindəndir. Bu kəmalı başqa elmlər tək
əldə etmək olmaz.
4 Tərcüməsi: Insanları arzusuna çatdırana, çətin işləri yaradana və onları həll edənə hörmət
bəsləyirik. O kimsəni müqəddəs sayırıq ki, onun mərhəmətlə yardımı olmasaydı, Adəmə
bütün adları (sözləri) öyrətməzdi.
5 Tərcüməsi: Biz ona şairlik öyrətmədik. (Quran, surə 36, ayə 69)

26


hikmətbəyani “innə minəş-şe’ ri ləhikmətün” [1] təqriri-dilpəzirilə məqbuliqülubiəhli-hal etmiş. Və sənayi-biriya ol qafiyeyi-nəzmi-ənbiyayə ki, ədəmi-iltifatlərilə
rütbeyi-şe’r payeyi-ihanətdə qalmışkən, silsileyi-səadətintisabi-şəriflərilə filcümlə
dərəceyi-e’ tibarə yetmiş.
**Nəzm**

Ol düri-dürci-“ənə əfsəh” ki, hikmət dayəsi,
Şe’ r şəhdilə ləbi-canpərvərin tər qılmamış.
Şe’ r bir zirvədir, əmma biz kimi naqislərə,
Ol ki, kamildir, onu möhtaci-zivər qılmamış.

**F a r s i**

Əhməde-mürsəl, on ki, dər aləm
Hərçe başəd tüfeyle-xilqəte-ust,
Rütbeye-şe’ r həm əz ust bolənd,
Məhəke-covhəre-nübüvvəte-ust [2]

**Ərəbi**

Əsna əla xeyril-ənami Mühəmmədin,
Kuşifəd-duca biziyai-bədri-cəmalihi.
Bisənaihi rufiət mədaricu qədrina
Xüssət təhiyyətuna əleyhi və alihi [3]

Əmma bə’ d raqimi-təsvidati-səhayifi-üsyan, Füzuliyi-natəvan bu tərz ilə
bəyani-hal və bu nəhc ilə şərhi-mafilbal edər ki, çün zövrəqi-vücudim badbanitəbiət birlə dəryayi-qəfləti-tüfuliyyətdən sahili-idrakü ehsasə yetdi və təhrikihəvavü həvəs birlə atəşi-səbavət işti’ al bulub, hərarəti canü cananə tə’ sir etdi və
rayizi-iqtizayi-kəmali-mə’ nəvi inani-tövsəni-iqbalimi canibi-iktisabi-adabə mün’
ətif qılıb və afitabi-hikmət cövhəri-təb’ imə əsəri-təhsili-mə’ arif salıb, rəğıbətikəsbi-ədəb qıldıqda və güli-bəxtim kəsbi-hünər həvasilə açıldıqda, mə’ dənicəvahiri-iktisabi-kəmalim bir


1 Tərcüməsi: Şeirdə əlbəttə hikmət vardır.
2 Tərcüməsi: O göndərilmiş Əhməd ki, dünyada hər nə varsa onun yaranmasından
törənmişdir, şerin dərəcəsi də ondan yüksəldi və onun peyğəmbərlik incisinin məhək daşı
oldu.
3 Tərcüməsi: Insanların ən xeyirlisi olan Məhəmmədə dua edirəm. Onun gözəllik ayının işığ
ilə gecənin qaranlıq pərdəsi açıldı. Onu tərifləməklə bizim hörmət və etibar dərəcəmiz artdı.
Ona və onun övladına bizim salamımız olsun.


27


dəbistani-cənnətnişan idi ki, səhni-lətifi süfufi-ğilman ilə xüldi-bərindən xəbər
verirdi və mətale’ i-əxtəri-hüsuli-iqbalim bir məktəbi-mühəzzəb idi ki, fəzayişərifi sərvqəd sənəmlər birlə canə cinan müjdəsi yetirirdi.

**Q i t ’ ə**

Səhne-lətifo dər vey xuban neşəste səf-səf,
Didareşan mobarək həmçun süture-moshəf.
Xorşidlovh çun məh hər yek nehadə dər piş,
Bərge-ketab çun qol hər yek gerefte dər kəf. [1]

Əmma hənuz ol növrəslərə nəzakəti-təb’dən tabi-iktisabi-dəqayiqi-ülum və
taqəti-məşəqqəti-tə’limi-həqayiqi-hüdudü rüsum olmamağın məhfili-behiştasalərində həmişə əş’ari-aşiqanədən qeyri nəsnə oxunmazdı və mütali’ə etdükləri
ovraqda cigərsuz qəzəllərdən qeyri bir xətt bulunmazdı.

**Beyt**

Şe’ r bir mə’ şuqdur, hüsni-ibarət zivəri,
Canü dildən nazənin məhbublər aşiqləri.

Ol taifeyi-girami müdaviməti-sənaye’ i -əş’ ar və müvazibəti-lətaifigöftar ilə
həm hüsn halatından vüquf bulmuşlardı və həm eşq kəmalatından xəbərdar
olmuşlardı.

**Q i t ’ ə**

Ey xoş ol kim təb’ i-mövzunilə bəhsi-şe’ r edib,
Xubrulər vaqifi-məzmuni-əş’ ar olalar.
Demədən fəhm edələr keyfiyyəti-əsrari-eşq,
Aşiqi-biçarə halindən xəbərdar olalar.

Mənim ki, səhifeyi-cibillətimdə bidayəti-ruzi-əzəldən kilki-qəza
hərfiməhəbbəti-nəzm rəqəm qılmışdı və hədiqeyi-xilqətimdə bidayəti-fitrətdən
tüxmi-məvəddət və movzuniyyət əkilmişdi, ol məcməin sihabi-imtizacindən
nihali-təb’iətim nəm çəkib, izhari-əzhari-iste’dadi-nəzm etdi. Və ol məhfilin
həvayi-ixtilatindən gülbüni-cibillətim sərsəbz olub, məzrəəyi-mizacımda güliməzaqi-şe’r bitdi.


1 Tərcüməsi: Lətif bir səhn, orada gözəllər səf-səf oturmuşlar. Onların görünüşü Quran
sətirləri kimi uğurludur. Hər birisi ay kimi günəş lövhəsini qarşısına qoymuşdur, hər birisi
kitab vərəqini gül kimi əlində tutmuşdur.


28


**Q i t ’ ə**

Şahidi-nəzm sərapərdeyi-qüvvətdə ikən,
Qıldı ol bəzmi görüb, fe’ l fəzasinə xuram.
Qönçələr könlünü açmağa lətayif birlə,
Bülbülə verdi səba rüxsəti-təqriri-kəlam.

Lacərəm, əndəlibi-şeyda kimi sərməst oldum və ol güllərə qarşı tərənnüm
etməyə iste’ dadi-fitrətdən rüxsət buldum. Üfüqi-təb’ imdə hilalimövzuniyyət
tülu’ edib, ol xurşidvəşlərdən iqtibasi-nuri-şövq etməgim güngündən bir ğayətdə
mütəzaid oldu ki, az müddətdə əşi’ eyi-ənvari-nəzmimlə çox şəhərlər və vilayətlər
doldu.

**Q i t ’ ə**

Seyti-fəsahət ilə sözüm dutdu aləmi,
Mən məhdi-etibardə tifli-zəbun hənuz,
Buyi-xoşumla oldu müəttər dimağılər,
Mən nafeyi-vücuddə bir qətrə xun hənuz.

Zaman-zaman sevdayi-şe’r sair əf’alimə qalib düşüb və güruh-güruh
leylivəşlər Məcnun kimi istimai-şe’r üçün başıma üyüşüb, şairligim müqərrər
oldu. Və avazeyi-nəzmim ilə aləmlər doldu və şöhrəti-tam buldu.

**Beyt**

Təbiət şöhreyi-şəhr olmağa meyli-təmam etdi,
Nə pünhan eyləyim, sevda məni rüsvayi-am etdi.

Bu halə müqarin, məşşateyi-himmət rəva görmədi ki, müxəddəreyihüsninəzmim pirayeyi-məarifdən xali, minəssəyi-dəhrdə cilvə qıla və sərrafi-iste’ dadiülüvvi-rif’ ət riza vermədi ki, rişteyi-silki-şe’ rim cəvahirielmdən ari gərdənbəndialəm ola. Zira ki, elmsiz şe’ r əsası yox divar olur və əsassız divar qayətdə bie’
tibar olur. Payeyi-şe’ rimi hilyeyi-elmdən müərra olmağ mucibi-ihanət bilib,
elmsiz şe’ rdən qalibi-biruh kimi tənəffür qılıb, bir müddət nəqdi-həyatim sərfiiktisabi-fünuni-ülumi-əqli və nəqli və hasili-ömrüm bəzli-iqtibasi-fəvaidi-hikəmi
və həndəsi qılmağın [1] mürür ilə ləaliyi-əsnafi-hünərdən şahidi-nəzmimə pirayələr
mürəttəb qıldım və tədric ilə tətəbbü’ i-təfasir və əhadis edüb fəziləti-şe’ rə
məzəmmət isnadi-töhmət olduğunun həqiqətin bildim.


1 Qılmaqla


29


**Q i t ’ ə**

Şeir zövqindən olmayan agah
Əhli-nəzmi məzəmmət eyləməsin.
Kəndi cəhlinə etiraf etsin,
Hər kəramatə seh’r söyləməsin.

Əlqissə, əsbabi-ixtirai-fünuni-nəzm cəm’ olub müqtəzayi-zühuri-asar olduğu
zamanlarda ki, hər dəm dəsti-qüdrətim, müxtərəati-məsnuədən gərdəni-kainatə bir
həmayil asardı və hər saət səyyahi-təbiətim hədaiqi-müəlləfati-bədiədən bir
gülüstanə qədəm basardı; bir gün bir nigari-mişkinxəttə ki, daneyi-xalinə mişkiXütən demək xəta idi və zülfi rəşgindən nafeyitatarın ruzigarı qara idi, sərvi-naz
kimi xuraman-xuraman mən üftadəsinə sayeyi-mərhəmət saldı və şirin-şirin
kəlimat ilə xatirim sorub, könlüm aldı. Əsnayi-mühavirət və hiyni-müsahibətdə
dedi ki:

  - Ey şükufeyi-bustani-fəsahət və ey səbzeyi-novbəhari-hüsni-ibarət, lillahilhəmd iradeyi-tovfiqi-sübhani və məşiyyəti-tə’yidi-rəbbani məmalikifünuni-nəzmü
nəsr təsxirin sənə müyəssər etmişdir və növbəti-riyasətiəqalimi-süxən tədriclə
sənə yetmişdir. Əgərçi ərəbdə və əcəmdə və türkdə yeganə kamillər çoxdur, əmma
sən kimi cəmii-lisanə qadir, came’i-fünuninəzmü nəsr yoxdur. Hala ki, miftahizəbanin ruyi-ruzigarə əbvabi-feyz açmaqda və qəvvasi-təb’in xasü amə dəryayifəsahətdən cəvahiri-bəlağət çıxarıb saçmaqdadır. Əhaliyi-aləmdən bə’zi ləaliyimünşəat və müəmməyatindən bəhreyi-feyz almışlar və bə’zi məsnəvi və
qəsaidindən təməttö bulmuşlar və bə’zi farsi qəzəllərin nəqşi-zəmir etmişlər və
bə’zi ərəbi rəcəzlərin zövqinə yetmişlər, haşa ki, türkzadə məhbublər feyzinəzmindən bəhrəmənd olmayalar və taifeyi-ətrak sahibməzaqları bustanikəlamindən şükufeyi-divani-qəzəlin bulmayalar. Bu səbəbdən tərhi-binayi-təbiətin
qabili-qüsur ola və bu vasitədən bünyeyi-isted’ayi-kəmalin rəxnə bula.

**Q i t ’ə**

Qəzəldür səfabəxşi-əhli-nəzər,
Qəzəldür güli-bustani-hünər.
Ğəzali-qəzəl seydi asan degil,
Qəzəl münkiri əhli-irfan degil.
Qəzəl bildirir şairin qüdrətin,
Qəzəl artırır nazimin şöhrətin.
Könül, gərçi əş’arə çox rəsm var,
Qəzəl rəsmin et cümlədən ixtiyar
Ki, hər məhfilin zinətdir qəzəl,
Xirədməndlər sən’ətidir qəzəl.
Qəzəl de ki, məşhuri-dövran ola,
Oxumaq da, yazmaq da asan ola.


30


Əlhəq bu kəlimati-dilpəziri ki, ol binəzirdən eşitdim, məzmuni-kəlamin məhz
nəsihət görüb, icabi-iltimasına iqdam etdim. Əmma iqtizayi-zəman kəmaliistiğınayə rüxsət vermədi ki, sərrafi-xirəd, nəqdi-ovqatı sərfi-təsanifimö’təbərə
etməkdə ikən, bu cüzviyyatə zaye’ edə. Və şəhbazi-təbiət müəzzəm seydlər
gözədirkən, bir müxtəsər şikar ardınca gedə. Naçar məhmilie’tibarimdə bu ibarə
lazımdır deyib, zəmani-tüfuliyyətimdə sadir olub, mütəfərriq olan qəzəllərdən bir
müxtəsər divan cəm’ etmək səlahin gördüm. Və ol vəqtdə məndən iltimasla
alanlardan iltimasla alıb surəti-cəm’i ixtisar üzrə itmamə yetirdim. Ümmiddir ki,
ərbabi-fəsahət və əshabi-bəlağət müşahidə və mütaliə qıldıqda, mənşə’ və
mövlidim Iraqi-Ərəb olub, təmamiyi-ömrdə ğeyr məmləkətlərə səyahət
qılmadığmdan vaqif olduqda, bu illəti mucibisüquti-e’tibar bilməyələr. Və
məhəllü məqamimə görə, rütbeyi-iste’dadimə həqarət ilə nəzər qılmayalar. Zira
e’tibari-vətən iste’dadi-zatə tə’sir etməz və topraqda yatmaq ilə tiladən cila
getməz. Nə əhli-bilad olmaqla nadan sahibi-qəbul olur və nə biyabanlarda
durmaqla dana qəbuli-vəhşət qılır.

**Nəzm**

Əgər omrha mərdome-bədsirişt,
Bovəd həmdəme-huriyane-behişt.
Dər on məhfele-porsəfa ruzo şəb,
Zi Cibril xanəd fünune-ədəb,
Bər on e’tiqadəm ke, əncame-kar,
Nəgərdəd əzu coz bədi aşkar.
Vəgər salha govhəre-tabnak,
Fitəd xaro biqədr bər ruyi-xak,
Bər anəm ke, kəmtər neşinəd ğübar,
Ze xakəş bər ayineyi-e’tibar.
Ço əz xak xizəd, həman govhərəst,
Şəhanra bərazəndeye-əfsərəst [1] .


1 Pis təbiətli adam bütün ömrünü.
Behişt hurilərilə həmdəm olsa,
O səfalı yerdə gecə-gündüz
Cəbraildən ədəb elmi öyrənərsə,
Bu etiqaddayam ki, işin sonunda
Ondan pislikdən başqa şey aşkar olmaz.
Əgər parlaq gövhər illərcə
Qiymətsiz olub torpaq üzərinə düşərsə,
Inanıram ki, onun etibar ayinəsinə
Torpaqdan toz qonar.
Əgər torpaqdan götürülsə, yenə həmin gövhərdir
Şahların tacının zinətinə layiqdir.


31


Məasimu hüssadil-kəlami ə’zimətun,
Mə’sərətuhum məhzəz-zəlaləti fil-məla.
Təzyi’u mura’atis-sənaye’i beynəhum,
Təsəddudu minhacəl-vusili iləl-’ula [1]

Ah əz on badiyepeymaye-biyabane-həsəd,
Ke, nədarəd dele-zolmaniyəş əz irfan nur.
Çun ənakib be do beyti ke, behəm mibafəd,
Xişra dide beh əz baniye-beytül-mə’mur.
Eyb başəd həme ca mətrəhe-mədde-nəzərəş,
Gərdəd əz gərde-həsəd dideyi-insafəş kur [2] .

Xəzandır gülşəni-irfanə hasid
Ilahi, hasidi xar eylə daim.
Işidir mə’rifət əhlinə azar,
Ilahi, hasidi zar eylə daim.

Və rəhməti-eyzəd ol həlalzadeyi-pake’tiqədə kim, bu növrəs şahidlərə
müşahidə qıldıqca ə’lasının hilyeyi-təhsinlə-cəmali-kəmalinə zinət yetirə və
ədnasının şaneyi-mürüvvət birlə zülfi-xətasından iqdi-üyubin çıxarub, ayineyiqüdrətdən seyqəl ehsanilə nöqsan ğübarin götürə.


1 Tərcüməsi: Gözəl kəlama həsəd edənlərin günahı böyükdür, onların çətinliyə uğramaları
aydıncasına azğınlıqlarındandır. Onların arasında sənətkarlığa riayət etməyərək yüksəliş
yolunu bağılarlar.
2 Tərcüməsi: Vay paxıllıq çölündə gəzən və qara könlü irfandan işıqlanmayanın əlindən. O,
hörümçək tək iki beyti biri-birinə toxuduqda özünü Beytül-məmur binasını tikəndən
üstünsanır. Onun nəzəri hər yerdə nöqsan axtarır. Paxıllıq tozu onun insaf gözünü kor
etmişdir.

34


35


36


Qəd ənarəl-eşqə-lil-üşşaqi minhacəl hüda! [1]
Saliki-rahi-həqiqət eşqə eylər iqtida.

Eşqdir ol nəş’eyi-kamil kim, ondandır müdam
Meydə təşviri-hərarət, neydə tə’siri-səda.

Vadiyi-vəhdət, həqiqətdə, məqami-eşqdir
Kim, müşəxxəs olmaz ol vadidə sultandan gəda.

Eyləməz xəlvətsərayi-sirri-vəhdət məhrəmi
Aşiqi mə’şuqdən, mə’şuqi aşiqdən cüda.

Ey ki, əhli-eşqə söylərsən: məlamət tərkin et!
Söylə kim, mümkünmüdür təğyiri-təqdiri-Xuda?

Eşq kilki çəkdi xət hərfi-vücudi-aşiqə
Kim, ola sabit həq isbatında nəfyi-maəda.

Ey Füzuli, intihasız zövq buldun eşqdən,
Böylədir hər iş ki, Həqq adilə qılsan ibtida.


1 Eşq aşiqlər üçün hidayət yolunu işıqlandırdı.


37


Ya mən əhatə elmükəl-əşya’ə külləha,
1Nə ibtida sənə mütəsəvvir, nə intəha.

Kim versə can yolunda, bulur xaki-məqdəmin.
Guya ki, xaki-rahinədir nəqdi-can bəha.

Sənsən qılan məzahiri-ümmidü bim, edib
Musayı elm gənci, əsasini əjdəha.

Səndən bulubdur Əhmədi-mürsəl məqami-qürb,
Təhsini-“Ya’vü “sin” ilə təşrifi-“Ta”vü “ha”.

Yə’qubdə nişaneyi-şövqin qəmü ələm,
Yusifdə nəş’əyi-nəzərin bəhcətü bəha.

Bulmazdı, qəhrin açmasa xani-siyasətin,
“Həl min məzid” [2] löqməsinə duzəx iştəha.

Ya rəb, bəlayi-qeydə Füzuli əsirdir,
Ol bidili bu dami-küdurətdən et rəha.


1Tərcüməsi: Ey elmi bütün şeyləri əhatə edən.
2 Tərcüməsi: Yenə varmı?


38


Ya Rəb, həmişə lütfünü et rəhnüma mana,
Göstərmə ol təriqi ki, getməz sana, mana.

Qət’ eylə aşinalığm ondan ki, qeyridir,
Ancaq öz aşinalərin et aşina mana.

Bir yolda sabit et qədəmi-e’tibarimi
Kim, rəhbəri-şəriət ola müqtəda mana.

Yox məndə bir əməl sənə şayistə, ah əgər
Ə’malimə görə verə ədlin cəza mana.

Xövfi-xətadə müztəribəm, var ümid kim,
Lütfün verə bəşarəti-əfvü əta mana.

Mən bilməzəm mənə gərəgin, sən həkimsən,
Mən’ eylə, vermə, hər nə gərəkməz sana, mana.

Oldur mənə murad ki, oldur sənə murad,
Haşa ki, səndən özgə ola müddəa mana.

Həbsi-həvadə qoyma Füzulisifət əsir,
Ya Rəb, hidayət eylə təriqi-fəna mana!


39


Zəhi, zatın nihanü ol nihandan masiva peyda,
Bihari-sün’ünə əmvac peyda, qə’r napeyda.

Büləndü pəsti-aləm şahidi-feyzi-vücudundur,
Degil bihudə olmaq yox ikən ərzü səma peyda.

Kəmali-qüdrətin izhari-hikmət qılmağa etmiş
Qübari-tirədən ayineyi-gitinüma peyda.

Dəmadəm əks alır mir’ati-aləm qəhrü lütfündən,
Onunçün gəh küdurət zahir eylər, gəh səfa peyda.

Gəhi toprağə eylər hikmətin min məhliqa pünhan,
Gəhi sün’ün qılır topraqdən min məhliqa peyda.

Cahan əhlinə ta əsrari-elmin qalmaya məxfi,
Qılıbdır hikmətin küffar içində ənbiya peyda.

Nişani-şəfqətindir kim, olur izhari-həmdinçün,
Füzuli tirə təb’indən kəlami-canfəza peyda!


40


Əşrəqət min fələkil-behcəti şəmsün və biha,
Mələəl-aləmə nurən və sürurən və bəha1 [1] .

Çıxdı bir gün ki, ziyasında təmamiyyi-rüsul,
Oldu məhv öylə ki, xurşid şüaində Süha.

Oldu bazari-cahan rövnəqi bir dürri-yetim
Ki, degil iki cahan hasili ol dürrə bəha.

Rütbeyi-hikməti-me’raci-kəmalinə görə,
Hükəma firqeyi-dun, fəlsəfə cəm’i-süfəha.

Münhiyi-mə’rifəti hal dililə daim,
Qılır əhli-həqə əsrari-həqiqət inha.

Necə təqrir edəyin vəsfini bir şahin kim,
Ona vəssaf ola “Yasin”u müərrif – “Taha”.

Ey Füzuli, rəhi-şər’ini tut ol rahbərin,
Bu təriqilə zəlalətdən özün eylə rəha!


1 Tərcüməsi: Gözəllik fələyindən günəş doğıdu və onunla aləm gözəllik, şadlıq və işıqla
doldu.


41


Ey olub me’rac bürhani-ülüvvi-şan sana!
Yerə enmiş göydən istiqbal edib Fürqan sana.

Heyni-də’vayi-nübüvvət müddəi ilzaminə,
Cahil ikən el, kəmali-elm bəs bürhan sana.

Kilki-hökmün çəkdi hərfi-sairi-ədyanə xət,
Hökm isbat etdi nəfyi-sairi-ədyan sana.

Baqiyi mö’cüz nə hacət əmri-həq isbatinə,
Aləm içrə mö’cüzi-baqi yetər qur’an sana.

Vəsf Cibrili-əmin etmiş qəbuli-xidmətin,
Sirri-Həq kəşfinə ayətlə yetib fərman sana.

Sənsən ol xatəm ki, dəf’ etmiş təmami-hakimi,
Xatəmi-hökmi-risalət tapşırıb dövran sana.

Ol qədər zövqi-şəfa’ət cövhəri-zatındadır
Kim, gəlir ərzi-xəta mə’nidə bir ehsan sana.

Mahi-növdür, yoxsa sən etdikdə seyri-asiman,
Qaldırıb barmaq gətirmiş asiman iman sana.

Ya nəbi, lütfün Füzulidən kəm etmə ol zaman
Kim, olur təslim miftahi-dəri-ğüfran sana.


42


Kargər düşməz xədəngi-tə’neyi-düşmən mana,
Kəsrəti-peykanın etmişdir dəmirdən tən mana.

Eymənəm səngi-məlamətdən kim, alıb çevrəmi,
Oldu zənciri-cünun bir qəl’əyi-ahən mana.

Ondanam rüsva ki, seylabi-sirişkim çak edər,
Zəxmi-tiğin qanı geydirdikcə pirahən mana.

Dəmbədəm şəm’i-cəmalından münəvvər olmasa,
Ey gözüm nuri, gərəkməz dideyi-rövşən mana.

Hiç məskəndə qərarım yoxdurur ol zövqdən
Kim, qaçan xaki-səri-kuyin ola məskən mana.

Başda bir sərvi-sənubər vəslinin sevdası var,
Sud qılmaz bağiban, nəzzareyi-gülşən mana.

Ey Füzuli: odlara yansın büsati-səltənət!
Yeydir ondan, Həq bilir, bir guşeyi-gülxən mana.


43


Ey mələksima ki, səndən özgə heyrandır sana,
Həq bilir, insan deməz hər kim ki, insandır sana.

Verməyən canın sənə bulmaz həyati-cavidan,
Zindeyi-cavid ona derlər ki, qurbandır sana.

Aləmi pərvaneyi-şəm’i-cəmalın qıldı eşq,
Cani-aləmsən, fəda hər ləhzə min candır sana.

Aşiqə şövqünlə can vermək ikən müşkül degil,
Çün Məsihi-vəqtsən, can vermək asandır sana.

Çıxma yarım gecələr, əğyar tə’nindən saqın,
Sən məhi-övci-məlahətsən, bu nöqsandır sana.

Padşahim, zülm edib aşiq sana zalim demiş,
Xubrulardan yaman gəlməz, bu böhtandır sana.

Ey Füzuli, xubrulardan təğafüldür yaman,
Gər cəfa həm gəlsə onlardan, bir ehsandır sana.


44


Cam içrə mey ki, dairə salmış hübab ona,
Ayinədir ki, əks salır afitab ona.

Zahid sual edərsə ki, meydən nədir murad?
Bizdə səfadır, onda küdurət, – cəvab ona.

Qan-yaş töküb yanında dönər atəşin kəbab,
Mə’şuqə bənzər atəşü aşiq kəbab ona.

Eylər könüldə əşk xətin şövqünü füzun,
Oddan çıxar buxar, saçıldıqca ab ona.

Çeşmin mərizi oldu könül, lə’ldən əm et,
Rənci-xumarə düşdü, dəvadır şərab ona.

Təklifi-cənnət eyləmə kuyində könlümə,
Çün cənnət əhlidir, nə verirsən əzab ona?

Məsduddur Füzuliyə meyxanələr yolu,
Ya Rəb, hidayət eylə təriqi-səvab ona!


45


Dustum, aləm səninçin gər olur düşmən mana,
Qəm degil, zira yetərsən dust ancaq sən mana.

Eşqə saldım mən məni, pənd almayıb bir dustdən,
Hiç düşmən eyləməz onu ki, etdim mən mana.

Canü tən olduqca, məndən dərdü dağ əksik degil,
Çıxsa can, xak olsa tən, nə can gərək, nə tən mana.

Vəsl qədrin bilmədim hicran bəlasın çəkmədən,
Zülməti-hicr etdi çox mübhəm işi rövşən mana.

Dudü əxgərdir mana sərv ilə gül, ey bağiban,
Neylərəm mən gülşəni, gülşən sana, gülxən mana.

Qəmzə tiğin çəkdi ol məh, olma qafil, ey könül!
Kim, müqərrərdir bu gün ölmək sana, şivən mana.

Ey Füzuli, çıxdı can, çıxman təriqi-eşqdən,
Rəhgüzari-əhli-eşq üzrə qılın mədfən mana!


46


Kəmali-hüsn veribdir şərabi-nab sana,
Sana həlaldir, ey müğıbeçə, şərab sana.

Səni mələk görəli yazmaz oldu eşqi günah,
Vəli yazıldı bu üzdən bəsi səvab sana.

Ləbin sualına verməz cəvab üşşaqın,
Sual olursa bu səndən, nədir cəvab sana?

Cəza günündə sorulmaz xətalər eylədigin,
Yetər fəğan ilə mən verdigim əzab sana.

Məni qərarım ilə qoymaz oldun, ey gərdun,
Yeridir ahim ilə versəm inqilab sana.

Şüayi-cövhəri-tiğindən umma rəhm, ey dil,
Saqınma su verə, ey təşnə, ol sərab sana.

Füzuli, başına ol sərv sayə saldı bu gün,
Ülüvvi-rif’ət ilə yetməz afitab sana.


47


Riştədir cismim ki, dövri-çərx vermiş tab ona,
Mərdümi-çeşmim düzər hər dəm düri-sirab ona.

Sayeyi-zülfün şəbistanındadır şəm’i-rüxün,
Necə yetsin qədr ilə xurşidi-aləmtab ona?

Dürdi-mey tək ğərqeyi-xunaə gördüm könlümü,
Gör nə gəldi başına, netdi şərabi-nab ona.

Qaməti-xəm birlə bir əhli-kəramətdir qaşın,
Daş olur, əlbəttə, gər baş əgməsə mehrab ona.

Çeşmini əhli-nəzər qəsdinə tə’yin eyləyən,
Nazü qəmzəndən mühəyya eyləmiş əsbab ona.

Tərləmiş rüxsar ilə xublar açarlar könlümü,
Gör nə gülşəndir ki, atəşdən verərlər ab ona.

Silki-əhli-halə çəkmiş zahidi əşki-riya,
Mis kimi kim, sim qədrin buldurur simab ona.

Ey Füzuli, qalmamış qovğayi-Məcnundan əsər,
Qaliba, əfsaneyi-eşqin gətirmiş xab ona.


48


Eşq ətvarın müsəlləm eylədi gərdun mana,
Bunca kim, yeldi-yügürdü, yetmədi Məcnun mana.

Qıldı məndən rəf’ təklifi-nəmazi məstlik,
Qaldı bərhəq nəş’eyi-cami-meyi-gülgun mana.

Bağiban, gər meyl qılman sərvinə, mə’zur tut,
Sərvdən yeyrək gəlir ol qaməti-mövzun mana.

Dustlar, qan-yaş töküb qıldı məni rüsvayi-xəlq,
Vəh ki, düşmən çıxdı axir dideyi-pürxun mana.

Olmazam, hər qanda kim olsam, giriftar olmadan,
Bir bəladır göz, bir afətdir dili-məhzun mana.

Ey Füzuli, navəki-ahimlə aldım intiqam,
Dönə-dönə gərçi bidad etdi çərxi-dun mana.


49


Qəm diyarında əcəl peyki güzar etməz mana,
Yox sanıb varım məgər kim, e’tibar etməz mana.

Yar cövr etməz mana, əğyar tə’lim etmədən,
Billah, əğyar eyləyən ehsanı yar etməz mana.

Dağıdır hər ləhzə rəxti-eyşimi ahim yeli,
Qansı nahəq zülmdür kim, ruzigar etməz mana.

Eşq zövqilə xoşam, tərki-nəsihət qıl, rəfiq,
Mən ki, tiryakimizacəm, zəhr kar etməz mana.

Çərxdən aşurmadan yadinlə ahi-atəşin,
Qədr edib gərdun şərərdən zər nisar etməz mana.

Nəqdi-can taraci-qəmdən saxlamaq düşvardır,
Eşq ta səngi-məlamətdən həsar etməz mana.

Yadi-lə’linlə Füzuli gözləyib rahi-ədəm,
Var bir tədbiri, əmma aşikar etməz mana.


50


Canımın cövhəri ol lə’li-gühərbarə fəda,
Ömrümün hasili ol şiveyi-rəftarə fəda.

Dərd çəkmiş başım ol xali-siyəh qurbanı,
Tab görmüş tənim ol türreyi-tərrarə fəda.

Gözlərimdən saçılan qətreyi-əşkim gühəri
Ləblərindən tökülən lö’löi-şəhvarə fəda.

Çak sinəmdə olan qanlı cigər parələri
Məst çeşmində olan qəmzeyi-xunxarə fəda.

Parə-parə dili-məcruhi-pərişanimdən
Səri-kuyində olan hər itə bir parə fəda.

Canü dil qeydini çəkməkdən özüm qurtardım,
Canı cananəyə etdim, dili dildarə fəada.

Ey Füzuli, nola gər saxlar isəm canı əziz,
Vəqt ola kim, ola ol şuxi-sitəmkarə fəda.


51


Qəmdən öldüm, demədim hali-dili-zar sana,
Ey güli-tazə, rəva görmədim azar sana!

Iç meyi-nab ki, bağrından edər cümlə kəbab,
Atəşi-eşq ilə üşşaqi-cigərxar sana.

Meyi-gülgündə degil nərgisi-məstin əksi,
Qədəh olmuş, göz açıb, aşiqi-didar sana.

Arizin gül-gül edibdir meyi-gülgun tabi,
Vəh ki, bir güldən açılmış neçə gülzar sana.

Bağə seyr et bu rüxi-lə’l ilə kim, qönçəvü gül
Göstərə xuni-dilü dideyi-xunbar sana.

Der idim qamətinə sərv, vəli özgə imiş
Hərəkatü rəvişü şivəvü rəftar sana.

Əgilib tərfi-binaguşinə, dərdi-dilimi
Ya o tağın deyə, ya türreyi-dəstar sana.

Mən giriftarinəmü fitnədən olman azad,
Hiç kim olmasın, ey şux, giriftar sana.

Lə’li-nabin həvəsi bağrımı qan eylədigin,
Ah kim, qanlı yaşım qılmadı izhar sana.

Ey Füzuli, fələkin var səninlə nəzəri
Kim, qəmü möhnətini verdi nə kim var sana.


52


Qəmzəsin sevdin, könül, canın gərəkməzmi sana?
Tiğə urdun, cismi-üryanın gərəkməzmi sana?

Atəşin ahimlə eylərsən mənə təklifi-bağ,
Bağiban, gülbərgi-xəndanın gərəkməzmi sana?

Yelə vermə dağıdıb hər yan, ayaqlardan götür,
Ey pəri, zülfi-pərişanın, gərəkməzmi sana?

Ey kəmanəbru, rəqibə vermə qəmzəndən nəsib,
Ox atarsan daşə, peykanın gərəkməzmi sana?

Yandırıb canım, cahansuz etmə bərqi-ahimi,
Asiman, xurşidi-rəxşanın gərəkməzmi sana?

Küfri-zülfündən məni mən’ eyləmək layiqmidir,
Sufi, insaf ilə imanın gərəkməzmi sana?

Tutalım kim, əşk seylabinə yoxdur e’tibar,
Ey Füzuli, çeşmi-giryanın gərəkməzmi sana?


53


Gərçi, ey dil, yar üçün üz verdi yüz möhnət sana,
Zərrəcə qət’i-məhəbbət etmədin, rəhmət sana!

Saxlama nəqdi-qəmi-eşqini, ey can, zahir et
Kim, verim həbsi-bədəndən çıxmağa rüxsət sana.

Çareyi-behbudimi sordum müalicdən, dedi:
Dərd, dərdi-eşqdir, mümkün degil sihhət sana.

Tutaram yarın qiyamətdə, həbibim, damənin,
Məstsən qəflət şərabından, bu gün möhlət sana.

Eşq əhlin atəşi-hicranə eylərsən kəbab,
Dönə-dönə imtəhan etdim, budur adət sana.

Incidir naləm səni, vəh nola gər bir tiğ ilə
Çeşmi-cəlladın edə ehsan mənə, minnət sana.

Səndə dün gördüm, Füzuli, meyli-mehrabü nəmaz,
Tərki-eşq etməkmi istərsən, nədir niyyət sana?


54


Ey bivəfa ki, adət olubdur cəfa sana,
Billah, cəfadır, olma, demək bivəfa sana.

Gəh nazü gəh kirişməvü gəh işvədir işin,
Canın sevənlər olmasa yey aşina sana.

Min can olaydı kaş məni-dilşikəstədə
Ta hər birilə bir gəz olaydım fəda sana.

Eşqində mübtəlalığmı eyb edən sanır
Kim, olmaq ixtiyar ilədir mübtəla sana.

Ey dil ki, hicrə doymayıb [1], istərsən ol məhi,
Şükr et bu halə, yoxsa gələr bir bəla sana.

Ey gül, qəmində əşk rüxi-zərdim etdi al,
Bildirdi ola surəti-halım səba sana.

Düşməz çü şah qürbi, Füzuli, gədalərə,
Ol şəhdən iltifat nə nisbət mana, sana.


1 Dözməyib


55


Şəb ki, miftahi-məhi-növ ola gəncinəgüşa,
Qıla peymaneyi-gərduni cəvahirpeyma.

Gizləyib çeşmeyi-xurşid suyun kuzeyi-çərx,
Qətrə-qətrə qıla əncüm rəşəhatın peyda.

Lalərəng ola şəfəqdən fələki-minafam,
Dişrə salmış kimi əksi-meyi-gülgun mina.

Məhi-növ camini dövrə gətirə saqiyi-dəhr,
Əncümi-çərxə sala nəş’eyi-tə’siri-həva.

Mən həm ol ruhfəza rahi [1] tökəm sağərə kim,
Nəxli-himmət rəşəhatından ala nəşvü nüma.

Tutar olsam, nə əcəb, mey ətəgin dürd sifət,
Eyləyibdir necə toprağ bu iksir tila.

Cam dövrində, Füzuli, oxudum mey vəsfin:
Atəşi-xirməni-qəm, abi-həyati-hükəma.


1 Şərabı


56


Fəqr mülki təxtü, aləm tərki əfsərdir mana,
Şükr lillah, dövləti-baqi müyəssərdir mana.

Zülfü rüxsari xəyalilə nədir halın, demən [1]
Öyləyəm kim, gecəvü gündüz bərabərdir mana.

Hurü Tuba vəsfin, ey vaiz, bu gün az eylə kim,
Həmdəm ol tubaqiyamü hurpeykərdir mana.

Arədən, ey şəm’, çıx bir guşə tut, kim, bu gecə
Bəzm bir xurşidtəl’ətdən münəvvərdir mana.

Verdi badi-sübh bir xurşidtəl’ət müjdəsin,
Şəmvəş vəh, kim, bu dəm ölmək müqərrərdir mana.

Zahida, sən qıl təvəccəh guşeyi-mehrabə kim,
Qibleyi-taət xəmi-əbruyi-dilbərdir mana.

Ey Füzuli, cəm olur peyvəstə el nəzzarəmə,
Ərseyi-dəşti-cünun səhrayi-məhşərdir mana.


1 Deməyin


57


Şərbəti-lə’lin ki, derlər çeşmeyi-heyvan ona,
Ol verir can dəmbədəm üşşaqəvü mən can ona.

Oxlarından kim, tikən tək sancılıbdır hər tərəf,
Gülbünidir xəm qədim, hər qönçə bir peykan ona.

Xalü xətdir bilmən ol ayineyi-rüxsar üzə,
Ya gözümdən əks salmış mərdümü müjgan ona.

Tutma, ey qan, dəmbədəm tüğyan edib tən çakini,
Qoy bu mənzərdən dəmi nəzzarə qılsın can ona.

Bəhrə, lö’lö dişlərin vəsfin məgər, söyləy səba
Kim, qulaq tutmuş sədəf içrə düri-qəltan ona.

Saldı xəttin zövqini dil canə, qanlar uddurub,
Tifl tək kim, oxudarlar zəcr ilə Qur’an ona.

Ey Füzuli, ol sənəm əfğanına rəhm eyləməz,
Daşə bənzər bağrı, tə’sir eyləməz əfğan ona.


58


Hər zaman mənzur bir şuxi-sitəmgərdir mana,
Qanda olsam bir bəla həqdən müqəddərdir mana.

Ol xəmi-əbruyə qılsam səcdə hər saət, nola,
Qiblə ilə ol xəmi-əbru bərabərdir mana.

Qəm degil, cismimdə gər səngi-məlamət zəxmi var,
Şəhneyi-bazari-sevdayəm, bu zivərdir mana.

Gözdə xunaludə peykanın xəyalilə xoşam,
Hər biri, guya ki, bir bərgi-güli-tərdir mana.

Zəxmlərdən min ağız açdı ədayi-şükrə kim,
Hər oxun bir ne’məti-qeyri-mükərrərdir mana.

Əql irşadilə bulmaq kam mümkündür, vəli
Dami-rah ola həlqeyi-zülfi-müənbərdir mana.

Əxtəri-bəxtim vəbalin gör ki, ol məhdən gələn
Mehrlərdir özgəyə, cövrü cəfalərdir mana.

Ey Füzuli, mənzili-məqsudə yetsəm, nə əcəb,
Xidməti-piri-müğan irşadı rəhbərdir mana.


59


Mənim tək hiç kim zarü pərişan olmasın, ya Rəb!
Əsiri-dərdi-eşqü daği-hicran olmasın, ya Rəb!

Dəmadəm cövrlərdir çəkdigim birəhm bütlərdən,
Bu kafərlər əsiri bir müsəlman olmasın, ya Rəb!

Görüb əndişeyi-qətlimdə ol mahi, budur virdim
Ki, bu əndişədən ol məh pəşiman olmasın, ya Rəb!

Çıxarmaq etsələr təndən, çəkib peykanın ol sərvin
Çıxan olsun dili-məcruh, peykan olmasın, ya Rəb!

Cəfavü cövr ilə mö’tadəm, onlarsız nolur halım,
Cəfasinə hədü cövrinə payan olmasın, ya Rəb!

Demən kim, ədli yox, ya zülmü çox, hər hal ilə olsa,
Könül təxtinə ondan qeyri sultan olmasın, ya Rəb!

Füzuli buldu gənci-afiyət meyxanə küncündə,
Mübarək mülkdür, ol mülk viran olmasın, ya Rəb!


60


Ey navəki-şövqin sipəri-sineyi-əhbab,
Zülfün xəmi ərbabi-vəfa seydinə qüllab!

Mehrabdə şəkli-xəmi-əbruyi-lətifin,
Vacib bu cəhətdən qamuya səcdeyi-mehrab.

Suzim der idim şəm’ sana eyləyə rövşən,
Nəzzareyi-rüxsarına yox şəm’də həm tab.

Xurşid cəmalından ol ay saldı niqabın,
Sübh oldu, dur ey bəxt, nədir munca şəkərxab?

Dün sübh yetirdim fələkə mövci-sirişkim,
Qərq etdi fələk üzrə olan əncümü girdab.

Saqi məgər ol lə’l sözün der meyi-nabə
Kim, düşdü əyağinə, əlin öpdü meyi-nab?!

Cəm’iyyəti-əsbabə könül vermə, Füzuli
Kim, təfriqədir xatirə cəm’iyyəti-əsbab.


61


Sübh çəkmiş çərxə, çalmış daşə tiğin afitab,
Zahir etmiş ol məhi-dəllakə eyni-intisab.

Dəmbədəm təhriki-tiğindən bulur başlar səfa,
Öylə kim, su mövc urub zahir qılır hər dəm hübab.

Hər səri-muyimdə bir baş olsa muyi-sər kimi,
Kəssə varın, tiği-xunrizindən etmən ictinab.

Kəşfi-əsrari-məlamət cövhəri-tiğindədir
Kim, alır başlardakı sevda cəmalından niqab.

Qüssəsindən başımın qıl kimi incəlmiş tənim
Kim, tənimlə tiği ortasında başimdir hicab.

Tiği-çapük seyrinə ahuyi-Çin dersəm nola,
Seyr qıldıqca tökər səhrayi-Çinə mişki-nab.

Muyi-jülidəmlə tiğindən ümidim kəsməzəm,
Ey Füzuli, xali olmaz bərqi-lame’dən səhab!


62


Sübh salıb mah rüxündən niqab,
Çıx ki, təmaşayə çıxa afitab!

Rişteyi-canım yetər et bir gireh,
Salma səri-zülfi-səmənsayə tab.

Məst çıxıb, salma nəzər hər yana,
Görmə rəva kim, ola aləm xərab.

Kəsmə nəzər canibi-üşşaqdən,
Naleyi-dilsuzdan et ictinab.

Şamlər əncüm sayıram sübhədək,
Ey şəbi-hicrin mənə ruzi-hesab.

Duzəxə girməz sitəmindən yanan,
Qabili-cənnət degil əhli-əzab.

Saldı ayaqdan qəmi-aləm məni,
Ver mənə qəm dəf’inə, saqi, şərab!

Rəhm qıl üftadələrin halinə,
Hiç gərəkməzmi sənə bir səvab?

Yar sual etsə ki, halın nədir,
Xəstə Füzuli, nə verərsən cəvab?


63


Qaliba bir əhli-dil toprağidir dürdi-şərab
Kim, qılıb hörmət, binalər dutmuş üstündə hübab.

Bərqü baran sanma kim, gördükdə ahü əşkimi,
Bilməzəm nəmdir mənim, ağılar mənə, yanar səhab.

Ey soran halım, bu istiğına sualindən nə sud;
Halım eylərsən sual, əmma eşitməzsən cəvab.

Dəşti-qəmdə xaki-qəbrim üzrə sərvi-girdbad
Çəksə baş, ol sərvdən su kəsmə, ey seyli-sərab.

Yetməyib vəslinə sən Leylivəşin, bir ömrdür
Mən kimi Məcnun olub səhrayə düşmüş afitab.

Ol büt əbrusin qoyub mehrabə döndərmən üzüm,
Qoy məni, zahid, mana çox vermə Tanriçün əzab.

Nəqdi-ömrün bir sənəm eşqində sərf etdin təmam,
Ey Füzuli, ah, əgər səndən sorulsa bu hesab!


64


Qılsa vəslin şamımı sübhə bərabər, yox əcəb;
Rəsmdir fəsli-bəhar olmaq bərabər ruzü şəb.

Gün ki, sayən düşdüyü yerdən durar, bir vəchi var,
Gəlsə aliqədrlər, fəqr əhli durmaqdır ədəb.

Olmadan meyxaneyi-eşqində məsti-cami-zövq,
Düzmədi bəzmi-fələkdə Zöhrə qanuni-tərəb.

Cənnəti-vəslindir ol məqsəd ki, iman əhlinə
Qılsa həq ruzi cəhənnəm atəşi, oldur səbəb.

Qaliba məqsəd vüsalındır ki, dün gün durmayıb,
Çərx sərgərdan gəzər, bilməz nədir rəncü tə’əb.

Bəsteyi-zənciri-zülfündür nəsimi-tərmizac,
Təşneyi-cami-vüsalındır mühiti-xüşkləb.

Qılma feyzi-ne’məti-vəslin Füzulidən diriğ,
Yoxdur özgə məqsədi, səndən səni eylər tələb.


65


Sən üzündən aləmi rövşən qılıb saldın niqab,
Yazıya [1] salsın bu gündən böylə nurin afitab.

Sən nə nuri-paksən, ey məzhəri-sün’i-ilah,
Kim, alır şəm’i-rüxündən nur mehrü mahitab.

Əks ruyin suya salmış sayə, zülfün toprağa,
Ənbər etmiş toprağın adın, suyun ismin gülab.

Yeldə bulmuş buyi-zülfün, suda əksi-arizin
Kim, yeli bağrına basıb, suya göz dikmiş hübab.

Lə’lgun meydir əlində sağəri-simin ilə,
Ya nigini-lə’ldir, rəşki-ləbindən oldu ab?

Kilki-qüdrət lövhi-sinəmdə səni qılmış rəqəm,
Eyləyib məhbublər məcmuəsindən intixab.

Ey Füzuli, hər əməl qılsan xətadır, qeyri-eşq,
Budurur mən bildigim, “vəllahü ə’ləm bis-səvab” [2]


1 Səhraya
2 Tərcüməsi: Doğrusunu Allah daha yaxşı bilər.


66


Kuhkən Şirinə öz nəqşin çəkib vermiş firib,
Gör nə cahildir, yonar daşdan öziçün bir rəqib.

Qaşların yayi bir ox lütf eyləmiş hər aşiqə,
Mən həm ondan eylərəm bir ox təmənna, ya nəsib.

Tutiyayi-xaki-payin feyzinə yol bulmasam,
Nuri-çeşmim, eyb qılma, kor olur derlər qərib.

Müztəribdir çareyi-dərdimdə, vəh kim, bilməyib,
Bir dəvasız dərdə uğratmış özün miskin təbib.

Bərqi-ahimdən evim hər guşə bulmuş rəxnələr,
Gəl gör, ey gül, kim, giriftari-qəfəsdir əndəlib.

Ey mənə səbr et deyən, hali-dilimdən bixəbər,
Eşq olan yerdə nədir aram, ya neylər şəkib?

Ey Füzuli, incimə səndən təğafül qılsa yar,
Rəsmdir kim, göstərə əhbabə istiğına həbib.


67


Ol ki, hər saət gülərdi çeşmi-giryanım görüb,
Ağılar oldu halimə, birəhm cananım görüb.

Eyləyən tə’yini-əczayi-müdava dərdimə,
Tərk edib, cəm etmədi, hali-pərişanım görüb.

Lalərüxlər göksümün çakinə qılmazlar nəzər,
Hiç bir rəhm eyləməzlər daği-pünhanım görüb.

Tut gözün, ey dudi-dil, çərxin ki, devrin tərk edib,
Qalmasın heyrətdə, çeşmi-gövhərəfşanım görüb.

Pərtövi-xurşid sanmın yerdə kim, devri-fələk,
Yerə urmuş afitabın, mahi-tabanım görüb.

Suda əksi-sərv sanmın, kim qoparıb bağiban
Suyə salmış sərvini, sərvi-xuramanım görüb.

Ey Füzuli, bil ki, ol gül arizin görmüş degil,
Kim ki, tə’n eylər mənim çaki-giribanım görüb.


68


Ruzigarım buldu dövrani-fələkdən inqilab,
Qan içər oldum, əyağın çəkdi bəzmimdən şərab.

Şö’leyi-ah ilə yandırdım dili-sərgəştəyi,
Bir od oldum, cizginən çevrəmdə olmazmı kəbab?

Lə’lin ilə badə bəhs etmiş, zəhi gümrahlıq,
Oldu vacib eyləmək ol biədəbdən ictinab.

Verməz oldu yol vüsalə piçi-zülfün, ah, kim,
Rişteyi-tədbirdən dövrani-kəcrov açdı tab.

Olmadı ol mahə rövşən yandığm hicran günü,
Yandığın şəb ta səhər şəm’in nə bilsin afitab.

Göz ki, peykanın qapub, gögdən saçar hər yan sirişk,
Bir sədəfdir, qətreyi-barani eylər dürri-nab.

Oldu əbri-dudi-ahim pərdeyi-rüxsari-mah,
Ah kim, almaz cəmalindən hənuz ol məh niqab.

Kəsmədi məndən səri-kuyində azarın rəqib,
Ey Füzuli, cənnət içrə nişə yox, derlər əzab?


69


Dərdi-eşqim dəf’inə zəhmət çəkər daim təbib,
Şükr kim, olmuş ona zəhmət, mənə rahət nəsib.

Bir zəbandır şərhi-qəm təqririnə hər bərgi-gül,
Eyləməz bihudə gül gördükdə əfğan əndəlib.

Bilsə zövqüm vəsldən firqətdə əfzun olduğun,
Vəsldən mən’im rəva görməzdi rəşkindən rəqib.

Tə’ni-qəflətdir pəritəl’ətlərə izhari-hal,
Sanma kim, əhbab halından olur qafil həbib.

Ah, bilmən neyləyim, qurtulmaq olmaz qeyddən,
Mən hərifi-sadədil, xuban cəmali dilfirib.

Şəm’ qürbilə təfaxür qılma, ey pərvanə, kim,
Xirməni-ömrün göyər bərqi-fənadan ənqərib.

Nola ağılarsa Füzuli rövzeyi-kuyin anıb,
Lacərəm giryan olur qılğac vətən yadın qərib.


70


Payibənd oldum səri-zülfi-pərişanın görüb,
Nitqdən düşdüm ləbi-lə’li-dürəfşanın görüb.

Oda yaxdım şəm’vəş canım, baxıb rüxsarinə
Çərxə çəkdim dudi-dil, sərvi-xuramanın görüb.

Gəzdirər hər yan gözüm əşk içrə bağrım parəsin,
Xəl’əti-gülgun ilə rəxş üzrə cövlanın görüb.

Bir zaman keçməz ki, dil tiğindən olmaz çak-çak,
Açılır hər dəm tutulmuş könlüm ehsanın görüb.

Könlümü tənhalıq eylərdi pərişan sinədə,
Olmasaydı cəm, hər yanında peykanın görüb.

Bəndü zindani-qəmü möhnətdən olmuşdum xilas,
Ah kim, düşdüm yenə, zülfü zənəxdanın görüb.

Ey Füzuli, bunca kim, tutdun nihan hali-dilin,
Aqibət fəhm etdi el çaki-giribanın görüb.


71


Qeyrə eylər bisəbəb min iltifat ol nuşləb,
İltifat etməz mənə mütləq, nədir bilmən səbəb?

Cövr olur adət qəzəb vəqti, nə adətdir bu kim,
Cövrün az eylər mənə ol tündxu qılğac qəzəb.

Nola qəmzən fikri düşdisə dili-suzanimə,
Zalimin gər olsa atəş mənzili, olmaz əcəb.

Dəmbədəm gər düşsə gözdən dürri-əşkim, vəchi var.
Yaş uşaqlardır yetim, onlarda yox rəsmi-ədəb.

Cövri könlümdür çəkən, gözdür görən rüxsarını,
Allah, Allah, kam alan kimdir, çəkən kimdir təəb.

Yar bidad eyləməz üşşaq fəryad etmədən,
Hər necə ruzi müqəddər olsa, vacibdir tələb.

Mütrib, ağılatma sürudinlə Füzuli xəstəni,
Seyli-əşkindən saqın, qopmaya bünyadi-tərəb.


72


Vəslin mənə həyat verir, firqətin məmat,
Sübhanə xaliqi xələqəl movtə vəl-həyat [1] .

Hicranına təhəmmül edən vəslini bulur,
Tuba limən yusaidühüs-səbrü vəs-səbat [2] .

Mehrindir iqtinai-məqasid vəsiləsi,
Ma şaə mən əradə, bihil-fovzu vən-nəcat [3] .

Tökmüş riyazi-təb’imə barani-şövqini,
Mən ənzələl-miyahə və əhya bihin-nəbat [4] .

Həq afərinişə səbəb etdi vücudini,
Əvcəbtə biz-zühuri zühurəl-mükəvvənat [5] .

İyzəd səriri-hüsnə səni qıldı padişah,
Ə’la kəmalə zatikə fi əhsənis-sifat [6] .

Qıldın ədayi-nə’t, Füzuli, təmam qıl,
Kəmmilhu bis-səlami və təmmimhu bis-səlat [7] .


1 Tərcüməsi: Pak və müqəddəsdir o yaradan ki, diriliyi və ölümü yaratmışdır.
2 Tərcüməsi: O adam xoşbəxtdir ki, mətanət və səbr ona kömək edir.
3 Tərcüməsi: Nə istərsə, kimi nəzərdə tutarsa, nəcat və müvəffəqiyyət onun vasitəsilədir.
4 Tərcüməsi: Yağşı yağıdırıb, bitkiləri dirildən.
5 Tərcüməsi: Zühurunla varlığın zühuruna səbəb oldun.
6 Tərcüməsi: Zatının kəmalını gözəl sifətlərlə yüksəltdi.
7 Tərcüməsi: Salam ilə onu tamamla, dua ilə bitir.

73


Yürü, yetir mənə, ey simi-əşk, bidad et,
Gər aqçan ilə alınmış qul isəm, azad et!

İtirmə itləri avazının, könül, zövqin,
Yetər qara gecələr hərzə-hərzə fəryad et!

Xərab olan könül, ey büt, sənin məqamındır,
Təğafül eyləmə, bir qaç daş ilə abad et!

Eşitmədinmi, könül, eşq müşkil olduğunu,
Sənə bu müşkil işi kim dedi ki, bünyad et?!

Xilafi-adətə çox olma, ey pəri, mail,
Yetər füsun ilə təsxiri-adəmizad et!

Səba, əsirləri qəsdin eyləmiş ol gül,
Bizi həm onda, əgər düşsə fürsətin, yad et!

Füzuli, istər isən izdiyadi-rütbeyi-fəzl,
Diyari-Rum gözət, tərki-xaki-Bağıdad et!


74


Əksi-rüxsarın ilə oldu müzəyyən mir’at,
Bədəni-mürdəyə feyzi-nəzərin verdi həyat.

Bənzədərdim qədi-mövzuninə fil-cümlə əgər,
Can içində əlif etsəydi qəbuli-hərəkat.

Xət bu məzmun ilədir tərfi-zənəxdanında
Ki, bu zindanın əsirinə yox ümmidi-nəcat.

Kakilin qıldı müqərrər mənə sərgəştəliyi,
Deməsin kimsə ki, var gərdişi-gərdunə səbat.

Qəmzə peykanin edər aşiqə çeşmin sədəqə,
Öylə kim, mərdümi-mün’im verə möhtacə zəkat.

Afərin cövhəri-məqbulinə kim, aləmdə
Mümkün olmaz bu sifat ilə ki, sənsən bir zat.

Ey Füzuli, vərə’ü zöhd ilə mö’tad oldun,
Bilmədin halını, bihudə keçirdin ovqat.


75


Ey əsiri-dami-qəm, bir guşeyi-meyxanə tut!
Tutma zöhhadın müxalif pəndini, peymanə tut!

Dişlədimsə lə’lin, ey qanım tökən, qəhr eyləmə,
Tut ki, qan etdim, ədalət eylə, qanı qanə tut!

Cizginirkən başına, şəm’i-rüxündən canımı,
Mən’ qılma, anı həm ol şəm’ə bir pərvanə tut!

Gər sənə əfğanimi bihudə dersə müddəi,
Ol sözə tutma qulaq, mən çəkdigim əfğanə tut!

Tutmazam zənciri-zülfü tərkin, ey naseh, məni
Xah bir aqil xəyal et, xah bir divanə tut.

Ey olub sultan, deyən dünyadə məndən qeyri yox,
Sən səni bir cüğıd bil, dünyanı bir viranə tut.

Ey Füzuli, dəhr zalinin firibindən saqın,
Olma qafil, ər kimi təprən, işin mərdanə tut!


76


Bəhri-eşqə düşdün, ey dil, zövqi-dünyani unut!
Baliğ oldun, gəl rəhimdən içdigin qani unut!

Verdi rehlətdən xəbər muyi-səfidü ruyi-zərd,
Çöhreyi-gülgun ilə zülfi-pərişani unut!

Çək nədamətdən gögə dudi-dilin, tək qanlı yaş,
Sərvi-nazin tərk tut gülbərgi-xəndani unut!

Gör qənimət fəqr mülkündə gədalıq şivəsin,
E’tibari-mənsəbü dərgahi-sultani unut!

Çəkmə aləm qeydini, ey sərbüləndi-fəqr olan,
Səltənət təxtinə irdin, bəndü zindani unut!

Lövhi-xatir surəti-cananə qıl ayinədar,
Onu yad et, hər nə kim yadındadır, ani unut!

Mə’siyət dərsin yetər təkrar qıl, döndər vərəq,
Özgə hərfin məşqin et, ol dərs-ünvani unut.

Ey Füzuli, çək məlamət rəhgüzarından qədəm
Ləhzə-ləhzə çəkdigin bihudə əfğani unut!


77


Mürdə cismim iltifatından bulur hər dəm həyat,
Ölərəm, gər qılmasan hər dəm mənə bir iltifat.

Yazə bilməz ləblərin vəsfin təmami-ömrdə,
Abi-heyvan versə Xizrə kilkü zülmətdən dəvat.

Mən fəqirəm, sən qəni, vergil zəkati-hüsn kim,
Şər’ içində həm mənədir həm sənə vacib zəkat.

Görməyincə hüsnünü imanə gəlməz aşiqin,
Yüz peyəmbər cəm olub, göstərsələr min mö’cüzat.

Məzhəri-asari-qüdrətdir vücudi-kamilin,
Feyzi-fitrətdən qərəz sənsən, tüfeylin kainat.

Cövhəri-zatindədir məcmui-övsafi-kəmal,
Bu sifat ilə ki, sənsən, qandadır bir pak zat?

Eşqə ta düşdüm, Füzuli, çəkmədim dünya qəmin;
Bil ki, qeydi-eşq imiş dami-təəllüqdən nəcat.


78


Səba, əğyardan pünhan, qəmim dildarə izhar et!
Xəbərsiz yarımı hali-xərabimdən xəbərdar et!

Gətir yadım onun yanında, vər görsən ki, qəhr eylər,
Xəmuş olma, yenə düşnam təqribilə təkrar et!

Könül, qəm günlərin tənha keçirmə, istə bir həmdəm,
Əcəl xabından, əfqanlar çəkib, Məcnunu bidar et!

Çü yox, eşq atəşi bir şö’lə çəksə, taqətin, ey ney,
Baş ağrıtma, dəmi-eşq urma, ancaq naleyi-zar et!

Məni rəşk oduna pərvanə tək, ey şəm’, yandırma,
Yetər xurşidi-rüxsarın çiraği-bəzmi-əğyar et!

Giriftari-qəmi-eşq olalı azadeyi-dəhrəm,
Qəmi-eşqə məni bundan bətər, yarəb, giriftar et!

Füzuli, baxmaq olur ol günəş yadilə xurşidə,
Nə vəch ilə kim, olsa gün keçər, fikri-şəbi-tar et.


79


Xətti-rüxsarın edər lütfdə reyhan ilə bəhs,
Hüsni-surətdə cəmalın güli-xəndan ilə bəhs.

Cənnəti kuyinə zöhd əhli münasib desələr,
Nə münasib ki, qılam bir neçə nadan ilə bəhs.

Yüzünə durmasın ayinə urub lafi-səfa,
Nə rəva məh qıla xurşidi-dirəxşan ilə bəhs.

Gərçi şümşaddə çox lafi-lətafət vardır,
Yorulur eyləsə ol sərvi-xuraman ilə bəhs.

Qılsa can lə’lin ilən feyz yetirmək bəhsin,
Canibi-lə’lini tut, ey könül, et can ilə bəhs!

Düşər od şəm’ dilinə bu səbəbdən ki, qılır
Dil uzadıb gecələr ol məhi-taban ilə bəhs.

Sifəti-hüsnün edər xəstə Füzuli, nə əcəb,
Hüsni-göftardə gər eyləsə Həssan ilə bəhs.


80


Cəhan içrə hər fitnə kim, olsa hadis,
Ona sərvi-qəddindir, əlbəttə, bais.

Mədarisdə təhqiqi-muyi-miyanın,
Dəqayiqdən ortayə salmış məbahis.

Müvəhhidlərə qılma inkar, zahid,
Meyi-vəhdəti sanma ümmül-xəbais [1] .

Iki didəsiz aləmə Yusifü sən,
Sizə yox cəhan içrə imkani-salis.

Mənə cəm olur qanda kim, var bir qəm,
Mənəm mülki-qəm içrə Məcnunə varis.

Töküb əşk kuyində, vəslin dilər dil,
Saçar nəf’ üçün danə toprağə haris [2] .

Üzarü ləbin vəsfin eylər Füzuli,
Ona həm müfəssir derəm, həm mühəddis.


1Ümmül-xəbais – pisliklər anası
2 H a r i s – əkinçi


81


Ey qübari-qədəmin ərşi-bərin başinə tac,
Şərəfi-zatinə ədnayi-məratib me’rac.

Müntəha şər’inə ədyani-təmamiyyi-rüsul,
Bəhrsən, sairi-ərbabi-risalət əmvac.

Xazini-gənci-şəfaət səni qılmış iyzəd,
Hiç kim yox ki, sənə olmaya axir möhtac.

Sünnətin məğfirət əsbabinə minhaci-hüsul,
Ta’ətin mə’siyət əmrazinə tədbiri-ilac…

Xəlqə təqlidi-sülukin səbəbi-hüsni-məaş,
Mülkə təğyiri-təriqin əsəri-sui-mizac.

Qaim olmazdı nizamü nəsəqi-əsli-vücud,
Verməsəydin əsəri-ədl ilə dünyayə rəvac.

Şükr-lillah ki, Füzulini edib daxili-feyz,
Rəğıbətin daireyi-xovfdən etmiş ixrac.


82


Can çıxır təndən könül zikri-ləbi-yar eyləgəc,
Tən bulur can yenlədən ol ləfzi təkrar eyləgəc.
Qılma, ey əfqan, gözün bidar, məsti-xab ikən,
Olmaya bir fitnə peyda ola, bidar eyləgəc.
Söhbətimdən ar edib, ey gül, məni tərk etmə kim,
Gül olur əfsürdə tərki-söhbəti-xar eyləgəc.
Varımı fikri-dəhanınla yox etdim kim, qəza
Böylə əmr etmiş mana, yoxdan məni var eyləgəc.
Ərzi-rüxsar et bu gün, ey məh, güm olsun göydə gün,
Öylə kim əncüm olur, gün ərzi-rüxsar eyləgəc.
Hər zəban bir tiğıdir guya Züleyxa qətlinə,
Yusifi almaqda əhli-eşq bazar eyləgəc.
Naleyi-zarım, Füzuli, xoş gəlir ol gülrüxə,
Açılır gül könlü bülbül naleyi-zar eyləgəc.


83


Könlüm açılır zülfi-pərişanını görgəc,
Nitqim tutulur qönçeyi-xəndanını görgəc.

Baxdıqca sənə qan saçılır didələrimdən,
Bağrım dəlinir navəki-müjganını görgəc.

Rə’nalıq ilə qaməti-şümşadı qılan yad,
Olmazmı xəcil sərvi-xuramanını görgəc?

Çox eşqə həvəs edəni gördüm ki, həvasın
Tərk etdi, sənin aşiqi-nalanını görgəc.

Kafər ki, degil mö’tərifi-nari-cəhənnəm,
Imanə gələr atəşi-hicranını görgəc.

Naziklik ilə qönçeyi-xəndanı edən yad,
Etməzmi həya lə’li-dürəfşanını görgəc?

Sən hali-dilin söyləməsən, nola, Füzuli,
El fəhm qılır çaki-giribanını görgəc.


84


Münhərifdir, saqiya, ənduhi-dünyadən mizac,
Badə tut kim, illəti-ənduhə qəflətdir ilac.

Fəqr mülkün tut, gər istiğınadə istərsən kəmal,
Səltənətdən keç kim, ol vadidə çoxdur ehtiyac.

Çəkmə təxtü tac qeydin, bisərü palıq gözət
Kim, əyağə bənddir təxtü bəladır başə tac.

Bir pəri zülfün tutub, xalindən alsan kami-dil,
Tut ki, Çin mülkini tutdun, Hinddən aldın xərac.

Tərkü təcrid ixtiyar et kim, diyari-eşqdə
Fəqr bazarinə əsbabi-fənadəndir rəvac.

Nəqşi-zayildir, ümuri-dəhrə qılma e’tibar,
Olsa hasil fəqrdən hüznü qinadən ibtihac.

Ey Füzuli, mən məlamət mülkünün sultaniyəm,
Bərqi-ahim taci-zər, simi-sirişkim təxti-tac.


85


Olur qəddim düta eşqin yolunda, hər bəla görgəc,
Təriq əhlinə adətdir təvazö, aşina görgəc.

Nihan eşqimi mə’lum etsə aləm, dudi-ahimdən,
Əcəb yox kim, gümani-gənc edər xəlq, əjdəha görgəc.

Füzun olduqca eşqim gərm olur əşkim gözüm içrə,
Əgərçi su bürudət kəsbini eylər həva görgəc.

Oxun hər ləhzə kim, canım dələr, könlüm qılar əfğan,
Be-eyni eylə kim, fəryad edər itlər, gəda görgəc.

Rəvaci-nəqd nəqşi-sikkədəndir, nola qədr etsə
Mənə el, cismi-üryanımda nəqşi-buriya görgəc.

Məni-dərvişə el həm cövr edər, sən cövr qıldıqca,
Kim eylər zülm mən’in, padihaşım, sən rəva görgəc?

Füzulini yaşur, ey zə’f, məhvəşlər cəfasından
Ki, məhvəşlər qılırlar min cəfa, bir mübtəla görgəc.


86


Ey könül, yarı istə, candan keç,
Səri-kuyin gözət, cəhandan keç!

Ya təmə’ kəs həyat zövqindən,
Ya ləbi-lə’li-dilsitandan keç.

Mülki-təcriddir fərağət evi,
Tərki-mal eylə, xanimandan keç.

Laməkan seyrinin əzimətin et,
Bu xərab olacaq məkandan keç.

E’tibar etmə mülki-dünyayə,
E’tibari-ülüvvi-şandan keç!

Əhli-dünyanın olmaz axirəti,
Ey Füzuli, bu xakdandan keç!


87


Gər degil bir mah mehrilən mənimtək zar sübh,
Başin açıb nişə hər gün yaxasın yırtar sübh?

Gün degil, hər gün bir ay mehrilə köksün çak edib,
Tazə-tazə dağılərdir kim, qılır izhar sübh.

Tiği-xurşid ilə rəf’ olsa yeridir kim, müdam
Yandırıb pərvanəyi, şəm’ə verir azar sübh.

Sübhi şamü şami sübh olmuş mənəm aləmdə kim,
Şam şəm’i-bəzm olub, ayrıldı məndən yar sübh.

Gör nə aşiqdir ki, bir xurşid vəslin bulmağa
Sərf edər hər ləhzə min-min lö’löi-şəhvar sübh.

Eşqdə sadiqlik izhar etdi dağın göstərib,
Qaliba derlərdi kazib, qıldı ondan ar sübh.

Hicr şamında qəm etmişdi Füzuli, qəsdi-can,
Olmasaydı mərhəmətdən dəm urub qəmxar sübh.


88


Əgər murad isə vermək səfayi-cövhəri-ruh,
Fələk misal yürüt sağəri-şərabi-səbuh.

Buyurma tövbə mənə ol şərabdan naseh
Ki, görsə onu tutar cəzm tərki-tövbə Nəsuh.

Hücumi-qəmdə mənə onu etdi zövrəqi-mey
Kim, etmədi onu tufan olanda kəştiyi-Nuh.

Müdam çeşmimə qan doldurur xədəngi-qəmin,
Yuva başımda tutan quşları edib məcruh.

Dil oldu daği-fəraqinlə şərhə-şərhə, vəli
Nə sud, çün sənə olmadı hali-dil məşruh.

Tənimdə sancılı navəklərinlə şadəm kim,
Dəri-bəla bu kilid ilədir mənə məftuh.

Füzuli oldu belin fikri ilə muy misal,
Hənuz bulmadı ol sirrə ehtimali-vüzuh.


89


Qansı mahin, bilməzəm, mehrilə olmuş zar sübh,
Hər gün eylər xəlqə bir daği-nihan izhar sübh.

Batdı əncüm, çıxdı gün, ya bir əsiri-eşqdir,
Tökdü dürri-əşki, çəkdi ahi-atəşbar sübh.

Nola gər əmvatə ehya versə sübhün dəmləri,
Zikri-lə’lindir kim, eylər dəmbədəm təkrar sübh.

Bir müsəvvirdir ki, zərrin kilk ilə hər gün çəkər,
Səfheyi-gərdunə nəqşi-arizi-dildar sübh.

Müjdə bir xurşiddən vermiş məgər badi-səhər
Kim, nisar eylər ona yüz min düri-şəhvar sübh.

Aşiqi-sadiqdir, izhari-qəm eylər hər səhər,
Ah ilə xəlqi yuxusundan qılır bidar sübh.

Ey Füzuli, şami-qəm əncamına yoxdur ümid,
Bir təsəllidir sənə ol söz ki, derlər var sübh.


90


Ol mişkbu qəzalə ixlasım eylə vazeh,
Bəlliğ, səba, səlamən miskiyyətər-rəvayeh [1] .

Olğac həbibə vasil, bizdən həm olma qafil,
Latəqtəir-rəsail, latəktəmis-sərayeh [2] .

Yüzdə sirişk qani, söylər qəmi-nihani,
Qəd təzhərül-mə’ani bil-xətti fil ləvayeh [3] .

Mən mübtəlayi-hicran, məndən iraq canan.
Vəl-ömrü keyfə ma kan mislür-riyahi rayeh [4] .

Eşqin, Füzuliyi-zar, tərk etmək oldu düşvar
Ya arifən bima sar, la tüksirin-nəsayeh [5] .


1 Tərcüməsi: Ey səhər yeli, məndən mişk qoxulu salam yetir.
2 Tərcüməsi: Məktubları məndən kəsmə, əzab-əziyyətlərini gizlətmə!
3 Tərcüməsi: Mənalar lövhələr üzərində xətt ilə zahir olur.
4 Tərcüməsi: Ömür nə cür olursa-olsun külək kimi əsib gedəndir.
5 Tərcüməsi: ey olan şeyləri bilən, çox nəsihət etmə!

91


Kimsədə rüxsarına taqəti-nəzzarə yox,
Aşiqi öldürdü şövq, bir nəzərə çarə yox.

Bağrı bütünlər mənə tə’nə edərlər müdam,
Halımı şərh etməyə bir cigəri parə yox.

Yığıdı mənim başıma dəhr qəmin, neyləsin,
Badiyeyi-eşqdə mən kimi avarə yox.

Dəhrdə həmta sənə var pərirüx desəm
Var gözəl çox, vəli sən kimi xunxarə yox.

Gözdə gəzib cizginir qətreyi-əşkim müdam,
Qətreyi-əşkim kimi çərxdə səyyarə yox.

Çak görüb köksümü qılma ilacım, təbib,
Zaye’ olur mərhəmin, məndə bitər yarə yox.

Zarlığm eşqdən var, Füzuli, vəli,
Ol məhi-bimehrdən rəhm məni-zarə yox.


92


Nola gər qucsa miyanın kəməri-zər küstax,
Gətirib çoxları ortayə zər, eylər küstax.

Xaki-sağər, Cəmü Cəmşiddir, ey piri-müğan,
Xəbər et saqiyə kim, tutmaya sağər küstax!

Rəşk odilə yaxılır rişteyi-canım ki, neçün
Dəgər ol arizə geysuyi-müənbər küstax.

Rövzənindən qoma kim, gün düşə xəlvətgəhinə,
Hərəmi-şahə nə layiq girə çakər küstax.

Saxla, ey əşk, ədəb, getmə səri-kuyinə çox
Ki, düşər gözdənü üzdən sürülər hər küstax.

Həvəsim badeyi-gülgunə bu ümmid ilədir
Kim, olam məstü tutam daməni-dilbər küstax.

Bənzədirsən özünü itlərinə hər saət,
Ey Füzuli, ola bilməz sənə bənzər küstax.


93


Rəngi-ruyindən dəm urmuş sağəri-səhbayə bax!
Afitab ilə qılır də’va, tutulmuş ayə bax!

Şəm’ başından çıxarmış dud şövqi-kakilin,
Böylə kutah ömr ilə başindəki sevdayə bax!

Ey səlamət əhli, ol rüxsarə baxma zinhar!
Ehtiraz eylə məlamətdən, məni-rüsvayə bax!

Bildi eşqində nəmədpuş olduğum ayinə tək,
Rəhm edib bir gəz mənə baxmaz, bu istiğınayə bax!

Sinəmi çak eylə, gör dil iztirabın eşqdən,
Rövzən aç, hər dəm həvadən mövc uran dəryayə bax!

Ey deyən kim, şami-iqbalın nə üzdən tirədir?
Sayə salmış ayə ol geysuyi-ənbərsayə bax.

Ey Füzuli, hər necə mən’ eyləsə naseh səni,
Baxma onun qovlinə, bir surəti-zibayə bax.


94


Ləblərin tək lə’lü ləfzin tək düri-şəhvar yox,
Lə’lü gövhər çox, ləbin tək lə’li-gövhərbar yox.

Səndən etmən dad: “cövrün var, lütfün yox” deyib,
Məsti-zövqi-şövqünəm, birdir yanımda var, yox.

Kimə izhar eyləyim bilmən, bu pünhan dərdi kim,
Var yüz min dərdi-pünhan, qüdrəti-izhar yox.

Dövr sərməsti-şərabi-qəflət etmiş aləmi,
Bunca sərməstin təmaşasinə bir hüşyar yox.

Xəlqi mədhuş eyləmiş xabi-şəbi-tuli-əməl,
Sübh təhqiqi əlamətinə bir bidar yox.

Surəti zibasənəmlər yox demən bütxanədə,
Var çox, əmma sənə bənzər büti-xunxar yox.

Ey Füzuli, səhldir hər qəm ki, qəmxari ola,
Qəm budur kim, məndə min qəm var, bir qəmxar yox.


95


Gərmdir şamü səhər mehrinlə çərxi-lacivərd,
Gəh sirişki-al edər izharü gəh rüxsari-zərd.

Sübhə bənzər aşiqi-sadiq, demən aləmdə kim,
Bir nəfəs keçməz ki, çəkməz suzi-dildən ahi-sərd.

Yaxşı sanma, ey könül, əhli-xirəd ətvarını,
Olma qafil, eşq dərdindən, yaman olmaz bu dərd.

Mümkün olduqca fələk mənsubəsindən qıl həzər,
Nişə kim, xali degil bidad nəqşindən bu nərd.

Zülməti-qəm iztirabin çəkməz ol azadə kim,
Hər təəllüqdən ola xurşid tək aləmdə fərd.

Ey Füzuli, kəsmə ol məhvəş vüsalindən ümid,
Səbr qıl kim, dövr dövranı degil bihudəgərd.


96


Nalədəndir ney kimi avazeyi-eşqim bülənd,
Nalə tərkin qılmazam, ney tək kəsilsəm bənd-bənd.

Qıl mədəd, ey bəxt, vərnə, kami-dil mümkün degil,
Böylə kim, ol dilrüba bidərddir, mən dərdmənd.

Dağılərdir odlu könlümdə qarası qopmamış,
Ya səbati-eşq üçün od üzrə bir neçə sipənd.

Açılır könlüm gəhi kim, giryeyi-təlxim görüb,
Açar ol gülrüx təbəssüm birlə lə’li-nuşxənd.

Xaki-rahindən məni qaldıra bilməz sayə tək,
Qılsa gərdun afitabın hər şüaın bir kəmənd.

Cam tut, der, saqiyi-gülçöhrə, zahid, tərki-cam,
Ey könül, fikr eylə gör kim, qansıdır tutmalı pənd.

Ey Füzuli, surəti-fəqrin qəbuli-dustdur,
Hiç dərvişi sənin tək görmədim sultanpəsənd.


97


Göz xətindən mərdümin məhv etmədən bulmaz murad,
Zaye eylər hüsnünü xəttin səvad üzrə səvad.

Ola bilməz çini-zülfündən cüda göz mərdümi,
Cari olmuşdur bu adət, türrəsiz olmaz midad.

Könlün ahimdən tərəhhüm surətin göstərdi, leyk
Mövcdən su nəqşinə çox etmək olmaz e’timad.

Əşkü ahim nifrəti qət’ etdi eldən ülfətim,
Çizginən devrəmdə ya girdabdır, ya girdibad.

Keçdi təndən oxların, tənha qalıb dil, dəmbədəm
Nalələr eylər, keçən həmdəmlərin etdikcə yad.

Çaki-sinəmdən könül çıxdıqca şad olsam nola,
Oylə afətdən yaxasın qurtaran olmazmı şad?

Şiveyi-şümşad qəddin görsə, eylər bağiban
E’tidali-sərvdən, əlbəttə, səlbi-e’tiqad.

Qoyma naqis əhli-dərd içrə Füzulini, təbib,
Eylə bir dərman ki, dərdin edə gün-gündən ziyad.


98


Ey məzaqi-canə cövrün şəhdü şəkkər tək ləziz,
Dəmbədəm zəhri-qəmin qəndi-mügərrər tək ləziz.

Atəşi-bərqi-fəraqın nari-duzəx tək əlim,
Cür’eyi-cami-vüsalin abi-kövsər tək ləziz.

Şərhi-əhvalım sənə məstə nəsihət kimi təlx,
Təlx göftarın mənə məxmurə sağər tək ləziz.

Daği-eşqin dərdi zövqi-səltənət tək dilpəzir,
Xaki-kuyin seyri fəthi-həft kişvər tək ləziz.

Nola bulsam zövq göydürdükcə sinəm üzrə dağ,
Əhli-dərdə dağ olur, bidərdə zivər tək ləziz.

Tazə-tazə daği-dərdindir dili-suzanimə
Filməsəl, hirs əhlinə cəm’iyyəti-zər tək ləziz.

Ey Füzuli, aləmin gördüm qamu ne’mətlərin,
Hiç ne’mət görmədim didari-dilbər tək ləziz.


99


Cilveyi-əksi-rüxün ayinədə, ey rəşki-hur,
Rövşən etmiş onu kim, xurşiddəndir ayə nur.

Bərqi-ahim göy üzün tutmuş, sirişkim yer üzün,
Söhbətimdən həm vühuş etmiş tənəffür, həm tüyur.

Eşq rəsmi gər budur, müşkül yetər dərmanə dərd,
Dərd əhli bizəban, bidərdlər məsti-qürur.

Daği-dilsuzi-fəraqın qıldı gün-gündən füzun,
Nuri-mah əfzun olur, xurşiddən olduqca dur.

Və’deyi-vəslin çox, əmma bəxt yar olmaz, nə sud,
Gül gətirməz, abi-şirin vermək ilə xaki-şur.

Tari-zülfündürmü rüxsarında canlar məskəni,
Ya buraxmış bir rəhi-pürpiçü xəm gülzarə mur.

Ol səri-kuy itləri içrə, Füzuli, yox yerim,
Bəs mənə matəmsəra, mən qandanü bəzmi-sürur?


100


Yanan eşq atəşinə atəşi-duzəxdən eyməndir,
Nə kim, bir gəz yanar, yandırmaq oni qeyri-mümkindir.

Buraqdım zövrəqi-dil eşq bəhrinə, saqın, ey mah.
Təməvvüc verməsin təşviş ona kim, onda sakindir.

Dəhanın dürcünü xali-ləbin gözdən nihan etmiş,
Əmanət gör ki, hindu məxzəni-lö’löyə xazindir.

Qəmin kim, tökdü qanım, dildə sakin olduğun bildim
Ki, xəlvət çəkməgin tə’siri sirri-kəşfi batindir.

Cigər dağinə mərhəm oldu peykanın, bihəmdillah,
Səadət kövkəbinə əxtəri-bəxtim müqarindir.

Rüxündən nur oğurlar şəm’, başın kəssələr caiz,
Budur bir qul sərəncami ki, sultaninə xaindir.

Füzuli, xali olmaz surəti-dil dust fikrindən,
Bu mə’nidən ki, beytüllah, deyərlər qəlbi-mö’mindir.


101


Çeşmi-surətbazimə müjgan səfi həngamədir,
Qanə batmış hər müjəm bir şuxi-gülguncamədir.

Göstərər hər dəm əlamətlər qiyamətdən qədin,
Qaim etmiş həşr bürhanın, əcəb əllamədir.

Ta xətin üzrə xəmi-əbrulərin sərgərmiyəm,
Hər sözüm dərdi-dil imlasinə bir sərnamədir.

Üzdə nəqşi-xuni-dil razi-nihanım faş edər,
Şərhi-qəm təhririnə hər kiprigim bir xamədir.

Dərdim oldur kim, müsəlman olmuş ol tərsabeçə,
Küfrə olan zülmlər tə’ni bu gün islamədir.

Ey səba, rəhm et kim, ol bidərd qılmış tərki-cövr,
Çareyi-dərdi-dilim mövquf bir e’lamədir.

Ey Füzuli, bulmadım rəngi-riyadən bir səfa,
Nola gər meylim bu rəng ilə meyi-gülfamədir.


102


Səbuh üçün mənə dürdi-meyi-şəbanə yetər,
Əsər ki var, xərab olmağa bəhanə yetər.

Cəfa oxun mənə yağıdırman ancaq, ey əflak,
Demin ki, yeddi kəmandarə bir nişanə yetər.

Bəyanə yetməyə dərdü qəmim fəsanələri,
Zəbanım atəşi-dildən çıxan zəbanə yetər.

Qopardı mərdümi-çeşmim könül binasın kim,
Hübabi-əşk həva nəqdinə xəzanə yetər.

Ləbin xəyalı ilə parə-parə oldu cigər,
Güvahi-hal mənə əşki-danə-danə yetər.

Hərifi-bəzmi-qəmim, xuni-dil şərabım olub,
Təraneyi-tərəbim ahi-aşiqanə yetər.

Füzuli, istəməzəm məsnədi-Cəmü Cəmşid,
Mənə nişiməni-dövlət şərabxanə yetər.


103


Gah gözdə, gəh könüldə xədəngin məkan tutar,
Hər qanda olsa qanlını, əlbəttə, qan tutar.

Dil çəksə, nola, canü təni xaki-kuyinə,
Xarü xəs iltər onda ki, quş aşiyan tutar.

Zikri-ləbinlə zülfünə can buldu dəstrəs,
Onun kimi ki, oxuyub əfsun ilan tutar.

Dil tutdu qönçə ilə bərabər dəhanını,
Bu əqli-naqis ilə özün xurdədan tutar.

Xurşid xirməninə ura şö’lə-şö’lə od,
Ahım ki, ləhzə-ləhzə rəhi-asiman tutar.

Can eylədikdə meyli-təmaşayi-qamətin,
Göz rövzənin sirişki-rəvanım rəvan tutar.

Tutmaq dilər qapında Füzuli məqam, leyk
Bu sirri kimsəyə aça bilməz, nihan tutar.


104


Xoşam kim, dəmbədəm giryan gözüm ol xaki-padəndir.
Ziyanı olmaz ol göz yaşının kim, tutiyadəndir.

Dəmadəm mərdümi-çeşmim içər qan zülfü xalından,
Bəli əksər mə’aşi əhli-dəryanın qəradəndir.

Demə Fərhad qanın tökmüş ancaq eşq şəmşiri,
Mənim gör qanlı yaşım kim, bu həm ol macəradəndir.

Müənbər sünbülündən almadan bu, olmadım rüsva,
Bu rüsvalıq mənə səndən degil, badi-səbadəndir.

Hübabi-əşk içində muyi-julidəmlə xoşhaləm,
Başımda bu humayun sayə ol ali binadəndir.

Vəfa rəsmin unutmuşsan deyə, incinməzəm zira,
Bu kim, məndən cəfa kəm eyləməzsən, həm vəfadəndir.

Kəmali-hüsni-məşrəb, ari olmaqdır təərrüzdən,
Riya əhlinə həm çox e’tiraz etmək riyadəndir.

Füzuli, tökmə çox yaş, ehtiyat et getməsin nagəh
Gözündən sürmə kim, xaki-rəhi-əhli-səfadəndir.


105


Pərişan xəlqi-aləm ahü əfqan etdigimdəndir,
Pərişan olduğum, xəlqi pərişan etdigimdəndir.

Təni-zarimdə dərdi-eşq gün-gündən füzun olmaq
Yetən bidərd tədbirilə dərman etdigimdəndir.

Gözüm kim, bağrımın qanın tökər pərkalə-pərkalə,
Dəmadəm aruziyi-lə’li-canan etdigimdəndir.

Degil bihudə, gər yağsa fələkdən başimə daşlar,
Binasın tişeyi-ahimlə viran etdigimdəndir.

Qaçan rusva olurdum, qan udub səbr edə bilseydim,
Məlamət çəkdigim bihudə əfğan etdigimdəndir.

Xəta səndən degil, cismim oxundan binəsib olsa,
Hübabi-əşki-gülgun içrə pünhan etdigimdəndir.

Füzuli, ixtilati-mərdümi-aləmdən ikrahim,
Pərivəşlər xəyalın munisi-can etdigimdəndir.


106


Qəbrim daşinə kim, qəm odundan zəbanədir,
Tə’n oxun atma kim, xətəri çox nişanədir.

Eylər qədəh zəmanə qəmin dəf’, qaliba,
Dövri-qədəh müxalifi-dövri-zəmanədir.

Qaldırdı əşk dün məni ol asitanədən
Kim, məqsədim mənim dəxi ol asitanədir.

Vaiz sözünə tutma qulaq, qafil olma kim,
Qəflət yuxusunun səbəbi ol fəsanədir.

Nəzr etmişəm fəraqinə kim, yox nihayəti,
Nəqdi-sirişkimi ki, tükənməz xəzanədir.

Can verməyimmi qürbətə kim, bimi-tə’nədən
Yadi-vətən fəğanıma sənsiz bəhanədir.

Ey dil, həzər qıl atəşi-ahinlə yanmasın
Cismim ki, dərd quşlarına aşiyanədir.

Məndən, Füzuli, istəmə əş’ari-mədhü zəmm,
Mən aşiqəm, həmişə sözüm aşiqanədir.


107


Canı kim cananı üçün sevsə, cananın sevər,
Canı üçün kim ki, cananın sevər, canın sevər.

Hər kimin aləmdə miqdarıncadır təb’ində meyl,
Mən ləbi-cananimi, Xizr abi-heyvanın sevər.

Başə dəm düşdükcə təqsir eyləməz, eylər mədəd,
Ol səbəbdən müttəsil çeşmim cigər qanın sevər.

Mişki-Çin avarə olmuşdur vətəndən mən kimi,
Qansı şuxun, bilməzəm, zülfi-pərişanın sevər.

Su ki, sərgərdan gəzər, başında vardır bir həva,
Qaliba, bir gülrüxün sərvi-xuramının sevər.

Aqibət rusva olub mey tək, düşər xəlq ağızına,
Kim ki, bir sərməst sali lə’li-xəndanın sevər.

Nolacaqdır, tərki-eşq etmə Füzuli, vəhm edib,
Qayəti derlər, ola bir bəndə sultanın sevər.


108


Mehri könlümdə nihan olduğun ol mah bilir,
Kimsə bilməz, füqəra sirri-dilin şah bilir.

Sorman ol mahilə hali-dilimi, Tanrı üçün,
Biləli onu, özüm bilməzəm, Allah bilir.

Gah yüz lütf qılır, gah təğafül, guya
Gah bilməz bu giriftarlığm, gah bilir.

Can fəda eyləməyi yara həmin mən bilirəm,
Bu təriqi demə hər qafilü gümrah bilir.

Nəzəri-lütf diriğ etmə Füzulidən kim,
Sənə sidqilə özün bəndeyi-dərgah bilir.


109


Müjəm sərçeşmələr mənzil qılan aşüftə məcnundur,
Anınçun bəsteyi-zənciri-seyli-əşki-gülgundur.

Səvadi-nöqteyi-girdabə bənzər mərdümi-çeşmim
Ki, daim qərqeyi-girdabi-çeşmi-əşki-pürxundur.

Eşit dərdi-dilim, əfsaneyi-Məcnunə meyl etmə
Kim, ol əfsanədən həm anlanan mütləq bu məzmundur.

Fərəhbəxşi-dili-mə’şuq olur şərhi-qəmi-aşiq,
Sürudi-bəzmi-Şirin naleyi-Fərhadi-məhzundur.

Kəməndi-çini-zülfün vəhmi getməz zar könlümdən,
Mənə ol rişteyi əjdər qılan bilmən nə əfsundur.

Xəmidə qamətim kim, daği-dildən qanə qərq olmuş,
Içində nöqtəsi guya ki, qan altındakı nundur.

Füzuli, vermədi tə’n oxları göz yaşinə təskin,
Önün bənd etmək olmaz xarü xaşak ilə, Ceyhundur.


110


Qübari-səcdeyi-rahin xəti-lövhi-cəbinimdir,
Sücudi-dərgəhin sərmayeyi-dünyavü dinimdir.

Əgər əzmi-rəh etsəm, şövqi-vəslin hadiyi-rahim,
Və gör aram həm dutsam, xəyalın həmnişinimdir.

Həvayi-rövzeyi-kuyin, bahari-gülşəni-canim,
Nihali-qamətin sərvim, üzarın yasəminimdir.

Yəqinimdir ki, məqsudum olur hasil sənə yetsəm,
Bihəmdillah, mənə səndən yana rəhbər yəqinimdir.

Tələbkari-vüsaləm, müjdeyi-vəslin diriğ etmə
Kim, ol müjdə fərəhbəxşi-dili-ənduhginimdir.

Çıxardı zövqi-vəslin xatirimdən rövzə pərvasın,
Sözün kövsər, münəvvər məclisin xüldi-bərinimdir.

Mənə üz göstərər hər ləhzə yüz min şahidi-dövlət
Çü mir’ati-rüxün, mənzuri-çeşmi-pakbinimdir.

Səriri-səltənət zövqindən əfzundur mənə ol söz
Ki, lütf ilən demişsən: bir qulami-kəmtərinimdir.

Bəri oldum, Füzuli, qeyrdən, ol dilrüba ancaq,
Ənisim, munisim, yarım, nigarım, nazəninimdir.


111


Demiş hər qönçəyə aşiqligim razın səba derlər,
El ağızın tutmaq olmaz, qorxuram, ey gül, sana derlər.

Əsiri-dərdi-eşqü məsti-cami-hüsn çox əmma
Bizüz məşhur olan, Leyli sənə, Məcnun mana derlər.

Sənin mehrü vəfa göstərdigin əğyarə çox gördüm,
Qələtdir kim, səni bimehr oxurlar, bivəfa derlər.

Sənə derlər büti-Çin, zülfünə zünnar söylərlər,
Zəhi imanı yoxlar küff söylərlər, xəta derlər.

Mənə derlərdi əvvəl: bir mələkdir sevdigin, hala
Görənlər, mən fəqirə göydən enmiş bir bəla, derlər.

Mərizi-eşq iqdi-zülfün eylər arizu, zira
Müaliclər bu mühlik dərdə müşkildir dəva derlər.

Füzuli, aşiqə onlar ki, derlər tərki-eşq eylə,
Deməzlərmi xəta, təğyir qıl hökmi-qəza, derlər.


112


Səbadən gül üzündə sünbüli-pürpiçü tab oynar,
Sanasan pər açıb, gülşəndə bir mişkin qürab oynar.

Xəyali-arizin cövlan edər bu çeşmi-pürnəmdə,
Nəçük kim, mövclənmiş suda əksi-afitab oynar.

Rüxün görgəc olur suzi-dərunü dudi-dil hasil,
Bahar əyyami sıçrar bərqi-rəxşəndə, səhab oynar.

Irağ olsun yaman gözdən, nə xoş saətdir ol saət
Ki, mə’şuqilə aşiq eyləyib nazü itab oynar.

Riyayi-zahidi-xüşkün sima’indən nolur hasil,
Xoş ol kim, rindi-meyxarə, içib cami-şərab oynar.

Bu qəmlər kim, mənim vardır, bə’irin başinə qoysan,
Çıxar kafər cəhənnəmdən, gülər əhli-əzab, oynar.

Qılır göz pərdəsin xunabi-həsrət çak hər dəm kim,
Rüxündə ləzzəti-didar zövqindən niqab oynar.

Füzuli, rəşkdən titrər dili-pürxuni üşşaqın,
Binaguşində yarın hər zaman kim, lə’li-nab oynar.


113


Ah eylədigim sərvi-xuramanın üçündür,
Qan ağıladığm qönçeyi-xəndanın üçündür.

Sərgəştəligim kakili-mişkinin ucundan,
Aşüftəligim zülfi-pərişanın üçündür.

Bimar tənim nərgisi-məstin ələmindən,
Xunin cigərim lə’li-dürəfşanın üçündür.

Yaqdım tənimi vəsl günü şəm, tək, əmma,
Bil kim, bu tədarük şəbi-hicranın üçündür.

Qurtarmağa yəğmayi-qəmindən dilü canı,
Sə’yim nəzəri-nərgisi-fəttanın üçündür.

Can ver, könül, ol qəmzəyə kim, bunca zamanlar,
Can içrə səni bəslədigim anın üçündür.

Vaiz bizə dün duzəxi vəsf etdi, Füzuli,
Ol vəsf sənin külbeyi-əhzanın üçündür.


114


Qansı gülşən gülbüni sərvi-xuramanınca var?
Qansı gülbün üzrə qönçə, lə’li-xəndanınca var?

Qansı gülzar içrə bir gül açılır hüsnün kimi,
Qansı gül bərgi ləbi-lə’li-dürəfşanınca var?

Qansı bağın var bir nəxli, qədin tək barvər,
Qansı nəxlin hasili sibi-zənəxdanınca var?

Qansı xuni sən kimi cəlladə olmuşdur əsir,
Qansı cəlladın qılıncı tiği-müjganınca var?

Qansı bəzm olmuş münəvvər bir qədin tək şəm’dən,
Qansı şəm’in şö’ləsi rüxsari-tabanınca var?

Qansı yerdə bulunur nisbət sənə bir gənci-hüsn,
Qansı gəncin əjdəri zülfi-pərişanınca var?

Qansı gülşən bülbülün derlər, Füzuli, sən kimi,
Qansı bülbülün sürudi ahü əfğanınca var?


115


Vəh nə qamət, nə qiyamət, bu nə şaxi-güli-tərdir?!
Nə bəladır nəzər əhlinə, nə xoş məddi-nəzərdir?

Göz yoludur ki, könül mülkünə xublar girər ondan,
Tutma, ey əşk, onu billah ki, əcəb rahgüzərdir.

Nə gühər bulsa bəgənməz, buraxır yazıya dərya,
Qaliba, kim ona məqsud dişin kimi gühərdir.

Eşq eybini bilibsən hünər, ey zahidi-qaftl,
Hünərin eybdir, əmma dedigin eyb hünərdir.

Sitəmin gərçi yamandır, onu tərk elləmə, billah
Ki, təğafül, sitəmindən dəxi əlbəttə, betərdir.

Axir olmaz necə kim, göz yaşı axarsa, həmana
Ki, dəmadəm ona imdad qılan xuni-cigərdir.

Sərsəri basma qədəm eşq təriqinə, Füzuli,
Ehtiyat eylə ki, qayətdə xətərnak səfərdir.


116


Hüsnün olduqca füzun, eşq əhli artıq zar olur,
Hüsn nə miqdar olursa, eşq ol miqdar olur.

Cənnət üçün mən’ edən aşiqləri didardən,
Bilməmiş kim, cənnəti aşiqlərin didar olur.

Eşq dərdindən olur aşiq mizaci müstəqim,
Aşiqin dərdinə timar etsələr, bimar olur.

Zahidi-xudbin nə bilsin zövqini eşq əhlinin,
Bir əcəb meydir məhəbbət kim, içən huşyar olur.

Eşq sevdasinə sərf eylər Füzuli ömrünü,
Bilməzəm, bu xabi-qəflətdən qaçan bidar olur.


117


Ey gül, nə əcəb silsileyi-mişki-tərin var,
Vey sərv, nə xoş canalıcı işvələrin var!

Acıtdı məni, acı sözün, tünd nigahın,
Ey nəxli-məlahət, nə bəla, təlx bərin var!

Peykanları ilə doludur çeşmi-pürabım,
Ey bəhr, saqınma, sənin ancaq gühərin var!

Ol səngdilə naleyi-zarın əsər etmiş,
Ey dil, sənə bu zövq yetər, ta əsərin var.

Eşq içrə, könül, demə ki, mən bixüdəm, ancaq,
Ey qafil, özündən sənin ancaq xəbərin var?

Dedim yetər, et cövr, çü xaki-rəhin oldum,
Dedi ki, yetər cövr sənə ta əsərin var.

Çox baxdığına qəmzə ilən bağrın əzərsən,
Hər kimə ki, baxmazsan onunla nəzərin var.

Eşq əhlinə ol mah, Füzuli, nəzər etmiş,
Sən həm, özünü göstər əgər bir hünərin var.


118


Ləhzə-ləhzə ləbin anıb edicək əfqanlar,
Qətrə-qətrə saçılır didələrimdən qanlar.

Qətrə-qətrə demə qandır ki, çıxar çeşmimdən
Dəmbədəm könlüm odilə əriyən peykanlar.

Qaşların yayinə meyl eyləyəli canü könül,
Dünü gün mən bilirəm kim, nə çəkirlər anlar.

Açma kakil girəhin, başın üçün görmə rəva
Ki, pərişan olalar, bir neçə sərgərdanlar.

Yel dəgər zülfünə, ya qoymayıb öz hali ilə,
Gəzdirərlər onu əldən-ələ hər dəm canlar.

Eylə üşşaqə cəfalər ki, vəfalər görəsən,
Sanma kim, zaye’ olur eylədigin ehsanlar.

Sorma zöhhadə, Füzuli, rəhü rəsmin eşqin,
Nə bilirlər rəvişi-əhli-xirəd nadanlar!


119


Tökdükcə qanımı oxun, ol asitan içər,
Bir yerdəyəm əsir ki, toprağ qan içər.

Əhli-zəmanə qanına çox təşnədir zəmin,
Qanın kimin tökərsə fələk, ol zəman içər.

Mey içmədən açılmaz imiş babi-məğfirət,
Sövgəndlər bu babdə piri-müğan içər.

Üqbadə Kövsər istəməsin rindi-meykədə,
Dünyadə bəs degilmi meyi-ərğəvan içər?

Qəmzən görünməyib gözə, qanlar içər müdam,
Zahid kimi ki, badəni eldən nihan içər.

Meydən əgərçi tövbə verir el Füzuliyə,
Ey sərv, sən qədəh sunar olsan, rəvan içər.


120


Girib meyxanəyə, müğ məşrəbilə kim ki, xu eylər,
Olub mö’min, behişti, kafərəm, gər arizu eylər.

Məgər divanədir sevdayi-əbrusilə zahid kim,
Baxıb mehrabə daim, öz-özilə göftgu eylər.

Dəmadəm qətrə-qətrə qan yaşımdır kim, çıxar gözdən
Və ya peykanların kim, atəşi-dil onu su eylər.

Rəhi eşqində olman təngdil sevda hücumundan,
Təriqi-səltənət hər kim tutar, qovğayə xu eylər.

Dedim: “kimdir pərişan eyləyən aşiqlər əhvalın?”
Səba göstərdi tari-sünbüli-zülfün ki: “bu eylər!”

Füzuli zülfünə bağılandı, əmma öylə incəldi
Ki, guya zə’f onu həm zülfünə bir tari-mu eylər.


121


Saçın əndişəsi təhriki-zənciri-cünunumdur.
Cünunum dəf’inə zikri-ləbi-lə’lin füsunumdur.

Diyari-dərd sərgərdaniyəm, hər kim məni istər,
Dəlili-rah qətrə-qətrə əşki-laləgunumdur.

Fələkdə bərqi-ahimdən sərasər yandı kövkəblər,
Qalan odlara yanmış kövkəbi-bəxti-zəbunumdur.

Gələn navəklərin bir-bir yaqıb qoymaz bulam zövqin,
Məni hirman oduna yandıran suzi-dərunumdur.

Səri-kuyində könlüm bərqi-ahın sanma bihudə,
Qaranğu gecə əzmi-kuyin etsəm, rəhnümunumdur.

Ləbi şirinlərin zövqilə Fərhadi mənəm əsrin,
Yanımda cəm olan səngi-məlamət Bisütunumdur.

Füzuli, xali olmaq cami-eyşim saf səhbadən,
Nişani-bəxti-nafərcamü iqbali-nigunumdur.


122


Məndə Məcnundan füzun aşiqlik iste’dadı var,
Aşiqi-sadiq mənəm, Məcnunun ancaq adı var.

Nola qan tökməkdə mahir olsa çeşmim mərdümi,
Nütfeyi-qabildürür, qəmzən kimi ustadı var.

Qıl təfaxür kim, sənin həm var mən tək aşiqin,
Leylinin Məcnunu, Şirinin əgər Fərhadı var.

Əhli-təmkinəm, məni bənzətmə, ey gül, bülbülə,
Dərdə yox səbri onun, hər ləhzə min fəryadı var.

Öylə bədhaləm kim, əhvalım görəndə şad olur,
Hər kimin kim, dövr cövründən dili-naşadı var.

Gəzmə, ey könlüm quşu, qafil fəzayi-eşqdə
Kim, bu səhranın güzərgəhlərdə çox səyyadı var.

Ey Füzuli, eşq mən’in qılma nasehdən qəbul,
Əql tədbiridir ol, sanma ki, bir bünyadı var.


123


Müqəvvəs qaşların kim, vəsmə birlə rəng tutmuşlar,
Qılınclardır ki, qanlar tökmək ilə jəng tutmuşlar.

Qılıb təğyiri-surət vəsmədən yəğma qılırlar dil,
Hərami qaşların rəsmü rəhi-neyrəng tutmuşlar.

Könül mir’atını eylər mükəddər əql təklifi,
Xoş ol bibaklər kim, tərki-namü nəng tutmuşlar.

Fəzayi-ömrdən guya degillər qönçə tək vaqif
Olar kim, özlərin dünya üçün diltəng tutmuşlar.

Məni, kim səngsari-möhnətəm bazari-eşq içrə,
Bəla daği çəkən Fərhad ilə həmsəng tutmuşlar.

Ləbin dövründə zahidlər tutub meyxanələr küncün,
Qılıb təsbih tarın tərk, zülfi-çəng tutmuşlar.

Səhər bülbüllər əfğanı degil bihudə gülşəndə,
Füzuli naleyi-dilsuzinə ahəng tutmuşlar.


124


Aşiyani-mürği-dil zülfi-pərişanındadır,
Qanda olsam, ey pəri, könlüm sənin yanındadır.

Eşq dərdilə xoşam, əl çək əlacımdan, təbib,
Qılma dərman kim, həlakim zəhri-dərmanındadır.

Çəkmə damən, naz edib, üftadələrdən, vəhm qıl,
Göglərə açılmasın əllər ki, damanındadır.

Gözlərim yaşın görüb şur, etmə nifrət kim, bu həm
Ol nəməkdəndir ki, lə’li-şəkkərəfşanındadır.

Məsti-xabi-naz olub, cəm’ et dili-sədparəmi
Kim, onun hər parəsi bir növki-müjganındadır.

Bəs ki, hicranındadır xasiyyəti-qət’i-həyat,
Ol həyat əhlinə heyranəm ki, hicranındadır.

Ey Füzuli, şəm’ tək mütləq açılmaz yanmadan,
Tablar kim, sünbülündən rişteyi-canındadır.


125


Saqiya, cam tut ol aşiqə kim, qayğuludur,
Qayğu çəkmək nə üçün, cam ilə aləm doludur.

Təlx göftarsız olmaz ləbi-yar, ey aşiq,
Çox həvəs eyləmə ol şərbətə kim, ağuludur.

Qoyalım başı xümi-badə əyağinə gəlin,
Tutmamaq olmaz onun hörmətini, bir uludur.

Bunca kim, kuhsifət başimə daşlar urulur,
Dideyi-bəxtim oyanmaz, nə ağr uyğuludur.

Dili-pürxunimə yağıdırma bəla peykanın,
Həzər et, şişəyə, nagəh zərər eylər, doludur.

Könlümün zəxminə peykanını etdim mərhəm,
Gənci-qəmdir, nola gər böylə dəmir qapuludur.

Nərgisin fikri, Füzuli, gözü könlümdə gəzər,
Tutar ahu vətən ol yerdə ki, otlu, suludur.


126


Məni zikr etməz el, əfsaneyi-Məcnunə mayildir,
Nə bənzər ol mənə, dərdi onun dərmanə qabildir.

Biyabanlarda Məcnundan qəmü dərdim sual etmin,
Nə bilsin bəhr halın ol ki, mənzilgahi sahildir.

Mənim tək ola bilməz şöhreyi-şəhri-bəla Məcnun,
Qəbul eylərmi bu rüsvalığ hər kim ki, aqildir.

Nə müşkil halı olsa aşiqin mə’şuq edər çarə,
Gər ol bidərd bilməzsə bu hali, hal müşkildir.

Fəraq əyyami seylabi-sirişkimdən xəbər tutmaz,
Qiyamət macərasından gör, ol zalim nə qafildir.

Fəqihi-mədrəsə mə’zurdur inkari-eşq etsə,
Yox özgə elminə inkarımız, bu elmə cahildir.

Füzuli, el səni Məcnundan əfzun der məlamətdə,
Buna münkir degil, Məcnun dəxi mə’qulə qaildir.


127


Ol pərivəş kim, məlahət mülkünün sultanıdır,
Hökm onun hökmüdürür, fərman onun fərmanıdır.

Sürdü Məcnun növbətin, indi mənəm rüsvayi-eşq,
Doğru derlər: hər zaman bir aşiqin dövranıdır.

Ləhzə-ləhzə könlüm odundan şərərlərdir çıxan,
Qətrə-qətrə göz tökən sanmın sirişkim qanıdır.

Çaklər cismimdə tiği-eşqdən eyb etməyiz
Kim, cünun gülzarının bunlar güli-xəndanıdır.

Ey Füzuli, ola kim rəhm edə yar əfğaninə,
Ağılagil zar, onca kim, zar ağılamaq imkanıdır.


128


Mənim kim, bir ləbi-xəndan üçün giryanlığm vardır,
Pərişan türrələr dövründə sərgərdanlığm vardır.

Yaşım təxti-rəvandır, taci-zərrin şö’leyi-ahim,
Görün kim, dövləti-eşq ilə nə sultanlığm vardır?

Yumulmaz əşk tüğyanından ansız çeşmi-xunbarım,
Xəyali-surəti-cananə xoş heyranlığm vardır.

Sirişkim gör, məni, ey əbr, özündən kəm xəyal etmə,
Həvayi-eşq ilə min səncə əşkəfşanlığm vardır.

Ləbin dövründə kim, insan olan can der ona mütləq
Əgər abi-həyat etsəm tələb, heyvanlığm vardır.

Füzuli cami-mey tərkin qılıb, zöhd ilə təqvadən
Qamu danayə rövşəndir bu, kim, nadanlığm vardır.


129


Zövq şövqilə cəhan qeydin çəkən zəhmət çəkər,
Əhli-zövq oldur kim, ondan daməni-himmət çəkər.

Gün çəkər yerdən gögə hər dəm qübari-rahini,
Tutiya içün, bəli, yerdən gögə minnət çəkər.

Ey çəkən qeyr ilə pünhan bəzm edib mey gah-gah,
Yad qıl ondan ki, bəzmin yad edib həsrət çəkər.

Xali etmiş qeyrdən zülfün xəyali könlümü,
Nola sahibkəşf ilə bir ömrdür xəlvət çəkər.

Çək, səbuhi, sübh nəqqaşinə ərzi-ariz et,
Böylə çəksin, kim fələk lövhinə bir surət çəkər.

Sərvqamətlər səmənrüxsarlər toprağıdır,
Hər səmən kim, açılır, hər sərv kim, qamət çəkər.

Qətreyi-əşkim qətarı, sinə çakindən girib,
Tən evinə dışradan bari-qəmü möhnət çəkər.

Ey Füzuli, baxmayam ta qeyrə, hər xunin müjə
Atəşin bir mildir kim, çeşmimə qeyrət çəkər.


130


Hər kitabə kim, ləbi-lə’lin hədisin yazələr,
Rişteyi-can birlə zövq əhli onu şirazələr.

Bu nə sirdir, sirri-eşqin demədən bir kimsəyə,
Şəhrə düşmüş “mən səni sevdim” deyən avazələr.

Şeyxlər meyxanədən üz döndərərlər məscidə,
Bitəriqətlər gərək kim, doğru yoldan azələr.

Çaklər göksümdə, sanmın kim, açıbdır tiği-eşq
Könlümün şəhrinə mehrin girməyə dərvazələr.

Ey Füzuli, yar əgər cövr etsə, ondan incimə,
Yar cövrü aşiqə hər dəm məhəbbət tazələr.


131


Seyr qıl, gör kim, gülüstanın nə abü tabı var,
Hər tərəf min sərvi-sərsəbzü güli-sirabı var.

Pəncəyi-bərgi-çinar etmiş mühəyya şanələr,
Anlamış guya ki, sünbül kakilinin tabı var.

Rahət içün fərş salmış məbzeyi-tər gülşənə,
Nərgisin görmüş gözün məxmur, sanmış xabı var.

Bulunur hər dərdə istərsən, gülüstanda dəva,
Höqqəsində qönçənin guya şəfa cüllabı var.

Güldü gül, açıldı nərgis, lalə doldu jalədən,
Ey xoş ol kim, işrətü eyş etməyə əsbabı var.

Qalib olmuş xəlqə zövqi-seyri-gülşən, guiya
Çəkməyə xəlqi bənəfşə zülfünün qüllabı var.

Gər Füzuli meyli-gülzar etsə fəsli-gül, nola
Eyş üçün xunabeyi-dildən şərabi-nabı var.


132


Sərvi-azad qədinilə mana yeksan görünür,
Nəyə sərgəştə olan baxsa, xuraman görünür.

Can görünməz desələr təndə inanman, nişə kim,
Lütfdən hər necə baxsam təninə, can görünür.

Derəm əhvalımı cananə qılam ərz, vəli,
Görə bilmən özümü onda ki, canan görünür.

Ey deyən: səbr qıl, ah eyləmə yari görcək,
Mənə düşvardır ol, gər sənə asan görünür.

Sordum əhvalımı eşqində münəccimlərdən,
Baxdılar tale’ evinə, dedilər: qan görünür.

Nə kəmandarsan, ey məh, ki, atıb qəmzə oxun,
Yıxdığın seyddə nə zəxm, nə peykan görünür.

Bir sənəm zülfünə guya ki, veribdir könlün
Ki, Füzulinin ikən halı pərişan görünür.


133


Süluki-fəqr ətvarım, məzaqi-eşq halımdır,
Təcərrüd aləmi seyrində aləm payimalımdır.

Xəyalımda budur kim, bulmuşam aləmdə bir xilqət,
Nə aləm, qanğ xilqət, sandığm batil xəyalımdır.

Cünun feyzilə azad olmuşam qeydi-əlayiqdən,
Kəmalü fəzl tərki, rütbeyi-fəzlü kəmalımdır.

Mənəm şəm’i-vüsalə yandıran pərvanəvəş varın,
Fənayi-mütləqim canan ilə bəzmi-vüsalımdır.

Təbiba, qılmışam təşxis, dərdi-eşqdir dərdim,
Əlamət ahi-sərdü ruyi-zərdü əşki-alımdır.

Həvadən mövcə gəlmiş bəhri-dərdəm, şahidi-halım
Dili-püriztirabü naleyi-bie’tidalımdır.

Füzuli, aləmi-fəqrü fənadə mün’imi-vəqtəm,
Diyari-məskənət, nəqdi-qənaət mülkü malımdır.


134


Şəfayi-vəsl qədrin hicr ilə bimar olandan sor,
Zülali-zövq şövqün təşneyi-didar olandan sor.

Ləbin sirrin gəlib göftarə, məndən özgədən sorma,
Bu pünhan nüktəni bir vaqifi-əsrar olandan sor.

Gözü yaşlıların halın nə bilsin mərdümi-qafil,
Kəvakib seyrini şəb ta səhər bidar olandan sor.

Xəbərsiz olma fəttan gözlərin cövrün çəkənlərdən,
Xəbərsiz məstlər bidadını hüşyar olandan sor.

Qəmindən şəm’ tək yandım, səbadən sorma əhvalım,
Bu əhvalı şəbi-hicran mənimlə yar olandan sor.

Xərabi-cami-eşqəm, nərgisi-məstin bilir halım,
Xərabat əhlinin halini bir xummar olandan sor.

Məhəbbət ləzzətindən bixəbərdir zahidi-qafil,
Füzuli, eşq zövqün, zövqi-eşqi var olandan sor.


135


1 Deməyin



Xəm açıldıqca zülfündən bəlavü möhnətim artar,
Bihəmdillah ki, ömrüm uzanar, cəm’iyyətim artar.

Demən1 [1] əksik məni tədric ilə yaqut olan daşdan,
Boyandıqca cigər qanilə qədrü qiymətim artar.

Tuta gör göz yolun, ey əşk, kim, təmkinim əksikdir,
Bu surətxanənin gördükcə nəqşin heyrətim artar.

Mərizi-dərdi-eşqəm, tərki-aləmdir muradım kim,
Bu naxoş mülkdə əyləndigimcə zəhmətim artar.

Büküldü qamətim həsrət yükündən, vəh ki, aləmdə
Ümidim əksilib hər ləhzə yüz min, həsrətim artar.

Nə şərbətdir qəmin kim, içdigimcə əksilir səbrim,
Nə sehr eylər rüxün kim, baxdığmca rəğıbətim artar.

Çox olduqca qəmü dərdim rəhi-eşq içrə xoşhaləm,
Füzuli, şad olub şükr etməyimmi, ne’mətim artar.


136


Nola gər rəşki-rüxsarinlə bağrı xubların qandır,
Daşı tə’sir ilə lə’l eyləyən xurşidi-rəxşandır.

Müjən gər səngdillər könlünü alsa əcəb olmaz,
Onun tək abnus ox layiqi-fulad peykandır.

Pərivəşlər dili-səxtinə düşmüş mehri-rüxsarın,
Sənin əksin alan fulad güzgulər firavandır.

Dəhanın dürci kim, qeydin çəkərlər hurpeykərlər,
Pərilər ta’ətiçün xatəmi-mülki-Süleymandır.

Atın yolunda xublar sürsələr üz nola əmrinlə,
Mələk xeyli sücudi-Adəm etmək nəssi-Qur’andır.

Qatı könlünə bağrı daşların düşmüş qəmi-eşqin,
Bir oddur eşqi-dilsuzun ki, daşlar içrə pünhandır.

Gəzər kuyində hər yan çox giribançak gülrüxlər,
Bu rəng ilə Füzuli, ol səri-ku bir gülüstandır.


137


Səbrim alıb fələk, mənə yüz min bəla verər,
Az olsa bir məta’, ona el çox bəha verər.

Düşdüm bəlayi-eşqə, xirədməndi-əsr ikən,
El şimdi məndən aldığ pəndi mana verər.

Sanmın əcəb, rütəb yerinə versə lə’li-tər
Nəxli ki, qan yaşım ona nəşvü nəma verər.

Xaki-dərindir ol ki, dünü gün səvab üçün,
Həm ayə sürmə, həm günəşə tutiya verər.

Qılmaz qəbul surəti-iqbal bunca kim,
Ayineyi-vücuduma cövrin cila verər.

Ney kimi cismim oldu oxundan dəlik-dəlik,
Dəm urduğumca yerli-yerindən səda verər.

Hər dərdsizdən umma, Füzuli, dəvayi-dərd,
Səbr eylə, kim ki, dərd veribdir, dəva verər.


138


Əzəl katibləri üşşaq bəxtin qarə yazmışlar,
Bu məzmun ilə xət ol səfheyi-rüxsarə yazmışlar.

Xəvasi-xaki-payin şərhini təhqiq edib mərdüm,
Qübarilə bəyazi-dideyi-xunbarə yazmışlar.

Gülüstani-səri-kuyin kitabın bab-bab, ey gül,
Xəti-reyhan ilə cədvəl çəkib, gülzarə yazmışlar.

Iki sətr eyləyib ol iki meygun lə’llər vəsfin,
Görənlər hər birin bir çeşmi-gövhərbarə yazmışlar.

Girib bütxanəyə qılsan təkəllüm, can bulur, şəksiz,
Müsəvvirlər nə surət kim, dərü divarə yazmışlar.

Mühərrirlər yazanda hər kəsə aləmdə bir ruzi,
Mənə hər gün dili-sədparədən bir parə yazmışlar.

Yazanda Vamiqü Fərhadü Məcnun vəsfin əhli-dərd
Füzuli adını, gördüm, səri-tumarə yazmışlar.


139


Buldu kuyindən dəva dərdi-dili-bimarımız,
Sən ağasan, biz quluz, kuyindədir timarımız.

Zahida, gör sinə çakın şö’ləsin, bizdən saqın,
Bir ocağız biz ki, suzandır dərü divarımız.

Nola gər olduysa fani Kuhkən, mən baqiyəm,
Eşqə bizdəndir bəqa, yoxdur yox olmaq varımız.

Gülşəni-qəm nəxliyüz, pərvərdə abi-didədən,
Dağılər bərg, ahi-atəşbarımızdır barımız.

Əhli-tərkin quluyuz, oldur bizə candan əziz,
Yusif isə xudfüruş, onunla yox bazarımız.

Əşkimiz girdabı ali, ömrümüz bünyadı pəst,
Gör nə alçaq dirlikilə cizginir pərgarımız.

Ey Füzuli, cövri-yarü tə’neyi-əğyardən
Var yüz min qəm, bu həm bir qəm ki, yox qəmxarımız.


140


Xəm qədilə ağılaram ol türreyi-tərrarsız,
Gərçi derlər çəngdən çıxmaz tərənnüm tarsız.

Sineyi-çakimdən əksik etmə tiri-qəmzəni,
Ey güli-rə’na, bilirsən kim, gül olmaz xarsız.

Saxlamazdım navəkin gözdə, bəlasın çəkməsəm,
Su verib ol nəxli bəslərdimmi olsa barsız?

Yol azarsan zülməti-heyrətdə, ey dil, vaqif ol,
Zinhar, ol kuyə varma ahi-atəşbarsız.

Giryəyi-zar ilə xoşhaləm ki, bəhri-eşqdə,
Əşksiz göz bir sədəfdir, lö’löi-şəhvarsız.

Canə azari-xədəngin xoş gəlir, ey qaşı yay,
Bir sifariş qıl ki, bizdən ötməsin azarsız.

Zöhddən keçməz Füzuli, eyləməz tərki-riya,
Pənd çox verdim, eşitməz arsızdır, arsız.


141


Təriqi-fəqr tutsam təb’ tabe’, nəfs ram olmaz,
Qina qılsam tələb, əsbabi-cəmiyyət təmam olmaz.

Dəhanından əsər görmən, miyanındən nişan, vəh kimi
Məni-nakamə ömrümdən müyəssər hiç kam olmaz.

Müqimi-kuyi-dərd eylər məni ahi-cigərsuzim,
Bu ahəngi-məlaləfzayə bundan yey məqam olmaz.

Müridi-saqiyəm kim lütfi əhli-zövqə daimdir,
Nə hasil əhli-zöhdün şəfqətindən kim, müdam olmaz.

Dedim: üşşaqə cövr etmə; dedi ol xublar şahi:
Siyasət olmayınca eşq mülkündə nizam olmaz!

Ləbindən qətrə-qətrə qan içər könlüm kərahətsiz,
Şəkərdən olıcaq mey qətrəsi guya həram olmaz.

Füzulini məlamət eyləyən bidərd bilməzmi
Ki, bazari-cünun rüsvalarında nəngü nam olmaz.


142


Aləm oldu şad səndən, mən əsiri-qəm hənuz,
Aləm etdi tərki-qəm, məndə qəmi-aləm hənuz.

Can bağşlardı ləbin izhari-göftar eyləyib,
Urmadan Isa ləbi canbəxşlikdən dəm hənuz.

Səcdəgah etmişdi eşq əhli qaşın mehrabini,
Qılmadan xeyli-məlaik səcdeyi-Adəm hənuz.

Canə dərdin, cismə peykanın rəvan etmişdi hökm,
Cismilə can irtibatı olmadan möhkəm hənuz.

Əşk sərf eylər fələkdən kam hasil qılmağa,
Bu gühər qədrini bilməz dideyi-pürnəm hənuz.

Pərdeyi-çeşmim məqam etmişdi bir tərsabeçə,
Olmadan məhdi-Məsiha daməni-Məryəm hənuz.

Ey Füzuli, eylədi hər dərdə dərman ol təbib,
Bir mənim zəxmimdir ancaq bulmayan mərhəm hənuz.


143


Qəmzə peykanın gözün mən mübtəladən saxlamaz,
Sərf edər əhli-nəzər, nəqdin gədadən saxlamaz.

Dil nədir yanımda, çün qılmaz məni qəmdən xilas,
Çəkmən ol tə’viz barın kim, bəladən saxlamaz.

Canə cismim ol xədəngi-qəmzədən olmaz pənah,
Hiç cövşən kimsəni tiri-qəzadən saxlamaz.

Eşqdən bir dəm təni-suzanı dur etməz fələk,
Vəh necə fanusdur, şəm’i həvadən saxlamaz.

Aləmi şeyda qılır, gər olsa gözdən həm nihan,
Bir pərivəş kim, səri-zülfün səbadən saxlamaz.

Eylərəm bixud fəğan, gördükcə kuyin itlərin,
Aşina razi-nihanın aşinadən saxlamaz.

Bisəbəb sanmın Füzulinin məlamət çəkdigin,
Bixəbərdir, məşrəbin əhli-riyadən saxlamaz.


144


Razi-eşqin saxlaram eldən nihan, ey sərvinaz,
Getsə başım şəm’ tək, mümkün degil ifşayi-raz.

Xublər mehrabi-əbrusinə meyl etməz fəqih
Ölsə kafərdir, müsəlmanlar, ona qılmın nəmaz.

Kimsə ol bədxuyə izhar edə bilməz halımı,
Ey sürudi-nalə, Tanriçün, sən olğıl çarəsaz.

Qalibim görmüş tühi, tökmək dilər bir tazə ruh,
Bərqi-ahim kim, gələn peykanına vermiş güdaz.

Xubsurətlərdən, ey naseh, məni mən’ etmə kim,
Pərtövi-ənvari-xurşidi-həqiqətdir məcaz.

Mən xud öldüm, ey türabımdan olan sağər, müdam
Rindlər bəzmin gəzib, bir-bir yetir məndən niyaz.

Ey Füzuli, qalmışam heyrətdə, bilmən neyləyim,
Dövr – zalim, bəxt – nafərcam, tələb – çox, ömr – az.


145


Fəğan kim, bağrımın ol lalərüx qan olduğun bilməz,
Cigər pərkaləsində daği-pünhan olduğun bilməz.

Həbibim könlümü cəm’ eyləməz rüxsarı dövründə,
Məgər zülfü kimi halim pərişan olduğun bilməz?

Qılır təqsir edib bir lütf hərdəm könlüm almaqdan,
Vəfa rəsmin sanır düşvar, asan olduğun bilməz.

Gözəllər dövləti-vəslin bulub, məğrur olan aşiq
Nişati-vəsldə ənduhi-hicran olduğun bilməz.

Dili-sədparədən bidad kəsməz qəmzeyi-məstin,
Nə qafil padişəhdir, mülk viran olduğun bilməz.

Sanır zahid özün xali xəyalından, qələtdir bu,
Bu heyran olduğundandır ki, heyran olduğun bilməz.

Füzuli xəstəyə düşmən sözilə dust cövr eylər,
Zəhi sadə, müariz qövlə böhtan olduğun bilməz.


146


Səgridir cilvəyə ol sərv səməndin yenəməz,
Kim onu görsə fəğan etməyə kəndin yenəməz.

Gərçi şümşad lətafətdə çəkibdir gögə baş,
Naz bəhsində onun sərvi-büləndin yenəməz.

Eylə divanəligə düşdü könül kim, dildar
Salsa gər boynuna həm zülfi-kəməndin yenəməz.

Qaça bilməz dili-divanə saçın qeydindən,
Netsin, ol vəhşi ayağındakı bəndin yenəməz.

Edəməz mən’ Füzulini qədəhdən zahid,
Hiç kim kuyi-xərabat ləvəndin yenəməz.


147


Könüldə min qəmim vardır ki, pünhan eyləmək olmaz,
Bu həm bir qəm ki, el tə’nindən əfğan eyləmək olmaz.

Nə müşkül dərd olursa bulunur aləmdə dərmanı,
Nə müşkül dərd imiş eşqin ki, dərman eyləmək olmaz.

Fəna mülkünə çox əzm etmə, ey dil, çəkmə zəhmət kim,
Bu tədbir ilə dəf’i-dərdi-hicran eyləmək olmaz.

Saqın, könlüm yıxarsan, pənddən dəm urma, ey naseh,
Həvayi-nəfs ilə bir mülkü viran eyləmək olmaz!

Dəhanın üzrə lə’lin istəmiş dil, dəf’i müşküldür,
Görünməz hiç cürmü, yox yerə qan eyləmək olmaz.

Dualar eylərəm, məndən yana bir dəm güzar etməz,
Nə çarə, sehrilə sərvi xuraman eyləmək olmaz.

Füzuli, aləmi-qeyd içrəsən, dəm urma eşqindən,
Kəmali-cəhl ilə də’vayi-irfan eyləmək olmaz.


148


Neçə illərdir səri-kuyi-məlamət bəkləriz,
Ləşkəri-sultani-irfaniz, vilayət bəkləriz.

Sakini-xaki-dəri-meyxanəyiz şamü səhər,
Irtifa’i-qədr üçün babi-səadət bəkləriz.

Ciffeyi-dünya degil kərkəs kimi mətlubumuz,
Bir bölük ənqaləriz, Qafi-qənaət bəkləriz.

Xab görməz çeşmimiz əndişeyi-əğyardən,
Pasibanuz, gənci-əsrari-məhəbbət bəkləriz.

Surəti-divar edibdir heyrəti-eşqin bizi,
Qeyr seyri-bağ edər biz künci-möhnət bəkləriz.

Karivani-rahi-təcridiz xətər xofin çəkib,
Gah Məcnun, gah mən dövr içrə növbət bəkləriz.

Sanmanız kim, gecələr bihudədir fəryadımız,
Mülki-eşq içrə həsari-istiqamət bəkləriz.

Yatdılar Fərhadü Məcnun məsti-cami-eşq olub,
Ey Füzuli, biz olar yatdıqca söhbət bəkləriz.


149


Təşneyi-cami-vüsalın abi-heyvan istəməz,
Mayili-muri-xətin mülki-Süleyman istəməz.

Zülməti-zülfün giriftari dəm urmaz nurdən,
Talibi-şəm’i-rüxün xurşidi-rəxşan istəməz.

Eyləməz meyli behişt üftadeyi-xaki-dərin,
Sakini-künci-qəmin seyri-gülüstan istəməz.

Cövrdən ah etmə, ey aşiq ki, eyni-lütfdür,
Dust əsbabi-kəmali-hüsnə nöqsan istəməz.

Eşqdən vəhm etməsin aşiq, yıxar könlüm deyib,
Hiç sultanəm deyən mülkünü viran istəməz.

Aşiq isən rindü rüsvalıqdan ikrah etmə kim,
Eşq sirrin iqtizayi-dövr pünhan istəməz.

Ey Füzuli, müttəsil, dövran müxalifdir mana,
Qaliba, ərbabi-iste’dadı dövran istəməz.


150


Xəlqə ağızın sirrini hər dəm qılır izhar söz,
Bu nə sirdir kim, olur hər ləhzə yoxdan var söz.

Artıran söz qədrini sidqilə qədrin artırar,
Kim nə miqdar olsa, əhlin eylər ol miqdar söz.

Ver sözə ehya ki, tutduqca səni xabi-əcəl,
Edə hər saət səni ol uyqudan bidar söz.

Bir nigari-ənbərinxətdir könüllər almağa,
Göstərər hər dəm niqabi-qeybdən rüxsar söz.

Xazini-gəncineyi-əsrardır, hər dəm çəkər
Rişteyi-izharə min-min gövhəri-əsrar söz.

Olmayan qəvvasi-bəhri-mə’rifət arif degil
Kim, sədəf tərkibi-təndir, lö’löi-şəhvar-söz.

Gər çox istərsən, Füzuli, izzətin, az et sözü
Kim, çox olmaqdan qılıbdır çox əzizi xar söz.


151


Mana badi-səba ol sərvi-gülrüxdən xəbər verməz,
Açılmaz qönçeyi-bəxtim, ümidim nəxli bər verməz.

Töküb göz yaşını sənsiz həlakim istərəm, əmma
Əcəl peykinə seyli-əşk girdabi güzər verməz.

Gözümdə məskən et, xari-müjəmdən ehtiraz etmə,
Güli-xəndanə sordum, xarə yar olmaq zərər verməz.

Əgər can almaq istərsən, tənimdən oxunu kəsmə
Ki, pəjmürdə nihalə verməyincə su səmər verməz.

Qiyas et şəm’dən, vəhm eylə çərxin inqilabından
Kim, ol baş almağa qəsd etməyincə taci-zər verməz.

Bəla zimnində rahət olduğun izhar edər xəlqə
Fələk, bihudə xari-xüşkdən gülbərgi-tər verməz.

Füzuli, dəhrdən kam almaq olmaz olmadan giryan,
Sədəf su almayınca əbri-nisandan gühər verməz.


152


Nəmi-əşkim mükəddər xatirimdən dəf’i-qəm qılmaz,
Bu rövşəndir ki, nəm ayinədən jəngar kəm qılmaz.

Xəmi-əbruyi-mişkinini görsə zahidi-kəcbin,
Dəxi qamət sücudi-guşeyi-mehrabə xəm qılmaz.

Sənə, ey şuxi-səngindil, demən büt, nişə kim, büt həm
Əgərçi səngdildir, böylə bidadü sitəm qılmaz.

Cəfavü cövr ilə qan oldu bağrım, yarəb, ol bədxu
Neçün tərk eyləməz bidadü cövrün, bir kərəm qılmaz?

Muradım giryədən kəsbi-qübari-rəhgüzarındır,
Gözüm yaşı dəmadəm çöhrəmi bihudə nəm qılmaz.

Xətin dövründə əşki-al ilə dərdü qəmim şərhin,
Dəm olmaz kim, rüxi-zərd üzrə müjganım rəqəm qılmaz.

Füzuli binəva ta rövzeyi-kuyində sakindir,
Təmənnayi-behiştü meyli-gülzari-Irəm qılmaz.


153


Kuhkəndən gözükür kuhdə asar hənuz,
Ol nə bənzər mana, anın əsəri var hənuz.

Çəkdi Məcnun ayağın badiyədən, leyk verir
Qanlı güllər, ayağından çəkilən xar hənuz.

Vadiyi-eşqdə sevda ilə sərgəştə idim
Gəlmədən gərdişə bu günbədi-dəvvar hənuz.

Nöqteyi-xalinə bağılanmış idi canü könül,
Gəzmədən daireyi-dövrdə pərgar hənuz.

Mahə çəkdim şəbi-hicran ələmi-şö’leyi-ah,
Ah kim, olmadı ol mah xəbərdar hənuz.

Naleyi-zarım ilə xəlqə həram oldu yuxu,
Qarə bəxtim yuxudan olmadı bidar hənuz.

Mərhəmi-vəsli ilə buldu qamu dərdə dəva,
Bu Füzuli ələmi-hicr ilə bimar hənuz.


154


Ey könül, ol xəncəri-müjganə eylərsən həvəs,
Qəsdi-can etdin, bəqayi-ömrdən ümmidi kəs.

Çəkmə qürbət əzminə, ey sariban məhmil, saqın
Kim, bu yolda bimi-qürbətdəndir əfğani-cərəs.

Hali-zarimdən səni əfğanım agah eylədi,
Şükrlillah, oldu fəryadım mənə fəryadrəs.

Bir-birinə bəs ki, sancıldı tənimdə oxlarım,
Mürği-ruhum qeydinə oldu mürəttəb bir qəfəs.

Tə’neyi-əhli-məlamətdən nə nöqsan aşiqə,
Bərqi-lame’ dəf’in eylərmi hücumi-xarü xəs?

Suzi-eşqin təndə nagəh bulmasın nöqsan deyib,
Can çıxınca istərəm çıxmaya təndən bir nəfəs.

Ey Füzuli, mən qənaət mülkünün sultaniyəm,
Səltənət isbatı əgnimdə pəlasi-fəqr bəs.


155


Xaki-rəh etdi aşiqi-miskini ol həvəs
Kim, paybusi-yarə qaçan bula dəstrəs.

Razi-dəruni dışraya salmaq rəva degil,
Budur günahı kim, asılır müttəssil cərəs.

Didari-dustdur iki aləm nəticəsi,
Yox ondan özgə aşiqə aləmdə mültəməs.

Sinəm həvayi-eşqin ilə doldu ney kimi,
Dəm urduğumca ahü fəğandır çıxan nəfəs.

Hər qeyd olursa məhz bəladır ki bülbülə
Gər şaxi-güldən olsa, küdurət verər qəfəs.

Ol qəmzədən, könül, əgər istərsən iltifat,
Tiği-təcərrüd ilə canından əlaqə kəs.

Olmaz vücudi-aşiqə eşq içrə e’tibar,
Dözməz, Füzuli, atəşi-suzanə xarü xəs.


156


Məskən, ey bülbül, sənə gəh şaxi-güldür, gəh qəfəs,
Necə aşiqsən ki, ahindən tutuşmaz xarü xəs?

Yar kuyində gər olsaydı, müsəlmanlar, yerim,
Kafərəm gər rövzeyi-rizvanə eylərdim həvəs.

Kuh fəryadi-sədasin verdi Fərhadın demin,
Nəqşi-Şirindir verir avaz, olub fəryadrəs.

Naqə Leyli məhmilin çəkmiş biyaban seyrinə,
Eylə Məcnunu bu halətdən xəbərdar, ey cərəs!

Bir nəfəs qalmış həyatımdan, həbibim, sübh tək,
Nola gər bir mehr göstərsən mənə axir nəfəs.

Xali etdim dil həvayi-ixtilati-xəlqdən,
Bəzmi-qəmdə ney kimi həmdəm mənə fəryad bəs.

Ey Füzuli, gər sənə cəm’iyyəti-dildir murad,
Bağıla bir dildarə könlün, qeyrdən peyvəndi kəs.


157


Göz yaşımdan suzi-pünhanım edər arif qiyas,
Bixəbər təsiri-əncümdən degil əxtərşünas.

Qandürür kim, dəmbədəm gözdən yenib, örtər tənim,
Dəşti-qəm Məcnuniyəm, mən qandanü qandan libas?

Xiştlər tək bir-biri üzrə cigər pərkaləsin,
Göz yığıb salmış hübabi-xun binasiçün əsas.

Ey sanan julidə mu başında Məcnunun, saqın,
Bitəkəllüf getmə kim, Leyli evidir ol pəlas.

Ləhzə-ləhzə xəm qədim peykanın istər, ya qılır,
Zərrə-zərrə mahi-nov xurşiddən nur iqtibas.

Tiği-qəmzən öylə bürrandır ki, cəlladi-əcəl
Töksə qan tə’cil üçün tiğindən eylər iltimas.

Ey Füzuli, zəhri-qəhrilə doludur tasi-çərx,
Çəkməz onun qəhrini hər kim, çəkər bir dolu tas.


158


Ey xoş ol məst ki, bilməz qəmi-aləm nə imiş,
Nə çəkər aləm üçün qəm, nə bilər qəm nə imiş.

Bir pəri silsileyi-eşqinə düşdüm nagəh,
Şimdi bildim səbəbi-xilqəti-Adəm nə imiş.

Vaiz övsafi-cəhənnəm deyər, ey əhli-vərə’,
Var onun məclisinə, bil ki, cəhənnəm nə imiş.

Oxu köksümdən ötüb, qalmış imiş peykanı,
Ah, bildim səbəbi-ahi-dəmadəm nə imiş.

Ey Füzuli, məzeyi-saqiyü səhba bildin,
Tövbə qıl, ta biləsən zərqü riya həm nə imiş.


159


Bu gün tiğin çəkib, çıxmışdır ol namehriban sərxoş,
Saqın, ey rəhm edən caninə kim, bilməz aman sərxoş.

Ona hüşyar ikən dərdi-dil istərmən deyəm, saqi,
Peyapey sunma camı, qılma ol sərvi rəvan sərxoş.

Degil təqvadən etsəm badə tərkin, vəhmim ondadır
Ki, izhar eyləyim xəlq içrə eşqin nagəhan sərxoş.

Məgər qan içmək ilə əsrümüş nərgislərin, vər nə
Bəsi mey nuş edənlər gördüm, olmaz böylə qan sərxoş.

Meyi-eşqinlə sərməst olduğum eldən nihan qalmaz,
Məhali-əqldir kim, saxlaya razin nihan sərxoş.

Könül ta oldu bixud, aldı qəmzən canımı təndən,
Verər yəğmayə nəqdin, gəncin olğac pasiban sərxoş.

Füzuli, qeyr ilə xəlvət məgər bəzm etmiş ol gülrux,
Rəqibi-kəcrövü gördüm bu gün bari yaman sərxoş.


160


Büti-növrəsim nəmazə şəbü ruz rağib olmuş,
Bu nə dindir, Allah-Allah, bütə səcdə vacib olmuş.

Əsəri-qəbuli-ta’ət ona vermiş öylə halət
Ki, qülubi-əhli-halə hərəkatı cazib olmuş.

Fərəhim görüb, cəfasın həsənatə daxil eylər,
Nə mələk kim, ol pərinin əməlinə katib olmuş.

Nə əcəb gər olsa qəmdən dünümü günüm bərabər,
Nəzərimdən ol üzü gün neçə gün ki, qaib olmuş.

Qəmi-hicrdir kim, artar əsərilə eşq zövqü,
Qələt eyləmiş Füzuli ki, vüsalə talib olmuş.


161


Bilməz idim, bilmək ağızın sirrini düşvar imiş,
Ağızını derlərdi yox, dedikəlrincə var imiş.

Aciz olmuş yıxmağa ah ilə kuhi Kuhkən,
Neyləsin miskin, onun eşqi həm ol miqdar imiş.

Daşə çəkmiş xəlq üçün Fərhad Şirin surətin,
Ərz qılmış xəlqə məhbubin, əcəb biar imiş.

Kə’bə ehraminə zahid, dedilər, bel bağıladı,
Eylədim təhqiq, onun bağılandığ zünnar imiş.

Ömrlərdir eylərəm əhvali-dünya imtəhan,
Noqdi-ömrü hasili-dünya həman bir yar imiş.

Zövqi-didarilə dildarın yox etdim varimi,
Dövləti-baqi ki, derlər, dövləti-didar imiş.

Dün Füzuli arizin görgəc, rəvan tapşırdı can,
Laf edib derdi ki, canım var, əmanətdar imiş.


162


Dil ki, sərmənzili ol zülfi-pərişan olmuş,
Nola cürmi ki, asılmasına fərman olmuş?

Şahsən mülki-məlahətdə, sənə qullar çox,
Biri oldur ki, varıb Misrdə sultan olmuş.

Rəhm edib aşiqini həşr günü yaqmayalar
Ki, bu dünyada əsiri-qəmi-hicran olmuş.

Dedilər, qəm gedirər badə, çox içdim sənsiz,
Qəmi-hicranə müfid olmadı ol qan olmuş.

Bağibani-çəməni-dəhrə xəyali-dəhənin
Səbəbi-tərbiyəti-qönçeyi-xəndan olmuş.

Adəm əvvəl səri-kuyin verib almış cənnət,
Eşidib tə’ni-mələk, sonra peşiman olmuş.

Ey Füzuli, mənim əhvalimə bir vaqif yox,
Böylə kim, aləm onun hüsnünə heyran olmuş.


163


Hübabi-əşki-xunin cismimi eldən nihan etmiş,
Qəmi-eşqin məni-rüsvayi binamü nişan etmiş.

Götürmüş xakdən tüğyani-əşkim xarü xaşaki,
Başım üzrə məlamət quşlariçün aşiyan etmiş.

Büküb möhnət yükündən qəddimi, çıxmış tənimdən can,
Təvafi-kuyin etmək qəsdinə teyyi-məkan etmiş.

Səninlə də’viyi-hüsn etdigiçün mülki-hüsn içrə,
Fələk tə’zir edib Leylini rüsvayi-cəhan etmiş.

Məgər tərkibi-Isa xaki-kuyi-dərgəhindəndir
Ki, durmuş xakdən qədrilə əzmi-asiman etmiş.

Gəzən peykanlarındır təndə, ya can bağinə eşqin
Bəla sərçeşməsindən hər tərəf sular rəvan etmiş.

Füzulidən mizacın münhərif gördüm bu gün yarın,
Məgər fürsət bulub bir şəmmə halından bəyan etmiş?


164


Ta ki, taği-zərnigarın çərx viran eyləmiş,
Xişti-zərrinin səba fərşi-gülüstan eyləmiş.

Katibi-təqdir xətti-səbzə təhrir etməyə
Lövhi-gülzari xəzan bərgi zərəfşan eyləmiş.

Qət’ edib fəsli-xəzan abi-rəvan şirazəsin,
Nüsxeyi-gülzarın övraqın pərişan eyləmiş.

Dövr cövrün gör ki, nüzhətgahi-əhli-zövq ikən,
Cuybari-gülşəni zənciri-zindan eyləmiş.

Eyləmiş tədbiri-təşvişi-xəzan taracının
Lalə, rəngin rəxtini dağ içrə pünhan elyəmiş.

Ruzigarın tirə, bəxtin qarə, nitqin lal edib,
Matəmi-gül bülbüli zağ ilə yeksan eyləmiş.

Ey Füzuli, dəhr halın şaxi-güldən qıl qiyas
Kim, verib əvvəl təcəmmül, sonra üryan eyləmiş.


165


Cismimi yandırma, rəhm et yaşimə, ey bağrı daş!
Ehtiyat et, yanmasın nagəh quru odunda yaş.

Xoş keçər nəzzareyi-hüsnünlə ömrüm, var ümid
Kim, edib məqbuli-dərgahın məni hüsni-məaş.

Tövfi-kuyində ayaqdan başə irmiş bir mədəd,
Nola gər qəddim büküb hərdəm, ayağm olsa baş.

Fitnə yayın qurmağa atəşmi olmuş ehtiyac
Kim, urarsan aləmə atəş, çatıb peyvəstə qaş.

Ey hübabi-əşk, nayab et təni-üryanımı
Kim, bu rüsva pərdəmi çak etdi, sirrim qıldı faş.

Parə-parə könlümün suzi-dərunə tabı yox,
Göz yolundan qətrə-qətrə qan olub, çıxsaydı kaş.

Ey Füzuli, qərqi-xunab etdi göz mərdümlərin,
Görəyim qüllabi-müjganə urulsun qanlı yaş.


166


Zəhi, cəvahiri-ehsani-amə mə’dəni-xas,
Düri-şəfa’ət üçün bəhri-rəhmətə qəvvas.

Yetib hüzurinə me’rac vəqti qılmışlar,
Qəmər hüsuli-məasir, Süheyl kəsbi-xəvas.

Fələk həm ol gecə bulmuş səfa ki, sufi tək
Qərar tutmayıb, olmuş o bəzmdə rəqqas.

Rəhi-mütabi’ətindir təriqi-fövzü nəcat,
Həvayi-mərhəmətindir ümidi-xeyrü xilas.

Təfaxür eylə, Füzuli kim, ondan özgə degil
Sana zəmanədə nəqşi-səhifeyi-ixlas.


167


Xəlqə xublardan vüsali-rahətəfzadır qərəz,
Aşiqə ancaq təsərrüfsüz təmaşadır qərəz.

Zahida, tərk etmə şahidlər vüsali-rahətin,
Gər ibadətdən həmin qilmanü huradır qərəz.

Hurü kövsərdən ki, derlər rövzeyi-rizvanda var,
Saqiyi-gülçöhrəvü cami-müsəffadır qərəz.

Zövqsüz lazım çıxar dünyadan ol dünyapərəst
Kim, ona dünyadan ancaq zövqi-dünyadır qərəz.

Rahət olsaydı qərəz, dünyadə fəqr istərdi xəlq,
Qaliba kim, xəlqə bir bihudə qovğadır qərəz.

Arif ol, sövdayi-eşq inkarın etmə, ey həkim
Kim, vücudi-xəlqdən ancaq bu sevdadır qərəz.

Qıl Füzuli, tərk ibrami-təkəllüm kim, yetər,
Surəti-halın, gər izhari-təmənnadır qərəz.


168


Qıl, səba, könlüm pərişan olduğun cananə ərz,
Surəti-halın bu viran mülkün et sultanə ərz.

Dərhəm olmuş sünbülün guya ki, qılmışdır ona
Mu-bə-mu hali-dilim, dillər uzadıb şanə ərz.

Təndə canım bir pərinindir, əmanət saxlaram
Ol zamandan kim, əmanət qıldılar insanə ərz.

Xəlq küfr əhlinə iman ərz edər, mən dəmbədəm
Küfri-zülfün eylərəm köksümdəki imanə ərz.

Surəti-bican ilə cənnət dolar bütxanə tək,
Qılsalar cənnətdə təsvirin çəkib qılmanə ərz.

Mün’imin ərzi-təcəmmüldür işi fəqr əhlinə,
Nola gər dil qılsa hər dəm dərdi-eşqin canə ərz.

Ey Füzuli, böylə pünhan tutma əşki-alini,
Eylə hər rəngilə kim, var ol güli-xəndanə ərz.


169


Dürcdür lə’li-rəvanbəxşin, düri-şəhvar ləfz,
Dürcdən dürlər tökərsən, eyləsən izhar ləfz.

Öylə ağızın təngdir kim, söyləşir saət sana,
Gərçi nazikdir, verir, əlbəttə, bir azar ləfz.

Yetmək olmaz ləfzi-canbəxşinlə ağızın sirrinə,
Vəhydir guya bu kim, mütləq ağız yox, var ləfz.

Nişə lə’lin gec gəlir göftarə, guya kim, bilir,
Mən kimi, ol lə’ldən ayrılmağ düşvar ləfz.

Qönçə lə’linlə lətafətdən dəm urmuş, bilməzəm,
Neylər izhar eyləgəc ol lə’li-gövhərbar ləfz.

Ey Füzuli, istərəm dildar halim sormaya,
Rəşkdən kim, bulmasın vəsli-ləbi-dildar ləfz.


170


Af’tabi-təl’ətin tutduqca övci-irtifa’,
Qətli-əhli eşqə tiği-qəmzədir ondan şüa’.

Dəşt tutmaq adətin qoymuşdu Məcnun eşqdə,
Şöhreyi-şəhr olmağın rəsmin mən etdim ixtira’.

Zərq dəryasında bir xaşakdır kim, cizginir
Sufiyi-şəyyad kim, dövran tutub eylər sima’.

Keçdigim dünyavü üqbadən səninçün oldu faş,
Doğru derlər: “küllü sirrin cəvəzəl-isneyni şa” [1] .

Ol büti-sərkəş gəlir, salmış cəmalından niqab,
Ey səlamət əl-firaq, ey əqlü iman, əlvida.

Canü dil bir ömrdür tiğinçün eylərlər cədəl,
Girmədən tiğin sənin ortayə, qət’ olmaz niza’.

Ey Füzuli, axirət mülkünə lazımdır səfər,
Böylə fariğ, təqvadən mühəyya qıl məta’.


1 Tərcüməsi: hər sirri ki, ikincidən keçdi, yayılar.


171


Yar vəslin istəyən kəsmək gərək candan təmə’,
Hər kişi kim vəsli-yar istər, kəsin ondan təmə’.

Aruziyi-vəsli-canan, canə afətdir, könül,
Ya tə’əllüq candan üz, ya vəsli-canandan təmə’.

Çün mənə bir zərrə yox tabi-təmaşayi-cəmal,
Mən kiməm, vəsl etmək ol xurşidi-rəxşandan təmə’.

Aşiq oldur kim, təmənnayi-bəlayi-hicr edə,
Yoxsa çoxdur mehr edən ol mahi-tabandan təmə’.

Rişteyi-tuli-əməl dami-bəladır, neyləyim,
Üzmək olmaz ol səri-zülfi-pərişandan təmə’.

Arizin görmək həyatım tazə eylər, vəh nə eyb,
Gər gəda vəchi-mə’aşın qılsa sultandan təmə’.

Müttəsil hirman qılır hasil təmə’dən əhli-hirs,
Türfə kim, artar ona gəldikcə hirmandan təmə’.

İstər olsan həsrətü hirmanə hər dəm düşməmək,
Kəs, Füzuli, dəhrdən ümmidü dövrandan təmə’.


172


Dil uzadır bəhs ilə ol arizi-xəndanə şəm’,
Od çıxar ağızından, etməzmi həzər kim, yanə şəm’.

Nola qeyrət atəşi canım əritsə mum tək,
Bu nə sözdür kim, demişlər arizi-cananə şəm’?

Arizi-canan ilə bəhsi-kəmali-hüsn edər,
Dil ucundandır ki, hər saət düşər nöqsanə şəm’.

Gah ayağ bağılı, gah boynu, nədəndir bilməzəm,
Bir pəri eşqindən olmuşdur məgər divanə şəm’.

Nola canım qamətin istərsə, könlüm arizin,
Rəsmdir aləmdə: bülbül gül sevər, pərvanə şəm’.

Qıl şəbistanı münəvvər kim, nisarın qılmağa,
Riştədən dürlər çəkib cəm’ eyləmiş damanə şəm’.

Ey Füzuli, şövqdən yaqdın tənin ruzi-vüsal,
Netdin, ey qafil, gərəkməzmi şəbi-hicranə şəm’?


173


Gəl, ey rahət sanan əsbab cəm’in, qılma nadanlıq,
Təriqi-fəqr tut kim, fəqr imiş aləmdə sultanlıq.

Murad ər səltənətdən kami-dildir, nəfsə tabe’ sən,
Nə hasil səltənət adilə qılmaq bəndəfərmanlıq.

Pərişanlıqdan, ey xəlqi-cahan, siz cəm edin xatir
Ki, mən cəm eylədim hər qanda vardır bir pərişanlıq.

Nə tale’dir bu kim, aləmdə ağaz etmədim bir iş
Kim, ol işdən sərəncam etmədim, hasil peşimanlıq.

Mənə zülmi-sərih ol kafər eylər, kimsə mən’ etməz,
Füzuli, küfr olurmu gər desəm yoxdur müsəlmanlıq?


174


Saqiya, mey sun ki, dami-qəmdürür huşyarlıq,
Məstlikdir kim, qılır qəm əhlinə qəmxarlıq.

Var fikrin, yox qəmin çəkmək nədir, bir cam ilə,
Bixəbər qıl kim, mənə bir ola yoxluq, varlıq.

Can məta’inin bəhasidir nə kim, dövran verir,
Türfə bu kim, sanıram şəfqətdir ol qəddarlıq.

Məndən axır çün qılır bizarlıq əsbabi-dəhr,
Dəhr əsbabından ol yey kim, qılam bizarlıq.

Tə’neyi-əğyar çəkməkdir işim bir yar üçün
Kim, olub əğyarə yar, eylər mənə əğyarlıq.

Çəkmə zəhmət, çək əlin tədbiri-dərdimdən, təbib
Kim, degil sən bildigin bən çəkdigim bimarlıq.

Ey Füzuli, eylərəm qət’i-tə’əllüq qamudan,
Bu təriq içrə mənə tovfiq edərsə yarlıq.


175


1 Əyağ – qədəh



Eyş üçün bir türfə mənzildir bahar əyyamı bağ,
Onda tutsun qönçəvəş hər kim ki, eyş istər otağ.

Qönçələr açıldı, seyri-bağ edin, ey əhli-dil
Kim, görüb güllər, könüllər açılan çağıdır bu çağ.

Səndən, ey bülbül, füzundur məndə möhnət fəsli-gül,
Sənsənü min tazə gül, hala mənü min tazə dağ.

Bağə sərvim gəldigin bilmiş səhərdən şaxi-gül,
Rövşən etmiş rəhgüzari üzrə hər yan min çirağ.

Çəksələr zəncir ilə gülzarə getmən kim, mənə
Sünbüli-zülfün fəraqından müşəvvəşdir dimağ.

Mövsimi-güldür, vəli getmən çəmən seyrinə kim,
Rövzeyi-kuyin mənə ol seyrdən vermiş fərağ.

Məhrəm olmaz rindlər bəzminə mey nuş etməyən,
Ey Füzuli, çək ayağ ol bəzmdən, ya çək əyağ [1] .


176


Ey xədəngi-qəminə sineyi-əhbab hədəf,
Müntəzir xəncəri-müjganinə canlar səf-səf.

Xaki-dərgahinə hər sübh sürər gün üzünü,
Qaliba ondan ona hasil olubdur bu şərəf.

Haşə lilləh ki, bu divaneyi-şövqi-xətinə
Səbəbi-qeyd ola, zənciri-süturi-müshəf.

Saldı dəryayə səba xəncəri-qəmzən vəhmin
Ki, çıxarmayə dəxi gövhəri-nasüftə sədəf.

Ey könül, aləmə aldanma, sənə rəng verir,
Xakdir kim, onu gəh lə’l qılır, gah xəzəf.

Bəzmi-Cəmşid fəna bulmaq ilə bildim kim,
Dövr cövründən imiş, növheyi-ney, naleyi-dəf.

Ey Füzuli, tələbi-rütbeyi-irfan eylə,
Cəhl ilə hasili-övqati-şərif etmə tələf.


177


Möhnəti-eşq, ey dil, asandır deyib, çox urma Laf,
Eşq bir yükdür ki, xəm olmuş onun altında Qaf.

Olma xali dürdkeşlər söhbətindən, ey könül,
Gər dilərsən edəsən ayineyi-idrakı saf.

Sübhdəm zülfün dağt, ya şam ərzi-ariz et,
Qoyma sübhü şam arasında təriqi-ixtilaf.

Rəşki-rüxsarın dili-xurşidə salmış iztirab,
Qeyrəti-qəddin mizaci-şəm’ə vermiş inhiraf.

Xaki-kuyin Kə’bəyə nisbət qılan bilməzmi kim,
Bunda hərdəm, onda bir növbət olur vacib təvaf.

Vəhmim ondandır ki, mümkün olmaya qəmdən nicat,
Fərric allahümmə həmmi, nəccini mimma nəxaf [1] .

Ey Füzuli, zahid ər də’vayi-əql eylər, nə sud,
Nəfyi-zövqi-eşqdir, cəhlinə eyni-e’tiraf.


1 Tərcüməsi: Allah, mənim qəmimi qurtar, qorxduğum şeydən mənə nicat ver


178


Olur rüxsarına gün, lə’linə gülbərgi-tər aşiq,
Sənə əksik degil, gögdən yağar, yerdən bitər aşiq.

Mənə məqsud tərki-eşq idi, vəh kim, məni hüsnün
Olub gün-gündən əfzun, qıldı gün-gündən bətər aşiq.

Təmaşayi-cəmalından nəzər əhlini mən’ etmə,
Nə sud ol xubyüzdən kim, ona qılmaz nəzər aşiq.

Çəməndə paybusindən olubdur səbzələr xürrəm,
Haman bir səbzəcə olmağə aləmdə bitər, aşiq.

Qılırsan min cigər qan, hər yana baxdıqca, ey zalim,
Nə baxmaqdır bu, hər dəm qandan alsın bir cigər aşiq?

Qırarsan əhli-eşqi, tutalım, kimsə əlin tutmaz,
Nə işdir bu, gərəkməzmi sənə, ey simbər, aşiq?

Nə pərvanə doyar bir şö’ləyə, nə şəm’ bir ahə,
Füzuli, sanma kim, bənzər sənə aləmdə hər aşiq.


179


Tabi-xurşid məhi-ruyinə vermiş rövnəq,
Ta ki, ziba xət üçün ola bu təzhibi-vərəq.

Əksi-qəddinlə görən daireyi-ayinəyi,
Der məhi-bədrdir əngüşti-nübüvvətdən şəq.

Sənə gülşəndə nisar etmək üçün hər nərgis
Götürübdür başa altun dolu bir sim təbəq.

Hər sənəm müshəfi-hüsni-həqə bir ayətdir,
Məktəbi-eşqdə hər dil ona bir tifli-səbəq.

Aşiq olmaq sənə, bəsdir bizə bürhani-cünun,
Hüsnə əql əhli müqəyyəd ola bilməz mütləq.

Rəsmdir aşiqə gəlmək qaşı yaylardan ox,
Eşq peyda olalı böylə qurulmuş bu nəsəq.

Şahdır hüsn büsatında bu gün ol gülrüx,
Ey Füzuli, məni-avarə sürülmüş beydəq.


180


Olmaz oldu görüb əhvalımı el xublara aşiq,
Eşq nəhyində bu rüsvalığ gör şər’ə müvafiq.

Gəlir olsan, qılaram fərşi-rəhin pərdeyi-çeşm,
Dəxi nəm var, əzizim, gözə qarşı sənə layiq?

Gülüb açılmaq umulmaz dəhənindən, məgər oldur,
Cüzv kim, ləyatəcəzza [1] der ona əhli-dəqayiq.

Bağrımın parələrin gözlərin asmış müjələrdən,
Mərdümi-guşənişin, qandanü qandan bu əlayiq?

Gecələr şəm’ yanar, əşk tökər sübh gəlincə,
Can verir sübh gələn dəmdə, zəhi aşiqi-sadiq.

Sibqət etmişdi cigər qanı, gözüm yaşına bir dəm,
Eşq hökm etdi, yenə cari ola adəti-sabiq.

Ey Füzuli, özünü guşənişin et xümi-mey tək,
Ola nagəh olasan kaşifi-əsrari-həqayiq.


1 Hissələrə ayrılmayan


181


Ey fəraqi-ləbi-canan, cigərim xun etdin,
Çöhreyi-zərdimi xunab ilə gülgun etdin.

Cigərim qanını göz yaşına tökdün, ey dil,
Varə-varə onu Qülzüm, bunu Ceyhun etdin.

Necə hüsn ilə səni Leyliyə nisbət qılayım,
Bilməyib qədrimi tərki-məni-Məcnun etdin.

Söylədin kim, tutaram şad könüllərdə məqam,
Şad ikən, bu söz ilə könlümü məzhun etdin.

Əhd qıldın ki, cəfa kəsməyəsən aşiqdən,
Aşiqi və’deyi-ehsan ilə məmnun etdin.

Cür’ə-cür’ə mey içib, zibi-cəmal artırdın,
Zərrə-zərrə gözümün nurini əfzun etdin.

Ey Füzuli, axıdıb seyli-sirişk ağılıyalı,
Eşq əhlinə fəğan etməgi qanun etdin.


182


Qıldı zülfün tək pərişan halimi xalin sənin,
Bir gün, ey bidərd, sormazsan: nədir halin sənin?

Getdi başından, könül, ol sərvqəddin sayəsi,
Ağıla kim, idbarə təbdil oldu iqbalin sənin.

Zinət üçün cism divarında etməzdim yerin,
Çəkməsəyədi eşq lövhi-canə timsalin sənin.

Tiz çəkməzsən cəfa tiğin məni öldürməyə,
Öldürər axir məni bir gün bu ehmalin sənin!

Qərqi-xunabi-cigər qılmış gözüm mərdümlərin,
Arizuyi-xali-mişkinü rüxi-alin sənin.

Damigahi-eşqdən tut bir kənar, ey mürği-dil,
Sınmadan səngi-məlamətdən pərü balin sənin.

Sayəvəş çoxdan Füzuli xaki-kuyin yaslanır,
Budur ümmidi ki, bir gün ola pamalin sənin.


183


Çeşmimi əşk ilə gənci-düri-məknun etdin,
Mərdümi-çeşmimi ehsan ilə Qarun etdin.

Meyi-gülguni, dedin, əqlə ziyandır, zahid,
Bumudur əql ki, tərki-meyi-gülgun etdin?

Canım aldın mey üçün, saqi, içirdin mənə qan,
Dad əlindən ki, məni al ilə məğıbun etdin.

Xəttinin afəti-can olduğunu bildirdin,
Lütf qıldın ki, məni vaqifi-məzmun etdin.

Dil tutar, mari-səri-zülfünü, vəhm eyləməyib,
Bilməzəm kim, ona tə’lim nə əfsun etdin.

Biləməz oldu məni tə’nə edən əhli-riya,
Şükr kim, halimi, ey eşq, digərgun etdin.

Ey Füzuli, nə murad oldu müyəssər bilmən,
Bunca kim, həsrəti-lə’lilə cigər xun etdin?


184


Can verir rayiheyi-türbəti-pakin, ey tak,
Nəvvər-Əllahu ləkəl-əzrə, səq-Əllahu sərak [1] .

Hörmət etdin meyə, tə’zim ilə tutdun, saqi,
Əzzəm-Əllahu ləkəl-əcrə ələllahi cəzak [2] .

Səri-kuyində qəribiz, bizə bir munis yox,
Talə ma anəsənəl-qəlbu, cəəlnahu fədak [3] .

Səfheyi-dildə bulunmaz əsəri-surəti-qeyr,
Hinə ma həllə, nəfil-ğeyrə ənil-qəlbi həvak [4] .

Rəhi-eşqində götür qeyrdən, ey dil, rəğıbət,
Fəiza şi’tə rəfiqən, ələmül-eşqi kəfak [5] .

Xabi-qəflətdə, könül, vəsldən oldun məhrum,
Fazə mən nalə ila vəslihi, ma xabə sivak [6] .

Ey Füzuli, nə bilir əhli-vərə’ mey zövqin,
Ənkərəl-hikmətə mən laməkə cəhlən və nəhak [7] .


1 Tərcüməsi: Allah yeri sənin üçün nurlu etsin, Allah sənin torpağını suvarsın.
2 Tərcüməsi: Allah əcrini çoxaltsın, Allah mükafatını versin.
3 Tərcüməsi: Uzun müddət könül bizi munis etdi, onu sənə fəda etdik.
4 Tərcüməsi: Sənin sevgin könülə yol tapdıqda özgələrini qəlbdən uzaqlaşdırdı.
5 Tərcüməsi: Dost istədikdə eşq dərdi sənə kifayətdir.
6 Tərcüməsi: Onun vəslinə nail olan məqsədinə çatdı, sənin tək heç kim müvəffəqiyyətsiz
olmadı.
7 Tərcüməsi: Səni cəhalət üzündən danlayıb ondan uzaqlaşdıran hikməti inkar etmiş oldu.

185


Şəm’i-ruyin afitabi-aləmaradır sənin,
Nuri-həq xurşidi-rüxsarında peydadır sənin.

Sənsən ol cövhər ki, dürci-mümkinat içrə bu gün,
Mümkün olan eybdən zatın mübərradır sənin.

Can verir lə’lin təmənnasında min abi-həyat,
Feyzinə ləbtəşnə yüz Xizrü Məsihadır sənin.

Sərvü gül nəzzarəsin neylər sənə heyran olan
Kim, qədin sərvü rüxün gülbərgi-rə’nadır sənin.

Razi-eşqin xəlqdən qılmaq nihan mümkün degil,
Aşiqin ol vəchdən aləmdə rüsvadır sənin.

Qıldı şövqün əşk qəvvası gözüm mərdümlərin,
Ey düri-tər, mənzilin guya bir dəryadır sənin.

Cümlə afaq əhldən çəkmiş təəllüq damənin,
Ta Füzuli xəstəyə vəslin təmənnadır sənin.


186


Öylə rə’nadır, gülüm, sərvi-xuramanın sənin
Kim, görən bir gəz olur, əlbəttə, heyranın sənin.

Kakilin tək başına cizginmək istər xatirim,
Ey mənü yüz mən kimi sərgəştə qurbanın sənin.

Arizin dövründə cəm’iyyətdən olsun naümid
Olmayan aşüfteyi-zülfi-pərişanın sənin.

Çün əcəbdir lə’lə guyalıq, nə mö’cüzdür bu kim,
Eylər izhari-süxən lə’li-dürəfşanın sənin.

Çərx yayından atıldı canıma tiri-əcəl,
Leyk ondan tizrək dəprəndi mügjanın sənin.

Daği-hicranın odun bənzətmək olmaz duzəxə,
Olmasın kafər əsiri-daği-hicranın sənin.

Ey Füzuli, öylə kim, bimari-dərdi-eşqsən,
Yoxdürür ölməkdən özgə hiç dərmanın sənin.


187


Daği-hicran ilə yanmaqdan cigər qan olsa yey,
Mülki-dil qəm mənzili olunca, viran olsa yey.

Yarı əğyar ilə görmək aşiqə düşvar irür,
Böylə görməkdən əsiri-dərdi-hicran olsa yey.

Sinəmə peykanını göndər könül də’finə kim,
Sinədə suzan könül olunca peykan olsa yey.

Sirrimi rüsvalığm faş etmədən aləmlərə,
Zar cismim əşk girdabında pünhan olsa yey.

Dağıdırsa, nola, iqdi-zülfünü badi-səba,
Fitnə əhli olanın cəm’i pərişan olsa yey.

Dün Füzuli səhv edib, keçmiş meyü məhbubdən
Tövbə edib, bu yaman işdən peşiman olsa yey.


188


Qıymadın sakini-kuyin olana peykanın,
Bir içim su ilə ağrlamadın mehmanın.

Navəki-qəmzə diriğ eyləmə aşiqlərdən,
Kəsmə ərbabi-vəfadən nəzəri-ehsanın.

Istəyin can idi, xaki-rəhinə tapşırdım,
Yetdi ol xud yerinə, şimdi nədir fərmanın?

Canı yetdim ələmi-hicrin ilə, ey zalim,
Rəhm qıl, canın üçün, var isə bir dərmanın.

Dadxahəm sənə, damən nə çəkirsən məndən,
Yoxmu vəhmin ki, tutam həşr günü damanın?

Zalim olsan nə əcəb, yox sənə duzəx vəhmi,
Sənə xud yetməyəcəkdir sənin öz hicranın.

Vəsl əyyami rəvan yarə fəda eyləmədin,
Ey Füzuli, qəmi-hicran ilə çıxsın canın.


189


Ey məh, mənimlə dustlərim düşmən eylədin,
Düşmən həm eyləməz bu işi kim, sən eylədin.

Peykanlarınla doldu tənim, afərin sənə
Bidad çəkməyə tənimi ahən eylədin.

Təhsin sənə ki, könlüm evin tirə qoymadın,
Hər zəxmi-navəkin ona bir rövzən eylədin.

Olsun ziyadə rif’ətin, ey ahi-atəşin,
Möhnətsəramizi bu gecə rövşən eylədin.

Əksilməsin təravətim, ey əşki-laləgun,
Gül-gül damıb məqamımızı gülşən eylədin.

Can çıxsa, mənzil etməyə ev tut hübabdən,
Ey göz yaşı ki, qəsdi-binayi-tən eylədin.

Mümkün degil, Füzuli, cahanda iqamətin,
Bihudə sən bu mərhələdə məskən eylədin.


190


Səba, lütf etdin, əhli-dərdə dərmandan xəbər verdin,
Təni-məhzunə candan, canə canandan xəbər verdin.

Xəzani-qəmdə gördün iztirabın bülbüli-zarın,
Bahar əyyamı tək gülbərgi-xəndandan xəbər verdin.

Sözünü vəhyi-nazil gər deyərsəm hiç küfr olmaz,
Cəhanı tutmuş ikən küfr, imandan xəbər verdin.

Dedilər yar, üşşaqin gəlir cəm’ etməyə könlün,
Məgər kim, yarə üşşaqi-pərişandan xəbər verdin?

Süleyman məsnədindən divi-gümrəh rəğıbətin kəsdin,
Dənizdə xatəmi-hökmi-Süleymandan xəbər verdin.

Füzuli, ruzigarın tirə gördün şami-hicrandan,
Nəsimi-sübh tək xurşidi-rəxşandan xəbər verdin.


191


Bəqa mülkün dilərsən, fani et varini dünya tək.
Ətək çək gördügündən afitabi-aləmara tək.

Təəllüq zülmətin təcrid xurşidinə qıl mətlə’,
Əgər aləmdə bir gün görmək istərsən Məsiha tək.

Könül hər surəti-Şirinə vermə, iç meyi-mə’ni,
Həzər qıl, daşə çalma tişəni Fərhadi-şeyda tək.

Rəfiqin olsa dilsiz canəvər, həm saxla raz ondan,
Saqın, sirrin düşürmə dillərə Məcnuni-rüsva tək.

Yetər tavus tək ücbilə qıl arayişi-surət,
Vücudindən keçib, aləmdə bir ad eylə ənqa tək.

Gühər tək qılma təğyiri-təbiət dəlsələr bağrın,
Qərar et, hər həvadən olma şurəngiz dərya tək.

Füzuli, kainat əsbabının qıldım təmaşasın,
Nədamətsiz tənə’üm yox, təsərrüfsüz təmaşa tək.


192


Dəhənin dərdimə dərman dedilər cananın,
Bildilər dərdimi, yoxdur dedilər dərmanın.

Olsa məhbublərin eşqi cəhənnəm səbəbi,
Hurü qılmanı qalır kəndisinə Rizvanın.

Keçdi meyxanədən el, məsti-meyi-eşqin olub,
Nə mələksən ki, xərab etdin evin şeytanın?

Vurmazam sihhət üçün mərhəm oxun yarəsinə,
Istərəm çıxmaya zövqi-ələmi-peykanın.

Nə bilir oxumayan müshəfi-hüsnün şərhin,
Yerə gögdən nə üçün endigini Qur’anın.

Yerdən, ey dil, gögə qovmuşdu sirişkin mələki,
Onda həm qoymayacaqdır oları əfğanın.

Ey Füzuli, olubam qərqeyi-girdabi-cünun,
Gör nə qəhrin çəkirəm dönə-dönə dövranın.


193


Gəlir ol sərvi-səhi, ey gülü lalə, açılın!
Vey məhü mehr çıxın, qüdrətə nəzzarə qılın!

Əzmi-bağ eyləmiş ol sərvi-rəvan, ey güllər,
Zər nisar edə görün, cümlə yığılın, dərilin.

Götürün oxların, ey didələrim, topraqdan,
Bu yarar nəsnələrin qədrini yaxşicə bilin.

Eyləmin, ey dilü can, xəncəri-müjganinə meyl,
Bilirəm nolisər axir, gəlin ondan kəsilin.

Göz yaşı tiğiniz içün tökülür, ey xublar,
Sizi ta etməyə rüsva, görünən dəmdə silin!

Düşdü od canimə, ey təndə olan peykanlar!
Qızmadan mə’rəkə bir yanə ərinmin, çəkilin!

Ey Füzuli, qədimiz qıldı fələk xəm, yə’ni
Vəqtdir çıxmağa dünya qapısından, əgilin.


194


Ey könül, çox seyr qılma, günbədi-dəvvar tək,
Sakin olmaq seyrdən yey, nöqteyi-pərgar tək.

Ün verir can riştəsi, xəm qamətimdən çəksəm ah,
Yel dəgib çəng üstidə, avazə gəlmiş tar tək.

Sinəmi ney oxların dəldi dəm urduqca könül,
Ün verir hər bir dəlikdən nalə musiqar tək.

Arizin üstə xəmi-zülfün anıb, dün ta səhər,
Dolanırdım hər tərəf odlarə düşmüş mar tək.

Cismi-zarım tiği-bidadindən oldu çak-çak,
Tünd sudən rəxnələr peyda qılan divar tək.

Bilməyib behbudimi cövründən etdim ictinab,
Təlx şərbətlərdən ikrah eyləyən bimar tək.

Xatirin cəm’ eylədin, əhli-vəfa könlün pozub,
Bir imarət yapmağa min ev yıxan me’mar tək.

Bibəqadır nəş’eyi-mey, zövqin etdim imtəhan,
Hiç zövqi-baqi olmaz nəş’eyi-didar tək.

Ey Füzuli, xatiri-əhli-səfa ayinədir,
Çərx cövründən əsər, ayinədə jəngar tək.


195


Var ümidim ki, görüb cövlanını olsam həlak,
Gərdi-nə’li-badpayin örtə cismim üzrə xak.

Öldügüm mənzildə dəfnim qılmağa sanmın ləhəd,
Yer görüb qürbətdə əhvalım, giriban etdi çak.

Məst can verdim, məzarım üzrə tə’zim eyləyib,
Qübbə yapıb daneyi-əngur, eyvan tutdu tak.

Çün cəfa mö’tadiyəm, bilmən nədir mehrü vəfa,
Bilməsə mehrü vəfa rəsmin cəfakarım, nə bak.

Hər küdurətdən məni pak etdi seyli-xuni-dil,
Şükr-lillah, atəşi-eşqin məni yandırdı pak.

Ah, bilmən neyləyim, canımda rahət qalmadı,
Gözlərim nəmnak, sinəm çak, könlüm dərdnak.

Qeyr nəqşin məhv qılmışdır Füzuli sinədən,
Ma ləhu fid-dəhri-mətlubün və məqsudun sivak [1] .


1 Tərcüməsi: Onun dünyada səndən başqa istək və arzusu yoxdur.


196


Ləbin rəşki mizacın təlx qıldı badeyi-nabın,
Qaşın meyli üzini qiblədən döndərdi mehrabın.

Girehlər oldu canım riştəsi təsbih tari tək,
Mənə gör netdi axır arizuyi-zülfi-pürtabın.

Ayağın tozuna üz sürməyə verməz səba rüxsət,
Üzün yüz kərrə şəbnəm yumadan, gülbərgi-sirabın.

Səba, ol zülf təprəndikcə təşvişim ziyad eylər,
Saqın, təprətmə kim, bağrımdadır başı bu qüllabın.

Dərü divarinə küstax üz sürmüş deyib, gərdun
Üzini gecələr sürtər yerə ta sübh mehtabın.

Məhəbbət zahir etmək cürminə, qan tökmək istərsən,
Həbibim, bunca həm rəğıbət nədir zəcrinə əhbabın!

Füzuli qəmzeyi-mərdümküşindən iltifat istər,
Sanır kim, iltifatı rəhm olur qurbanə qəssabın.


197


Nə xoşdur arizin dövründə zülfi-ənbərəfşanın,
Bu dövranda nə xoş cəm’iyyəti var ol pərişanın.

Rüxün dövründə bir divanədir sevdalı zülfün kim,
Pərişanlıqdan olmuş mən kimi, məşhuri dövranın.

Həvadən kakilindir təprənən, ya rişteyi-candır
Ki, hər dəm cizginib başinə istər ola qurbanın.

Müsəlsəl zülfi-mişkinindən artırmış rüxün rövnəq,
Zəhi sünbül ki, olmuş zivəri gülbərgi-xəndanın.

Qararıbdır tütün tək ruzgarım ol zamandan kim,
Tənim xaşakinə odlar urubdur bərqi-hicranın.

Işimdir sayə tək yerdən-yerə üz urmaq ol gündən
Ki, başımdan gedibdir sayeyi-sərvi-xuramanın.

Füzulini ayaqdan saldı bari-möhnəti-eşqin,
Neçün tutmazsan, ey kafər, əlini bir müsəlmanın?


198


Ey müsəvvir, yar timsalinə surət vermədin,
Zülfü rüx çəkdin, vəli tabü təravət vermədin.

Eşq sevdasından, ey naseh, məni mən’ eylədin,
Yox imiş əqlin, mənə yaxşı nəsihət vermədin.

Dün ki, fürsət düşdü xaki-dərgəhindən kam alam,
Noldu, ey göz yaşı, göz açmağa fürsət vermədin.

Göz yumub aləmdən, istərdim açam rüxsarinə,
Canım aldın, göz yumub-açınca möhlət vermədin.

Bumudur rəhmin ki, xalin eylər ikən qəsdi-can,
Çıxdı xəttin kim, onu mən’ edə, rüxsət vermədin.

Vermə hüsn əhlinə, ya rəb, qüdrəti-rəsmi-cəfa,
Çün cəfa çəkməkdə eşq əhlinə taqət vermədin.

Ey Füzuli, öldün, əfğan etmədin, rəhmət sənə!
Rəhm qıldın, xəlqə əfğanınla zəhmət vermədin.


199


Çərx hər ay başına salmış qaşından bir xəyal,
Bu cəhətdəndir hər ay başında olmaq bir hilal.

Mahi-növ olmuş qaşın sevdasının sərgəştəsi,
Şəhrdən şəhrə gəzər avarələr tək mahü sal.

Etdigiçün hüsnünə qarşu kəmal izharı gün
Bir gün olmaz kim, ona gərdun yetirməz bir zəval.

Sübh qıldın cilvə, gün çəkdi özün bu guşəyə,
Şam ərz etdin, rüxün şəm’i əritdi infial.

Qılma gözdən çöhrəvü xalın nihan kim, qılmaya
Dudi-ahim afitabi çöhreyi-gərdunə xal.

Olmuyub məqbuli-xaki-dərgəhin mahi-təmam,
Zə’fi-tale’ verdi gün-gündən ona təğyiri-hal.

Ey Füzuli, mah nisbət məhv qıl varın təmam,
Gər dilərsən bulmaq ol xurşid birlə ittisal.


200


Mülki-hüsnün böylə zalim padişahi olmağıl
Kim, sana zalim desə adil, güvahi olmağıl.

Qəmzə tiğin çəkmə hər saət könül yəğmasinə,
Hökmə tabe’, mülkə qarətgər sipahi olmağıl.

Ahını, ey mah, üşşaqin yetirmə göglərə,
Dərd əhlinin nişani-tiri-ahi olmağıl.

Gər dilərsən şəm’ tək qeyrət oduna yanmayım,
Şamlər əğyar şəm’i-bəzmgahi olmağıl.

Adət etmək xoş degil bidadə, rəhm et, Tanrıçün,
Gah olsan maili-bidad, gahi olmağıl.

Aşiqi rusva görüb, mən’ etmə, ey naseh, məni,
Münkiri-asari-təqdiri-ilahi olmağıl.

Ey Füzuli, eyləmə, taət riyayi, tərkin et,
Tövbə qıl minbə’d, məşğuli-mənahi olmağıl.


201


Bəs ki, zə’fi-ruzədən hər gün bulur təğyiri-hal,
Olacaqdır eyd üçün mahi-təmamim bir hilal.

Qıldı mahi-ruzə xurşidimi gün-gündən zəif,
Zərrə-zərrə ayə, san gün nuri eylər intiqal.

Bir xəyal etmişmi zə’fi-ruzə yarı, bilməzəm,
Yoqsa yarı görməyib, mən gördügümdür bir xəyal.

Tuta bilsəydim, su içməzdim, qılırdım dəf’ini,
Ruzənin kim, göz görə xurşidimə istər zəval.

Ay tutulsun, ruzə əyyamında gün düşsün yerə
Kim, bu ay, gündən bulubdur mehriban mahim məlal.

Qanımı içmək dilər ol lə’li-meygun hər gecə,
Ruzə tutmuş qaliba, iftar içün istər həlal.

Yemək-içmək fikrin əhli-ruzədən kəs, ey günəş,
Bir səvab et, sübhlər ta şam qıl ərzi-cəmal.

Ruzə təklifin Füzulidən götür, ey möhtəsib,
Natəvandır, onda bu təklifə yoxdur ehtimal.


202


Eylə müstəsna gözəlsən kim, sənə yoxdur bədəl,
Səndən, ey can, münqəte’ qılmaz məni illa əcəl.

Necə surət bağılasın könlüm xilasi-eşqdən,
Eşqdir bir hal kim, ol halə könlümdür məhəl.

Eşqimə nöqsan gətirməz görməmək ol arizi,
Cövhərə təğyiri-asari-ərəz verməz xələl.

Eylədi rüsva könül çaki-giribani-ədəb,
Gör nə əhli-elmdir, adab ilən eylər cədəl.

Halimi gördükcə mən’i-əhli-eşq eylər fəqih,
Höccəti-məqtui yox, eylər qiyas ilən əməl.

Mədrəsə içrə müdərris verdigi min dərsdən
Yeydürür meyxanədə bir cam vermək bir gözəl.

Ey Füzuli, mən dəm urmuşdum səfayi-eşqdən
Mətləi-xurşid icad olmadan sübhi-əzəl.


203


Ey rüxün qibleyi-can, xaki-dərin Kə’beyi-dil,
Rəhi-eşqində fəna sərhədi əvvəl mənzil.

Lalərəng etdi gözüm qan ilə xaki-dərini,
Kimyagərdir edər gördüyü toprağ qızıl.

Ol ki, yarın şəbi-hicrinə qiyamət günü der,
Xəlq arasında qiyamət günü olmazmı xəcil?

Qatı müşküldür işim zülfi-girehgirindən,
Səbr bu müşkili, derlər, açar, əmma müşkil.

Etmək olmaz səni agah könül halından,
Yazıq ol kim, sənə könlün verə, səndən qafil.

Sevirəm zahidi kim, guşeyi-mehrabı sevər,
Xəmi-əbrunə rəqibim olub, olmaz mail.

Dəli dersəm nola üşşaqına gülçöhrələrin,
Özünü göz görə odlarə salırmı aqil?

Səni canan sanıram, çıx bədənimdən, ey can!
Mənü cananım arasında çox olma hail.

Ey Füzuli, yanıram kim, nə üçün ol üzü gül
Mənə yanar od olur, özgəyə şəm’i-məhfil.


204


Hiç sünbül sünbüli-zülfün kimi mişkin degil,
Nafeyi-Çini saçın tək derlər, əmma çin degil.

Var gül bərgində həm əlhəq, nəzakət birlə rəng,
Leyk, canpərvər ləbi-lə’lin kimi şirin degil.

Mehriban derlər səni əğyarə, lakin mən ona
Bavər etmən kim, sənə mehr eyləmək ayin degil.

Xublər mehrabi-əbrusinə qılmazsan sücud,
Dinini döndərgil, ey zahid, ki, yaxşı din degil.

Ta Füzuli qamətü rüxsarına vermiş könül,
Maili-sərvü həvaxahi-gülü nəsrin degil.


205


Üzünü güzgüyə qeybətdə oxşadan qafil,
Toxunsa üz-üzə olmazmı ara yerdə xəcil.

Buraq niqab ki, bilsin kəmali-sün’i görüb,
Firiştə xilqəti-Adəmdə şübhəsin batil.

Hədisi-vəhyvəşin zaye’ etmə əğyarə,
Rəvamıdır, edəsən qədrin ayətin nazil.

Hərimi-kuyini göstər nümunə, eylə səvab
Kim, ola cənnət içün xəlq taətə mail.

Səni qoyub, bütə eylər ibadətin kafir,
Əzabi-duzəxə ol vəchdən olur qabil.

Həkimə nəfyi-qiyamət xətasını bildir,
Qiyam göstər ona, e’tiqadın et zail.

Qərəz Füzuliyə ancaq əlində ölməkdir,
Vəli məhaldır ol həm, sən olıcaq qatil.


206


Canə basdım qönçəvəş peykanını, ey tazə gül,
Dözmək içün hicrinə düzdüm dəmirdən bir könül.

Vəh nə sairsən ki, oddan su çıxardın, sudan od,
Tərlədib rüxsarını gül-gül qılanda tabi-mül.

Yandırıb əczayi-tərkibim, külüm verəsən yelə,
Yox yolundan dönməgim, varım sənindir cüzvi küll.

Mərdümi-çeşmim yığar navəklərin mümkün sanır
Ol ağaclar birlə tutmaq əşk dəryasinə pül.

Ey könül, lövhi-əməl nəqşi-bəqadən sadədir,
Fani etmə ömrün ol sevdadə kim, baqi degül.

Surətaray olma, təhsili-kəmali-mə’ni et
Kim, bəhayim növ’ün etməz adəmi zərbəft çül.

Nola dersəm qədr ilə əfzun Məsihadən səni,
Yerü göy mizan olub fərq olmuş ağrdan yünül.

Atəşi-dil öylə suzandır ki, basmaz hiç kim,
Rəhm edib navəklərindən özgə zəxmim üzrə kül.

Hasilin əvvəl qəmi-canandı axir təki-can,
Bu imiş qismət, Füzuli, xah ağıla, xah gül.


207


Rəhrövi-irfanə bəsdir sağərü saqi dəlil
Kim, məhü xürşiddən bulmuş təmənnasın Xəlil.

Olsa iste’dadi-arif qabili-idraki-vəhy,
Əmri-həq irsalına hər zərrədir bir Cəbrəil.

Hər kimin təqdirdən məqsudi öz qədrincədir,
Əhli-eşq istər zülali-vəsl, zahid Səlsəbil.

Cənnətə zahid bilir can vermədən yetməz, vəli,
Canə qımaz, öz təmənnasındadır miskin bəxil.

Ey qılan izhari-zillət, müjdeyi-izzət sənə
Kim, bu dərgəhdə müqərrərdir əziz olmaq zəlil.

Və’deyi-vəslin məni salmış xəyali-zülfünə
Kim, dilər tuli-əməl sərmayeyi-əmri-təvil.

Ey Füzuli, xublər zikri-cəmalilə xoşam,
Şükr kim, kəsb etmişəm aləmdə bir zikri-cəmil.


208


Degilsən çoxdan, ey gərdun, cəhan seyrində yoldaşım,
Nola xəm olsa qəddin, səndən artıqdır mənim yaşım.

Tərazuyi-əyari-möhnətəm bazari-eşq içrə,
Gözüm hər dəm dolub, min daşə hər saət dəgər başım.

Sirişkim al, bağrım parə, bir kuhi-bəlayəm kim,
Həmişə laləvü lə’l ilə rəngindir içim, daşım.

Mənə manənd bir divanə surət bağılamaz, guya
Qələm sındırdı, təsvirim çəkəndən sonra nəqqaşım.

Füzuli, xazini-gənci-vəfayəm, ol səbəbdəndir,
Gühərlər tökdü israf ilə bu çeşmi-gühərpaşım.


209


Tənimdə zəxmi-tiğin çeşmi-xunəfşanə bənzətdim,
Oxun kim, səf-səf ətrafındadır, müjganə bənzətdim.

Bəqayi-ruhimi bildim zülali-lə’li-nabindən,
Həyatımdır dedim, bağrıma basdım, qanə bənzətdim.

Sökülmüş köksümü kim, doludur qəmzən xəyalilə,
Həramilər yatağ mənzili-viranə bənzətdim.

Tənimdən incinib çıxmış rəvan can kimi peykanın,
Neçük incinməsin, yetdikdə zövqün, canə bənzətdim.

Gözümdə bəslənib, qiymət bulan peykanını gördüm,
Sədəfdə gövhər olan qətreyi-baranə bənzətdim.

Füzuli, öldürər hər dəm məni əhli-nəzər tə’ni
Ki, neyçün yar lə’lin çeşmeyi-heyvanə bənzətdim.


210


Eşqdən canımda bir pünhan mərəz var, ey həkim!
Xəlqə pünhan dərdim izhar etmə, zinhar, ey həkim!

Var bir dərdim ki, çox dərmandan artıqdır mənə,
Qoy məni dərdimlə, dərman eyləmə, var ey həkim!

Gər basıb əl nəbzimə, təşxis qılsan dərdimi,
Al əmanət, qılma hər bidərdə izhar, ey həkim!

Gəl mənim tədbiri-bihudəmdə sən bir sə’y qıl
Kim, olam bu dərdə artıqraq giriftar, ey həkim!

Gör təni-üryan ilə əhvalımı hicran günü,
Var imiş ruzi-qiyamət, qılma inkar, ey həkim!

Çəkməyincə çareyi-dərdimdə zəhmət bilmədin
Kim, olur dərmani-dərdi-eşq düşvar, ey həkim!

Rənc çəkmə, sihhət ümmidin Füzulidən götür
Kim, qəbuli-sihhət etməz böylə bimar, ey həkim!


211


Qəmindən başə dün həsrət əlilə ol qədər urdum
Ki, sübh olunca mürdə cismimi toprağə tapşurdum.

Büküldü qəddim, ahim yetdi xurşidə, saqın, ey dil
Ki, möhnət oxunu peykanladım, qəm yayını qurdum.

Demin Məcnunə aşiq kim, başında quş yuva tutmuş,
Mənəm aşiq kim, seyli-çeşmimi başımdan aşurdum.

Kəlamindən mürəttəb eylədi bürhani-isbatın,
Nə sahib kəşfə ki, dürci-dəhanın sirrini sordum.

Təcərrüd seyrinə sayəmdən özgə bulmadım həmrəh,
Təriqi-eşq içində çoxlarilə durdum, oturdum.

Həvayi-eşq sərgərdanı olmuş girdibadəm kim,
Savurdum göylərə toprağmı hər qanda kim, durdum.

Füzuli, eşqə mühlik derdim, ol məhvəş inanmazdı,
Bihəmdillah ki, can vermək təriqilə inandırdum.


212


Dəhənin şövqünü cansuz güman etməz idim,
Yoxsa bir dəm onu mən munisi-can etməz idim.

Vəsfi-xali-ləbini bilsə idim naməqdur,
Arizusunda qara bağrımı qan etməz idim.

Xublər aşiqə meyl etmədigin bilsə idim,
Özümü eşq ilə rüsvayi-cəhan etməz idim.

Düşməsəydi gözümün yaşinə feyzi-nəzərin,
Onu hər sərvin əyağinə rəvan etməz edim.

Salmasaydım dili-viranə imarət tərhin,
Onda gənci-gühəri-eşqi nəhan etməz idim.

Sitəmi-tə’neyi-əğyarə degildim vaqif,
Yoqsa yarın səri-kuyində məkan etməz idim.

Etməsəydi sitəmi-yar, Füzuli, məni-zar,
Bunca fəryad çəkib, ahü fəğan etməz idim.


213


Bir qul oğılani könül mülkünə sultan etdim,
Misr idi, padişəhin Yusifi-Kən’an etdim.

Dil ki, bir dilbərə sərmənzil idi, ahim ilə
Yelə verdim, adını təxti-Süleyman etdim.

Eşq tərki, dilü candan görünürdü müşkil,
Tərki-eşq eylə dedin, tərki-dilü can etdim.

Can qəmin çəkmiş idi, var idi boynumda həqi
Bu onun əcri idi kim, sənə qurban etdim.

Rəhi-eşqin tutub, etdim qəmü dərdim dəf’in,
Görə nə cəm’i bu təriq ilə pərişan etdim.

Sənə tapşırdığm oxlarını yaqdın, ey dil,
Zaye’ etdin nə qədər kim, sənə, ehsan etdim.

Səbzə tək qıldı Füzuli, çıxarıb əşk əyan,
Tən qübarində oxun hər necə pünhan etdim.


214


Nurini mah mehri-rüxündən alır müdam,
Inkar edərsə, şəhr güvahımdurur təmam.

Mehrab imiş qaşın ki, ona qarşu kirpigin
Səf-səf gəlir qiyamə qılıb qəmzəni imam.

Ol hur və’dəsinə behişti-vüsal üçün,
Qur’anca e’tibar edübəm, hasili-kəlam.

Əksi-rüxün oğurladığçün dönə-dönə,
Asıldı güzgü şəhrdə, eldən sürüldü cam.

Dəşt üzrə girdbadmı, ya gəldigim görüb,
Məcnun qubarıdır ki, durub eylər ehtiram.

Durğurma, yolların yügürüb tutma, ey sirişk,
Ol sərv edəndə naz ilə bizdən yana xüram.

Həmsöhbət oldu daneyi-əngür zahidə,
Əsli budur ki, oxudular badəni həram.

Meyxanədir cahanda, Füzuli, məqami-əmn,
Cəhd et bir ev hübab kimi, onda tut müdam.


215


Pənbeyi-daği-cünun içrə nihandır bədənim,
Diri olduqca libasım budur, ölsəm kəfənim.

Canı canan diləmiş, verməmək olmaz, ey dil!
Nə niza’ eyləyəlim, ol nə sənindir, nə mənim.

Daş dələr ahim oxu şəhdi-ləbin şövqindən,
Nola zənbur evinə bənzəsə beytül-həzənim.

Tövqi-zənciri-cünun daireyi-dövlətdir,
Nə rəva kim, məni ondan çıxara zə’fi-tənim.

Eşq sərgəştəsiyəm, seyli-sirişk içrə yerim,
Bir hübabəm ki, həvadən doludur pirəhənim.

Bülbüli-qəmzədəyəm, bağü bəharım sənsən,
Dəhənü qəddü rüxün qönçəvü sərvü səmənim.

Edəmən tərk, Füzuli, səri-kuyin yarın,
Vətənimdir, vətənimdir, vətənimdir, vətənim.


216


Faş qıldın qəmim, ey dideyi-xunbar, mənim!
Eylədin mərdümə nəm olduğun izhar mənim.

Dəhənin istərəm, ey eşq, yox et varlığm
Ki, yox olmaqda bu gün bir qərəzim var mənim.

Çıxmış əğyar ilə seyr etməyə ol mərdümi-çeşm,
Bu əcəb, mərdümi çıxmış gözüm ağılar mənim.

Bu təmənnadə ki, ol şəm’ ilə həmsöhbət olam,
Dudi-ah etdi dünüm tək günümü tar mənim.

Mövc ilə könlümü, ey əşk, qopar yanımdan,
Nalə ilə başım ağrıtdı bu bimar mənim.

Çıxmış ol şux bu gün tökməyə qanın görənin,
Girmə ey göz, kərəm et, qanıma, zinhar mənim.

Ey Füzuli, dərü divarə qəmim yazmaqdan
Şahidi-hali-dilimdir dərü divar mənim.


217


Ol mah vüsalilə xoş et bir gecə halim,
Ey əxtəri-tale’ qoma boynunda vəbalim!

Fəryad ki, bər vermədi bidaddən özgə,
Göz yaşı ilə bəslədigim türfə nihalim.

Sınmış müjə tək, xəlq gözündən axıdır yaş,
Nəzzareyi-zə’fi-bədəni-muymisalim.

Ol şəm’ xəyalilə xoşam, ola ki, daim,
Bu surət ilə cizginə fanusi-xəyalim.

Suzandır odumdan tənimə sancılan oxlar,
Pərvanəyəm, ey şəm’, tutuşmuş pərü balim.

Saqi, qəmi-dövran ilə qayətdə məluləm,
Bir cami-fərəhbəxş ilə dəf’ eylə məlalim.

Lütf eylə, Füzuli, mənim əhvalımı ərz et
Ol sərvə ki, söyləşməyə qalmadı məcalim.


218


Hər hübabi-əşkimə bir əks salmış peykərim,
Şahi-mülki-möhnətəm, tutmuş cahani ləşkərim.

Əhli-qədrəm yanalı eşq oduna pərvanəvəş,
Sürmeyi-çeşm eyləmişlər şəm’lər xakistərim.

Cismimi yaqdınsa, pamal etmə könlümdən, saqın,
Gülxənəm, əksik degil xakistərimdə əxgərim.

Eşq sərgərdaniyəm, köksümdə min-min dağılər,
Bir sipehri-sairəm, sabit cəmii-əxtərim.

Çeşm tari-cismimə düzmüşdü əşkim gövhərin,
Ah kim, çərx üzmüş ol tari, dağılmış gövhərim.

Nola hər saət od üstündə durarsam dud tək,
Udi-bəzmi-eşqəm, atəşdir büsatü bəstərim.

Ey Füzuli, çox məlamətdən məni mən’ etmə kim,
Mən nihali-gülşəni-dərdəm, məlamətdir bərim.


219


Əql yar olsaydı, tərki-eşqi-yar etməzmidim?
Ixtiyar olsaydı, rahət ixtiyar etməzmidim?

Ləhzə-ləhzə surətin görsəydim ol şirinləbin,
Sən kimi, ey Bisütun, mən həm qərar etməzmidim?

Nişə məhrəm eylədin şəm’i, məni məhrum edib,
Mən sənin bəzmində can nəqdin nisar etməzmidim?

Dərdimi aləmdə pünhan tutduğum naçardır,
Uğrasaydım bir təbibə, aşikar etməzmidim?

Yar ilə əğyarı həmdəm görməgə olsaydı səbr,
Tərki-qürbət eyləyib, əzmi-diyar etməzmidim?

Vaizin bəzmin mənim rüsvalığmdan qıl qiyas,
Onda sidq olsaydı, mən təqva şüar etməzmidim?

Ol güli-xəndanı görmək mümkün olsaydı mənə,
Sən tək, ey bülbül, gülüstanə güzar etməzmidim?

Ey Füzuli, daği-hicran ilə yanmış könlümü,
Laləzar açsaydı, seyri-laləzar etməzmidim?


220


Eşigin daşini qan ilə yudu çeşmi-tərim,
Bəs ki pakəm, daşı lə’l eylədi feyzi-nəzərim.

Cigərim dağinə mərhəm bulamadım səndən,
Necə ah eyləməyim, ah, yanıbdır cigərim.

Dedi ol yar: səhər vəqti gəlim, leyk nə sud,
Vəqt mə’lum degil, şam ilə birdir səhərim.

Ey xoş ol şam ki, bixud gedəyim kuyinə, sübh:
Neylədim onda, deyə qeyrdən alım xəbərim.

Düşməzəm könlünə, yə’ni olubam öylə zəif,
Dərdi-eşqinlə ki, güzgudə görünməz əsərim.

Neçə min aşiqə ancaq bir ox atdın, demədin
Ki, düşər bir-birinə bir neçə üftadələrim.

Ey Füzuli, dura məndən ala tə’limi-vəfa,
Nagəh ər mərqədi-Məcnunə düşərsə güzərim.


221


Zülfi kimi ayağın qoymaz öpəm nigarım,
Yoxdur onun yanında bir qılca e’tibarım.

Insaf xoşdur, ey eşq, ancaq məni zəbun et,
Ha böylə möhnət ilə keçsinmi ruzigarım?

Bildi təmami-aləm kim, dərdməndi-eşqəm,
Yarəb, hənuz halım bilməzmi ola yarım?

Vəslindən ayrı nola qanim tökülsə gül-gül,
Mən gülbüni-bəlayəm bu fəsldir bəharım.

Təsvir edən vücudim yazmış əlimdə sağər,
Rəf’ olmağa bu surət yox əldə ixtiyarım.

Dur istəmən zəmani mey sayəsin başımdan,
Topraq olanda, yarəb, dürdi-mey et qübarım.

Rüsvalərindən ol məh saymaz məni, Füzuli,
Divanə olmayımmı dünyadə, yoxmu arım?


222


Dürdvəş sərgəşteyi-camü xərabi-badəyəm,
E’tibarım yox, ayaq toprağ bir üftadəyəm.

Hiç rəng ilə mənə abadlıq mümkün degil,
Mən xərabi-badeyi-safü üzari-sadəyəm.

Deməzəm dəgməz mənə qəmzən xəyalı, ya dəgər.
Dəgmə qeydi çəkməzəm, aləmdə bir azadəyəm.

Abi-çeşmim cizginir kuyində, əmma qədri yox,
Deməsin bu dövrdə kimsə ki, mərdümzadəyəm.

Zahida, məndən nə hasil kim, oxursan məscidə,
Məndə taət yox, haman alayişi-səccadəyəm.

Çərx dövründən nə hasil kim, verir təğyiri-zövq,
Durmadan zövq artırır miskini-dövri badəyəm.

Zövq istərsən, Füzuli, tərki-dünya qıl ki, mən
Bulmadım bir zövq bundan qeyr ta dünyadəyəm.


223


Canlar verib, sənin kimi cananə yetmişəm,
Rəhm eylə kim, yetincə sənə canə yetmişəm.

Şükraneyi-vüsalinə can verdigim bu kim,
Çox dərd çəkmişəm ki, bu dərmanə yetmişəm.

Halım deyib, muradıma yetsəm əcəb degil,
Bir bəndəyəm ki, dərgəhi-sultanə yetmişəm.

Muri-mühəqqərəm ki, sərasimə çox gəzib,
Nagah barigahi-Süleymanə yetmişəm.

Bir bülbüləm ki, gülşən olubdur nişimənim,
Ya tutiyəm ki, bir şəkəristanə yetmişəm.

Dövri-fələk müyəssər edibdir muradımı,
Guya ki, talibi-gühərəm, kanə yetmişəm.

Miskin Füzuliyəm ki, sənə tutmuşam üzüm,
Ya bir kəminə qətrə ki, ümmanə yetmişəm.


224


Yar hali-dilimi zar bilibdir, bilirəm,
Dili-zarimdə nə kim var, bilibdir, bilirəm.

Yari əğyar bilibdir ki, mənə yar olmaz,
Mən dəxi ani ki, əğyar bilibdir, bilirəm.

Zülfünü əhli-vəfa seydinə dam eyləyəli,
Məni ol damə giriftar bilibdir, bilirəm.

Mən nə hacət ki, qılam şərh ona dərdi-dilimi,
Qamu dərdi-dilimi yar bilibdir, bilirəm.

Yar həmsöhbətim olmazsa, Füzuli, nə əcəb,
Özünə söhbətimi ar bilibdir, bilirəm.


225


Xoş ol zaman ki, hərimi-vüsalə məhrəm idim,
Nə mübtəlayi-bəla, nə müqəyyədi-qəm idim.

Gəzərdim itlərin içrə fəzayi-kuyində,
Yerim behişti-bərin idi, mən bir Adəm idim.

Həmişə səcdəgahim xagi-asitanın idi,
Bu e’tibar ilə bir sərbüləndi-aləm idim.

Gədayi-kuyin idim, böylə zillətim yox idi,
Səriri-səltənəti-qürbdə müəzzəm idim.

Zaman-zaman əsəri-pərtövi-cəmalindən
Müalici-dili-pürdərdü çeşmi-pürnəm idim.

Ziyadə qəmzədəyəm hicr ilə, xoş ol günlər
Ki, mən bu qəmzədəlikdən ziyadə xürrəm idim.

Füzuli, olmaz imiş möhnəti-fərağə müfid,
Bu zövqi-zikr ki, bir vəqt yarə həmdəm idim.


226


Ney kimi, hər dəm ki, bəzmi-vəslini yad eylərəm,
Ta nəfəs vardır quru cismimdə, fəryad eylərəm.

Ruzi-hicrandır, sevin, ey mürği-ruhim kim, bu gün
Bu qəfəsdən mən səni, əlbəttə, azad eylərəm.

Vəhm edib ta salmaya sən mahə mehrin hiç kim,
Kimə yetsəm, zülmü cövründən ona dad eylərəm.

Qan yaşım qılmaz vəfa, giryan gözüm israfina,
Bunca kim, hər dəm cigər qanından imdad eylərəm.

Incimən hər necə kim, əğyar bidad eyləsə,
Yar gövriçün, könül, bidadə mö’tad eylərəm.

Bilmişəm bulman vüsalın, leyk bir ümmid ilə
Gah-gah öz xatiri-naşadımı şad eylərəm.

Lövhi-aləmdən yudum əşk ilə Məcnun adını,
Ey Füzuli, mən dəxi aləmdə bir ad eylərəm.


227


1Ki ondan



Şəm’i-şami-firqətəm, sübhi-vüsali neylərəm?
Bulmuşam yanmaqda bir hal, özgə hali neylərəm?

Qeyrə ərz et hər nə əsbabın ki, var, ey dəhri-dun!
Mən bir əhli-zövqəm, əsbabi, məlali neylərəm.

Yox əcəb, gər malə rəğıbət, mülkə qılman iltifat,
Mən gədayi-kuyi-eşqəm, mülkü mali neylərəm?

Əhli-haləm, demə büt vəsfin mənə, ey bütpərəst,
Hal bilməz dilbəri-sahibcəmali neylərəm?

Ehtimali-hicr təşvişinə dəgməz zövqi-vəsl,
Vəsl kim, var onda hicran ehtimali neylərəm?

Nəxli-qəddin istərəm, kandan [1] bəladır hasilim,
Baxmazam şümşadə, bər verməz nihali neylərəm?

Ey Füzuli, qıl kəmali-fəzl kəsbin, yoxsa mən
Kamili-eşqəm, dəxi özgə kəmali neylərəm?


228


Bağə girdim, səri-kuyin anıb əfğan etdim,
Gül görüb, yadın ilə çaki-giriban etdim.

Baxuban nərgisə, əyyar gözün qıldım yad,
Nərgisi naləvü əfğanıma heyran etdim.

Qönçəvü lalə demə, dağ qarasın qoparıb,
Alu alayə sarıb səbzədə pünhan etdim.

Güli-tər üzrə düşən şəbnəmə düşdü nəzərim,
Gözümü şövqi-cəmalında dürəfşan etdim.

Bərgi-gül sanma ki, xunabə tökən dəmdə gözüm,
Neçə yaprağə cigər qanı silib, qan etdim.

Görücək sünbülü, andım şikəni-kakilini,
Sünbüli giryəvü ahimlə pərişan etdim.

Ey Füzuli, rəvişi-əql məlul etdi məni,
Səhv qıldım ki, cünun dərdinə dərman etdim.


229


Hicran ilə yanar gecələr rişteyi-canım,
Rövşən ola, ey şəm’, sənə suzi-nihanım.

Bir şəm’i-şəbistani-bəlayəm ki, degil kəm,
Ta mən diriyəm suzi-dilü əşki-rəvanım.

Ey xəlvətimə şəm’i-rüxündən buraxan nur!
Didarinə müştaq idi çeşmi-nigəranım.

Sənsiz gecələr ahü fəğanım məh eşitdi,
Ey məh, sənə həm yetdi ola ahü fəğanım.

Canə nə rəvadır ki, çəkib tiğ, dəmadəm
Qəmzən sökə cismim, dələ bağrım, tökə qanım.

Həmrəngi-ləbindir deyə, qət’i-nəzər etməz
Xuni-cigərimdən müjeyi-əşkfəşanım.

Pünhani odum aləmə faş oldu, Füzuli,
Ya rəb ki, mənim şəm’ kimi yanə zəbanım.


230


Tutuşdu qəm oduna şad gördügün könlüm,
Müqəyyəd oldu ol azad gördügün könlüm.

Diyari-hicrdə seyli-sitəmdən oldu xərab,
Fəzayi-eşqdə abad gördügün könlüm.

Nə gördü badədə bilmən ki, oldu badəpərəst,
Mürid məşrəbü zöhhad gördügün könlüm.

Fəraqın odunu gördükcə mum tək əridi,
Səbatü səbrdə fulad gördügün könlüm.

Gətirdi əcz, görüb eşq müşkül olduğunu,
Qamu hünərlərə ustad gördügün könlüm.

Degildi böylə, dəmində bir əhli-işrət idi,
Bu qanlar içməgə mö’tad gördügün könlüm.

Füzuli, eylədi ahəngi-eyşxaneyi-Rum,
Əsiri-möhnəti-Bəğıdad gördügün könlüm.


231


Qaçan kim, qamətindən ayrı seyri-busitan etdim,
Qoparıb əşk seylabilə min sərvi rəvan etdim.

Götürdüm, girdibadi-ah ilə gərdunə tapşırdım,
Qübari-rəhgüzarın cövhərin gözdən nihan etdim.

Nişani-surəti-xubin verib, bütlər sücudində
Fəsadi-e’tiqadin kafərin xatirnişan etdim.

Olub sərməst, qıldım nəş’eyi-zövqi-ləbin fikrin,
Meyə rağib olanlar küfrünü xəlqə əyan etdim.

Görüb divarlərdə Kuhkən nəqşin, demin aşiq,
Mənəm aşiq ki, tutdum dəşt, tərki-xaniman etdim.

Rəhi-eşqində ol gülrüx cigər qan etdigim bilmiş,
Çəkər hər dəm mənə tiği-siyasət, sanki qan etdim.

Füzuli, şahibazi-övci-istiğına ikən, bilmən,
Nə səhv etdim ki, bu viranə deyri-aşiyan etdim?


232


Müxalif dövrdən, gülgun şərabı qanə dəgşirdim,
Sürudin çəngü udun naləvü əfqanə dəgşirdim.

Dəxi zövqi-vüsali-dust şövqin istəmin məndən
Ki, mən zövqi-vüsali möhnəti-hicranə dəgşirdim.

Məni, ey bağiban, mə’zur tut gülzar seyrindən
Ki, mən gülzar seyrin külbeyi-əhzanə dəgşirdim.

Könül verdim fənavü fəqrə, tərki-e’tibar etdim,
Bihəmdillah ki, axir küfrümü imanə dəgşirdim.

Niqabi-surəti-hal eylədim xuni-cigər seylin,
Əyan rüsvalığ dərdü qəmi-pünhanə dəgşirdim.

Könüldən zövq bulmazdım, çıxardım çaki-köksümdən,
Qaşı yaylar xədəngilə gələn peykanə dəgşirdim.

Füzuli, məndə zövqi-afiyət az istə kim, çoxdan,
Mən onu aruziyi-təl’əti-cananə dəgşirdim.


233


Qıldı ol sərv səhər naz ilə həmmamə xüram,
Şəm’i-rüxsarı ilə oldu münəvvər həmmam.

Görünürdü bədəni çaki-giribanından,
Camədən çıxdı, yeni ayını göstərdi təmam.

Nilgun futəyə sardı bədəni-üryanın,
San bənəfşə içinə düşdü müqəşşər badam.

Oldu pabusi-şərifilə müşərrəf ləbi-hövz,
Buldu didari-təlifilə ziya dideyi-cam.

Sandılar kim, satılır daneyi-dürri-ərəqi,
Vurdu əl kisəyə çoxlar qılıb əndişeyi-xam.

Kakilin şanə açıb, qıldı həvayi mişkin,
Tiğ muyin dağıdıb, etdi yeri ənbərfam.

Tas əlin öpdü, həsəd qıldı qara bağrımı su,
Yetdi su cisminə, rəşk aldı tənimdən aram.

Çıxdı həmmamdən o, pərdeyi-çeşmim sarınıb,
Tutdu asayiş ilə guşeyi-çeşmimdə məqam.

Mərdümi-çeşmim əyağinə rəvan su tökdü
Ki, gərək su tökülə sərvin əyağinə müdam.

Müzdi-həmmam, Füzuli, verərəm can nəqdin,
Qılmasın sərf zər ol sərvqədü siməndam.


234


Ey kəmanəbru, şəhidi-navəki-müjganinəm,
Bulmuşam feyzi-nəzər səndən, sənin qurbaninəm.

Kakilin tarinə peyvənd etmişəm can riştəsin,
Başın üçün, bir tərəhhüm qıl ki, sərgərdaninəm.

Nola qılsam tərki-mey, minnət qılıb zahidlərə,
Neylərəm mey nəş’əsin, mən kim, sənin heyraninəm.

Şanəvəş yüz navəki-qəm sancılıbdır canimə,
Ta əsiri-həlqeyi-geysuyi-mişkəfşaninəm.

Əl çəkib, qət’i-nəzər qılmış əlacımdan təbib,
Bildi guya kim, xərabi-nərgisi-fəttaninəm.

Canə meylin var isə, hökm eylə, təslim eyləyim,
Şah sənsən, mən sənin bir bəndeyi-fərmaninəm.

Qönçə qılmaz şad, gül açmaz tutulmuş könlümü,
Arizuməndi-rüxi-alü ləbi-xəndaninəm.

Qan edib bağrım, işim ah etmə hər dəm, ey fələk,
Hörmətim tut bir-iki gün kim, sənin mehmaninəm.

Ey Füzuli, atəşi-ah ilə yandırdın məni,
Qaliba sandın ki, şəm’i-külbeyi-əhzaninəm.


235


Səcdədir hər qanda bir büt görsəm, ayinim mənim,
Xah mö’min, xah kafər tut, budur dinim mənim.

Bağiban, şümşadü nəsrinin mənə ərz etmə kim,
Ol qədü rüxsardir şümşadü nəsrinim mənim.

Xaki-dərgahin nəzərdən sürmə, ey seylabi-əşk,
Qılma zaye’ sürmeyi-çeşmi-cəhanbinim mənim.

Əşk mövci gəzdirir hər yan tənim xaşakini,
Mümkün olmaz əşk təhrikilə təskinim mənim.

Çarə umdum lə’li-şirinindən əşki-təlximə,
Təlx göftar ilə aldın cani-şirinim mənim.

Məndə sakin oldu dərdi-eşq Məcnundan keçib,
Ondan artıqdır məgər eşq içrə təmkinim mənim?

Ey Füzuli, hər yetən tə’n eylər oldu halimə,
Bu yetər əhli-məlamət içrə təhsinim mənim.


236


Zairi-meyxanəyəm, müğ səcdəsidir ta’ətim,
Eşq pirim, nəqdi-can nəzrim, təvəkkül niyyətim.

Hər yana baxsam, sürahi tək sücud etmək işim,
Qanda olsam, badə tək düşmək əyağə adətim.

Tövrümə zahid əgər surətdə eylər e’tiraz,
Ixtilat etsəm, onu şərməndə eylər sirətim.

Bəs ki, cami-mey kimi xoşməşrəbü safidiləm,
Hörmətim vacib bilir hər kim bilir keyfiyyətim.

Mö’təbərlikdir qürur əsli, mən ondan fariqəm,
E’tibarə çün degil qabil mühəqqər hey’ətim.

Eşq ərbabi-vəfadən zail etmiş mehrimi,
Fəqr əsbabi-əlayiqdən götürmüş rəğıbətim.

Ey Füzuli, fəqr toprağında dövlət istə kim,
Sayə ol toprağə salmışdır hümayi-himmətim.


237


Kərəm qıl, kəsmə, saqi, iltifatın binəvalərdən,
Əlindən gəldigi xeyri diriğ etmə gədalərdən.

Əsiri-qürbətiz, bir səndən özgə aşinamız yox,
Ayağın kəsmə, başinçün, bizim möhnətsəralərdən.

Səba, kuyində dildarın nədir üftadələr hali?
Bizim yerdən gəlirsən, bir xəbər ver aşinalərdən.

Demə, zahid ki, tərk et simbət bütlər təmaşasın,
Məni kim qurtarır Tanrı sataşdırmış bəlalərdən.

Girib məscidlərə, gər müqtədalər peyrəvi olman,
Budur vəchi ki, hərgiz görmədim üz müqtədalərdən.

Təbiba, xaki-kuyi-yardəndir əşk təskini,
Bizə artırma zəhmət, göz yaşarar tutiyalərdən.

Fələkdir mehri zayil, yar qafil, ömr müstə’cil,
Nədir tədbir, bilmən, canə yetdim bivəfalərdən.

Vücudim ney kimi surax-surax olsa, ah etmən,
Məhəbbətdən dəm urdum, incimək olmaz cəfalərdən.

Füzuli, nazəninlər görsən, izhari-niyaz eylə,
Tərəhhüm umsa, eyb olmaz, gədalər padişalərdən.


238


Yaqma canım, naleyi-biixtiyarımdan saqın!
Tökmə qanım, abi-çeşmi-əşkbarımdan saqın!

Su verər hər sübhdəm göz yaşi tiği-ahimə,
Çox məni incitmə, tiği-abidarımdan saqın!

Cövr odu yaxdı məni, yanımda durma, ey könül!
Bir tutuşmuş atəşəm, qürbü civarımdan saqın!

Tən evindən rəxtini, cəhd eylə, ey can, dışra çək,
Afəti-seyli-sirişki-biqərarımdan saqın!

Gərçi bir xaki-rəhəm, kimsə məni almaz gözə,
Çox həqarətlə nəzər qılma, qübarımdan saqın!

Gəlmə qəbrim üzrə, ey eşq içrə mən tək olmayan!
Tə’nə daşidir sənə, səngi-məzarımdan saqın!

Şahi-mülki-möhnətəm, xeylü sipahim dərdü qəm,
Xeyli-bihəddü sipahi-bişümarımdan saqın!

Ey Füzuli, qansı məhbubi ki, sevsən rəhmi var,
Qıl həzər, ancaq mənim birəhm yarımdan saqın!


239


1 Xa n – süfrə



Ey geyib gülgun, dəmadəm əzmi-cövlan eyləyən,
Hər tərəf cövlan edib döndükcə yüz qan eyləyən.

Ey məni məhrum edib bəzmi-vüsalindən müdam,
Qeyri xani-iltifati üzrə mehman eyləyən [1] .

Ey dəmadəm rəşk tiğilə mənim qanım töküb,
Mey içib, əğyar ilə seyri-gülüstan eyləyən!

Bunca kim, əfğanımı, ey məh, eşitdin gecələr,
Demədin bir gecə kimdir bunca əfğan eyləyən?

Nola gər cəm’iyyəti-xatirdən olsam naümid,
Cəm’ olurmu xublər zülfi pərişan eyləyən?

Yar dün çəkmişdi qətlim qəsdinə tiği-cəfa,
Yetməsin məqsudinə, ya rəb, pəşiman eyləyən.

Eşq dərdilə olur aşiq mizaci müstəqim,
Düşmənimdir, dustlar, bu dərdə dərman eyləyən.

Zahidin tə’n ilə döndərdim üzün mehrabdən,
Necə bulmaz əcr min kafir müsəlman eyləyən?

Dərdi-hicran natəvan etmiş Füzuli xəstəni,
Yoxmudur, ya rəb, dəvayi-dərdi-hicran eyləyən.


240


Nola zahid bilsə küfri-zülfün iman olduğun,
Şimdi görmüşlərmidir kafir müsəlman olduğun.

Mən əgər aşiq olub, din verməsəydim qarətə,
Kim bilirdi eşq mülkün kafiristan olduğun.

Qıl səvab, ey göz, töküb qan, vaqif et qafilləri,
Meyl edənlər eşqə bilsinlər cigər qan olduğun.

Daşə bənzər qanlı hər pərkalə kim, gözdən çıxar,
Ondan etdim fəhm, könlüm şəhri viran olduğun.

Və’deyi-vəslinə ol gündən ki, verdim könlümü,
Mən onun bilməzmidim axir pəşiman olduğun.

Eşqini asan görüb oldum əsiri tifl ikən,
Bilmədim gəldikcə bir aşubi-dövran olduğun.

Ey Füzuli, xublar vəslinə eylərsən həvəs,
Guiya, bilməzsən ol vəsl içrə hicran olduğun.


241


Sipehrin fariğəm vəslində mahü aftabindən,
Qərəz eydi-vüsalındır bu ayü gün hesabindən.

Təmaşayi-rüxün əzminə çıxdı afitab, əmma
Gəlirkən sür’ətilən düşdü yüz yerdə şitabindən.

Fələk məhcubdur, şəm’i-rüxündən yandırıb çərxi,
Çıxarmaq istər onu şö’leyi-ahim hicabindən.

Fələk eşqində ol qayətdə, ey məh, müztərib olmuş
Ki, hər nə eyləsə bilməz nə eylər iztirabindən.

Günəş lövhi degil gögdə şüa’ üstündə zərrinxət,
Fələk almış əlinə bir vərəq hüsnün kitabindən.

Dəgirmən danə içün cizginür, bihudə dövr etməz,
Mücərrədsən, könül, vəhm etmə çərxin inqilabindən!

Kimi hüşyar görsən sən, ona ver cami-mey, saqi,
Bihəmdillah, Füzuli məstdir vəhdət şərabindən.


242


Dust bipərva, fələk birəhm, dövran bisükun,
Dərd çox, həmdərd yox, düşmən qəvi, tale’ zəbun.

Sayeyi-ümmid zail, afitabi-şövq gərm,
Rütbeyi-idbar ali, payeyi-tədbir dun.

Əql dunhimmət, sədayi-tə’nə yer-yerdən bülənd,
Bəxt kəmşəfqət, bəlayi-eşq gün-gündən füzun.

Mən qəribi-mülkü rahi-vəsl pürtəşvişü məkr,
Mən hərifi-sadəlövhü dəhr pürnəqşü füsun.

Hər səhiqəd cilvəsi, bir seyli-tufani-bəla,
Hər hilaləbru qaşı bir sərxəti-məşqi-cünun.

Yeldə bərgi-lalə tək, təmkini-daniş bisəbat,
Suda əksi-sərv tək, tə’siri-dövlət vajigun.

Sərhədi-mətlubə pür möhnət təriqi-imtəhan,
Mənzili-məqsudə pürasib rahi-azimun.

Şahidi-məqsəd nəvayi-çəng tək pərdənişin,
Sağəri-işrət hübabi-safi-səhba tək nigun.

Təfriqə hasil, təriqi-mülki-cəm’iyyət məxuf,
Ah, bilmən neyləyim, yox bir müvafiq rəhnümun.

Çöhreyi-zərdin Füzulinin tutubdur əşki-al,
Gör ona nə rənglər çəkmiş sipehri-nilgun.


243


Çirağ göydüricək atəşi-nihanimdən,
Fitiləsin qılıram məğızi-üstüxanimdən.

Açıldı girməgə qəm, can evinə rövzənlər,
Çəkəndə oxlarını cismi-natəvanimdən.

Oxun təsərrüf edib cismi, qəsdi-can etdi,
Noleydi rəhm qılıb keçməsəydi canimdən.

Bir ignə etdi məni zə’f, riştəm ol qandır
Ki, müttəsil tökülür çeşmi-xunfəşanimdən.

Ədayi-şükri-xədəngindir ol səda ki, çıxar,
Zaman-zaman tökülən qətrə-qətrə qanimdən.

Oxun müsahibətilə keçər xoş ovqatım,
Həlak olurdum əgər təprənəyədi yanimdən.

Qəmi-nihanımı eylər, Füzuli, ellərə faş,
Ikən əzabdəyəm naləvü fəğanimdən.


244


Ucaldın qəbrim, ey bidərdlər, səngi-məlamətdən
Ki, mə’lum ola dərd əhlinə qəbrim ol əlamətdən.

Məzarim üzrə qoymun mil, əgər kuyində can versəm,
Qoyun bir sayə düşsün qəbrimə ol sərvqamətdən.

Görən saətdə ol qamət qiyamın, qıymadım canə,
Qiyamət həm gələ qurtulmayam mən bu nədamətdən.

Qiyamətdə hesabi olmayanlardandır ol qafil
Ki, fərq eylər fəraqın şamini sübhi-qiyamətdən.

Təriqi-səbrü tədbiri-səlamət ləzzətin bilmən,
Mənə eşqü məlamət yey gəlir səbrü səlamətdən.

Təbiət inhirafın gör həvayi-eşqdən təndə,
Əlac et düşmədən, saqi, mizacım istiqamətdən.

Füzuli, keç səlamət kuçəsindən, səbr kuyindən,
Fərağət olmayan yerdə səfər yeydir iqamətdən.


245


Budur fərqi, könül, məhşər gününün ruzi-hicrandan
Kim, ol can döndərər cismə, bu cismi ayırır candan.

Tutub rahi-ədəm, bulmuş dəhanından könül kamın,
Mənə həm cəzmdir ol əzm, mən həm qalmazam andan.

Qəmim şərh etmək üçün istərəm hər gördügüm saət,
Tutam damanını, dəgməz əlim çaki-giribandan.

Təvafi-kuyin istərdim qılam, bari-qəmi-eşqin,
Xəm etdi qamətim, yollar tutuldu xari-müjgandan.

Nə xoş ülfət tutubdur natəvan cismimlə can, guya
Sanır bir tari-mudur ol səri-zülfi-pərişandan.

Oxun gəldikdə çeşmim töksə bağrım qanın, ondandır
Ki, bağrım qanına yer qalmadı sinəmdə peykandan.

Sitəm daşı, məlamət xəncəri, bidad şəmşiri,
Füzuli, hər cəfa kim, gəlsə xoşdur canə canandan.


246


Bəzmi-eşq içrə şərabımdır sirişki-laləgun,
Qıldı qəm qəddim büküb, cami-şərabım sərnigun.

Hər tərəf pürxun əliflərdir çəkilmiş köksümə,
Ya həvadən mövc urur bağrımdakı dəryayi-xun.

Artırır əyyami-hicranın sirişkim hiddətin,
Müddəti-əyyam mey keyfiyyətin eylər füzun.

Məskən etmiş yar mari-zülfi çeşmim rəxnəsin,
Pənd vermin kim, onu ondan çıxarmaz min füsun.

Qət’i-ülfət, qaliba, düşvardır kim, eyləmiş
Nəqşi-Şirin ilə Fərhadı müqəyyəd Bisütun.

Rişteyi-can eylədim peyvənd tari-zülfinə,
Ah kim, çəkməkdə imdad eyləməz bəxti-zəbun.

Ey Füzuli, mən məlamət gövhərinin gənciyəm,
Əjdəhadır kim, yatır çevrəmdə zənciri-cünun.


247


Əgərçi ignə tək keçdim cahanın hər nə varindən,
Hənuz ardımcadır qeydi-təəllüq zülfi tarindən.

Şəhidi-eşq olub, feyzi-bəqa kəsb eyləmək xoşdur,
Nə hasil bivəfa dəhrin həyati-müstə’arindən.

Hübabi-əşkü ahi-pürşərər qılmış məni fariq,
Cahanın qəsri-siməndudü kaxi-zərnigarindən.

Görünməz surəti-ümmidi-vəslin lövhi-canımdan,
Mükəddərdir məgər ol ayinə cismim qübarindən?

Uzanır rişteyi-tuli-əməl didar zövqilə,
Xəm açıldıqca ol gülçöhrə zülfi-tabdarindən.

Sənədir iqtidası tovfi-kuyi-Leyli etməkdə,
Xəsü xarı qopar, ey naqə, Məcnun rəhgüzarindən.

Füzulidən məlamət ehtirazın istəyən guya
Degil vaqif dili-suzanü çeşmi-əşkbarindən.


248


1Zamin



Yerə düşməz hər nə ox kim, atsa ol əbrukəman,
Gün şüailə onun çox fərqi var, ey asiman!

Eşq namusi mənü Məcnunə düşmüş lacərəm,
Qəm yükün çəkməkdəyiz mən bir zəman, ol bir zəman.

Yox rəhi-eşqində bir mənzil yaşım girdabinə,
Yol itirmişdir, işi sərgəştə gəzməkdir həman.

Kam mümkündür uzun ömr ilə zülfündən, vəli
Bulmaq olmaz dövri-rüxsarında xəttindən əman.

Hiç kim sirri-dəhanın bilməz ol Isaləbin,
Aləmi qövğayə salmışdır mücərrəd bu güman.

Şəm’i-rüxsarın nihan tut çeşmeyi-xurşiddən,
Nuri-çeşmim, ehtiraz eylə yaman gözdən, yəman.

Ey Füzuli, çəkmə sən, rahi-təvəkküldən qədəm,
Mənzili-məqsudə yetməkdir müqərrər, mən zəman [1] .


249


Görüb mühlik mənim çevrəmdə bəhri-eşq tüğyanın,
Qaçıb bir dağə çıxdı kuhkən, qurtarmağa canın.

Buraxmış itlərinə parə-parə könlümü ol məh,
Üləşdirmiş, kəsib ərbabi-istehqaqə qurbanın.

Mənim çaki-giribanım görüb eyb eyləməz ol kim,
Görər sərməst çıxdıqda onun çaki-giribanın.

Könül qəm həmdəmidir, qanın, ey göz mərdümi, içmə,
Bilirsən qanə qandır, qəm sənə qoymaz onun qanın.

Gözün kim, guşeyi-mehrab tutmuş din qılır yəğma,
Bu mülkün etmək olmaz fərq kafirdən müsəlmanın.

Gözüm mərdümləri çoxdan qılırlar də’viyi-eşqin,
Nə hacət yaşların sormaq, anarlar Nuh tufanın.

Füzuli, çəkmə yarın oxların hər ləhzə yarəndən,
Sənəmi qaldı çəkmək hər zaman bir yar hicranın?


250


Şəfa lütf et məni-bimarə lə’li-nuşxəndindən,
Ikən həm olma, ey bidərd, qafil dərdməndindən.

Səməndin qətlimə səgritdin, əmma qorxum ondandır
Ki, səbqət edə nagəh tövsəni-ömrüm səməndindən.

Müradi-xatirin gər müşkül olmaqdır işim, olsun,
Nə çarə, keçmək olmaz xatiri-müşkülpəsəndindən.

Bilirdim səndə həm var ol həva kim, məndə var, ey ney,
Dəm urduqca əgər çıxsaydı atəş bənd-bəndindən.

Həris eylər məni pəndin məzaqi-eşqə, ey naseh!
Diriğ etmə ki, məhzuzəm sənin peyvəstə pəndindən.

Kəməndi-dudi-ahindir, Füzuli, çərx boynunda,
Əcəb səyyadsən kim, çərx qurtulmaz kəməndindən.


251


Ələ alır gəzicək ol güli-rə’na ətəgin,
Vəhm edər kim, tuta bir aşiqi-şeyda ətəgin.

Bildi kim, xaki-rəh oldum ətəgin tutmaq üçün,
Götürər, düşməyə qoymaz yerə əmda ətəgin.

Dadlər qılmağa ol kafir əlindən, gecələr
Çıxar ahim gögə ta tutə Məsiha ətəgin.

Şamlər qanlu yaşım movcinə, əlbəttə, dəgər,
Hər necə kim, götürür çərxi-müəlla ətəgin.

Öylə üryan gərək avareyi-səhrayi-cünun
Ki, təəllüq tikəni tutmaya qət’a ətəgin.

Rind xak olsa dəxi, dürdi-xümi-badə olur,
Nə isə, qoymaz əlindən meyi-səhba ətəgin.

Güllər açıldı, Füzuli, yaxalar çak edibən,
Gəl tutalım meyü məhbub ilə səhra ətəgin.


252


Görməsəm hər göz açanda ol güli-rə’na üzün,
Göz yumunca əşki-gülgunim tutar dünya üzün.

Gərçi kafərsən sənə, ey büt, yetər ol əcr kim,
Rəğıbətin meyxanədən döndərdi yüz tərsa üzün.

Pərdeyi-çeşmimdə nəqşi-cövhəri-tiğin sənin,
Mövcə bənzər kim, tutar təhrik ilə dərya üzün.

Olma, ey səhranişin qafil, degil hər su sərab,
Mövci-əşki-çeşmi-Məcnundur tutan səhra üzün.

Yadi-rüxsarilə ol mahın gözüm qan-yaş tökər,
Hər görən saətdə xurşidi-cahanara üzün.

Naz edib döndərmə, ey bidərd, üz üşşaqdən,
Bunca həm göstərmə fəqr əhlinə istiğına üzün.

Ey Füzuli, dudi-ahim tirə eylər aləmi,
Görməsəm bir ləhzə ol mahi-mələksima üzün.


253


Sün’ me’marı yapar saətdə gərdun məxzənin,
Dudi-ahim çıxmağa açmış kəvakib rövzənin.

Gün batıb ulduz çıxar sanmın ki, göy dehqanının,
Gecə ahim dağıdar gündüz yığılmış xirmənin.

Göz tökər israf ilə xunabə lə’lin guiya
Kim, cigər dağində ol lə’lin bulubdur mə’dənin.

Dözmək olmaz tiği-bidadinə şirinləblərin,
Gər fələk Fərhadvəş daş etsə üşşaqin tənin.

Sübh tək çak et, Füzuli, pirəhən eşq içrə kim,
Bilməyə kimsə giribanından onun damənin.


254


1Haçan



Qurutmuş qaliba şövq odu Fərhadın gözü yaşın
Ki, gər axsaydı, lə’l eylərdi, bişək, Bisütun daşın.

Bəla yolunda qovğayə qaçan [1] mən tək dözər Məcnun,
Qaçan olmaz durantək, yey bilür hər kimsə yoldaşın.

Demən göz yaşı ilə dəf’ olur eşq atəşi təndən,
Bu od hər yerə düşsə, fərq qılmaz, qurusun, yaşın.

Bəyani-eşqə bəsdir lövhi-rüxsarimdə xuni-dil,
Bəsirət əhlinə zahir qılır hər nəqş nəqqaşın.

Füzuli, badəxari duzəxi der xəlq, heyranəm
Ki, həq neyçün salıbdır cənnətə meyxanə ovbaşın.


255


Kuhkən künd eyləmiş min tişəni bir dağilən,
Mən qoparıb salmışam min daği bir dırnağilən.

Qəm yolunda mən qalıb, getdisə Məcnun, yox əcəb,
Sayruya düşvardır həmrəhlik etmək sağ ilən.

Gərdi-rahin verməsə göz yaşinə təskin, nola.
Tutmaq olmaz böylə seylabın yolun toprağilən.

Qəm oğurlar eşq bazarında nəqdi-ömrümü,
Qılmaq olmaz sud sövdadə yaman ortağilən.

Rövzeyi-kuyində bulmuşdur Füzuli bir məqam
Kim, ona cənnət quşu yetməz min il uçmağilən.


256


Gərdi-rəhin, ey əşk, yudun çeşmi-tərimdən,
Tərki-ədəb etdin, nola düşsən nəzərimdən.

Xunin müjələrdirmi və ya mərdüm əlilə,
Oxlar çəkilib, dişrə atılmış cigərimdən?

Hər badə ki, sənsiz içirəm bəzmi-bəladə,
Xunab olub, əlbəttə, çıxar didələrimdən.

Seylabi-sirişkilə xoşam eşq yolunda,
Xaşaki-təəllüq qoparır rəhgüzərimdən.

Daşlarə urub başımı, rüsva gəzər oldum,
Ey əql, qaçıb qurtula gör dərdi-sərimdən.

Kəs mehrini, ey çərx, günəşdən, sənə hər sübh
Bir şö’lə yetər atəşi-ahi-səhərimdən.

Seylabi-sirişk etdi məni qərqə, Füzuli,
Ta dövr cüda qıldı büti-simbərimdən.


257


Ta sirişki-dideyi-Fərhadi gördü laləgun,
Çeşmələr suyini gözdən saldı kuhi-Bisütun.

Ta ələm qaldırdı ahi-atəşinim, şərm edib,
Qıldı xurşidin fələk zərrin livasın nilgun.

Daş bağrlı olmasaydı Bisütun, Fərhad üçün,
Su yerinə gözlərindən axıdardı seyli-xun.

Ey görən min dağ ilə səbrü səbatım, eyləmə
Nisbətim Fərhadə kim, bir dağ ilə olmuş zəbun.

Quş yuvası sanma kim, sərgəştə Məcnun başinə
Xarü xəs cəm’ eyləmiş girdabi-dəryayi-cünun.

Ta göründü səfheyi-hüsnündə xəttin, rəşkdən,
Daşə çaldı afitabi-sadəlövhin çərxi-dun.

Ey Füzuli, xaki-kuyi-yarə yetdim, qanı Xizr
Kim, verəm kamın, olam abi-həyatə rəhnümun.


258


Cəm’ könlün dövr cövründən pərişan olmasın,
Çərx fərmanınla gəzməkdən peşiman olmasın.

Yer işi, gög cünbüşi-rə’yinlə bir dəm olmasa,
Yeddi iqlimü doquz gərduni-gərdan olmasın.

Bir binadır dövlətin, olmuş pənahi-xasü am,
Ol bina, yarəb, cahan olduqca viran olmasın.

Qılmasa aləm muradınca mədar, olsun xərab,
Olmasa dövran sənin rə’yinlə, dövran olmasın.

Cizginirkən dustlər kamınca fərmanində çərx,
Hakimi-təqdirdən təğyiri-fərman olmasın.

Tabe’ olsun cümleyi-aləm sənin fərmanına,
Cümleyi-aləmdə səndən qeyri sultan olmasın.

Ləhzə-ləhzə gülşəni-məhdində guya olmasa,
Bülbüli-nitqi Füzulinin xoşəlhan olmasın.


259


Topraqdən götür məni, ey əşki-laləgun!
Başimdən etmə sayəni kəm, ey hübabi-xun!

El tə’nəsindən istərəm ol kuyə getməyim,
Öz ixtiyarım ilə məni qoyma, ey cünun!

Təskin bulur cigərdə hərarət sirişk ilə,
Suzi-dil ilə sinədə rahət olur füzun.

Ey xuni-didə, kəsmə cigərdən təəllüqün,
Mehrin savutma sinədən, ey atəşi-dərun!

Bir gün bizə səadəti-vəsl etmədin nəsib,
Bizdən götür nühusətin, ey talei-zəbun!

Ol qəmzə xəncərinə bir uğratmadın bizi,
Kəs bizdən aşinalığın, ey bəxti-vajigun!

Ey çərx, qıl Füzulinin ahından ehtiraz
Kim, bir gün etməyə yedi taqini sərnigun.


260


Bari-möhnətdən nihali-qamətin xəm olmasın,
Başımızdan sayeyi-sərvi-qədin kəm olmasın.

Hasilim rüxsarü lə’lü çeşmü qəmzən olmasa,
Ömr bir an, bir nəfəs, bir ləhzə, bir dəm olmasın!

Gərdi-rahin əzmi-gərdun etdi kim, bu qədr ilə,
Şöhreyi-aləm həmin Isayi-Məryəm olmasın.

Iltimas etdim səbadən tutiya çəkdirməyə,
Ağılama, ey göz, qübari-dərgəhi nəm olmasın.

Sən tək afət gəldigin bilmişdi kim, həqdən mələk
Iltimas eylərdi kim, aləmdə Adəm olmasın.

Der imiş zahid ki, olmaq eybdir rüsvayi-eşq,
Bu sözü faş etməsin, rüsvayi-aləm olmasın.

Ey Füzuli, zövqi-dərdi-eşqə nöqsan heyfdir,
Ehtiyat et, pənbeyi-dağində mərhəm olmasın.


261


Gör sirişkim şəbi-hicran, demə kim, qandır bu,
Zərrə-zərrə şərəri-atəşi-hicrandır bu.

Sanmanız qanlı dügün, sinə dəlüb, baş çəkmiş,
Şö’leyi-atəşi-ahi-dili-suzandır bu.

Kəsmə ümmid, könül, başına cizginməkdən,
Ola nagəh düşə fürsət ələ, dövrandır bu.

Dəmbədəm canımı, ey dərdü bəla, incitmin!
Lütf edin bir-iki dəm kim, sizə mehmandır bu.

Nə yaqırsan oxun, ey atəşi-dil, vəsl günü,
Bizə hicran gecəsi şəm’i-şəbistandır bu.

Könül istər ala bir bu səri-zülfündən, leyk,
Vermədən can dilər almaq, sanır asandır bu.

Dün demişsən ki, Füzuli mənə qurban olsun!
Sənə qurban olayım, yenə nə ehsandır bu.


262


Nihali-dərddir Məcnun, yer etmiş sayəsin ahu,
Başında quş qanadı bərg, əyağində səlasil su.

Mənə zali-fələk çəkdirdi ol muyi-miyan cövrün,
Görün bir tari-muyi necə əjdər etmiş ol cadu.

Olur meyli-dil əfzun asitanın daşına hər dəm,
Əgərçi rəsmdir yasdıqdan ikrah eyləmək sayru.

Tərəhhüm qıl bükülmüş qəddimə, vəhm eylə ahimdən,
Saqın çıxmayə nagəh yaydən ol ox, ey kəmanəbru.

Nədir, – dedim, rüxi-safində əksi-mərdümi-çeşmim?
Dedi: gəlmiş gəmilə Rumə, dərya qət’ edib, hindu.

Qaşın yayı fərağindən xədəngin kimi incəldim,
Necə bir çəkdirər eşqin mənə zülmün, nə gücdür bu?

Füzuli, ayrı düşdün yardən, səbr etməyə yer yox
Düşüb səhrayə əfğan edəlim sən ayru, mən ayru.


263


Bülbüli-dil gülşəni-rüxsarın eylər arizu,
Tutiyi-can lə’li-şəkkərbarın eylər arizu.

Naməvü qasid pəyamilə xoş olmaz xatirim,
Öz ləbindən ləhceyi-göftarın eylər arizu.

Sərvü gül nəzzarəsin neylər sənə heyran olan,
Arizinlə qəddi-xoşrəftarın eylər arizu.

Arizu eylər ki, mən tək müttəsil bimar ola,
Kim ki, vəsli-nərgisi-bimarın eylər arizu.

Hicr bimari tənim badi-səbadən dəmbədəm,
Sihhət içün sihhəti-əxbarın eylər arizu.

Zülməti-hicrində baxmaz şəm’ə çeşmim mərdümi,
Pərtövi-rüxsari-pürənvarın eylər arizu.

Arizuməndi-vüsalındır Füzuli xəstədil,
Vəslin istər, dövləti-didarın eylər arizu.


264


Rəməzan oldu çəkib şahidi-mey pərdəyə ru,
Mey üçün çəng dutub, tə’ziyə açdı geysu.

Bildi mütrib ki, nədir hal, götürdü qopuzun,
Bəzmdən çəkdi əyağini sürahiyyü səbu.

Bəzm qanuni pozuldu, ney üçün çəng ilə dəf,
Yığılıb etməyələr hakim eşigində ğülu.

Rəməzən ayı gərək açıla cənnət qapısı,
Nə rəva kim, ola meyxanə qapısı bağılu.

Fəthi-meyxanə üçün oxuyalım fatihələr,
Ola kim, yüzümüzə açıla bir bağılı qapu.

Afitabi-qədəh etməz rəməzən ayı tülu’
Nə bəladır bizə, ya Rəb, nə qara gündür bu?

Intizari-meyi-gülrəng ilə bayram ayına,
Baxa-baxa enəcəkdir gözümüzə qara su.

Rəməzan oldu, budur vəhmi Füzulinin kim,
Neçə gün içməyə mey, zöhd ilə nagəh tuta xu.


265


Əgər çıxsaydı dərdin cismdən, derdim ki, candır bu,
Nə hacət dərdini yeydir demək candan, əyandır bu.

Dəmadəm xublar gövrilə artar ləzzəti eşqin,
Yamandır bu ki, təhqiq etmədən derlər yamandır bu.

Xədəngi sayəsində xoş keçir ovqatını, ey dil
Ki, gülzari-həyatın zinəti sərvi-rəvandır bu.

Tutuşdum atəşi-dildən, cigər qanilə qərq oldum,
Əgərçi bir şərarə oddur ol, bir qətrə qandır bu.

Cəhanə qəddin ilə kakilindən fitnələr düşmüş,
Qiyamət ibtidası, fitneyi-axirzəmandır bu.

Dedilər bixəbərlər: baği-cənnət kuyinə bənzər,
Xəbər verdi mənə andan gələn Adəm, yalandır bu.

Füzuli, qıldı fəryadü fəğanım tirə gərduni,
Hənuz, ol mah sormaz kim, nə fəryadü fəğandır bu?


266


Aşiq oldum yenə bir tazə güli-rə’nayə
Ki, salır al ilə hər dəm məni yüz qovğayə.

Lət urub qalibi-fərsudəmi gəh həbs qılır,
Gəh sərasiməvü üryan buraxır səhrayə.

Yüzümün qanilə kimüxtini al etdim kim,
Aləti-sən’ət ola ol büti-bipərvayə.

Bu nə işdir ki, bizi ignə kimi incəldib,
Salır iplik kimi hər dəm bir uzun sevdayə.

Ayağın bağılamış avarələrin sən’ət ilə,
Yox nəhayət səri-kuyində gəzən şeydayə.

Ləxt-ləxt olmuş ikən qəmzə dirəfşini çəkib,
Çarəsaz olmadı bir gün məni-qəmfərsayə.

Yaxa çak edəni başmaq kimi salır ayağa,
Ey Füzuli, bax onun etdiyi istiğınayə.


267


Olsaydı məndəki qəm Fərhadi-mübtəladə,
Bir ah ilə verərdi min Bisütuni badə.

Versəydi ahi-Məcnun fəryadımın sədasın,
Quşmi qərar edərdi başındakı yuvadə?

Fərhadü zövqi-surət, Məcnunü seyri-səhra,
Bir rahət içrə hər kəs, ancaq mənəm bəladə.

Əşki-rəvanimə el cəm’ oldu, var ümidim
Kim, ola varə-varə cəm’iyyətim ziyadə.

Gəh qəmzən içmək istər qanimi, gah çeşmin,
Qorxum budur ki, nagəh qanlar ola aradə.

Sərvərlik istər isən, üftadəlik şüar et
Kim, düşmədən əyağə, çıxmadı başə badə.

Gər görməmək dilərsən rəsmi-cəfa, Füzuli,
Olma vəfayə talib dünyayi-bivəfadə.


268


Istədim mərhəm oxundan cigərim yarəsinə,
Atdı min ox ki, dəgər hər biri bir parəsinə.

Bir-birilə çəkişir gərdi-rəhinçün müjələr,
Gör nə qanlar düşəcəkdir oların arəsinə.

Çəkməz oldu, könül oxlar yükün, ol sərv məgər
Çəkərək atə oxun, rəhm edə biçarəsinə.

Qanı göz yaşı kimi əhli-nəzər kim, yügürüb
Bir içim su verə dəşti-qəmin avarəsinə.

Hər tərəf əkslərimdir görünən, ya yığılıb
Gəldi su xəlqi sirişkim suyu nəzzarəsinə.

Bilməzəm kim, nəzər əhli nəsini əksildər,
Qəzəb eylər, nəzər etsəm məhi-rüxsarəsinə.

Ey Füzuli, cigərim qanını qoymaz tökülə,
Can fəda ol sənəmin qəmzeyi-xunxarəsinə.


269


Bağə gir, bülbülə ərzi-güli-rüxsar eylə,
Yığ gülün irzini, bülbül gözünə xar eylə.

Bağ şahidlərinə zülf ilə çeşmin göstər,
Sünbülü dərhəm edib, nərgisi bimar eylə.

Qönçəyə lafi-lətafətdə ağız açdırma,
Ləhzə-ləhzə onu şərməndeyi-göftar eylə.

Sərvə azadəlik ismilə yaraşmaz yürümək,
Onu həm şiveyi-rəftarə giriftar eylə.

Dari-dünyanı, könül, cəhd qılıb, tərk edə gör,
Xabi-qəflətdə ikən özünü bidar eylə.

A cigər zəxmi, ağız açma xədəngin görübən,
Yetənə razi-nihanım, yetər, izhar eylə.

Kəs, Füzuli, təməin qeyr təmənnalərdən,
Qanda olsan tələbi-dövləti-didar eylə.


270


Uyub ahuyə düşdü mişk Məcnun tək biyabanə,
Nola çəksən onu zənciri-zülfi-ənbərəfşanə.

Çəkər kafir gözün hər dəm cigərdən qəmzə peykanın,
Nə gücdür bu, nə verdi alə bilməz bir müsəlmanə?

Bəla navəklərin sancılmasınmı köksümə hər dəm,
Dolaşır şanə tək hər ləhzə ol zülfi-pərişanə.

Oxun gəldikcə sinəmdən sədalərdir çıxan, bilmən
Dil eylər nalə, ya peykan dəgər sinəmdə peykanə.

Sədayi-navəkin çıxdıqca can xürrəm olur, guya,
Bu zindani-bəladən çıxmağa rüxsət verər canə.

Boyanıb qanə, olmuş parə-parə güllər ə’zası,
Məgər xəncər çəkib, sən sərv tək çıxdın gülüstanə?

Məlamət oduna yandın, Füzuli, çıx bu aləmdən,
Tərəhhüm qıl, rəva görmə ki, aləm oduna yanə.


271


Ey dili-sərgəştəvü şikəsteyi-valeh!
Səlli və səllim ələn-nəbiyyə və aleh! [1]

Nə’ti-nəbidir kəmali-əql nişani,
Fə’ti bima şa’ə min sifati-kəmaleh [2] .

Daği-fəraqinə ehtimal və mümkin,
Əhrəqəni nari-iştiyaqi-vüsaleh [3] .

Zikri ilə xoş keçir həmişə zamanın,
Müftəkirən fi cəmalihi və cəlaleh [4] .

Eylə xəyali-rüxün nəzərdə təsəvvür,
Vəqtəbisin-nurə min şü’ai-cəmaleh [5] .

Mərziyü məşkurdur cəm’i-fiali,
Əhsənu min xissətin cəmi’ü xisaleh [6] .

Tabe’i olmaqdadır nəcat, Füzuli,
Yəssərəkəllahu tabiən li fi’aleh [7] .


1 Tərcüməsi: Peyğəmbər və onun övladına salavat və salam (söylə).
2 Tərcüməsi: Onun yayılmış kamal sifətlərindən zikr eylə (söylə).
3 Tərcüməsi: Onun vüsal şövqünün odu məni yandırdı.
4 Tərcüməsi: Onun böyüklüyü və gözəlliyini fikr etdikdə.
5 Tərcüməsi: Nuru onun cəmalı şü’asından iqtibas et.
6 Tərcüməsi: Onun bütün xasiyyətlərinin hər biri gözəldir.
7 Tərcüməsi: Allah səni onun işlərinə tabe etsin.

272


1 Allah üçün



Daraldır qönçə həlqin, dürci-lə’lin gəlsə göftarə,
Qarardır afitabı sayə çəksən pərdə rüxsarə.

Sənə bir söz deyincə keçdi ömrüm həsbətən lilləh [1],
Sualım kami-dil verməklə möhtac etmə təkrarə.

Dili-sədpareyi cəm’ eyləmək kuyində müşküldür,
Olurmu cəm’ə qabil, hər itin ağızında bir parə!

Səri-zülfündə hər mu, seyd qılmış bir dili-suzan,
Düşübdür, sanəsən, bir şö’lə od şəm’ üzrə hər tarə.

Təmənnayi-vüsalinçün degil giryəm, budur qəsdim
Ki, seyli-əşkdən yer qalmaya kuyində əğyarə.

Başım qaldırmasın xaki-rəhindən, sərnigun çəksin,
Çəkər olsa müsəvvir surətim kuyində divarə.

Füzuli, zəf’i-tən üzrilə kəsmə naleyi-zarın,
Bizi çün çəng tək mö’tad qıldın naleyi-zarə.


273


Rəhm et, ey şəh, məni-dərviş çəkən ahlərə
Ki, gəda ahi əsər eylər olur şahlərə.

Mehri yox mahlərə ah əsər etməz, ya Rəb!
Ver bir insaf bu mehri yox olan mahlərə.

Qaşların tağinə versəm dili-suzan, nə əcəb,
Rəsmdir asıla qəndil nəzərgahlərə.

Maili-sərv, qədin vəslinə yetməz, nişə kim,
Bəxt şayəstə degil himməti kutahlərə.

Saqiyi-bəzmi-cünun nərgisi-məstindir kim,
Içirir badeyi-qəflət dili-agahlərə.

Baxma, ey didə, zənəxdanına məhbublərin,
Gəzmə qafil, həzər et düşməyəsən çahlərə.

Ey Füzuli, vərə’ əhli rəhi-məscid tutmuş,
Sən rəhi-meykədə tut, uyma bu gümrahlərə.


274


Yenə ol mah mənim aldı qərarım bu gecə,
Çıxacaqdır fələkə naleyi-zarım bu gecə.

Şəm’vəş məhrəmi-bəzm eylədi ol mah məni,
Yanacaqdır yenə eşq oduna varım bu gecə.

Həm vüsali vurur od canıma, həm hicrani,
Bir əcəb şəm’ ilə düşdü sərü karım bu gecə.

Nə tütündür ki, çıxar çərxə, dili-zarə məgər
Hicr dağini urur laləüzarım bu gecə?

Sübhə saldı bu gecə şəm’ kimi qətlimi hicr,
Ola kim, sübh gəlincə gələ yarım bu gecə.

Parə-parə cigərim itlərinə nəzr olsun,
Ol səri-kuyə əgər düşsə güzarım bu gecə.

Var idi sübh vüsalinə, Füzuli, ümmid,
Çıxmasa həsrət ilə cani-figarım bu gecə.


275


Nihali-sərvdir qəddin, qaşın nun ol nihal üzrə,
Misali-nöqteyi-nun xalın ol mişkin hilal üzrə.

Olub heyran, götürmən xəttü xalından nəzər, guya,
Gözüm mərdümləridir nöqtələr ol xəttü xal üzrə.

Xəm etdin qamətim, gər tərki-sər qıldımsa mə’zurəm,
Nə üzrüm var əgər derlərsə olmaz nöqtə dal üzrə.

Zülali-xuni-dildəndir gözüm peymanəsi məmlu,
Hübab altındadır ol nüqtə kim, qorlar zülal üzrə.

Yazar göz pərdəsinə əşk şərhi-hal, bilməz kim,
Oxunmaz qan ilə yazılsa xət övraqi-al üzrə.

Dəmadəm kilki-müjganilə tifli-mərdümi-çeşmim,
Xəti-sevdayi-xalın məşq edər lövhi-xəyal üzrə.

Füzulinin təriqi-nəzmə təb’in müstəqim etmiş
Xəyali-qamətin kim, bir əlifdir e’tidal üzrə.


276


Müshəf demək xətadır ol səfheyi-cəmalə,
Bu bir kitab sözdür, fəhm edən əhli-halə.

Rüxsarə nöqtə qoymaq rəsmi-xət olmasaydı,
Düşməzdi mənzil etmək rüxsarın üzrə xalə.

Heyrani-mahi-ruyin xurşidə mehr salmaz,
Müştaqi-taqi-əbrun əksik baxar hilalə.

Qondurdu gərd xəttin ayineyi-muradə,
Qıfl urdu iqdi-zülfün gəncineyi-vüsalə.

Dövran mənə qələm tək sevda qapısın açdı,
Ta qəddimi qəmindən döndərdi zə’f nalə.

Rəsmi-vəfa, Füzuli, səndən kəmalə yetmiş,
Xoş kamili-zamansan, əhsəntə bu kəmalə.


277


Həzər qıl ah odundan, cövrünü üşşaqə az eylə,
Xəsü xaşaki yaqma, şö’ləsindən ehtiraz eylə!

Sənəmlər səcdəsidir bizdə taət, Tanrıçün, zahid,
Kimi görsən sən öz dinində, təklifi-nəmaz eylə!

Həqiqət xəttini yazmaq dilərsən lövhi-zatında,
Xətin gülrüxlərin mənzur tut, məşqi-məcaz eylə!

Sənəmlər səngdillərdir eşitməzlər sözü, zahid,
Yetər bihudə mən tək onlara ərzi-niyaz eylə!

Sənin nazın görəndə əql qalmaz həsbətən lillah,
Aman ver talibi-didarə, bir dəm, tərki-naz eylə!

Yolunda intizari-məqdəminlə xak olan çoxdur,
Xüram et bir qədəm, min xakisari sərfəraz eylə!

Füzuli, canə tapşırdın xəyalın, şimdi rüsvasən,
Sənə kim der ki, hər naməhrəmə ifşayi-raz eylə!


278


Batalı qanə oxun dideyi-giryan içrə,
Bir əlifdir sanasan kim, yazılır qan içrə.

Yeridir sineyi-suzanıma külxən desələr,
Bəs ki, yanmışdır oxun sineyi-suzan içrə.

Canı tən içrə nə saxlardım əgər bilsə idim
Ki, degil gizli qəmi-lə’li-ləbin can içrə.

Ala gər oxlarını didələrimdən, ey dil,
Heyfdir, olmaya nagəh itə müjgan içrə.

Çak könlüm arasında yaraşır peykanın,
Iqdi-şəbnəm xoş olur qönçeyi-xəndan içrə.

Qəddinə sərv demiş, qönçələrin tə’nindən,
Duramaz badi-səba hiç gülüstan içrə.

Ey Füzuli, kimə suzi-dilimi şərh qılım,
Yox mənim kimi yanan atəşi-hicran içrə.


279


Arizin görsə fələk, mehr buraxmaz ayə,
Zərrə-zərrə qılıb onu buraxar səhrayə.

Ləblərin əksin alıb, bağə girər hər dəm su,
Rəşkdən qan içirir bərgi-güli-rə’nayə.

Yeridir əksinə ayinə dəmir bənd ursa,
Nə üçün qarşı durur sən kimi bihəmtayə.

Bulduğu yerdə həsəddən gün urar sayənə tiğ
Ki, rəfiq olmaya sən mahi-mələksimayə.

Oxa peykan dikilir qəmzən üçün peyvəstə,
Toxunur tə’nə oxu qaşın ucundan yayə.

Lə’li-nabın sifəti şəhdi-müsəffadır, leyk
Acı etmiş onu səfrayi-həsəd səhbayə.

Yar meylin sənə salmazsa, Füzuli, nə əcəb,
Necə meyl etmək olur sən kimi bir rüsvayə.


280


Su verər hər sübhdəm göz yaşı tiği-ahimə
Kim, tökəm qanın sipehrin, salsa mehrin mahimə.

Şəm’i-rüxsarın odu qıldı məni atəşpərəst,
Çaki-sinəmdən təmaşa eylə atəşgahimə.

Qəm kimi öldürsə, qanlı tək qaçar məndən yana,
Şahi-dərdəm, iltica eylər ülüvvi-cahimə.

Tutiya tək çeşmi-ərbabi-nəzərdir mənzilim,
Gərçi xaki-rəhgüzarəm dideyi-bədxahimə.

Bir fəqirəm durmasın kimsə mənə tə’zim üçün,
Qanda getsəm, ey gözüm, su səp qübari-rahimə.

Qafiləm sirri-ləbi-canpərvərindən ta xətin,
Qondurubdur gərd mir’ati-dili-agahimə.

Ey Füzuli, yarə döndərdim üzüm əğyardən,
Xəsmi çox gördüm, sığındım sidqilə Allahimə.


281


Yürütməyin ərəqi məclis içrə badə ilə,
Həramzadəni qoymın həlalzadə ilə.

Verir sitəm səbəqin tifli-xəttinə zülfün,
Qoman bu üzü qaranı o lövhi sadə ilə.

Mənə zaman ilə Məcnun müqəddəm olsa nola,
Oyunda şah bərabər degil piyadə ilə.

Qaşın bəlasına düşdüm, fələk qəmin çəkərək,
Bu güclü yayı çəkər oldum ol kəbadə ilə.

Qapında xəm qədimi gəzdirib yürür könlüm,
Itin durur, yügürür hər tərəf qəladə ilə.

Mənəm müdərrisi-elmi-cünun, qanı Məcnun
Ki, bərmurad ola dövrümdə istifadə ilə.

Başım ayağına gər düşsə mən’ eyləməzəm,
Nə eylədi mənə, nəm var bir fütadə ilə.

Məni saqınma, Füzuli, qəm içrə Məcnun tək
Ki, mən ziyadəyəm ondan qəmi-ziyadə ilə.


282


Xoşdur, ey gün, talein kim, düşdün ol xaki-dərə,
Əhli-dövlət damənin tutdun, yetərsən bir yerə.

Damə düşmüş bir şikarəm kim, ədəm səhrasına,
Mənzilimdən hər tərəf açmış əcəl min pəncərə.

Lə’lin ətrafında xəttindən könül eymən degil,
E’timad olmaz yeni imanə gəlmiş kafərə.

Xət nə hacət, əhli-dil qeydinə rüxsarın yetər,
Aləmi tutmaqda gün möhtac olurmu ləşkərə?

Sayə saldın suyə, sərvi-nazi rəşk öldürdü kim,
Mən dururkən, dövləti-vəslin nə nisbət axərə?

Başda hər tük, eşq odundan bir tütündür kim, çıxar,
Cizginən başım bəla bəzmində bənzər məcmərə.

Ey Füzuli, məndə rahət qoymadı şeyda könül,
Istərəm kim, qurtulam ondan, verəm bir dilbərə.


283


Könül, səccadəyə basma ayaq, təsbihə əl urma,
Namaz əhlinə uyma, onlar ilə durma, oturma!

Əgilib səcdəyə, salma fərağət tacını başdan,
Vüzudən su səpib, rahət yuxusun gözdən uçurma!

Saqın, pamal olursan buriya tək, məscidə girmə
Və gər naçar girsən, onda minbər kimi çox durma!

Müəzzin naləsin alma qulağə, düşmə təşvişə,
Cəhənnəm qapısın açdırma, vaizdən xəbər sorma!

Cəmaət izdihami məscidə salmış küdurətlər,
Küdurət üzrə, lütf et, bir küdurət sən həm arturma!

Xətibin sanma sadiq məscidin, qovlilə fe’l etmə,
Imamın sanma aqil, ixtiyarın ona tapşurma.

Füzuli, bəhrə verməz taəti-naqis, nədir cəhdin,
Kərəm qıl, zərqi taət surətində həddən aşurma!


284


Ey vücudi-kamilin, əsrari-hikmət məsdəri,
Məsdəri-zatın olan əşya sifatın məzhəri.

Məzhəri hər hikmətin sənsən ki, kilki-qüdrətin
Səfheyi-əflakə nəqş etmiş xütuti-əxtəri.

Əxtəri məs’ud olan oldur ki, təb’i-pakinin
Qabili-feyz ola lütfündən səfayi-cövhəri.

Cövhəri mə’yub olan naqis mənəm kim, müttəsil
Sadədir xəttin xəyalilə zəmirim dəftəri.

Dəftəri-ə’malımın xətti xətadəndir siyah,
Qən tökər çeşmim, xəyal etdikcə hövli-məhşəri.

Məhşəri əşkim verər seylabə, gər ruzi-cəza
Olmasa məqbul dərgahə sirişkim gövhəri.

Gövhəridir eşq bəhrinin, Füzuli, abi-çeşm,
Leyk bir gövhər ki, lütfi-həq onadır müştəri.


285


Ey vücudun əsəri, xilqəti-əşya səbəbi!
Nəbi ol vəqt ki, bilfe’l gərəkməzdi nəbi.

Seyyidi-əbtəhiyü məkkiyü ümmiyü zəki,
Haşimiyü mədəniyü qüreyşiyü ərəbi [1] .

Səbqəti-zat ilə eyvani-risalət sədri,
Şərəfi-əsl ilə fehristi-rüsul müntəxəbi.

Əzmi-çərx etdi Məsiha ki, bula me’racın,
Yetmədi mənzili-məqsudə təriqi-tələbi.

Ənbiyadan kimə sən tək bu, müyəssərdir kim,
Adəmə vəchi-mübahat ola izzü nəsəbi.

Xələfi-mö’təbəri-Adəmü Həvva sənsən,
Cə’ələllahü fədaən ləkə ümmi və əbi [2] .

Ya Nəbi, qılma Füzulini qapından məhrum,
Əfv qıl, var isə dərgahdə tərki-ədəbi.


1 Tərcüməsi: Məkkəli, dərs oxumamış, zəkalı, bir ağadır, haşimi, mədinəli, qureyşi və
ərəbidir.
2 Tərcüməsi: Allah ata-anamı sənə qurban etsin.


286


Ey xoş ol günlər ki, rüxsarın mənə mənzur idi,
Çeşmi-ümmidim çiraği-vəsldən pürnur idi.

Qürb şövqi afiyətbəxşi-təni-bimar idi,
Vəsl zövqi rahətəfzayi-dili-məhcur idi.

Izzətim şəm’i münəvvər, taleyim əzmi qəvi,
Dövlətim hökmü rəvan, eyşim evi mə’mur idi.

Daməni-iqbalimə gərdi-təərrüz yetməyib,
Çeşmi-hasid çöhreyi-cəm’iyyətimdən dur idi.

Adəm idim, qürbi-dərgahında bulmuşdum qəbul,
Mənzilim cənnət, meyim kövsər, ənisim hur idi.

Bəxt mətlubim müyəssər qılmağa məhkum olub,
Dəhr əsbabim mühəyya qılmağa mə’mur idi.

Hər dua qılsam, təvəqqüfsüz olurdu müstəcab,
Hər təmənna eyləsəm, ehmalsız məqdur idi.

Hicr vəhmindən yetirməzdim küdurət könlümə,
Gərçi dövranın müxalif gəzməgi məşhur idi.

Nola gər salsa Füzulini qəmi-hicranə çərx,
Vəsl əyyamında ol qafil ikən məğrur idi.


287


Ey təğafül birlə hər saət qılan şeyda məni,
Vaqif ol kim, öldürər bir gün bu istiğına məni.

Zə’fim eldən yaşırıb, əhvalimi saxlar, vəli
Naleyi-biixtiyarımdır qılan rüsva məni.

Gər məni xunabeyi-əşkim nihan eylər, nə sud,
Qanda olsam, möhnəti-eşqin qılar peyda məni.

Valehi-zövqi-ləbi-meygunü çeşmi-məstinəm,
Saqiya, sanma xərab etmiş meyü səhba məni.

Xali etmişdir məni məndən məhəbbət, dustlər,
Eyb qılmın, görsəniz aləmdə bipərva məni.

Guşeyi-mehrabə tutmuşdum rəhi-zöhdü səlah,
Qoymadı öz halimə ol nərgisi-şəhla məni.

Ey Füzuli, bir sənəm zülfünə könlüm bağıladım,
Çəkdi zənciri-cünunə aqibət sevda məni.


288


Buraqdı xakə hüsnün afitabi-aləmarayi,
Götürdü yer üzündən mö’cüzi-lə’lin Məsihayi.

Iki gözdən rəvan etmiş sirişkim qamətin şövqi,
Əsayi-mö’cizi gör kim, iki bölmüş bu dəryayi.

Bükülmüş qəddimi qurtarə gör qüllabi-zülfündən,
Xətadır, çəkməsin çox bağrı çökmüş bir sınıq yayi.

Rüxün üzrə xəmi-əbruni görmək istərəm, əmma
Ikən düşvar olur, gün var ikən görmək yeni ayi.

Şərabi-nabə lütf et, möhtəsib, qəhr ilə çox baxma,
Mükəddər qılma əksi-tirədən cami-müsəffayi.

Yedi gündür ol ayi görmədim, ahim şərarilə
Nola qılsam Bənatün-nə’ş ilə yeksan Sürəyyayi.

Füzuli, əşk seylilə pərişan olma, səbr eylə!
Ona həm var ola axir, tutub durarmı dünyayi?


289


Məni candan usandırdı, cəfadən yar usanmazmı?
Fələklər yandı ahimdən, muradım şəm’i yanmazmı?

Qamu bimarinə canan dəvayi-dərd edər ehsan,
Neçün qılmaz mənə dərman, məni bimar sanmazmı?

Qəmim pünhan tutardım mən, dedilər yarə qıl rövşən,
Desəm, ol bivəfa bilmən, inanarmı, inanmazmı?

Şəbi-hicran yanar canım, tökər qan çeşmi-giryanım,
Oyadar xəlqi əfqanım, qara bəxtim oyanmazmı?

Güli-rüxsarinə qarşu gözümdən qanlı axar su,
Həbibim, fəsli-güldür bu, axar sular bulanmazmı?

Degildim mən sənə mail, sən etdin əqlimi zail,
Mənə tə’n eyləyən qafil səni görgəc utanmazmı?

Füzuli rindü şeydadır, həmişə xəlqə rüsvadır,
Sorun kim, bu nə sevdadır, bu sevdadən usanmazmı?


290


1 Nə edək



Getdi əldən sənəmin sünbüli-mişkəfşani,
Yenə dövr etdi pərişan məni-sərgərdani.

Öylə mö’tad olubam atəşi-hicranına kim,
Görməsəm yandırar, əlbəttə, məni hicrani.

Gögdə ahim yeli söndürdü çirağın günəşin,
Yerdə əşkim ayağa saldı düri-qəltani.

Göz bəyazinə çəkər lə’llərin surətini,
Dəmbədəm xameyi-müjgan ilə bağrım qani.

Çıxdı can, kimsəyə izhar edə bilmən dərdim,
Nedəyin [1], ah, bu dərdin nə olur dərmani?

Ey sitəm daşını bidərdlərə zaye’ edən!
Yapa gör bir neçə daş ilə dili-virani.

Versə can, yetməsə cananə, Füzuli, nə əcəb
Hər kişi kim, sevər öz cani üçün canani.


291


Gecələr ta halimə gərdun təmaşa etmədi,
Tərk edib bidadını, bir mehr peyda etmədi.

Navəkin gör kim, yarub əşkim, tutar göz pərdəsin,
Ey deyən Musa əsası qət’i-dərya etmədi.

Hər dəmindən min Məsiha zindeyi-cavid olur,
Sən edən izhari-e’cazi Məsiha etmədi.

Aşiyan ta rövzeyi-kuyində tutdu mürği-dil,
Keçdi tovfi-Kə’bədən, uçmağə pərva etmədi.

Hiç abid anmadı lə’lin ki, gözdən qan töküb,
Səcdədən durduqca, təğyiri-müsəlla etmədi.

Zə’fi-tale’ kəsdi dünyadən nəsibin zahidin,
Yoxsa öz rə’yilə zahid tərki-dünya etmədi.

Etmədi eldən nihan bir gecə tovfi-kuyini
Kim, Füzulini sədayi-nalə rüsva etmədi.


292


Fariğ etdi mehrin özgə məhliqalərdən məni,
Hirz imiş eşqin sənin, saxlar bəlalərdən məni.

Könlüm aldın, göstərib min lütfü minnət canıma,
Eylədin müstəğıni özgə dilrübalərdən məni.

Vamiqü Fərhad tək rüsvayə qılmın nsibətim,
Bir fəqirəm, sanmanız ol xüdnümalərdən məni.

Işvəvü naz ilə dəf’ etdin qəmü ənduhimi,
Sehr ilən biganə etdin aşinalərdən məni.

Qıl təkəllüm, zülfün ənduhini, könlümdən gedir,
Bir füsun ilə xilas et, əjdəhalərdən məni.

Qayəti-zöhdü vərə’, zahid, vüsali-hur isə,
Vəchi yox mən’ etməgin huriliqalərdən məni.

Hər cəfa etsən, Füzuli tək şikayət qılmazam,
Eşq ətvarında sanma bivəfalərdən məni.


293


Çöhreyi-zərdimdə gör həmdəm sirişki-alimi,
Ol güli-rə’nayə bu rəng ilə bildir halimi.

Ta ki, sərvim basə gahi başim üzrə bir qədəm,
Ey müsəvvir, rəhgüzari üzrə çək timsalimi.

Ey fələk, yoxdur libasi-fəqrdən arım mənim,
Ətləsindən bilmişəm üstün mühəqqər şalimi.

Ey xoş ol kim, eşq hərfin bir dəxi təkrar edəm,
Həşr divanında görgəc nameyi-ə’malimi.

Hiç kim yoxdur ki, naləmdən şikayət eyləməz,
Şükr kim, ərz eyləyən çoxdur sənə əhvalimi.

Niyyətim oldur ki, rüxsarın görüb canım verəm,
Müshəfi-rüxsar açıb, qılğıl mübarək falimi.

Sübhü şam ol qibleyi-əbru müqabildir mənə,
Ey Füzuli, Tanrı gözdən saxlasın iqbalimi.


294


Yar qılmazsa mənə cövrü cəfadən qeyri,
Mən ona eyləməzəm mehrü vəfadən qeyri.

Ey deyən “qeyrə könül vermə”, qanı məndə könül,
Səri-zülfündə olan bəxti-qəradən qeyri?

Qıldı Məcnun kimi çoxlar həvəsi-eşq, vəli
Doymadı dərdə, məni-bisərü padən qeyri.

Mişki-Çin zülfün ilə eyləsə də’va nə əcəb,
Nə olur üzü qara qulda xətadən qeyri?

Ləbinə çeşmeyi-heyvan deməzəm kim, ləbinin
Var bir canə yarar feyzi, bəqadən qeyri.

Hiç kim bilmədi təhqiq ilə ağızın sirrin,
Sirri-qeybi nə bilir kimsə xudadən qeyri.

Ey Füzuli, bizə təqdir qəm etmiz ruzi,
Qılalım səbr, nədir çarə rizadən qeyri.


295


Yıxdı saqi bir əyaq ilə məni-əfgari,
Bir təpik eylədi viran bu kühən divari.

Gah mə’mur qılır badə məni, gah xərab,
Görünüz gah yapıb, gah yıxan me’mari.

Gün çıxınca saçaram gövhəri-əşk əncüm tək,
Gecələr yadimə gəldikcə məhi-rüxsari.

Dil yaxar dağ gözün fikri ilə hicr günü,
Bu çirağiləmi saxlar gecə ol bimari?

Yox özündən xəbəri kim ki, gəlir dünyayə,
Bəzmdən dışra qomaz piri-müğan hüşyari.

Bizə çün qədr bulunmaz, çıxalım dünyadən,
Müştəri yox, necə bir bəkliyəlim bazari.

Qeydi-islam, Füzuli, sənə bir afətdir,
Bir həsar edə gör ondan özünə zünnari.


296


Nə görər əhli-cəfa məndə vəfadən qeyri,
Nə bulur şəm’i yaqan kimsə ziyadən qeyri.

Ey olan sakini-məscid, nə bulubsan bilmən,
Buriyasında onun buyi-riyadən qeyri.

Gəl xərabətə, nəzər saqiyə qıl kim, yoxdur
Rüxi-safü meyi-safində səfadən qeyri.

Sərbəsər vadiyi-möhnətdirü qəm mülki-vücud,
Bir fərağət yeri yox şəhri-fənadən qeyri.

Cümleyi-xəlq mənə yar üçün əğyar oldu,
Qalmadı kimsə mənə yar xudadən qeyri.

Əzmi-kuyində könül yarlıq istər bizdən,
Əlimizdən nə gəlir xeyr-duadən qeyri.

Fəqr imiş fəqr, Füzuli şərəfi-əhli-vücud,
Özünə eyləmə həmdəm füqəradən qeyri.


297


Tərəşşüh qəbrimin daşından etmiş çeşmimin yaşi,
Xəyal eylər görən kim, lə’ldəndir qəbrimin daşi.

Nə zibasən ki, surət bağılamaz təsviri-rüxsarın,
Təhəyyür surət eylər, surətin çəkdikcə nəqqaşi.

Nola girdabi-qəm dersə, dili-sərgəştə dünyayə,
Sanır kim, cizginir aləm, kimin kim, cizginir başi.

Sipehri-pürkəvakibdən degil dərdə dəva mümkün,
Xəyal etmən verə tiryaki-zəhri-qəm, bu xəşxaşi.

Bəqasi mümkün olmaz, olsa gər divari-ömründə
Məhü xurşiddən xiştü bina, əflakdən kaşi.

Verər əmvatə ehya badə, guya kim, çıxıb hər dün,
Salır feyzi-Məsiha badəyə xümxanə xəffaşi.

Füzulini rəhi-eşqində əşkü ah edər rüsva,
Bəladır, hər kimin bir yolda qəmmaz olsa yoldaşi.


298


Hasilim yox səri-kuyində bəladən qeyri,
Qərəzim yox rəhi-eşqində fənadən qeyri.

Neyi-bəzmi-qəməm, ey ah, nə bulsan yelə ver,
Oda yanmış quru cismimdə həvadən qeyri.

Pərdə çək çöhrəmə hicran günü, ey qanlı sirişk!
Ki, gözüm görməyə ol mahliqadən qeyri.

Yetdi bikəsliyim ol qayətə kim, çevrəmdə
Kimsə yox cizginə, girdabi-bəladən qeyri.

Nə yanar kimsə mənə atəşi-dildən özgə,
Nə açar kimsə qapım badi-səbadən qeyri.

Pozma, ey mövc, gözüm yaşı hübabın ki, bu seyl
Qoymadı hiç imarət bu binadən qeyri.

Bəzmi-eşq içrə, Füzuli, necə ah eyləməyim,
Nə təməttö bulunur neydə sədadən qeyri?


299


Heyrət, ey büt, surətin gördükdə lal eylər məni,
Surəti-halım görən, surət xəyal eylər məni.

Mehr salmazsan mənə, rəhm eyləməzsən bunca kim,
Sayə tək sevdayi-zülfün payimal eylər məni.

Zə’fi-tale’, manei-tovfiq olur, hər necə kim,
Iltifatın arizuməndi-vüsal eylər məni.

Mən gəda, sən şahə yar olmaq yox, əmma neyləyim,
Arizu sərgəşteyi-fikri-məhəl eylər məni.

Tiri-qəmzən atma kim, bağrım dələr, qanım tökər,
Iqdi-zülfün açma kim, aşüftəhal eylər məni.

Dəhr vəqf etmiş məni növrəs cavanlar eşqinə,
Hər yetən məhvəş əsiri-xəttü xal eylər məni.

Ey Füzuli, qılmazam tərki-təriqi-eşq kim,
Bu fəzilət daxili-əhli-kəmal eylər məni.


300


Aldı gülzar içrə su əksi-üzari-alini,
Çəkdi güllər surətin, mənzur edib timsalini.

Adın etmiş gün, alıb bir əks mir’ati-fələk,
Sübh göstərdikdə sən rüxsari-fərrüxfalini.

Şərhə bir gün qıldığın bidadi çəkməz həşrədək,
Ol mələk kim, yazmaq istər nameyi-ə’malini.

Seyli-xun xalın xəyalilə pozub göz mərdümün,
Mərdüm etmiş çeşmi-xunbarə xəyali-xalini.

Mürği-dil qalmadı kim, seyd olmadı, ey şuxçeşm,
Sakin et pərvazdən şəhbazi-mişkinbalini.

Qoymadın bir kimsə cövrün çəkməyə, rəhm et dəmi,
Mən’ qıl xunrizlikdən qəmzeyi-qəttalini.

Qəm günü üstümdə səndən qeyri yox, ey dudi-ah!
Lütf qıl, məndən götürmə sayeyi-iqbalini.

Ey Füzuli, bəs ki, qəmnak oldu əhvalın soran,
Qəmdən ölsən, hiç kim sormaz dəxi əhvalini.


301


Gördüm ol xurşidi-hüsnün, ixtiyarım qalmadı,
Sayə tək bir yerdə durmağa qərarım qalmadı.

Bir gün olmaz təl’ətin görmək müyəssər, ah kim,
Zərrəcə ol gül yanında e’tibarım qalmadı.

Pak qıldı surətimdən zə’f dəhr ayinəsin,
Öylə məhv oldum ki, bir zərrə qübarım qalmadı.

Qəm günü həmdəmlərim qərq oldular göz yaşinə,
Silməyə göz yaşimi bir qəmküsarım qalmadı.

Ruzigarım xoş keçirdi, ah kim, dövran dönüb,
Oldu əhvalım xərab, ol ruzigarım qalmadı.

Rahi-eşq içrə mənə ancaq fəna məqsud idi,
Şükr kim, məqsudə yetdim, intizarım qalmadı.

Ey Füzuli, el qamu əğyarım oldu yar üçün,
Suzi-dildən qeyri bir dilsuz yarım qalmadı.


302


Hər görən eyb etdi abi-dideyi-giryanimi,
Eylədim təhqiq, görmüş kimsə yox cananimi.

Ləhzə-ləhzə xublar gördüm ki, dil qəsdindədir,
Parə-parə eylədim mən həm dili-suzanimi.

Çox yetirmə göglərə əfğanım, ey kafir, saqın,
Incinir nagəh Məsiha eşidib əfğanimi.

Qılma hər saət məni rüsvayi-xəlq, ey bərqi-ah,
Eyləmə rövşən şəbi-qəm külbeyi-əhzanimi.

Çıxma, ey divanə, bazari-məlamətdən deyər,
Müttəsil çaki-giribanım tutar damanimi.

Qansı bütdür bilməzəm, imanımı qarət qılan,
Səndə iman yox ki, sən aldın deyim imanimi.

Ey Füzuli, canə yetmişdim könüldən, şükr kim,
Bağıladım bir dilbərə, qurtardım ondan canimi.


303


Canımın cismilə zövqi-ittisali qalmadı,
Ah kim, sənsiz dirilmək ehtimali qalmadı.

Şükrallah, bəxt yar oldu, yetirdim tiğinə,
Başımın bir qılca boynumda vəbali qalmadı.

Istədim ol mahə ərzi-hal edim, heyrət mənə
Öylə qalib oldu kim, bir söz məcali qalmadı.

Bilməzəm xalin xəyalın qanda təsvir eyləyim,
Dağıdən bir yer tənü canımda xali qalmadı.

Hər kimi gördünsə qəm üftadəsi, tutdun əlin,
Vəh ki, məndən qeyri bir qəm payimali qalmadı.

Ey xoş ol sərməst kim, könlündə şövqü zövqdən
Axirət əndişəsi, dünya xəyali qalmadı.

Afərin, ey cam, kim, sildin könül ayinəsin,
Xatiri-pakimdə dünyanın məlali qalmadı.

Dürd nisbət, payimali-qeyddir hər kim ki, var,
Bəzmi-dəhr içrə hərifi-laübali qalmadı.

Gör, Füzuli, eşq tüğyanın, ədəm mülkün gözət,
Əzmi-künc et kim, həvanın e’tidali qalmadı.


304


Giryədir hər dəm açan qəmdən tutulmuş könlümü,
Əşkdir xali qılan qan ilə dolmuş könlümü.

Ey pərivəşlər, cəfa rəsmin unutmın, lütf edin,
Eyləmin bədxu cəfa mö’tadı olmuş könlümü.

Və’deyi-vəsl ilə, ey gülrüxlər, etmin müztərib,
Möhnəti-hicran ilə aram bulmuş könlümü.

Xəncəri-bidad ilə hər dəm görər zəxm üzrə zəxm,
Hiç bir dəm görmədim onmuş, onulmuş könlümü.

Payibəndi-lütf olub, bir yerdə sakin bulmadım
Dəşti-heyrətdə tərəddüddən yorulmuş könlümü.

Simbərlərdən gələn daşları yığmış çevrəmə,
Eşq mə’mur eyləmək istər pozulmuş könlümü.

Hər zaman bir atəşinrüxsar sevdasın çəkər,
Ey Füzuli, gör bu odlarə urulmuş könlümü.


305


Sanma kim, bülbül açar uçmağa balü pərini,
Gül yaqıb onu savurmuş gögə xakistərini.

Gözümü üzüm arasında çəri çəkdi müjəm
Ki, gözümdən su çıxıb yumaya xaki-dərini.

Mövci-əşkim görüb, əbruyə salır çin, nə əcəb
Ki, su urmaq çıxarır ol qılıcın cövhərini.

Düşdü vəsfi-düri-dəndani ağızdan ağıza,
Eşidib saldı biyabanə dəniz gövhərini.

Göz yüzün görməsə qanlar tökülər, ah, nola,
Fitneyi basə, müşərrəf qıla göz mənzərini.

Rəşheyi-cam bizi tutdu, nola gər saqi
Gələ qurtarə bizi, alə əyaği tərini.

Oldu nəzzarəmizə cəm’, Füzuli, ətfal,
Gəl tutalım bu sipah ilə cünun kişvərini.


306


Tabi-suzi-sinədən əksilməsəydi göz nəmi,
Göz yumub-açınca seylabə verərdim aləmi.

Hər gözüm pürmövc dəryadır, o dərya üzrə kim,
Hər qaşımdır mövcdən bir sərnigun olmuş gəmi.

Muyi-julidəmdədir cəm’iyyəti-əsnafi-qəm,
Mülki-sevdanın budur guya səvadi-ə’zəmi.

Hicr var, ey didə, vəsl əyyamı tökmə xuni-dil,
Saxla kim, əlbəttə, anın həm gələr bir gün dəmi.

Adəmidən çox olur zahir pərivəşlər, vəli
Az olur vaqe’ pərivəşlərdə sən tək adəmi.

Vəsl yadilə, könül, söndürmə ahim atəşin,
Külbeyi-tarimdən ikrah etməsin hicran qəmi.

Ey Füzuli, qıldı canım riştəsin pürpiçü tab,
Bir pərivəş dilbərin sevdayi-zülfi-pürxəmi.


307


Tilismi-gənc üçün min ismi-ə’zəm yad tutdun, tut!
Tilismi sındırıb, gənci töküb, ismi unutdun tut!

Töküb mey, cami-mey tutmaq təmənnasın çıxar başdan,
Yügüş qanlar töküb, aləmdə çox xunabə yutdun, tut!

Şərabi-nab zövqindən nə hasil, çün degil baqi,
Piyazi-ömrə min gəz su verib, axır qurutdun, tut!

Çü nə Cəmşid bulmuşdur bəqa keyfiyyətin, nə Cəm,
Bu bəzm içrə Cəmü Cəmşid əlindən cam tutdun, tut!

Füzuli, qıl qiyasi-halin əhli-dəhr halindən,
Qümari-məkrü təzviri hiyəl əhlindən utdun, tut!

***

Şö’leyi-şəm’i-rüxün əğyarə bəzməfruz olur,
Ah kim, yetgəc mənə bir bərqi-aləmsuz olur.

Qeyr çeşmindən bulur hər dəm nigahi-mərhəmət,
Bən nə qıldım kim, nəsibim navəki-dilsuz olur.

Hər gün açır könlümü zövqi-vüsalın yengidən,
Gərçi güllər açmağa hər ildə bir novruz olur.

Halətək çıxmaz evindən mahtəl’ətlər müdam,
Hər kimin dövri-qəmərdə talei firuz olur.

Saidin zövqilə tərk etmiş Füzuli aləmi,
Meyli-səhra eyləməz hər quş ki, dəstamuz olur.


308


Xoşdur irmək ol bədən vəslinə pirahən kimi,
Gəh əl öpmək astin tək, gəh ayaq damən kimi.

Əks salmaz peykərim güzguyə baxsam, zə’fdən,
Aləmi-surətdə bir şeyda bulunmaz mən kimi.

Cəm’dir könlün sənin kim, var mən tək çoxların,
Mən pərişanəm ki, tapılmaz mənə bir sən kimi.

Bu çəmən gülrüxlərinə dərdi-dil qılmaz əsər,
Yüz dilin var isə, xamuş ol, könül, susən kimi.

Gər dilərsən edəsən nəzzareyi-didari-yar,
Kənduzin görmə aradə, dideyi-rövşən kimi.

Damənin doldursa gərdun dürr ilən, tök əbr tək,
Dürr üçün təlx etmə kamın bəhri-tərdamən kimi.

Sal nəzərdən lə’li həm görsən, sirişki-al tək,
Lə’l üçün hər daşə urma başını, mə’dən kimi.

Kargahi-sün’dən bir surət et nəqşi-zəmir,
Min xəyalın tutmagil, sərrişteyi-suzən kimi.

Göz yaşilə danə-danə cəm’i-əsbab etmə kim,
Yelə verər dəhr onu, pamal edib xirmən kimi.

Bəhrlər seyr eyləsən, mütləq tər olmaz damənin,
Gər həvayi-eşq ilə məmlüvisən yelkən kimi.

Qanda olsan, qapı lövhi tək gözət ismət yolun,
Açma göz divarlərdən hər evə rövzən kimi.

Ey Füzuli, mənzili-məqsudə yetmək istəsən,
Hiç rəhbər yoxdürür ətvari-müstəhsən kimi.


309


Qərqi-xunabi-dil etdi dideyi-giryan məni,
Onca qan tökdüm ki, bu rəng ilə tutdu qan məni.

Hər tərəf yüz qəm həlakim qəsdin etmiş, Tanrıçün
Bir dəm ey gözdən axan xunabə, qıl pünhan məni.

Yox məcalim özgə gülrüxsarə sənsiz baxmağa,
Eyləmiş hicri-rüxün öz halıma heyran məni.

Ruzi-hicr, ey gün, çəkib bir tiğ, minnət qoy mənə,
Yoxsa minnətsiz həlak eylər şəbi-hicran məni.

Qərqi-xunab oldu cismi-xaksarim, ah, kim,
Dürdvəş saldı ayaqlarə qəmi-dövran məni.

Pənbeyi-dağim nihan etmiş sərasər cismimi
Kim, məlamət qılmaya hər kim görüb üryan məni.

Bir məhi-bimehrəyəm mail, Füzuli, yox əcəb,
Qılsa hər yan, zərrə nisbət, çərx sərgərdan məni.


310


Mey peyapey sunma, saqi, qılma layə’qil məni,
Etmə bir dəm dövləti-didardən qafil məni.

Zəhri-qəhrin içmədən var isə qəsdin, qətlim et,
Abi-heyvan içsəm öldürmək olur müşkil məni.

Ar qətlimdən sənə, mən təşnə abi-tiğinə,
Öldürər həsrət gər öldürməzsən, ey qatil, məni.

Mən sənə heyranü məndən qeyri səndən bixəbər,
Şükr ona kim, eşqinə qılmış haman qabil məni.

Ey xoş ol sərməstlik vəqti ki, rəf’ olub hicab,
Zövqi-mey biixtiyar eylər sənə mail məni.

Dönə-dönə lə’li-meygunin öpər, ey qönçələb,
Qılmasınmı rəşki-cami-badə xunindil məni.

Zövq nöqsani bir afətdir mənə, ey piri-deyr!
Qoyma naqis, bir neçə cam ilə qıl kamil məni.

Qurtulum qəmdən, derəm, kuyində, əmma bilməzəm,
Qurtararmı bəhri-qəm mövcündən ol sahil məni.

Ey Füzuli, dövləti-baqi fənadəndir mənə
Kim, fənadır eyləyən məqsudimə vasil məni.


311


Qamətin xidmətinə sərvin əgilməz başi,
Nə bilir əhli-təriqin rəvişin ol naşi.

Ögünür didə ki, heyranəm əzəldən üzünə,
Oldu mə’lum bu lafında ki, çoxdur yaşi.

Əşk lə’li rəhi-eşqində tutubdur ətəgim,
Qorxuluqdur, necə salıb gedəlim yoldaşi?

Yetdi ol qayətə zə’fim ki, çəkər təsvirim
Hər zaman daireyi-heyrətə min nəqqaşi.

Möhtəsib, Tanrı üçün’ gəl mənə çox vermə əzab,
Meyli-məscidmi edər meykədələr ovbaşi?

Kəsdi mən şiftədən əhli-səlamət yolunu,
Bəs ki, ətrafıma cəm’ oldu məlamət daşi.

Ey Füzuli, nə bəla oxları kim, gəlsə mənə,
Səbəb ol qaşları yayin gözüdür, ya qaşi.


312


Mərhəm qoyub önərmə, sinəmdə qanlı daği,
Söndürmə öz əlinlə yandırdığın çiraği.

Uymuş cünunə könlüm, əbrunə der məhi-növ,
Nə e’tibar ona kim, seçməz qaradan aği.

Qəddin qəmində sərvin sormağa zə’fi-halın,
Gülzardən kəsilməz irmaqların əyaği.

Dür tək dişin sözünü hər dəm eşitmək istər,
Bəhrin müdam onunçün sahildədir qulaği.

Zülfü sayəh sənəmlər olmuş sənin əsirin,
Eşqində hər birinin öz lütfü boynu baği.

Gər mişk dersə aşiq ol buyi-zülfə, saqi,
Tünd olma, bir qədəh ver, tər eyləsin dimaği.

Dövran həvadisindən yox bakimiz, Füzuli,
Darül-əmanımızdır meyxanələr bucaği.


313


Xoş gəldi dün ol ayə sirişkim nəzarəsi,
Böylə olur ki, aşiqin işlər sitarəsi.

Ey hər mərəz ilacinə hökm eyləyən həkim,
Bimari-dərdi-eşq olanın yoxmu çarəsi?

Çıxmaq dilər səfineyi-tən cünbüşilə can
Dəryayi-eşqdən ki, ədəmdir kənarəsi.

Derlər ki, var Vamiqü Məcnun, əcəb degil,
Dağılmış ola atəşi-eşqim şərarəsi.

Noldu gətirmədin ələ sədparə könlümü,
Vəhm eylədinmi əl kəsə bu şişə parəsi?

Səndən həmişə tiri-bəladır gələn mənə,
Böylə olurmu aşiqü mə’şuqin arəsi?

Ey söyləyən Füzuliyə eşq içrə səbr qıl,
Söylə, bu mərhəm ilə kimin bitdi yarəsi?


314


Məgər xab içrə gördün, ey könül, ol çeşmi-şəhlayi
Ki, qıldın türfətül-eyn içrə qərqi-əşk dünyayi.

Yetirdi ahimi gərdunə ol büt, gör nə kafirdir,
Deməz kim, gögdə nagəh incidə naləm Məsihayi.

Çəkərsən, ey müsəvvir, surətin ol məhvəşin, əmma
Nə mümkündür muradincə çəkilmək qaşları yayi.

Bəladır şəhrlərdə mən kimi rüsvayi-xəlq olmaq,
Nə xoş Fərhadü Məcnun mənzil etmiş kuhü səhrayi.

Görünməz yar, xəlq əşkim təmaşasinə cəm’ olmuş,
Əgər nagəh görünsə ol pəri, gəl gör təmaşayi.

Tutub quşlar başımda aşiyan, fəryadə gəlmişlər,
Çıx, ey ahim odu, bir dəm başımdan sav bu qovğayi.

Füzuli, zülfi sevdasın qələm tək başa salmışsan,
Gedər başın, əgər başdan gedirməzsən bu sevdayi.


315


Mübəddəl qılmağa sübhi-vüsalə şami-hicrani,
Mənim ahim əlidir sübhü şam çərx damani.

Gözüm yaşilə həmrəng olduğiçün kəşfi-razında,
Basırkən bağrıma, düşdü gözümdən bağrımın qani.

Dili-pürxunmudur sinəmdə, ya ol qaşları yayın
Çəkilmiş navəki, cismimdə qalmış qanlı peykani?

Üzün görmək təmənnasindəyəm, əmma budur müşkül
Ki, dəm düşdükcə açdırmaz mənə göz əşk tüğyani.

Dedin, ey Xizr, bənzər yar lə’li abi-heyvanə,
Bu tə’zim ilə topraqdan götürdün abi-heyvani.

Nisari-xaki-payin layiqi bir gövhər istərdim,
Qamu gözdən keçirdim qətrə-qətrə əşki-qəltani.

Füzulinin yetər eşqinə inkar eylə, ey gərdun!
Güvahi-hal yetməzmi sənə fəryadü əfğani?


316


Yetər, ey fələk, bu cəfa, yetir məni-zarə sərvi-rəvanimi,
Məhi-təl’ətilə münəvvər et, dilü dideyi-nigəranimi.

Rüxum üzrə xətti-sirişkimi, dəfəatilə qələmi-müjəm,
Rəqəm etdigiçün el oxuyub, bilir oldu razi-nihanimi.

Cigərim odunu nihan ikən, elə zahir etdi mürur ilə,
Görəyim yerə keçə abi-çeşmi-təri-şərarəfşanimi.

Tutalım ki, zülfi-siyahını tutan üzrə sabit olur günəh,
Nə rəva ki, qəmzeyi-qatilin, günəh etmədən tökə qanimi?

Bu bəlayə saldı məni qədin ki, yaşırdı yer üzünü yaşım,
Bu yerə ytirdi məni qəmin ki, ələk eşitdi fəğanimi.

Necə qəddü xalü xətü rüxün qəmü rəncü dərdü bəla ilə,
Bükə qəddimi, tökə yaşımı, yıxa könlümü, yaxa canimi.

Sitəmin daşiylə başı sınıq, bədəni şikəstə Füzuliyəm,
Bu əlamətilə bulur məni, soran olsa namü nişanimi.


317


Ey səfi-novki-müjən zülfi-məlamət şanəsi,
Hər gireh zülfündə bir dami-təhəyyür danəsi.

Bülbüli-can övci-istiğınayi-hüsnün tairi,
Tairi-dil pərtövi-şəm’i-rüxün pərvanəsi.

Könlümü qılmış xəyali-mərdümi-çeşmin vətən,
Şükr kim, mərdümnişin olmuş bu qəm viranəsi.

Dövri-rüxsarində xəttin hey’əti eşq əhlinə,
Bəzmi-qəmdə qanilə dolmuş bəla pemanəsi.

Şəm’i ruyin tabi xurşidi-qiyamət pərtövi,
Höqqeyi-lə’lin sözü xabi-ədəm əfsanəsi.

Zaye’ olmaz vadiyi-vəhdətdə ol avarə kim,
Bəsteyi-zənciri-zülfündür dili-divanəsi.

Qanlı yaşın bəs ki, saçmışdır Füzuli hər tərəf,
Lalərəng olmuş hübabi-mey kimi xümxanəsi.


318


Ayinə sevər candan rüxsareyi-canani,
Bir qayətə yetmiş kim, ayrılsa çıxar cani.

Fəryad ki, əks oldu ol kim görəyim derdim,
Ayineyi-rüxsarın lövhi-dili-heyrani.

Ol çahi-zənəxdanda derdim görərəm könlüm,
Könlümdə görər oldum ol çahi-zənəxdani.

Azadələrin könlün cəm’ etmiş ikən qəflət,
Təprətmə səba, billah, ol zülfi-pərişani.

Yarə qəmi-pünhanım izhar edə bilməzdim,
Şadəm ki, rəvan oldu gözdən cigərim qani.

Dərdü qəmi-pünhanim fəhm etdi el ahimdən,
Yüz ah ki, faş oldu dərdü qəmi-pünhani.

Hicran gecəsi görgəc duzəx ələmin, bildim
Kim, ruzi-qiyamətdir yarın şəbi-hicrani.

Candan keçəli buldum rahət qəmi-aləmdən,
Xoş hikmət ilə buldum ol dərdə bu dərmani.

Yarəb, nə səbəbdəndir kim, hiç əsər qılmaz
Dildarə Füzulinin fəryad ilə əfğani.


319


Məhşər günü görüm derəm, ol sərvqaməti,
Gər onda həm görünməsə, gəl gör qiyaməti.

Tərki-mey etdin, ey könül, əyyami-gül gəlir,
Əlbəttə, bu işin çəkilir bir nədaməti.

Məcnun ki, padşahi-sipahi-vühuş idi,
Mən tək müsəxxər etmədi mülki-məlaməti.

Səhranəvərd ikən, mənə təsviri-Kuhkən,
Öyrətdi şəhri-eşqdə rəsmi-iqaməti.

Səngi-məlamət ilə çəkin çevrəmə həsar,
Əşkim fənayə verməsin əhli-səlaməti.

Zahid, çox etmə tə’n mey üftadəsinə kim,
Çoxları yıxdı piri-müğanın kəraməti.

Qəm zülmətində bulmağa dərdü bəla məni
Bəsdir, Füzuli, atəşi-ahim əlaməti.


320


Rəvacın nəqdi-peykanınla bulmuş hüsn bazari,
Keçər nəqdin əgər min Yusifin olsan xəridari.

Məgər dövri-rüxün tərhin çəkər gül səfhəsi üzrə
Kim, olmuş gövhərəfşan bülbülün pərgar minqari.

Çəkər min dairə çevrəmdə hirz üçün sirişkimdən,
Xəmidə qəddimin bihudə cizginməz bu pərgari.

Keçər naləm fələkdən, xəm qədimi çəngə bənzətmin
Ki, çıxmaz pərdədən çəngin sədayi-naleyi-zari.

Yeni aydan fələk səthində min qalib düzüb-pozmuş,
Verincə qaşların taqinə surət sün’ me’mari.

Sənəmlər xidmətin taət bilən rind əcrsiz qalmaz,
Qılar min rişteyi-təsbih işin hər tari-zünnari.

Füzulini dəhanın həsrəti bir dərdə salmış kim,
Nə pünhan etməyi mümkündür ol dərdin, nə izhari.


321


Ey, hər təkəllümüm xəti-səbzin hekayəti!
Virdim həmişə müshəfi-rüxsarin ayəti!

İrmiş səhih nəql ilə ərvahi-qüdsdən,
İsayə mö’cizi-ləbi-lə’lin rəvayəti.

Dil kişvərini qarət edərlərdi xublər,
Mən’ etməsəydi şəhneyi-şövqün himayəti.

Bildim təriqi-eşq xətərnakdir, vəli
Mən dönməzəm bu yoldan, ölüm olsa qayəti.

Qəddin həlakiyəm, düşə bilmən əyağinə,
Bir dərdə düşmüşəm ki, bulunmaz nihayəti.

Bəs kim, səni görəndə gedər məndən ixtiyar,
Gəlməz bəyanə möhnəti-eşqin şikayəti.

Şükr et, Füzuli, qılma fəğan, yar qılsa cövr,
Kim, əhli-eşqə cövrdür onun inayəti.


322


Göz qarası əşki-gülgunimdə xalın sədqəsi,
Əşki-gülgunim güli-rüxsari-alın sədqəsi.

Dudi-ahimdən qararmış zarü sərgərdan tənim,
Atəşin rüxsar üzə mişkin hilalın sədqəsi.

Şövqi-vəslin yandıran naqis vücudum, mah tək
Zərrə-zərrə afitabi-bizəvalın sədqəsi.

Aşiyani-təndə mürği-ruhi etmən tərbiyət,
Olmasa pərvanə tək şəm’i-cəmalın sədqəsi.

Hicranə başım fəda olsun ki, canım almadın,
Etdim axir müjdeyi-zövqi-vüsalın sədqəsi.

Yusifi-gümgəştə kimdir kim, sana manənd ola?
Yüz ona manənd hüsni-bimisalın sədqəsi.

Əfv edər xidmətdə hər nöqsanımız piri-müğan,
Ey Füzuli, canımız əhli-kəmalın sədqəsi.


323


Ləbin əksi gözüm yaşini mey tək laləgun etdi,
Zənəxdanın muradım dəstgahın sərnigun etdi.

Sənə əksin müqabil durduğiçün hüsn lafilə
Onu cam içrə qeyrət qərqeyi-girdabi-xun etdi.

Özün nisbət qılırdı zülfünə zəncir hər saət,
Bu sevdalər onu sərhəlqeyi-əhli-cünun etdi.

Onun tək kim, pərişanlıq ziyasın artırır şəm’in,
Mənə gövrün ziyad olmaq, sənə meylim füzun etdi.

Müjən xəncərlərin könlüm basır bağrına, vəhm etməz,
Ona cadu gözün guya ki, tə’limi-füsun etdi.

Bəqayi-surəti-Şirin üçün tovfiq me’marı,
Binayi-eşqi-Fərhadın əsasın Bisütun etdi.

Füzulidən səbatü səbrü cövrü qəhr az istə
Kim, ol biçarəyi dərdü qəmin bihəd zəbun etdi.


324


Ey saçın fikri qamu sevdalərin sərmayəsi!
Olmasın başimdən əksik sərvqəddin sayəsi.

Baş qoyar hər sübhdəm xurşid xaki-payinə,
Bu səadətdən onun gəldikcə artar payəsi.

Sən səlamət kisvətin zivər qıl, ey əhli-səlah
Kim, mənə bəs muyi-julidəm cünun pirayəsi.

Görməmiş məhdi-zəmin bir tifl sən tək, ta fələk
Dəhr zalın qılmış ətfali-rəyahin dayəsi.

Bərqi-ahindən Füzulinin göyərdi bixəbər,
Dünlər əfğanilə bidar olmasa həmsayəsi.


325


Dün könül dilbərə şərhi-qəmi-pünhan etdi,
Cəm’ ikən, könlünü bir parə pərişan etdi.

Yer tutam, derdi könül, nalə ilə kuyində,
Yetmədi bir yerə hər necə ki, əfğan etdi.

Və’də verdi cigərim qanın içə müjganın,
Intizar ilə bu həsrət cigərim qan etdi.

Qəmzə tiğilə gözün könlümü yüz parə qılıb,
Hər birin bir hədəfi-navəki-müjgan etdi.

Qıldı mehrabə qaşın fikri fəqihi mail,
Gör necə kafiri ol və’z müsəlman etdi.

Görəyin çox yaşasın didə ki, mərdümlük edib,
Qəm hücumində məni əşk ilə pünhan etdi.

Ey əcəl, can təməin qılma Füzulidən kim,
Bir kəmanəbruyə çoxdan onu qurban etdi.


326


Ey göz, ol nərgisi-xunxarə nigah etmə dəxi,
Ruzigarım qəmi-eşq ilə siyah etmə dəxi!

Ey gözüm yaşı, bu sərgəştəligin tərkin qıl,
Sərvqamətlərə qət’i-səri-rah etmə dəxi!

Ey könül, ömrümü verdin yelə aşiqlik ilə,
Baxma hər qönçələbü gülrüxə, ah etmə dəxi!

Baxma, ey can, xətü rüxsarına məhbublərin,
Ehtiyat eylə, günah üzrə günah etmə dəxi!

Qılma, ey eşq, mənə ərz pəriçöhrələri,
Surəti-halimi ləhv ilə təbah etmə dəxi!

Götür, ey nəfs, həvavü həvəsin aləmdən,
Hərzə-hərzə tələbi-rif’əti-cah etmə dəxi!

Ey Füzuli, meyü mə’şuq məzaqın tərk et,
Özünü asiyi-dərgahi-ilah etmə dəxi!


327


Könül, yetdi əcəl, zövqi-rüxi-dildar yetməzmi?
Ağardı muyi-sər, sevdayi-zülfi-yar yetməzmi?

Yetirdi başini gərdun əyağə bari-möhnətdən,
Xəyali-həlqeyi-geysuyi-ənbərbar yetməzmi?

Sənə yetdi əcəl peymanəsin nuş etməyə növbət,
Həvayi-çeşmi-məstü qəmzeyi-xunxar yetməzmi?

Yetər oldu qulağə bangi-rehlət dəhr bağından,
Nə durmuşsan, təmaşayi-güli-rüxsar yetməzmi?

Yetər, cəm’ eylə bari-mə’siyət, təğyiri-ətvar et,
Həya qıl, yoxmudur insafın, ol kim var, yetməzmi?

Hidayət mənzilinə yetdilər sə’yilə əqranın,
Zəlalət içrə sən qaldın, sənə ol ar yetməzmi?

Füzuli, demə yetmək mənzili-məqsudə müşküldür,
Tutan damani-şər’i-Əhmədi-Müxtar yetməzmi?


328


329


330


1 Zamin



**1**

Mən kiməm? – Bir bikəsü biçarəvü bixaniman,
Taleim aşüftə, iqbalım nigun, bəxtim yaman.
Nəmli əşkimdən zəmin məmlu, ünümdən asiman,
Ahü naləm navəki peyvəstə, xəm qəddim kəman.
Tiri-ahim bixəta, tə’siri-naləm bigüman,
Müttəsil qəmxaneyi-sinəmdə yüz qəm mihman.
Qanda bir qəm itsə, məndən istəsinlər, mən zəman [1],
Yox mənə qeydi-bəlavü dami-möhnətdən aman.
Çıxmadı könlümdən ənduhü qəmü möhnət həman,
Ey mənim canım sənü könlüm səninlə şadiman.
Sənsiz olman ayrı möhnətdən, bəladən bir zəman,
Əl-əman, hicran bəlavü möhnətindən, əl-əman!

**2**

Fariğ idim cümlə aləmdən, bilir aləm məni,
Eyb edərdi bixəbər sanıb bəniadəm məni.
Qoymadı dövrani-çərx öz halimə xürrəm məni,
Şad ikən aləmdə, çərx etdi əsiri-qəm məni.
Eşq nagəh oldu peyda, tutdu müstəhkəm məni,
Saldı yüz sevdaya ol geysuyi-xəm dər-xəm məni.
Şimdi Məcnundan rəhi-eşq içrə sanmın kəm məni,
Yar xud qılmaz hərimi-vəslinə məhrəm məni.
Sən ki, məhrəmsən, səba, billah, anıb hər dəm məni,
Söylə ey gül kim, sənə bəxt eyləməz həmdəm məni.
Sənsiz olman ayrı möhnətdən, bəladən bir zəman,
Əl-əman, hicarn bəlavü möhnətindən, əl-əman!

**3**


331


Bülbüli-zarəm, güli-rüxsari-alindən cüda,
Tutiyi-laləm, şəkərnisbət məqalindən cüda.
Der idim səbr eyləyim, olsam cəmalindən cüda
Bilmədim düşvar imiş olmaq vüsalindən cüda.
Tirə oldu ruzigarim zülfü xalindən cüda,
Oldu səhra mənzilim vəhşi qəzalindən cüda.
Mu tək incəldi tənim nazik nəhalindən cüda,
Xəm gətirdi qamətim, mişkin hilalindən cüda.
Çıxdı cani-natəvan, şirin zülalindən cüda,
Oldum, əlqissə, rüxi-fərxündəfalindən cüda.
Sənsiz olman ayrı möhnətdən, bəladən bir zəman,
Əl-əman, hicran bəlavü möhnətindən, əl’əman!

**4**

Sinə çakü didə nəmnakü bədən əfgardir,
Can həzin, xatir qəmin, şeyda könül bimardir.
Mən bu qəm içrə ki, dəf’in eyləmək naçardir,
Məsləhət sordum, dedilər məsləhət izhardir.
Söylədim dərdi-dilimni bildi ol kim yardir,
Qılmadı bir rəhm bəs kim, zalimü xunxardir.
Dəxi izhar edəmən, nə hacəti-təkrardir,
Eyləyim səbrü təhəmmül ta həyatim vardır.
Canə yetgəc ta ki, məndə qüvvəti-göftardir,
Söylərəm: ey gül ki, səndən ayrılıq düşvardir,
Sənsiz olman ayrı möhnətdən, bəladən bir zəman,
Əl-əman, hicran bəlavü möhnətindən, əl-əman!

**5**


332


**1**

Mənəm ki, qafiləsalari-karivani-qəməm,
Müsafiri-rəhi-səhrayi-möhnətü ələməm.
Həqir baxma mənə, kimsədən sağınma kəməm,
Fəqiri-padişahasa, gədayi-möhtəşəməm,
Sirişk təxti-rəvandır mənə, bu ah, ələm,
Cəfavü cövr – mülazim, bəlavü dərd – həşəm.

**2**

Nə mülkü mal mənə çərx versə, məmnunəm,
Nə mülkü maldən avarə qılsa məhzunəm.
Əgərçi müflisü pəstü mühəqqərü dunəm,
Dəmadəm öylə xəyal ellərəm ki, Qarunəm.
Könüldə nəqdi-vəfa gənci, leyk pünhani,
Gözüm xəzaneyi-lə’lü gühər, vəli fani.

**3**

Həyat sərf edübən, dərd qılmışam hasil,
Sirişki-alü rüxi-zərd qılmışam hasil,
Zəmir güzgüsünə gərd qılmışam hasil,
Təbiəti-səgi-şəbgərd qılmışam hasil,
Işim qara, gecə ta sübh naləvü fəryad,
Nə versələr ona şakir, nə desələr ona şad.

**4**

Sirişkriz güləndamlər həvasilə,
Şikəstəhal siyəhzülflər bəlasilə,
Zəmanə içrə qəmi-eşq macərasilə,
Həmişə məsləhətim özgələr rizasilə,
Nə dövri-gərdişi-gərdun mənim muradimlə,
Nə qayəti-əməlim hüsni-e’tiqadimlə.

**5**

Həsud surəti-əhvalimə nəzər qılmaz,
Cəfa qılır məni biçarəyə, həzər qılmaz,


334


Sanır ki, naləvü zarım ona əsər qılmaz,
Onu mürur ilə aləmdə dərbədər qılmaz,
Zəmanə içrə mücərrəbdir intiqami-zəman,
Həmişə yaxşıya yaxşı verər, yəmanə yəman.

**6**

Xoşam ki, xameyi-təqdiri-eyzədi-mütəal,
Vücud lövhinə təsvir edəndə surəti-hal,
Rəqəm qılıb əgər idbardır və gər iqbal,
Olur təğəyyür ona qeyridən bu əmri-məhal,
Səadəti-əzəli qabili-zəval olmaz.
Günəş yer üstünə həm düşsə, payimal olmaz.

**7**

Əzizi-həq həsədi-düşmən ilə olmaz xar,
Həsud hiyləsi iqbali eyləməz ibdar.
Əgərçi gülbünə gahi xəzandan afət var,
Tədarük eylər ona afiyət nəsimi-bəhar.
Qərəz ki, hər kim əzəldən olursa dövlətmənd,
Məhaldır yetə asari-dövlətinə gəzənd.

**8**

Əgərçi bir neçə gün iqtizayi-aləmi-dun,
Cahanda eylədi iqbal ra’yətini nigun.
Zəmanə surəti-əhvalim etdi digərgun,
Vəfa xətinə qələm çəkdi çərxi-buqələmun,
Bu gün zəmanə ol əhvaldən peşimandır,
Əgərçi kafər idi, haliya müsəlmandır.

**9**

Füzuli, eylədigin əhdinə vəfa qılğıl,
Yetər şikayət edib şərhi-macəra qılğıl,
Vücudunu hədəfi-navəki-bəla qılğıl,
Qamu cəfalərə səbr eyləyib dua qılğıl.
Kim ola dust rizası həmin sənə hasil,
Rizayi-düstdur əsli-təməttö’, ey qafil!


335


**1**

Gətir, saqi, qədəh kim, növbahari-aləmaradır!
Zəmin səbzü həva canbəxşü gülşən rahətəfzadır!

Pərişan olma kim, gülbərg tək hala bu gülşəndə,
Nişatü eyş üçün əsbabi-cəm’iyyət mühəyyadır.

Açıldı lalə, güldü qönçə, gəldi işrət əyyami,
Zəbani-hali-səbzə işrət iymasına guyadır.

Gör öz halini vü çəkmə qəmi-mazivü müstəqbəl
Ki, hala mövsimi-gülgəştü dövri-cami-səhbadır.

Səhər gülzarə gir, billah, bu mövsimlərdə vü hərdəm,
Təmaşa qıl ki, divanında gülün xoş təmaşadır.

Açıldı qönçə tumarı və mə’lüm oldu məzmuni,
Budur kim: fövt qılman [1] mövsimi-gül, cami-gülguni.

**2**

Gətir, saqi, qədəh, bil kim, təəllül fövti-fürsətdir,
Bu firsət var ikən fövt etmə kim, fürsət qənimətdir.

Zəminə: “keyfə yöhyil-ərz” [2] yazmış xameyi-səbzə,
Nəzər qıl kim, bu həm asari-rəhmətdən bir ayətdir.

Deyirlər cənnət içrə atəş olmaz, bu əcəbdir kim,
Gülüstan atəşin gül birlə rəşki-baği-cənnətdir.

Cahani rəşki-gülzari-Xəlil etkən bahar iməs,
Bu feyzi-ədli-Ibrahim xani-paksirətdir.

Onun yanında kim, gülbərg gülzari-məanidir,
Onun bəzmində kim, sərvi-rəvani baği-behcətdir.


1 Qılmayın
2 Yeri necə dirildər.

336


Açıldı qönçə tumarı və mə’lum oldu məzmuni,
Budur kim: fövt qılman mövsimi-gül, cami-gülguni.

**3**

Gətir, saqi, qədəh, boldunsa [1] hali-dəhrdən agəh
Ki, dövran üzrədir peyvəstə sübhü şamü salü məh.

Xəzandan qurtulub gülzar bəzmində azan bülbül,
Çiraği-gül yaqub, xəlvətsərayi-vəslə bulmuş rəh.

Gül açmış xani-vəslin, bülbülə təklif edər hər dəm
Ki, gər mehman isən xani-Xəlilullahə, bismilləh.

Cahandan dün mükəddər xatir idim fali-fəthi çün
Bu gün gülzarə girdim gül kitabın açmağa nagəh.

Açıldı qönçə tumarı və mə’lum oldu məzmuni,
Budur kim: fövt qılman mövsimi-gül, cami-gülguni.

**4**

Gətir, saqi, qədəh kim, eyş xoşdur gül zamanində,
Zaman fövt dəhrin qüsseyi-sudü ziyanində.

Qümari “təhtəhəl-ənhar” [2] oxur gülzar vəsfində.
Ənadil “hazihi cənnat” [3] oxur gülzər şə’nində.

Səba qönçə dəhanın pürzər etsə, eyb irməz kim
Ki, mədhi-xani-xaqanqədrdir qönçə dəhanində.

Hava səbzə zəbanin tiz əgər qılsa, yeridir kim,
Sənayi-xani-xeyrəncamdır səbzə zəbanində.


1 Oldunsa
2 Altından çaylar.
3 Cənnətlər bunlardır.

337


Qədəh tutmaqdan ikrah etməzəm, ta kim eşitdim mən,
Səhər bülbül dilində, gül qatında səbzə yanində:

Açıldı qönçə tumarı və mə’lum oldu məzmuni,
Budur kim: fövt qılman mövsimi-gül, cami-gülguni.

**5**

Gətir, saqi, qədəh kim, bağü səhra laləzar oldu,
Əcəb fəsli-xücəstə, mövsimi-xoşruzigar oldu.

Şükufə bərgi topraq üzrə simin xiştlərdir kim,
Əsasi-eyşi-xəlq ol xiştlərdən üstüvar oldu.

Cigər qani kimi getmişdi gözdən tazə gül şəkli,
Yenə daği-dili-əhli-vəfa tək aşikar oldu.

Çıxardı səbzəvü gül xakdən çox lə’lü firuzə,
Vəli, yüz şükr kim, xan xaki-payinə nisar oldu.

Füzuli, gər xəzan vaxtı irərdin müttəqi, hala
Mey iç kim, mövsimi-gül gəldi, əyyami-bəhar oldu.

Açıldı qönçə tumarı və mə’lum oldu məzmuni,
Budur kim: fövt qılman mövsimi-gül, cami-gülguni.


338


**1**

Dün sayə saldı başimə bir sərvi-sərbülənd
Kim, qəddi dilrüba idi, rəftarı dilpəsənd.
Göftarə gəldi nagəh açıb lə’li-nuşxənd,
Bir püstə gördüm bu dürci-dəhəndir – dedim, dedi:

- Yox, yox, dəvayi-dərdi-nihanındürür sənin!

**2**

Əymiş hilali üstünə tərfi-külahini,
Çox dilşikəstənin gögə yetirmiş ahini,
Zülfün dağtdı, gizlədi əbr içrə mahini,
Gördüm üzündə həlqeyi-zülfi-siyahini,

- Ol piçü tabı çox nə rəsəndir? – dedim, dedi:

- Dövri-rüxümdə rişteyi-canındürür sənin!

**3**

Vermiş füruğ şəm’i-rüxi gün çirağinə,
Salmış şikəst sərv qədi gül budağinə.
Dün sərv tək basanda qədəm göz bulağinə,
Bir neçə xardən ələm irmiş əyağinə,

- Gül bərginə batan nə digəndir? – dedim, dedi:

- Müjgani-çeşmi-əşkfəşanındürür sənin!

**4**

Ceyr ilə saldı bağə güzər ol səmən’üzar,
Ənvai-zibü zinət ilə fəsli-növbəhar,
Açmış gül üzrə sünbülü giysuyi-mişkbar,
Yaxmış lətif ayağına gülbərg tək nigar,

- Nəsrinə rəngi-lalə nədəndir? – dedim, dedi.

- Qəmzəm xədəngi tökdüyü qanındürür sənin!

**5**

Düşmüş üzarı üzrə müənbər səlasili,
Aşüftəhal edib neçə bisəbrü bidili,


339


Əqlimi valeh eylədi, şəklü şəmaili,
Göz gördü qamətin, dilü can oldu maili,

- Vəh, bu nə türfə sərvi-çəməndir? – dedim, dedi:
–Mənzuri-dideyi-nigəranındürür sənin!

**6**

Seyli-sirişkim oldu rəvan xaki-kuyinə,
Can valeh oldu lə’li-ləbü göftguyinə,
Dil düşdü dami-silsileyi-mişkbuyinə,
Ol ləhzə kim, sataşdı gözüm zülfü ruyinə,

- Əqrəb məhi-münirə vətəndir? – dedim, dedi:

- Ey çox xətalı, kəndi qiranındürür sənin!

**7**

Dün sübhdəm ki, laləvü nəsrin salıb niqab,
Gül çöhrəsindən atdı səba pərdeyi-hicab,
Gülzarə çıxdı seyr ilə ol rəşki-afitab,
Şəbnəm nisarın etdi yüküş lö’löi-xoşab,

- Bunlar nədir, nə dürri-Ədəndir? – dedim, dedi:

- Əbsəm, Füzuli, əşki-rəvanındürür sənin!


340


Vay, yüz min vay kim, dildardən ayrılmışam,
Fitnə çeşmi sahirü xunxardən ayrılmışam,
Bülbüli-şuridəyəm, gülzardən ayrılmışam,
Kimsə bilməz kim, nə nisbət yardən ayrılmışam,
Bir qədi şümşadü gülrüxsardən ayrılmışam.

Qəddi tuba, lə’li firdövsün şərabi-kövsəri,
Xülqü xuyidir mələk, surətdə əmsali-pəri,
Bürci-əflakin səadətli, şərəfli əxtəri,
Hüsn ara məcmu’i-xubların sərasər sərvəri,
Bir qədi şümşadü gülrüxsardən ayrılmışam.

Dustlar, mən naləvü fəryad qılsam, eyb iməs,
Çərxi-bədmehrin əlindən dad qılsam, eyb iməs,
Qəm diyarın dil ara abad qılsam, eyb iməs,
Bu bina birlə cahanda ad qılsam, eyb iməs,
Bir qədi şümşadü gülrüxsardən ayrılmışam.

Düşmüşəm qəmxaneyi-hicranə zarü dərdnak,
Naxüni-həsrət bilən edib giribanimi çak,
Gündə yüz gəz hicr tiğilən oluram mən həlak,
Gərdişi-dəvvar cövründən məni-dilxəstənak,
Bir qədi şümşadü gülrüxsardən ayrılmışam.

İştiyaqü şövqdən canü tənim aludədir,
Şami-qəm fərzaneyi-bəxtim mənim uyxudədir,
Ağılamaqdan çeşmü cisi-dərdnakim sudədir,
Sanma, ey həmdəm ki, fəryadım mənim bihudədir,
Bir qədi şümşadü gülrüxsardən ayrılmışam.

Vəsl umub cövrü cəfasini çəkərkən can hənuz,
Mehr umub şövqində yanarkən dili-suzan hənuz,
Cismi-qəmnakimdə var ikən qəmi-hicran hənuz,
Yetmədən payanə ahü naləvü əfğan hənuz.
Bir qədi şümşadü gülrüxsardən ayrılmışam.

Mülki-vəsli dilbərin, könlümdə mə’mur olmadan,
Eşq camindən dilü can məstü məxmur olmadan,
Dərdi-bidərmani-hicrindən tənim dur olmadan,
Həm Füzuli eşqü aşiqliği məşhur olmadan,
Bir qədi şümşadü gülrüxsardən ayrılmışam.


341


Ey hərir içrə tənin, mütləq bülur içrə gülab,
Köksün abi-rövşən, ol ab üzrə dügməndir hübab.
Böyləsən məhbub, yox nəzzarənə aləmdə tab,
Vay əgər tezcik çıxıb, sərpib ləçək, salsan niqab,
Hiç şək yox kim, səni görcək olur aləm xərab.

Dil çəkib zərrin o tağın, verdi lə’lindən soraq,
Tutdu ol göftar içün lə’li-binaguşin qulaq,
Zülfünə həmdəm daraq, aşüftə mən ondan iraq,
Diş salıb hər piçü tab açdıqca zülfündən daraq,
Rişteyi-canımğa rəşkimdən düşür yüz piçü tab.

Ey üzü gül, köynəgi gülgunü donu qırmızı!
Atəşin kisvət geyib, odlara yandırdın bizi.
Adəm oğılundan sənin tək doğmaz, ey zalım qızı.
Ayü gündür hüsn bəhsində cəmalin acizi,
Guiya atan məhi-tabandır, anan afitab.

Al saç bağında mişkin saç pərişanhaliyəm,
Sim-saq üzrə qızıl xəlxallər pamaliyəm,
Sanma xəlxalın kimi mehrindən, ey məh, xaliyəm,
Arizin dövründə zərrin silsilən timsaliyəm,
Qəmzən oxundan həzin canımda yüz min iztirab.

Sürmədən gözlər qara, əllər hənadən lalərəng,
Hiç şahid yox bu rəng ilə ki, sənsən şuxü şəng,
Vəsməli qaşın yaşıl tozlu kəman, qəmzən xədəng,
Qəmzəvü qaşinə meyl eylər Füzuli bidirəng,
Quş əcəbdir qılmamaq tirü kəmandan ictinab.


342


Tən pozuldu əşki-çeşmi-xunfəşanimdən mənim,
Göydü can könlümdəki suzi-nihanimdən mənim.
Ta əsər var cismü cani-natəvanimdən mənim,
Qəm kəm etməz gözü könlüm cismü canimdən mənim,
Bu başımdan savulub, ol getsə yanimdən mənim.

Meyli-vəsl əgmiş qədimni çəngi-bəzmi-yar tək,
Rəglərim sızlar əl ursam çəng üzrə tar tək,
Çəngü ney mümkün kəm edə zarlıq mən zar tək,
Bəs ki, məmluyəm həvayi-eşqə musiqar tək,
Min fəğan hər dəm çıxar hər üstüxanimdən mənim.

Aləmi tutdu sirişkim qanı, tutmazsan xəbər!
Saldı yaşım rəxnələr yollarə, qılmazsan nəzər!
Qan yaşımdan sarı kim, tutmuş yolun, qıl bir güzər!
Meyl qıl məndən yana, hər dəm bu istiğına yetər!
Qanlı isəm dəxi gəl keç şimdi qanimdən mənim.

Güz evi tək oldu əşkimdən çox evlər qərqi-ab,
Göz evi tək qıldı çox ev mərdümi-çeşmim xərab,
Aləmi seylabə verdim, ey cəmali afitab!
Görünür mərdüm gözünə seyldən qopmuş hübab,
Suyə hər ev kim gedər əşki-rəvanimdən mənim.

Ey xəyalın xəlvəti nəqdi-rəvanim məxzəni,
Göz yaşı olur rəvan hərgəh xəyal etsəm səni,
Lütf umub səndən, səri-kuyində etdim məskəni,
Gəl gözüm nuri, Füzuli tək çox ağılatma məni,
Inciməzmi xatirin ahü fəğanimdən mənim.


343


_Həbibiyə təxmis_

Ta cünun rəxtin geyib, tutdum fəna mülkün vətən,
Əhli-təcridəm, qəbul etmən qəbavü pirəhən,
Hər qəbavü pirəhən geysəm misali-qönçə mən.
“Gər səninçün qılmasam çak, ey büti-nazikbədən!
Gorum olsun bu qəba əynimdə pirahən kəfən”.

Gərçi sevdayi-səri-zülfindənəm zarü zəlil,
Keçmən ol sevdadən olduqca mənə ömri-təvil,
Sanma tərk edəm bu sevdayi, gər olsam həm qətil,
“Çıxmaya sevdayi-zülfün başdan, ey məh, gər yüz il
Üstüxani-kəlləm içrə tutsa əqrəblər vətən”.

Qalib oldu sübhdəm şövqi-güli-ruyin mana,
Seyri-bağ etdim ki, buyi-gül verə təskin mana,
Gül görüb, yadınla dürri-əşk saçdım hər yana,
“Düşdü şəbnəm, bağə gir, ta gül nisar etsin sana,
Səbzənin hər bərginə bir dür ki, tapşırmış çəmən”.

Der idim, ey dil, gətirmə hiç dərd əhlinə şək,
Ta səni həm salmasın bir dərdə dövrani-fələk,
Almadın pənd imdi, aşiqsən, işin ah eyləmək,
“Ey könül, eşq əhlinə hər şəb gülərdin şəm’ tək,
Mən deməzmidim ki, danla ağılayasıdır gülən”.

Xah sincab eyləsin fərşin, Füzuli, xah kül,
Hicr ilə mütləq yuxu görməz göz, əglənməz könül.
Yarsız eşq əhlinin dinlənməgi mümkün degül,
“Necə dinlənsin Həbibi sənsiz, ey əndami gül
Kim, batır cisminə təndə hər tük olmuş bir tikən”.


344


_Lütfiyə təxmis_

Candadır sübhi-əzəldən mehri-rüxsarın sənin,
Nola ta şami-əbəd olsam tələbkarın sənin,
Imdi cana bulmamış min aşiqi-zarın sənin.
“Ey əzəldən ta əbəd könlüm giriftarın sənin,
Çarə qıl kim, buldu canım əsrü qəmxarım sənin!”

Tutdular təşxisi-dərd içün müaliclər rəgim,
Tapdı bu sihhət ki, sihhətdən yəqindir ölməgim,
Çün yəqin oldu dəvasız dərdilən can verməgim,
“Can verir çağında, Tanrıçün, qaşımğa gəl bəgim,
Bari görmüş bulğa min bir ləhzə didarın sənin.”

Xublarını imtəhan qılmaqda çox çəkdim cəfa,
Naleyi-zarilə bildim dərdi-dil bulmaz şəfa.
Mən sınadım, şimdi sən pəndim eşit, qıl iktifa,
“Çünki xublar məzhəbində yox imiş rəsmi-vəfa,
Ey könül, nə yerə yetkay naleyi-zarın sənin?”

Könlüm aldı ol iki əyyari-çeşmi-pürxumar,
Şimdi can qəsdin həm etmişlər nə məkrilən ki, var,
Ürf içində olsa hər əyyar qövli üstüvar,
“Şər’ilən gər tutsalar əsrük sözinə e’tibar,
Qanıma vergay danuqluq iki əyyarın sənin.”

Sanma cövr etsən Füzuli incinib tərkin qılə,
Gər cəfa qıl, gər vəfa canim fəda sən qatilə,
Mən xud öldüm, imdi sən tiği-cəfa alıb ələ,
“Lütfini öldürsən, ey dilbər, cəfa tiği bilə,
Anda həm bolğay mənim ruhim mədədkarın sənin.”


345


Necə bir vəsvəseyi-əql ilə qəmnak olalım,
Gəlin alayişi-qəmdən çıxalım, pak olalım,
Nəş’eyi-mey tapalım, qabili-idrak olalım.
Məstü mədhuşü xərabatiyü bibak olalım.

Rindlər bəzminə sərməst səbu tək giribən,
Zövq bağinə girib, cam gülüni dəribən,
Meyə derlərsə bəha əql mətain, veribən,
Məstü mədhuşü xərabatiyü bibak olalım.

Paybəsti-meyi-safi olalım dürd misal,
Verəlim saqiyə can, eyləyəlim kəsbi-həlal
Nəş’ədən bilməyəlim aləmi-keyfiyyəti-hal,
Məstü mədhuşü xərabatiyü bibak olalım.

Mey hübabı kimi meyxanədir bir ev tutuban,
Iqdi-əngur kimi bir araya baş çatuban,
Alsalar, din ilə dünyayi şərabə satuban,
Məstü mədhuşü xərabatiyü bibak olalım.

Badədən qeyr ki, qəm dəf’inə bir cam yetər,
Nəqdini nisyəyə hər kim verəcək olsa itər,
Ey Füzuli, rəvişi-əhli-riyadən nə bitər?
Məstü mədhuşü xərabatiyü bibak olalım.


346


Pərişan halin oldum, sormadın hali-pərişanım,
Qəmindən dərdə düşdüm, qılmadın tədbiri-dərmanım,
Nə dersən, ruzigarım böyləmi keçsin, gözəl xanım!
Gözüm, canım, əfəndim, sevdigim, dövlətli sultanım!

Əsiri-dami-eşqin olalı, səndən vəfa görmən,
Səni hər qanda görsəm, əhli-dərdə aşina görmən,
Vəfavü aşinalıq rəsmini səndən rəva görmən,
Gözüm, canım, əfəndim, sevdigim, dövlətli sultanım!

Dəgər hər dəm vəfasız çərx yayından mənə bir ox,
Kimə şərh eyləyim kim, möhnətü ənduhü dərdim çox,
Sənə qaldı mürüvvət, səndən özgə hiç kimsəm yox,
Gözüm, canım, əfəndim, sevdigim, dövlətli sultanım!

Gözümdən dəmbədəm bağrım əzib yaşım kimi getmə!
Səni tərk etməzəm çün mən, məni sən dəxi tərk etmə!
Ikən həm zalım olma, mən kimi məzlumi incitmə!
Gözüm, canım, əfəndim, sevdigim, dövlətli sultanım!

Qatı könlün nədən bu zülmilə bidadə raqibdir,
Gözəllər nisbəti olmaz cəfa, səndən nə vacibdir?
Sənin tək nazəninə, nazənin işlər münasibdir,
Gözüm, canım, əfəndim, sevdigim, dövlətli sultanım!

Nəzər qılmazsan əhli-dərd gözdən axıdan seylə,
Yamanlıqdır işin üşşaq ilə yaxşımıdır böylə?
Gəl, Allahı sevirsən, aşiqə cövr etmə, lütf eylə,
Gözüm, canım, əfəndim, sevdigim, dövlətli sultanım!

Füzuli şiveyi-ehsanın istər, bir gədayindir,
Dirildikcə sənin kuyin yolunda xaki-payindir,
Gərək öldür, gərək qoy, hökm – hökmün, rə’y – rə’yindir,
Gözüm, canım, əfəndim, sevdigim, dövlətli sultanım!


347


Hasilim bərqi-həvadisdən məlamət dağıdır,
Məsnədim kuyi-məlamətdə fəna toprağıdır,
Zar könlüm təndə zindani-bəla dutsağıdır,
Rəhm qıl, dövlətli sultanım, mürüvvət çağıdır!

Dövr cövrindən tənü canimdə rahət qalmadı,
Surəti-halimdə asari-fərağət qalmadı,
Möhnətü qəm çəkməyə minbə’d taqət qalmadı,
Rəhm qıl, dövlətli sultanım, mürüvvət çağıdır!

Könlümün mülkün cəfa seylabi viran eylədi,
Bəxtimin halin hücumi-qəm pərişan eylədi,
Bağrımı əndişeyi-dövri-fələk qan eylədi,
Rəhm qıl, dövlətli sultanım, mürüvvət çağıdır!

İntihasız cövrlər odlarə yandırdı məni,
Acı sözlər dadlı canımdan usandırdı məni,
Xəlqdən bihudə fəryadım utandırdı məni,
Rəhm qıl, dövlətli sultanım, mürüvvət çağıdır!

İstəyib bir çarə, çox yeldim, yügürdüm hər yana,
Rəhm edib, bir kimsə imdad etmədi mütləq mana,
Çarəsiz qaldım, mürüvvət istəyib gəldim sana,
Rəhm qıl, dövlətli sultanım, mürüvvət çağıdır!

Dadə gəldim ədl divaninə, fəryadım eşit!
Sən ki, adilsən, gör əfğanım nədəndir, qurə yet!
Şərhi-halim sor, muradım ver, əlim tut, fikrim et!
Rəhm qıl, dövlətli sultanım, mürüvvət çağıdır!

Gör Füzulinin rüxi-zərdində əşki-alini,
Pərdeyi-idbar tutmuş surəti-iqbalini,
Dərdməndindir, inayətlər edib sor halini,
Rəhm qıl, dövlətli sultanım, mürüvvət çağıdır!


348


349


350


**1**

Həmdi-bihəd dəmbədəm ol mübdii-əşyayə kim,
Xilqəti-imkan vücubi-zatini icab edər.

Gəh səvadi-girdbadi-qəhri xaki-tirəyi
Tutiyayi-dideyi-xurşidi-aləmtab edər.

Gəh nüzuli-qətreyi-barani-əbri-rəhməti
Yer yüzündə səbzeyi-pəjmürdeyi sirab edər.

Meydə müzmər eyləyib keyfiyyəti-təğyiri-hal,
Simbərlər zülfünü can qeydinə qüllab edər.

Canə həm, əlbəttə, ondandır bu iste’dad kim,
Rəğıbəti-məhbubü pərvayi-şərabi-nab edər.

Ola kim, məqbul edə üzri-günahim, çün bilir,
Kim, əməl təklifini cəm’iyyəti-əsbab edər.

**2**

Çox təfaxür qılma cəm’i-mal ilə, ey xacə kim,
Simü zər cəm’iyyəti əhli-qürur eylər səni.

Barigahi-qürbdən cəm’iyyəti-malü mənal,
Hər nə miqdar olsa, ol miqdar dur eylər səni.

Gərçi ne’mət çox, kifayətdən təcavüz qılma kim,
Imtila bari-bədəndir, bihüzur eylər səni.

**3**

Əhli-kəmalə cahil əgər qədr qılmasa,
Mə’zurdur, məlamətin etmək rəva degil.
Cahil təbiətində məzaqi-kəmal yox,
Hər nəfsə iqtidai-təbiət xəta degil.
Ülfət həmişə fər’i olur aşinalığın,
Cahil fəzilət əhli ilə aşina degil.


351


**4**

Ey səfayi-surətin qeydin çəkən, bil kim, hənuz
Jəngdən ayineyi-idrakını pak etmədin.
Jəngdir ayineyi-idrakə hər surət ki var,
Sən hənuz, ey sadə, bu məzmuni idrak etmədin.

**5**

Ey vücudi-kamilin ayinədari-feyzi-həq,
Asitanın qibleyi-hacati-ərbabi-yəqin.

Ey kəmali-rəf’ətin sərmayeyi-əmnü əman!
Vey cəmali-şövkətin pirayeyi-dünyavü din!

Hüsni-rə’yin afitabi-aləmi-sidqü səfa,
Xaki-payin mənşəi-cəm’iyyəti-ruyi-zəmin.

Gəlməmiş bir sən kimi pakizətinət aləmə,
Ta binayi-aləm etmiş nəqşbəndi-maü tin.

Məsnədi-Nurşirəvandır büq’əyi-Darüssəlam,
Snsən istehqaq ilə Nurşirəvanə canişin.

Cismdir mə’nidə bürci-övliya, sən ruhi-pak,
Bir nigindir xitteyi-Bəğıdad, sən nəqşi-nigin.

Sərvəra, yüz şükr kim, feyzi-kəmali-rəf’ətin,
Övliya bürcini etmiş rəşki-firdövsi-bərin.

Xasü am olmuş nəvali-ne’mətindən bəhrəmənd,
Afərin, ey şəhriyari-mülkpərvər, afərin!

Mən ki, bir kəmtər dauguyəm, nəzər saldın mənə,
Qoymadın xaki-məzəllətdə qalım zarü həzin.

Zaye’ ikən qədrimi bildirdin əhli-aləmə,
Tirə ikən eylədin xaki-vücudim ənbərin.


352


Əbri-lütfün qıldı xari-xüşkimi gülbərgi-tər,
Feyzi-cudun qıldı səngi-xarəmi dürri-səmin.

Ne’mətin şükri mana fərz etdi izhari-səna,
Şəfqətin tövqi məni qıldı qulami-kəmtərin.

Qəm degil əhli-qərəz eylərsə məndən mən’i-xeyr,
Qəm degil əhli-həsəd bağılarsa mən miskinə kin.

Ruzigarilə mənim məqsudimi hasil qılıb,
Ol ki, mən’ eylər, olur bədxahi-rəbbül-aləmin.

Hiç şək yox kim, yetər məqsudə, olmaz naümid,
Xirməni-əltafın ətrafında olan xuşəçin.

Var ümidim mehrü mah etdikcə dövran, olasan
Kamyabü kamranü kambəxşü kambin.

**6**

Pərdə çək eybinə zülmət kimi, xəlqin daim,
Gər dilərsən ki, nəsib ola sənə abi-həyat.

Qılma xurşid kimi, eybnümalıq ki, fələk
Yerə salmayə səni bə’d ülüvvüd-dərəcat.

Cəhd qıl zatın ola məzhəri-asari-qəbul,
Qılma ol cahə təfaxür ki, ola xarici-zat.

Fəzl olur, sanma, sənə mənziləti-əslü nəsəb,
Cah olur, sanma, sənə kəsrəti-əsbabü cihat.

Ariyətdən özünə qılma qəmər tək zinət,
Qeyridən ariyətin nur isə, həm yazıya at.

**7**

Ey müəllim, aləti-təzvirdir əşrarə elm,
Qılma əhli-məkrə tə’limi-məarif zinhar!


353


Hiylə içün elm tə’limin qılan müfsidlərə,
Qətli-am içün verər cəlladə tiği-abdar.
Hər nə təzvir etsə əhli-cəhl ona olmaz səbat,
Məkri-əhli-elmdir, əsli-fəsadi-ruzigar.

**8**

Bəxil qılmasa cəm’ etdiyi dirəm sərfin,
Nihali-məqsədi sərsəbz olub səmər verməz.
Əlindəki gühəri bəzl qılmasa mümsik,
Şəbi-qəminə əməl müjdeyi-səhər verməz.
Tükənməyincə kəvakib, günəş tülu’ etməz,
Tökülməyincə şükufə, nihal bər verməz.

**9**

Ey ki, əndişeyi-mal ilə sərasimə olub,
Dünü gün dəhrdə aşüftə keçər əhvalın
Cəm’i-mal eylədigin rahət üçündür, əmma
Rahətin əksik olur, hər necə artar malın.
Mal çox etmə, həzər eylə əzabından kim,
Rənci artar, ağr olduqca yükü həmmalın.

**10**

Mən sübhü şam dudi-dili-suznak ilə,
Bağrın kəbab edib, verərəm çərxə inqilab.
Hutü Həməl mədari ilə asiman dəxi,
Qan uddurub, verər dili-suzanimə əzab.
Dünyadə yox fərağətə ümmid, nişəkim,
Qan uddurur oda netəkim, cizginir kəbab.

**11**

Elm kəsbilə rütbeyi-rif’ət
Arizuyi-məhal imiş ancaq.
Eşq imiş hər nə var aləmdə,
Elm bir qiylü qal imiş ancaq.


354


**12**

Olsa məqsudunca dövrani-fələk bir neçə gün,
Olma məğrur, ey ki, hali-dəhr rövşəndir sənə.
Qatili-abavü əcdadın məaf etməz səni,
Umma ondan dustluq rəsmin ki, düşməndir sənə.

**13**

Gəlin, ey əhli-həqiqət, çıxalım aləmdən,
Qeyr yerlər gəzəlim, özgə səfalər görəlim.
Seyri-gərmiyyəti-qovğayi-qiyamət qılalım,
Vəz’i-cəm’iyyəti-həngameyi-məhşər görəlim.
Rəvişi-silsileyi-dəhr məlul etdi bizi,
Necə bir dəhrdə ovzai-mükərrər görəlim.

**14**

Sevərəm ol nigari-simbəri
Ki, cəfapişəvü sitəmgərdir.
Necə kim, ona eşqbazlığm
Mə’siyyət olduğu müqərrərdir.
Cövr ilə ol müdam mən’im edib,
Rəhi-zöhdü səlahə rəhbərdir.
Qalibi-əcr olursa cövrü, nola,
Əmri-mə’rufü nəhyi-münkərdir.

**15**

Necə bir nəfs təmənnası ilə,
Yeməkü içmək ola dilxahın.
Eyləyib zöhdü vərə’dən nifrət,
Taəti-həqdən ola ikrahın.
Mə’bədin mətbəx ola şamü səhər,
Müstərah ola ziyarətgahın.
Bunun üçünmü olubsan məxluq?
Bumudur əmri sənə Allahın?

**16**

Həmişə dustum oldur, derəm ki, mal verib,
Qılır təbiətimi bəsteyi-əlaqeyi-mal.


355


İbadəti-həqü kəsbi-ülum içün mütləq,
Qomaz mülahizeyi-zəbti-mal, məndə məcal,
Müdam düşmən ona söylərəm ki, malım alıb,
Mənə müyəssər edər ne’məti-fərağəti-hal,
Hüzuri-qəlb verər rövnəqi-ibadəti-həq,
Fəraği-xatir olur mucibi-hüsuli-kəmal.
Fəğan ki, dustumu düşmənimdən etmən fərq,
Kəmali-cəhl ilə ovqat sərf olur məhü sal.
Bu cəhl ilə özümü əhli-mə’rifət sanıram,
Zəhi təsəvvüri-batil, zəhi xəyali-məhal!

**17**

Ey qaziyi-xocəstəliqa kim, həq eyləmiş,
Sahibsəriri-məsnədi-hökmi-qəza səni!
Cəhd eylə kim, mülahizeyi-nəf’i-dünyəvi,
Hökmi-qəzadə etməyə əhli-xəta səni.
Məqbuli-xəlq qılmış ikən elmü mə’rifət,
Mərdudi-xaliq eyləməyə irtişa səni.

**18**

Zülm ilə ağçalar alıb, zalim
Eylər ən’am xəlqə minnət ilə.
Bilməz onu kim, etdigi zülmə
Görəcəkdir cəza məzəllət ilə.
Müddəası bu kim, rizayi-ilah
Ona hasil ola bu adət ilə.
Cənnəti almaq olmaz ağça ilə,
Girmək olmaz behiştə rüşvət ilə.

**19**

Min ikən qədrü qiymətin bir olur,
Müztərib olsa qəlbin, ey arif!
Eylə təskini-qəlb hasil kim,
Əlfi təhriki-qəlb eylər əlif [1] .


1 “Əlf” ərəbcə min deməkdir, “əlif” isə əbcəd hesabında birdir (1).


356


**20**

Oldur ğəzəl ki, feyzi onun am olub müdam,
Arayişi-məcalisi-əhli-qəbul ola.
Virdi-zəbani-əhli-səfavü sürur olub,
Məzmunu zövqbəxş, səriül-hüsul ola.
Ondan nə sud kim, ola mübhəm ibarəti,
Hər yerdə istimain edənlər məlul ola.

**21**

Sərfi-nəqdi-ömr edib mən kəsbi-irfan etmişəm,
Əhli-dünya həm kəmali-cəhl ilə təhsili-mal.
Dəhr bir bazardır, hər kim mətain ərz edər:
Əhli-dünya – simü zər, əhli-hünər – fəzlü kəmal.
Kim ki, məndən nəf’ bulmaz, istəmən nəf’in onun,
Ol ki, yox nəf’im ona, nəf’in mənə olmaz həlal.
İstəmən nadan mənə gər versə gənci-simü zər
Kim, əvəzsiz malə nadandan təsərrüfdür vəbal.

**22**

Eyləyib nadanə ərzi-fəzlü izhari-hünər,
Şərmsar etmək, əta ummaq, nədir zülmi-sərih!
Sən bilirsən, mücmələn, ondan nə alırsan, vəli
Bilməz ol kim, aldığ səndən həsəndir, ya qəbih.
Zahirən satmaq hünər, almaq əta bir bey’dir,
Tifldir nadan, buyurmaz şər’ onun bey’in səhih.

**23**

Hər kimin var isə zatında şərarət küfrü,
Istilahati-ülum ilə müsəlman olmaz.
Gər qara daşı qızıl qan ilə rəngin edəsən,
Təb’ə təğyir verib, lə’li-Bədəxşan olmaz.
Eyləsən tutiyə tə’lim ədayi-kəlimat,
Nitqi insan olur, əmma özü insan olmaz.
Hər uzun boylu, şücaət edə bilməz də’va,
Hər ağac kim boy ata, sərvi-xuraman olmaz.


357


1 Zəiflik
2 Ki eylədim



**24**

Ey xəta ləfzilə Qur’anın şükuhin sındıran,
Mö’cüzi-ayati-Qur’andan həzər qılmazmısan?
Hər əlif bir xəncəri-xunrizi-bürrandır sənə,
Xəncəri-xunrizi-bürrandan həzər qılmazmısan?
Bir həkimi-kamilin darüş-şəfayi-hikmətin
Etmək istərsən xərab, ondan həzər qılmazmısan?

**25**

Sən nə afətsən mənə, ey əqli-bədfərcam, kim,
Bulmaq olmaz surəti-qürbündə asari-nişat.
Tifllər, divanələr səndən mübərra olmağın,
Dünyəvü üqbadə bulmuşlar kəmali-inbisat.
İzzətü zillətdə bilməzlər təriqi-imtiyaz,
Hillətü [1] hirmanda çəkməzlər əzabi-ehtiyat.
Ol ki, daim həmnişinindir, müəzzəbdir müdam,
Netə kim təklifə hökmi-şər’ ilə sənsən mənat.
Ol zamandan kim, sənə verdim inani-ixtiyar,
Ol zamandan keylədim [2] möhkəm səninlə irtibat,
Olmayıb xali qəmü ənduhdən qəbrim evi,
Xar bəstərdir mənə peyvəstə, xakistər – büsat.
Olmayaydım, kaş ki, hərgiz səninlə həmnişin,
Qılmayaydım kaş ki, mütləq səninlə ixtilat.

**26**

Ey xacə, gər qulundan oğulluq murad isə,
Şəfqət gözilə bax ona daim oğul kimi.
Vər oğılunu dilərsən ola sahibi-ədəb,
Əlbəttə, eylə zillətə mö’tad qul kimi.

**27**

Ey vəziri-mülkpərvər kim, nizami-mülk üçün,
Intixab etmiş cəmii-xəlqdən sultan səni.


358


Həllü əqdin aləmin qılmış müfəvvəz rə’yinə,
Naibi-hökmi-xilafət eyləyib dövran səni.
Qıl həzər kim, olmaya nagəh mizacın münqəlib,
Qılmaya sərməst, cami-şövkəti-divan səni.
Olasan insaf üçün mənsub ikən, əhli-fəsad,
Edə din əhlinə afət, qilləti-iman səni.
Etməyə mə’mureyi-islami viran, kəndüyə,
Ə’zəmi-ə’vanü ənsar eyləyə şeytan səni.
Etmiş ikən əfzəli-xəlqi-cəhan iqbal ilə,
Ərzəli-əhli-cəhənnəm eyləyə sübhan səni.

**28**

Ey ki, aləmdə məhəbbət adini məzmun edib,
Hər zaman bir mahrüxsarın olursan maili.
Keçdi ömrün, şahidi-məqsəd cəmalın görmədin,
Şahidi-məqsəd sağınmış, sən aradə haili,
Arif isən, tuta gör sərrişteyi-feyzi-bəqa,
Tərk qıl, bu surəti-faniyyü nəqşi-zaili.

**29**

Dəhr bir seylabdır, mülhəq ədəm dəryasına,
Biz ki, sərgərdanız, ol seylabə düşmüş xarü xəs.
Cizginir xarü xəs ol seylab olduqca rəvan,
Yetmədən dəryayə, rahət mümkün olmaz bir nəfəs.

**30**

Kəfi-hirsilə daim daməni-dünyayi-dun tutsan,
Zəmanə şurbəxt eylər səni, peyvəstə dərya tək.
Müləvvəs olmayıb, təcrid ilə çıxsan bu aləmdən,
Səni zali-fələk xurşidə cüft eylər Məsiha tək.

**31**

Ey gözəl, zatın məarif birlə rəngin edə gör,
Xətti-mişkin, pərdeyi-rüxsari-gülgun olmadan.
Söhbəti-ərbabi-elmü mə’rifətdən kəsb qıl,


359


Hüsni-sirət, surəti-halın digərgun olmadan.
Cəhd qıl kim, görməyə xurşidi-rüxsarin zəval
Nur feyzindən hilali-qədrin əfzun olmadan.

**32**

Əlindən ahlər, ey əxtəri-bəxti-siyahim, kim,
Məni xəlq içrə aliqədr ikən, qayətdə xar etdin.
Qılıb xurşidi-hirman mətləi-ümmid gərdunun,
Vücudimdən misali-sayə, səlbi-e’tibar etdin.
Səvadi-didəmi mütləq bəyazi-eynə döndərdin,
Bəyazi-hüsni-halim xali-ruyi-ruzigar etdin.

**33**

Ey könül, mütləq ibadət qılmayıb, ömrün təmam
Eylədin sevdayi-zülfi-hər pərirüxsarə sərf,
Saç ağardı, gəl,yetər mir’ati-bəxtin tirə qıl,
Ömrdən bir dəm ki, qalmış, eylə istiğfarə sərf.

**34**

Xirədməndi ki, daim aləmi-elm içrə seyr eylər,
Əsalibi-fünuni-şe’rdən, əlbəttə, qafildir.
Məzaqi-şe’r həm bir özgə aləmdir, həqiqətdə
Iki aləm müsəxxər eyləmək qayətdə müşkildir.

**35**

Padişahi-mülk, dinarü dirəm rüşvət verib,
Fəthi-kişvər qılmağa eylər mühəyya ləşkəri.
Yüz fəsadü fitnə təhrikilə bir kişvər alır,
Ol dəxi asari-əmnü istiqamətdən bəri.
Göstərən saətdə dövrani-fələk bir inqilab,
Həm özü fani olur, həm ləşkəri, həm kişvəri.
Gör nə sultanəm məni-dərviş kim, feyzi-süxən
Eyləmiş iqbalimi asari-nüsrət məzhəri.


360


Hər sözüm bir pəhlivandır kim, bulub tə’yidi-həq,
Əzm qıldıqda tutar tədric ilə bəhrü bəri.
Qanda kim, əzm etsə, mərsumü məvacib istəməz,
Qansı mülkü tutsa dəgməz kimsəyə şurü şəri.
Payimal etməz onu asibi-dövri-ruzigar,
Eyləməz tə’sir ona dövrani-çərxi-çənbəri.
Qılmasın dünyadə ultanlar mənə təklifi-cud,
Bəs dürür başımda tövfiqi-qənaət əfsəri.
Hər cəhətdən fariğəm, aləmdə haşa kim, ola
Rizq üçün əhli-bəqa, əhli-fənanın çakəri.

**36**

Sədayi-ney həram olmaz, dedin, ey sufiyi-cahil,
Yelə verdin xilafi-şər’ilə namusun islamın.
Bu əndam ilə vəcdiyyatdan dəm urmaq istərsən,
Ilahi, ney kimi surax-surax olsun əndamın.

**37**

Müttəsil mə’rifət əhlini ayaqlarə salıb,
Fələki-süflə qılır möhnətü qəm pamali,
Ol ki, cahildir, edib cümlə muradın hasil,
E’tibar ilə qılır məsnədi-qədrin ali.
Bu səbəbdən bilirəm kim, bu cahan övrətdir,
Övrətin böylədir övladi ilə əf’ali.
Ulu övladi kəsər süddənü tə’dib verər,
Süd verib, lütf ilə bağılar beşiyə ətfali.

**38**

Yaxamı pəncəyi-təxvifi-rəhi-şər’ tutar,
Daməni-mə’rifəti-əhli-riyasət tutsam.
Jəngi-iflas tutar ayineyi-rahətimi,
Tərki-hükkam qılıb, künci-qənaət tutsam.
Hiç halətdə bulunmaz əsəri-rahəti-dil,
Oluram müztəribül-hal nə sən’ət tutsam.


361


**39**

Doğruluq ilə istə ülüvvi-məqam kim,
Gəldikcə halinə verə dövri-fələk rəvac.
Doğruluq ilə hərflərə sədrdir “əlif”,
“Ya” hərfini ayağə buraxmışdır e’vicac.
Doğrular ilə gəz ki, səni sərbülənd edə,
Əgrilər ilə eyləmə, əlbəttə, imtizac.
“Ya” ixtilatı ilə sərir oldu payimal,
Başda məqam tutdu “əlif” nüsrətilə tac.

**40**

Müddəi eylər mənə təqlid nəzmü nəsrdə,
Leyk namərbut əlfazü mükəddər zatı var.
Pəhlivanlar, badpalər səgridəndə hər yana,
Tifl həm cövlan edər, əmma ağacdan atı var.

**41**

Ol səbəbdən farsi ləfzilə çoxdur nəzm kim,
Nəzmi-nazik türk ləfzilə ikən düşvar olur.
Ləhceyi-türki qəbuli-nəzmi-tərkib etməyib,
Əksərən əlfazi namərbutü nahəmvar olur.
Məndə tovfiq olsa, bu düşvarı asan eylərəm,
Novbahar olğac tikəndən bərgi-gül izhar olur.

**42**

Sə’dü nəhs əhvalını qılsan münəccimdən sual,
Müqtədai-mə’rifət Bərcisü Keyvandır ona.
Eyləsən rəmmaldən təftişi-hali-nikü bəd,
Mürşidi-rahi-yəqin Əngisü Lehyandır ona.
Nöqteyi-əşkali-rəmlü seyri-əcrami-nücum,
Kimə rəhbər olsa, feyzi-əql böhtandır ona.
Bilmiş ol kim, hər nə sadir olsa ziştü xubü bəd,
Məzhəri bir elmdir kim, əql heyrandır ona.


362


363


364


**1**

Əlhəmdü limən ənarə qəlbi və həda,
Vəş-şükrü lima fihi minəş-şovqi bəda.
Ma əmdəhü vahibən sivahu əbəda,
La əşrikü fi sənai-rəbbi əhəda [1] .

**2**

Əlhəmdü limən əzzə kəmalən və əla,
Mən qamə bi-əmrihi və mən nazəə-la.
Sümməs-səlavatu vət-təhiyyatu əla
Mən fəzzələhul-lahu bi-izzin və üla [2] .

**3**

Ey feyzi-vücud, şahidi-cud sana,
Vey şahidi-cud, hər nə mövcud sana.
Ümmidi-qəbulü e’timadi-kərəmin,
Mərdudini etmiş yenə mərdud sana.

**4**

Ey zatına mümkinat bürhani-vücub,
Sabit sana imtinai-imkani-üyub.
Şayisteyi-ne’məti-həyati-əbədi,
Ərvahi-məarifinlə əbdanü qülub.

**5**

Ey üqdəgüşayi-əcəmü türkü ərəb,
Rəssami-rüsumi-fəzlü asarü ədəb!
Məzmuni-hədisin səbəqi-hər millət,
Də’vayi-qəbulun sənədi-hər məzhəb.


1 Tərcüməsi: Mənim qəlbimi işıqlandırana və doğru yol göstərənə həmd olsun.
Şükr olsun ona ki, onunla şövq başlanır.
Ondan başqa bir kimsəni mədh etmərəm.
Öz duamda Allahıma hek kəsi şərik etmirəm.
2 Tərcüməsi:Kəmalı ilə əziz olana həmd olsun,
Onun əmrinə tabe olanlar yüksəldi, xilafinə gedənlər yox.
Sonra sələvat və səlam olsun o adama ki,
Allah onu əzizlik və yüksəkliklə fəzilətləndiribdir.


365


**6**

Xoş ol ki, dəmi-əcəl çəkəm badeyi-nab,
Sərməst yatam qəbrdə ta ruzi-hesab.
Qovğayi-qiyamətdə duram məstü xərab,
Nə fikri-hesab ola, nə idraki-əzab.

**7**

Saqi, kərəm et, şərabi-gülfam yürüt!
Gülfam şərabə vermə aram, yürüt!
Bəzm içrə hübabi-əşki-gülgunumdan
Min cam yürütmə, cam üçün cam yürüt.

**8**

Canımda olan zəxireyi-nitqü həyat,
Cismimdə olan cövhəri-hissi-hərəkat.
Sərf olmadı xublar rəhi-eşqində,
Əfsus ki, bihudə keçirdim ovqat!

**9**

Tə’miri-bəqavü cəm’i-mal etdin, tut!
Hər arizu etdinsə, ona yetdin, tut!
Çün ömr bəqasına tutulmaz ümmid,
Hər hal ilə gəldigin kimi getdin, tut!

**10**

Derlər ki, qılır qönçə ləbi-yar ilə bəhs,
Gülbərgi-tər ol lə’li-gühərbar ilə bəhs.
Ol bir neçə dilsizlərə töhmətdir bu,
Də’vayə gərək ləhceyi-göftar ilə bəhs.


366


**11**

Ey mehri-rüxün qədimü aləm hadis!
Izhari-vücudə kəşfi-razin bais.
Keçdim səri-kuyində iki aləmdən,
Li beynə məqameyi məqamün salis [1] .

**12**

Xeyli-qəmin etdi nəqdi-səbrim tarac,
Səbr ilə müyəssər olmadı dərdə ilac.
Rüxsarıma tökdü mərdümi-çeşmim qan,
Hinduyi görün, lə’l verir Rumə xərac.

**13**

Ey faideyi-elminə aləm möhtac,
Xaki-qədəmin əhli-hünər başına tac.
Hər kimdə ki, gördü himmətin sui-mizac,
Ol sui-mizacə qıldı lütf ilə ilac.

**14**

Ey şərbəti-vəslin ələmi-hicrə ilac!
Bazari-qəmində eşq nəqdinə rəvac.
Gər tutsa xədəngin rəgi-canım nə əcəb,
Nəbz ilə qılır təbib təşxisi-mizac.

**15**

Ey zikri-ləbin nasixi-ənsafi-Məsih!
Nitqin “ənə əfsəh” [2], kəlimatın da fəsih.
İzhari-qəbulun əsəri-lütfi-xəfi,
İxfayi-rəhi-şəri’ətin zülmi-sərih.


1 Tərcüməsi: İki məqam arasında üçüncü məqam mənimdir.
2 Tərcüməsi: mən ən fəsahətliyəm.


367


**16**

Tutduqca ələ sağəri-səhbayi-səbuh,
Artar əsəri-zövqi-dilü rahəti-ruh.
Tuğyani-qəmə müfiddir zövrəqi-mey,
Tufan xətərində öylə kim, kəştiyi-Nuh.

**17**

Gül dövrü xoş ol kim, tuta gülfam qədəh,
Bəzmində dəmi tutmaya aram qədəh,
Hər sübh ki, xürşidsifət qaldıra baş,
Bəzmin bəzəyib, gəzdirə ta şam qədəh.

**18**

Mey şövqü olubdur mənə adət, ey şeyx!
Gəldikcə bu şövq olur ziyadət, ey şeyx!
Xoşdur mənə mey, sənə ibadət, ey şeyx!
Rə’y ilə degil eşqü iradət, ey şeyx!

**19**

Gər kuyinə əşkim güzər eylər küstax,
Vər qəddinə çeşmim nəzər eylər küstax.
Eyb eyləmə, rəngi-çöhreyi-zərdimi gör
Kim, çoxları aləmdə zər eylər küstax.

**20**

Bir abü həvadır əşki-gərmü dəmi-sərd
Kim, ondan alır nəşvü nəma gülbüni-dərd.
Gülzari-qəmin bənəfşəvü yasəməni,
Dudi-dili-aşüftədirü çöhreyi-zərd.


368


**21**

Ta dövrdədir daireyi-kövnü fəsad,
Mümkün degil olmaq hərəkatından şad.
Tasi-fələk içrə kə’bəteyni-əncüm,
Göstərməz imiş hiç kimə nəqşi-murad!

**22**

Ta məhmili-mehrdir bu zəngari-məhd,
Mehrinlə vəfa əhlinədir möhkəm əhd.
Birdir bizə bəzmgahi-eşqində fələk,
Gər qəhrilə zəhr versə, vər lütflə şəhd.

**23**

Hər yerdə ki, ol simbərü simin xəd,
Ərz eyləyə ariz, aça sünbül, çəkə qəd;
Rəngi-gülü buyi-sünbülü cilveyi-sərv,
Hökm eyləməzəm kim, ola məqbuli-xirəd.

**24**

Ta boynuma saldı ol xəmi-zülf kəmənd,
Tədbir ilə açılmadı boynumdan bənd.
Çox pənd verildi, olmadı faidəmənd,
Yetməzmi mənə pənd verən, xəlqə bu pənd.

**25**

Dəf’i-qəmi-ruzigarədir badə müfid,
Rəf’i-ələmi-eşqə rüxi-sadə müfid.
Tərki-meyü mə’şuqdur ol illət kim,
Olmaz ona hiç nəsnə dünyadə müfid.


369


**26**

Ey şəhdi-ləbin sözü şəkərvar ləziz!
Lə’lin kimi qanda bir şəkər var ləziz?
Tüngi-şəkər olmasaydı dürci-dəhənin,
Olmazdı çıxan ləhceyi-göftar ləziz.

**27**

Gər möhnəti-kəsrdir və gər ne’məti-səbr,
Səbr ilə qənaətdə gərək müslimü gəbr.
Hər ne’mətü möhnət ki, verərsən, yarəb!
Ver ne’mətə bir qənaətü möhnətə səbr!

**28**

Hərdəm mənə yar ərzi-rüxsar eylər,
Hüsnilə məni bətər giriftar eylər.
Guya ki, kəmali-eşq dərsin oxudur,
Hərdəm mənə tə’limini təkrar eylər.

**29**

Hicrin, cigərini hər kimin qan eylər,
Tədric ilə vəslin ona dərman eylər.
Zülfün kimi kim, müddət ilə kafir idi,
Lə’lin onu bir dəmdə müsəlman eylər.

**30**

Hər dil ki, əsiri-qəmi-hicran olmaz,
Şayisteyi-zövqi-vəsli-canan olmaz.
Hər dərd ki var, var dərmanı, vəli,
Bidərdlərin dərdinə dərman olmaz.


370


**31**

Biz aləmi-eşq aləmaraləriyüz,
Meyxaneyi-dərd dürdpeymaləriyüz.
Gülbərgi-nədamət çəmənidir aləm,
Biz bu çəmənin bülbüli-şeydaləriyüz.

**32**

Kimdir ki, qəmində naleyi-zar etməz!
Dərdin sənə nalə ilə izhar etməz!
Fəryadına hiç kimsənin yetməzsən,
Fəryad ki, fəryad sənə kar etməz!

**33**

Canan isə mətlub, təmə’ candan kəs!
Mətlub isə can, ümid canandan kəs!
Can sevmək ilə müyəssər olmaz canan,
Ya bundan ümid, ya təmə’ ondan kəs!

**34**

Suzi-dilim əşki-aldən eylə qiyas,
Ənduhimi zə’fi-haldən eylə qiyas.
Xurşid ki, hüsnünlə qılır bəhsi-kəmal,
Tərki-ədəbin zəvalədən eylə qiyas.

**35**

Ədvari-zaman daireyi-heyrət imiş,
Əsbabi-cəhan məhalikü möhnət imiş,
Dünyayə həvəs etməmək etməkdən yey,
Çün əvvəli hirsü axiri həsrət imiş.


371


**36**

Kuyində sənin nə daşə kim, vurdum baş,
Qıldım onu qərqi-xun, töküb gözdən yaş.
Göz yaşinə rəhm eylə ki, çox müddətdir,
Bidadinə səbr edib basar bağrına daş.

**37**

Ey kəsbi-kəmalə e’tiqadın naqis,
Təhsili-kəmalə ictihadın naqis!
Ar etmə tələbdə, qıl həzər ondan kim,
Kamillər içində ola adın naqis.

**38**

Xoş ol ki, qılıb rəhbəri-sidqin ixlas,
Xəlvətgəhi-qürbə ola ixlas ilə xas.
Sərrafi-vəfa buteyi-tə’dibə salıb,
Hər qəşdən edə missi-vücudini xilas.

**39**

Ey bad, qıl əhvalımı cananimə ərz!
Sərgəştəligim sərvi-xuramanimə ərz!
Öldürdü kinayətilə əğyar məni,
Bu zülmi-sərihi eylə sultanimə ərz!

**40**

Ey cövhəri-eşqin əsəri cismü ərəz,
Yox aşiqə səndən özgə aləmdə qərəz.
Çün bildin əsirinəm tərəhhüm qıl kim,
Tədbir gərək, müşəxxəs olduqda mərəz.


372


**41**

Zahid, meyi-nabdəndir ikrah qələt!
Sən xah sözüm səhih tut, xah qələt.
Məscidlərə girdigim degil rəğıbətdən.
Sərməstligimdən eylərəm rah qələt.

**42**

Dağ urma dili-həzinə, ey mişkinxət!
Gər maili-hüsnü xəttsən, qılma qələt
Kim, eyləməmiş katibi-divani-qəza,
Dil hərflərin qabili-təzyini-nüqət!

**43**

Mey nəfyini eyləyib şüar, ey vaiz!
Tutdun rəhi-tə’ni-eşqi-yar, ey vaiz!
Tərki-meyü məhbub edəriz cənnət üçün,
Şərh eylə ki, cənnətdə nə var, ey vaiz!

**44**

Təhdid ilə keçdi ruzigar, ey vaiz!
Fövt oldu şərabü vəsli-yar, ey vaiz!
Gər kövsərü hur isə qərəz, vermə əzab,
Nə tərk buyur, nə intizar, ey vaiz!

**45**

Ey vəsfi-cəmalinə təhəyyür mane’,
Vermiş sənə isbati-kəmalin sane’.
Vəslində cəfayi-tə’neyi-əğyarın,
Hicrində məni xəyalə etmiş qane’.


373


**46**

Pərvanəyə zülmi-bihesab eylər şəm’,
Zülm oduna bağrını kəbab eylər şəm’,
Guya ki, bilir zülm sərəncamı nədir,
Bihudə degil ki, iztirab eylər şəm.

**47**

Hər şam yetər vüsali-cananə çirağ,
Ta sübh qalır həmdəmü həmxanə çirağ.
Rəşk odinə yandırdı məni hər saət,
Vəhm eyləməz ahim oduna yanə çirağ.

**48**

Hər gəh ki, bahar qıldı arayişi-bağ,
Növmidlik urdu laləvəş bağrıma dağ,
Zira tikən üzrə tutdu bülbül məskən,
Gül bad güzərgəhində yandırdı çirağ.

**49**

Yox dəhrdə bir müvafiqi-təb’ hərif
Kim, söhbəti dilgüşa ola, təb’i zərif.
Fəryad ki, nacins müsahiblər ilə
Bifaidə zaye’ oldu ovqati-şərif.

**50**

Mən zöhdü vərə’dən urmazam lafi-xilaf,
Daim rüxi-sadə istərəm, badeyi-saf.
Tərki-meyü məhbub edə bilmən mütləq,
Gər etmək olur, derəm, zəhi bihudə laf.


374


**51**

Ey navəki-bidadinə hər sinə hədəf!
Vey cövhəri-peykaninə hər didə sədəf!
Fəryadü fəğanım qəmi-hicranından,
Bəzmi-qəmədir naleyi-ney, novheyi-dəf.

**52**

Ey saliki-rahi-həq, sənə qət’i-təriq,
Düşvardır olmasa rəfiqin tovfiq.
Tut daməni-mürşidi-təvəkkül ki, sənə
Məqsud müyəssər ola, tovfiq rəfiq.

**53**

Sərmənzili-hər muradə rəhbərdir eşq,
Keyfiyyəti-hər kəmalə məzhərdir eşq,
Gəncineyi-kainatə gövhərdir eşq,
Hər sadir olan nəş’əyə məsdərdir eşq.

**54**

Üşşaqə degil qeydi-əlaiq layiq,
Hərgiz qəmi-ruzigar çəkməz aşiq.
Qeydi-qəmi-ruzigar bir illətdir,
Ol illətə eşqdir təbibi-haziq.

**55**

Ya mən bəsət əl-ərzə və əcr əl-əflak,
Idraku kəmalihi kəmalül-idrak.
Fil-ərzi və fis-səmai la rəbbə sivak,
Ma nə’büdü ya vahidü, illah iyyak [1] .


1 Tərcüməsi: Ey yeri döşəyən və fələkləri hərəkətə gətirən,
Kamalının dərki idrakın kamilliyidir.
Yerdə və göydə səndən başqa Allah yoxdur.
Ey tək olan, səndən başqa kimsəyə ibadət etmirik.


375


**56**

Ya mən bikə iltica’u mən kanə sivak,
Tuba limən iqtəda bima fihi rizak.
Bürhanukə filkəmali yəkfi lovlak,
Lovlakə ləma darə mədarül-əflak [1] .

**57**

Məcnun oda yandı şö’leyi-ah ilə pak,
Vamiq suya batdı, eşqdən oldu həlak.
Fərhad həvəs ilə yelə verdi ömrün,
Xak oldular onlar, mənəm imdi ol xak.

**58**

Ta həlqeyi-zülfi-yarə düşdün, ey dil!
Dami-qəmi-ruzigarə düşdün, ey dil!
Əfsus ki, qütbi-əhli-cəm’iyyət ikən
Ol dairədən kənarə düşdün, ey dil!

**59**

Xurşid ki, qıldı sübhdəm ərzi-cəmal,
Dərgahinə üz sürmək ilə buldu kəmal.
Çün yetdi kəmalə, etdi sən mah ilə bəhs,
Ol tərki-ədəb verdi kəmalinə zəval.

**60**

Məh durdu müqabil sənə bulduqda kəmal,
Gördü ki, özündə səncə yox hüsnü cəmal.
Bir qayətə yetdi, incəlib qəmdən kim,
Zə’fi-bədənilə bədr ikən oldu hilal.


1 Tərcüməsi: Ey hamının pənah gətirdiyi,
Sənin razılığın uğrunda çalışanlara eşq olsun.
Kamalına dəlil “lövlak” kifayətdir.
Sən olmasaydın fələk mədari dolanmazdı.


376


**61**

Ey üqdəgüşayi-rişteyi-tədbirim!
Hər taətə əfvin səbəbi-təqsirim.
Təqsirimə etmə özgə təqdiri-cəza,
Şərməndəligim yetər mənim tə’zirim.

**62**

Qəd ənqəzəni dəvamü dai daim,
Ma li cəsədi ələl məsai qaim.
Ya laimü, lo vəqə’tə fima ənə fih
Vəllahi lənasəhtə və lümtəl-laim [1] .

**63**

Həmdəm, gör axan sirişki-alimni mənim,
Tutmuş rüxi-kəhrübamisalimni mənim.
Billah, yürü ol gülruxə ərz eyləyə gör,
Bir rəng ilə bu surəti-halimni mənim.

**64**

Əfqandır işim, sərvi-xuramının üçün,
Qandır cigərim, qönçeyi-xəndanın üçün,
Eşqində qəmü qüssə çəkib, pir oldum,
Mən pirə tərəhhüm et, igit, canın üçün!

**65**

Qəd şərrəfəkəllahü bitovfil-hərəmeyn,
Min rö’yəti məşhədeyni qərrət ləkə eyn,
Tuba limən əlqakə, ləinənnət-təhqiq,
Mən zarəkə, qəd zarə Əliyyən və Hüseyn [2] .


1 Tərcüməsi: Daimi xəstəlik məni vəziyyətə saldı.
Cəsədim artıq çalışmaqla ayaq üstə duran deyil.
Ey məni məzəmmət edən, mənim halıma düşəsən,
Allaha and olsun, nəsihət edərdin, məzəmmət edənləri isə
məzəmmət edərdin.
2 Tərcüməsi: Ey iki hərəmin təvafilə şərəflənən,
İki qəbri görməklə gözün işıqlandı.
Sənə çatanlara eşq olsun, doğrudan da,
Səni ziyarət edən Əlinin və Hüseyni ziyarət etmiş olur.


377


**66**

Ey qaib olan dideyi-xunbarimdən!
Vey rahət olan sineyi-əfgarimdən!
Mən varimi yox səninçün etdim, nə rəva
Sən tutmayasan xəbər yoxü varimdən.

**67**

Xunabə töküb dideyi-giryanimdən,
Sənsiz boyadım yer üzün öz qanimdən.
Öz qanimi eylərəm özümlə də’va,
Getməzsə əlim, nola, giribanimdan.

**68**

Qəddinə dedim ki, sərvi-bustandır bu!
Tünd oldu ki, ey xəstə, nə hədyandır bu.
Pabəstəvü urü bizəbandır dedigin,
Xəndanü qəbapuşü xuramandır bu.

**69**

Dedim ləbinə: lə’li-Bədəxşandır bu!
Güldü, dedi: ey fəqir, böhtandır bu!
Bir daşə nə rəng ilə qılarsan nisbət,
Şirinü şəkərfəşanü xəndandır bu.

**70**

Yandırdı məni şövqi-cəmalın, ey mah!
Hər ləhzə əcəb degil yetirsəm gögə ah!
Zülfün girehi çıxdı əlimdən nagah,
Gör kim, nə cəfa etdi mənə bəxti-siyah.


378


**71**

Rüxsarə səri-zülfi pərişan eylə!
Gözdən güli-rüxsarını pünhan eylə!
Bir neçə pərişanları öz halına qoy,
Hər ləhzə yetər, qəsdi-dilü can eylə.

**72**

Müjganımı, ey şəm’, gühərbar etmə!
Pünhan qəmimi aləmə izhar etmə!
Eşq əhlinə zülmdür vəfa eyləməmək!
Zinhar, bu zülmü etmə, zinhar etmə!

**73**

Rüxsarına ey etmə nigah etdigimi,
Göz yaşı töküb, naləvü ah etdigimi.
Ey padişəhi-hüsn, tərəhhüm çağıdır!
Əvf eylə ki, bilmişəm günah etdigimi.

**74**

Fəryad ki, eşq biqərar etdi məni,
Dərdü qəm ilə zarü nizar etdi məni.
Xaki-səri-kuyində qübar etdi məni,
Sərgəştəvü xarü xakisar etdi məni.

**75**

Gördüm səni, əldən ixtiyarım getdi,
Baxdım üzünə, səbrü qərarım getdi.
Xak oldumü hər yana qübarım getdi,
Əlqissə, qapından e’tibarım getdi.


379


# **Əlavələr**


                  - * *

Ey cahandidə gözüm, bunca ki, çox yaşın var,
Az görübsən eyi gün, vəh nə yaman başın var?

Var rüxsarimə xunabə çəkən müjganım,
Qıl qələm kimi ki, nəqş etməyə nəqqaşın var.

Şövqi-nə’lim oda salır necə kim, qarşımda,
Atəşin təl’ət ilən zülfü gözün, qaşın var.

Lə’l kani kimi, gər köksümü çak eyləyələr,
Onda xunabə ilən rəngli çox daşın var.

Rəhi-eşq içrə, Füzuli, demə tənha yürürəm,
Key xəbərsiz, qəmü möhnət kimi yoldaşın var.

                  - * *

Həvayi-eşq başda, dildə tabi-nari-firqət var,
Bəla xakində tən pamal, gözdə abi-həsrət var.

Nola bəzmi-bəladə sineyi-nalani çak etsəm,
Dəruni-dildən ol yarə yenə ərzi-məhəbbət var.

Məhi-növ sanma tutmuş çərxi tiği-şö’leyi-ahim,
Əduyi-bədnihadə ölməz isəm, yenə niyyət var.

Ləbin yadına can vermiş deyib, Fərhadi-dil, cana
Yenə əfvahi-aləmdə əcəb Şirin hekayət var.

Gəhi dərdi-fəraği-yar, gahi tə’neyi-əğyar;
Füzuli, sanma bu möhnətsəradə istirahət var [1] .


1 Bu qəzəl yalnız İstanbul nəşrindədir.


380


Guşeyi-əbrulərində çeşmi-cadularmıdır?
Yoxsa girmiş yayə tirəndaz hindularmıdır?

Iqdi-şəbnəmdir güli-tər üzrə, yaxud hər tərəf,
Qətrə-qətrə tərdən ol rüxsar üzə sularmıdır?

Iki əjdərdir ki, bir gənc üzrə baş qoymuş yatır,
Ya müsəlsəl arizin dövrində geysularmıdır?

Əşki-çeşmimdir səri-zülfün xəyalilə müdam,
Ya düzülmüş rişteyi-mişk üzrə lölö’lərmidir?

Sənmisən ancaq, Füzuli, böylə xublər maili [1],
Yoxsa eşq əhli qamu sən tək bəlacularmıdır?

                  - * *

**1**

Rəngim küli-zə’fəranə döndü sənsiz,
Qəddim xəm olub, kəmanə döndü sənsiz.
Qurbanın olum, əgər sitəmdir, bəsdir,
Peymanəm əlimdə qanə döndü sənsiz.

**2**

Dəlili-cəhldir eşq əhlinə surətpərəst olmaq
Ki, aqil iftiraqı mümkün ilə ittisal etməz.
Iradət zaye’ etməz əhli-mə’na surətə hərgiz,
Həqiqət cövhərin cəhli-məcazə paymal etməz.
Müqəyyəd olmaz əhli-surətin rənginə hal əhli,
Füzuli kim müqəyyədir, məgər idraki-hal etməz.


1 Bu qəzəl yalnız İstanbul nəşrindədir. Bizim gördüyümüz əlyazmalarından XVII
əsr nüsxəsində Şahiyə nəzirədir


381


**3**

Dərd yoxdur kimsədə, yoxsa təbibi-feyzi-eşq,
Kimdə gördü dərd kim, ol dərdə dərman etmədi.
Səbr yoxdur mərdümi-aləmdə, yoxsa ruzigar,
Hansı müşküldür ki, tədric ilə dərman etmədi?

**4**

Qəlbi-nadan olur həmişə siyah,
Laləvəş, rəngi ruyi-əhmər olur.
Üzü fəzl əhlinin riyazətlə,
Zəri-xalis misali əfsər olur.
Gər zəif olsa cismi danişmənd,
Ərəbi at çünki lağər olur.

**5**

Nükteyi-eşq neçə surətdən
Əhli-mə’na ilə təsrih etdik.
Kəsrəti vəhdətə qıldıq təbdil,
Cümlədən üzləti tərcih etdik.


382


**LÜĞƏT**

**A**

Aba – atalar.
Ac – fil dişi, fil sümüyü.
Afaq – üfüqlər.
Ağaz – başlama, ibtida, başlanğc.
Alayiş – ləkələmək, bulaşmaq.
Arayiş – bəzək, süs, zinət.
Ariyət – birovuz.
Ariz – yanaq; başvermə, meydana
çıxmaq; şikayətçi.
Asa – kimi, təki.
Aşiyan – yuva, sığınacaq yeri.
Aşub – fitnə; qarışıqlığa səbəb olan,
həyəcan.
Aşüftə – pərişan, dağınıq, özünü
itirmiş, qarıxmış.
Atəşbar – od yağıdıran.
Ayin – rəsm, adət, qayda-qanun.
Azimun (azmun) – öyrəniş, yoxlama,
təcrübə.

**B**

Bab – qapı; fəsil.
Badpa – sürətlə qaçan at.
Baqi – əbədi, daimi, həmişəlik; artıq
qalan.
Bang – səs, haray.
Bar – meyvə; yük.
Baran – yağş.
Barvər – meyvəli, yemişli.
Behbud – sağılıq, səhhət.
Bey’ – alver.
Beytül-həzən – qəm-qüssə evi.
Bədxah – düşmən, rəqib, pis fikirli
adam.
Bədmehr – rəhmsiz, şəfqətsiz, namehriban.
Bəha – parlaqlıq; işıq, gözəllik, qiymət;
dəyər.
Bəhaim – heyvan.
Bəhcət – gözəllik, şənlik, şadlıq.
Bəid – uzaq.
Bəir – dəvə.
Bənatün-nə’ş – sünbülə bürcü.

383


Bər – meyvə, yemiş, bəhər
Bərg – yarpaq.
Bəri – kənar; uzaq, boş.
Bərqi-lame’ – ildırım.
Bəstər – yataq, yorğan-döşək.
Bəyazi-eyn – gözün ağ.
Bəzm – qonaqlıq, kef məclisi.
Bihar – dəryalar, dənizlər.
Bihudəgərd – veyil-veyil gəzən,
avara.
Bim – qorxu.
Buqələmun – rəngdən-rəngə girən.
Büqa’ – yerlər, şəhərlər.
Bürhan – dəlil, sənəd.
Bürudət – soyuqluq.

**C**

Camə – paltar
Cavid – əbədi, daimi, həmişəlik.
Cazib – cəzb eyləyən, çəkici.
Cəbin – alın.
Cəvar – qonşular, qonşuluq.
Cəzm – kəsmək, qətiyyət.
Cidal – bərk dalaşmaq, şiddətli
qovğa etmək.
Cifə – qoxumuş cəmdək, leş.
Cüğıd – bayquş.
Cül – atın üstünə salınan çul.
Cüllab – gül suyu, gülab, gül suyundan
şərbət.
Cünbüş – tərpənmə, qımıldanma,
hərəkət.
Cünun – dəlilik, divanəlik.
Cür’ə – udum, qurtum.
Cürm – günah, suç.


384


**Ç**

Çah – quyu.
Çakər – qul, nökər.

**D**

Damən (daman) – ətək.
Daniş – bilik, elm.
Darüləman – aman evi, qorxusuz ev.
Darüssəlam – Bağıdadın ikinci adı,
dinclik evi.
Dəqaiq – incə nüktələr, dəqiqliklər.
Dərdnak – dərdli.
Dəstamuz – ələ öyrənən, ələ öyrənmiş.
Dəvvar – dövr edən, fırlanan, hərlənən.
Didə – göz.
Dinar – qızıl pul, sikkəli qızıl.
Dirəfş – bayraq.
Dirəm (dirhəm) – ağ pul, ağça (gümüş
pul).
Diriğ – heyf; əsirgəmək.
Dud – tüstü, tütün.
Dun – alçaq, əskik.
Dur – uzaq.
Duzəx – cəhənnəm.
Dürd – şərabın dibinə çökən torta,
xılt.
Dürr – inci, mirvarid.
Dürri-yetim – sədəfin içində tək bir
dənə olan inci, misilsizürr.
Düşvar – çətin, müşkül.

**E**

E’timad – etibar, inam.
E’vicac – əyrilik, qıvrım.
Ehram (Ihram) – Hacıların Kəbəni
ziyarət müddətində geydikləri
xüsusi paltar və bu müddətdə
müəyyən işlərdən çəkinmələri.

**Ə**

Ə’van – köməklər, köməkçilər.
Əbdan – bədənlər, gövdələr.
Əbr – bulud.Əbru – qaş.

385


Ədvər – dövrlər, zamanlar, vaxtlar,
mərhələlər.
Ədyan – dinlər.
Əfgar – yaralı, üzgün.
Əfkar – fikirlər.
Əflak – fələklər, göylər.
Əfsər – tac.
Əfsürdə – bürüşmüş, solğun.
Əfza – artıran.
Əhbab – dostlar.
Əxgər – od parçası, qığılcım, qor.
Əxtərşünas – münəccim.
Əqran – yaxın adamlar, tay-tuşlar.
Əlayiq – əlaqələr, rabitələr.
Əlfaz – ləfzlər; ifadə, söz.
Əllamə – dərin bilikli, bilici, çox
bilən.
Əmin – inanılmış; mötəbər.
Əmn – rahatlıq, əmniyyət.
Əmraz – azarlar, xəstəliklər.
Əmvac – ləpələr, dalğalar.
Əmvat – meyitlər, ölülər.
Ənadil – əndəliblər, bülbüllər.
Ənbiya – peyğəmbərlər.
Əncüm – ulduzlar.
Ənfas – nəfəslər.
Əngur – üzüm.
Ənis – həyan, dost.
Ər – əgər.
Ərbabi-yəqin – yəqinlik sahibləri,
elm ilə yəqin mərtəbəsinə atanlar.
Ərvahi-qüds – pak, təmiz ruhlar.
Ərzəl – ən rəzil, ən alçaq.
Əsalib – üslublar, qaydalar.
Əsrar – sirrlər, gizli sözlər.
Əşk – göz yaşı.
Əşkal – şəkillər, növlər.


386


Əşkbar – göz yaşı tökən, çox ağılayan.
Ətvar – tövrlər, hallar.

**F**

Fərsudə – solmuş, köhnəlmiş.
Fəttan – təşviq edici; çox fitnəli;
gözəl.
Firdövsi-bərin – uca behişt.
Firiştə – mələk.
Firuz – qalib, xoşbəxt, ağgünlü.
Fitrət – yaradılış, xilqət.
Fövz – qurtuluş, nicat, nüsrət.
Fürqan – Quranın ikinci adı; xeyirlə
şəri ayıran.
Füruğ – işıq, ziya.
Füsun – ovsun.
Füzun – artıq.

**G**

Gəncinə – xəzinə, dəfinə.
Gərd – toz.
Gəzaf – artıq, mübaliğə.
Girehgir – düyümlü, qıvrım.
Gülbün – gül ağacı.
Gülgəşt – gül seyri, gül tamaşası.
Gülgun – gül rəngli, gül üzlü.
Gümrah – yolunu itirmiş, azğın.

**H**

Hail – pərdə, örtü.
Halə – ayın ətrafında görünən işıqlı
dairə.
Haris – əkinçi, rəncbər.
Hasid – gözü dar, həsəd əhli, paxıl.
Heyn – an, zaman.
Həməl – qoç bürcü.
Hərami – oğru, yolkəsən, adamsoyan.
Hərim – məhrəm yer, yaxın adamların
gedə biləcəkləri yer.
Hərir – ipək, ipəkdən toxunmuş paltar.
Həzin – qəmli, qayğılı, qüssəli.
Hirman – məhrum olmaq, əli üzülmək,
peşmançılıq.
Hirz – tilsim, bəladan qorunmaq üçün

387


yazılı dua; möhkəm yer, qala.
Hiyəl – hiylələr.
Hur – huri, pəri, gözəllər.
Hut – balıq bürcü.
Hübab – suyun üzərində əmələ gələn
qabarcıq, köpük.
Hükkam – hökm verənlər, hakimlər.
Hüsul – hasil olma, vücuda gəlmə.

**X**

Xaksar – düşkün, xar.
Xalxal – qadınların bəzək üçün
topuqlarına taxdıqları zınqırov.
Xamə – qələm.
Xan – xonça, içi yeməklə dolu məcməyi,
süfrə.
Xara – bərk daş, çaxmaq daşı.
Xaşak – çör-çöp.
Xatəm – üzük qaşı, möhür.
Xatim – axırıncı, xətm eyləyən,
möhürləyən.
Xazin – xəzinəçi.
Xeyl – dəstə, zümrə, bölük.
Xeyrəncam – aqibəti xeyr, axırı xeyr.
Xədəng – ox.
Xəffaş – yarasa, gecə quşu.
Xələf – övlad.
Xəmidə – əyilmiş.
Xərac – vergi, bac.
Xəzan – payız.
Xəzəf – saxsı qab, saxsı parçası.
Xilafət – xəlifəlik, din və dövlət
hakimi.
Xilqət – xəlq olunmaq, yaranmaq.
Xirəd – ağıl.
Xirədmənd – ağıllı.
Xişt – kərpic.
Xu – xasiyyət.
Xuni – qanlı, qatil.


388


Xüşk – quru.
Xütut – xətlər.

**İ**

İbram – üzə salıb rica etmək; bir işi
bir adamın boynuna güc ilə,
utandıra-utandıra qoymaq, israr.
İbtihac – sevinc, fərəh, sürur.
İctinab – çəkinmək, uzaq durmaq.
İfşa – açmaq, aşkar etmək.
İxfa – gizləmə, gizli, örtülü saxlamaq.
İqd – həmail, boyunbağ; qıvrım.
İlzam – lazım bilmək, qane etmək,
məcbur etmək.
İmtila – tıxanmaq, dolmaq.
İmtina – mən etmək, çəkinmək, rədd
etmək.
İmtizac – qarışma, üns tutma.
İnfial – mütəəssir, xəcalətli olmaq,
utanmaq.
İnha – xəbər vermək, söz yetirmək.
İnhiraf – dönmək, boyun qaçırmaq.
İntiha – nəhayət, son, axır.
İrşad – yol göstərmək, rəhbərlik
etmək.
İrtifa’ – ucaltma, yüksəltmə, hündürlük.
İrtişa – rüşvət almaq. Istehqaq – ləyaqət
və xidmətə görə haqq almaq.
İstiğfar – üzr istəmək, tövbə etmək.
İstiğına – vara qənaət etmə, nazlanma,
ağr davranma; laqeydlik.
İstiqamət – möhkəmlik, düzlük,
hərəkət yolu.
İstiqbal – pişvaz etmək, qabağa çıxmaq,
qarşılamaq.
İstima’ edən – eşidən, dinləyən.
İşkal – çətinlik, maneə.
İştiha – istək, arzu; yemək həvəsi.
İttisal – bitişmək, yapışmaq, qovuşmaq.
İzdiyad – artmaq, çoxalmaq.
İzəd – Tanrı, Allah.


389


**J**

Jəngar (zəngar) – pas.
Julidə – dağınıq, qarmaqarışıq.

**K**

Kax – qəsr, köşk, saray.
Kam – arzu; damaq, ağız.
Kamandar – ox atan.
Kan – mədən.
Kar – iş.
Kargər – işləyən, işlək.
Kasid – qiymətsiz, işə keçməyən.
Kazib – yalançı.
Kəbbadə – yeni öyrənənlərə məxsus
təlim yayı.
Kəbud – göy rəng.
Kəc – əyri.
Kəlimat – kəlmələr, sözlər.
Kəlimullah – Musa peyğəmbərin
ləqəbi; Allahla danışan.
Kəminə – aciz.
Kəmtər – az, əskik.
Kərahət – iyrənmək.
Kərkəs – quzğun.
Kəsrət – çoxluq.
Kəşti – gəmi.
Kəvakib – ulduzlar.
Kilk – qələm.
Kimüxt – saqrı dərisi.
Kisvət – paltar.
Kizb – yalan.
Kövkəb – ulduz.
Kövn – varlıq, dünya, olmaq.
Kuh – dağ.
Kuhkən – Fərhad; dağçapan.
Külbə – dar, qaranlıq hücrə, koma.
Küstax – həyasız, sırtıq.
**Q**

Qazi – şəriət hakimi.
Qə’r – dərinlik, suyun dibi.


390


Qəba – don.
Qəvvas – dalğc..
Qiladə – boyunbağ, xalta.
Qillət – azlıq.
Qüfran – bağşlama, günahdan keçmə.
Qüllab – çəngəl, qarmaq.
Qülü (ğülüvv) – coşmaq, həddi
aşmaq.
Qürb – yaxınlıq.
Qüreyşi – Qüreyş tayfasına mənsub.

**L**

Laməkan – yersiz, məkansız.
Layətəcəzza – bölünməz.
Ləb – dodaq.
Ləhəd – qəbr.
Ləxt-ləxt – parça-parça.
Lərzan – titrəyən, əsən.
Ləziz – ləzzətli, dadlı.
Liva – bayraq.
Lö’löi-xoşab – ən parlaq inci, sulu inci.
Lövh – lövhə, səhifə.

**M**

Ma’ – su.
Ma’əda – ondan başqa, ondan qeyri.
Mahtab – ay işığ.
Manənd – kimi, bənzər.
Masəva – Allahdan başqa nə varsa;
yaradılmış, varlıq.
Maütin – su və palçıq.
Mayil – meyl edici, meyilli.
Mə’bəd – ibadət evi, ibadətxana.
Mə’mur – abad.
Mə’zur – üzürlü.
Məal – məna, məfhum.
Məani – mənalar, dərin düşüncə.
Məcalis – məclislər, yığıncaqlar.
Mədaris – mədrəsələr, dərs verilən
yerlər.
Məddi-nəzər – görmə hüdudu, üfüq,
gözün qeyri-ixtiyari olaraq bir
nöqtəyə dikilməsi, gözün yol
çəkməsi.
Mədəni – mədinəli, Mədinə əhli.

391


Mədfən – qəbir.
Məftuh – açılmış.
Məğız – ilik; iç, beyin.
Məhd – beşik.
Məhfil – toplanacaq yer, yığıncaq.
Məhfuz – saxlanılmış, qorunmuş.
Məxuf – qorxunc, qorxulu.
Məkki – Məkkə əhli.
Məknun – gizlənmiş.
Məqal – danışıq.
Məqasid – məqsədlər.
Məqtu – kəsilmiş, qət olunmuş.
Məmlüv – dolu, ağızına qədər
doldurulmuş.
Mənahi – qadağan edilmiş işlər,
bəyənilməyən şeylər.
Mənsubə – şətrənc, şahmat.
Mənzilət – dərəcə, rütbə, mərtəbə.
Mənzur – nəzərə alınmış, baxılmış.
Məratib – mərtəbələr, dərəcələr.
Mərdud – qovulmuş, sürülmüş, rədd
olunmuş.
Mərdüm – göz giləsi; xalq, camaat.
Mərqəd – qəbir, məzar.
Mərsum – yol xərci; ümumi qayda,
adət.
Məsdər – mənşə; bir şeyin çıxdığ yer.
Məsnəd – taxt, söykənəcək yer.
Məşkur – şükr olunmuş, təşəkkür
edilmiş.
Məşrəb – xülq, xasiyyət.
Məşruh – şərh, bəyan olunmuş.
Məzahir – zahir olan yerlər.
Məzhər – bir şeyin zahir olduğu yer.
Midad – qələm.
Miftah – açar.
Minbə’d – bundan sonra.
Minhac – böyük yol, şahrah.
Minqar – dimdik.


392


Mir’at – güzgü, ayna.
Möhlik – təhlükəli, öldürücü.
Möhtəsib – dinin qanunlarını qoruyan
mə’mur.
Mubəmu – bir-bir, incədən-incəyə,
telbətel.
Munis – hayan, ünsiyyətli.
Mü’ənbər – ənbərlənmiş, ətirli.
Müalic – əlac edən, təbib.
Mübahat – öyünmək, fəxr etmək.
Mübahis – bəhs edən.
Mübdi – bağılayan.
Mübərra – təmiz, pak.
Mübhəm – anlaşılmayan, dolaşıq.
Mücərrəb – sınanmış, təcrübədən
çıxmış.
Mücərrəd – yalqız; boş; nəfsini
dünyadan kəsən.
Mücmələn – xülasə olaraq, müxtəsər.
Müddəi – iddia edən, rəqib.
Müəlla – uca, yüksək, ali.
Müərrif – tanıdan, tanış edən.
Müəssir – təsirli.
Müfəvvəz – inanılmış.
Müfsid – fitnə-fəsad törədən.
Müğ – atəşpərəst.
Mühəddis – hədisçi, hədis rəvayət
edən.
Mühəqqər – təhqir olunmuş, kiçik.
Müqarin – yavuq, yaxın.
Müqərrər – qərarlaşmış, qət edilmiş.
Müqəşşər – qabığ soyulmuş.
Müqəvvəs – yarımdairə kimi əyilmiş.
Mül – üzüm şərabı.
Mülazim – xidmətçi, vəzifəsindən
ayrılmayan qulluqçu.
Müləvvəs – çirkin, bulaşıq, kirli.
Mülhəq – ilhaq olmuş, bitişmiş,
qovuşmuş.
Mültəməs – iltimas edilmiş.
Mümsik – simic, xəsis.
Mün’im – nemət verən, ehsan edən,
varlı.
Münhi – xəbərçi, müxbir.
Münqad – itaət eyləyən, ram olmuş.
Münqəlib – dönən, dəyişilən.
Münqəte’ – kəsilmiş, parçalanmış.

393


Müntəxəb – seçilmiş.
Mürəbbe’ – dördlük.
Mürsəl – göndərilmiş; elçi.
Müsəddəs – hər bəndi altı misradan
ibarət şeir.
Müsəffa – durulmuş, saflaşmış.
Müsəxxər – istila edilmiş, itaətə
gətirilmiş.
Müshəf – Quran.
Müstəar – başqasından qəbul olunmuş,
birovuz.
Müşəxxəs – təşxis olunmuş, aydınlaşmış.
Müşəvvəş – qarışıq.
Müşkbar – müşk yağıdıran.
Müşkbu – müşk qoxulu.
Mütabiə – tabe olmaq.
Müttəqi – pəhrizkar.
Müttəsil – bir-birinin ardınca, daima.
Müvəhhid – Allahı bir bilən.
Müzmər – örtülü, gizlədilmiş.
Müztərib – iztirablı, narahat.

**N**

Nafə – göbək.
Nafərcam – sonu pis vəziyyətə
düşən, pis nəticəli, əncamsız.
Naqə – dişi dəvə, maya.
Nal – qamış qələm içindəki tel; nalə
etmək.
Namərbut – rabitəsiz, bağılanmamış.
Nasix – pozan.
Nasüftə – dəlinməmiş, deşilməmiş.
Navək – ox.
Neyrəng – hilə.
Nəf’i-dünyəvi – dünya mənfəəti.
Nəhy – qadağan etmək; bir adamı pis
işdən çəkindirmək.


394


Nəxl – xurma ağacı.
Nəməd – keçə.
Nəsəq – nizam, qanun, tərtib.
Nəss – aşkar dəlil, doğru məna, mətn.
Nəval – bəxşiş.
Nigin – üzük qaşı.
Nihal – təzə, boyu düz ağac.
Nişimən – oturaq, məskən.
Növrəs – yeniyetmə, gənc.
Nüsrət – kömək, yardım.

**P**

Paş – səpən, çiləyən.
Payə – rütbə, mərtəbə, pillə.
Peykan – ox.
Pərkalə – parça-parça.
Pəst – alçaq.
Pirahən – köynək.
Pirayə – bəzək, zinət.
Pül – körpü.
Pürxəm – əyri-üyrü, qıvrım.

**R**

Rah – şərab, çaxır; yol.
Rayət – bayraq.
Rayihə – ətir, qoxu, iy.
Raz – sirr, gizli olan şey.
Rəg – damar.
Rəhnümun – yol göstərən.
Rəhröv – yolçu, yol gedən.
Rəxt – yatacaq, paltar.
Rəsən – ip, kəndir.
Rəşəhat – sızıntılar, damcılar.
Rəşhə – sızıntı, damcı.
Rəşk – həsəd, qısqanmaq.
Ribat – saray, meyxana, karvansara.
Riyaz – bağça.
Riyazət – nəfsin istədiklərini rədd
edərək özünü ac və yuxusuz
saxlamaq.
Rizvan – behiştin, cənnətin baxıcısı.
Rövzən – pəncərə, baca.
Ruzə – oruc.
Rüf’ət – yüksəklik.
Rüsul – elçilər, peyğəmbərlər.

395


Rüsum – rəsmlər, adətlər.
Rütəb – xurma.
**S**

Sağər – qədəh, piyalə.
Sahir – cadugər, gözbağılayıcı.
Said – bilək.
Salik – yolçu.
Salis – üçüncü.
Salus – hiyləgər, adamaldadan,
siyasətçi.
Sane’ – yaradıcı, icad edən.
Savab – doğru, düz.
Seyd – ov, şikar.
Seylab – sel.
Sə’d – uğurlu.
Səbəq – dərs.
Səbu – cürdək, sovça.
Səccadə – canamaz, namaz xalçası.
Səfinə – gəmi, cüng.
Səgi-şəbgərd – gözətçi it.
Səhab – bulud.
Səhranəvərd – səhraları gəzən.
Səlasil – silsilələr, zəncirlər.
Səlsəbil – behiştdə bulaq adıdır.
Səmin – bahalı, qiymətli.
Səng – daş.
Səngsar – daşqalaq.
Sərab – miraj.
Sərd – soyuq.
Sərgərm – nəşəli, məşğul, başı
qarışmış.
Sərgəştə – avara, heyran.
Sərih – açıq, aydın.
Sərir – taxt.
Sərvər – başçı.
Sib – alma.
Sima’ – dinləmək, nəğmə eşitmək.
Simab – civə.
Simbər – gümüş bədənli.
Siməndud – gümüş suyuna çəkilmiş.
Simsaq – baldırı gümüş kimi ağ.
Sipah – ordu, qoşun.
Sipehr – göy, sfera.
Sirət – əxlaq, fitri təbiət; yaşayış tərzi.
Sirişk – göz yaşı.
Sövgənd – and, qəsəm.

396


Sud – fayda, qazanc.
Sui-məzac – bədtəbiət, bədxulq,
bədxasiyyət.
Surax – dəlik, deşik.
Sübhi-əzəl – ilk sübh.
Sücud – səcdə etmək.
Süfəha – səfehlər, axmaqlar.
Süflə – alçaq, rəzil.
Süha – ən kiçik ulduz.
Sürahi – uzun boğazlı şərab şüşəsi.
Sürəyya – yeddiqardaş ulduz, Ülkər.
Sürud – nəğmə, oxumaq, melodiya.
Sütur – sətirlər, xətlər.

**Ş**

Şahid – gözəl.
Şayistə – layiq, dəyərli.
Şəbgərd – darğa; gecə növbətçi.
Şəhnə – darğa, gözətçi.
Şəhriyar – padşah.
Şəkərxab – sizin yuxu.
Şəqq – bölmək.
Şəmmə – bir az, cüzi.
Şərarə – od parçası, qığılcım.
Şərhə-şərhə – para-para, dilim-dilim.
Şəyyad – fırıldaqçı, yalançı, ikiüzlü.
Şiftə – aşiq, məftun, vurğun.
Şitab – tələsmə.
Şivən – fəryadla ağılamaq.
Şöhrə – şöhrətli, məşhur.
Şuridə – şura gəlmiş, özünü itirmiş,
dalğın.
Şükufə – çiçək.
Şükuh – dəbdəbə, şərəf, əzəmət.

**T**

Tabdar – parlaq, işıqlı; qıvrılmış.
Tak – üzüm budağ, tənək.
Tə’dib – ədəbləndirmək, ədəb
vermək.
Tə’əb – məşəqqət, zəhmət.
Tə’viz – bəladan qorunmaq üçün
yazılı dua.
Tə’yid – qüvvət alma, gücləndirmə,
təsdiq etmə.

397


Tə’zim – ehtiram etmək, baş əymək.
Tə’zir – danlamaq, qınamaq, cəzalandırmaq.
Təcəmmül – bəzənib düzənmək,
zinətlənmək.
Təəllül – yubatmaq, yubandırmaq.
Təərrüz – sataşmaq, hücum etmək,
dolaşmaq.
Təfaxür – fəxr etmə, öyünmə.
Təfriqə – dağınıqlıq, ayrılıq.
Təğyir – döndərmək, dəyişmək.
Təhrik – hərəkət vermə, tərpənmə.
Təhsin – alqış, afərin, bəyənmək.
Təxfif – yüngülləşdirmək.
Təxt-rəvan – çiyin üzərində aparılan
təxt.
Təxvif – qorxutmaq, hədələmək.
Təqdir – əvvəlcədən qərara alınmış.
Təlx – acı.
Təməvvüc – dalğalanmaq, ləpələnmək.
Tənə’üm – var-dövlət içərisində
həyat sürmək.
Tərəb – şadlıq.
Tərəhhüm – rəhm etmək.
Tərrar – hiyləgər, adam aldadan,
əyyar.
Təşvir – coşmaq, qaynamaq.
Təvaf – başına dolanmaq.
Təvil – uzun.
Təzvir – hiylə.
Tila – qızıl suyu, qızıl.
Timar – xəstəyə baxmaq, şəfa vermək.
Tin – palçıq.
Tirə – qaranlıq, tutqun.
Tişə – külüng.
Tövq – həlqə, boyunbağ.
Tövsən – harın at.
Tuba – cənnətdə bitən ağac.
Turab – torpaq.
Tutiya – gözə çəkilən maddə.
Türbət – torpaq.
Türrə – saçın qıvrımı.
Tüyur – quşlar.
**U**

Ud – yandırılarkən gözəl qoxu verən
bir ağacın adıdır.
Ur – çılpaq.

398


**Ü**

Ücb – özü haqda yüksək fikirdə olma,
təkəbbür.
Üqd – düyüm, çətinlik.
Üqdi-irtibat – əlaqə bağ.
Ülüvv – ucalıq, yüksəklik.
Ülüvvid-dərəcat – ali dərəcəli,
yüksək məqamlı.
Ümm – ana.
Ümmi – anadangəlmə yazıb-oxumaq
bilməyən.
Ümmül-xəbais – xəbislərin anası;
şəraba verilən addır.
Üstüxan – sümük.
Üstüvar – möhkəm, qüvvətli, daimi.
Üzar – yanaq.

**V**

Vabəstə – bağılı; asılı olmaq.
Vajgun – başı aşağ.
Vəcdiyyat – sevinclər, şadlıqlar.
Vəh – aydınlıq, aşkarlıq.
Vərə’ – haram şeylərdən çəkinmək.
Vəsmə – qaraltmaq üçün qaşa yaxılan
maddə.
Vəş – kimi, tək mənasında işlənən
ədatdır.
Vücub – lazım, gərək.
Vühuş – vəhşi heyvanlar.


399


**Z**

Zağ – qarğa.
Zahid – dünya işlərindən əl çəkərək
ibadətlə məşğul olan adam.
Zayir – görüşə gedən, ziyarət edən.
Zəbun – düşkün, aciz, zəif.
Zəhi – nə xoş, nə gözəl.
Zəxirə – dar günə saxlanılan şey,
azuqə.
Zəxm – yara.
Zəman – zamin.
Zəmir – könül, qəlb.
Zərq – hiylə, biclik.
Zərnigar – qızıl suyu ilə yazılı.
Zərrin – qızıldan qayrılma.
Zində – diri.
Zinhar – saqın, aman.
Zivər – bəzək.
Ziyadət – artıq, artıqlıq.
Zöhd – zahidlik
Zövrəq – qayıq.
Zünnar – xristian ruhanilərinin
bağıladığ qurşaq.


400


**MÜNDƏRİCAT**

Füzuli “Divan”ının nəşri haqqında (Həmid Araslı)…………………………...4
Füzuli sözünün sehri (Samət Əlizadə)……………………………………….11

Füzuli divanının dibaçəsi ……………………………………………………26

Qəzəllər
Qəd ənarəl-eşqə-lil-üşşaqi minhacəl-hüda …………………………………..37
Ya mən əhatə elmükəl-əşya’ə külləha……………………………………….38
Ya Rəb, həmişə lütfünü et rəhnüma mana . . . . . . . . . . . . . . . . . . . . . . . . . ....39
Zəhi, zatın nihanü ol nihandan masiva peyda . . . . . . . . . . . . . . . . . . . . . . .. .40
Əşrəqət min fələkil-behcəti şəmsün və biha . . . . . . . . . . . . . . . . . . . . . . …. .41
Ey olub me’rac bürhani-ülüvvi-şan sana . . . . . . . . . . . . . . . . . . . . . . . . . . ....42
Kargər düşməz xədəngi-tə’neyi-düşmən mana . . . . . . . . . . . . . . . . . . . . …. .43
Ey mələksima ki, səndən özgə heyrandır sana . . . . . . . . . . . . . . . . . . . . . … .44
Cam içrə mey ki, dairə salmış hübab ona . . . . . . . . . . . . . . . . . . . . . . . . . ... .45
Dustum, aləm səninçin gər olur düşmən mana . . . . . . . . . . . . . . . . . . . . …. .46
Kəmali-hüsn veribdir şərabi-nab sana . . . . . . . . . . . . . . . . . . . . . . . . . . . … .47
Riştədir cismim ki, dövri-çərx vermiş tab ona . . . . . . . . . . . . . . . . . . . .. . .. .48
Eşq ətvarın müsəlləm eylədi gərdun mana . . . . . . . . . . . . . . . . . . . . . . . …. .49
Qəm diyarında əcəl peyki güzar etməz mana . . . . . . . . . . . . . . . . . . . . . … ..50
Canımın cövhəri ol lə’li-gühərbarə fəda . . . . . . . . . . . . . . . . . . . . . . . . . …. .51
Qəmdən öldüm, demədim hali-dili-zar sana . . . . . . . . . . . . . . . . . . . . . . . ….52
Qəmzəsin sevdin, könül, canın gərəkməzmi sana? . . . . . . . . . . . . . . . . . …. .53
Gərçi, ey dil, yar üçün üz verdi yüz möhnət sana . . . . . . . . . . . . . . . . . . …. .54
Ey bivəfa ki, adət olubdur cəfa sana . . . . . . . . . . . . . . . . . . . . . . . . . . . . ... . .55
Şəb ki, miftahi-məhi-növ ola gəncinəgüşa . . . . . . . . . . . . . . . . . . . . . . . …. .56
Fəqr mülki təxtü aləm tərki əfsərdir mana . . . . . . . . . . . . . . . . . . . . . . . . .... .57
Şərbəti-lə’lin ki, derlər çeşmeyi-heyvan ona . . . . . . . . . . . . . . . . . . . . . … . .58
Hər zaman mənzur bir şuxi-sitəmgərdir mana . . . . . . . . . . . . . . . . . . . . . … .59
Mənim tək hiç kim zarü pərişan olmasın, ya Rəb . . . . . . . . . . . . . . . . . . …. .60
Ey navəki-şövqin sipəri-sineyi-əhbab . . . . . . . . . . . . . . . . . . . . . . . . . . . …. .61
Sübh çəkmiş çərxə, çalmış daşə tiğin afitab . . . . . . . . . . . . . . . . . . . . . . . ... .62
Sübh salıb mah rüxündən niqab . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . … .63
Qaliba bir əhli-dil toprağidir dürdi-şərab . . . . . . . . . . . . . . . . . . . . . . . . . ... .64
Qılsa vəslin şamımı sübhə bərabər, yox əcəb . . . . . . . . . . . . . . . . . . . . . …. .65
Sən üzündən aləmi rövşən qılıb saldın niqab . . . . . . . . . . . . . . . . . . . . . . ... .66
Kuhkən Şirinə öz nəqşin çəkib vermiş firib . . . . . . . . . . . . . . . . . . . . . . … . .67


401


Ol ki, hər saət gülərdi, çeşmi-giryanım görüb . . . . . . . . . . . . . . . . . . . . . .... .68
Ruzigarım buldu dövrani-fələkdən inqilab . . . . . . . . . . . . . . . . . . . . . . … .. .69
Dərdi-eşqim dəf’inə zəhmət çəkər daim təbib . . . . . . . . . . . . . . . . . . . . . …..70
Payibənd oldum səri-zülfi-pərişanın görüb . . . . . . . . . . . . . . . . . . . . . . . … .71
Qeyrə eylər bisəbəb min iltifat ol nuşləb . . . . . . . . . . . . . . . . . . . . . . . . . .... .72
Vəslin mənə həyat verir, firqətin məmat . . . . . . . . . . . . . . . . . . . . . . . . . . ….73
Yürü, yetir mənə, ey simi-əşk, bidad et . . . . . . . . . . . . . . . . . . . . . . . . . . … .74
Əksi-rüxsarın ilə oldu müzəyyən mir’at . . . . . . . . . . . . . . . . . . . . . . . . …. . .75
Ey əsiri-dami-qəm, bir guşeyi-meyxanə tut . . . . . . . . . . . . . . . . . . . . . . …. .76
Bəhri-eşqə düşdün, ey dil, zövqi-dünyani unut . . . . . . . . . . . . . . . . . . . . … .77
Mürdə cismim iltifatından bulur hər dəm həyat . . . . . . . . . . . . . . . . . . .. . . .78
Səba, əğyardan pünhan, qəmim dildarə izhar et! . . . . . . . . . . . . . . . . . . . ... .79
Xətti-rüxsarın edər lütfdə reyhan ilə bəhs . . . . . . . . . . . . . . . . . . . . . . . . …. .80
Cəhan içrə hər fitnə kim, olsa hadis . . . . . . . . . . . . . . . . . . . . . . . . . . . . . … .81
Ey qübari-qədəmin ərşi-bərin başinə tac . . . . . . . . . . . . . . . . . . . . . . . . . …. .82
Can çıxır təndən könül zikri-ləbi-yar eyləgəc . . . . . . . . . . . . . . . . . . . . …. . .83
Könlüm açılır zülfi-pərişanını görgəc . . . . . . . . . . . . . . . . . . . . . . . . . . …. . .84
Münhərifdir, saqiya, ənduhi-dünyadən mizac . . . . . . . . . . . . . . . . . . . . . .... .85
Olur qəddim düta, eşqin yolunda hər bəla görgəc . . . . . . . . . . . . . . . . . . … .86
Ey könül, yarı istə, candan keç . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ... .87
Gər degil bir mah mehrilən mənimtək zar sübh . . . . . . . . . . . . . . . . . . . . … .88
Əgər murad isə vermək səfayi-cövhəri-ruh . . . . . . . . . . . . . . . . . . . . . . ….. .89
Qansı mahin, bilməzəm, mehrilə olmuş zar sübh . . . . . . . . . . . . . . . . . …. . .90
Ol mişkbu qəzalə ixlasım eylə vazeh . . . . . . . . . . . . . . . . . . . . . . . . . . . … . .91
Kimsədə rüxsarına taqəti-nəzzarə yox . . . . . . . . . . . . . . . . . . . . . . . . . . . … .92
Nola gər qucsa miyanın kəməri-zər küstax . . . . . . . . . . . . . . . . . . . . . . …. . .93
Rəngi-ruyindən dəm urmuş sağəri-səhbayə bax . . . . . . . . . . . . . . . . . . … . .94
Ləblərin tək lə’lü ləfzin tək düri-şəhvar yox . . . . . . . . . . . . . . . . . . . . . …. . .95
Gərmdir şamü səhər mehrinlə çərxi-lacivərd . . . . . . . . . . . . . . . . . . . . . …. .96
Nalədəndir ney kimi avazeyi-eşqim bülənd . . . . . . . . . . . . . . . . . . . . . . . ... .97
Göz xətindən mərdümin məhv etmədən bulmaz murad . . . . . . . . . . . . . …. .98
Ey məzaqi-canə cövrün şəhdü şəkkər tək ləziz . . . . . . . . . . . . . . . . . . . . …. .99
Cilveyi-əksi-rüxün ayinədə, ey rəşki-hur . . . . . . . . . . . . . . . . . . . . . . . . ….100
Yanan eşq atəşinə atəşi-düzəxdən eyməndir . . . . . . . . . . . . . . . . . . . . . …. .101
Çeşmi-surətbazimə müjgan səfi həngamədir . . . . . . . . . . . . . . . . . . . . . . ....102
Səbuh üçün mənə dürdi-meyi-şəbanə yetər . . . . . . . . . . . . . . . . . . . . . …. .103
Gah gözdə, gəh könüldə xədəngin məkan tutar . . . . . . . . . . . . . . . . . . . … .104
Xoşam kim, dəmbədəm giryan gözüm ol xaki-padəndir . . . . . . . . . . . . . ...105
Pərişan xəlqi-aləm ahü əfqan etdigimdəndir . . . . . . . . . . . . . . . . . . . . . . ….106
Qəbrim daşinə kim, qəm odundan zəbanədir . . . . . . . . . . . . . . . . . . . . . … .107
Canı kim cananı üçün sevsə cananın sevər . . . . . . . . . . . . . . . . . . . . . . ... . .108


402


Mehri könlümdə nihan olduğun ol mah bilir . . . . . . . . . . . . . . . . . . . . . . ..109
Müjəm sərçeşmələr mənzil qılan aşüftə məcnundur . . . . . . . . . . . . . . . … .110
Qübari-səcdeyi-rahin xəti-lövhi-cəbinimdir . . . . . . . . . . . . . . . . . . . . . . ….111
Demiş hər qönçəyə aşiqligim razın səba derlər . . . . . . . . . . . . . . . . . . . . ....112
Səbadən gül üzündə sünbüli-pürpiçü tab oynar . . . . . . . . . . . . . . . . . . .. . .113
Ah eylədigim sərvi-xuramanın üçündür . . . . . . . . . . . . . . . . . . . . . . . . . ... .114
Qansı gülşən gülbüni sərvi-xuramanınca var . . . . . . . . . . . . . . . . . . . . . ... .115
Vəh nə qamət, nə qiyamət, bu nə şaxi-güli-tərdir . . . . . . . . . . . . . . . . . ….116
Hüsnün olduqca füzun eşq əhli artıq zar olur . . . . . . . . . . . . . . . . . . . . .. . .117
Ey gül, nə əcəb silsileyi-mişki-tərin var . . . . . . . . . . . . . . . . . . . . . . . . …. .118
Ləhzə-ləhzə ləbin anıb, edicək əfqanlar . . . . . . . . . . . . . . . . . . . . . . . . . ….119
Tökdükcə qanımı oxun, ol asitan içər . . . . . . . . . . . . . . . . . . . . . . . . . . . ... .120
Girib meyxanəyə müğ məşrəbilə kim ki, xu eylər . . . . . . . . . . . . . . . . . … .121
Saçın əndişəsi təhriki-zənciri-cünunumdur . . . . . . . . . . . . . . . . . . . . . . … .122
Məndə Məcnundan füzun aşiqlik iste’dadı var . . . . . . . . . . . . . . . . . . . . …123
Müqəvvəs qaşların kim, vəsmə birlə rəng tutmuşlar . . . . . . . . . . . . . . . . ...124
Aşiyani-mürği-dil zülfi-pərişanındadır . . . . . . . . . . . . . . . . . . . . . . . . . . ….125
Saqiya, cam tut ol aşiqə kim, qayğuludur . . . . . . . . . . . . . . . . . . . . . . . . ... .126
Məni zikr etməz el, əfsaneyi-Məcnunə mayildir . . . . . . . . . . . . . . . . . . … .127
Ol pərivəş kim, məlahət mülkünün sultanıdır . . . . . . . . . . . . . . . . . . . . …. .128
Mənim kim, bil ləbi-xəndan üçün giryanlığm vardır . . . . . . . . . . . . . . … .129
Zövq şövqilə cəhan qeydin çəkən zəhmət çəkər . . . . . . . . . . . . . . . . . . ... .130
Hər kitabə kim, ləbi-lə’lin hədisin yazələr . . . . . . . . . . . . . . . . . . . . . . … ..131
Seyr qıl, gör kim, gülüstanın nə abü tabı var . . . . . . . . . . . . . . . . . . . . … . .132
Sərvi-azad qədinilə mana yeksan görünür . . . . . . . . . . . . . . . . . . . . . . . . ....133
Süluki-fəqr ətvarım, məzaqi-eşq halımdır . . . . . . . . . . . . . . . . . . . . . . . … .134
Şəfayi-vəsl qədrin hicr ilə bimar olandan sor . . . . . . . . . . . . . . . . . . . . … .135
Xəm açıldıqca zülfündən bəlavü möhnətim artar . . . . . . . . . . . . . . . . . . ….136
Nola gər rəşki-rüxsarinlə bağrı xubların qandır . . . . . . . . . . . . . . . . . . . .... .137
Səbrim alıb fələk, mənə yüz min bəla verər . . . . . . . . . . . . . . . . . . . . . …. .138
Əzəl katibləri üşşaq bəxtin qarə yazmışlar . . . . . . . . . . . . . . . . . . . . . . . . ...139
Buldu kuyindən dəva dərdi-dili-bimarımız . . . . . . . . . . . . . . . . . . . . . . . ...140
Xəm qədilə ağılaram ol türreyi-tərrarsız . . . . . . . . . . . . . . . . . . . . . . . . . .. .141
Təriqi-fəqr tutsam təb’ tabe’, nəfs ram olmaz . . . . . . . . . . . . . . . . . . . . . ....142
Aləm oldu şad səndən, mən əsiri-qəm hənuz . . . . . . . . . . . . . . . . . . . . … .143
Qəmzə peykanın gözün mən mübtəladən saxlamaz . . . . . . . . . . . . . . . … .144
Razi-eşqin saxlaram eldən nihan, ey sərvinaz . . . . . . . . . . . . . . . . . . . . .... .145
Fəğan kim, bağrımın ol lalərüx qan olduğun bilməz . . . . . . . . . . . . . . . .. .146
Səgridir cilvəyə ol sərv səməndin yenəməz . . . . . . . . . . . . . . . . . . . . . . …147
Könüldə min qəmim vardır ki, pünhan eyləmək olmaz . . . . . . . . . . . . . . .148
Neçə illərdir səri-kuyi-məlamət bəkləriz . . . . . . . . . . . . . . . . . . . . . . . . ….149


403


Təşneyi-cami-vüsalın abi-heyvan istəməz . . . . . . . . . . . . . . . . . . . . . . . …..150
Xəlqə ağızın sirrini hər dəm qılır izhar söz . . . . . . . . . . . . . . . . . . . . . . . ... .151
Mana badi-səba ol sərvi-gülrüxdən xəbər verməz . . . . . . . . . . . . . . . . . ….152
Nəmi-əşkim mükəddər xatirimdən dəf’i-qəm qılmaz . . . . . . . . . . . . . . …..153
Kuhkəndən gözükür kuhdə asar hənuz . . . . . . . . . . . . . . . . . . . . . . . . . . ... .154
Ey könül, ol xəncəri-müjganə eylərsən həvəs . . . . . . . . . . . . . . . . . . . . …. .155
Xaki-rəh etdi aşiqi-miskini ol həvəs . . . . . . . . . . . . . . . . . . . . . . . . . . . …. .156
Məskən, ey bülbül, sənə gəh şaxi-güldür, gəh qəfəs . . . . . . . . . . . . . . . ….157
Göz yaşımdan suzi-pünhanım edər arif qiyas . . . . . . . . . . . . . . . . . . . … . .158
Ey xoş ol məst ki, bilməz qəmi-aləm nə imiş . . . . . . . . . . . . . . . . . . . . …. .159
Bu gün tiğin çəkib, çıxmışdır ol namehriban sərxoş . . . . . . . . . . . . . . . … .160
Büti-növrəsim nəmazə şəbü ruz rağib olmuş . . . . . . . . . . . . . . . . . . . . . .... .161
Bilməz idim bilmək ağızın sirrini düşvar imiş . . . . . . . . . . . . . . . . . . . . ... .162
Dil ki, sərmənzili ol zülfi-pərişan olmuş . . . . . . . . . . . . . . . . . . . . . . . . . …163
Hübabi-əşki-xunin cismimi eldən nihan etmiş . . . . . . . . . . . . . . . . . . . … .164
Ta ki, taği-zərnigarın çərx viran eyləmiş . . . . . . . . . . . . . . . . . . . . . . . … . .165
Cismimi yandırma, rəhm et yaşimə, ey bağrı daş . . . . . . . . . . . . . . . . . …. .166
Zəhi, cəvahiri-ehsani-amə mə’dəni-xas . . . . . . . . . . . . . . . . . . . . . . . . …. .167
Xəlqə xublardan vüsali-rahətəfzadır qərəz . . . . . . . . . . . . . . . . . . . . . . …. .168
Qıl, səba, könlüm pərişan olduğun cananə ərz . . . . . . . . . . . . . . . . . . . . . ...169
Dürcdür lə’li-rəvanbəxşin, düri-şəhvar ləfz . . . . . . . . . . . . . . . . . . . . . . ….170
Afitabi-təl’ətin tutduqca övci-irtifa’ . . . . . . . . . . . . . . . . . . . . . . . . . . . …. .171
Yar vəslin istəyən kəsmək gərək candan təmə’ . . . . . . . . . . . . . . . . . ….. . .172
Dil uzadır bəhs ilə ol arizi-xəndanə şəm’ . . . . . . . . . . . . . . . . . . . . . . . …. .173
Gəl, ey rahət sanan əsbab cəm’in, qılma nadanlıq . . . . . . . . . . . . . . . . . ... .174
Saqiya, mey sun ki, dami-qəmdürür huşyarlıq . . . . . . . . . . . . . . . . . . . . .. .175
Eyş üçün bir türfə mənzildir bahar əyyamı bağ . . . . . . . . . . . . . . . . . . . … .176
Ey xədəngi-qəminə sineyi-əhbab hədəf . . . . . . . . . . . . . . . . . . . . . . . . …. .177
Möhnəti-eşq, ey dil, asandır deyib, çox urma laf . . . . . . . . . . . . . . . . . . ... .178
Olur rüxsarına gün, lə’linə gülbərgi-tər aşiq . . . . . . . . . . . . . . . . . . . . . . ….179
Tabi-xurşid məhi-ruyinə vermiş rövnəq . . . . . . . . . . . . . . . . . . . . . . . . …. .180
Olmaz oldu görüb əhvalımı el xublara aşiq . . . . . . . . . . . . . . . . . . . . . … . .181
Ey fəraqi-ləbi-canan, cigərim xun etdin . . . . . . . . . . . . . . . . . . . . . . . . …. .182
Qıldı zülfün tək pərişan halimi xalin sənin . . . . . . . . . . . . . . . . . . . . . . …. .183
Çeşmimi əşk ilə gənci-düri-məknun etdin . . . . . . . . . . . . . . . . . . . . . . . ….184
Can verir rayiheyi-türbəti-pakin, ey tak . . . . . . . . . . . . . . . . . . . . . . . . . … .185
Şəm’i-ruyin afitabi-aləmaradır sənin . . . . . . . . . . . . . . . . . . . . . . . . . . . .... .186
Öylə rə’nadır, gülüm, sərvi-xuramanın sənin . . . . . . . . . . . . . . . . . . . . …. .187
Daği-hicran ilə yanmaqdan cigər qan olsa yey . . . . . . . . . . . . . . . . . . . …. .188
Qıymadın sakini-kuyin olana peykanın . . . . . . . . . . . . . . . . . . . . . . . . . … .189
Ey məh, mənimlə dustlərim düşmən eylədin . . . . . . . . . . . . . . . . . . . . . … .190


404


Səba, lütf etdin, əhli-dərdə dərmandan xəbər verdin . . . . . . . . . . . . . . … ...191
Bəqa mülkün dilərsən, fani et varini dünya tək . . . . . . . . . . . . . . . . . . . … .192
Dəhənin dərdimə dərman dedilər cananın . . . . . . . . . . . . . . . . . . . . . . . . ....193
Gəlir ol sərvi-səhi, ey gülü lalə, açılın . . . . . . . . . . . . . . . . . . . . . . . . . . ... .194
Ey könül, çox seyr qılma günbədi-dəvvar tək . . . . . . . . . . . . . . . . . . . . ... .195
Var ümidim ki, görüb cövlanını olsam həlak . . . . . . . . . . . . . . . . . . . . . .. .196
Ləbin rəşki mizacın təlx qıldı badeyi-nabın . . . . . . . . . . . . . . . . . . . . . . . ..197
Nə xoşdur arizin dövründə zülfi-ənbərəfşanın . . . . . . . . . . . . . . . . . . . . …198
Ey müsəvvir, yar timsalinə surət vermədin . . . . . . . . . . . . . . . . . . . . . . . …199
Çərx hər ay başına salmış qaşından bir xəyal . . . . . . . . . . . . . . . . . . . . . ….200
Mülki-hüsnün böylə zalim padişahi olmağıl . . . . . . . . . . . . . . . . . . . . . … .201
Bəs ki, zə’fi-ruzədən hər gün bulur təğyiri-hal . . . . . . . . . . . . . . . . . . . . ….202
Eylə müstəsna gözəlsən kim, sənə yoxdur bədəl . . . . . . . . . . . . . . . . . . ….203
Ey rüxün qibleyi-can, xaki-dərin Kə’beyi-dil . . . . . . . . . . . . . . . . . . . . . ....204
Hiç sünbül sünbüli-zülfün kimi mişkin degil . . . . . . . . . . . . . . . . . . . . . … .205
Üzünü güzgüyə qeybətdə oxşadan qafil . . . . . . . . . . . . . . . . . . . . . . . . . ... .206
Canə basdım qönçəvəş peykanını, ey tazə gül . . . . . . . . . . . . . . . . . . . . … .207
Rəhrövi-irfanə bəsdir sağərü saqi dəlil . . . . . . . . . . . . . . . . . . . . . . . . . . ….208
Degilsən çoxdan, ey gərdun, cahan seyrində yoldaşım . . . . . . . . . . . . . … .209
Tənimdə zəxmi-tiğin çeşmi-xunəfşanə bənzətdim . . . . . . . . . . . . . . . . . ….210
Eşqdən canımda bir pünhan mərəz var, ey həkim . . . . . . . . . . . . . . . . . ... .211
Qəmindən başə dün həsrət əlilə ol qədər urdum . . . . . . . . . . . . . . . . . . … .212
Dəhənin şövqünü cansuz güman etməz idim . . . . . . . . . . . . . . . . . . . . . … .213
Bir qul oğılani könül mülkünə sultan etdim . . . . . . . . . . . . . . . . . . . . . . ... .214
Nurini mah mehri-rüxündən alır müdam . . . . . . . . . . . . . . . . . . . . . . . . ... .215
Pənbeyi-daği-cünun içrə nihandır bədənim . . . . . . . . . . . . . . . . . . . . . . … .216
Faş qıldın qəmim, ey dideyi-xunbar, mənim . . . . . . . . . . . . . . . . . . . . . … .217
Ol mah vüsalilə xoş et bir gecə halim . . . . . . . . . . . . . . . . . . . . . . . . . . … ..218
Hər hübabi-əşkimə bir əks salmış peykərim . . . . . . . . . . . . . . . . . . . . . … ..219
Əql yar olsaydı, tərki-eşqi-yar etməzmidim? . . . . . . . . . . . . . . . . . . . . … ..220
Eşigin daşini qan ilə yudu çeşmi-tərim . . . . . . . . . . . . . . . . . . . . . . . . . …. .221
Zülfi kimi ayağın qoymaz öpəm nigarım . . . . . . . . . . . . . . . . . . . . . . . . … .222
Dürdvəş sərgəşteyi-camü xərabi-badəyəm . . . . . . . . . . . . . . . . . . . . . . . ….223
Canlar verib, sənin kimi cananə yetmişəm . . . . . . . . . . . . . . . . . . . . . . . . ...224
Yar hali-dilimi zar bilibdir, bilirəm . . . . . . . . . . . . . . . . . . . . . . . . . . . . … .225
Xoş ol zaman ki, hərimi-vüsalə məhrəm idim . . . . . . . . . . . . . . . . . . . . . ...226
Ney kimi, hər dəm ki, bəzmi-vəslini yad eylərəm . . . . . . . . . . . . . . . . …. .227
Şəm’i-şami-firqətəm, sübhi-vüsali neylərəm? . . . . . . . . . . . . . . . . . . . . ….228
Bağə girdim, səri-kuyin anıb, əfğan etdim . . . . . . . . . . . . . . . . . . . . . . . . ...229
Hicran ilə yanar gecələr rişteyi-canım . . . . . . . . . . . . . . . . . . . . . . . . . . . ....230
Tutuşdu qəm oduna şad gördügün könlüm . . . . . . . . . . . . . . . . . . . . . . . . ...231


405


Qaçan kim, qamətindən ayrı seyri-busitan etdim . . . . . . . . . . . . . . . . . . . ...232
Müxalif dövrdən gülgun şərabı qanə dəgşirdim . . . . . . . . . . . . . . . . . . . .. .233
Qıldı ol sərv səhər naz ilə həmmamə xüram . . . . . . . . . . . . . . . . . . . . . . …234
Eə kəmanəbru, şəhidi-navəki-müjganinəm . . . . . . . . . . . . . . . . . . . . . . . ....235
Səcdədir hər qanda bir büt görsəm, ayinim mənim . . . . . . . . . . . . . . . . … .236
Zairi-meyxanəyəm, müğ səcdəsidir ta’ətim . . . . . . . . . . . . . . . . . . . . . . ….237
Kərəm qıl, kəsmə, saqi, iltifatın binəvalərdən . . . . . . . . . . . . . . . . . . . . . ....238
Yaqma canım, naleyi-biixtiyarımdan saqın . . . . . . . . . . . . . . . . . . . . . . . ....239
Ey geyib gülgun, dəmadəm əzmi-cövlan eyləyən . . . . . . . . . . . . . . . . . . …240
Nola zahid bilsə küfri-zülfün iman olduğun . . . . . . . . . . . . . . . . . . . . . . . ...241
Sipehrin fariğəm vəslində, mahü aftabindən . . . . . . . . . . . . . . . . . . . . . . ....242
Dust bipərva, fələk birəhm, dövran bisükun . . . . . . . . . . . . . . . . . . . . . . ….243
Çirağ göydüricək atəşi-nihanımdan . . . . . . . . . . . . . . . . . . . . . . . . . . . . . …244
Ucaldın qəbrim, ey bidərdlər, səngi-məlamətdən . . . . . . . . . . . . . . . . . . ….245
Budur fərqi, könül, məhşər gününün ruzi-hicrandan . . . . . . . . . . . . . . . . ...246
Bəzmi-eşq içrə şərabımdır sirişki-laləgun . . . . . . . . . . . . . . . . . . . . . . . . …247
Əgərçi ignə tək keçdim cahanın hər nə varindən . . . . . . . . . . . . . . . . . . ….248
Yerə düşməz hər nə ox kim, atsa ol əbrukəman . . . . . . . . . . . . . . . . . . . ….249
Görüb mühlik mənim çevrəmdə bəhri-eşq tüğyanın . . . . . . . . . . . . . . . … .250
Şəfa lütf et, məni-bimarə lə’li-nuşxəndindən . . . . . . . . . . . . . . . . . . . . . ….251
Ələ alır gəzicək ol güli-rə’na ətəgin . . . . . . . . . . . . . . . . . . . . . . . . . . . . ….252
Görməsəm hər göz açanda ol güli-rə’na üzün . . . . . . . . . . . . . . . . . . . . .... .253
Sün’-me’marı yapar saətdə gərdun məxzənin . . . . . . . . . . . . . . . . . . . . . …254
Qurutmuş qaliba şövq odu Fərhadın gözü yaşın . . . . . . . . . . . . . . . . . . . . .255
Kuhkən künd eyləmiş min tişəni bir dağilən . . . . . . . . . . . . . . . . . . . . . . ...256
Gərdi-rəhin, ey əşk, yudun çeşmi-tərimdən . . . . . . . . . . . . . . . . . . . . . . ….257
Ta sirişki-dideyi-Fərhadi gördü laləgun . . . . . . . . . . . . . . . . . . . . . . . . . ….258
Cəm’ könlün dövr cövründən pərişan olmasın . . . . . . . . . . . . . . . . . . . . ... .259
Topraqdən götür məni, ey əşki-laləgun . . . . . . . . . . . . . . . . . . . . . . . . . . ....260
Bari-möhnətdən nihali-qamətin xəm olmasın . . . . . . . . . . . . . . . . . . . . … .261
Gör sirişkim şəbi-hicran, demə kim, qandır bu . . . . . . . . . . . . . . . . . . . . …262
Nihali-dərddir Məcnun, yer etmiş sayəsin ahu . . . . . . . . . . . . . . . . . . . . ….263
Bülbüli-dil gülşəni-rüxsarın eylər arizu . . . . . . . . . . . . . . . . . . . . . . . . . . …264
Rəməzan oldu, çəkib şahidi-mey pərdəyə ru . . . . . . . . . . . . . . . . . . . . . ….265
Əgər çıxsaydı dərdin cismdən, derdim ki, candır bu . . . . . . . . . . . . . . . . …266
Aşiq oldum yenə bir tazə güli-rə’nayə . . . . . . . . . . . . . . . . . . . . . . . . . . . …267
Olsaydı məndəki qəm Fərhadi-mübtəladə . . . . . . . . . . . . . . . . . . . . . . . .... .268
Istədim mərhəm oxundan cigərim yarəsinə . . . . . . . . . . . . . . . . . . . . . . . ....269
Bağə gir, bülbülə ərzi-güli-rüxsar eylə . . . . . . . . . . . . . . . . . . . . . . . . . . ….270
Uyub ahuyə düşdü mişk Məcnun tək biyabanə . . . . . . . . . . . . . . . . . . . . ...271
Ey dili-sərgəştəvü şikəsteyi-valeh . . . . . . . . . . . . . . . . . . . . . . . . . . . . . …. .272


406


Daraldır qönçə həlqin, dürci lə’lin gəlsə göftarə . . . . . . . . . . . . . . . . . . … .273
Rəhm et, ey şəh, məni-dərviş çəkən ahlərə . . . . . . . . . . . . . . . . . . . . . . . ….274
Yenə ol mah mənim aldı qərarım bu gecə . . . . . . . . . . . . . . . . . . . . . . . … .275
Nihali-sərvdir qəddin, qaşın nun ol nihal üzrə . . . . . . . . . . . . . . . . . . . . … .276
Müshəf demək xətadır ol səfheyi-cəmalə . . . . . . . . . . . . . . . . . . . . . . . …. .277
Həzər qıl ah odundan, cövrünü üşşaqə az eylə . . . . . . . . . . . . . . . . . . . . ….278
Batalı qanə oxun dideyi-giryan içrə . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ....279
Arizin görsə fələk, mehr buraxmaz ayə . . . . . . . . . . . . . . . . . . . . . . . . . . ....280
Su verər hər sübhdəm göz yaşı tiği-ahimə . . . . . . . . . . . . . . . . . . . . . . . … .281
Yürütməyin ərəqi məclis içrə badə ilə . . . . . . . . . . . . . . . . . . . . . . . . . . … .282
Xoşdur ey gün, talein kim, düşdün ol xaki-dərə . . . . . . . . . . . . . . . . . . … .283
Könül, səccadəyə basma ayaq, təsbihə əl urma . . . . . . . . . . . . . . . . . . . . ...284
Ey vücudi-kamilin, əsrari-hikmət məsdəri . . . . . . . . . . . . . . . . . . . . . . . …285
Ey vücudun əsəri, xilqəti-əşya səbəbi . . . . . . . . . . . . . . . . . . . . . . . . . . . ...286
Ey xoş ol günlər ki, rüxsarın mənə mənzur idi . . . . . . . . . . . . . . . . . . . . ....287
Ey təğafül birlə hər saət qılan şeyda məni . . . . . . . . . . . . . . . . . . . . . . . ... .288
Buraqdı xakə hüsnün afitabi-aləmarayi . . . . . . . . . . . . . . . . . . . . . . . . . … .289
Məni candan usandırdı, cəfadən yar usanmazmı? . . . . . . . . . . . . . . . . . . ...290
Getdi əldən sənəmin sünbüli-mişkəfşani . . . . . . . . . . . . . . . . . . . . . . . . … .291
Gecələr ta halimə gərdun təmaşa etmədi . . . . . . . . . . . . . . . . . . . . . . . . . ....292
Fariğ etdi mehrin özgə məhliqalərdən məni . . . . . . . . . . . . . . . . . . . . . …. .293
Çöhreyi-zərdimdə gör həmdəm sirişki-alimi . . . . . . . . . . . . . . . . . . . . . ….294
Yar qılmazsa mənə cövrü cəfadən qeyri . . . . . . . . . . . . . . . . . . . . . . . . . ….295
Yıxdı saqi, bir əyaq ilə məni-əfgari . . . . . . . . . . . . . . . . . . . . . . . . . . . . … .296
Nə görər əhli-cəfa məndə vəfadən qeyri . . . . . . . . . . . . . . . . . . . . . . . . . …297
Tərəşşüh qəbrimin daşından etmiş çeşmimin yaşi . . . . . . . . . . . . . . . . . . ...298
Hasilim yox səri-kuyində bəladən qeyri . . . . . . . . . . . . . . . . . . . . . . . . . …299
Heyrət, ey büt, surətin gördükdə lal eylər məni . . . . . . . . . . . . . . . . . . . ... .300
Aldı gülzar içrə su əksi-üzari-alini . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ….301
Gördüm ol xurşidi-hüsnün, ixtiyarım qalmadı . . . . . . . . . . . . . . . . . . . . … .302
Hər görən eyb etdi abi-dideyi-giryanimi . . . . . . . . . . . . . . . . . . . . . . . . . ….303
Canımın cismilə zövqi-ittisali qalmadı . . . . . . . . . . . . . . . . . . . . . . . . . . . ...304
Giryədir hər dəm açan qəmdən tutulmuş könlümü . . . . . . . . . . . . . . . . … .305
Sanma kim, bülbül açar uçmağa balü pərini . . . . . . . . . . . . . . . . . . . . . . .. ..306
Tabi-suzi-sinədən əksilməsəydi göz nəmi . . . . . . . . . . . . . . . . . . . . . . . …..307
Tilismi-gənc üçün min ismi-ə’zəm yad tutdun, tut . . . . . . . . . . . . . . . . . ….308
Şö’leyi-şəm’i-rüxün əğyarə bəzməfruz olur . . . . . . . . . . . . . . . . . . . . . . ….308
Qərqi-xunabi-dil etdi dideyi-giryan məni . . . . . . . . . . . . . . . . . . . . . . . . .....309
Xoşdur irmək ol bədən vəslinə pirahən kimi . . . . . . . . . . . . . . . . . . . . . … .310
Mey peyapey sunma, saqi, qılma layə’qil məni . . . . . . . . . . . . . . . . . . . . ...311
Qamətin xidmətinə sərvin əgilməz başi . . . . . . . . . . . . . . . . . . . . . . . . . . ....312


407


Mərhəm qoyub önərmə, sinəmdə qanlı daği . . . . . . . . . . . . . . . . . . . . . . ….313
Xoş gəldi dün ol ayə sirişkim nəzarəsi . . . . . . . . . . . . . . . . . . . . . . . . . ... . .314
Məgər xab içrə gördün, ey könül, ol çeşmi-şəhlayi . . . . . . . . . . . . . . . . . …315
Mübəddəl qılmağa sübhi-vüsalə şami-hicrani . . . . . . . . . . . . . . . . . . . . . …316
Yetər, ey fələk, bu cəfa, yetir məni-zarə sərvi-rəvanimi . . . . . . . . . . . . …...317
Ey səfi-novki-müjən zülfi-məlamət şanəsi . . . . . . . . . . . . . . . . . . . . . . . .....318
Ayinə sevər candan rüxsareyi-canani . . . . . . . . . . . . . . . . . . . . . . . . . . . .. ..319
Məhşər günü görüm derəm, ol sərvqaməti . . . . . . . . . . . . . . . . . . . . . . . . ...320
Rəvacın nəqdi-peykanınla bulmuş hüsn bazari . . . . . . . . . . . . . . . . . . . . …321
Ey, hər təkəllümüm xəti-səbzin hekayəti . . . . . . . . . . . . . . . . . . . . . . . . ….322
Göz qarası əşki-gülgunimdə xalın sədqəsi . . . . . . . . . . . . . . . . . . . . . . . . …323
Ləbin əksi gözüm yaşini mey tək laləgun etdi . . . . . . . . . . . . . . . . . . . . … .324
Ey saçın fikri qamu sövdalərin sərmayəsi . . . . . . . . . . . . . . . . . . . . . . . . …325
Dün könül dilbərə şərhi-qəmi-pünhan etdi . . . . . . . . . . . . . . . . . . . . . . . …326
Ey göz, ol nərgisi-xunxarə nigah etmə dəxi . . . . . . . . . . . . . . . . . . . . . . ….327
Könül, yetdi əcəl, zövqi-rüxi-dildar yetməzmi? . . . . . . . . . . . . . . . . . . . ….328
Tərcibəndlər, tərkibbəndlər,
müxəmməs, təxmis və mürəbbelər
Mən kiməm? – Bir bikəsü biçarəvü bixaniman . . . . . . . . . . . . . . . . . . . . ...331
Mənəm ki, qafiləsalari-karivani-qəməm . . . . . . . . . . . . . . . . . . . . . . . . . …334
Gətir, saqi, qədəh kim, novbahari-aləmaradır! . . . . . . . . . . . . . . . . . . . . ….336
Dün sayə saldı başimə bir sərvi-sərbülənd . . . . . . . . . . . . . . . . . . . . . . . ….339
Vay, yüz min vay kim, dildardən ayrılmışam . . . . . . . . . . . . . . . . . . . . . . ..341
Ey hərir içrə tənin mütləq bülur içrə gülab . . . . . . . . . . . . . . . . . . . . . . . ....342
Tən pozuldu əşki-çeşmi-xunfəşanimdən mənim . . . . . . . . . . . . . . . . . . . …343
Ta cünun rəxtin geyib, tutdum fəna mülkün vətən . . . . . . . . . . . . . . . . . …344
Candadır sübhi-əzəldən mehri-rüxsarın sənin . . . . . . . . . . . . . . . . . . . . . …345
Necə bir vəsvəseyi-əql ilə qəmnak olalım . . . . . . . . . . . . . . . . . . . . . . . . …346
Pərişan halin oldum, sormadın hali-pərişanım . . . . . . . . . . . . . . . . . . . . . …347
Hasilim bərqi-həvadisdən məlamət dağıdır . . . . . . . . . . . . . . . . . . . . . . . …348
Qitələr . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ….351
Rübailər . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . …...365
Əlavələr . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ….380
Lüğət . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ...383


408


Buraxılışa məsul: _Əziz Güləliyev_


Texniki redaktor: _Rövşən Ağayev_


Tərtibatçı-rəssam: _Nərgiz Əliyeva_


Kompyuter səhifələyicisi: _Rəvan Mürsəlov_


Korrektor: _Pərvanə Məmmədova_


Yığılmağa verilmişdir 03.10.2004. Çapa imzalanmışdır 01.04.2005.
Formatı 60x90 [1] /16. Fiziki çap vərəqi 25. Ofset çap üsulu.
Tirajı 25000. Sifariş 67.
Kitab “PROMAT” mətbəəsində çap olunmuşdur.


409


